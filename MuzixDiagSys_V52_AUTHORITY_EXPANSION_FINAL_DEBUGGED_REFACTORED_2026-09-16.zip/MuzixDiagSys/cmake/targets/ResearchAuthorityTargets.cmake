# Fundamental-physics algorithms are isolated from the broad advanced-platform
# archive so their unit tests and downstream research tools do not need to
# compile or link every unrelated advanced subsystem.  aesim_advanced retains
# the complete public feature surface through its PUBLIC dependency below.
add_library(aesim_fundamental_physics STATIC
  src/advanced/fundamental_physics_platform.cpp
)
target_include_directories(aesim_fundamental_physics PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
aesim_configure_target(aesim_fundamental_physics)

# Generalized engineering-operations qualification is isolated from the broad
# advanced archive so software-engineering workflows can be built and tested
# without compiling unrelated vehicle/motorsport domains.
add_library(aesim_generalized_engineering_operations STATIC
  src/advanced/generalized_engineering_operations_concurrency_io_storage.cpp
  src/advanced/generalized_engineering_operations_governance_testing.cpp
  src/advanced/generalized_engineering_operations_coverage_architecture.cpp
  src/advanced/generalized_engineering_operations_soak_fuzz.cpp
)
target_include_directories(aesim_generalized_engineering_operations PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_generalized_engineering_operations PUBLIC aesim_professional aesim_core Threads::Threads)
if(WIN32)
  target_link_libraries(aesim_generalized_engineering_operations PUBLIC ws2_32)
endif()
aesim_configure_target(aesim_generalized_engineering_operations)

# Native C++ qualification is a separate additive V34 layer. It consumes the
# V33 generalized engineering-operations foundation without duplicating its
# coverage/build-cost/test-management primitives.
add_library(aesim_native_qualification STATIC
  src/advanced/native_qualification_sanitizer_configuration.cpp
  src/advanced/native_qualification_reproducibility_binary.cpp
  src/advanced/native_qualification_stochastic_resources_process.cpp
  src/advanced/native_qualification_static_fault_differential.cpp
)
target_include_directories(aesim_native_qualification PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_native_qualification PUBLIC aesim_generalized_engineering_operations aesim_professional aesim_core Threads::Threads)
aesim_configure_target(aesim_native_qualification)

# V35 motorsport expansion is isolated from the broad advanced archive so the
# endurance/rally/Formula-E/GT and cross-series engineering models can be built
# and qualified without recompiling unrelated simulation domains.  Existing
# F1/IndyCar/NASCAR/NHRA and frontier compatibility surfaces remain unchanged.
add_library(aesim_motorsport_v35 STATIC
  src/advanced/motorsport_v35_endurance_bop_gt.cpp
  src/advanced/motorsport_v35_rally_formulae_driver.cpp
  src/advanced/motorsport_v35_track_racecraft_strategy.cpp
  src/advanced/motorsport_v35_lap_coaching.cpp
)
target_include_directories(aesim_motorsport_v35 PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_motorsport_v35 PUBLIC aesim_core)
aesim_configure_target(aesim_motorsport_v35)

# Canonical lightweight multi-objective optimization authority.  This target
# isolates the existing NSGA-II/Bayesian optimizer so domain platforms can
# reuse it without duplicating algorithms or depending on the entire advanced
# archive.
add_library(aesim_optimization STATIC
  src/advanced/optimization.cpp
)
target_include_directories(aesim_optimization PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_optimization PUBLIC aesim_core)
aesim_configure_target(aesim_optimization)

# Shared statistical-inference authority.  HMC/NUTS/MLMC previously lived
# only inside the broad aesim_advanced archive, which prevented lower-level
# research authorities from reusing the canonical samplers without dependency
# inversion.  V48 promotes the existing implementation into a focused library;
# no algorithm is duplicated.
add_library(aesim_statistics STATIC
  src/advanced/frontier_professional_statistics.cpp
)
target_include_directories(aesim_statistics PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_statistics PUBLIC aesim_core Threads::Threads)
aesim_configure_target(aesim_statistics)

# Focused reusable R4 services promoted for V49.  These are the canonical
# implementations formerly compiled only inside aesim_advanced; keeping them
# in one lower-level archive lets performance authorities reuse passivity,
# adaptive co-simulation, and co-kriging without a dependency cycle.
add_library(aesim_research_authority_reusable STATIC
  src/advanced/research_authority_reusable.cpp
)
target_include_directories(aesim_research_authority_reusable PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_research_authority_reusable PUBLIC aesim_core Threads::Threads)
aesim_configure_target(aesim_research_authority_reusable)

# Hardware discovery/placement is shared by the V40.4 scheduler and the
# Frontier Runtime Sensing facade.  V49 promotes the established implementation
# out of the broad advanced archive without changing the public API.
add_library(aesim_frontier_hardware STATIC
  src/advanced/frontier_hardware_scheduler.cpp
)
target_include_directories(aesim_frontier_hardware PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_frontier_hardware PUBLIC aesim_core Threads::Threads)
aesim_configure_target(aesim_frontier_hardware)

# Canonical heterogeneous scheduler promoted from runtime_scaling_execution.cpp
# so lower-level performance/UQ authorities can dispatch deterministic indexed
# ensembles through the existing V40.4 execution policy.
add_library(aesim_runtime_scheduler STATIC
  src/advanced/runtime_scaling_scheduler.cpp
)
target_include_directories(aesim_runtime_scheduler PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_runtime_scheduler PUBLIC aesim_frontier_hardware aesim_core Threads::Threads)
aesim_configure_target(aesim_runtime_scheduler)

# V36 Professional Authority Platform. This additive layer consolidates the
# requested high-fidelity authority models and composes existing V35, MDF/HIL,
# UQ and numerical-assurance services instead of duplicating them.
add_library(aesim_professional_authority_v36 STATIC
  src/advanced/professional_authority_dynamics.cpp
  src/advanced/professional_authority_operations.cpp
  src/advanced/professional_authority_science.cpp
  src/advanced/suspension_research_platform.cpp
  src/advanced/performance_reality_platform.cpp
  src/advanced/performance_reality_v49.cpp
  src/advanced/vehicle_reality_r1_platform.cpp
)
target_include_directories(aesim_professional_authority_v36 PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_professional_authority_v36 PUBLIC
  aesim_motorsport_v35 aesim_industrial aesim_optimization aesim_statistics
  aesim_research_authority_reusable aesim_runtime_scheduler aesim_core Threads::Threads ${CMAKE_DL_LIBS})
aesim_configure_target(aesim_professional_authority_v36)

# V37 ECU / Diagnostics / SocketCAN Authority Platform. This additive layer
# extends the canonical UDS/ECM/SocketCAN/XCP/assurance authorities and does
# not introduce competing protocol engines.
add_library(aesim_ecu_diagnostics_socketcan_v37 STATIC
  src/industrial/ecu_diagnostics_v37_protocol.cpp
  src/industrial/ecu_diagnostics_v37_regulatory.cpp
  src/industrial/ecu_diagnostics_v37_socketcan.cpp
  src/industrial/ecu_diagnostics_v37_engineering.cpp
)
target_include_directories(aesim_ecu_diagnostics_socketcan_v37 PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_ecu_diagnostics_socketcan_v37 PUBLIC
  aesim_industrial aesim_diagnostics aesim_professional aesim_core Threads::Threads ZLIB::ZLIB OpenSSL::Crypto ${CMAKE_DL_LIBS})
aesim_configure_target(aesim_ecu_diagnostics_socketcan_v37)

add_library(aesim_advanced STATIC
  src/advanced/interoperability.cpp
  src/advanced/learning_environment.cpp
  src/advanced/safety_analysis.cpp
  src/advanced/cyber_security.cpp
  src/advanced/homologation.cpp
  src/advanced/distributed_execution.cpp
  src/advanced/execution_graph.cpp
  src/advanced/generalized_infrastructure_g1.cpp
  src/advanced/compiler_synthesis_ai.cpp
  src/advanced/sdv_security_network.cpp
  src/advanced/scene_reliability_compute.cpp
  src/advanced/codegen_manufacturing_fleet.cpp
  src/advanced/digital_thread_calibration.cpp
  src/advanced/electrical_battery_architecture.cpp
  src/advanced/world_spectral_city.cpp
  src/advanced/crash_lifecycle.cpp
  src/advanced/scenario_localization.cpp
  src/advanced/mlops_laboratory.cpp
  src/advanced/multiphysics_tire.cpp
  src/advanced/v50_reality_authority.cpp
  src/advanced/v50_reality_io.cpp
  src/advanced/v51_scientific_reality_a.cpp
    src/advanced/v51_scientific_reality_b.cpp
    src/advanced/v51_scientific_reality_c.cpp
  src/advanced/fleet_soc.cpp
  src/advanced/passport_service.cpp
  src/advanced/compliance_toolchain.cpp
  src/advanced/measurement_debug_regression.cpp
  src/advanced/realtime_autosar.cpp
  src/advanced/ads_cad.cpp
  src/advanced/collaborative_studio.cpp
  src/advanced/next_generation_labs.cpp
  src/advanced/integrated_frontier_platform.cpp
  src/advanced/must_have_platform.cpp
  src/advanced/deep_engineering_platform.cpp
  src/advanced/qualification_science_platform.cpp
  src/advanced/materials_energy_multiphysics_platform_a.cpp
  src/advanced/materials_energy_multiphysics_platform_b.cpp
  src/advanced/silicon_human_infrastructure_platform_a.cpp
  src/advanced/silicon_human_infrastructure_platform_b.cpp
  src/advanced/atomistic_remote_operations_platform_a.cpp
  src/advanced/atomistic_remote_operations_platform_b.cpp
  src/advanced/architecture_intelligence_sustainability_platform_a.cpp
  src/advanced/architecture_intelligence_sustainability_platform_b.cpp
  src/advanced/next_generation_autonomy_platform_a.cpp
  src/advanced/next_generation_autonomy_platform_b.cpp
  src/advanced/frontier_compute_energy_risk_platform_a.cpp
  src/advanced/frontier_compute_energy_risk_platform_b.cpp
  src/advanced/certified_deployment_infrastructure_platform.cpp
  src/advanced/assured_engineering_operations_platform_a.cpp
  src/advanced/assured_engineering_operations_platform_b.cpp
  src/advanced/operational_digital_infrastructure_platform_a.cpp
  src/advanced/operational_digital_infrastructure_platform_b.cpp
  src/advanced/automotive_standards_conformance_platform.cpp
  src/advanced/emerging_mobility_platform.cpp
  src/advanced/generalized_simulation_platform_a.cpp
  src/advanced/generalized_simulation_platform_b.cpp
  src/advanced/generalized_simulation_platform_c.cpp
  src/advanced/scientific_fidelity_platform_a.cpp
  src/advanced/scientific_fidelity_platform_b.cpp
  src/advanced/scientific_fidelity_platform_c.cpp
  src/advanced/continuum_reality_platform_a.cpp
  src/advanced/continuum_reality_platform_b.cpp
  src/advanced/continuum_reality_platform_c.cpp
  src/advanced/frontier_vehicle_ecosystem_platform.cpp
  src/advanced/electronics_power_distribution_platform.cpp
  src/advanced/electronics_circuit_conversion_platform.cpp
  src/advanced/embedded_electronics_assurance_platform.cpp
  src/advanced/nhra_championship_strategy_platform.cpp
  src/advanced/nhra_race_engineering_platform.cpp
  src/advanced/nhra_deep_authority_platform.cpp
  src/advanced/nhra_deep_authority_a_b.cpp
  src/advanced/nhra_deep_authority_c_d.cpp
  src/advanced/nhra_deep_authority_e_f.cpp
  src/advanced/nhra_deep_authority_g_h.cpp
  src/advanced/nhra_deep_authority_i_j.cpp
  src/advanced/motogp_authority_platform.cpp
  src/advanced/motogp_authority_a_b.cpp
  src/advanced/motogp_authority_c_d.cpp
  src/advanced/motogp_authority_e_f.cpp
  src/advanced/motogp_authority_g_h.cpp
  src/advanced/motogp_authority_i_j.cpp
  src/advanced/frontier_runtime_sensing_platform.cpp
  src/advanced/frontier_expansion_platform_a.cpp
  src/advanced/frontier_expansion_platform_b.cpp
  src/advanced/frontier_expansion_platform_c.cpp
  src/advanced/frontier_expansion_platform_d.cpp
  src/advanced/frontier_systems_platform_a.cpp
  src/advanced/frontier_systems_platform_b.cpp
  src/advanced/frontier_systems_platform_c.cpp
  src/advanced/frontier_systems_platform_d.cpp
  src/advanced/frontier_integration_platform_a.cpp
  src/advanced/frontier_integration_platform_b.cpp
  src/advanced/frontier_integration_platform_c.cpp
  src/advanced/frontier_integration_platform_d.cpp
  src/advanced/frontier_next_platform.cpp
  src/advanced/connected_vehicle_security.cpp
  src/advanced/connected_vehicle_sensing.cpp
  src/advanced/connected_vehicle_compute.cpp
  src/advanced/connected_vehicle_power_telematics.cpp
  src/advanced/experimental_mechanics_nvh.cpp
  src/advanced/experimental_mechanics_xfem.cpp
  src/advanced/experiment_intelligence_platform.cpp
  src/advanced/engineering_validation_platform.cpp
  src/advanced/engineering_validation_extensions.cpp
  src/advanced/engineering_intelligence_platform_a.cpp
  src/advanced/engineering_intelligence_platform_b.cpp
  src/advanced/engineering_intelligence_platform_c.cpp
  src/advanced/engineering_intelligence_expansion_platform.cpp
  src/advanced/runtime_scaling_numerics.cpp
  src/advanced/runtime_scaling_execution.cpp
  src/advanced/runtime_scaling_assurance_pdes.cpp

  # R1-R7 Research Authority — ordered next-generation scientific platform.
  src/advanced/research_authority_r1.cpp
  src/advanced/research_authority_r2.cpp
  src/advanced/research_authority_r3.cpp
  src/advanced/research_authority_r4.cpp
  src/advanced/research_authority_r5.cpp
  src/advanced/research_authority_r6.cpp
  src/advanced/research_authority_r7.cpp

  # Frontier Professional Integration (ordered implementation surface).
  src/advanced/frontier_professional_opcua_aas.cpp
  src/advanced/frontier_professional_dil_openxr.cpp
  src/advanced/frontier_professional_hardware_io.cpp
  src/advanced/frontier_professional_ns3.cpp
  src/advanced/frontier_professional_prometheus.cpp
  src/advanced/frontier_professional_sigstore.cpp
  src/advanced/frontier_professional_acoustics.cpp
  src/advanced/frontier_professional_federated_privacy.cpp

  # V52 Authority Expansion — additive authority/interoperability upgrades.
  src/advanced/v52_formal_security.cpp
  src/advanced/v52_scientific_cae.cpp
  src/advanced/v52_interoperability.cpp
  src/advanced/v52_data_streaming.cpp
  src/advanced/v52_completion.cpp
  src/advanced/v52_completion_science.cpp
  src/advanced/v52_completion_industrial.cpp
  src/advanced/v52_completion_cad.cpp
)
target_include_directories(aesim_advanced PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_advanced PUBLIC aesim_formula_one aesim_indycar aesim_nascar aesim_fundamental_physics aesim_industrial aesim_generalized_engineering_operations aesim_professional aesim_core aesim_engineering
  aesim_native_qualification aesim_motorsport_v35 aesim_professional_authority_v36 aesim_ecu_diagnostics_socketcan_v37
  aesim_optimization aesim_statistics aesim_research_authority_reusable aesim_runtime_scheduler aesim_frontier_hardware
  ${AESIM_SQLITE_TARGET} OpenSSL::Crypto Threads::Threads ${CMAKE_DL_LIBS})
if(MPI_CXX_FOUND)
  target_link_libraries(aesim_advanced PUBLIC MPI::MPI_CXX)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_MPI=1)
endif()
if(AESIM_HAVE_NATIVE_ULFM)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_NATIVE_ULFM=1)
endif()
if(AESIM_HIP_AVAILABLE)
  target_sources(aesim_advanced PRIVATE src/advanced/frontier_expansion_particle_hip.hip)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAS_PARTICLE_HIP=1)
  set_source_files_properties(src/advanced/frontier_expansion_particle_hip.hip PROPERTIES LANGUAGE HIP)
endif()
if(OpenMP_CXX_FOUND)
  target_link_libraries(aesim_advanced PUBLIC OpenMP::OpenMP_CXX)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_OPENMP=1)
endif()
if(TARGET Kokkos::kokkos)
  target_link_libraries(aesim_advanced PUBLIC Kokkos::kokkos)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_KOKKOS=1)
endif()
if(AESIM_HDF5_INCLUDE_DIR AND AESIM_HDF5_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_HDF5_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_HDF5_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_HDF5=1)
endif()
if(AESIM_NETCDF_INCLUDE_DIR AND AESIM_NETCDF_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_NETCDF_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_NETCDF_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_NETCDF=1)
endif()
if(AESIM_HAVE_ZFP_NATIVE)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_ZFP_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_ZFP_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_ZFP_NATIVE=1)
endif()
if(AESIM_HAVE_SZ3_NATIVE)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_SZ3_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_SZ3_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_SZ3_NATIVE=1)
endif()
if(CUDAToolkit_FOUND AND TARGET CUDA::cudart)
  target_link_libraries(aesim_advanced PUBLIC CUDA::cudart)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_CUDA_RUNTIME=1)
endif()
if(AESIM_PETSC_INCLUDE_DIR AND AESIM_PETSC_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_PETSC_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_PETSC_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_PETSC_NATIVE=1)
endif()
if(AESIM_SUNDIALS_INCLUDE_DIR AND AESIM_SUNDIALS_CVODE_LIBRARY AND AESIM_SUNDIALS_NVEC_LIBRARY
   AND AESIM_SUNDIALS_SUNMATRIX_DENSE_LIBRARY AND AESIM_SUNDIALS_SUNLINSOL_DENSE_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_SUNDIALS_INCLUDE_DIR})
  set(_aesim_sundials_native_libraries
    ${AESIM_SUNDIALS_CVODE_LIBRARY}
    ${AESIM_SUNDIALS_NVEC_LIBRARY}
    ${AESIM_SUNDIALS_SUNMATRIX_DENSE_LIBRARY}
    ${AESIM_SUNDIALS_SUNLINSOL_DENSE_LIBRARY})
  # SUNDIALS 6+/7.x splits SUNContext/SUNMatrix/SUNLinearSolver common symbols
  # into libsundials_core.  Propagate it PUBLIC so final executables that link
  # the static aesim_advanced archive receive the required DSO explicitly.
  if(AESIM_SUNDIALS_CORE_LIBRARY)
    list(APPEND _aesim_sundials_native_libraries ${AESIM_SUNDIALS_CORE_LIBRARY})
  endif()
  target_link_libraries(aesim_advanced PUBLIC ${_aesim_sundials_native_libraries})
  unset(_aesim_sundials_native_libraries)
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_SUNDIALS_NATIVE=1)
endif()
if(AESIM_HYPRE_INCLUDE_DIR AND AESIM_HYPRE_LIBRARY AND MPI_CXX_FOUND)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_HYPRE_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_HYPRE_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_HYPRE_NATIVE=1)
endif()
if(AESIM_ADIOS2_INCLUDE_DIR AND AESIM_ADIOS2_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_ADIOS2_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_ADIOS2_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_ADIOS2_NATIVE=1)
endif()
if(AESIM_CGNS_INCLUDE_DIR AND AESIM_CGNS_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_CGNS_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_CGNS_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_CGNS_NATIVE=1)
endif()
if(AESIM_EXODUS_INCLUDE_DIR AND AESIM_EXODUS_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_EXODUS_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_EXODUS_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_EXODUS_NATIVE=1)
endif()
if(AESIM_NCCL_INCLUDE_DIR AND AESIM_NCCL_LIBRARY AND MPI_CXX_FOUND AND CUDAToolkit_FOUND AND TARGET CUDA::cudart)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_NCCL_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_NCCL_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_NCCL_NATIVE=1)
endif()
if(AESIM_OPEN62541_INCLUDE_DIR AND AESIM_OPEN62541_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_OPEN62541_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_OPEN62541_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_OPEN62541=1)
endif()
if(AESIM_OPENXR_INCLUDE_DIR AND AESIM_OPENXR_LIBRARY)
  target_include_directories(aesim_advanced PRIVATE ${AESIM_OPENXR_INCLUDE_DIR})
  target_link_libraries(aesim_advanced PUBLIC ${AESIM_OPENXR_LIBRARY})
  target_compile_definitions(aesim_advanced PRIVATE AESIM_HAVE_OPENXR=1)
endif()
if(WIN32)
  target_link_libraries(aesim_advanced PUBLIC ws2_32)
endif()
aesim_configure_target(aesim_advanced)

# V38 Advanced Automotive Electronics & Compute Authority.  This layer extends
# the canonical advanced electronics/compute/network/power/security models and
# deliberately composes them rather than introducing competing replacements.
add_library(aesim_electronics_compute_v38 STATIC
  src/advanced/automotive_electronics_compute_phase_a.cpp
  src/advanced/automotive_electronics_compute_phase_b.cpp
  src/advanced/automotive_electronics_compute_phase_c.cpp
  src/advanced/automotive_electronics_compute_phase_d.cpp
  src/advanced/automotive_electronics_compute_phase_e.cpp
)
target_include_directories(aesim_electronics_compute_v38 PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_electronics_compute_v38 PUBLIC aesim_advanced)
aesim_configure_target(aesim_electronics_compute_v38)


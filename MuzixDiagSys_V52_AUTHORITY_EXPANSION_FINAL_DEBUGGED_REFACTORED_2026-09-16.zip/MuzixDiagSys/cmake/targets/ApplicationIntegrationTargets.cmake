add_library(aesim_fmi3_model SHARED fmi/aesim_fmi3_model.cpp)
target_include_directories(aesim_fmi3_model PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
set_target_properties(aesim_fmi3_model PROPERTIES
  LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/fmu3/x86_64-linux
  PREFIX ""
  OUTPUT_NAME "aesim_powertrain"
)
aesim_configure_target(aesim_fmi3_model)

add_library(aesim_sample_sil_controller SHARED plugins/sample_sil_controller.cpp)
target_include_directories(aesim_sample_sil_controller PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
set_target_properties(aesim_sample_sil_controller PROPERTIES
  LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/controllers
  PREFIX "lib"
)
aesim_configure_target(aesim_sample_sil_controller)

# Older developer builds staged plugins/ as a symlink into the source tree.
# Remove only that legacy symlink during configure so native plugin outputs can
# never be written into the checkout. A real build-local directory is retained.
if(UNIX AND IS_SYMLINK "${CMAKE_CURRENT_BINARY_DIR}/plugins")
  file(REMOVE "${CMAKE_CURRENT_BINARY_DIR}/plugins")
endif()
file(MAKE_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/plugins")

add_library(aesim_sample_native_plugin_v2 SHARED plugins/sample_native_plugin_v2.cpp)
target_include_directories(aesim_sample_native_plugin_v2 PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
set_target_properties(aesim_sample_native_plugin_v2 PROPERTIES
  LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/plugins
  PREFIX "lib"
)
aesim_configure_target(aesim_sample_native_plugin_v2)

# Shared advanced-platform CLI dispatcher. The primary interactive executable and
# the standalone advanced CLI use the same implementation so API/motorsport
# command semantics cannot drift.
add_library(aesim_advanced_cli STATIC
  tools/advanced_platform_cli.cpp
  tools/advanced_platform_interactive.cpp
  tools/advanced_api_cli_registry.cpp
  tools/advanced_api_cli_frontend.cpp
  tools/advanced_api_cli_extensions.cpp
  tools/advanced_api_cli_execute.cpp
  tools/advanced_api_cli_orchestration.cpp
  tools/advanced_api_cli_vehicle_services.cpp
  tools/advanced_api_cli_verification_assurance.cpp
  tools/advanced_api_cli_lifecycle_services.cpp
  tools/advanced_api_cli_transport_services.cpp
  tools/advanced_api_cli_system_services.cpp
  tools/advanced_api_cli_engineering_expansion.cpp
  tools/advanced_api_cli_core.cpp
  tools/advanced_api_cli_materials_physics.cpp
  tools/advanced_api_cli_software_scientific.cpp
  tools/advanced_api_cli_simulation.cpp
  tools/advanced_api_cli_frontier.cpp)
target_include_directories(aesim_advanced_cli PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/tools ${AESIM_NGHTTP2_INCLUDE_DIR})
target_compile_definitions(aesim_advanced_cli PRIVATE MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")
target_link_libraries(aesim_advanced_cli PUBLIC aesim_advanced PRIVATE ${AESIM_NGHTTP2_LIBRARY})
if(WIN32)
  target_link_libraries(aesim_advanced_cli PRIVATE ws2_32 psapi)
endif()
aesim_configure_target(aesim_advanced_cli)
if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
  # The advanced CLI consists of control-heavy command dispatch/serialization
  # translation units rather than numerical kernels.  The transactional build
  # wrapper defaults to RelWithDebInfo, so protecting only Release leaves the
  # normal developer/CI path at -O2 where GCC/Clang can spend minutes and large
  # amounts of memory optimizing these dispatchers.  Keep numerical libraries
  # fully optimized while compiling this front-end layer at -Og in both release
  # configurations that carry optimization.
  target_compile_options(aesim_advanced_cli PRIVATE
    $<$<CONFIG:Release>:-Og>
    $<$<CONFIG:RelWithDebInfo>:-Og>)
endif()

# Shared dispatchers for every standalone non-test backend/tool executable.
# Each executable links only its own implementation; the aggregate registry is
# linked by the primary interactive shell. This preserves exact parity without
# forcing unrelated standalone tools to inherit every backend dependency.
add_library(aesim_engineering_cli_impl STATIC tools/engineering_cli.cpp)
target_include_directories(aesim_engineering_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_engineering_cli_impl PUBLIC aesim_engineering aesim_industrial aesim_professional Threads::Threads)
aesim_configure_target(aesim_engineering_cli_impl)

add_library(aesim_causal_cli_impl STATIC tools/causal_simulation_cli.cpp)
target_include_directories(aesim_causal_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_causal_cli_impl PUBLIC aesim_industrial)
aesim_configure_target(aesim_causal_cli_impl)

add_library(aesim_advanced_safety_cli_impl STATIC tools/advanced_safety_cli.cpp)
target_include_directories(aesim_advanced_safety_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_advanced_safety_cli_impl PUBLIC aesim_industrial)
aesim_configure_target(aesim_advanced_safety_cli_impl)

add_library(aesim_specification_discovery_cli_impl STATIC tools/specification_discovery_cli.cpp)
target_include_directories(aesim_specification_discovery_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_specification_discovery_cli_impl PUBLIC aesim_industrial)
aesim_configure_target(aesim_specification_discovery_cli_impl)

add_library(aesim_standards_deployment_cli_impl STATIC tools/standards_deployment_cli.cpp)
target_include_directories(aesim_standards_deployment_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_standards_deployment_cli_impl PUBLIC aesim_industrial)
aesim_configure_target(aesim_standards_deployment_cli_impl)

add_library(aesim_frontier_professional_cli_impl STATIC tools/frontier_professional_cli.cpp)
target_include_directories(aesim_frontier_professional_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_frontier_professional_cli_impl PRIVATE MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")
target_link_libraries(aesim_frontier_professional_cli_impl PUBLIC aesim_advanced)
aesim_configure_target(aesim_frontier_professional_cli_impl)

add_library(aesim_study_worker_cli_impl STATIC tools/study_worker.cpp)
target_include_directories(aesim_study_worker_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_study_worker_cli_impl PUBLIC aesim_industrial)
aesim_configure_target(aesim_study_worker_cli_impl)

add_library(aesim_research_reference_cli_impl STATIC tools/research_reference_generator.cpp)
target_include_directories(aesim_research_reference_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_research_reference_cli_impl PUBLIC aesim_core)
aesim_configure_target(aesim_research_reference_cli_impl)

# Reusable dispatchers for the newer standalone platform executables.  The same
# source file still owns each executable's behavior; AESIM_BACKEND_CLI_LIBRARY
# suppresses only the process-level main() wrapper for in-process shell reuse.
add_library(aesim_generalized_ops_cli_impl STATIC tools/generalized_engineering_operations_main.cpp)
target_include_directories(aesim_generalized_ops_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_generalized_ops_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_generalized_ops_cli_impl PUBLIC aesim_generalized_engineering_operations)
aesim_configure_target(aesim_generalized_ops_cli_impl)

add_library(aesim_native_qualification_cli_impl STATIC tools/native_qualification_main.cpp)
target_include_directories(aesim_native_qualification_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_native_qualification_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_native_qualification_cli_impl PUBLIC aesim_native_qualification)
aesim_configure_target(aesim_native_qualification_cli_impl)

add_library(aesim_motorsport_v35_cli_impl STATIC tools/motorsport_v35_main.cpp)
target_include_directories(aesim_motorsport_v35_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_motorsport_v35_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_motorsport_v35_cli_impl PUBLIC aesim_motorsport_v35)
aesim_configure_target(aesim_motorsport_v35_cli_impl)

add_library(aesim_professional_authority_v36_cli_impl STATIC tools/professional_authority_v36_main.cpp)
target_include_directories(aesim_professional_authority_v36_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_professional_authority_v36_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_professional_authority_v36_cli_impl PUBLIC aesim_professional_authority_v36)
aesim_configure_target(aesim_professional_authority_v36_cli_impl)

add_library(aesim_ecu_diagnostics_v37_cli_impl STATIC tools/ecu_diagnostics_socketcan_v37_main.cpp)
target_include_directories(aesim_ecu_diagnostics_v37_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_ecu_diagnostics_v37_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_ecu_diagnostics_v37_cli_impl PUBLIC aesim_ecu_diagnostics_socketcan_v37)
aesim_configure_target(aesim_ecu_diagnostics_v37_cli_impl)

add_library(aesim_v50_reality_cli_impl STATIC tools/v50_reality_main.cpp)
target_include_directories(aesim_v50_reality_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_v50_reality_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_v50_reality_cli_impl PUBLIC aesim_advanced)
aesim_configure_target(aesim_v50_reality_cli_impl)

add_library(aesim_v51_reality_cli_impl STATIC tools/v51_reality_main.cpp)
target_include_directories(aesim_v51_reality_cli_impl PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(aesim_v51_reality_cli_impl PRIVATE AESIM_BACKEND_CLI_LIBRARY=1)
target_link_libraries(aesim_v51_reality_cli_impl PUBLIC aesim_advanced)
aesim_configure_target(aesim_v51_reality_cli_impl)

add_library(aesim_backend_cli STATIC tools/backend_cli_registry.cpp)
target_include_directories(aesim_backend_cli PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_backend_cli PUBLIC
  aesim_engineering_cli_impl
  aesim_causal_cli_impl
  aesim_advanced_safety_cli_impl
  aesim_specification_discovery_cli_impl
  aesim_standards_deployment_cli_impl
  aesim_frontier_professional_cli_impl
  aesim_study_worker_cli_impl
  aesim_research_reference_cli_impl
  aesim_generalized_ops_cli_impl
  aesim_native_qualification_cli_impl
  aesim_motorsport_v35_cli_impl
  aesim_professional_authority_v36_cli_impl
  aesim_ecu_diagnostics_v37_cli_impl
  aesim_v50_reality_cli_impl
  aesim_v51_reality_cli_impl)
aesim_configure_target(aesim_backend_cli)

if(AESIM_BUILD_TOOLS)
  add_executable(muzixdiagsys_v50_reality tools/v50_reality_main.cpp)
  target_include_directories(muzixdiagsys_v50_reality PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_v50_reality PRIVATE aesim_advanced)
  aesim_configure_target(muzixdiagsys_v50_reality)

  add_executable(muzixdiagsys_v51_reality tools/v51_reality_main.cpp)
  target_include_directories(muzixdiagsys_v51_reality PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_v51_reality PRIVATE aesim_advanced)
  aesim_configure_target(muzixdiagsys_v51_reality)

  add_executable(aesim_study_worker tools/study_worker_main.cpp)
  target_include_directories(aesim_study_worker PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(aesim_study_worker PRIVATE aesim_study_worker_cli_impl)
  aesim_configure_target(aesim_study_worker)

  add_executable(research_reference_generator tools/research_reference_generator_main.cpp)
  target_include_directories(research_reference_generator PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(research_reference_generator PRIVATE aesim_research_reference_cli_impl)
  aesim_configure_target(research_reference_generator)

  add_executable(muzixdiagsys_engineering tools/engineering_main.cpp)
  target_include_directories(muzixdiagsys_engineering PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_engineering PRIVATE aesim_engineering_cli_impl)
  aesim_configure_target(muzixdiagsys_engineering)

  add_executable(muzixdiagsys_causal_lab tools/causal_simulation_main.cpp)
  target_include_directories(muzixdiagsys_causal_lab PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_causal_lab PRIVATE aesim_causal_cli_impl)
  aesim_configure_target(muzixdiagsys_causal_lab)

  add_executable(muzixdiagsys_advanced_safety tools/advanced_safety_main.cpp)
  target_include_directories(muzixdiagsys_advanced_safety PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_advanced_safety PRIVATE aesim_advanced_safety_cli_impl)
  aesim_configure_target(muzixdiagsys_advanced_safety)

  add_executable(muzixdiagsys_specification_discovery tools/specification_discovery_main.cpp)
  target_include_directories(muzixdiagsys_specification_discovery PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_specification_discovery PRIVATE aesim_specification_discovery_cli_impl)
  aesim_configure_target(muzixdiagsys_specification_discovery)

  add_executable(muzixdiagsys_standards_deployment tools/standards_deployment_main.cpp)
  target_include_directories(muzixdiagsys_standards_deployment PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_standards_deployment PRIVATE aesim_standards_deployment_cli_impl)
  aesim_configure_target(muzixdiagsys_standards_deployment)

  add_executable(muzixdiagsys_frontier_professional tools/frontier_professional_main.cpp)
  target_include_directories(muzixdiagsys_frontier_professional PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_frontier_professional PRIVATE aesim_frontier_professional_cli_impl)
  aesim_configure_target(muzixdiagsys_frontier_professional)

  add_executable(muzixdiagsys_advanced_platform tools/advanced_platform_main.cpp)
  target_include_directories(muzixdiagsys_advanced_platform PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_advanced_platform PRIVATE aesim_advanced_cli)
  aesim_configure_target(muzixdiagsys_advanced_platform)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    # Preserve the standalone front-end's FORTIFY-compatible Release policy even
    # though its feature implementation now lives in aesim_advanced_cli.
    target_compile_options(muzixdiagsys_advanced_platform PRIVATE $<$<CONFIG:Release>:-Og>)
  endif()

  add_executable(muzixdiagsys_generalized_ops tools/generalized_engineering_operations_main.cpp)
  target_include_directories(muzixdiagsys_generalized_ops PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_generalized_ops PRIVATE aesim_generalized_engineering_operations)
  aesim_configure_target(muzixdiagsys_generalized_ops)

  add_executable(muzixdiagsys_native_qualification tools/native_qualification_main.cpp)
  target_include_directories(muzixdiagsys_native_qualification PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_native_qualification PRIVATE aesim_native_qualification)
  aesim_configure_target(muzixdiagsys_native_qualification)

  add_executable(muzixdiagsys_motorsport_v35 tools/motorsport_v35_main.cpp)
  target_include_directories(muzixdiagsys_motorsport_v35 PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_motorsport_v35 PRIVATE aesim_motorsport_v35)
  aesim_configure_target(muzixdiagsys_motorsport_v35)

  add_executable(muzixdiagsys_professional_authority_v36 tools/professional_authority_v36_main.cpp)
  target_include_directories(muzixdiagsys_professional_authority_v36 PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_professional_authority_v36 PRIVATE aesim_professional_authority_v36)
  aesim_configure_target(muzixdiagsys_professional_authority_v36)

  add_executable(muzixdiagsys_ecu_diagnostics_v37 tools/ecu_diagnostics_socketcan_v37_main.cpp)
  target_include_directories(muzixdiagsys_ecu_diagnostics_v37 PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
  target_link_libraries(muzixdiagsys_ecu_diagnostics_v37 PRIVATE aesim_ecu_diagnostics_socketcan_v37)
  aesim_configure_target(muzixdiagsys_ecu_diagnostics_v37)
endif()

find_package(Python3 COMPONENTS Interpreter REQUIRED)
set(AESIM_ENGINEERING_BROWSER_ASSET_CPP "${CMAKE_CURRENT_BINARY_DIR}/generated/engineering_browser_asset.cpp")
add_custom_command(
  OUTPUT "${AESIM_ENGINEERING_BROWSER_ASSET_CPP}"
  COMMAND "${CMAKE_COMMAND}" -E make_directory "${CMAKE_CURRENT_BINARY_DIR}/generated"
  COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/embed_web_asset.py"
          --input "${CMAKE_CURRENT_SOURCE_DIR}/web/engineering_browser.html"
          --output "${AESIM_ENGINEERING_BROWSER_ASSET_CPP}"
  DEPENDS
    "${CMAKE_CURRENT_SOURCE_DIR}/web/engineering_browser.html"
    "${CMAKE_CURRENT_SOURCE_DIR}/tools/embed_web_asset.py"
    "${CMAKE_CURRENT_SOURCE_DIR}/include/aesim/app/engineering_browser_asset.hpp"
  COMMENT "Embedding deterministic engineering browser asset"
  VERBATIM)
set_source_files_properties("${AESIM_ENGINEERING_BROWSER_ASSET_CPP}" PROPERTIES GENERATED TRUE)

add_library(aesim_console_support STATIC
  "${AESIM_ENGINEERING_BROWSER_ASSET_CPP}"
  src/ui/terminal_text.cpp
  src/ui/terminal_rendering_foundation.cpp
  src/ui/professional_tui_presentation.cpp
  src/ui/terminal_input.cpp
  src/ui/ui_experience.cpp
  src/ui/ui_customization_platform.cpp
  src/ui/global_ui_architecture.cpp
  src/ui/workflow_flexibility_platform.cpp
  src/ui/workflow_intelligence_platform.cpp
  src/ui/tui_productivity_platform.cpp
  src/ui/tui_ide_interaction.cpp
  src/ui/engineering_ui_platform.cpp
  src/ui/engineering_instrumentation.cpp
  src/ui/advanced_debugging_verification.cpp
  src/ui/advanced_analysis_operations.cpp
  src/ui/advanced_assurance_debugging_v23.cpp
  src/ui/runtime_intelligence_v24.cpp
  src/ui/tui_intelligence_v25.cpp
  src/ui/advanced_engineering_workbenches.cpp
  src/ui/terminal_workstation_platform.cpp
  src/ui/tui_resilience_v31.cpp
  src/ui/tui_self_diagnostics_v32.cpp
  src/ui/professional_engineering_desktop_v12.cpp
  src/ui/professional_engineering_operations_v13.cpp
)
target_include_directories(aesim_console_support PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_console_support PUBLIC aesim_core aesim_engineering Threads::Threads)
aesim_configure_target(aesim_console_support)
# These engineering TUI sources are large control/formatting translation units,
# not numerical kernels. Keep GNU optimization bounded in optimized developer
# builds to prevent pathological compile-time and peak-memory growth while
# preserving hardening and full optimization in the simulation libraries.
if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
  set(_aesim_tui_control_sources
    src/ui/engineering_ui_platform.cpp
    src/ui/workflow_flexibility_platform.cpp
    src/ui/workflow_intelligence_platform.cpp
    src/ui/tui_productivity_platform.cpp
    src/ui/tui_ide_interaction.cpp
    src/ui/advanced_debugging_verification.cpp
    src/ui/advanced_analysis_operations.cpp
    src/ui/advanced_assurance_debugging_v23.cpp
    src/ui/runtime_intelligence_v24.cpp
    src/ui/tui_intelligence_v25.cpp
    src/ui/advanced_engineering_workbenches.cpp
    src/ui/terminal_workstation_platform.cpp
    src/ui/terminal_rendering_foundation.cpp
    src/ui/professional_tui_presentation.cpp
    src/ui/tui_resilience_v31.cpp
    src/ui/tui_self_diagnostics_v32.cpp
    src/ui/professional_engineering_desktop_v12.cpp
    src/ui/professional_engineering_operations_v13.cpp)
  set_property(SOURCE ${_aesim_tui_control_sources}
    APPEND PROPERTY COMPILE_OPTIONS
      $<$<CONFIG:Debug>:-O0>
      $<$<CONFIG:Release>:-Og>
      $<$<CONFIG:RelWithDebInfo>:-Og>
      $<$<CONFIG:MinSizeRel>:-Os>)
  unset(_aesim_tui_control_sources)
endif()

add_executable(muzixdiagsys
  src/muzixdiagsys.cpp
  src/security/console_authentication.cpp
  src/simulation_runtime_helpers.cpp
  src/simulation_runtime.cpp
  src/ui/console_frontend.cpp
  src/ui/performance_cli_support.cpp
)
add_dependencies(muzixdiagsys aesim_fmi3_model aesim_sample_sil_controller aesim_sample_native_plugin_v2)
target_include_directories(muzixdiagsys PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(muzixdiagsys PRIVATE MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}" AESIM_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}" AESIM_FMI3_BINARY_PATH="$<TARGET_FILE:aesim_fmi3_model>")
target_link_libraries(muzixdiagsys PRIVATE aesim_console_support aesim_advanced_cli aesim_backend_cli aesim_core aesim_professional aesim_industrial aesim_engineering Threads::Threads ${CMAKE_DL_LIBS})
aesim_configure_target(muzixdiagsys)
# Simulation orchestration and the terminal frontend are independent translation
# units. GCC's normal release optimizer is pathological on these unusually large
# control-heavy translation units, while the previous unconditional -O0 override
# can trigger pathological compile time and memory growth. Keep the orchestration
# translation unit at -Og in Release; numerical kernels remain in optimized
# libraries. -Og keeps glibc _FORTIFY_SOURCE active while retaining bounded compile
# cost for this control-heavy orchestration code.
if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
  set_property(SOURCE src/simulation_runtime.cpp
    APPEND PROPERTY COMPILE_OPTIONS
      $<$<CONFIG:Debug>:-O0>
      $<$<CONFIG:Release>:-Og>
      $<$<CONFIG:RelWithDebInfo>:-Og>
      $<$<CONFIG:MinSizeRel>:-Os>)
  # The terminal orchestration TU is control/formatting code, not a numerical
  # kernel. Keep bounded optimization in optimized configurations so glibc
  # _FORTIFY_SOURCE remains active while avoiding the full -O3 optimizer cost.
  set_property(SOURCE src/ui/console_frontend.cpp
    APPEND PROPERTY COMPILE_OPTIONS
      $<$<CONFIG:Debug>:-O0>
      $<$<CONFIG:Release>:-Og>
      $<$<CONFIG:RelWithDebInfo>:-Og>
      $<$<CONFIG:MinSizeRel>:-Os>)
endif()

# Keep the feature-dense console executable practical to build. The numerically
# intensive research modules live in aesim_core/aesim_industrial and retain the
# normal CMake optimization level. The target-level setting remains a fallback
# for small launcher sources and non-source-specific compiler configurations.
if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
  target_compile_options(muzixdiagsys PRIVATE
    $<$<CONFIG:Debug>:-g1>
    $<$<CONFIG:Debug>:-fno-var-tracking>
    $<$<CONFIG:Debug>:-fno-var-tracking-assignments>
    $<$<CONFIG:Release>:-Og>
    $<$<CONFIG:RelWithDebInfo>:-O1>
    $<$<CONFIG:RelWithDebInfo>:-g1>
    $<$<CONFIG:RelWithDebInfo>:-fno-var-tracking>
    $<$<CONFIG:MinSizeRel>:-Os>
  )
  if(AESIM_ENABLE_SANITIZERS)
    # Full sanitizer instrumentation is retained; only expensive variable-level
    # debug bookkeeping is reduced for the unusually large compatibility TU.
    target_compile_options(muzixdiagsys PRIVATE -g1 -fno-var-tracking)
    find_program(AESIM_LLD_LINKER ld.lld)
    if(AESIM_LLD_LINKER)
      # GNU ld can spend many minutes resolving the heavily instrumented legacy
      # object. lld is materially faster and does not alter sanitizer coverage.
      target_link_options(muzixdiagsys PRIVATE -fuse-ld=lld)
    endif()
  endif()
endif()

add_library(aesim_sample_native_plugin SHARED plugins/sample_native_plugin.cpp)
target_include_directories(aesim_sample_native_plugin PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
set_target_properties(aesim_sample_native_plugin PROPERTIES
  LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/plugins
  PREFIX "lib"
)
aesim_configure_target(aesim_sample_native_plugin)

# Keep out-of-source builds self-contained. Runtime resources remain private
# build-local copies because tests and interactive sessions may write exports
# below data/. The plugin directory is refreshed without deletion so compiled
# plugin shared libraries are not removed by the executable post-build step.
# Only the large legacy executable name is linked on Unix.
if(UNIX)
  add_custom_command(TARGET muzixdiagsys POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E rm -rf
            $<TARGET_FILE_DIR:muzixdiagsys>/data
            $<TARGET_FILE_DIR:muzixdiagsys>/configs
            $<TARGET_FILE_DIR:muzixdiagsys>/engine_sim${CMAKE_EXECUTABLE_SUFFIX}
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/data $<TARGET_FILE_DIR:muzixdiagsys>/data
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/plugins $<TARGET_FILE_DIR:muzixdiagsys>/plugins
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/configs $<TARGET_FILE_DIR:muzixdiagsys>/configs
    COMMAND ${CMAKE_COMMAND} -E create_symlink
            $<TARGET_FILE_NAME:muzixdiagsys>
            $<TARGET_FILE_DIR:muzixdiagsys>/engine_sim${CMAKE_EXECUTABLE_SUFFIX}
    COMMENT "Staging MuzixDiagSys resources and linking compatibility launcher"
  )
else()
  add_custom_command(TARGET muzixdiagsys POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/data $<TARGET_FILE_DIR:muzixdiagsys>/data
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/plugins $<TARGET_FILE_DIR:muzixdiagsys>/plugins
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/configs $<TARGET_FILE_DIR:muzixdiagsys>/configs
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
            $<TARGET_FILE:muzixdiagsys>
            $<TARGET_FILE_DIR:muzixdiagsys>/engine_sim${CMAKE_EXECUTABLE_SUFFIX}
    COMMENT "Copying MuzixDiagSys runtime resources and compatibility launcher"
  )
endif()

install(TARGETS muzixdiagsys RUNTIME DESTINATION bin)
if(TARGET muzixdiagsys_engineering)
  install(TARGETS muzixdiagsys_engineering RUNTIME DESTINATION bin)
  install(DIRECTORY python/muzixdiag DESTINATION share/muzixdiagsys/python)
  install(FILES python/pyproject.toml DESTINATION share/muzixdiagsys/python)
  install(FILES docs/ENGINEERING_PLATFORM.md
                docs/VALIDATION_LIFECYCLE_PLATFORM.md
          DESTINATION share/muzixdiagsys/docs)
endif()
if(TARGET muzixdiagsys_causal_lab)
  install(TARGETS muzixdiagsys_causal_lab RUNTIME DESTINATION bin)
endif()
if(TARGET muzixdiagsys_advanced_safety)
  install(TARGETS muzixdiagsys_advanced_safety RUNTIME DESTINATION bin)
  install(FILES docs/ADVANCED_SAFETY_DISCOVERY_PLATFORM.md
          DESTINATION share/muzixdiagsys/docs)
endif()
if(TARGET muzixdiagsys_specification_discovery)
  install(TARGETS muzixdiagsys_specification_discovery RUNTIME DESTINATION bin)
  install(FILES docs/SPECIFICATION_DISCOVERY_VERIFICATION_SUITE.md
          DESTINATION share/muzixdiagsys/docs)
endif()
if(TARGET muzixdiagsys_standards_deployment)
  install(TARGETS muzixdiagsys_standards_deployment RUNTIME DESTINATION bin)
  install(FILES docs/STANDARDS_DEPLOYMENT_CREDIBILITY_PLATFORM.md
          DESTINATION share/muzixdiagsys/docs)
endif()
if(TARGET muzixdiagsys_advanced_platform)
  install(TARGETS muzixdiagsys_advanced_platform RUNTIME DESTINATION bin)
  install(FILES docs/ADVANCED_CYBER_PHYSICAL_PLATFORM.md
          DESTINATION share/muzixdiagsys/docs)
endif()
install(TARGETS aesim_sample_native_plugin aesim_sample_native_plugin_v2
  LIBRARY DESTINATION share/muzixdiagsys/plugins
  RUNTIME DESTINATION share/muzixdiagsys/plugins)
install(FILES docs/STREAMLINED_UI_EXPERIENCE.md
              docs/REAL_WORLD_TUI_USAGE_GUIDE.md
              docs/GLOBAL_NUMERICAL_RIGOR.md
              docs/GLOBAL_MATHEMATICAL_ASSURANCE.md
        DESTINATION share/muzixdiagsys/docs)
install(DIRECTORY data plugins configs DESTINATION share/muzixdiagsys
  PATTERN "*.so" EXCLUDE
  PATTERN "*.dll" EXCLUDE
  PATTERN "*.dylib" EXCLUDE)

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/notebooks")
  install(DIRECTORY notebooks DESTINATION share/muzixdiagsys)
endif()
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/integrations/ns3")
  install(DIRECTORY integrations/ns3 DESTINATION share/muzixdiagsys/integrations)
endif()
if(TARGET muzixdiagsys_frontier_professional)
  install(TARGETS muzixdiagsys_frontier_professional RUNTIME DESTINATION bin)
endif()
install(FILES docs/FRONTIER_PROFESSIONAL_INTEGRATION.md
        DESTINATION share/muzixdiagsys/docs OPTIONAL)

# A compatibility build target keeps `cmake --build ... --target engine_sim`
# working while the primary executable target and output are MuzixDiagSys.
add_custom_target(engine_sim DEPENDS muzixdiagsys)

find_package(Python3 COMPONENTS Interpreter QUIET)
if(Python3_Interpreter_FOUND)
  add_custom_target(source_package
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tools/package_source.py
            ${CMAKE_CURRENT_BINARY_DIR}/MuzixDiagSys-source.zip
            --root ${CMAKE_CURRENT_SOURCE_DIR}
            --prefix MuzixDiagSys
    COMMENT "Creating deterministic source-only MuzixDiagSys archive")
  add_custom_target(clean_generated_artifacts
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tools/clean_generated_artifacts.py
    COMMENT "Removing reproducible simulator output from the source tree")
endif()

add_library(aesim_core STATIC
  src/core/numerical_rigor.cpp
  src/core/mathematical_assurance.cpp
  src/core/multirate_kernel.cpp
  src/core/accuracy.cpp
  src/core/cylinder_combustion.cpp
  src/core/gas_path.cpp
  src/core/validation.cpp
  src/core/uncertainty.cpp
  src/core/calibration.cpp
  src/core/automated_assurance.cpp
  src/core/provenance.cpp
  src/core/research_core.cpp
  src/core/research_workflows.cpp
  src/core/realism_systems.cpp
)
target_include_directories(aesim_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_core
  PUBLIC Threads::Threads
  PRIVATE OpenSSL::Crypto
)
aesim_configure_target(aesim_core)


add_library(aesim_professional STATIC
  src/security/authentication.cpp
  src/security/authorization.cpp
  src/professional/document.cpp
  src/professional/project.cpp
  src/professional/units.cpp
  src/professional/schema.cpp
  src/professional/checkpoint.cpp
  src/professional/health.cpp
  src/professional/scenario.cpp
  src/professional/plugin_host.cpp
  src/professional/execution.cpp
  src/professional/fmi3.cpp
  src/professional/research_state.cpp
)
target_include_directories(aesim_professional PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_professional PUBLIC aesim_core Threads::Threads ZLIB::ZLIB OpenSSL::Crypto ${CMAKE_DL_LIBS})
aesim_configure_target(aesim_professional)

# Diagnostic domain boundary.  Protocol semantics and transport adapters are
# built independently from the broad vehicle/research library so CLI, test,
# SocketCAN, DoIP, SOVD, and virtual-adapter clients cannot select a competing
# implementation by linking a different industrial object set.
add_library(aesim_diagnostics STATIC
  src/industrial/network.cpp
  src/industrial/network_fault_lab.cpp
  src/industrial/can_obd.cpp
  src/industrial/diagnostic_service.cpp
  src/industrial/ecm_obd_platform.cpp
  src/industrial/diagnostic_workflow.cpp
  src/industrial/diagnostic_causal_graph.cpp
  src/industrial/diagnostic_compat.cpp
  src/industrial/virtual_diagnostics.cpp
  src/industrial/measured_validation.cpp
)
target_include_directories(aesim_diagnostics PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_diagnostics PUBLIC aesim_professional aesim_core Threads::Threads OpenSSL::Crypto ${CMAKE_DL_LIBS})
aesim_configure_target(aesim_diagnostics)

set(AESIM_ELECTRIFICATION_SOURCES
  src/electrification/battery.cpp
  src/electrification/hybrid.cpp
  src/electrification/charging.cpp
  src/electrification/thermal.cpp
  src/electrification/modelica.cpp
  src/electrification/middleware.cpp
  src/electrification/acceleration.cpp
  src/electrification/onnx.cpp
  src/electrification/platform.cpp
  src/electrification/advanced_vehicle.cpp
  src/electrification/cell_resolved_pack.cpp
)

option(AESIM_ENABLE_SYCL "Build the native SYCL compute backend when the compiler supports it" ON)
option(AESIM_ENABLE_HIP "Build the native ROCm/HIP compute backend when a HIP compiler is available" ON)

message(STATUS "MuzixDiagSys build policy: hardening=${AESIM_ENABLE_HARDENING}, strict-numerics=${AESIM_ENABLE_STRICT_NUMERICS}, sanitizers=${AESIM_ENABLE_SANITIZERS}, LTO=${AESIM_ENABLE_LTO}, SYCL=${AESIM_ENABLE_SYCL}, HIP=${AESIM_ENABLE_HIP}")
include(CheckCXXSourceCompiles)
include(CheckLanguage)
set(AESIM_SYCL_AVAILABLE OFF)
if(AESIM_ENABLE_SYCL)
  set(CMAKE_REQUIRED_FLAGS_SAVED "${CMAKE_REQUIRED_FLAGS}")
  set(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} -fsycl")
  check_cxx_source_compiles("#include <sycl/sycl.hpp>
int main(){sycl::queue q; return q.get_device().is_cpu()?0:0;}" AESIM_SYCL_AVAILABLE)
  set(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS_SAVED}")
  if(AESIM_SYCL_AVAILABLE)
    list(APPEND AESIM_ELECTRIFICATION_SOURCES src/electrification/acceleration_sycl.cpp)
  endif()
endif()

set(AESIM_HIP_AVAILABLE OFF)
if(AESIM_ENABLE_HIP)
  check_language(HIP)
  if(CMAKE_HIP_COMPILER)
    enable_language(HIP)
    set(AESIM_HIP_AVAILABLE ON)
    list(APPEND AESIM_ELECTRIFICATION_SOURCES src/electrification/acceleration_hip.hip)
  endif()
endif()

add_library(aesim_industrial STATIC
  src/industrial/signals.cpp
  src/industrial/archive.cpp
  src/industrial/realtime.cpp
  src/industrial/hil_io.cpp
  src/industrial/xcp.cpp
  src/industrial/mdf.cpp
  src/industrial/xil.cpp
  src/industrial/ssp.cpp
  src/industrial/traceability.cpp
  src/industrial/fault_campaign.cpp
  src/industrial/platform.cpp
  src/assurance/assurance.cpp
  src/assurance/resilience.cpp
  src/assurance/resilience_cli.cpp
  src/vehicle/world.cpp
  src/vehicle/dynamics.cpp
  src/vehicle/advanced_dynamics.cpp
  src/vehicle/high_fidelity_chassis.cpp
  src/vehicle/high_fidelity_powertrain.cpp
  src/vehicle/high_fidelity_controls.cpp
  src/vehicle/high_fidelity_engine.cpp
  src/vehicle/engine_research_digital_twin.cpp
  src/vehicle/engine_v45_physics.cpp
  src/vehicle/high_fidelity_integrated.cpp
  src/vehicle/depth_structural_environment.cpp
  src/vehicle/depth_electrical_aero_brake.cpp
  src/vehicle/depth_autosar_replay_fidelity.cpp
  src/vehicle/depth_integrated.cpp
  src/vehicle/ecosystem_thermofluid_powertrain.cpp
  src/vehicle/transmission_authority.cpp
  src/vehicle/ecosystem_battery_sensors.cpp
  src/vehicle/ecosystem_human_world_interop.cpp
  src/vehicle/ecosystem_integrated.cpp
  src/vehicle/lifecycle_physics.cpp
  src/vehicle/lifecycle_fluid_network.cpp
  src/vehicle/lifecycle_systems.cpp
  src/vehicle/lifecycle_integrated.cpp
  src/vehicle/perception_realism.cpp
  src/vehicle/connected.cpp
  src/vehicle/study.cpp
  src/vehicle/platform.cpp
  src/vehicle/experience_lifecycle_timeline.cpp
  src/vehicle/experience_physics_world.cpp
  src/vehicle/experience_workshop_visual.cpp
  src/vehicle/automotive_lab.cpp
  src/frontier/digital_thread.cpp
  src/frontier/v2x.cpp
  src/frontier/openx.cpp
  src/frontier/runaway.cpp
  src/frontier/vecu.cpp
  src/frontier/differentiable.cpp
  src/frontier/platform.cpp
  src/research2/coupling_osi.cpp
  src/research2/estimation_bayes.cpp
  src/research2/reachability_surrogate.cpp
  src/research2/deterministic_observability.cpp
  src/research2/causal_runtime.cpp
  src/research2/resilience_simulation.cpp
  src/research2/rare_differentiable.cpp
  src/research2/advanced_search_diagnostics.cpp
  src/research2/advanced_assurance_control.cpp
  src/research2/advanced_execution_twin.cpp
  src/research2/specification_temporal_discovery.cpp
  src/research2/specification_formal_assurance.cpp
  src/research2/specification_perception_fleet.cpp
  src/research2/standards_scenario_odd.cpp
  src/research2/standards_formal_runtime.cpp
  src/research2/standards_perception_intelligence.cpp
  src/research2/platform.cpp
  src/federation/hla_dcp.cpp
  src/federation/vecu_control.cpp
  src/federation/qualification_cloud.cpp
  src/federation/platform.cpp
  ${AESIM_ELECTRIFICATION_SOURCES}
)
target_include_directories(aesim_industrial PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_industrial PUBLIC aesim_diagnostics aesim_professional aesim_core ${AESIM_SQLITE_TARGET} Threads::Threads ZLIB::ZLIB OpenSSL::Crypto ${CMAKE_DL_LIBS})
if(AESIM_SYCL_AVAILABLE)
  target_compile_definitions(aesim_industrial PRIVATE AESIM_HAS_SYCL=1)
  # The target can also contain a HIP translation unit.  Apply -fsycl only to
  # ordinary C++ sources so Clang's HIP frontend never sees a conflicting
  # accelerator-driver option when both toolchains are installed.
  target_compile_options(aesim_industrial PRIVATE
    $<$<COMPILE_LANGUAGE:CXX>:-fsycl>
  )
  target_link_options(aesim_industrial PRIVATE -fsycl)
endif()
if(AESIM_HIP_AVAILABLE)
  target_compile_definitions(aesim_industrial PRIVATE AESIM_HAS_HIP=1)
  set_source_files_properties(src/electrification/acceleration_hip.hip PROPERTIES LANGUAGE HIP)
endif()
aesim_configure_target(aesim_industrial)



add_library(aesim_engineering STATIC
  src/platform/workspace_campaign.cpp
  src/platform/replay_fault_telemetry.cpp
  src/platform/diagnostics_reporting.cpp
  src/platform/learning_models.cpp
  src/platform/requirements_analytics.cpp
  src/platform/assurance_collaboration.cpp
  src/platform/thermal_battery_lifecycle.cpp
  src/platform/timing_fleet_prognostics.cpp
  src/studio/action_signal_timeline.cpp
  src/studio/contracts_debug.cpp
  src/studio/validation_minimizer_capsule.cpp
  src/studio/calibration_topology.cpp
  src/studio/observatory_manufacturing.cpp
  src/studio/engineering_studio.cpp
  src/app/engineering_studio_runtime.cpp
)
target_include_directories(aesim_engineering PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_engineering PUBLIC aesim_industrial aesim_professional aesim_core Threads::Threads OpenSSL::Crypto ${CMAKE_DL_LIBS})
if(WIN32)
  target_link_libraries(aesim_engineering PUBLIC ws2_32)
endif()
aesim_configure_target(aesim_engineering)


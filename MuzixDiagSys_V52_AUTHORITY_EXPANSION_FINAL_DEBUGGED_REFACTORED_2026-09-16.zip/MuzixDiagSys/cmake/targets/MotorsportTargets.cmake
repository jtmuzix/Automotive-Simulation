add_library(aesim_nascar STATIC
  src/advanced/nascar_competition_platform.cpp
  src/advanced/nascar_ecosystem_platform.cpp
  src/advanced/nascar_frontier_platform.cpp
  src/advanced/nascar_next_generation_platform_a.cpp
  src/advanced/nascar_next_generation_platform_b.cpp
  src/advanced/nascar_next_generation_platform_c.cpp
  src/advanced/nascar_integrated_fidelity_platform_a.cpp
  src/advanced/nascar_integrated_fidelity_platform_b.cpp
  src/advanced/nascar_integrated_fidelity_platform_c.cpp
  src/advanced/nascar_integrated_fidelity_platform_d.cpp
  src/advanced/nascar_integrated_fidelity_platform_e.cpp
  src/advanced/nascar_engineering_assurance_platform_a.cpp
  src/advanced/nascar_engineering_assurance_platform_b.cpp
  src/advanced/nascar_engineering_assurance_platform_c.cpp
  src/advanced/nascar_engineering_assurance_platform_d.cpp
  src/advanced/nascar_engineering_assurance_platform_e.cpp
)
target_include_directories(aesim_nascar PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_nascar PUBLIC aesim_professional aesim_core
  OpenSSL::Crypto Threads::Threads)
aesim_configure_target(aesim_nascar)

add_library(aesim_indycar STATIC
  src/advanced/indycar_platform_a.cpp
  src/advanced/indycar_platform_b.cpp
  src/advanced/indycar_operations_platform_a.cpp
  src/advanced/indycar_operations_platform_b.cpp
  src/advanced/indycar_future_competition_platform_a.cpp
  src/advanced/indycar_future_competition_platform_b.cpp
  src/advanced/indycar_frontier_expansion_platform_a.cpp
  src/advanced/indycar_frontier_expansion_platform_b.cpp
  src/advanced/indycar_frontier_expansion_platform_c.cpp
  src/advanced/indycar_development_operations_platform_a.cpp
  src/advanced/indycar_development_operations_platform_b.cpp
  src/advanced/indycar_development_operations_platform_c.cpp
  src/advanced/indycar_integrated_fidelity_platform_a.cpp
  src/advanced/indycar_integrated_fidelity_platform_b.cpp
  src/advanced/indycar_integrated_fidelity_platform_c.cpp
  src/advanced/indycar_integrated_fidelity_platform_d.cpp
  src/advanced/indycar_engineering_assurance_platform_a.cpp
  src/advanced/indycar_engineering_assurance_platform_b.cpp
  src/advanced/indycar_engineering_assurance_platform_c.cpp
  src/advanced/indycar_engineering_assurance_platform_d.cpp
  src/advanced/indycar_engineering_assurance_platform_e.cpp
  src/advanced/indycar_engineering_assurance_platform_f.cpp
)
target_include_directories(aesim_indycar PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_indycar PUBLIC aesim_professional aesim_core
  OpenSSL::Crypto Threads::Threads)
aesim_configure_target(aesim_indycar)

add_library(aesim_formula_one_industrial STATIC
  src/advanced/formula_one_industrial_ecosystem_platform_a.cpp
  src/advanced/formula_one_industrial_ecosystem_platform_b.cpp
  src/advanced/formula_one_industrial_ecosystem_platform_c.cpp
)
target_include_directories(aesim_formula_one_industrial PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_formula_one_industrial PUBLIC aesim_professional aesim_core
  OpenSSL::Crypto Threads::Threads)
aesim_configure_target(aesim_formula_one_industrial)

add_library(aesim_formula_one STATIC
  src/advanced/formula_one_platform.cpp
  src/advanced/formula_one_fidelity_platform.cpp
  src/advanced/formula_one_multiphysics_platform_a.cpp
  src/advanced/formula_one_multiphysics_platform_b.cpp
  src/advanced/formula_one_multiphysics_platform_c.cpp
  src/advanced/formula_one_realism_platform_a.cpp
  src/advanced/formula_one_realism_platform_b.cpp
  src/advanced/formula_one_realism_platform_c.cpp
  src/advanced/formula_one_integrated_operations_platform_a.cpp
  src/advanced/formula_one_integrated_operations_platform_b.cpp
  src/advanced/formula_one_integrated_operations_platform_c.cpp
  src/advanced/formula_one_race_engineering.cpp
  src/advanced/formula_one_performance_laboratory.cpp
  src/advanced/formula_one_team_competition.cpp
  src/advanced/formula_one_design_qualification.cpp
  src/advanced/formula_one_frontier_laboratory_a.cpp
  src/advanced/formula_one_frontier_laboratory_b.cpp
  src/advanced/formula_one_physical_operations_laboratory_a.cpp
  src/advanced/formula_one_physical_operations_laboratory_b.cpp
  src/advanced/formula_one_championship_operations.cpp
  src/advanced/formula_one_regulatory_competition_platform_a.cpp
  src/advanced/formula_one_regulatory_competition_platform_b.cpp
  src/advanced/formula_one_regulatory_competition_platform_c.cpp
  src/advanced/formula_one_regulatory_competition_platform_d.cpp
)
target_include_directories(aesim_formula_one PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_link_libraries(aesim_formula_one PUBLIC aesim_formula_one_industrial aesim_industrial aesim_professional aesim_core
  ${AESIM_SQLITE_TARGET} OpenSSL::Crypto Threads::Threads ${CMAKE_DL_LIBS})
aesim_configure_target(aesim_formula_one)


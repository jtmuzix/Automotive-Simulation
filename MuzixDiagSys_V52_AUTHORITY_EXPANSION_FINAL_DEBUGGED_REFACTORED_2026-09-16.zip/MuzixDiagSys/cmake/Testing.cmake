if(BUILD_TESTING)
  # Record which CTest entries execute compiled targets.  CTest itself is a
  # test runner rather than a build tool, so these entries require the
  # runtime-artifact setup fixture registered at the end of this file.  Pure
  # source/documentation regressions remain immediately runnable and do not
  # trigger the large compiled-target closure.
  function(add_test)
    _add_test(${ARGV})
    if(ARGC LESS 2)
      return()
    endif()
    if(NOT "${ARGV0}" STREQUAL "NAME")
      return()
    endif()

    set(AESIM_TEST_REQUIRES_COMPILED_ARTIFACT FALSE)
    foreach(AESIM_TEST_ARGUMENT IN LISTS ARGV)
      string(FIND "${AESIM_TEST_ARGUMENT}" "$<TARGET_FILE:"
        AESIM_TARGET_FILE_EXPRESSION_POSITION)
      if(NOT AESIM_TARGET_FILE_EXPRESSION_POSITION EQUAL -1
          OR TARGET "${AESIM_TEST_ARGUMENT}")
        set(AESIM_TEST_REQUIRES_COMPILED_ARTIFACT TRUE)
        break()
      endif()
    endforeach()

    if(AESIM_TEST_REQUIRES_COMPILED_ARTIFACT)
      set_property(GLOBAL APPEND PROPERTY
        AESIM_COMPILED_ARTIFACT_TESTS "${ARGV1}")
    endif()
  endfunction()

  if(NOT Python3_Interpreter_FOUND)
    find_package(Python3 COMPONENTS Interpreter REQUIRED)
  endif()
  find_program(AESIM_BASH_EXECUTABLE NAMES bash)
  if(NOT AESIM_BASH_EXECUTABLE)
    message(FATAL_ERROR "BUILD_TESTING requires a Bash interpreter")
  endif()

  function(muzixdiagsys_add_cpp_test target source library test_name)
    cmake_parse_arguments(TEST "" "" "ARGS;DEFINITIONS;DEPENDENCIES" ${ARGN})
    add_executable(${target} ${source})
    target_include_directories(${target} PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)
    target_link_libraries(${target} PRIVATE ${library})
    if(TEST_DEFINITIONS)
      target_compile_definitions(${target} PRIVATE ${TEST_DEFINITIONS})
    endif()
    if(TEST_DEPENDENCIES)
      add_dependencies(${target} ${TEST_DEPENDENCIES})
    endif()
    aesim_configure_target(${target})
    add_test(NAME ${test_name} COMMAND ${target} ${TEST_ARGS})
  endfunction()

  muzixdiagsys_add_cpp_test(regression_tests tests/regression_tests.cpp aesim_core
    quantity_and_calibration_units)
  muzixdiagsys_add_cpp_test(generalized_infrastructure_g1_tests tests/generalized_infrastructure_g1_tests.cpp aesim_advanced
    generalized_infrastructure_g1_unit_tests)
  muzixdiagsys_add_cpp_test(engineering_ui_platform_tests tests/engineering_ui_platform_tests.cpp aesim_console_support
    engineering_ui_platform_unit_tests)
  muzixdiagsys_add_cpp_test(terminal_workstation_platform_tests tests/terminal_workstation_platform_tests.cpp aesim_console_support
    terminal_workstation_platform_unit_tests)
  muzixdiagsys_add_cpp_test(tui_rendering_foundation_tests tests/tui_rendering_foundation_tests.cpp aesim_console_support
    tui_rendering_foundation_unit_tests)
  muzixdiagsys_add_cpp_test(tui_professional_presentation_tests tests/tui_professional_presentation_tests.cpp aesim_console_support
    tui_professional_presentation_unit_tests)
  muzixdiagsys_add_cpp_test(tui_engineering_visualization_tests tests/tui_engineering_visualization_tests.cpp aesim_console_support
    tui_engineering_visualization_unit_tests)
  muzixdiagsys_add_cpp_test(tui_ide_interaction_tests tests/tui_ide_interaction_tests.cpp aesim_console_support
    tui_ide_interaction_unit_tests)
  muzixdiagsys_add_cpp_test(tui_resilience_v31_tests tests/tui_resilience_v31_tests.cpp aesim_console_support
    tui_resilience_v31_unit_tests)
  muzixdiagsys_add_cpp_test(tui_self_diagnostics_v32_tests tests/tui_self_diagnostics_v32_tests.cpp "aesim_console_support;aesim_professional"
    tui_self_diagnostics_v32_unit_tests
    ARGS "$<TARGET_FILE:aesim_sample_native_plugin_v2>"
    DEPENDENCIES aesim_sample_native_plugin_v2)
  muzixdiagsys_add_cpp_test(professional_engineering_desktop_v12_tests tests/professional_engineering_desktop_v12_tests.cpp aesim_console_support
    professional_engineering_desktop_v12_unit_tests)
  muzixdiagsys_add_cpp_test(professional_engineering_operations_v13_tests tests/professional_engineering_operations_v13_tests.cpp aesim_console_support
    professional_engineering_operations_v13_unit_tests)
  add_test(NAME professional_engineering_operations_v13_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_engineering_operations_v13_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME engineering_ui_platform_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/engineering_ui_platform_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME tui_intelligence_v25_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/tui_intelligence_v25_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME terminal_workstation_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/terminal_workstation_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME tui_resilience_v31_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/tui_resilience_v31_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME tui_self_diagnostics_v32_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/tui_self_diagnostics_v32_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME generalized_engineering_operations_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/generalized_engineering_operations_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME native_qualification_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/native_qualification_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME motorsport_v35_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/motorsport_v35_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME professional_authority_v36_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_authority_v36_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME ecu_diagnostics_socketcan_v37_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ecu_diagnostics_socketcan_v37_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME professional_ui_workbenches_cli_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_ui_workbenches_cli_regression.py $<TARGET_FILE:muzixdiagsys>)
  set_tests_properties(professional_ui_workbenches_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 120)
  add_test(NAME unified_engineering_ui_cli_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/unified_engineering_ui_cli_regression.py $<TARGET_FILE:muzixdiagsys>)
  set_tests_properties(unified_engineering_ui_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 150)
  add_test(NAME ui_customization_cli_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_customization_cli_regression.py $<TARGET_FILE:muzixdiagsys>)
  set_tests_properties(ui_customization_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 150)
  muzixdiagsys_add_cpp_test(numerical_rigor_tests tests/numerical_rigor_tests.cpp aesim_core
    global_numerical_rigor_unit_tests)
  muzixdiagsys_add_cpp_test(mathematical_assurance_tests tests/mathematical_assurance_tests.cpp aesim_core
    global_mathematical_assurance_unit_tests)
  muzixdiagsys_add_cpp_test(industrial_core_tests tests/industrial_core_tests.cpp aesim_industrial
    industrial_core_unit_tests
    DEFINITIONS AESIM_FMI3_BINARY_PATH="$<TARGET_FILE:aesim_fmi3_model>"
    DEPENDENCIES aesim_fmi3_model)
  muzixdiagsys_add_cpp_test(diagnostic_authority_tests tests/diagnostic_authority_tests.cpp aesim_diagnostics
    diagnostic_authority_unit_tests)
  muzixdiagsys_add_cpp_test(obd_responder_lifecycle_tests tests/obd_responder_lifecycle_tests.cpp aesim_diagnostics
    obd_responder_lifecycle_unit_tests)
  muzixdiagsys_add_cpp_test(ecm_obd_platform_tests tests/ecm_obd_platform_tests.cpp aesim_diagnostics
    ecm_obd_platform_unit_tests)
  muzixdiagsys_add_cpp_test(project_workflow_causal_tests tests/project_workflow_causal_tests.cpp aesim_diagnostics
    project_workflow_causal_unit_tests)
  muzixdiagsys_add_cpp_test(network_fault_lab_tests tests/network_fault_lab_tests.cpp aesim_diagnostics
    network_fault_lab_unit_tests)
  muzixdiagsys_add_cpp_test(terminal_text_tests tests/terminal_text_tests.cpp aesim_console_support
    terminal_text_unit_tests)
  muzixdiagsys_add_cpp_test(terminal_input_tests tests/terminal_input_tests.cpp aesim_console_support
    terminal_input_unit_tests)
  add_test(NAME ui_lock_order_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_lock_order_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  muzixdiagsys_add_cpp_test(ui_experience_tests tests/ui_experience_tests.cpp aesim_console_support
    ui_experience_unit_tests)
  muzixdiagsys_add_cpp_test(engineering_instrumentation_tests tests/engineering_instrumentation_tests.cpp aesim_console_support
    engineering_instrumentation_unit_tests)
  muzixdiagsys_add_cpp_test(advanced_debugging_verification_tests tests/advanced_debugging_verification_tests.cpp aesim_console_support
    advanced_debugging_verification_unit_tests)
  muzixdiagsys_add_cpp_test(advanced_analysis_operations_tests tests/advanced_analysis_operations_tests.cpp aesim_console_support
    advanced_analysis_operations_unit_tests)
  muzixdiagsys_add_cpp_test(advanced_assurance_debugging_v23_tests tests/advanced_assurance_debugging_v23_tests.cpp aesim_console_support
    advanced_assurance_debugging_v23_unit_tests)
  muzixdiagsys_add_cpp_test(runtime_intelligence_v24_tests tests/runtime_intelligence_v24_tests.cpp aesim_console_support
    runtime_intelligence_v24_unit_tests)
  muzixdiagsys_add_cpp_test(tui_intelligence_v25_tests tests/tui_intelligence_v25_tests.cpp aesim_console_support
    tui_intelligence_v25_unit_tests)
  muzixdiagsys_add_cpp_test(global_ui_architecture_tests tests/global_ui_architecture_tests.cpp aesim_console_support
    global_ui_architecture_unit_tests)
  muzixdiagsys_add_cpp_test(ui_customization_platform_tests tests/ui_customization_platform_tests.cpp aesim_console_support
    ui_customization_platform_unit_tests)
  muzixdiagsys_add_cpp_test(frontier_professional_integration_tests tests/frontier_professional_integration_tests.cpp aesim_advanced
    frontier_professional_integration_unit_tests)

  foreach(test_spec IN ITEMS
      "vehicle_platform_tests|vehicle_platform_unit_tests"
      "advanced_vehicle_systems_tests|advanced_vehicle_systems_unit_tests"
      "high_fidelity_vehicle_tests|high_fidelity_vehicle_unit_tests"
      "vehicle_depth_tests|vehicle_depth_unit_tests"
      "accuracy_depth_complete_tests|accuracy_depth_complete_unit_tests"
      "simulation_experience_tests|simulation_experience_unit_tests"
      "can_obd_synthesis_tests|can_obd_synthesis_unit_tests"
      "ecosystem_tests|ecosystem_unit_tests"
      "lifecycle_systems_tests|lifecycle_systems_unit_tests"
      "perception_realism_systems_tests|perception_realism_systems_unit_tests"
      "advanced_electrified_vehicle_tests|advanced_electrified_vehicle_unit_tests"
      "assurance_core_tests|assurance_core_unit_tests")
    string(REPLACE "|" ";" test_fields "${test_spec}")
    list(GET test_fields 0 test_target)
    list(GET test_fields 1 test_name)
    muzixdiagsys_add_cpp_test(${test_target} tests/${test_target}.cpp aesim_industrial ${test_name})
  endforeach()

  muzixdiagsys_add_cpp_test(transmission_authority_tests tests/transmission_authority_tests.cpp aesim_industrial
    transmission_authority_phases_a_d_unit_tests)

  muzixdiagsys_add_cpp_test(assurance_resilience_tests tests/assurance_resilience_tests.cpp aesim_industrial
    assurance_resilience_reproducibility_unit_tests)

  muzixdiagsys_add_cpp_test(automotive_lab_tests tests/automotive_lab_tests.cpp aesim_industrial
    automotive_lab_unit_tests ARGS ${CMAKE_CURRENT_SOURCE_DIR})
  muzixdiagsys_add_cpp_test(electrification_platform_tests tests/electrification_platform_tests.cpp aesim_industrial
    electrification_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(automotive_standards_conformance_platform_tests tests/automotive_standards_conformance_platform_tests.cpp aesim_advanced
    automotive_standards_conformance_platform_unit_tests)
  muzixdiagsys_add_cpp_test(emerging_mobility_platform_tests tests/emerging_mobility_platform_tests.cpp aesim_advanced
    emerging_mobility_platform_unit_tests)
  muzixdiagsys_add_cpp_test(formula_one_championship_operations_tests tests/formula_one_championship_operations_tests.cpp aesim_formula_one
    formula_one_championship_operations_unit_tests)
  muzixdiagsys_add_cpp_test(nascar_competition_platform_tests tests/nascar_competition_platform_tests.cpp aesim_nascar
    nascar_competition_platform_unit_tests)
  muzixdiagsys_add_cpp_test(nascar_ecosystem_platform_tests tests/nascar_ecosystem_platform_tests.cpp aesim_nascar
    nascar_ecosystem_platform_unit_tests)
  muzixdiagsys_add_cpp_test(nascar_frontier_platform_tests tests/nascar_frontier_platform_tests.cpp aesim_nascar
    nascar_frontier_platform_unit_tests)
  muzixdiagsys_add_cpp_test(nascar_next_generation_platform_tests tests/nascar_next_generation_platform_tests.cpp aesim_nascar
    nascar_next_generation_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(nascar_integrated_fidelity_platform_tests tests/nascar_integrated_fidelity_platform_tests.cpp aesim_nascar
    nascar_integrated_fidelity_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(nascar_engineering_assurance_platform_tests tests/nascar_engineering_assurance_platform_tests.cpp aesim_nascar
    nascar_engineering_assurance_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  add_library(aesim_fake_precice SHARED tests/fake_precice_c_api.cpp)
  set_target_properties(aesim_fake_precice PROPERTIES OUTPUT_NAME aesim_fake_precice)
  aesim_configure_target(aesim_fake_precice)

  muzixdiagsys_add_cpp_test(causal_simulation_tests tests/causal_simulation_tests.cpp aesim_industrial
    causal_simulation_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(advanced_safety_platform_tests tests/advanced_safety_platform_tests.cpp aesim_industrial
    advanced_safety_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(specification_discovery_platform_tests tests/specification_discovery_platform_tests.cpp aesim_industrial
    specification_discovery_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(standards_deployment_platform_tests tests/standards_deployment_platform_tests.cpp aesim_industrial
    standards_deployment_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(advanced_platform_tests tests/advanced_platform_tests.cpp aesim_advanced
    advanced_cyber_physical_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(research_authority_platform_tests tests/research_authority_platform_tests.cpp aesim_advanced
    research_authority_r1_r7_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(frontier_runtime_sensing_platform_tests tests/frontier_runtime_sensing_platform_tests.cpp aesim_advanced
    frontier_runtime_sensing_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(runtime_scaling_platform_tests tests/runtime_scaling_platform_tests.cpp aesim_advanced
    runtime_scaling_platform_unit_tests)

  muzixdiagsys_add_cpp_test(workflow_flexibility_platform_tests tests/workflow_flexibility_platform_tests.cpp aesim_console_support
    workflow_flexibility_platform_unit_tests)

  muzixdiagsys_add_cpp_test(workflow_intelligence_platform_tests tests/workflow_intelligence_platform_tests.cpp aesim_console_support
    workflow_intelligence_platform_unit_tests)

  muzixdiagsys_add_cpp_test(tui_productivity_platform_tests tests/tui_productivity_platform_tests.cpp aesim_console_support
    tui_productivity_platform_unit_tests)

  muzixdiagsys_add_cpp_test(frontier_expansion_platform_tests tests/frontier_expansion_platform_tests.cpp aesim_advanced
    frontier_expansion_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(frontier_systems_platform_tests tests/frontier_systems_platform_tests.cpp aesim_advanced
    frontier_systems_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(frontier_integration_platform_tests tests/frontier_integration_platform_tests.cpp aesim_advanced
    frontier_integration_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(frontier_next_platform_tests tests/frontier_next_platform_tests.cpp aesim_advanced
    frontier_next_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(connected_vehicle_integration_platform_tests tests/connected_vehicle_integration_platform_tests.cpp aesim_advanced
    connected_vehicle_integration_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(physical_diagnostics_intelligence_platform_tests tests/physical_diagnostics_intelligence_platform_tests.cpp aesim_advanced
    physical_diagnostics_intelligence_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(engineering_validation_platform_tests tests/engineering_validation_platform_tests.cpp aesim_advanced
    engineering_validation_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(engineering_intelligence_platform_tests tests/engineering_intelligence_platform_tests.cpp aesim_advanced
    engineering_intelligence_platform_unit_tests)

  muzixdiagsys_add_cpp_test(engineering_intelligence_expansion_tests tests/engineering_intelligence_expansion_tests.cpp aesim_advanced
    engineering_intelligence_expansion_unit_tests)

  muzixdiagsys_add_cpp_test(next_generation_platform_tests tests/next_generation_platform_tests.cpp aesim_advanced
    next_generation_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(next_generation_labs_tests tests/next_generation_labs_tests.cpp aesim_advanced
    next_generation_labs_unit_tests)

  muzixdiagsys_add_cpp_test(integrated_frontier_platform_tests tests/integrated_frontier_platform_tests.cpp aesim_advanced
    integrated_frontier_platform_unit_tests)

  muzixdiagsys_add_cpp_test(must_have_platform_tests tests/must_have_platform_tests.cpp aesim_advanced
    must_have_platform_unit_tests)

  muzixdiagsys_add_cpp_test(deep_engineering_platform_tests tests/deep_engineering_platform_tests.cpp aesim_advanced
    deep_engineering_platform_unit_tests)

  muzixdiagsys_add_cpp_test(generalized_simulation_platform_tests tests/generalized_simulation_platform_tests.cpp aesim_advanced
    generalized_simulation_platform_unit_tests)

  muzixdiagsys_add_cpp_test(scientific_fidelity_platform_tests tests/scientific_fidelity_platform_tests.cpp aesim_advanced
    scientific_fidelity_platform_unit_tests)

  muzixdiagsys_add_cpp_test(continuum_reality_platform_tests tests/continuum_reality_platform_tests.cpp aesim_advanced
    continuum_reality_platform_unit_tests)

  muzixdiagsys_add_cpp_test(frontier_vehicle_ecosystem_platform_tests tests/frontier_vehicle_ecosystem_platform_tests.cpp aesim_advanced
    frontier_vehicle_ecosystem_platform_unit_tests)

  muzixdiagsys_add_cpp_test(electronics_power_distribution_platform_tests tests/electronics_power_distribution_platform_tests.cpp aesim_advanced
    electronics_power_distribution_platform_unit_tests)

  muzixdiagsys_add_cpp_test(electronics_circuit_conversion_platform_tests tests/electronics_circuit_conversion_platform_tests.cpp aesim_advanced
    electronics_circuit_conversion_platform_unit_tests)

  muzixdiagsys_add_cpp_test(embedded_electronics_assurance_platform_tests tests/embedded_electronics_assurance_platform_tests.cpp aesim_advanced
    embedded_electronics_assurance_platform_unit_tests)

  muzixdiagsys_add_cpp_test(automotive_electronics_compute_authority_tests tests/automotive_electronics_compute_authority_tests.cpp aesim_electronics_compute_v38
    automotive_electronics_compute_phases_a_e_unit_tests)

  muzixdiagsys_add_cpp_test(nhra_championship_strategy_platform_tests tests/nhra_championship_strategy_platform_tests.cpp aesim_advanced
    nhra_championship_strategy_platform_unit_tests)

  muzixdiagsys_add_cpp_test(nhra_race_engineering_platform_tests tests/nhra_race_engineering_platform_tests.cpp aesim_advanced
    nhra_race_engineering_platform_unit_tests)

  muzixdiagsys_add_cpp_test(nhra_deep_authority_platform_tests tests/nhra_deep_authority_platform_tests.cpp aesim_advanced
    nhra_deep_authority_phases_a_j_unit_tests)

  muzixdiagsys_add_cpp_test(motogp_authority_platform_tests tests/motogp_authority_platform_tests.cpp aesim_advanced
    motogp_authority_phases_a_j_unit_tests)

  muzixdiagsys_add_cpp_test(fundamental_physics_platform_tests tests/fundamental_physics_platform_tests.cpp aesim_fundamental_physics
    fundamental_physics_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_platform_tests tests/formula_one_platform_tests.cpp aesim_formula_one
    formula_one_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_fidelity_platform_tests tests/formula_one_fidelity_platform_tests.cpp aesim_formula_one
    formula_one_fidelity_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_multiphysics_platform_tests tests/formula_one_multiphysics_platform_tests.cpp aesim_formula_one
    formula_one_multiphysics_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_realism_platform_tests tests/formula_one_realism_platform_tests.cpp aesim_formula_one
    formula_one_realism_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_integrated_operations_platform_tests tests/formula_one_integrated_operations_platform_tests.cpp aesim_formula_one
    formula_one_integrated_operations_platform_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_race_engineering_tests tests/formula_one_race_engineering_tests.cpp aesim_formula_one
    formula_one_race_engineering_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_performance_laboratory_tests tests/formula_one_performance_laboratory_tests.cpp aesim_formula_one
    formula_one_performance_laboratory_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_team_competition_tests tests/formula_one_team_competition_tests.cpp aesim_formula_one
    formula_one_team_competition_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_design_qualification_tests tests/formula_one_design_qualification_tests.cpp aesim_formula_one
    formula_one_design_qualification_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_frontier_laboratory_tests tests/formula_one_frontier_laboratory_tests.cpp aesim_formula_one
    formula_one_frontier_laboratory_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_physical_operations_laboratory_tests tests/formula_one_physical_operations_laboratory_tests.cpp aesim_formula_one
    formula_one_physical_operations_laboratory_unit_tests)

  muzixdiagsys_add_cpp_test(formula_one_regulatory_competition_platform_tests tests/formula_one_regulatory_competition_platform_tests.cpp aesim_formula_one
    formula_one_regulatory_competition_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(formula_one_industrial_ecosystem_platform_tests tests/formula_one_industrial_ecosystem_platform_tests.cpp aesim_formula_one_industrial
    formula_one_industrial_ecosystem_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(indycar_platform_tests tests/indycar_platform_tests.cpp aesim_indycar
    indycar_platform_unit_tests)

  muzixdiagsys_add_cpp_test(indycar_operations_platform_tests tests/indycar_operations_platform_tests.cpp aesim_indycar
    indycar_operations_platform_unit_tests)

  muzixdiagsys_add_cpp_test(indycar_future_competition_platform_tests tests/indycar_future_competition_platform_tests.cpp aesim_indycar
    indycar_future_competition_platform_unit_tests)

  muzixdiagsys_add_cpp_test(indycar_frontier_expansion_platform_tests tests/indycar_frontier_expansion_platform_tests.cpp aesim_indycar
    indycar_frontier_expansion_platform_unit_tests)

  muzixdiagsys_add_cpp_test(indycar_development_operations_platform_tests tests/indycar_development_operations_platform_tests.cpp aesim_indycar
    indycar_development_operations_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(indycar_integrated_fidelity_platform_tests tests/indycar_integrated_fidelity_platform_tests.cpp aesim_indycar
    indycar_integrated_fidelity_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(indycar_engineering_assurance_platform_tests tests/indycar_engineering_assurance_platform_tests.cpp aesim_indycar
    indycar_engineering_assurance_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")

  muzixdiagsys_add_cpp_test(qualification_science_platform_tests tests/qualification_science_platform_tests.cpp aesim_advanced
    qualification_science_platform_unit_tests)

  muzixdiagsys_add_cpp_test(materials_energy_multiphysics_platform_tests tests/materials_energy_multiphysics_platform_tests.cpp aesim_advanced
    materials_energy_multiphysics_platform_unit_tests)

  muzixdiagsys_add_cpp_test(silicon_human_infrastructure_platform_tests tests/silicon_human_infrastructure_platform_tests.cpp aesim_advanced
    silicon_human_infrastructure_platform_unit_tests)

  muzixdiagsys_add_cpp_test(atomistic_remote_operations_platform_tests tests/atomistic_remote_operations_platform_tests.cpp aesim_advanced
    atomistic_remote_operations_platform_unit_tests)

  muzixdiagsys_add_cpp_test(architecture_intelligence_sustainability_platform_tests tests/architecture_intelligence_sustainability_platform_tests.cpp aesim_advanced
    architecture_intelligence_sustainability_platform_unit_tests)

  muzixdiagsys_add_cpp_test(next_generation_autonomy_platform_tests tests/next_generation_autonomy_platform_tests.cpp aesim_advanced
    next_generation_autonomy_platform_unit_tests)

  muzixdiagsys_add_cpp_test(frontier_compute_energy_risk_platform_tests tests/frontier_compute_energy_risk_platform_tests.cpp aesim_advanced
    frontier_compute_energy_risk_platform_unit_tests)
  muzixdiagsys_add_cpp_test(certified_deployment_infrastructure_platform_tests tests/certified_deployment_infrastructure_platform_tests.cpp aesim_advanced
    certified_deployment_infrastructure_platform_unit_tests)
  muzixdiagsys_add_cpp_test(assured_engineering_operations_platform_tests tests/assured_engineering_operations_platform_tests.cpp aesim_advanced
    assured_engineering_operations_platform_unit_tests)
  muzixdiagsys_add_cpp_test(generalized_engineering_operations_platform_tests tests/generalized_engineering_operations_platform_tests.cpp aesim_generalized_engineering_operations
    generalized_engineering_operations_platform_unit_tests)
  muzixdiagsys_add_cpp_test(native_qualification_platform_tests tests/native_qualification_platform_tests.cpp aesim_native_qualification
    native_qualification_platform_unit_tests
    ARGS ${CMAKE_CURRENT_BINARY_DIR}/native_qualification_platform_unit_tests_data)
  muzixdiagsys_add_cpp_test(motorsport_v35_platform_tests tests/motorsport_v35_platform_tests.cpp aesim_motorsport_v35
    motorsport_v35_platform_unit_tests)
  add_library(aesim_fake_professional_authority_backends SHARED tests/fake_professional_authority_backends.cpp)
  aesim_configure_target(aesim_fake_professional_authority_backends)
  muzixdiagsys_add_cpp_test(professional_authority_platform_tests tests/professional_authority_platform_tests.cpp aesim_professional_authority_v36
    professional_authority_platform_unit_tests
    ARGS "$<TARGET_FILE:aesim_fake_professional_authority_backends>"
    DEPENDENCIES aesim_fake_professional_authority_backends)
  muzixdiagsys_add_cpp_test(suspension_research_platform_tests tests/suspension_research_platform_tests.cpp aesim_professional_authority_v36
    suspension_research_platform_unit_tests)
  muzixdiagsys_add_cpp_test(performance_reality_platform_tests tests/performance_reality_platform_tests.cpp aesim_professional_authority_v36
    performance_reality_platform_unit_tests)
  muzixdiagsys_add_cpp_test(performance_reality_v49_tests tests/performance_reality_v49_tests.cpp aesim_professional_authority_v36
    performance_reality_v49_unit_tests)
  # Both performance authorities are intentionally heavyweight, whole-process
  # qualification workloads.  Running them concurrently with each other (or
  # with other RUN_SERIAL simulator sessions) creates host-load dependent
  # watchdog failures and previously exposed shared temporary-artifact races.
  # Keep their numerical assertions unchanged and make scheduling deterministic.
  set_tests_properties(
    performance_reality_platform_unit_tests
    performance_reality_v49_unit_tests
    PROPERTIES RUN_SERIAL TRUE TIMEOUT 1200)
  muzixdiagsys_add_cpp_test(vehicle_reality_r1_platform_tests tests/vehicle_reality_r1_platform_tests.cpp aesim_professional_authority_v36
    vehicle_reality_r1_platform_unit_tests)
  muzixdiagsys_add_cpp_test(v50_reality_authority_tests tests/v50_reality_authority_tests.cpp aesim_advanced
    v50_reality_authority_unit_tests)
  muzixdiagsys_add_cpp_test(v51_scientific_reality_tests tests/v51_scientific_reality_tests.cpp aesim_advanced
    v51_scientific_reality_unit_tests
    ARGS ${CMAKE_CURRENT_BINARY_DIR}/v51_scientific_reality_unit_tests_data)
  muzixdiagsys_add_cpp_test(v52_authority_expansion_tests tests/v52_authority_expansion_tests.cpp aesim_advanced
    v52_authority_expansion_unit_tests
    ARGS ${CMAKE_CURRENT_BINARY_DIR}/v52_authority_expansion_unit_tests_data)
  add_test(NAME v50_reality_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/v50_reality_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  if(TARGET muzixdiagsys_v50_reality)
    add_test(NAME v50_python_api_unit_tests
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/v50_python_api_tests.py
        ${CMAKE_CURRENT_SOURCE_DIR} $<TARGET_FILE:muzixdiagsys_v50_reality>)
    set_tests_properties(v50_python_api_unit_tests PROPERTIES TIMEOUT 60)
  endif()
  add_test(NAME v51_scientific_reality_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/v51_scientific_reality_source_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
  if(TARGET muzixdiagsys_v51_reality)
    add_test(NAME v51_release_artifact_certification
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/v51_release_artifact_certification.py
        ${CMAKE_CURRENT_SOURCE_DIR} $<TARGET_FILE:muzixdiagsys_v51_reality>)
    set_tests_properties(v51_release_artifact_certification PROPERTIES TIMEOUT 300)
  endif()
  if(TARGET muzixdiagsys_v51_reality)
    add_test(NAME v51_python_api_unit_tests
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/v51_python_api_tests.py
        ${CMAKE_CURRENT_SOURCE_DIR} $<TARGET_FILE:muzixdiagsys_v51_reality>)
    set_tests_properties(v51_python_api_unit_tests PROPERTIES TIMEOUT 180)
  endif()
  muzixdiagsys_add_cpp_test(ecu_diagnostics_socketcan_v37_tests tests/ecu_diagnostics_socketcan_v37_tests.cpp aesim_ecu_diagnostics_socketcan_v37
    ecu_diagnostics_socketcan_v37_unit_tests)
  muzixdiagsys_add_cpp_test(operational_digital_infrastructure_platform_tests tests/operational_digital_infrastructure_platform_tests.cpp aesim_advanced
    operational_digital_infrastructure_platform_unit_tests)

  muzixdiagsys_add_cpp_test(digital_thread_lifecycle_tests tests/digital_thread_lifecycle_tests.cpp aesim_advanced
    digital_thread_lifecycle_unit_tests)

  muzixdiagsys_add_cpp_test(continuous_engineering_platform_tests tests/continuous_engineering_platform_tests.cpp aesim_advanced
    continuous_engineering_platform_unit_tests)

  muzixdiagsys_add_cpp_test(qualification_studio_platform_tests tests/qualification_studio_platform_tests.cpp aesim_advanced
    qualification_studio_platform_unit_tests)

  if(TARGET muzixdiagsys_advanced_safety)
    add_test(NAME advanced_safety_cli_self_test COMMAND muzixdiagsys_advanced_safety self-test)
    set_tests_properties(advanced_safety_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_advanced_platform)
    add_test(NAME advanced_platform_cli_self_test
      COMMAND muzixdiagsys_advanced_platform self-test
              ${CMAKE_CURRENT_BINARY_DIR}/advanced_platform_cli_self_test)
    set_tests_properties(advanced_platform_cli_self_test PROPERTIES TIMEOUT 120)
  endif()

  if(TARGET muzixdiagsys_generalized_ops)
    add_test(NAME generalized_engineering_operations_cli_self_test
      COMMAND muzixdiagsys_generalized_ops self-test
              ${CMAKE_CURRENT_BINARY_DIR}/generalized_engineering_operations_cli_self_test)
    set_tests_properties(generalized_engineering_operations_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_native_qualification)
    add_test(NAME native_qualification_cli_self_test
      COMMAND muzixdiagsys_native_qualification self-test
              ${CMAKE_CURRENT_BINARY_DIR}/native_qualification_cli_self_test)
    set_tests_properties(native_qualification_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_motorsport_v35)
    add_test(NAME motorsport_v35_cli_self_test
      COMMAND muzixdiagsys_motorsport_v35 self-test)
    set_tests_properties(motorsport_v35_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_professional_authority_v36)
    add_test(NAME professional_authority_v36_cli_self_test
      COMMAND muzixdiagsys_professional_authority_v36 self-test)
    set_tests_properties(professional_authority_v36_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_ecu_diagnostics_v37)
    add_test(NAME ecu_diagnostics_socketcan_v37_cli_self_test
      COMMAND muzixdiagsys_ecu_diagnostics_v37 self-test)
    set_tests_properties(ecu_diagnostics_socketcan_v37_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(Python3_Interpreter_FOUND)
    add_test(NAME advanced_platform_python_syntax
      COMMAND ${Python3_EXECUTABLE} -m compileall -q
              ${CMAKE_CURRENT_SOURCE_DIR}/python/muzixdiag)
    set_tests_properties(advanced_platform_python_syntax PROPERTIES TIMEOUT 30)

    if(TARGET muzixdiagsys_advanced_platform)
      add_test(NAME generalized_infrastructure_g1_python_runtime
        COMMAND ${Python3_EXECUTABLE}
                ${CMAKE_CURRENT_SOURCE_DIR}/tests/generalized_infrastructure_g1_python_tests.py
                $<TARGET_FILE:muzixdiagsys_advanced_platform>)
      set_tests_properties(generalized_infrastructure_g1_python_runtime PROPERTIES
        TIMEOUT 180
        ENVIRONMENT "PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/python")

      add_test(NAME advanced_platform_python_runtime
        COMMAND ${Python3_EXECUTABLE}
                ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_python_runtime_tests.py
                $<TARGET_FILE:muzixdiagsys_advanced_platform>)
      if(MUZIXDIAGSYS_REQUIRE_OPTIONAL_PYTHON_RUNTIME)
        set(_muzixdiagsys_require_optional_python_runtime 1)
      else()
        set(_muzixdiagsys_require_optional_python_runtime 0)
      endif()
      set_tests_properties(advanced_platform_python_runtime PROPERTIES
        TIMEOUT 120
        ENVIRONMENT
          "PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/python;MUZIXDIAGSYS_REQUIRE_OPTIONAL_PYTHON_RUNTIME=${_muzixdiagsys_require_optional_python_runtime}")
    endif()
  endif()

  if(TARGET muzixdiagsys_specification_discovery)
    add_test(NAME specification_discovery_cli_self_test COMMAND muzixdiagsys_specification_discovery self-test)
    set_tests_properties(specification_discovery_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  if(TARGET muzixdiagsys_standards_deployment)
    add_test(NAME standards_deployment_cli_self_test COMMAND muzixdiagsys_standards_deployment self-test)
    set_tests_properties(standards_deployment_cli_self_test PROPERTIES TIMEOUT 60)
  endif()

  muzixdiagsys_add_cpp_test(research2_platform_tests tests/research2_platform_tests.cpp aesim_industrial
    research2_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_FAKE_PRECICE_PATH="$<TARGET_FILE:aesim_fake_precice>"
    DEPENDENCIES aesim_fake_precice)

  set(AESIM_TEST_RUNTIME_DIR "${CMAKE_CURRENT_BINARY_DIR}/test_runtime")
  file(MAKE_DIRECTORY "${AESIM_TEST_RUNTIME_DIR}")
  file(COPY "${CMAKE_CURRENT_SOURCE_DIR}/tests/fake_qemu.py"
    DESTINATION "${AESIM_TEST_RUNTIME_DIR}"
    FILE_PERMISSIONS OWNER_READ OWNER_WRITE OWNER_EXECUTE GROUP_READ GROUP_EXECUTE WORLD_READ WORLD_EXECUTE)
  muzixdiagsys_add_cpp_test(federation_platform_tests tests/federation_platform_tests.cpp aesim_industrial
    federation_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_FAKE_QEMU_PATH="${AESIM_TEST_RUNTIME_DIR}/fake_qemu.py")
  # This test launches nested mutation/process-control qualifications with
  # deliberately short timeout probes.  Isolate it from CPU-saturating
  # performance simulations so those probes measure process-control behavior,
  # not unrelated host contention.
  set_tests_properties(federation_platform_unit_tests PROPERTIES
    RUN_SERIAL TRUE TIMEOUT 300)

  muzixdiagsys_add_cpp_test(frontier_platform_tests tests/frontier_platform_tests.cpp aesim_industrial
    frontier_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")
  muzixdiagsys_add_cpp_test(authentication_tests tests/authentication_tests.cpp aesim_professional
    authentication_unit_tests)
  muzixdiagsys_add_cpp_test(engineering_platform_tests tests/engineering_platform_tests.cpp aesim_engineering
    engineering_platform_unit_tests
    DEFINITIONS MUZIXDIAGSYS_PROJECT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
                AESIM_FMI3_BINARY_PATH="$<TARGET_FILE:aesim_fmi3_model>"
    DEPENDENCIES aesim_fmi3_model)
  muzixdiagsys_add_cpp_test(validation_lifecycle_tests tests/validation_lifecycle_tests.cpp aesim_engineering
    validation_lifecycle_unit_tests)
  muzixdiagsys_add_cpp_test(engineering_studio_tests tests/engineering_studio_tests.cpp aesim_engineering
    engineering_studio_unit_tests)

  muzixdiagsys_add_cpp_test(professional_core_tests tests/professional_core_tests.cpp aesim_professional
    professional_core_unit_tests
    DEFINITIONS AESIM_FMI3_BINARY_PATH="$<TARGET_FILE:aesim_fmi3_model>"
                AESIM_SAMPLE_SIL_PATH="$<TARGET_FILE:aesim_sample_sil_controller>"
                AESIM_SAMPLE_PLUGIN_V2_PATH="$<TARGET_FILE:aesim_sample_native_plugin_v2>"
    DEPENDENCIES aesim_fmi3_model aesim_sample_sil_controller aesim_sample_native_plugin_v2)
  muzixdiagsys_add_cpp_test(research_core_tests tests/research_core_tests.cpp aesim_core
    research_core_unit_tests)
  add_test(NAME runtime_performance_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/runtime_performance_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME runtime_scaling_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/runtime_scaling_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME workflow_flexibility_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/workflow_flexibility_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME workflow_intelligence_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/workflow_intelligence_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME tui_productivity_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/tui_productivity_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  muzixdiagsys_add_cpp_test(core_time_regression tests/core_time_regression.cpp aesim_core
    core_time_regression)
  muzixdiagsys_add_cpp_test(realism_systems_tests tests/realism_systems_tests.cpp aesim_core
    coupled_realism_unit_tests)
  add_test(NAME cli_regression COMMAND ${AESIM_BASH_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/cli_regression.sh $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME cli_regression_harness_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/cli_regression_harness_source_regression.py)
  add_test(NAME authentication_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/authentication_cli_regression.py $<TARGET_FILE:muzixdiagsys>)
  if(TARGET muzixdiagsys_engineering)
    add_test(NAME engineering_python_api_regression
      COMMAND ${CMAKE_COMMAND} -E env
              PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/python
              ${Python3_EXECUTABLE}
              ${CMAKE_CURRENT_SOURCE_DIR}/tests/python_api_regression.py
              $<TARGET_FILE:muzixdiagsys_engineering>
              ${CMAKE_CURRENT_SOURCE_DIR})
    # This end-to-end API regression intentionally launches many short-lived native
    # engineering commands, a two-worker campaign, and a loopback telemetry server.
    # Account for its internal concurrency and allow headroom on loaded CI/workstations
    # without weakening any API assertion.
    set_tests_properties(engineering_python_api_regression PROPERTIES
      TIMEOUT 300
      PROCESSORS 2)
    add_test(NAME validation_python_api_regression
      COMMAND ${CMAKE_COMMAND} -E env
              PYTHONPATH=${CMAKE_CURRENT_SOURCE_DIR}/python
              ${Python3_EXECUTABLE}
              ${CMAKE_CURRENT_SOURCE_DIR}/tests/validation_python_api_regression.py
              $<TARGET_FILE:muzixdiagsys_engineering>)
    set_tests_properties(validation_python_api_regression PROPERTIES TIMEOUT 180)
  endif()
  add_test(NAME version20_feature_retention_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/version20_feature_retention_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME connected_vehicle_integration_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/connected_vehicle_integration_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME physical_diagnostics_intelligence_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/physical_diagnostics_intelligence_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME engineering_validation_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/engineering_validation_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME source_package_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/source_package_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME v48_performance_budget_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/v48_performance_budget_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME v49_performance_authority_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/v49_performance_authority_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME hip_compile_option_isolation_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/hip_compile_option_isolation_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME build_warning_policy_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/build_warning_policy_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME duplicate_implementation_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/duplicate_implementation_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME consolidation_architecture_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/consolidation_architecture_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME build_transaction_workflow_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/build_transaction_workflow_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME ctest_artifact_fixture_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/ctest_artifact_fixture_regression.py
            ${CMAKE_CURRENT_BINARY_DIR})
  add_test(NAME cmake_optional_tools_configuration_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake_optional_tools_configuration_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  set_tests_properties(cmake_optional_tools_configuration_regression PROPERTIES TIMEOUT 120)
  add_test(NAME indycar_frontier_expansion_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/indycar_frontier_expansion_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME indycar_development_operations_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/indycar_development_operations_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME indycar_integrated_fidelity_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/indycar_integrated_fidelity_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME indycar_engineering_assurance_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/indycar_engineering_assurance_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME nascar_next_generation_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/nascar_next_generation_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME nascar_integrated_fidelity_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/nascar_integrated_fidelity_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME nascar_engineering_assurance_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/nascar_engineering_assurance_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME formula_one_regulatory_competition_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_regulatory_competition_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME formula_one_fidelity_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_fidelity_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME formula_one_multiphysics_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_multiphysics_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME formula_one_realism_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_realism_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME formula_one_integrated_operations_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_integrated_operations_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME generalized_simulation_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/generalized_simulation_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME scientific_fidelity_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/scientific_fidelity_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME continuum_reality_platform_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/continuum_reality_platform_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME fundamental_physics_platform_source_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/fundamental_physics_platform_source_regression.py)


  add_test(NAME formula_one_industrial_ecosystem_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/formula_one_industrial_ecosystem_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME electronics_engineering_assurance_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/electronics_engineering_assurance_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME nhra_championship_strategy_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/nhra_championship_strategy_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME nhra_race_engineering_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/nhra_race_engineering_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME mathematical_assurance_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/mathematical_assurance_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME frontier_runtime_sensing_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_runtime_sensing_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME frontier_expansion_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_expansion_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME frontier_systems_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_systems_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME frontier_integration_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_integration_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME frontier_next_source_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_next_source_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})

  add_test(NAME documentation_consistency_regression
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/documentation_consistency_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  add_test(NAME clean_generated_artifacts_regression
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/clean_generated_artifacts_regression.py
            ${CMAKE_CURRENT_SOURCE_DIR})
  if(UNIX)
    add_test(NAME build_footprint_regression
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/build_footprint_regression.py
              ${CMAKE_CURRENT_BINARY_DIR})
    # This regression validates executables, compatibility launchers, staged resources,
    # and native plugin products.  It is not source-only and must wait for the
    # compiled-artifact fixture during direct CTest runs.
    set_property(GLOBAL APPEND PROPERTY AESIM_COMPILED_ARTIFACT_TESTS
      build_footprint_regression)
  endif()
  if(AESIM_ENABLE_POSITION_INDEPENDENT_CODE
      AND CMAKE_SYSTEM_NAME STREQUAL "Linux"
      AND CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    add_test(NAME pic_pie_configuration_regression
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/pic_pie_configuration_regression.py
        ${CMAKE_CURRENT_BINARY_DIR}/compile_commands.json
        $<TARGET_FILE:muzixdiagsys>)
  endif()
  if(UNIX AND CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    add_test(NAME accelerator_backend_factory_linkage_regression
      COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/accelerator_backend_factory_linkage_regression.py
        ${CMAKE_CXX_COMPILER}
        ${CMAKE_CURRENT_SOURCE_DIR}
        ${CMAKE_CURRENT_BINARY_DIR})
    set_tests_properties(accelerator_backend_factory_linkage_regression PROPERTIES TIMEOUT 120)
  endif()
  if(UNIX)
    add_test(NAME engineering_ui_live_routing_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/engineering_ui_live_routing_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME web_gui_v19_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/web_gui_v19_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME dashboard_arrow_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/dashboard_arrow_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME dashboard_visibility_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/dashboard_visibility_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME dashboard_scroll_anchor_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/dashboard_scroll_anchor_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_features_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_features_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_streamlined_experience_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_streamlined_experience_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_modified_key_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_modified_key_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_beginner_menu_theme_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_beginner_menu_theme_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_no_color_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_no_color_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME tui_ide_interaction_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/tui_ide_interaction_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_preferences_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_preferences_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_professional_workflow_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_professional_workflow_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME completion_popup_scroll_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/completion_popup_scroll_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME industrial_energy_completion_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/industrial_energy_completion_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME all_commands_completion_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/all_commands_completion_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME all_commands_completion_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/all_commands_completion_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME version20_cli_retention_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/version20_cli_retention_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME ui_input_fuzz_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_input_fuzz_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME ui_golden_frames COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/ui_golden_frames.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME lower_pane_visibility_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/lower_pane_visibility_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME help_focus_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/help_focus_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME user_manual_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/user_manual_regression.py ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME branding_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/branding_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(ui_professional_workflow_pty PROPERTIES TIMEOUT 120)
    set_tests_properties(completion_popup_scroll_pty PROPERTIES TIMEOUT 90)
    set_tests_properties(all_commands_completion_pty PROPERTIES TIMEOUT 120)
    set_tests_properties(all_commands_completion_regression PROPERTIES TIMEOUT 300)
    set_tests_properties(version20_cli_retention_regression PROPERTIES TIMEOUT 300)
    set_tests_properties(ui_input_fuzz_pty PROPERTIES TIMEOUT 120)
    set_tests_properties(ui_golden_frames PROPERTIES TIMEOUT 90)
    set_tests_properties(lower_pane_visibility_pty PROPERTIES TIMEOUT 90)
    set_tests_properties(help_focus_pty PROPERTIES TIMEOUT 90)
    set_tests_properties(user_manual_regression branding_regression PROPERTIES TIMEOUT 30)
    add_test(NAME terminal_resize_density_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/terminal_resize_density_pty.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME terminal_resize_anchor_pty COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/terminal_resize_anchor_pty.py $<TARGET_FILE:muzixdiagsys>)
    set(MUZIXDIAGSYS_PTY_TESTS
      engineering_ui_live_routing_pty
      web_gui_v19_pty
      dashboard_arrow_pty
      dashboard_visibility_pty
      dashboard_scroll_anchor_pty
      ui_features_pty
      ui_streamlined_experience_pty
      ui_modified_key_pty
      ui_beginner_menu_theme_pty
      ui_no_color_pty
      tui_ide_interaction_pty
      ui_preferences_pty
      ui_professional_workflow_pty
      completion_popup_scroll_pty
      industrial_energy_completion_pty
      all_commands_completion_pty
      ui_input_fuzz_pty
      ui_golden_frames
      lower_pane_visibility_pty
      help_focus_pty
      terminal_resize_density_pty
      terminal_resize_anchor_pty)
    # Every PTY test owns a foreground terminal session and launches the same
    # interactive executable. Serialize them under parallel CTest to prevent
    # pseudo-terminal contention and make child-process cleanup deterministic.
    set_tests_properties(${MUZIXDIAGSYS_PTY_TESTS} PROPERTIES
      RESOURCE_LOCK muzixdiagsys_pty
      RUN_SERIAL TRUE
      TIMEOUT 180)
    # This test performs a dense sequence of editor operations whose semantic
    # outputs must not be starved by unrelated CPU-heavy regressions.
    set_tests_properties(ui_features_pty PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    # These workflows depend on multiple causally ordered repaint/input cycles.
    # They are deterministic in isolation but can exceed their synchronization
    # windows when CPU-heavy numerical regressions run concurrently. Keep the
    # terminal integration contract deterministic under release qualification.
    set_tests_properties(ui_beginner_menu_theme_pty ui_preferences_pty
      ui_professional_workflow_pty dashboard_scroll_anchor_pty
      PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME drivetrain_accel_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/drivetrain_accel_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(drivetrain_accel_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME driver_control_and_catalog_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/driver_control_and_catalog_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(driver_control_and_catalog_regression PROPERTIES TIMEOUT 90)
    add_test(NAME automatic_wot_shift_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/automatic_wot_shift_regression.py $<TARGET_FILE:muzixdiagsys>)
    # This test runs a complete authenticated simulator session and advances a
    # 20-second coupled WOT pull.  Serialize it so a user-supplied
    # CTEST_PARALLEL_LEVEL cannot turn host contention into a false child-process
    # timeout; the Python watchdog remains finite and independently enforced.
    set_tests_properties(automatic_wot_shift_regression PROPERTIES
      RUN_SERIAL TRUE
      TIMEOUT 120)
    add_test(NAME automatic_high_load_hysteresis_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/automatic_high_load_hysteresis_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(automatic_high_load_hysteresis_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME automatic_throttle_sweep_anti_hunt_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/automatic_throttle_sweep_anti_hunt_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME partial_throttle_realism_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/partial_throttle_realism_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME coupled_realism_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/coupled_realism_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME regulatory_cycle_assets COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/regulatory_cycle_assets.py ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME regulatory_cycle_input_validation_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/regulatory_cycle_input_validation_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME regulatory_cycle_tracking_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/regulatory_cycle_tracking_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(coupled_realism_regression PROPERTIES TIMEOUT 150)
    set_tests_properties(regulatory_cycle_assets PROPERTIES TIMEOUT 30)
    set_tests_properties(regulatory_cycle_input_validation_regression PROPERTIES TIMEOUT 60)
    set_tests_properties(regulatory_cycle_tracking_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 900)
    # This regression launches several complete simulator sessions. In Debug
    # builds, concurrent CTest workers can make the original 120-second limit
    # nondeterministic even though the scenario itself remains stable.
    set_tests_properties(automatic_throttle_sweep_anti_hunt_regression PROPERTIES
      RUN_SERIAL TRUE
      TIMEOUT 300)
    # Four full authenticated vehicle sessions are intentionally executed in
    # sequence.  Keep this workload isolated from other CPU-heavy Debug tests;
    # otherwise scheduler contention can consume the per-session Python timeout
    # even though every deterministic vehicle case completes normally alone.
    # The aggregate CTest timeout exceeds the four 90-second child budgets.
    set_tests_properties(partial_throttle_realism_regression PROPERTIES
      RUN_SERIAL TRUE
      TIMEOUT 420)
    add_test(NAME automatic_coastdown_downshift_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/automatic_coastdown_downshift_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(automatic_coastdown_downshift_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME rpm_four_digit_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/rpm_four_digit_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(rpm_four_digit_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME realworld_gti_spec_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/realworld_gti_spec_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME plugin_loader_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/plugin_loader_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME plugin_dashboard_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/plugin_dashboard_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME expanded_realworld_presets_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/expanded_realworld_presets_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME preset_readability_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/preset_readability_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(preset_readability_regression PROPERTIES TIMEOUT 120)
    add_test(NAME resource_lookup_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/resource_lookup_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME metric_dictionary_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/metric_dictionary_regression.py $<TARGET_FILE:muzixdiagsys>)
    # Authentication uses a deliberately expensive password KDF and this test
    # launches the complete console application. Keep it isolated from other
    # CPU-heavy/authenticated regressions so its bounded child-process deadline
    # measures an actual application stall rather than CTest scheduler pressure.
    set_tests_properties(metric_dictionary_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 60)
    add_test(NAME research_features_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/research_features_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME research_workflow_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/research_workflow_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(research_workflow_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME engineering_studio_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/engineering_studio_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(engineering_studio_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME accuracy_depth_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/accuracy_depth_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME project_workflow_causal_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/project_workflow_causal_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(project_workflow_causal_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME network_fault_lab_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/network_fault_lab_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(network_fault_lab_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME simulation_experience_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/simulation_experience_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME can_obd_synthesis_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/can_obd_synthesis_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME socketcan_obd_responder_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/socketcan_obd_responder_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(accuracy_depth_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 150)
    add_test(NAME research_expansion_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/research_expansion_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME professional_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME professional_platform_v2_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_platform_v2_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME industrial_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/industrial_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME advanced_vehicle_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_vehicle_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME perception_realism_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/perception_realism_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(perception_realism_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 240)
    set_tests_properties(advanced_vehicle_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME assurance_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/assurance_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME assurance_resilience_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/assurance_resilience_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(assurance_resilience_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 150)
    if(TARGET aesim_study_worker)
      add_test(NAME vehicle_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/vehicle_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} $<TARGET_FILE:aesim_study_worker>)
      set_tests_properties(vehicle_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    endif()
    add_test(NAME electrification_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/electrification_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(electrification_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME frontier_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})

    # The standalone advanced-platform executable is optional.  Keep its CLI
    # regressions coupled to the target so BUILD_TESTING remains a valid
    # configuration when AESIM_BUILD_TOOLS=OFF.  Unconditionally embedding a
    # TARGET_FILE generator expression for a non-existent optional target makes
    # CMake fail during generation before any source-only or library tests can
    # run.
    if(TARGET muzixdiagsys_advanced_platform)
      add_test(NAME engineering_intelligence_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/engineering_intelligence_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform>)
      set_tests_properties(engineering_intelligence_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 120)
      add_test(NAME frontier_runtime_sensing_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_runtime_sensing_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(frontier_runtime_sensing_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
      add_test(NAME frontier_expansion_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_expansion_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(frontier_expansion_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
      add_test(NAME frontier_systems_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_systems_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(frontier_systems_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
      add_test(NAME frontier_integration_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_integration_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(frontier_integration_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
      add_test(NAME frontier_next_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/frontier_next_cli_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(frontier_next_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
      add_test(NAME motorsport_cli_commands_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/motorsport_cli_commands_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(motorsport_cli_commands_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 300)
      add_test(NAME advanced_api_cli_commands_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_api_cli_commands_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(advanced_api_cli_commands_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 600)
      add_test(NAME advanced_api_services_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_api_services_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform>)
      set_tests_properties(advanced_api_services_regression PROPERTIES TIMEOUT 240)
      add_test(NAME advanced_api_lifecycle_transport_system_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_api_lifecycle_transport_system_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform>)
      set_tests_properties(advanced_api_lifecycle_transport_system_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 360)
      add_test(NAME advanced_api_engineering_expansion_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/advanced_api_engineering_expansion_regression.py $<TARGET_FILE:muzixdiagsys_advanced_platform> ${CMAKE_CURRENT_SOURCE_DIR})
      set_tests_properties(advanced_api_engineering_expansion_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 360)
    endif()
    add_test(NAME interactive_advanced_motorsport_cli_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/interactive_advanced_motorsport_cli_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR})
    set_tests_properties(interactive_advanced_motorsport_cli_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 120)
    set_property(GLOBAL APPEND PROPERTY AESIM_COMPILED_ARTIFACT_TESTS interactive_advanced_motorsport_cli_regression)
    if(TARGET muzixdiagsys_advanced_platform AND
       TARGET muzixdiagsys_engineering AND TARGET muzixdiagsys_causal_lab AND
       TARGET muzixdiagsys_advanced_safety AND TARGET muzixdiagsys_specification_discovery AND
       TARGET muzixdiagsys_standards_deployment AND TARGET muzixdiagsys_frontier_professional AND
       TARGET aesim_study_worker AND TARGET research_reference_generator AND
       TARGET muzixdiagsys_generalized_ops AND TARGET muzixdiagsys_native_qualification AND
       TARGET muzixdiagsys_motorsport_v35 AND TARGET muzixdiagsys_professional_authority_v36 AND
       TARGET muzixdiagsys_ecu_diagnostics_v37 AND TARGET muzixdiagsys_v50_reality AND
       TARGET muzixdiagsys_v51_reality)
      add_test(NAME backend_executable_cli_parity_regression
        COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/backend_executable_cli_parity_regression.py
                ${CMAKE_CURRENT_SOURCE_DIR}
                $<TARGET_FILE:muzixdiagsys>
                $<TARGET_FILE:muzixdiagsys_advanced_platform>
                $<TARGET_FILE:muzixdiagsys_engineering>
                $<TARGET_FILE:muzixdiagsys_causal_lab>
                $<TARGET_FILE:muzixdiagsys_advanced_safety>
                $<TARGET_FILE:muzixdiagsys_specification_discovery>
                $<TARGET_FILE:muzixdiagsys_standards_deployment>
                $<TARGET_FILE:muzixdiagsys_frontier_professional>
                $<TARGET_FILE:aesim_study_worker>
                $<TARGET_FILE:research_reference_generator>
                $<TARGET_FILE:muzixdiagsys_generalized_ops>
                $<TARGET_FILE:muzixdiagsys_native_qualification>
                $<TARGET_FILE:muzixdiagsys_motorsport_v35>
                $<TARGET_FILE:muzixdiagsys_professional_authority_v36>
                $<TARGET_FILE:muzixdiagsys_ecu_diagnostics_v37>
                $<TARGET_FILE:muzixdiagsys_v50_reality>
                $<TARGET_FILE:muzixdiagsys_v51_reality>)
      set_tests_properties(backend_executable_cli_parity_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 300)
      set_property(GLOBAL APPEND PROPERTY AESIM_COMPILED_ARTIFACT_TESTS backend_executable_cli_parity_regression)
    endif()
    add_test(NAME federation_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/federation_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    set_tests_properties(federation_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME research2_platform_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/research2_platform_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    set_tests_properties(research2_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME osi_protobuf_wire_conformance COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/osi_protobuf_wire_conformance.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(osi_protobuf_wire_conformance PROPERTIES RUN_SERIAL TRUE TIMEOUT 90)
    set_tests_properties(frontier_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    set_tests_properties(assurance_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 120)
    set_tests_properties(industrial_platform_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME professional_depth_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_depth_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME professional_advanced_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_advanced_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    # The workflow intentionally runs many high-fidelity operations in one
    # process.  Isolate it from parallel load so its timeout measures the
    # simulator rather than host contention.
    set_tests_properties(professional_advanced_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 150)
    add_test(NAME professional_ops_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_ops_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME accuracy_richness_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/accuracy_richness_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME command_surface_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/command_surface_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME readme_command_audit_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/readme_command_audit_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    # This audit intentionally exercises nearly the entire command surface,
    # including the fixed API port and shared generated-artifact paths. Keep it
    # isolated so parallel CTest runs remain deterministic.
    set_tests_properties(readme_command_audit_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME professional_feature_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_feature_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME case_sensitive_path_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/case_sensitive_path_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME professional_optimization_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/professional_optimization_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME research_level_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/research_level_regression.py $<TARGET_FILE:muzixdiagsys> ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR})
    add_test(NAME terminal_formatting_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/terminal_formatting_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(terminal_formatting_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 90)
    add_test(NAME native_plugin_step_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/native_plugin_step_regression.py $<TARGET_FILE:muzixdiagsys> $<TARGET_FILE:aesim_sample_native_plugin>)
    add_test(NAME nonfinite_input_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/nonfinite_input_regression.py $<TARGET_FILE:muzixdiagsys>)
    add_test(NAME api_server_regression COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tests/api_server_regression.py $<TARGET_FILE:muzixdiagsys>)
    set_tests_properties(api_server_regression PROPERTIES RUN_SERIAL TRUE TIMEOUT 60)
  endif()

  # All CLI regressions authenticate through the same production path used by
  # operators. The credential file is confined to the build tree and protected
  # by owner-only permissions; no authentication bypass exists in the binary.
  set(AESIM_TEST_AUTH_DIR "${CMAKE_CURRENT_BINARY_DIR}/test_runtime/auth")
  set(AESIM_TEST_AUTH_CREDENTIALS "${AESIM_TEST_AUTH_DIR}/credentials.txt")
  set(AESIM_TEST_AUTH_DATABASE "${AESIM_TEST_AUTH_DIR}/users.json")
  file(MAKE_DIRECTORY "${AESIM_TEST_AUTH_DIR}")
  file(WRITE "${AESIM_TEST_AUTH_CREDENTIALS}" "jtmuzix\nT1k1@420\n")
  if(UNIX)
    execute_process(COMMAND chmod 700 "${AESIM_TEST_AUTH_DIR}")
    execute_process(COMMAND chmod 600 "${AESIM_TEST_AUTH_CREDENTIALS}")
  endif()
  get_property(AESIM_REGISTERED_TESTS DIRECTORY PROPERTY TESTS)
  if(AESIM_REGISTERED_TESTS)
    set_property(TEST ${AESIM_REGISTERED_TESTS} APPEND PROPERTY ENVIRONMENT
      "MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE=${AESIM_TEST_AUTH_CREDENTIALS}"
      "MUZIXDIAGSYS_USER_DB=${AESIM_TEST_AUTH_DATABASE}")
  endif()
endif()

# CTest normally assumes that the build step has already produced every test
# executable and runtime artifact.  In a feature-dense tree that assumption can
# turn one interrupted or partial build into a misleading cascade of
# FileNotFoundError/"missing executable" failures.  Keep a single dependency
# closure for both the transactional `aesim_check` target and a CTest fixture.
# The fixture makes direct invocations such as `ctest -R cli_regression`
# self-healing: CTest builds the required artifact closure once, before any
# registered test is allowed to start.  If compilation fails, the setup fixture
# reports the primary build error and dependent tests are not run.
if(BUILD_TESTING)
  get_property(AESIM_DIRECTORY_TARGETS DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
  set(AESIM_CHECK_DEPENDENCIES)
  foreach(AESIM_TARGET IN LISTS AESIM_DIRECTORY_TARGETS)
    get_target_property(AESIM_TARGET_TYPE ${AESIM_TARGET} TYPE)
    if(AESIM_TARGET_TYPE MATCHES
        "^(EXECUTABLE|STATIC_LIBRARY|SHARED_LIBRARY|MODULE_LIBRARY|OBJECT_LIBRARY)$")
      list(APPEND AESIM_CHECK_DEPENDENCIES ${AESIM_TARGET})
    endif()
  endforeach()
  list(REMOVE_DUPLICATES AESIM_CHECK_DEPENDENCIES)

  add_custom_target(aesim_test_artifacts
    DEPENDS ${AESIM_CHECK_DEPENDENCIES}
    COMMENT "Building the complete test runtime artifact closure")

  set(AESIM_TEST_ARTIFACT_BUILD_COMMAND
      ${CMAKE_COMMAND}
      --build ${CMAKE_CURRENT_BINARY_DIR}
      --target aesim_test_artifacts)
  if(CMAKE_CONFIGURATION_TYPES)
    list(APPEND AESIM_TEST_ARTIFACT_BUILD_COMMAND --config $<CONFIG>)
  endif()

  # Bypass the add_test wrapper: this entry creates the fixture rather than
  # consuming a compiled project artifact.
  _add_test(NAME aesim_prepare_test_artifacts
    COMMAND ${AESIM_TEST_ARTIFACT_BUILD_COMMAND})
  set_tests_properties(aesim_prepare_test_artifacts PROPERTIES
    FIXTURES_SETUP aesim_test_artifacts_ready
    RUN_SERIAL TRUE
    RESOURCE_LOCK aesim_build_tree
    TIMEOUT 3600)

  get_property(AESIM_COMPILED_ARTIFACT_TESTS GLOBAL PROPERTY
    AESIM_COMPILED_ARTIFACT_TESTS)
  if(AESIM_COMPILED_ARTIFACT_TESTS)
    list(REMOVE_DUPLICATES AESIM_COMPILED_ARTIFACT_TESTS)
    set_tests_properties(${AESIM_COMPILED_ARTIFACT_TESTS} PROPERTIES
      FIXTURES_REQUIRED aesim_test_artifacts_ready)
  endif()

  add_custom_target(aesim_check
    COMMAND ${CMAKE_CTEST_COMMAND}
            --test-dir ${CMAKE_CURRENT_BINARY_DIR}
            --output-on-failure
    DEPENDS aesim_test_artifacts
    USES_TERMINAL
    COMMENT "Building all binaries and running the complete CTest suite")
endif()

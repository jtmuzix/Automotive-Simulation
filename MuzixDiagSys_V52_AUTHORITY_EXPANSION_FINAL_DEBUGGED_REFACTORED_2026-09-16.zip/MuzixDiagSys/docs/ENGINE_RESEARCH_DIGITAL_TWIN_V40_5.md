# V40.5 Engine Research Digital Twin

## Purpose and implementation scope

`aesim::high_fidelity::EngineResearchDigitalTwin` is the feature-preserving, cylinder-resolved engine research orchestration layer in MuzixDiagSys. It couples the existing crank-angle gas-dynamics, injection/spray/combustion, cranktrain/valvetrain/EHL, forced-induction gas-path, thermal, durability, and calibration authorities and extends them with the advanced engine physics required for research-oriented transient studies.

The implementation is deliberately **not** a parallel replacement engine. Existing specialist solvers remain authoritative and are reused in the coupled loop. The V40.5 layer supplies the additional state, reduced-order physics, transport networks, observer/control loops, lifecycle accounting, and design/calibration optimization required to make those existing authorities interact as one digital twin.

The current implementation contains no placeholder execution paths for the V40.5 engine features documented here. The models are reduced-order engineering models where their names explicitly state that fact (for example, reduced chemical kinetics and reduced-FE flexible-body dynamics); they are not represented as full 3-D CFD, hundreds-species chemistry, or general-purpose nonlinear finite-element solvers.

## Authority and non-duplication map

The coupled authority chain is:

```text
core::LumpedGasPathModel
  turbo compressor/turbine and established lumped gas-path authority
                |
                v
EngineResearchDigitalTwin gas-wave network
  intake feed -> plenum -> N runners -> cylinders
  cylinders -> N primaries -> collector -> exhaust boundary
  (all 1-D branches reuse OneDimensionalGasDuct)
                |
                v
CrankAngleGasDynamicsEngine
  canonical crank-angle cylinder / gas-exchange authority
                ^
                | actual valve lift + wave-network boundary state
CranktrainValvetrainEhlSystem
  canonical crank torsion + valvetrain + EHL bearing authority
                ^
                | cylinder pressure + oil-gallery supply state
DetailedInjectionCombustionSystem
  canonical DI/PFI needle/spray/film/combustion/emissions authority
                ^
                | coupled fuel hydraulics + charge/EGR/control state
EngineResearchDigitalTwin extensions
  reduced chemistry + turbulence/flame-kernel physics
  EGR transport + oil hydraulics/dry sump + reduced FE
  clearance evolution + aftertreatment + pressure observers/control
  lifecycle/RUL/genealogy + advanced supplemental fueling
                |
                v
EngineResearchState
                |
                +--> EngineDynoCalibrationLab::calibrate()
                +--> EngineDynoCalibrationLab::optimize_design_and_calibration()
                     (reuses AutomatedCalibrationValidationUQ)
```

There is one established turbo gas-path authority, one established crank-angle engine authority, one established cranktrain/valvetrain/EHL authority, one detailed injection/combustion authority, and one automated calibration/UQ authority. The new per-runner/per-primary network is built from the already established `OneDimensionalGasDuct` numerical authority rather than from a second compressible-flow implementation.

## Coupled step ordering

A host call to `EngineResearchDigitalTwin::step(input, dt_s)` advances the mutually dependent states in a deterministic order. The significant feedback paths are:

1. deterministic fault injection modifies health/thermal/structural state before the new solve;
2. EGR transport establishes internal residuals, delayed/cooled external EGR, and intake oxygen fraction;
3. forced induction and water/methanol/nitrous/nitromethane conditioning establish the effective charge boundary;
4. oil hydraulics establishes gallery pressure, aeration-dependent viscosity, bearing/jet flow, and pump/windage power;
5. the 1-D feed/plenum/runner/header/collector network establishes cylinder intake/exhaust boundary pressures;
6. chamber turbulence/squish/flame-kernel state establishes turbulent flame and quench multipliers;
7. fuel hydraulics and detailed injection/combustion consume the charge, health, and closed-loop trims;
8. cranktrain/valvetrain/EHL consumes cylinder pressure and oil supply state;
9. the canonical crank-angle gas-dynamics engine consumes actual valve lift, charge composition, wave boundaries, EGR, aftertreatment backpressure, and controller commands;
10. multi-zone thermodynamics and reduced chemistry update heat release, species, wall heat, and abnormal combustion state;
11. ring tribology, structural stress/fatigue, reduced-FE dynamics, thermal state, and clearances are advanced;
12. engine-out emissions and aftertreatment update conversion, storage, soot loading/regeneration, tailpipe emissions, and next-step backpressure;
13. cylinder-pressure observers update peak-pressure/IMEP/CA50/knock estimates and the closed-loop controller computes bounded next-cycle spark/fuel/EGR/boost corrections;
14. health, lifecycle damage, RUL, and component genealogy are updated; and
15. brake output, friction/pumping losses, fuel flow, BSFC, efficiency, and report state are finalized.

This ordering makes the added subsystems physically consequential. They are not telemetry-only calculations.

# 1. Detailed reduced chemical kinetics

Each cylinder owns a `ReducedChemicalKineticsState`. The mechanism tracks normalized mass fractions for fuel, O2, N2, CO2, CO, H2O, H2, NO, and OH and integrates three temperature-dependent reduced reaction families:

- global fuel oxidation;
- CO oxidation toward CO2; and
- high-temperature NO formation.

The configurable Arrhenius forms use pre-exponential factors and activation temperatures from `EngineResearchConfiguration`. The implementation bounds reaction progress by the locally available reactant inventory, renormalizes species after integration, records a species-mass residual, and computes:

- fuel oxidation rate;
- CO oxidation rate;
- NO formation rate;
- chemical heat release;
- equilibrium-temperature estimate;
- chemical timescale with `kinetics_minimum_timescale_s` as a lower bound; and
- a combustion-efficiency multiplier that feeds the authoritative coupled engine output.

The mechanism uses multi-zone temperature/pressure, effective oxygen fraction, EGR dilution, and advanced-fuel LHV rather than a fixed ambient composition. The purpose is research-grade reduced chemistry suitable for a real-time/fast-transient engine digital twin; it is not presented as a detailed hundreds-species chemical reactor.

# 2. Advanced chamber turbulence, squish, and flame-kernel combustion

`ChamberTurbulenceCombustionState` is cylinder resolved and advances:

- turbulent kinetic energy and dissipation rate;
- turbulence intensity;
- tumble ratio;
- squish velocity;
- integral and Kolmogorov length scales;
- laminar and turbulent flame speed;
- flame-kernel radius;
- flame-surface-area ratio;
- Damkohler and Karlovitz numbers;
- quench probability; and
- a bounded burn-rate multiplier.

The model derives piston/squish forcing from engine speed and geometry, carries turbulence through a production/dissipation balance, and grows the flame kernel from `flame_kernel_initial_radius_m`. EGR, lambda, pressure, temperature, and water/methanol knock/charge-conditioning state modify flame speed and quench behavior. The resulting burn-rate multiplier and quench state feed the combustion/chemistry path instead of being display-only outputs.

# 3. Full intake/plenum/header wave network

The V40.5 network is represented by `GasWaveNetworkState` and the following reusable 1-D duct objects:

```text
compressor/ambient -> intake_feed_duct_
                   -> lumped plenum conservation volume
                   -> intake_runners_[cylinder]
                   -> cylinder ports

cylinder ports     -> exhaust_primaries_[cylinder]
                   -> lumped exhaust collector conservation volume
                   -> exhaust_collector_duct_
                   -> turbine/exhaust boundary
```

Each branch is an actual `OneDimensionalGasDuct` finite-volume compressible-flow domain. Configuration exposes feed/plenum/header geometry, runner and primary cell counts, and junction loss. The coupled state reports plenum/collector mass, temperature and pressure; individual branch flows and port pressures; pulse amplitudes; maximum runner Mach number; and mass/energy residuals.

The plenum and collector use explicit mass/energy storage so pressure waves and cylinder phasing can influence subsequent cylinders. The resulting intake/exhaust port pressures become the canonical crank-angle engine boundaries. Aftertreatment backpressure is included on the downstream side of the collector.

# 4. Internal and external EGR transport

`EgrTransportState` separates internal and external EGR rather than using one algebraic dilution scalar.

Internal residual fraction is evaluated cylinder by cylinder from valve-overlap context and exhaust/intake pressure conditions. External EGR uses:

- a commanded fraction;
- flow-capacity limiting;
- a finite loop inventory;
- a configurable transport time constant;
- cooler effectiveness and cooler bypass; and
- exhaust oxygen-content tracking.

The resulting delivered external fraction is combined with per-cylinder internal residuals into `effective_egr_fraction`. Intake oxygen fraction and charge temperature are updated accordingly and are consumed by combustion, kinetics, gas exchange, emissions, and closed-loop control.

Compatibility is preserved: when `EngineResearchInput::external_egr_command_fraction < 0`, the legacy `egr_fraction` input remains the external-EGR command.

# 5. Full oil hydraulic, aeration, and dry-sump model

`OilHydraulicState` models the lubrication circuit as conserved oil inventories and hydraulic flow paths rather than only an oil-temperature scalar. It includes:

- reservoir, crankcase, and pressure-gallery oil mass;
- positive-displacement pressure-pump flow;
- dry-sump scavenge flow and scavenge ratio;
- pump drive ratio and volumetric efficiency;
- gallery pressure and pressure relief;
- filter pressure loss;
- main-bearing supply demand;
- piston cooling-jet demand;
- aeration/foaming and finite deaeration;
- cavitation index;
- aeration-adjusted effective viscosity;
- pump power;
- windage power; and
- oil mass-conservation residual.

Longitudinal/lateral acceleration can disturb crankcase pickup and aeration. When dry-sump mode is enabled, reservoir/scavenge dynamics remain active instead of collapsing to a wet-sump approximation. Gallery pressure and effective viscosity are coupled to the canonical EHL/bearing path, while pump/windage loss contributes to total engine parasitic loss.

# 6. Reduced-FE crankshaft, connecting-rod, and piston flexible-body dynamics

The existing rigid/torsional cranktrain remains authoritative. `ReducedFeFlexibleBodyState` adds deformation dynamics using a configurable modal basis rather than replacing that solver.

The crankshaft has `reduced_fe_crank_modes` generalized coordinates, velocities and accelerations. Natural frequencies are generated from the configured first mode and spacing ratio; each modal oscillator includes inertia, stiffness, and damping. Cylinder gas/inertia forcing excites the modes through phase-dependent participation factors.

Connecting rods and piston crowns have reduced compliant coordinates driven by the existing structural load state. The model reports:

- crank modal displacement/velocity/acceleration;
- modal stress;
- rod dynamic stretch;
- piston-crown deflection;
- crank-web deflection;
- maximum dynamic stress;
- elastic strain energy; and
- damping power.

Dynamic flexible-body stress is combined with the established rod/piston/crank stress and fatigue accounting so it changes safety factor, cumulative fatigue, health, and RUL.

# 7. Thermal-expansion and clearance evolution

Each cylinder owns `ClearanceEvolutionState`. Thermal expansion is calculated from the current component thermal network and the configured material coefficients for aluminum, iron, and steel. Flexible-body deflection is included where it changes the running geometry.

The model evolves:

- piston-to-liner running clearance;
- ring end gap;
- main-bearing radial clearance;
- intake-valve lash;
- exhaust-valve lash;
- piston growth;
- liner growth;
- seizure margin; and
- lash margin.

Clearance state feeds tribology and health. Piston/liner clearance changes blow-by and ring-film behavior, bearing clearance changes lubrication margin, and valve lash contributes to valvetrain risk. A finite `minimum_operating_clearance_m` is enforced as a numerical/physical lower bound while the unbounded margin is retained for seizure-risk reporting.

# 8. Detailed engine emissions and aftertreatment

`AftertreatmentState` contains both `engine_out` and `tailpipe` `EngineOutEmissionsState` records. Engine-out aggregation retains the existing cylinder emissions authority and adds reduced-chemistry support where appropriate. Tracked quantities are:

- NOx mass rate;
- soot mass rate;
- unburned HC mass rate;
- CO mass rate;
- CO2 mass rate; and
- particulate-number rate.

The aftertreatment path contains thermally activated TWC, DOC, DPF, and SCR states with:

- independent catalyst/filter temperatures;
- TWC oxygen storage;
- DPF soot loading and regeneration;
- SCR ammonia storage;
- urea dosing input;
- conversion/filtration efficiencies;
- exhaust backpressure;
- cumulative tailpipe NOx and CO2; and
- an energy-accounting residual.

Conversion efficiency is light-off dependent rather than constant. Rich/lean state affects TWC oxygen storage, DPF loading raises pressure loss, hot operation can regenerate soot, and SCR NOx conversion is constrained by both temperature and stored reductant. Calculated aftertreatment pressure loss feeds the next gas-wave/exhaust solve.

# 9. Cylinder-pressure observers and advanced closed-loop combustion control

Each cylinder has a `CylinderPressureObserverState`. The observer performs a bounded Kalman-like correction using the authoritative cylinder pressure/combustion result and estimates:

- peak cylinder pressure;
- IMEP;
- CA50;
- knock index;
- pressure-sensor/model bias;
- innovation;
- covariance; and
- combustion-phasing uncertainty.

`CombustionControllerState` uses these estimates to compute cylinder spark and fuel trims plus engine-level EGR and boost trims. Targets are configurable globally and may be overridden in `EngineResearchInput` with `target_ca50_deg_atdc`, `target_peak_pressure_bar`, and `target_imep_bar`.

The controller includes integral state and hard authority limits for spark, fuel, EGR, and boost. It reacts to phasing error, peak-pressure constraint error, and knock error. Trims are applied on the next coupled cycle so the loop is causal. `closed_loop_combustion_control=false` disables active correction without deleting observer state.

# 10. Engine lifecycle, RUL, rebuilds, and component genealogy

`EngineLifecycleState` maintains engine hours, total cycles, minimum RUL, limiting component, an installed-component registry, and an immutable event history.

The registry includes shared engine components and cylinder-local components such as pistons, rods, rings, bearings, valves, and injectors. Each `EngineLifecycleComponentState` records:

- stable component/generation identity;
- parent identity;
- type and cylinder association;
- generation and rebuild count;
- installed and operating time;
- accumulated cycles;
- damage fraction;
- remaining useful life in hours and cycles; and
- service-due state.

Damage is derived from the actual engine health, structural/fatigue, tribology, thermal, and aftertreatment states. `EngineResearchDigitalTwin::rebuild_component(component_id)` restores the appropriate physical/health wear state according to `rebuild_restoration_fraction`, creates the next generation identity, reconnects child parentage when necessary, increments rebuild history, and records an `EngineLifecycleEvent` containing predecessor/successor identity and pre-event damage. This makes rebuilds auditable rather than simply zeroing a scalar.

# 11. Water, methanol, nitrous oxide, and nitromethane advanced fueling physics

`AdvancedFuelingState` advances the delivered supplemental-fluid state from the following `EngineResearchInput` commands:

- `water_injection_kg_s`;
- `methanol_injection_kg_s`;
- `nitrous_oxide_injection_kg_s`;
- `nitromethane_mass_fraction`; and
- `supplemental_fluid_temperature_k`.

The model applies configured delivery limits and finite delivery response, then computes the principal engine-level effects required by the coupled solver:

- water/methanol latent charge cooling;
- nitrous decomposition oxygen contribution and charge-mass increase;
- methanol chemical energy contribution;
- nitromethane-adjusted effective LHV and stoichiometric AFR;
- effective intake temperature;
- effective oxygen mass fraction;
- supplemental chemical power; and
- a charge-cooling/oxygen-fraction knock-suppression index.

These quantities modify intake boundary temperature/composition, effective oxygen inventory, requested fueling, chemical heat release, knock tendency, and brake output. They are therefore part of the physical solve, not post-processing multipliers.

# 12. Durability-aware automatic engine design and calibration optimizer

`EngineDynoCalibrationLab` remains the single engine dyno/calibration authority. The existing `calibrate()` path still delegates parameter estimation and uncertainty work to `AutomatedCalibrationValidationUQ`.

The new `optimize_design_and_calibration()` method adds a durability-aware outer design loop around that same authority. `EngineDurabilityOptimizationRequest` defines the weighted objective and constraints for:

- dyno fit;
- BSFC;
- peak cylinder pressure;
- exhaust temperature;
- fatigue/safety factor; and
- minimum RUL.

The deterministic coordinate search varies physically bounded design/calibration quantities including compression ratio, supercharger drive ratio, wall-heat scaling, rod section, crank section modulus, and friction scaling. Each candidate is evaluated through the same dyno prediction/correlation path, constraint penalties are applied, and the selected design is finally passed back through canonical calibration/UQ.

`EngineDesignOptimizationResult` reports feasibility, evaluation count, objective, dyno fit, BSFC, pressure/temperature limits, estimated safety factor/RUL, the optimized engine configuration, and the associated calibrated/UQ result. This avoids creating a second optimizer with competing parameter semantics.

# Preserved V40.5 engine capabilities

The advanced additions above retain the previously implemented V40.5 capabilities:

- canonical finite-volume crank-angle intake/exhaust gas dynamics;
- multi-zone unburned/burned/crevice thermodynamic state;
- Woschni/Hohenberg-type wall heat transfer and component heat partition;
- knock, pre-ignition, and detonation exposure;
- compliant follower/rocker/valve/spring-surge valvetrain dynamics;
- external DI/PFI hydraulic authority, needle/spray/droplet physics, and wall films;
- naturally aspirated, turbocharger, centrifugal/Roots/twin-screw supercharger, and compound modes;
- EHL main-bearing state;
- ring-pack tribology, blow-by, oil consumption, and wear;
- rod/piston/crank structural stress and cumulative fatigue;
- component thermal network and energy residual;
- per-cylinder health and deterministic failure propagation; and
- dyno correlation plus automatic calibration/UQ.

# C++ usage

## Basic coupled run

```cpp
#include "aesim/high_fidelity/engine_research_digital_twin.hpp"

using namespace aesim::high_fidelity;

EngineResearchConfiguration cfg;
cfg.forced_induction_mode = EngineForcedInductionMode::Turbocharger;
cfg.dry_sump_enabled = true;

EngineResearchDigitalTwin engine(cfg);
EngineResearchInput input;
input.rpm = 5200.0;
input.load = 0.92;
input.throttle = 0.96;
input.lambda = 0.92;
input.spark_deg_btdc = 17.0;
input.requested_fuel_mass_kg_cycle = 3.4e-5;
input.external_egr_command_fraction = 0.04;
input.water_injection_kg_s = 0.004;
input.methanol_injection_kg_s = 0.001;
input.closed_loop_combustion_control = true;

for (int n = 0; n < 4000; ++n) {
    engine.step(input, 0.0005);
}

const auto& state = engine.state();
```

Important structured state is then available through:

```cpp
state.chemical_kinetics
state.chamber_turbulence
state.gas_wave_network
state.egr_transport
state.oil_hydraulics
state.flexible_body
state.clearances
state.aftertreatment
state.pressure_observers
state.combustion_controller
state.lifecycle
state.advanced_fueling
```

The pre-existing V40.5 state remains in the same `EngineResearchState` object.

## Rebuild/genealogy operation

```cpp
const auto before = engine.lifecycle();
const std::string component = before.limiting_component_id;
if (!component.empty()) {
    const bool rebuilt = engine.rebuild_component(component);
    (void)rebuilt;
}
const auto& after = engine.lifecycle();
```

The rebuild call must use a currently installed `component_id`. A successful rebuild creates a successor generation and appends a genealogy event; it does not erase the predecessor record from history.

## Durability-aware optimization

```cpp
EngineDynoCalibrationLab dyno;
EngineDurabilityOptimizationRequest request;
request.minimum_safety_factor = 1.45;
request.maximum_peak_pressure_bar = 175.0;
request.maximum_exhaust_temperature_c = 940.0;
request.minimum_rul_hours = 750.0;
request.coordinate_passes = 6;

AutomatedAssuranceOptions assurance;
assurance.maximum_iterations = 40;
assurance.cross_validation_folds = 3;
assurance.uncertainty_samples = 24;

auto result = dyno.optimize_design_and_calibration(
    cfg, measured_dyno_points, request, assurance);
```

A feasible result means the reduced-order design evaluator met the configured optimizer constraints. It does not replace physical test, FEA/CFD correlation, emissions certification, or durability sign-off.

# Numerical and physical invariants

The coupled implementation enforces or reports the following invariants so qualification can detect silent failure:

- finite and positive absolute pressures/temperatures;
- normalized reduced-chemistry species and a finite species residual;
- finite gas-wave plenum/collector mass and energy residuals;
- bounded EGR and oxygen fractions;
- conserved oil inventory with a reported mass residual;
- finite modal displacement/stress/energy for the reduced-FE model;
- finite operating clearances and explicit seizure/lash margins;
- non-negative aftertreatment storage/load states and bounded conversion efficiencies;
- finite observer covariance and bounded closed-loop control authority;
- monotonic lifecycle time/cycles and bounded component damage;
- finite effective fuel LHV/AFR and delivered supplemental-fluid limits; and
- deterministic optimizer evaluation under fixed configuration/measurement input.

# Validation and qualification

The V40.5 engine path is covered in `tests/ecosystem_tests.cpp`. The current focused qualification exercises the established V40.5 authorities plus the twelve advanced extensions documented above, including state activity, finite/conserved quantities, control/observer state, lifecycle rebuild genealogy, and durability-aware optimization.

Recommended local gate after modifying this subsystem:

```bash
cmake -S . -B build/engine-validation -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build/engine-validation --target ecosystem_tests
./build/engine-validation/ecosystem_tests

cmake --build build/engine-validation --target high_fidelity_vehicle_tests
./build/engine-validation/high_fidelity_vehicle_tests

python3 tests/user_manual_regression.py .
```

The package-level release gate may contain many additional project tests. Do not substitute the focused engine gate for the full release suite when certifying an entire MuzixDiagSys release.

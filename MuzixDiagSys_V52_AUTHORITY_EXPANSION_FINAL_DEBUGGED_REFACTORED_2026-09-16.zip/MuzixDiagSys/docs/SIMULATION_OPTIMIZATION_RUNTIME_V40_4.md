# MuzixDiagSys V40.4 Unified Simulation Optimization Runtime

**Release:** V40.4  
**Scope:** General simulation execution/runtime optimization  
**Authority:** `aesim::advanced::runtime`

V40.4 consolidates existing runtime-scaling capabilities into a single optimization runtime without removing or cloning the established hybrid integrator, COW branch engine, SoA ensemble executor, incremental dependency engine, heterogeneous compute backends, hardware-placement authority, checkpoint infrastructure, or performance-contract machinery.

## 1. Architecture

`SimulationOptimizationRuntime` is the orchestration layer. It owns no second physics model. Domain RHS callbacks remain the physics authority; the runtime decides when and where those callbacks execute and which existing numerical/runtime services are used.

The runtime composes:

- `AdaptiveHybridIntegratorSupervisor` for adaptive explicit/stiff integration;
- `DynamicFidelityController` for cost/error-budget fidelity selection;
- `IncrementalDependencyEngine` for generation/dirty-state execution;
- `GlobalHeterogeneousTaskScheduler` plus `frontier::HardwareAwareScheduler` for CPU/GPU/NUMA/MPI-aware task placement;
- `AutomaticSolverToleranceTuner` for feedback-driven solver/tolerance policy;
- `CowStateStore` and `SimulationForkEngine` for incremental checkpoint branches;
- `BatchedStateSoA` and `BatchedEnsembleExecutor` for vectorized ensembles;
- `AlignedMemoryArena`, `MutableStateSlice`, and `ConstStateSlice` for stable aligned state and zero-copy cross-domain views;
- `IntegratedPerformanceProfiler` and `OptimizationAdvisor` for measured bottleneck analysis.

## 2. Adaptive multi-rate solver runtime

Each `MultiRateDomainConfig` defines an independent synchronization period and internal integration step bounds. The runtime advances only domains due at the current synchronization frontier. Domains can therefore operate at materially different rates while receiving a read-only zero-copy view of the other domain states at the synchronization boundary.

Within a domain interval, integration is adaptive. The existing hybrid supervisor selects Dormand-Prince, Rosenbrock-W, BDF2, or Radau IIA according to stiffness/event behavior and the automatic tuning policy.

The run report records per-domain synchronization steps, accepted/rejected solver steps, RHS evaluations, solver switches, fidelity transitions, wall time, simulated time, and realtime factor.

## 3. Dynamic fidelity controller

A domain may register multiple `FidelityLevel` entries. Every level declares:

- a name;
- an estimated error bound;
- relative execution cost;
- integration-step scale.

The controller enforces a maximum error budget and realtime target with hysteresis. When the measured domain error exceeds the configured envelope it selects the most accurate admissible level. When realtime performance is below target it selects the lowest-cost level that still satisfies the error envelope. Realtime headroom may be exchanged for additional fidelity.

A domain-specific error estimator can be supplied so fidelity control is driven by measured model error rather than nominal level metadata alone.

## 4. Dependency and dirty-state execution

Every registered simulation domain automatically publishes a dependency source named `domain:<id>`. Additional source and computed nodes can be registered through the runtime.

A source update propagates dirtiness only through dependent nodes. Unchanged values inside configured absolute/relative change thresholds remain cached. Derived nodes are evaluated lazily, so unrelated state changes do not force recomputation.

`DependencyExecutionStats` reports evaluations, cache hits, and dirty propagations for profiler/advisor use.

## 5. Global heterogeneous task scheduling

`GlobalHeterogeneousTaskScheduler` executes a validated DAG of `RuntimeTask` objects. A task declares dependencies, preferred resource, CPU-thread requirement, memory requirement, and whether an accelerator is mandatory.

Placement uses the established `frontier::HardwareAwareScheduler` topology discovery and NUMA-local placement logic. The task context reports CPU set, NUMA node, GPU index where available, and MPI rank/size discovered from common MPI/PMI/SLURM environments. Required accelerator requests fail explicitly when no feasible GPU placement exists; optional GPU preference can fall back to CPU.

Independent DAG nodes execute concurrently unless deterministic ordering is requested.

## 6. Automatic solver and tolerance tuning

`AutomaticSolverToleranceTuner` maintains an exponentially weighted history of:

- accepted/rejected steps;
- maximum normalized integration error;
- stiffness indicator;
- execution time.

The first interval preserves the canonical hybrid supervisor's own stiffness discovery. Subsequent intervals use measured stiffness to bias the solver toward Dormand-Prince, Rosenbrock-W, BDF2, or Radau IIA. Tolerances are relaxed only within configured accuracy ceilings when error/rejection behavior is comfortably below the target and tightened when rejection/error pressure rises.

## 7. Incremental execution and checkpoint branching

The runtime reuses `CowStateStore` and `SimulationForkEngine`. A checkpoint compares current flattened domain state with its parent and writes only changed scalars into the child branch. Untouched pages remain shared.

`checkpoint()` creates a state-bearing child from the active or supplied parent. In addition to the COW physics state, the runtime records the checkpoint's execution-policy state: per-domain synchronization frontier/statistics plus the dynamic-fidelity and solver/tolerance controller histories. `branch_from()` creates a zero-change counterfactual branch sharing the parent pages and inheriting that execution snapshot. `restore()` restores both physical and execution-policy state using `RuntimeCheckpointInfo::time_s` as the authoritative branch time.

`set_domain_state()` allows an intentional counterfactual mutation before continuing simulation. When a restored domain is materially changed through this API, the runtime invalidates that domain's learned fidelity and solver/tolerance history and returns those controllers to their configured initial policy. This prevents adaptation learned on the parent trajectory from being incorrectly reused across a discontinuous state change while leaving unmodified checkpoint replay deterministic with respect to stored policy state.

`RuntimeCheckpointInfo` reports parent lineage, authoritative checkpoint time, shared pages, private bytes, and logical bytes. Root-derived branches use the same metadata time rather than relying on an implementation-specific fork-engine root timestamp.

## 8. Batched/ensemble execution

The unified runtime exposes the established SoA RK4 ensemble executor through `run_ensemble()`. Ensemble member state is stored dimension-major for SIMD-friendly access. Existing deterministic reductions and heterogeneous affine acceleration remain available.

The ensemble run is recorded by the integrated profiler and is recognized by the optimization advisor as a batching/vectorization opportunity.

## 9. Zero-copy/SoA/memory-arena runtime

`AlignedMemoryArena` provides bounded aligned bump allocation for persistent double state. Domain state is placed once in this arena. `ConstStateSlice` provides zero-copy cross-domain observation at synchronization boundaries and `MutableStateSlice` provides controlled local storage access.

The arena never reallocates, so state addresses remain stable throughout runtime execution. Bounds and alignment are validated, capacity exhaustion raises `std::bad_alloc`, and all domain initial/mutated state must be finite.

The existing `BatchedStateSoA` remains the canonical SoA authority for ensemble state.

## 10. Integrated performance profiler and optimization advisor

Every domain integration and ensemble execution records categorized work in `IntegratedPerformanceProfiler`. Aggregation reports wall time, share of profiled work, sample count, work items, and bytes touched.

`OptimizationAdvisor` uses measured runtime evidence rather than fixed marketing claims. It reports prioritized recommendations when it detects conditions such as:

- a dominant runtime hotspot;
- low dirty-state cache reuse;
- excessive rejected integration steps;
- unstable fidelity switching;
- a large vectorizable ensemble;
- poor COW checkpoint sharing;
- failure to meet the configured realtime target.

Estimated speedup intervals are advisory and bounded; they do not alter simulation state.

## 11. Minimal usage example

```cpp
using namespace aesim::advanced::runtime;

SimulationOptimizationRuntime runtime;

MultiRateDomainConfig engine;
engine.id = "engine";
engine.initial_state = {1.0};
engine.synchronization_period_s = 1.0e-3;
engine.maximum_internal_step_s = 2.5e-4;
engine.fidelity_levels = {
    {"full",    1.0e-4, 1.0, 0.5},
    {"reduced", 5.0e-3, 0.35, 1.0}
};
engine.rhs = [](double, const StateVector& x,
                const CoupledStateView& coupled,
                const DomainStepContext& context) {
    (void)coupled;
    (void)context;
    return StateVector{-x[0]};
};

runtime.add_domain(std::move(engine));
auto result = runtime.run(0.0, 1.0);
if (!result.converged)
    throw std::runtime_error(result.diagnostic);

std::cout << runtime.optimization_report();
```

## 12. Correctness and determinism notes

- Deterministic task ordering is available through `SimulationOptimizationConfig::deterministic_task_order`.
- Hardware placement changes execution location, not physics semantics.
- Fidelity substitution is constrained by configured/model-provided error envelopes.
- Checkpoint branches use the established copy-on-write state authority rather than copying an independent runtime model; adaptive fidelity and solver/tolerance policy state is checkpointed alongside the physics state.
- Explicit counterfactual domain mutation invalidates only that domain's learned adaptive policy before continuation.
- A synchronization interval may end with a terminal step shorter than the configured ordinary minimum step; the hybrid supervisor constrains the nested solver consistently so this endpoint condition does not create an invalid `maximum_step < minimum_step` request.
- Derived dependency calculations remain lazy and deterministic for deterministic node functions.
- The profiler/advisor is observational: it cannot silently change model parameters or physics.

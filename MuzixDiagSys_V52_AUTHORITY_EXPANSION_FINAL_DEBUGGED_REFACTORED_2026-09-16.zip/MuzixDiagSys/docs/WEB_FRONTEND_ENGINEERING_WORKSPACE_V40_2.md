# MuzixDiagSys V40.2 Web Engineering Workspace Foundation

**Current-status note (2026-09-09):** This document remains the authoritative historical record for the V40.2 engineering workspace tranche. The current browser workstation is **V46**. V46 preserves these behaviors and adds structured schema-driven renderers, typed engineering-object drag/drop, transaction/autosave/recovery/deep-link infrastructure, integrated preflight/evidence/comparison/timeline/snapshot workflows, native V45 engine/transmission/four-corner views, and native research-grade analysis workbenches. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105 for current operation and qualification. Release-specific assertions in this document should not be read as a complete V46 feature inventory.

> **Historical V40.3 integration note (2026-08-29):** This document describes the retained V40.2 workspace foundation. The V40.3 operations/investigation workbenches and Signal Explorer selection repair are documented in [`WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md`](WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md); current V46 behavior is documented in `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105.


## Scope

V40.2 improves integration between existing browser workbenches while preserving the native `BrowserEngineeringServer`, the four canonical HTTP endpoints, and the existing command dispatcher. No feature-specific HTTP endpoint, JavaScript framework, CDN, or duplicate simulation state store is introduced.

## Global engineering search

Use **Ctrl/Cmd+Shift+K** or **?** when focus is not in an editor. The omnibox searches the registered workbench schema, browser-discovered telemetry signal names, recent canonical commands, and curated navigation/export actions. Keyboard Up/Down changes the active result, Enter executes it, and Escape closes the overlay. Workbench results call the existing desktop open command; command results stage text in the canonical command console rather than bypassing authorization.

## Shared engineering context

The browser context now includes:

- selected object kind/id/source and metadata;
- the existing primary/A/B linked cursors;
- a bounded selected-signal set;
- an optional normalized time range;
- the current presentation-unit profile.

Context updates are distributed to participating panes through `_context`, `_cursor`, `_range`, and `_units` callbacks and browser events. Backend cursor mutation remains routed through `ui linked-cursor`.

## Telemetry interactions

The telemetry scope retains bounded browser telemetry and canonical out-of-core LOD commands while adding synchronized interactions:

- click: set linked cursor A;
- Shift-click: set linked cursor B;
- Shift-drag: brush and publish a shared time range;
- drag: pan;
- mouse wheel: zoom;
- signal pills: publish the selected signal set;
- Shared Context range: drives participating telemetry panes.

Plot samples remain canonical. Unit conversion affects labels and displayed values only.

## Engineering display units

Three profiles are available from Shared Engineering Context:

- **Canonical** — show values in the simulator's native unit vocabulary;
- **Metric engineering** — normalized engineering glyphs/labels while retaining metric scales;
- **US motorsport** — operator presentation conversions including psi, °F, mph, lb-ft, hp, lbf, ft, and lb/h where a canonical mapping is known.

Conversions are affine presentation transforms. They never rewrite `/api/state`, `/api/stream`, command parameters, telemetry CSV values, model state, or persisted simulation data. Unknown units remain unchanged.

## Signal Explorer

The Signal Explorer now has a responsive two-pane browser view. The left pane filters discovered live signals and shows current presentation values and bounded sample counts. The right pane exposes current/canonical values and routes authoritative metadata/history requests through the existing `ui signal-explorer` commands. Signals can be added to the watchlist or opened in the telemetry scope without creating a duplicate signal registry.

## Run Manager browser

The Experiment / Run Manager now renders canonical `ui run-manager list` output as a searchable two-pane run browser. Selecting a run publishes the shared run context and retrieves full authoritative details through `ui run-manager inspect`. Lifecycle changes, annotations, creation, and removal still execute through role-aware canonical commands. Discovered run IDs are added to the global engineering search index for rapid navigation.

## Analysis Presets

Named browser Analysis Presets are stored in local browser storage. A preset captures the display-unit profile, watchlist, selected signals, selected context, linked cursor values, optional shared time range, and an active-workbench hint. Export produces a JSON copy for inspection. Restore reuses canonical linked-cursor and desktop commands for backend-affecting operations.

Presets deliberately do **not** serialize or overwrite authoritative simulation state, experiments, calibration maps, or backend workspace persistence. The existing desktop save/load commands remain the authority for native layout persistence.

## Validation expectations

The release gate for this tranche includes JavaScript syntax validation, the engineering UI source regression, native compilation of the modified UI and test translation units, the served-page browser unit test where feasible, and archive integrity verification.

# MuzixDiagSys Advanced Vehicle Realism Systems

This module extends the existing coupled longitudinal plant without removing or bypassing any legacy model. It is available through the existing `industrial vehicle` command namespace and publishes all measurements through the shared industrial signal registry.

## Exact command surface

```text
industrial vehicle sixdof status
industrial vehicle sixdof reset [speed_m_s]
industrial vehicle sixdof step <seconds> [drive_torque_nm] [brake_fraction] [steering_fraction]
industrial vehicle suspension status
industrial vehicle tires status
industrial vehicle driveline status

industrial vehicle opendrive load <file.xodr>
industrial vehicle opencrg load <file.crg>
industrial vehicle opencrg sample <u_m> <v_m>
industrial vehicle openscenario load <file.xosc>
industrial vehicle openscenario step <seconds>
industrial vehicle openscenario run <duration_s> <step_s>

industrial vehicle ecu status
industrial vehicle ecu reset
industrial vehicle ecu load <background_cpu_fraction>
industrial vehicle ecu step <seconds>
industrial vehicle ecu task <name> <period_us> <deadline_us> <wcet_us> <priority> [offset_us]

industrial vehicle degradation status
industrial vehicle degradation reset
industrial vehicle degradation service <all|engine|transmission|suspension|tires|brakes|catalyst|sensors>
industrial vehicle degradation step <dt_s> <speed_m_s> <load> <oil_C> <coolant_C> <tire_kW> <brake_kW> <clutch_kW> <catalyst_C>

industrial vehicle bayes load <experiments.csv>
industrial vehicle bayes run [burn_in] [draws] [seed]
industrial vehicle bayes export <result.json>
industrial vehicle bayes status
```

## XCP/A2L and MDF

All advanced measurements use the existing typed signal registry. Therefore no parallel calibration protocol is required.

```text
industrial xcp a2l advanced_vehicle.a2l AESIM_ADVANCED_VEHICLE
industrial xcp start 127.0.0.1 5555
industrial mdf start advanced_vehicle.mf4 0.001 vehicle6dof.roll_rad vehicle6dof.corner0.tire_surface_c
industrial mdf stop
industrial mdf validate advanced_vehicle.mf4
```

## Physical model

The body integrates longitudinal, lateral, vertical, roll, pitch, and yaw states. Each corner has sprung and unsprung motion, asymmetric bump/rebound damping, nonlinear bump stops, tire vertical compliance, camber gain, toe compliance, and wheel-contact detection.

The tire model combines longitudinal slip and lateral slip angle through a bounded friction envelope. It includes relaxation lengths, load sensitivity, temperature-dependent friction, surface/carcass thermal states, energy dissipation, and progressive tread wear.

The driveline includes input inertia, propshaft stiffness/damping, backlash, halfshaft compliance, and selectable open, locked, viscous, clutch-LSD, Torsen, or active differential behavior.

## OpenCRG input

MuzixDiagSys accepts a bounded rectangular OpenCRG-style grid. Required keys are `u_start`, `u_end`, `u_increment`, `v_start`, `v_end`, and `v_increment`, followed by `$DATA`. The number of height values must exactly match the calculated grid dimensions. Invalid extents, unsafe dimensions, non-finite values, or mismatched data counts are rejected.

## Multi-experiment Bayesian calibration

CSV columns:

```text
experiment,metric,input,observation,sigma,weight
```

Supported metrics include `torque`, `zero_to_hundred_s`, `road_load_n`, `fuel_l_100km`, and `top_speed_kmh`. The sampler estimates mass scale, torque scale, road-load scale, and driveline efficiency with bounded priors and reports posterior means, standard deviations, 95% credible intervals, acceptance rate, and posterior-predictive RMSE.

## Progressive degradation

Damage accumulation is driven by operating hours, distance, thermal stress, engine load, tire slip power, brake power, clutch dissipation, and catalyst temperature. Component-specific service operations reset only the repaired component; unrelated wear remains intact.


# Perception, ODD, Digital-Twin, and Real-World Measurement Extension

The second-stage vehicle-realism layer is integrated into the same `VehiclePlatform`, OSI ground truth, typed signal registry, XCP address space, A2L generator, MDF recorder, OpenDRIVE/OpenCRG road model, OpenSCENARIO runtime, ECU scheduler, and degradation model. It is not a parallel demonstration path.

## Physical steering and suspension kinematics

```text
industrial vehicle steering status
industrial vehicle steering reset
industrial vehicle steering step <seconds> [command_-1..1]
```

The steering model resolves steering-wheel and column inertia, torsional column compliance, EPS assist, rack mass, viscous damping, Coulomb-like rack friction, caster-trail/self-aligning feedback, Ackermann inner/outer road-wheel angles, and lateral-force compliance steer. Existing suspension travel continues to drive corner camber and toe kinematics. The following XCP/A2L/MDF signals are available:

```text
vehicle6dof.steering.wheel_angle_rad
vehicle6dof.steering.left_wheel_angle_rad
vehicle6dof.steering.right_wheel_angle_rad
vehicle6dof.steering.rack_m
vehicle6dof.steering.driver_torque_nm
vehicle6dof.steering.eps_torque_nm
vehicle6dof.steering.aligning_torque_nm
```

Writable calibrations include `vehicle6dof.cal.steering_ratio`, `vehicle6dof.cal.steering_bias_rad`, and `vehicle6dof.cal.eps_peak_assist_nm`.

## Five-dimensional aerodynamic coefficient maps

```text
industrial vehicle aero status
industrial vehicle aero reset
industrial vehicle aero load <map.csv>
industrial vehicle aero export <map.csv>
industrial vehicle aero sample <speed_m_s> <yaw_rad> <pitch_rad> <front_ride_m> <rear_ride_m>
```

The complete Cartesian map uses speed, relative-airflow yaw, body pitch, front ride height, and rear ride height as axes. Every point contains `Cd`, `Cy`, front/rear lift coefficients, yaw/pitch moment coefficients, and a cooling-flow factor. Import requires a finite and complete grid with no duplicate points. Export uses round-trip-safe floating-point precision.

CSV columns:

```text
speed_m_s,yaw_rad,pitch_rad,front_ride_height_m,rear_ride_height_m,cd,cy,cl_front,cl_rear,cm_yaw,cm_pitch,cooling
```

## OpenMATERIAL profile

```text
industrial vehicle openmaterial status
industrial vehicle openmaterial load <profile.yaml|profile.json>
industrial vehicle openmaterial assign-road <road-id> <material-id>
industrial vehicle openmaterial assign-object <classification> <material-id>
industrial vehicle openmaterial export <profile.json>
industrial vehicle openmaterial reset
```

MuzixDiagSys implements a bounded OpenMATERIAL-derived engineering profile. Each material specifies dry/wet friction, rolling resistance, roughness, camera reflectance, lidar reflectivity, radar reflectivity, ultrasonic reflectivity, infrared emissivity, thermal conductivity, water retention, and brake-dust retention. Material assignments influence tire-road friction, rolling resistance, sensor detection probability, and particulate resuspension. The supplied example is `data/vehicle_openmaterial.json`.

## Camera, radar, lidar, and ultrasonic models

```text
industrial vehicle perception status
industrial vehicle perception defaults [seed]
industrial vehicle perception reset [seed]
industrial vehicle perception add <camera|radar|lidar|ultrasonic> <name> <x_m> <y_m> <z_m> <yaw_deg> <hfov_deg> <range_m> <rate_hz> <latency_ms>
industrial vehicle perception step <seconds> [visibility_m] [rain_0..1]
industrial vehicle perception export <frame.json>
```

Each sensor has independent mounting, field of view, range, sample rate, latency, range/angle/radial-velocity noise, dropout probability, and false-positive rate. Detections are derived from OSI ground truth and are affected by material response, visibility, precipitation, field-of-view clipping, range, occlusion, latency, and seeded noise. Controllers and fusion consume delivered sensor frames rather than perfect ground truth.

## OSI and OSMP

The existing OSI 3.x ground-truth envelope remains the authoritative world exchange. The sensor layer adds a CRC-protected, length-bounded OSMP SensorData engineering profile:

```text
industrial vehicle osmp status
industrial vehicle osmp export <sensor_data.osmp>
industrial vehicle osmp import <sensor_data.osmp>
```

The binary envelope includes magic, profile version, payload length, CRC-32, and a structured SensorData payload. Invalid magic, unsupported versions, oversized payloads, truncated data, and CRC mismatches are rejected.

## OpenODD-driven scenario generation

```text
industrial vehicle openodd status
industrial vehicle openodd load <odd.yaml|odd.json>
industrial vehicle openodd generate <output-directory> <count> [seed]
```

Numeric dimensions are stratified into coverage bins; categorical dimensions are selected deterministically from the supplied seed. Boundary cases are explicitly generated before interior samples. The generator calculates one-dimensional and pairwise coverage, emits executable OpenSCENARIO files, and writes a manifest containing sampled ODD parameters, boundary flags, friction, and precipitation.

## Sensor fusion and localization

```text
industrial vehicle localization status
industrial vehicle localization reset
industrial vehicle localization gnss <x_m> <y_m> <sigma_m>
industrial vehicle localization wheel <speed_m_s> <sigma_m_s>
industrial vehicle localization heading <yaw_rad> <sigma_rad>
```

The localization estimator predicts pose and velocity using body accelerations and yaw rate, then performs uncertainty-weighted GNSS, wheel-speed, and heading corrections. Delivered sensor detections are converted into persistent fused tracks with velocity, confidence, age, contributing-sensor count, and stale-track removal.

## Digital-twin estimation

```text
industrial vehicle digital-twin status
industrial vehicle digital-twin reset
industrial vehicle digital-twin load <measurements.csv>
industrial vehicle digital-twin apply
industrial vehicle digital-twin restore
industrial vehicle digital-twin export <estimate.json>
```

Online and offline observations estimate bounded mass, aerodynamic, tire-friction, steering-bias, and longitudinal-velocity corrections. Application is transactional and idempotent: original calibration values are retained and `restore` returns only the modified calibrations to their prior values. The estimator reports observation count and position, velocity, and yaw RMSE.

Measurement CSV columns:

```text
time_s,x_m,y_m,yaw_rad,speed_m_s,sigma
```

## Brake, tire, and road-dust particulate emissions

```text
industrial vehicle particulate status
industrial vehicle particulate reset
industrial vehicle particulate export <nonexhaust.csv>
```

Brake PM10/PM2.5 depends on friction-brake power, regenerative share, pad degradation, rotor temperature, speed-dependent cooling, and wet suppression. Tire PM depends on combined-slip dissipation, normal load, material roughness, tread degradation, and precipitation. Road-dust resuspension depends on speed, axle loading, roughness, and surface wetness. Tailpipe and non-exhaust particulate streams remain separate.

## Virtual PEMS

```text
industrial vehicle pems status
industrial vehicle pems configure <period_s> <line_delay_s> <analyzer_tau_s> <gps_latency_s> <noise_sigma> <flow_uncertainty> [seed]
industrial vehicle pems zero
industrial vehicle pems span [reference]
industrial vehicle pems start
industrial vehicle pems stop
industrial vehicle pems reset
industrial vehicle pems export <measurements.csv>
```

The virtual portable emissions measurement system models sample-line transport delay, first-order analyzer response, sample period, GPS latency, seeded relative noise, zero drift, span drift, exhaust-flow uncertainty, zero calibration, and span calibration. It records exhaust CO2, CO, HC, NOx, PM, exhaust flow, speed, position, and measurement timestamp. Brake/tire particulate emissions are not incorrectly added to the exhaust sample line.

## XCP/A2L and MDF workflow

```text
industrial xcp a2l perception_vehicle.a2l AESIM_PERCEPTION_VEHICLE
industrial mdf start perception_vehicle.mf4 0.01 \
  vehicle6dof.steering.wheel_angle_rad \
  vehicle6dof.aero.cd \
  vehicle6dof.perception.radar_detections \
  vehicle6dof.localization.position_std_m \
  vehicle6dof.twin.mass_scale \
  emissions.nonexhaust.brake_pm10_g_s \
  emissions.pems.nox_g_s
step 10
industrial mdf stop
industrial mdf validate perception_vehicle.mf4
```

The same signals are available through live XCP measurement access. Writable steering, aero, sensor-noise, PEMS-noise, suspension, tire, driveline, mass, and ECU-load calibrations appear in A2L as calibration objects.

## Numerical and safety limits

- All integration steps, map values, material values, sensor definitions, uncertainties, emission rates, and calibrations reject non-finite input.
- Sensor and OSMP payloads are bounded; OSMP data is CRC checked.
- Aerodynamic grids must be complete Cartesian products.
- OpenODD dimension names must be unique, numeric bounds must be ordered, and categorical dimensions must be nonempty.
- PEMS rates and timestamps must be nonnegative.
- Calibration application is bounded by the signal registry and can be restored.
- Seeded stochastic models are deterministic for a fixed seed and identical command sequence.

## 2026-07-12 next-generation vehicle-depth integration

The realism stack now includes flexible structures, spatial terrain, structural tire failures, switching electrical dynamics, aero-thermal flow, detailed hydraulics, and causal replay.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


## V47 Tire, Traction & Precision Performance Dynamics

V47 extends the canonical flexible-ring tire and P1-P4 Performance Reality Platform for launch/straight-line correlation.

### Tire dynamics

The `FlexibleRingTire` now resolves rim and belt rotational states coupled by configurable carcass torsional stiffness/damping. Contact-patch circumferential speed uses the belt state, so driveline torque can wind the carcass before the belt/contact patch reaches the same speed. The torsional damper contributes heat to the existing tread/carcass thermal model.

Pure longitudinal/lateral tire force uses bounded nonlinear force-shaping on top of the existing relaxed slip/bristle states. A generalized p-norm (`combined_slip_exponent`) limits simultaneous longitudinal/lateral demand to the current friction capacity. The same pure-longitudinal law is scanned deterministically to obtain the instantaneous force-peak slip target used by TC.

### Pressure and temperature

A tire-gas state has its own heat capacity and carcass heat-transfer coefficient. Pressure evolves from reference pressure, gas absolute temperature and loaded internal volume. Current pressure modifies stiffness, friction sensitivity and hydroplaning speed. This state is fully additive to existing tread/carcass temperature and wear states.

### Dynamic load coupling

Straight-line acceleration uses the established `MultibodySuspensionSystem` for four-corner normal loads. Per-corner longitudinal tire forces and aerodynamic loads therefore feed chassis pitch/heave and return physically varying FL/FR/RL/RR vertical loads to the tire solves.

### Track-state coupling

The straight-line surface description seeds the existing `TrackStatePhysicsAssimilator`; it does not own evolving grip. Baseline μ, preparation, rubber, moisture, surface temperature and spatial grip/grade profiles are scenario inputs. Current effective surface μ and temperature are recorded in the performance trace.

### Longitudinal force balance and rotating inertia

The detailed acceleration solve accounts for tractive force, aerodynamic drag based on air-relative velocity, rolling resistance, grade force and reflected rotating inertia. Upstream inertia is mapped through current gear/final-drive ratios; tire wheel/belt inertia comes from the canonical tire configuration. The solver records the force-balance residual for numerical auditing.

### Timing and research analysis

`PerformanceEventDetector` performs continuous speed/distance crossings. Drag timing distinguishes stage clear, rollout, incremental ETs, finite-distance trap speed and instantaneous finish speed. Calibration, sensitivity, convergence and Monte Carlo all call the same detailed solver.


## V47.1 tire rotational-energy and carcass corrections

The flexible-ring tire owns rim and belt rotational inertia. Straight-line acceleration therefore reflects only upstream powertrain/driveline inertia into equivalent translational mass; wheel and belt inertia must not be counted again. Radial ring modal mass is derived from belt inertia. Carcass torsional deformation is an integrated relative-rotation state and is not reconstructed from independently wrapped rim/belt angles. Pressure-sensitive compliance follows the evolving sealed-gas pressure state during substeps, and rolling-resistance heat is referenced to belt/contact-patch rotational speed.

The configured pure-longitudinal law's dimensionless force-peak coordinate is precomputed once and transformed by the current stiffness/force scale to obtain optimal slip. This removes repeated transcendental scans from high-rate tire integration without introducing a second tire law.


V47.1 event-detector note: the first `update()` sample initializes the detector without a false crossing when callers choose implicit initialization; explicit `reset()` semantics remain unchanged.

# Research Authority R1-R7

**Release date:** 2026-08-28  
**Status:** implemented and integrated  
**Public C++ header:** `include/aesim/advanced/research_authority_platform.hpp`  
**Aggregate include:** `include/aesim/advanced/platform.hpp`

The Research Authority adds an ordered scientific-research stack to MuzixDiagSys without replacing existing specialized authorities. Where a mature implementation already existed, the Research Authority delegates to it and records that reuse in its capability manifest. This prevents divergent duplicate implementations of core Bayesian, contact, conservation, code-verification, and PMU functionality.

## Ordered implementation

| Tranche | Implemented capabilities |
|---|---|
| **R1 — Scientific Credibility** | Formal V&V credibility authority; explicit code/solution verification; Bayesian model comparison; posterior predictive checking; simulation-based calibration; prior predictive validation. |
| **R2 — Inference Laboratory** | 4D-Var; hybrid EnVar; profile-likelihood identifiability; Hessian/Fisher diagnostics; Bayesian information-gain experiment design; model-discrimination testing. |
| **R3 — Numerical Research Authority** | Probabilistic numerics; adaptive solver portfolio with stiffness switching; linear DAE index reduction; goal-oriented error estimation; energy-momentum integration; nonsmooth contact; Parareal time-parallel integration. |
| **R4 — Co-Simulation and Multi-Fidelity** | Conservative energy accounting; passivity observation/control; adaptive co-simulation step negotiation; multi-level Monte Carlo; autoregressive co-kriging/multi-fidelity Gaussian process. |
| **R5 — Laboratory Metrology** | ISO/IEC 17025-style instrument authorization; correlated GUM uncertainty propagation; crossed-ANOVA Gage R&R/MSA; integrity-protected digital calibration certificates; measurement-traceability graph verification. |
| **R6 — Research Reproducibility** | RO-Crate 1.1 research objects; W3C PROV-style JSON-LD provenance; dataset/model cards; SHA-256 immutable closed-world run manifests; Citation File Format metadata; complete reproducibility bundles. |
| **R7 — HPC Science** | Existing hardware PMU authority integration; Roofline analysis; Welch/Student-t and bootstrap performance-regression gates; in-situ field publication/downsampling; bounded audited computational steering; time-parallel production scheduling. |

## Canonical authority reuse

The capability manifest explicitly records these non-duplication boundaries:

- Bayesian model comparison → `BayesianMultimodelInference`.
- Code verification → `core::math_assurance` convergence/manufactured-solution evidence.
- Conservative energy accounting → `assured::ConservationGovernor`.
- Nonsmooth contact → `NonsmoothComplementarityContactSolver`.
- Hardware performance counters → `app::CpuMicroarchitecturePmuProfiler`.

The new classes add research workflow, diagnostics, uncertainty, decision logic, or adapters around those canonical engines rather than creating replacement engines.

## CLI discovery

Build the advanced platform and inspect the exact R1-R7 manifest:

```bash
cmake -S . -B build/research -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/research --target muzixdiagsys_advanced_platform research_authority_platform_tests -j4
./build/research/muzixdiagsys_advanced_platform research-authority capabilities
```

The same manifest is embedded under `research_authority` in the general command:

```bash
./build/research/muzixdiagsys_advanced_platform capabilities
```

The dedicated research APIs are typed C++ APIs rather than a generic JSON execution façade. This preserves dimensions, callbacks, covariance matrices, propagators, likelihood functions, and numerical operators as strongly typed contracts.

## Focused qualification

Run the dedicated end-to-end unit target:

```bash
./build/research/research_authority_platform_tests ./build/research/research_authority_bundle_test
```

The test exercises every requested R1-R7 capability, including negative integrity checks for digital calibration certificate tampering and for both mutated and unmanifested files in reproducibility bundles.

## Research integrity notes

### R1 credibility decisions

`FormalVVCredibilityAuthority` combines the preexisting simulation-quality qualification contract with code/solution verification, multimodel Bayesian evidence, posterior predictive checks, simulation-based calibration, prior predictive plausibility, and measured validation. A result is marked defensible only when mandatory scientific checks pass and the lower-confidence credibility score exceeds the authority threshold.

### R2 inference

The variational solvers support user-provided transition and observation operators, full observation/background covariance matrices, finite-difference derivatives, bounded optimization, posterior curvature, ensemble/static covariance hybridization, and likelihood-profile confidence regions. Experiment design maximizes sequential log-determinant information gain under a budget.

### R3 numerical authority

The adaptive portfolio estimates stiffness from the state Jacobian and switches among Dormand-Prince 5(4), Rosenbrock-Euler, and implicit trapezoid integration. The DAE reducer partitions differential/algebraic variables and performs algebraic elimination with an explicit failure verdict for a singular algebraic block. Goal-oriented error uses residual-adjoint contributions to rank refinement. Parareal provides a deterministic time-slice correction history and can use OpenMP when enabled by the build.

### R4 coupling and multi-fidelity

Passivity control maintains an energy tank at the coupling boundary. Step negotiation responds to participant-local normalized error and rollback capability. The conservation adapter retains the existing project-wide `ConservationGovernor` as the authority. MLMC allocates samples from pilot variances and costs; co-kriging uses an autoregressive low/high-fidelity relationship with a discrepancy GP.

### R5 metrology

Instrument authorization checks calibration validity, environment, traceability, resolution, and reference uncertainty. GUM propagation accepts correlated input quantities and rejects nonsymmetric, out-of-range, or non-positive-semidefinite correlation matrices. Digital calibration certificates are content-hashed and fail verification after payload mutation. Traceability verification detects graph cycles and evaluates the uncertainty accumulated through the reference chain.

### R6 reproducibility

A bundle contains copied research artifacts, `provenance.jsonld`, research cards, `CITATION.cff`, `run_metadata.json`, RO-Crate metadata, and an immutable SHA-256 manifest. Verification is closed-world: changing a listed file, deleting one, modifying the manifest, or adding an unmanifested payload invalidates the bundle.

### R7 HPC science

Raw hardware-counter collection remains the responsibility of the existing Linux PMU profiler. The Research Authority consumes counter observations for Roofline analysis, performance statistics, and production decisions. Performance gates combine relative/practical effect thresholds, Welch inference, and deterministic bootstrap confidence intervals rather than relying on a single timing comparison.

## Intended use

These authorities provide evidence and scientific decision support; they do not make a simulation automatically valid for certification or physical release. Credibility depends on the supplied model, validation data, instrument traceability, operating domain, numerical tolerances, priors, likelihoods, and experimental design.

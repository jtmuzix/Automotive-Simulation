# Global UI Architecture

The global UI architecture is an additive frontend-neutral layer for MuzixDiagSys. It preserves the complete legacy terminal, command registry, aliases, dashboards, preferences, and scripts while allowing every engineering domain to contribute UI metadata without editing the central console frontend.

## Public API

```cpp
#include "aesim/app/global_ui_architecture.hpp"

sim::console::globalui::GlobalUiArchitecture ui;
```

The implementation is compiled into `aesim_console_support` and is available to the production terminal, optional future desktop/web clients, plugins, and tests.

## Modular domain providers

`UiDomainProvider` supplies commands, workflows, dashboards, contextual actions, and issues. `ProviderRegistry` is thread-safe and prevents duplicate provider IDs. Domain-specific metadata can therefore reside with the domain rather than in `console_frontend.cpp`.

## Context graph, Explorer, Inspector, and deep links

`ContextGraph` stores typed objects, properties, metrics, capabilities, children, and relationships. Objects use stable addresses such as:

```text
muzix://project/ev-validation
muzix://vehicle/main
muzix://ecu/bms
muzix://run/thermal-018
```

The same graph drives the Project Explorer, persistent Inspector, adaptive home screen, workspace suggestions, search, dashboards, comparisons, and accessibility narration.

## Forms

`RichForm` and `RichParameterMetadata` support text, integer, real, Boolean, enumeration, multi-select, path, directory, timestamp, duration, frequency, quantity, vector, matrix, range, object/artifact references, expressions, tables, structured objects, and secret values.

The built-in unit registry performs dimension-safe conversions for temperature, pressure, time, frequency, voltage, current, power, energy, length, and speed. Fields support visibility, enablement, conditional required state, dependencies, conflicts, validation, provenance, and canonical command generation.

## Workflows and jobs

`WorkflowEngine` executes directed graphs with action, form, validation, decision, parallel, approval, wait, review, artifact, subworkflow, and checkpoint nodes. It also records canonical command sequences into reusable graphs.

`JobManager` tracks queued, running, paused, blocked, completed, failed, and cancelled operations, including progress, priority, resource estimates, child jobs, artifacts, and logs.

## Workspace restoration

`WorkspacePersistence` stores schema-versioned tabs, split views, selection, expanded Explorer nodes, Inspector section, active form/workflow, search, filters, dashboard time window, and scroll state. String fields are escaped so reserved delimiters, backslashes, and embedded newlines round-trip exactly. Older supported schemas are migrated to the current version rather than discarded; files declaring a newer schema are rejected explicitly instead of being silently coerced. The loader accepts LF and CRLF line endings, validates numeric and structural fields before conversion, and returns diagnostics for malformed records rather than leaking conversion exceptions.

## Dashboards and linked selection

`DashboardEngine` provides a 12-column layout system with numeric, status, gauge, sparkline, time-series, histogram, distribution, heatmap, matrix, table, progress, state machine, timeline, map, graph, flow, Pareto, confidence, coverage, issue, artifact, note, and action widgets. Widgets can cross-filter one another through linked selection and provide compact representations for narrow terminals.

## Activity, comparison, preview, state operations

The architecture includes:

- A bounded engineering activity timeline.
- Global object comparison.
- Dependency-aware impact-analysis reports.
- Field-safe selective undo.
- Three-way branch/configuration merge with explicit conflicts.
- Stable evidence and artifact references.

## Rendering, scale, and accessibility

`CellSpanRenderer` emits minimal changed spans instead of repainting whole rows. `VirtualizedRecordStore` pages and filters large histories without formatting all records. `UiPerformanceMonitor` records frame/input latency, dirty spans, index size, record count, update rate, and throttling. `AccessibilityNarrator` supports minimal, standard, detailed, and diagnostic narration.

## Compatibility

The architecture does not remove or rename any legacy command, alias, dashboard, workspace, preference, project, checkpoint, replay, or artifact format. Existing `ExperienceManager` behavior remains available. The new layer is additive and can be introduced progressively by domain providers.

## V16 graphical engineering desktop integration

The V16 browser frontend is a direct-manipulation projection of the canonical UI architecture rather than a separate workspace, simulation, or workflow implementation. `SchemaDrivenEngineeringDesktop` remains authoritative for recursive docking and tab/window state; browser dock activation, reordering, movement, splitting, ratios, and floating-window geometry are committed through the normal serialized command path. `SemanticCliService`, `UiAccessPolicy`, `TelemetryWorkbench`, `EngineeringDigitalTwinViewport3D`, `InteractiveCalibrationCorrelationWorkbench`, `LiveEeCosimulationTopologyCanvas`, `VisualScenarioEventTimelineComposer`, `WorkflowGraphEditor`, `WorkflowExecutionDebugger`, and `NWayRunComparisonWorkbench` likewise remain the authoritative model owners for their graphical projections.

Structured read models added for V16 are deliberately narrow: semantic-analysis JSON, calibration-map JSON, workflow-graph/debug-state JSON, and track/lap JSON. They expose existing state without cloning domain logic into JavaScript. Browser mutations are submitted through `/api/command`, live telemetry through `/api/stream`, and desktop/schema state through `/api/schema`. See `ENGINEERING_UI_PLATFORM.md` for the graphical interaction contract and exact commands.


## V20.1.2 unified engineering workspace integration

The Unified Engineering Workspace is an orchestration layer over existing authoritative services, not a replacement architecture. `EngineeringUiSuite` binds the schema-driven desktop, structured search, telemetry, synchronized time cursor, experiment matrix, mission control, regression triage, solver health, flight recorder, run comparison, dashboard designer, TUI layout manager, diagnostic center, causal-difference evidence explorer, and CLI/GUI equivalence registry.

The source-of-truth rules are:

- **Commands:** the canonical console command dispatcher and access policy remain authoritative. Browser controls call `/api/command` with the same `ui ...` commands used by the TUI.
- **Telemetry:** `TelemetryWorkbench` owns samples; Signal Explorer adds metadata/search over those samples rather than copying histories.
- **Runs:** `ExperimentMatrix` owns run records; Run Manager adds provenance, notes, artifacts, state transitions, and persistence to that same matrix.
- **Dashboards:** `DashboardDesigner` owns composed layouts and now persists them atomically.
- **Time travel:** `Backend::capture_ui_state()` / `restore_ui_state()` provide restorable simulator state; `SynchronizedTimeCursor` provides analytical cursor/event/bookmark semantics.
- **Diagnostics:** Mission Control, Regression Triage, Solver Health, and Flight Recorder remain evidence sources; Diagnostics / Fault Investigation Center correlates and explains them.
- **Causal differences:** `NWayRunComparisonWorkbench` supplies aligned run data; the new explorer traverses declared dependencies and divergence evidence without claiming unsupported causality.
- **TUI rendering:** existing dashboard/output/watch renderers are laid out and focused by `TuiPaneLayoutManager`; they are not reimplemented.
- **GUI equivalence:** `CliGuiEquivalenceRegistry` exposes auditable UI-action-to-command mappings, while execution remains centralized.

This arrangement prevents the terminal, browser, and automation interfaces from acquiring independent behavioral implementations as the simulator grows.


## V20.1.2 research-grade workbench integration

The 28 research-grade workbenches follow the same architectural boundary as the Unified Engineering Workspace: `EngineeringUiSuite` owns presentation/analysis state; authoritative simulator services remain authoritative; the schema-driven desktop registers each workbench once; the browser reads the schema and submits canonical commands through `/api/command`; the terminal submits identical commands through `handle_ui_command`/`handle_engineering_ui_command`.

No feature-specific browser mutation API was added. The only browser control endpoint is still `/api/command`. Plugin management and schema migration are particularly strict examples: browser actions are literally `plugin list|load|unload` and `config check-version|migrate|diff|upgrade-all`, so the UI cannot accumulate a conflicting backend implementation.

Derived workbenches reuse canonical state: run lineage reads `ExperimentMatrix.parent_id`; dependency heatmaps read `CausalDifferenceExplorer` edges; failure clustering reads `RegressionTriageDashboard`; performance investigation reads `RuntimeProfiler`, `SolverConvergenceConsole`, and distributed trace; cross-run divergence reads Run Manager, N-way Run Comparison, and Causal Difference state; digital-twin measurement reads `EngineeringDigitalTwinViewport3D`; alert rules raise `EngineeringMissionControl` alerts.

## V20.1.2 integrated terminal inspector and cockpit projections

The terminal enhancements remain projections over the global architecture rather than new domain owners. The lower-pane views reuse `JobManager`, `ContextGraph`, `NavigationContext`, Mission Control alerts, `ExperimentMatrix`, `RuntimeProfiler`, `SynchronizedTimeCursor`, `EngineeringFlightRecorder`, and `CausalDifferenceExplorer`. `ExperienceManager` remains the owner of UI state undo/redo and contextual documentation.

Live subsystem navigation is generated inside `EngineeringUiSuite::update_live_signals()`: each canonical signal remains a `signal://...` context object, subsystem nodes group those same objects, and `vehicle://live` is the stable hierarchy root. Search documents point back to those objects and canonical `ui navigator ...` commands. This means Project Explorer, inline Inspector, global search, browser schema surfaces, and terminal navigation refer to the same object identities.

The tabbed lower pane is presentation state only. `activity` continues to own scrollback/search/bookmark behavior; `events`, `timeline`, `jobs`, `notifications`, `experiments`, `profiler`, `navigator`, and `causal` render reports from authoritative services into the same pane. The selected view is persisted as UI preference/project layout metadata and does not alter simulation state.

Public renderer additions have matching interactive-shell routes: telemetry sparkline (`ui sparkline`), time-travel control (`ui time-travel`), track map (`ui track-map`), pit wall (`ui pit-wall`), friction circle (`ui friction-circle`), runtime profiler dashboard (`ui performance-profiler`), and uncertainty projection (`ui uncertainty-view`). Backend parameter discovery is exposed through `ui parameter-inspector`; canonical help/context/signal documentation is exposed through `ui doc-inspect`. This preserves the project rule that backend capabilities intended for operators are reachable from the authenticated InteractiveShell.

## V40.3 browser investigation integration

The V40.3 browser tranche strengthens integration without changing source-of-truth ownership. Live Operations, advanced run/causal comparison, fault investigation, Solver/HPC health, and provenance/time-travel state inspection are adapters over the existing canonical models. Shared Engineering Context carries selected run/object/signal, primary/A/B cursors, selected range, and presentation units between these workbenches.

Signal discovery follows the same ownership rule: `TelemetryWorkbench`/Signal Explorer metadata is authoritative through `ui signal-explorer list`; browser stream frames provide bounded live values only. The browser catalog is therefore usable before streaming begins, and live refresh never owns or recreates the signal registry. Browser selection is a presentation-context value retained at application scope, so it survives workbench redraws; canonical inspection results are generation-guarded so stale asynchronous responses cannot supersede the current selection.

## V46 schema-driven interaction and workflow composition

V46 extends the frontend-neutral architecture with presentation metadata rather than adding a competing UI authority. `WorkbenchSchema` may now advertise three optional fields:

- `renderer`: the browser-native renderer family to use for a workbench;
- `accepts`: typed engineering objects that can be dropped into that workbench;
- `produces`: typed engineering objects/evidence that the workbench can expose to other views.

Existing registrations remain valid because these fields have compatibility-preserving defaults. The browser consumes the metadata after `/api/schema` retrieval; the backend still owns command validity, state transitions, persistence, telemetry, numerical analysis and simulation physics.

### Typed engineering objects

V46 transfers small references rather than copied model state. A transferable object contains a type, stable ID, display label/URI, bounded metadata and optional simulation time. Current workbenches use types such as `signal`, `run`, `parameter`, `event`, `requirement`, `artifact`, `checkpoint`, `snapshot`, `configuration`, `schema`, `estimator`, `latency-path`, `source-location` and `evidence`. A drop target accepts only the types declared by its schema; incompatible drops are visibly rejected.

This establishes one interaction language across telemetry, diagnostics, calibration, qualification, provenance and research tools. It does **not** create a second object database. Selecting or dropping an object updates shared engineering context or asks an existing canonical authority to inspect/compare it.

### Structured renderer vocabulary

The browser uses reusable cards, KPI panels, engineering tables, line plots, matrix/heatmap projections and report panels. These renderers only transform already-returned canonical state/results into visual form. Examples include Bode data from `ui control-stability`, spectrogram bins from the C++ `TimeFrequencySpectrogramWorkbench`, identifiability/correlation reports from `ui identifiability`, and latency budgets from `ui latency-budget`.

### Persistence, recovery and deep links

The V46 interaction layer distinguishes presentation state from canonical simulator state:

1. browser preferences and a bounded workstation snapshot are journaled in browser local storage;
2. the canonical desktop is periodically persisted through `ui desktop save`;
3. the existing persistent-session registry is used for complete-session recovery when available;
4. recovery can restore browser state only or reattach the simulator session and then restore the desktop;
5. deep links encode workbench, engineering selection, selected signals, primary/A/B cursors, selected time range and workspace in the URL fragment.

Authentication credentials are never written into the deep-link fragment. The bearer token remains a session credential handled by the established browser authentication path.

### Transaction and workflow composition

The global transaction bar presents `ui command-stage` state, autosave state and current engineering selection. Its Commit/Clear actions call the canonical staging authority. V46 integrated workflow workbenches similarly aggregate existing services instead of moving logic into JavaScript: preflight calls availability/model-validity/solver/fidelity/qualification/campaign authorities; comparison dispatches to run/configuration/checkpoint/snapshot/schema/signal inspectors; the multilane timeline projects canonical time/SOE/checkpoint information; and Snapshot Diff operates on captured client metadata while full state restoration remains a backend operation.

### Compatibility rule

A V46 browser feature is valid only when it satisfies all of the following:

- the backend remains the engineering source of truth;
- executable mutations pass through `/api/command` and normal authorization/semantic checks;
- the browser introduces no duplicate solver, estimator, protocol decoder, FFT, calibration optimizer, persistence database or provenance engine;
- existing terminal and API workflows remain usable without the browser;
- typed drag/drop and deep links carry references/context, not shadow state.

See `ENGINEERING_UI_PLATFORM.md` for the complete workbench/operator contract and `MUZIXDIAGSYS_USER_MANUAL.md` Chapter 105 for end-user procedures.

## V47 tire/traction/performance composition

V47 demonstrates the same frontend-neutral authority rule as V46. `tire-traction-lab` and `acceleration-performance-lab` are schema-registered views over one C++ performance authority. The browser supplies configuration and renders returned structured state; it does not own a tire model, track-state field, launch controller, event detector, Monte Carlo engine or calibration optimizer.

The dependency direction is:

```text
browser workbench
  -> authenticated /api/command
  -> canonical ui command dispatcher
  -> PerformanceRealityPlatform
     -> EngineDynoCalibrationLab
     -> TransmissionAuthoritySystem
     -> MultibodySuspensionSystem
     -> FlexibleRingTire[4]
     -> TrackStatePhysicsAssimilator
     -> PerformanceEventDetector
```

The V47 `StraightLineSurfaceConfiguration` is scenario/configuration state. Evolving rubber/water/temperature/grip remains owned by `TrackStatePhysicsAssimilator`. Likewise, the performance trace is a returned analysis artifact; it is not a second telemetry repository.

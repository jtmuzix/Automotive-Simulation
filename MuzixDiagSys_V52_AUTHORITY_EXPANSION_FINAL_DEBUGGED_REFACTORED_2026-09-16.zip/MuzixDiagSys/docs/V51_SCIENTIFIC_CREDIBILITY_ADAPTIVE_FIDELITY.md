# V51 Scientific Credibility & Adaptive Fidelity

**Release:** V51  
**Date:** 2026-09-13  
**Canonical integrated authority:** `aesim::advanced::V51RealityAuthority`  
**Native executable:** `muzixdiagsys_v51_reality`  
**Python client:** `muzixdiag.v51`

V51 is an additive scientific-credibility release. It does not replace the V50 engine, tire, aftertreatment, SOTIF, MLOps, checkpoint, CAE, validation, scientific-data, or heterogeneous-compute authorities. V51 composes those canonical systems and adds the missing verification, fidelity-control, high-order transport, chemistry/spray, calibration, persistent-service, and governance logic required to make the V50 Integrated Reality model suitable for reproducible research campaigns.

## Authority ownership and non-duplication

The canonical V50 coupled plant remains `V50RealityAuthority`. V51-B extends its existing reactive-cylinder authority in place with selectable transport and conservative grid adaptation. V51-C uses the existing `ExternalCaeSolverFederation` for external solver execution. V51-D delegates measured-dataset scoring to `core::ValidationFramework`. V51-E uses `checkpoint::Store` for durable evidence images while retaining exact in-process authority snapshots for branch/restore. V51-F uses the existing `PortableHeterogeneousKernelRuntime`. V51-G delegates scientific arrays to `NativeScientificDataInterchangePlatform`. V51-I wraps `VehicleCloudMlopsPlatform` instead of creating a second deployment system.

## V51-A — verification and validation composition

`V51VerificationAuthority` performs manufactured-solution verification for one-dimensional periodic advection-diffusion using the same first-order/MUSCL reconstruction families exposed by V50. The manufactured field is advanced with SSP-RK2 and evaluated on a spatial refinement sequence and a temporal refinement sequence. It reports L1/L2/L∞ errors, observed spatial and temporal order, conserved-mass error, normalized V50 chamber mass/energy residuals when a live state is supplied, pass/fail diagnostics, and a SHA-256 evidence digest.

Observed order between successive resolutions is calculated from the error ratio and resolution ratio. The default V51 qualification requires second-order behavior within practical limiter tolerances for MUSCL transport and bounded normalized conservation residuals. `validate_measured_dataset(...)` and `validate_measured_csv(...)` route experimental records through the canonical `core::ValidationFramework`; no separate validation mathematics is maintained in V51.

## V51-B — adaptive spatial resolution and higher-order transport

`ReactiveCylinder3DConfiguration` now exposes `ReactiveTransportScheme::{FirstOrderUpwind, MusclMinmod, MusclVanLeer}` and adaptive-grid controls. MUSCL face reconstruction uses bounded slope limiting; scalar states remain bounded and species mass fractions are normalized after chemistry/transport updates.

Adaptive resolution uses the existing structured chamber authority. A normalized multi-field indicator measures temperature, fuel, progress-variable, and velocity gradients. At configured adaptation intervals the grid is refined or coarsened within explicit min/max bounds. `conservative_regrid(...)` trilinearly transfers the resolved field and then applies global conservative correction for total mass, species mass, and sensible/internal energy. The authority records active grid dimensions, adaptation indicator, refinement/coarsening counts, and the selected transport scheme in state/evidence.

The V50 defaults remain first-order and non-adaptive for backward compatibility. V51 fidelity control changes the numerical fidelity of the same authority at runtime; it does not instantiate a replacement cylinder solver.

## V51-C — detailed chemistry, Lagrangian spray, and external CFD federation

`V51DetailedChemistryAuthority` accepts an arbitrary documented species/reaction mechanism and ships with a mass-balanced gasoline-surrogate mechanism. Reaction rates use Arrhenius kinetics. The stiff source system is advanced with adaptive implicit backward Euler, numerical Jacobian construction, Newton iteration, positivity-preserving line search, temperature bounds, and automatic chemistry substepping. State includes species mass fractions, temperature, pressure, heat release, substeps/Newton iterations, residual norm, convergence status, and evidence.

`V51SprayAuthority` provides deterministic Lagrangian parcels with injection mass accounting, relative-flow drag, D-squared evaporation, Weber-number breakup, turbulent dispersion, wall interception/deposition, parcel culling, evaporated/deposited/remaining mass, and an explicit mass residual. Randomness is owned by a seeded authority and therefore remains reproducible.

`V51CfdReferenceFederation` is a high-fidelity provider around the canonical `ExternalCaeSolverFederation`. It passes solver, working-directory, timeout, and residual-acceptance configuration through the existing real OpenFOAM/SU2/other CAE execution layer and returns the canonical execution evidence. V51 does not emulate an external CFD solve when the requested solver is unavailable.

## V51-D — hierarchical Bayesian calibration and measured validation

`V51HierarchicalBayesianCalibrator` performs multi-chain posterior inference for bounded physical parameters, per-group random effects, and positive model-discrepancy scale. Physical-parameter proposals use bounded Metropolis-Hastings updates; hierarchical group effects and discrepancy state are updated conditionally/random-walk as appropriate. The result reports posterior mean/SD/2.5%/median/97.5% intervals, Gelman-Rubin R-hat, lag-aware effective sample size, group-bias posterior means, discrepancy scale, chain acceptance, convergence diagnostics, and evidence.

Posterior-mean predictions are converted into a canonical validation dataset and evaluated by `core::ValidationFramework`, producing the same residual statistics and requirements used by the rest of MuzixDiagSys. This creates one calibration-to-validation chain rather than a second V51-specific metrology implementation.

## V51-E — automatic multi-fidelity promotion and checkpointing

`V51FidelityController` implements four levels: F0 V50 reference, F1 high-order/adaptive, F2 detailed chemistry/spray, and F3 external CFD reference. Promotion scores use normalized conservation residuals, spatial-gradient indicator, and relative SOTIF credible-interval width. Demotion uses hysteresis and a minimum transition interval to prevent fidelity thrashing. Every decision records reasons and evidence.

`V51CheckpointManager` captures exact in-process `V51RealityAuthority` state for lossless branch/restore and simultaneously creates a canonical `checkpoint::Image` through `checkpoint::Store`. Saved checkpoint artifacts therefore retain the platform's integrity metadata while active persistent sessions can restore the complete authority object, including stochastic streams and history-dependent state.

## V51-F — scalable ensemble execution

`V51EnsembleExecutor` runs independent canonical V50 members with deterministic index ordering. Backends include serial, bounded threaded CPU, SIMD-batch reduction, OpenMP, and Kokkos. Host-side authority objects remain host objects; canonical OpenMP/Kokkos kernels perform deterministic aggregate reductions. When MuzixDiagSys is built with a CUDA/HIP/SYCL-backed Kokkos execution space, those reductions execute on the selected accelerator without duplicating vehicle physics in device-only code.

Results contain each member's signed state evidence and ensemble mean/standard-deviation metrics for brake torque, tailpipe emissions, tire grip, and SOTIF risk.

## V51-G — persistent service and scientific field store

`muzixdiagsys_v51_reality serve` is a line-delimited JSON service. A single native process can execute `configure`, `run`, `status`, `verify`, `checkpoint`, `restore`, `save-checkpoint`, `field-store`, `capabilities`, and `quit` requests. Errors are returned per request and do not terminate the service. This removes process-launch overhead from Bayesian/UQ/DOE campaigns while keeping all numerical work in C++.

`V51ScientificFieldStore` writes ordered chamber density/temperature/pressure/species/progress/velocity arrays and all spatial-tire tread/temperature/contact/water/wear/grip arrays through `NativeScientificDataInterchangePlatform`. Zarr works in the baseline build; HDF5/NetCDF remain available when those canonical optional backends are compiled. `roundtrip` mode reads the stored dataset and performs value/shape/unit/name identity verification.

The Python `V51RealityClient` retains a one-shot process-isolated mode and adds `V51PersistentSession`, which uses `subprocess.Popen` to keep the canonical native service alive. Python validates JSON finiteness and never reimplements simulation equations.

## V51-H — Integrated Reality Workbench

The existing engineering-workbench registry now includes `integrated-reality-v51` (`muzix://ui/integrated-reality-v51`). It composes canonical field visualization, numerical-trust, time/timeline, and evidence-browser actions around `backend v51-reality ...`. This makes V51 discoverable in the existing workstation without adding a competing UI framework.

The workbench is intended for synchronized inspection of chamber fields, numerical verification, fidelity decisions, catalyst/tire/navigation state inherited from V50, SOTIF governance, learning governance, checkpoint evidence, and scientific-field artifacts.

## V51-I — SOTIF and continual-learning governance

`V51SotifGovernanceAuthority` conditions the V50 Bayesian exposure risk on weighted ODD context factors for weather, lighting, traffic, and sensor contamination. It reports context-attributed risk, correlated posterior mean and upper credible risk, epistemic fraction, escalation decision, and evidence.

`V51ContinualLearningGovernor` composes the canonical `VehicleCloudMlopsPlatform`. Challenger observations are gated by conformal-coverage and OOD-fraction thresholds in addition to the existing accuracy, safety-violation, drift, and stage rules. A canonical continual-learning freeze/rollback or a failed external uncertainty gate forces governed rollback; successful promotion requires both the canonical learning authority and deployment gates to pass.

## V51-J — release and documentation artifact certification

`configs/current_release_manifest.json` is the machine-readable current-release authority. `tests/v51_release_artifact_certification.py` requires the README, documentation index, Markdown manual, and generated PDF manual to agree on V51, release date, title, and Chapter 110. The certification also verifies that the PDF contains V51/Chapter 110 and that no newer Markdown chapter is omitted from the distributed PDF.

This closes the V50 gap in which Markdown could contain a newer chapter while the packaged PDF and documentation index remained at an older release.

## Native use

```bash
cmake -S . -B build/v51 -G Ninja -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=ON -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build/v51 --target v51_scientific_reality_tests muzixdiagsys_v51_reality --parallel
./build/v51/muzixdiagsys_v51_reality self-test
./build/v51/muzixdiagsys_v51_reality capabilities
./build/v51/muzixdiagsys_v51_reality run examples/v51_reality_request.json
./build/v51/muzixdiagsys_v51_reality verify examples/v51_reality_request.json
./build/v51/muzixdiagsys_v51_reality serve
```

## Python persistent campaign

```python
from muzixdiag.v51 import V51RealityClient, default_request

client = V51RealityClient("./build/v51/muzixdiagsys_v51_reality")
request = default_request()
with client.session() as session:
    session.configure(request)
    result = session.run(request)
    session.checkpoint("baseline")
    # Run a branch, then restore exact native authority state.
    session.run({**request, "steps": 100})
    session.restore("baseline")
    session.store_fields("results/v51-fields.zarr", format="zarr")
```

## Focused qualification

```bash
./build/v51/v51_scientific_reality_tests ./build/v51/v51-test-data
PYTHONPATH=python python3 tests/v51_python_api_tests.py . ./build/v51/muzixdiagsys_v51_reality
python3 tests/v51_scientific_reality_source_regression.py .
python3 tests/v51_release_artifact_certification.py . ./build/v51/muzixdiagsys_v51_reality
ctest --test-dir build/v51 -R 'v51_|v50_' --output-on-failure
python3 tests/source_package_regression.py .
python3 tests/duplicate_implementation_regression.py .
python3 tests/consolidation_architecture_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```

## Interpretation limits

Passing V51 numerical verification shows that the implemented reference equations converge and satisfy the configured conservation tolerances; it does not establish physical truth for a particular engine, tire, sensor, or ODD. Detailed chemistry is a generic stiff finite-rate mechanism authority, not a claim that the shipped surrogate is a validated fuel mechanism for every fuel. External CFD validity remains dependent on mesh, boundary conditions, solver configuration, experimental correlation, and the external solver itself. Bayesian posteriors are conditional on the supplied likelihood/model hierarchy and data. Safety/SOTIF and continual-learning results are engineering evidence, not legal homologation or an autonomous-driving safety case by themselves.

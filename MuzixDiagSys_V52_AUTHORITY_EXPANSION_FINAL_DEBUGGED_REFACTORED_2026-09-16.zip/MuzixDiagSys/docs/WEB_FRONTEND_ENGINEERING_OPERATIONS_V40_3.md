# MuzixDiagSys V40.3 Browser Engineering Operations and Investigation Workbenches

**Current-status note (2026-09-09):** This document remains the authoritative historical record for the V40.3 engineering operations tranche. The current browser workstation is **V46**. V46 preserves these behaviors and adds structured schema-driven renderers, typed engineering-object drag/drop, transaction/autosave/recovery/deep-link infrastructure, integrated preflight/evidence/comparison/timeline/snapshot workflows, native V45 engine/transmission/four-corner views, and native research-grade analysis workbenches. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105 for current operation and qualification. Release-specific assertions in this document should not be read as a complete V46 feature inventory.

**Release:** V40.3  
**Documentation revision:** 2026-08-29

V40.3 upgrades five existing browser workbenches in place and repairs Signal Explorer selection. It does **not** create a second simulator state model, a second run database, a second diagnostics authority, or feature-specific mutation endpoints. The browser continues to use only the authenticated `BrowserEngineeringServer` projections `/api/state`, `/api/schema`, `/api/stream`, and `/api/command`; engineering actions dispatch the same canonical commands used by the terminal UI.

## 1. Live Operations Center

Open **Live Operations Center** from the Workbench Library or use the existing Live Operations shortcut (`Ctrl/Cmd+Shift+O`). The center combines bounded live telemetry with authoritative mission, diagnostic, profiler, and solver status.

Capabilities:

- connection, stream-age, dropped-frame, simulation-time, solver-acceptance, CPU, and GPU health indicators;
- unit-aware live KPI cards with canonical-value disclosure and bounded sparklines;
- signal selection propagated through Shared Engineering Context;
- direct navigation to Signal Explorer, Diagnostics / Fault Investigation, and Solver / HPC Health;
- canonical run, pause, and deterministic-step actions;
- dashboard-reference baseline capture, `what-changed`, and SOE first-out investigation;
- authoritative evidence panes populated through canonical commands rather than browser-owned state.

Primary canonical authorities include `ui mission-control status`, `ui diagnostic-center status`, `ui soe first-out`, `ui profiler json`, `ui solver-console json`, `ui what-changed`, and the established simulation loop/step commands.

## 2. Advanced Run Comparison + Causal Difference Analysis

The existing `run-comparison-studio` workbench is upgraded rather than duplicated. It retains N-way run overlays, baseline selection, statistics, live capture, and envelopes, then adds causal divergence ranking and configuration-difference inspection.

Capabilities:

- N-way selected-channel overlay with linked primary-cursor navigation;
- baseline/candidate selection over the authoritative `NWayRunComparisonWorkbench`;
- per-run bias, MAE, RMSE, maximum deviation, and correlation already supplied by the canonical run-comparison projection;
- causal divergence ranking from `ui causal-difference divergences`;
- earliest-divergence navigation into Shared Engineering Context;
- canonical causal explanation for a selected divergence;
- run metadata, parameter, objective, and tag differences using `ui run-manager inspect` when canonical Run Manager records exist;
- dependency graph from `ui causal-difference graph`;
- retained live capture and statistical-envelope functions.

The browser does not infer a new causal model. Causal explanations remain bounded by the declared dependency graph and temporal evidence maintained by the existing backend authority.

## 3. Diagnostics / Fault Investigation Center

The existing `diagnostic-center` ID is preserved and upgraded into an investigation-oriented workbench. It aggregates diagnostic references and gives each reference an evidence path.

Capabilities:

- searchable alert, solver, regression, and flight-recorder evidence references;
- detail explanation using `ui diagnostic-center explain`;
- role-aware acknowledgment and clearing of mission alerts;
- SOE first-out, alarm-flood/chatter, transient-lens, `what-changed`, and incident-workspace investigations;
- canonical causal graph visualization and node selection;
- time-bearing diagnostic evidence can drive the shared linked cursor and time-travel inspector;
- direct navigation to the event timeline and Provenance + Time-Travel State Inspector.

The workbench preserves the distinction between observed evidence, diagnostic references, causal hypotheses, and operator actions. Clearing or acknowledging an alert still passes through canonical command access policy.

## 4. Solver / HPC Health Dashboard

The existing `solver-observability` workbench is upgraded into a combined numerical and compute-health view.

Capabilities:

- authoritative profiler and solver JSON refresh;
- process CPU, system CPU, resident memory, GPU utilization, GPU memory, solver step size, residual, condition estimate, local error, conservation error, and iteration KPIs;
- threshold-aware health styling from `ui solver-console thresholds`;
- bounded performance sparklines derived from authoritative profiler samples;
- accepted/rejected solver-step status and worst-residual evidence;
- root-cause investigation through the existing performance investigator;
- HPC placement/topology details through `ui hpc-placement json`;
- direct navigation to the retained hardware-topology workbench;
- role-aware capture of an additional solver sample.

No browser-side scheduler, profiler, or numerical solver is introduced.

## 5. Provenance + Time-Travel State Inspector

The existing `time-travel` workbench now combines authoritative time controls with bounded state inspection and provenance lookup.

Capabilities:

- previous/next event, play, pause, follow-live, checkpoint, restore, and bookmarks through the existing `ui time ...` authority;
- primary/A/B linked-cursor controls;
- nearest buffered browser-stream state snapshot at the selected engineering time;
- selected-signal prioritization and A/B state deltas;
- linked signal selection across workbenches;
- metric provenance through `ui provenance-graph inspect`;
- object evidence through `ui object-inspector inspect`;
- signal metadata/history through Signal Explorer authority;
- flight-recorder evidence for the selected signal.

The nearest buffered browser snapshot is clearly identified as a bounded presentation cache. Restorable simulator state is still owned by the backend checkpoint/restore authority.

## 6. Signal Explorer selection repair

V40.2 primarily populated the browser Signal Explorer from signal names discovered in the live stream. In an idle or not-yet-streaming session, the canonical signal registry could therefore exist while the browser list was empty or effectively nonselectable. In addition, rebuilding the list during streaming updates could replace row DOM while the operator was interacting with it.

V40.3 corrects this architecture:

1. `ui signal-explorer list` loads the authoritative signal catalog.
2. The browser stores catalog metadata separately from bounded live values.
3. The visible list is the union of canonical catalog signals and any additional stream-discovered names.
4. Rows are focusable buttons with `role="option"` and `aria-selected` state.
5. The selected signal is stored in persistent application state rather than only inside one render closure, so a schema/workbench redraw cannot erase the selection.
6. Pointer-down commits the row selection synchronously before any canonical inspection request; Click, Enter, and Space then activate inspection.
7. Stream refresh updates visible values/sample counts **without rebuilding the selectable row list**.
8. Inspection requests carry a generation guard, so a delayed response for a previously selected signal cannot overwrite the current detail pane.
9. Canonical search results enrich the same catalog rather than constructing a second registry.
10. Signal selection publishes to Shared Engineering Context and can immediately open Scope, provenance, object-inspection, metadata, or history views.

The toolbar also exposes the current `selected <signal>` state explicitly. This repair makes Signal Explorer usable before the first telemetry sample and keeps selection stable across stream updates, schema/workbench reconstruction, and asynchronous inspection races.

## 7. Cross-workbench integration

All five V40.3 workbenches reuse V40.2 shared context and presentation infrastructure:

- primary/A/B linked cursors;
- selected time range;
- selected signals;
- selected run/object context;
- named analysis presets;
- canonical/Metric Engineering/US Motorsport presentation-unit profiles;
- global engineering omnibox;
- existing docking/workspace persistence.

A typical failure-investigation workflow is:

1. Observe an anomaly in **Live Operations Center**.
2. Open **Diagnostics / Fault Investigation Center** and inspect first-out/correlated evidence.
3. Send the event time to the linked cursor and open **Provenance + Time-Travel State Inspector**.
4. Select the implicated signal and inspect provenance/history in **Signal Explorer**.
5. If a baseline/candidate pair exists, open **Advanced Run Comparison + Causal Difference Analysis** to locate the first meaningful divergence and inspect declared upstream dependencies.
6. Use **Solver / HPC Health Dashboard** to determine whether numerical or compute-health degradation coincides with the physical event.

## 8. Security and authority boundaries

V40.3 does not weaken the established browser security model:

- loopback binding remains the default;
- bearer-token authentication remains required;
- restrictive CSP remains in force;
- mutating operations pass through canonical semantic/access checks;
- display-unit conversions remain presentation-only;
- browser analysis caches are bounded and nonauthoritative;
- canonical exports, run records, diagnostic evidence, solver records, and checkpoints remain backend owned.

## 9. Validation

Release-specific validation evidence is recorded in `WEB_FRONTEND_V40_3_VALIDATION.md`. The engineering UI source regression additionally guards against returning to stream-only Signal Explorer discovery or replacing selection rows on each stream refresh.

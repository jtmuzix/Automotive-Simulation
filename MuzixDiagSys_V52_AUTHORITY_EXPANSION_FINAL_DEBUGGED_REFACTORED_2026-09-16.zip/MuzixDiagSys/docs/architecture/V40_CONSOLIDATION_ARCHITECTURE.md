# V40 Feature-Preserving Consolidation Architecture

## Objective

V40 reduces architectural sprawl while preserving the complete V39 behavior and capability surface. The consolidation deliberately prefers canonical shared authorities, modular build ownership, and evidence organization over aggressive file merging. Scientific alternatives that are intentionally independent remain independent.

## Changes

### Modular CMake ownership

The former monolithic root `CMakeLists.txt` is now a thin policy/coordinator file. Exact target/source declarations were extracted without changing target membership into:

- `cmake/targets/CoreEngineeringTargets.cmake`
- `cmake/targets/MotorsportTargets.cmake`
- `cmake/targets/ResearchAuthorityTargets.cmake`
- `cmake/targets/ApplicationIntegrationTargets.cmake`
- `cmake/Testing.cmake`

Static source regressions inspect the complete logical CMake corpus through `tests/cmake_test_support.py`; they no longer depend on a monolithic physical file.

### Canonical scalar contracts

`include/aesim/core/input_contract.hpp` owns the common finite/positive/nonnegative/unit-interval validation and simple scalar helpers used by advanced domains. Specialized validators with materially different diagnostics or semantics remain local.

### Canonical document digests

`include/aesim/professional/document_digest.hpp` provides SHA-256 over canonical document JSON. Local wrappers now delegate to this authority. The IndyCar-local OpenSSL digest implementation was removed in favor of `core::Sha256`, reducing crypto implementation surface.

### Canonical UTC formatting

Subsystem-local UTC formatting helpers now delegate to `aesim/core/time.hpp`. Public compatibility functions remain where they are part of the API, but their implementation uses the canonical core authority.

### Historical evidence organization

Historical implementation and validation evidence formerly stored in the repository root is retained under `docs/history/root_archive/`. `docs/history/README.md` indexes the archive. Active operator files remain at the root, so default paths such as `fault_campaign.yaml` and `safety_limits.csv` are unchanged.

## Preservation rules

V40 does not merge distinct numerical algorithms merely because they solve a related problem. Independent solvers, verification formulations, CPU/GPU backends, and series-specific physical/rule behavior remain distinct when their semantics differ.

The `consolidation_architecture_regression` prevents the root CMake monolith and root evidence sprawl from returning, verifies canonical helper ownership, rejects a return of the IndyCar-local crypto implementation, and requires the deterministic source package manifest to cover every active source artifact.

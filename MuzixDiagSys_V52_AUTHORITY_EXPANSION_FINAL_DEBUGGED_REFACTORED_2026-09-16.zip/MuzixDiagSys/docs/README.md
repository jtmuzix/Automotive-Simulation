# MuzixDiagSys Documentation

**Current documentation revision:** 2026-09-10 - V47 Tire, Traction & Precision Performance Dynamics, retaining the V46 Integrated Engineering Workstation and completion-popup PTY hardening. V46 adds the schema-driven interaction foundation, integrated investigation/comparison/timeline workflow, V45 powertrain/vehicle visualization workbenches, and native research-grade protocol/control/spectral/identifiability/estimator/latency/schema/numerical/source-trace views while preserving canonical backend authorities. Earlier V40.3, V38-V33, NHRA, MotoGP, engine, and transmission references remain part of the current documentation set.

The authoritative operating manual is [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md). The PDF is generated from that Markdown source; edit the Markdown first and regenerate the PDF with `../tools/generate_user_manual_pdf.sh`.

## Start here

- [Comprehensive User Manual](MUZIXDIAGSYS_USER_MANUAL.md) - installation, terminal operation, engineering workflows, complete command reference, testing, troubleshooting, glossary, integrated platform chapters through V47, including NHRA/MotoGP authorities, V40.3 browser operations, V40.5/V45 engine depth, Transmission E-I, the V46 integrated browser workstation, and V47 tire/traction/precision-performance dynamics.
- [Comprehensive User Manual PDF](MUZIXDIAGSYS_USER_MANUAL.pdf) - release rendering of the same authoritative manual.
- [Tutorial and Exact Command Guide](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) - practical beginner-to-advanced workflows, including V33-V38 qualification workflows plus V40.3/V40.4/V40.5, Transmission E-I, the V46 integrated browser workflow, and the V47 tire/traction/performance workflow.
- [Documentation Index](DOCUMENTATION_INDEX.md) - authoritative/current references versus dated historical implementation and validation records.
- [Real-World TUI Usage Guide](REAL_WORLD_TUI_USAGE_GUIDE.md) - terminal-oriented operator workflows.

## Current V47 tire / traction / performance reference

- [Advanced Vehicle Realism](ADVANCED_VEHICLE_REALISM.md) - canonical V47 tire, traction, track/surface, launch, precision timing, calibration, uncertainty and convergence behavior.
- [Engineering UI Platform](ENGINEERING_UI_PLATFORM.md) - `tire-traction-lab` and `acceleration-performance-lab`, schema integration, structured JSON and browser authority boundaries.
- [Advanced API CLI Commands](ADVANCED_API_CLI_COMMANDS.md) - exact `ui tire-traction` / `ui acceleration-performance` command grammar and key/value options.
- [Comprehensive User Manual](MUZIXDIAGSYS_USER_MANUAL.md) Chapter 106 - complete end-user V47 reference.
- [Tutorial and Exact Command Guide](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) Section 45 - repeatable V47 workflows and qualification.

## Current V33-V38 platform references

- [V38 Advanced Automotive Electronics & Compute Authority](AUTOMOTIVE_ELECTRONICS_COMPUTE_AUTHORITY_V38.md) - additive ECU silicon/board, in-vehicle-network, body/access, centralized-compute, reliability/EMC/harness, OTA, and startup authority with finite-input boundary hardening.
- [V37 ECU / Diagnostics / SocketCAN Authority Platform](ECU_DIAGNOSTICS_SOCKETCAN_AUTHORITY_V37.md) - additive UDS/DCM/DEM, regulatory OBD, Linux SocketCAN, ODX/PDX/OTX, XCP/A2L, semantic-registry, and trace-interchange authority.
- [V36 Professional Authority Platform](PROFESSIONAL_AUTHORITY_PLATFORM_V36.md) - twenty additive authority families spanning tyres/dampers/suspension, telemetry, track/brake/driveline physics, DIL, WEC/IMSA/rally/Formula E operations, electrification aging/NVH, HIL/EtherCAT/XIL, model validity/sensitivity/CAE qualification, regulation diff, SINDy, and thermophysical backends.
- [V35 Motorsport Expansion Platform](MOTORSPORT_V35_PLATFORM.md) - WEC/IMSA endurance, BoP, rally, Formula E, driver digital twin, spatial track state, racecraft physics, hierarchical strategy, lap-time attribution/coaching, and GT3/GT4 customer racing.
- [V34 Native Qualification Platform](NATIVE_QUALIFICATION_PLATFORM.md) - sanitizers, configuration interactions, reproducible-build forensics, binary bloat, RNG lineage, resource ownership, process lifecycle, static analysis, fault localization, and compiler/optimization differential qualification.
- [V33 Generalized Engineering Operations Platform](GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md) - concurrency interleavings, hermetic I/O, persistence fault laboratory, compatibility governance, adaptive test execution, native coverage, build-cost profiling, architecture fitness, soak qualification, and unified fuzz corpus/triage.
- [Motorsport CLI Command Reference](MOTORSPORT_CLI_COMMANDS.md) - established F1/IndyCar/NASCAR/NHRA convenience routing plus the separate V35 qualification executable.
- [Advanced API CLI Commands](ADVANCED_API_CLI_COMMANDS.md) - advanced JSON command registry and the boundary between that registry and isolated V33-V36 qualification tools.

## Major current engineering references

- [Engineering Intelligence Platform](ENGINEERING_INTELLIGENCE_PLATFORM.md) - 20-domain reference covering consequence/causality, zonal E/E and geometric harness routing, software service graphs and actuator arbitration, timebase/AoI, conservation, identifiability, provenance, reproducibility, requirement budgets, workshop ADAS calibration, embedded-resource/concurrency degradation, fluid/charging-connector condition, scientific hypothesis planning, and HPC novelty control.
- [Global Mathematical Assurance](GLOBAL_MATHEMATICAL_ASSURANCE.md) - automatic error budgets, adaptive precision, exact reductions, convergence/MMS, derivative/KKT certification, consensus, property testing, and sealed evidence.
- [CTest Runtime-Artifact Fixture](CTEST_ARTIFACT_FIXTURE.md) - direct CTest build dependency closure, compiled-test fixture semantics, and missing-executable cascade prevention.
- [Global UI Architecture](GLOBAL_UI_ARCHITECTURE.md) - modular providers, context graph, rich forms, graph workflows, jobs, linked dashboards, persistence, virtualization, rendering, and accessibility.
- [Engineering UI Platform](ENGINEERING_UI_PLATFORM.md) - authoritative terminal/browser architecture through V47, including schema-driven renderers, typed object transfer, autosave/recovery, deep links, integrated workflow centers, domain laboratories, and native research workbenches.
- [V40.3 Browser Engineering Operations](WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md) - retained V40.3 baseline for Live Operations, causal run comparison, fault investigation, Solver/HPC, provenance/time-travel, and Signal Explorer selection behavior; V46 extensions are documented in `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105.
- [V40.3 Web Frontend Validation](WEB_FRONTEND_V40_3_VALIDATION.md) - release-specific source, native served-page, browser-interaction, documentation, and package validation evidence.

## NHRA and MotoGP A-J authority references

- [NHRA Deep Race Physics and Operations Authority](NHRA_DEEP_RACE_PHYSICS_OPERATIONS_AUTHORITY.md) - Phases A-J, shared run kernel, nitro subsystem, telemetry/calibration, Pro Stock/PSM/Top Alcohol, four-wide, rules/scrutineering/event operations.
- [MotoGP Engineering and Research Authority](MOTOGP_ENGINEERING_RESEARCH_AUTHORITY.md) - Phases A-J, motorcycle/tire/powertrain/control/aero/rider/circuit/telemetry/safety physics and 2027 research laboratory.
- [Comprehensive User Manual](MUZIXDIAGSYS_USER_MANUAL.md) - Chapters 99-100 integrate the new authorities with the complete build, CLI, numerical-safety, and qualification workflows.
- [Tutorial and Exact Command Guide](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) - workflows 38-39 provide focused build, self-test, and engineering examples.

## Documentation maintenance

Run the documentation gates after editing current guidance:

```bash
python3 tests/user_manual_regression.py .
python3 tests/documentation_consistency_regression.py .
./tools/generate_user_manual_pdf.sh
```

Then validate deterministic source packaging:

```bash
python3 tests/source_package_regression.py . build/doc-package-regression
```

Root-level dated `*_IMPLEMENTATION_REPORT_*.md`, `*_VALIDATION_*.txt`, and debug/refactor records are historical evidence. Do not rewrite them to describe later releases; current guidance belongs in the manual, tutorial, platform references, README, and documentation index.
- [V40.4 Unified Simulation Optimization Runtime](SIMULATION_OPTIMIZATION_RUNTIME_V40_4.md) - adaptive multi-rate execution, dynamic fidelity, dirty-state evaluation, heterogeneous scheduling/placement, solver auto-tuning, incremental branches, SoA ensembles, arena-backed zero-copy state, and integrated optimization profiling/advice.
- [V40.5 Engine Research Digital Twin](ENGINE_RESEARCH_DIGITAL_TWIN_V40_5.md) - coupled reduced chemistry and turbulent flame-kernel combustion, 1-D intake/plenum/header waves, EGR transport, dry/wet-sump oil hydraulics/aeration, reduced-FE flexibility, thermal clearances, emissions/aftertreatment, pressure observers/closed-loop combustion control, lifecycle/RUL/rebuild genealogy, advanced water/methanol/nitrous/nitromethane fueling, durability-aware design/calibration optimization, plus the preserved V40.5 multi-zone/valvetrain/DI-PFI/tribology/thermal/health authorities.
- [Transmission Authority Phases E-I](TRANSMISSION_AUTHORITY_PHASES_E_I.md) - prioritized common-core/manual/automatic/specialized gearbox specification covering multi-body gear dynamics, thermal/lubricant coupling, clutch-to-clutch shifts, driver/synchronizer mechanics, TCU supervision, physical fault/limp behavior, lubricant/debris/RUL/genealogy, durability-aware calibration, specialized architectures, API/telemetry, and release validation while preserving the established Phase A-D authority.


### V47.1 debug/refactor closure

The latest V47 maintenance tranche preserves the Tire & Traction and Acceleration Performance laboratories while correcting event-origin semantics, rotational-inertia accounting, carcass torsion integration, Monte Carlo median/rank-correlation semantics, bound-aware sensitivity/uncertainty, convergence error estimation, calibration interpolation/CSV validation and strict CLI numeric parsing. See Chapter 106.25 of the comprehensive user manual for migration/re-baseline guidance.

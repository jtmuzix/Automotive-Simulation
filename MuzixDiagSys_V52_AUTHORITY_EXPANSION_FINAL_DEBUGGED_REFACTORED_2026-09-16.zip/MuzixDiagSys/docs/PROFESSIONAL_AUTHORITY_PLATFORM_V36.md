# MuzixDiagSys V36 Professional Authority Platform

**Release:** 2026-08-27  
**Library:** `aesim_professional_authority_v36`  
**Public header:** `include/aesim/advanced/professional_authority_platform.hpp`  
**Qualification executable:** `muzixdiagsys_professional_authority_v36`  
**Machine-readable manifest:** `configs/professional_authority_v36_manifest.json`

V36 implements the twenty requested professional/research-grade capability families as an **additive authority layer**. Existing V35 motorsport, Formula One, IndyCar, NASCAR, NHRA, vehicle, electrification, MDF, HIL/XIL, uncertainty, validation, numerical-assurance, CAE federation, and regulation services remain in place. V36 composes those authorities where they already exist and adds missing algorithms only where the audit found a real gap.

No proprietary vendor solver source or licensed databases are redistributed. FTire/CDTire, REFPROP, and equivalent commercial engines are supported through executable runtime integration contracts; using those engines still requires the corresponding licensed vendor installation. This is an integration boundary, not an unimplemented code path: the loader, symbol validation, input/output marshalling, lifecycle, error handling, and behavioral regression are implemented and tested with ABI-compatible test libraries.

## 1. Architecture and non-duplication rules

The V36 target depends on `aesim_motorsport_v35`, `aesim_industrial`, and `aesim_core`. It deliberately reuses:

- V35 endurance, rally, Formula E, driver, track-state, racecraft, strategy, and coaching models;
- the established MDF 4.x recorder/data conventions;
- `HilIoManager` for deterministic HIL exchange;
- the core Saltelli/Sobol implementation for variance-based sensitivity;
- the core Richardson-extrapolation/Grid Convergence Index machinery for CAE convergence qualification.

`include/aesim/advanced/platform.hpp` exposes the V36 API through the existing umbrella surface, and `aesim_advanced` links the V36 library after V35. Existing public classes are not redefined.

## 2. MF-Tyre, MF-Swift, FTire and CDTire authority

`TireAuthorityModel` implements a deterministic Magic-Formula authority with combined longitudinal/lateral utilization, load and pressure sensitivity, camber force, aligning moment, rolling resistance, vertical compliance, relaxation dynamics, and an MF-Swift-style rigid-ring radial state. The model supports `.tir` parameter import/export and a bounded deterministic parameter-identification procedure against force/moment measurements.

`ExternalTireAuthority` loads licensed FTire/CDTire-compatible runtime adapters through `muzix_tire_authority_v1_eval`. It validates the library and symbol before accepting requests and maps the complete V36 tire operating point and transient state through the ABI. The project does not claim to contain the proprietary FTire or CDTire solver itself.

## 3. Nonlinear damper and suspension component laboratory

`NonlinearDamperLaboratory` models asymmetric bump/rebound behavior, low/high-speed transition, digressivity, bleed, shim dynamics, gas spring pressure, oil compressibility/temperature, viscosity fade, Coulomb/Stribeck friction, cavitation, aeration, bump-stop force, and inerter contribution. `fit_dynograph()` performs deterministic inverse calibration against measured force/velocity/displacement/temperature points.

## 4. Motorsport telemetry interoperability

`MotorsportTelemetryInterop` imports generic CSV plus MoTeC, McLaren ATLAS and Cosworth **delimited export** profiles, and the project’s supported fixed-record MDF4 channel-group representation. It performs canonical channel aliasing, engineering-unit normalization, sample-rate estimation, automatic lap-boundary detection, distance-domain resampling, and cross-correlation-based timestamp offset/drift/uncertainty estimation.

Vendor-proprietary encrypted or undocumented binary database formats are not falsely decoded. The supported vendor path is their exported delimited telemetry, while MDF4 uses the established native binary path.

## 5. Generalized hardpoint suspension MBD/K&C

`GeneralizedSuspensionKandC` accepts physical hardpoints and topology metadata for double-wishbone, pushrod, pullrod, MacPherson, multilink, trailing/semi-trailing arm, De Dion, live-axle, and torsion-beam studies. It calculates camber, toe, caster, KPI, scrub radius, mechanical trail, motion ratio, bump steer, camber gain, instantaneous-center/roll-center height, anti-dive, anti-squat, and compliance contributions over individual operating points or travel sweeps.

This generalizes hardpoint authority while preserving the existing Formula One-specific K&C implementation.

## 6. Track-state physics and assimilation V2

`TrackStatePhysicsAssimilator` evolves a structured surface field containing elevation, cross-slope, drainage, water, rubber, marbles, debris, temperature, grip, and grip uncertainty. The finite-volume-style update accounts for rainfall, drainage, neighboring water transport, evaporation, solar heating, convection, rubber/debris effects, and vehicle-induced slip-energy/water-displacement/debris deposition. Grip observations are fused by variance-weighted Bayesian updates, and `forecast()` propagates both the physical state and uncertainty.

## 7. Brake tribology and thermoelastic digital twin

`BrakeTribologyThermoelasticTwin` couples clamp force and sliding speed to temperature-dependent friction, transfer-layer formation/destruction, fade, rotor/pad wear, hot-spot growth, coning, judder, duct cooling, brake-fluid heating/boiling and pedal-travel growth. The model retains existing vehicle brake-system authorities and supplies higher-fidelity friction-interface state.

## 8. Driveline torsional dynamics and NVH

`DrivelineTorsionalNvhPlatform` solves arbitrary lumped inertial nodes connected by compliant/damped geared shafts. It includes backlash deadbands, gear-ratio kinematics, mesh-stiffness modulation, mesh excitation, dissipated power, and deterministic discrete-frequency spectral analysis for order/NVH studies.

## 9. Driver-in-the-loop qualification

`DriverInLoopQualificationPlatform` provides motion-cue washout/tilt-coordination with workspace limits and reports gaze fixation/saccade activity, blink rate, pupil statistics, latency mean/P95/jitter, motion residual exposure, and a qualification decision. It is intended to qualify existing DIL/OpenXR workflows rather than replace their rendering/device layer.

## 10. WEC/IMSA timing, scoring and race control

`EnduranceTimingScoringRaceControl` records timing-line crossings, pit-lane state, class identity, time/drive-through/stop-go/lap-deletion penalties, and neutralization intervals. Classification is deterministic by completed laps and adjusted elapsed time with both overall and class positions. It composes the V35 endurance vehicle/stint physics instead of creating a second endurance vehicle model.

## 11. Rally event operations

`RallyEventOperationsPlatform` implements entrant registration, time-control due-time evaluation, asymmetric early/late penalties, stage recording, cancelled-stage assigned times, retirement/restart penalties, and event classification. The platform provides the event-operations authority above V35 stage physics.

## 12. Formula E next-generation operations

`FormulaENextGenerationOperations` models high-power charge acceptance, efficiency loss, SOC-dependent taper, connector and battery thermal limits, stationary-time compliance, completion state, and configurable rear/front-regen/all-wheel-drive deployment limits with Attack Mode scaling. Rules remain configuration-driven so event-specific limits can be supplied externally.

## 13. E-machine electromagnetic NVH and demagnetization

`EMachineNvhReliabilityPlatform` calculates mean torque, torque ripple, cogging torque, electrical order frequency, radial electromagnetic force, common-mode shaft voltage, bearing current, acoustic excitation, magnet heating, irreversible demagnetization accumulation, and insulation damage.

## 14. Battery chemo-mechanical aging

`BatteryChemoMechanicalAgingPlatform` couples SOC, prior capacity loss, temperature, current and mechanical constraint into swelling strain, stack pressure, particle cracking, separator compression, tab fatigue, contact-resistance growth, internal-short probability, cell thickness, mechanical stored energy and thermal-contact scaling.

## 15. EtherCAT and ASAM XIL/HIL integration

`EthercatProcessImage` implements deterministic PDO bit packing/unpacking, scaling/offset conversion, process-image bounds checking, working counter and hardware timestamp state. `HilVendorIntegration` composes the existing `HilIoManager` and provides ASAM-XIL-oriented vendor profiles for dSPACE, Speedgoat, OPAL-RT, NI VeriStand, ETAS LABCAR, Vector VT and generic rigs.

V36 does not duplicate the established HIL device manager or XIL testbench.

## 16. Model discrepancy and validity-domain supervision

`ModelDiscrepancyValiditySupervisor` learns measured-minus-simulated residual structure across a declared operating domain using a normalized kernel estimator that includes measurement variance. Assessment returns discrepancy mean/uncertainty, corrected prediction, normalized extrapolation distance, extrapolation flag and a continuous validity-confidence score.

## 17. Advanced global sensitivity analysis

`AdvancedGlobalSensitivitySuite` combines four complementary analyses:

- Morris elementary effects for screening;
- the existing core Saltelli/Sobol authority for first/total-order indices;
- Shapley effects for contribution attribution;
- active-subspace extraction from gradient covariance.

The implementation validates domains and uses deterministic seeded sampling.

## 18. CAE convergence and correlation qualification

`CaeCorrelationQualificationPlatform` reuses `aesim::core::math_assurance::analyze_convergence()` for Richardson/GCI analysis rather than cloning numerical-assurance equations. It adds CAE-oriented residual/y+ gates plus measured-vs-simulated RMSE, bias, R², normalized RMSE and combined qualification decisions.

## 19. Rulebook ingestion and semantic regulation diff

`RegulatoryKnowledgeIngestionPlatform` ingests plain text, HTML/XML text, and extractable PDF text streams, normalizes clauses, fingerprints content, and returns Added/Removed/Modified/Unchanged semantic changes using token-set similarity. The output is suitable for review/provenance pipelines feeding the existing regulation-as-code services. Human approval remains necessary before a regulatory change becomes an executable competition rule.

## 20. SINDy physics equation discovery

`PhysicsEquationDiscoveryPlatform::sindy()` validates uniformly ordered time series, estimates derivatives, constructs polynomial candidate libraries through configurable degree, performs least-squares estimation with sequential thresholding, refits the active support, and reports sparse interpretable equations with RMSE. It is deliberately interpretable and deterministic.

## 21. CoolProp, REFPROP and Cantera authority backends

`ThermophysicalAuthorityBackend` always provides a deterministic native ideal-gas/property fallback for common gas-like studies. It can dynamically load:

- CoolProp through its `PropsSI` C ABI;
- REFPROP-compatible authority adapters through `muzix_thermo_authority_v1_eval`;
- Cantera-compatible authority adapters through the same stable V36 bridge ABI.

The bridge exists because REFPROP and Cantera deployment ABIs vary by installation/language binding. The V36 loader is production code; the commercial/scientific vendor package remains externally supplied.

## 22. Qualification

Configure and build the focused authority targets:

```bash
cmake -S . -B build/v36 -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/v36 --parallel 2 --target \
  professional_authority_platform_tests \
  muzixdiagsys_professional_authority_v36
```

Run the compiled behavioral qualification:

```bash
ctest --test-dir build/v36 --output-on-failure \
  -R '^professional_authority_(platform_unit_tests|v36_source_regression|v36_cli_self_test)$'
```

Or directly:

```bash
./build/v36/muzixdiagsys_professional_authority_v36 capabilities
./build/v36/muzixdiagsys_professional_authority_v36 self-test
```

The unit test additionally builds an ABI-compatible shared test library and exercises the external FTire/CDTire and CoolProp/REFPROP/Cantera loading paths. That test library is strictly a qualification fixture; it is not represented as a vendor solver.

## 23. Verification and completeness contract

`tests/professional_authority_v36_source_regression.py` enforces:

- presence of all V36 production, test, tool, documentation and manifest members;
- one unique public declaration for every new authority class;
- production symbols for each requested algorithm family;
- explicit reuse of core Sobol and Richardson/GCI authorities;
- CMake integration of the V36 library, compiled tests, source regression and CLI;
- exposure through the existing advanced umbrella API;
- absence of incomplete-work markers in V36 source/test/tool members.

`tests/professional_authority_platform_tests.cpp` supplies compiled behavioral coverage for all twenty requested capability families and the external authority ABI paths.

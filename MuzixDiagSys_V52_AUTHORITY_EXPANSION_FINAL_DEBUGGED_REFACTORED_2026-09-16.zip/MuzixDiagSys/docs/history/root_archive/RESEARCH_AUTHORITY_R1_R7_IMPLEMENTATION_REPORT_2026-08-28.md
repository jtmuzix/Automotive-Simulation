# MuzixDiagSys Research Authority R1-R7 — Implementation Report

**Date:** 2026-08-28  
**Implementation rule:** R1 through R7 integrated in the requested order; no existing feature removed; canonical implementations reused instead of duplicated.

## 1. Integration architecture

The implementation introduces one public research surface, `aesim::advanced::research_authority`, declared in `include/aesim/advanced/research_authority_platform.hpp` and exported by `include/aesim/advanced/platform.hpp`. The implementation is split by the requested tranche order into:

1. `src/advanced/research_authority_r1.cpp`
2. `src/advanced/research_authority_r2.cpp`
3. `src/advanced/research_authority_r3.cpp`
4. `src/advanced/research_authority_r4.cpp`
5. `src/advanced/research_authority_r5.cpp`
6. `src/advanced/research_authority_r6.cpp`
7. `src/advanced/research_authority_r7.cpp`

Shared dense-linear-algebra, finite-difference, optimization, statistics, hashing, and validation utilities are internal to `src/advanced/research_authority_internal.hpp`. These files are compiled into the existing `aesim_advanced` library, not a competing library hierarchy.

## 2. Non-duplication decisions

Five mature project authorities were identified and retained as canonical:

| Requested capability | Canonical authority retained | New integration behavior |
|---|---|---|
| Bayesian model comparison | `BayesianMultimodelInference` | Adds pairwise log Bayes factors and posterior entropy around the existing evidence/model-averaging engine. |
| Explicit code-verification basis | `core::math_assurance` | Converts convergence/manufactured-solution evidence into explicit code/solution-verification reports and numerical uncertainty. |
| Nonsmooth contact | `NonsmoothComplementarityContactSolver` | Adds a Research Authority adapter; the complementarity solver itself is not duplicated. |
| Conservative energy accounting | `assured::ConservationGovernor` | Adds the R4 authority boundary while retaining the canonical interface/aggregate conservation audit. |
| Hardware performance counters | `app::CpuMicroarchitecturePmuProfiler` | Retains the native Linux PMU collector; R7 consumes observations for scientific performance analysis instead of adding a second collector. |

## 3. R1 — Scientific Credibility

Implemented code-order verification using observed convergence order; solution verification with discretization, iterative, and input numerical uncertainties; Bayesian multimodel comparison diagnostics; replicated-data posterior predictive checks; rank/coverage simulation-based calibration; prior-predictive physical-plausibility validation; and a formal intended-use credibility authority that combines these results with the existing simulation-quality qualification contract.

All reports carry deterministic SHA-256 evidence digests. The final credibility decision uses mandatory gates plus a lower-confidence aggregate score and retains restrictions from the underlying qualification contract.

## 4. R2 — Inference Laboratory

Implemented a nonlinear 4D-Var solver with background/observation covariance weighting and propagated trajectory; hybrid EnVar using a convex blend of static and ensemble sample covariance; bounded profile-likelihood nuisance optimization and confidence regions; objective-Hessian and sensitivity/Fisher diagnostics with eigenvalue rank/conditioning/covariance analysis; greedy D-optimal Bayesian experiment design under cost/budget constraints; and model discrimination using AIC/AICc/BIC weights plus a pointwise Vuong comparison.

## 5. R3 — Numerical Research Authority

Implemented probabilistic ODE integration using embedded discretization discrepancy as a local state covariance; a stiffness-aware adaptive solver portfolio spanning Dormand-Prince 5(4), Rosenbrock-Euler, and implicit trapezoid methods; linear DAE differential/algebraic partition and reduction; adjoint-weighted goal-error estimation and refinement ranking; implicit-midpoint energy-momentum integration; canonical complementarity-contact delegation; and Parareal time-parallel integration with OpenMP fine-propagation support when available.

Finite-difference Hessians use an `epsilon^(1/4)` perturbation scale appropriate to second-derivative cancellation sensitivity.

## 6. R4 — Co-Simulation and Multi-Fidelity

Implemented energy-based passivity observation and energy-tank flow correction; participant-aware adaptive macro-step negotiation with Accept/Refine/Rollback/Abort decisions; canonical conservation accounting; cost/variance-driven MLMC sample allocation; and autoregressive co-kriging with separate low-fidelity and discrepancy Gaussian processes.

## 7. R5 — Laboratory Metrology

Implemented ISO/IEC 17025-style instrument authorization; correlated GUM uncertainty propagation and Welch-Satterthwaite effective degrees of freedom; crossed balanced ANOVA Gage R&R/MSA; deterministic integrity-hashed digital calibration certificates; and directed measurement-traceability verification with cycle detection and chain uncertainty.

Input hardening includes actual Gregorian date validation and correlation-matrix checks for finiteness, unit diagonal, symmetry, coefficient bounds, and positive semidefiniteness.

## 8. R6 — Research Reproducibility

Implemented W3C PROV-style JSON-LD graph construction, dataset/model research cards, Citation File Format 1.2 metadata, RO-Crate 1.1 metadata with enumerated `hasPart` payloads, copied artifact packaging, run metadata, and immutable SHA-256 manifests.

Bundle verification uses a closed-world rule: every payload must be listed and every listed payload must exist with the exact size/hash. Unmanifested files are rejected. Path traversal in manifests is rejected by checking path components rather than substring matching, so safe filenames containing two periods remain valid.

## 9. R7 — HPC Science

Implemented Roofline classification from hardware-counter observations; statistically rigorous regression analysis with Welch inference, Student-t probability, deterministic bootstrap confidence intervals, effect size, and practical thresholds; bounded in-situ field publication/downsampling; audited computational steering; and resource-aware time-parallel production scheduling. Existing native PMU collection remains the hardware-counter source of record.

## 10. CLI and discoverability

The advanced CLI now supports:

```bash
muzixdiagsys_advanced_platform research-authority capabilities [output.json]
```

The general `capabilities` response also includes a `research_authority` section. The manifest emits exactly seven ordered tranches and 41 capabilities: R1=6, R2=6, R3=7, R4=5, R5=5, R6=6, R7=6.

## 11. Qualification target

CMake adds `research_authority_platform_tests` and registers it as `research_authority_r1_r7_unit_tests`. The dedicated test directly exercises every requested capability. Integrity-negative tests verify that digital calibration certificate mutation, unmanifested reproducibility payloads, and modified reproducibility artifacts are rejected.

See `docs/RESEARCH_AUTHORITY_R1_R7.md` for operator/developer usage and `RESEARCH_AUTHORITY_R1_R7_VALIDATION_2026-08-28.txt` for the final executed validation record.

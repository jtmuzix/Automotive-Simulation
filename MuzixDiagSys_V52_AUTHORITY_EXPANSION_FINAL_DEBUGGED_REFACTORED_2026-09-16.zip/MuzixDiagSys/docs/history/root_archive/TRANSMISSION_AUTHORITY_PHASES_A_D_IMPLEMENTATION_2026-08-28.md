# Transmission Authority Phases A-D — Implementation Record

Date: 2026-08-28

## Integration policy

The transmission work extends the existing `aesim::high_fidelity::FullTransmissionSystem`; it does not create a second competing transmission simulator. `TransmissionConfiguration` owns a `TransmissionAuthorityConfiguration`, `TransmissionState` exposes the resulting `TransmissionAuthorityState`, and the existing physical transmission consumes authority outputs for ratio, clutch capacity, hydraulic line-pressure demand, converter torque, mesh efficiency/loss, torque disturbance, thermal loading, gear selection, and diagnostics.

The implementation is contained primarily in:

- `include/aesim/high_fidelity/transmission_authority.hpp`
- `src/vehicle/transmission_authority.cpp`
- `include/aesim/high_fidelity/ecosystem.hpp`
- `src/vehicle/ecosystem_thermofluid_powertrain.cpp`
- `include/aesim/industrial/ecu_diagnostics_socketcan_v37.hpp`
- `src/industrial/ecu_diagnostics_v37_engineering.cpp`
- `tests/transmission_authority_tests.cpp`
- `tests/ecu_diagnostics_socketcan_v37_tests.cpp`

## Phase A — fundamental mechanics

1. **Gear Tooth Contact / LTCA Authority** — tooth normal load, Hertz-style contact stress, load-dependent mesh stiffness, static transmission error, sliding velocity, EHL film thickness/lambda ratio, mesh efficiency, micropitting risk, and scuffing risk. Manufacturing profile/lead errors and injected tooth damage feed the result.
2. **Synchronizer / Dog Engagement Authority** — cone friction torque, finite synchronization dynamics, blocker release, sleeve travel/engagement, dog safe-speed gating, dog impact energy, and accumulated synchronizer wear. Synchronizer-wear faults directly reduce effective cone friction.
3. **Shaft / Bearing / Gear Structural Dynamics** — multi-inertia torsional modal frequencies, excitation-dependent dynamic amplification, shaft twist, radial bearing loads, shaft deflection, and mesh misalignment. Manufacturing bearing-clearance variation and bearing faults participate.
4. **Advanced Clutch Tribology** — temperature/viscosity/film calculation, lambda-based boundary/mixed/full-film behavior, Stribeck-style effective friction, thermal fade, PV severity, flash temperature, and accumulated wear. The resulting friction coefficient and learned bite adaptation alter the physical clutch capacity.
5. **Torque-Converter Hydrodynamics** — speed ratio, torque ratio, K/capacity behavior, pump/turbine/stator torques, stator freewheeling, efficiency, heat generation, and cavitation index. The existing automatic transmission consumes authority turbine torque and converter heat without double-counting losses.

## Phase B — architecture depth

6. **General Planetary Network** — arbitrary simple planetary sets expressed over a configurable node graph, grounded nodes, commandable couplings, regularized least-squares kinematic solution, node speed/torque state, constraint residual, circulating power, and network efficiency. The solved ratio physically owns `PlanetaryHybrid` operation.
7. **Physical DCT** — odd/even layshaft speeds, active/preselected gears, finite preselection time, clutch crossover, bounded overlap, torque-hole and tie-up metrics, and direct mapping into the two existing hydraulic clutch circuits.
8. **Physical CVT / IVT** — finite variator ratio actuation, pulley/belt clamping force, traction capacity, belt slip, variator efficiency, and configurable IVT power-split/recirculating-power loss. The solved variator ratio physically owns `ContinuouslyVariable` operation.
9. **Lubrication Network** — speed/viscosity-dependent pump delivery, relief/gallery pressure, mesh jets, bearing feeds, leakage, aeration dynamics, starvation index, and pumping loss. Aeration fault injection changes the network and line-pressure authority.
10. **Valve-Body / Mechatronic Network** — three solenoid/spool channels with RL current dynamics, electromagnetic force, spool mass/spring/damping, pressure feedback, orifice flow, leakage, regulated line pressure, pressure tracking error, and electrical/hydraulic power. Stuck-low/high solenoid faults are channel-aware.

## Phase C — control and diagnostics

11. **Adaptive TCM Learning** — shift-completion learning for pressure, fill time, clutch bite, and per-gear bias. Learned pressure changes line-pressure authority; fill-time changes the actual hydraulic shift phase; bite changes clutch capacity; gear bias closes back into the multi-objective shift optimizer.
12. **V37-Integrated Transmission Diagnostics** — twelve transmission measurements are registered in the existing V37 semantic registry with DID/CAN/XCP identities. Seven DTC families publish through the existing AUTOSAR-style DEM operation-cycle/debounce/confirmation/UDS-memory mechanism: P0730, P0868, P0741, P17A0, P17A1, P0711, and P17B0. Snapshot/extended records include monitor value, threshold, severity, and diagnostic confidence.
13. **Shift-Quality Authority** — shift duration, peak output jerk, flare, tie-up, torque-hole fraction, slip energy, and normalized quality score. This score participates in adaptation and diagnostics.
14. **Transmission Fault Injection** — line-pressure leak, stuck-low/high solenoid, clutch friction loss, synchronizer wear, gear-tooth damage, bearing damage, speed-sensor bias, oil aeration, CVT clamp loss, and converter-stator failure. Faults change the physical authority outputs rather than only setting flags.
15. **Intelligent Shift Optimization** — evaluates every installed fixed gear using weighted fuel/speed, performance/underspeed/overspeed, thermal, durability, housing-resonance/NVH, shift-distance penalty, and learned per-gear bias. Automatic fixed-ratio architectures consume the recommended gear.

## Phase D — professional engineering

16. **Transmission Dyno / Correlation Laboratory** — external torque-reference input, predicted/reference torque, residual, forgetting-factor RMSE, normalized residual, and correlation score. A zero external reference deliberately selects self-baselining instead of accidentally comparing against a previous simulated sample.
17. **Durability Authority** — cumulative gear-contact, bearing, clutch, synchronizer, and shaft fatigue damage with stress/life scaling, equivalent damage rate, and minimum remaining-life fraction.
18. **Manufacturing-Tolerance Twin** — deterministic seeded Monte-Carlo realization of gear profile/lead error, bearing clearance, clutch thickness, valve land, and pulley cone error. Tolerances feed efficiency, preload, contact, tribology, valve, and CVT behavior.
19. **Order-Resolved Gearbox NVH** — engine orders, gear-mesh order/frequency, configurable mesh sidebands, bearing-defect contribution, component amplitudes, overall acceleration RMS, and tonal prominence.
20. **Housing Structural / Acoustic Coupling** — configurable housing modes, damping and participation, modal transfer from gearbox excitation, surface velocity, radiated acoustic power, SPL, and dominant radiating frequency. Housing resonance also feeds the intelligent shift objective.

## Validation

The following binaries were built with the project's Release warning policy (`-Wall -Wextra -Wpedantic -Wshadow -Wformat=2`) and executed successfully:

- `transmission_authority_tests` — **PASS**
- `ecosystem_tests` — **PASS**
- `ecu_diagnostics_socketcan_v37_tests` — **PASS**

The dedicated transmission regression verifies physical outputs across all four phases, general multi-node planetary behavior, DCT behavior, CVT/IVT power recirculation, fault propagation, adaptive learning, explicit dyno reference ingestion, and `FullTransmissionSystem` integration. The V37 regression verifies semantic registration and DEM-to-UDS DTC publication.

A source scan of the new transmission authority/test implementation found no `TODO`, `FIXME`, `stub`, `placeholder`, or `not implemented` markers.

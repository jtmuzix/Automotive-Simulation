# Advanced Automotive Electronics & Compute Authority — Phases A–E

Date: 2026-08-28

## Integration policy

This expansion is additive. It does not replace or fork existing MuzixDiagSys authorities. Existing implementations are composed where they already own a physical or lifecycle domain: `BuiltInSelfTestLaboratory`, `NvmReliabilityLaboratory`, `SemiconductorAgingLaboratory`, `SecureProvisioningLifecycle`, `LowVoltagePowerNetwork`, `PmicSystemBasisChip`, and `electrification::OtaLifecycleManager` remain canonical. The V38 layer adds missing execution, network-silicon, body-electronics, centralized-compute, harness, EMC, deployment, and orchestration depth around those engines.

Public API: `include/aesim/advanced/automotive_electronics_compute_authority.hpp`

Implementation units:

- `src/advanced/automotive_electronics_compute_phase_a.cpp`
- `src/advanced/automotive_electronics_compute_phase_b.cpp`
- `src/advanced/automotive_electronics_compute_phase_c.cpp`
- `src/advanced/automotive_electronics_compute_phase_d.cpp`
- `src/advanced/automotive_electronics_compute_phase_e.cpp`

Regression suite: `tests/automotive_electronics_compute_authority_tests.cpp`

## Phase A — ECU silicon and board electronics

| Requested authority | V38 implementation | Principal behaviors |
|---|---|---|
| MCU peripheral/interrupt/DMA | `McuPeripheralInterruptDmaAuthority` | Priority/nested/preemptive ISRs, vector latency, peripheral FIFOs/overrun, edge/software/DMA triggers, future events, DMA queues, weighted arbitration, throughput/utilization/latency accounting and execution trace. |
| Safety MCU / lockstep / ECC / BIST | `SafetyMcuSupervisor` | Reuses canonical BIST laboratory; MBIST/LBIST startup, corrected/uncorrectable ECC accumulation, lockstep divergence, clock/voltage monitors, watchdog windows, fault escalation, reset and safe-state decisions. |
| Flash/NVM endurance and corruption | `TransactionalNvmAuthority` | Reuses physical `NvmReliabilityLaboratory`; redundant copies, generation counters, CRC32, commit markers, copy validation, power-loss transaction rejection, previous-version recovery, byte corruption injection and degraded redundancy reporting. |
| Clock/reset/power sequencing | `ClockResetPowerSequencer` | Reuses canonical PMIC/SBC; power rails, PLL lock/acquisition/loss, clock tolerance, reset-source capture, rail/clock dependencies and dependency-ordered boot-stage completion. |
| ECU board electronics | `EcuBoardElectronicsAuthority` | Board component thermal RC behavior, analog-front-end gain/offset/noise/filtering, ADC quantization/INL, actuator high/low-side loss and thermal stress, board power and diagnostic reporting. |

## Phase B — in-vehicle networks and AUTOSAR communication

| Requested authority | V38 implementation | Principal behaviors |
|---|---|---|
| Full LIN 2.x | `Lin2NetworkAuthority` | Master/slave nodes, protected identifiers, classic/enhanced checksum, schedule tables, payload ownership, NAD configuration, sleep/wake, clock tolerance, response timeout and checksum fault injection. |
| Full FlexRay | `FlexRayNetworkAuthority` | Cold-start participation, dual channels, static slots, dynamic/minislot traffic, communication cycles, channel availability, synchronization/clock-correction assessment and cycle counters. |
| Automotive Ethernet PHY | `AutomotiveEthernetPhyAuthority` | 100/1000/multi-gig T1 profiles, training time, master/slave timing assumptions, insertion/connector loss, SNR, uncoded BER, FEC residual BER, thermal derating, link fault/flap behavior. |
| Ethernet switch silicon | `EthernetSwitchSiliconAuthority` | MAC learning/aging, VLAN membership, unknown/broadcast flooding, ingress/egress queueing, priority arbitration, finite buffers, drops/HOL behavior, cut-through/store-forward latency and hardware PTP timestamps. |
| AUTOSAR COM/PduR/If/Tp/E2E | `AutosarCommunicationStackAuthority` | Signal packing/unpacking, I-PDU definitions/routes, bus-interface MTU segmentation/reassembly and AUTOSAR E2E Profiles 1/2/4/5/6/7 with Data ID, counter, CRC, repetition and sequence checks. |

## Phase C — body, access and distributed electronics

| Requested authority | V38 implementation | Principal behaviors |
|---|---|---|
| BCM/body electronics | `BodyControlModuleAuthority` | Ignition/body-state logic, ambient/rain-driven lighting/wiper behavior, brake/hazard/turn outputs, feedback-based lamp diagnostics and load estimates. |
| Smart power distribution/eFuse | `SmartPowerDistributionController` | Extends `LowVoltagePowerNetwork`; channel criticality, brownout-driven load shedding, retry lockout/timers and application of electronic-fuse commands to canonical electrical loads. |
| Door/seat/window ECUs | `DistributedBodyActuatorEcu` | DC motor electrical/mechanical dynamics, back-EMF, H-bridge/PWM command, gearing, inertia/damping, end-stop learning, obstruction force, pinch reversal, stall/current and motor thermal diagnostics. |
| PEPS/UWB/Digital Key depth | `PepsUwbDigitalKeyAuthority` | Multi-anchor time-of-flight ranging, weighted nonlinear least-squares 3D localization, secure timestamp validation, NLOS bias, residual/relay detection and inside/trunk/approach zoning. |
| Secure manufacturing/provisioning | `ProductionProvisioningAuthority` | Extends canonical `SecureProvisioningLifecycle`; enrollment, VIN/calibration personalization, one-time OTP programming, immobilizer pairing, lifecycle transitions, debug challenge authorization and audit trail. |

## Phase D — cockpit and centralized compute

| Requested authority | V38 implementation | Principal behaviors |
|---|---|---|
| Cockpit/IVI computer | `CockpitIviComputerAuthority` | CPU/GPU/NPU/memory/storage workloads, priority/safety classification, contention, completion/deadline accounting, thermal state and throttling. |
| Display pipeline | `DisplayPipelineAuthority` | Application/compositor/GPU/serializer/panel timing chain, vsync budget, link bandwidth/BER, frame presentation/drop/tear, panel reset and safety-frame deadline/fault reporting. |
| Automotive audio electronics | `AutomotiveAudioElectronicsAuthority` | Sample/DSP workload accounting, DSP xruns, amplifier efficiency/thermal state and ANC coherence/attenuation. |
| ADAS SoC contention | `AdasSocContentionAndSafetyAuthority` | Shared DDR and NoC bandwidth, GPU/NPU/ISP/DSP accelerator service, per-workload operations and data movement, utilization, DVFS/thermal behavior, completion and deadlines. |
| GPU/NPU safety partitioning | `AdasSocContentionAndSafetyAuthority` | Partition accelerator allow-lists, memory/DDR/NoC quotas, runtime watchdogs, ASIL criticality, violation counting and safety-island fault escalation. |

## Phase E — reliability, EMC, vehicle wiring and SDV lifecycle

| Requested authority | V38 implementation | Principal behaviors |
|---|---|---|
| ECU semiconductor aging | `EcuElectronicsAgingAuthority` | Extends canonical semiconductor mission-profile aging with capacitor ESR growth, solder thermal-cycle damage, oscillator drift, competing-risk survival aggregation and dominant-component reporting. |
| EMC/transient qualification | `AutomotiveEmcTransientQualificationAuthority` | ISO 7637 pulse families, load dump, crank, ESD, BCI/radiated stimulation, source impedance, TVS dynamic clamp, series/filter attenuation, absorbed energy, UVLO/OVLO reset, upset probability and damage/pass assessment. |
| Harness/grounding twin | `WiringHarnessGroundingAuthority` | Nodal conductance solve, wire/contact resistance, current/loss, multiple grounds and offsets, shield transfer-noise estimate, added resistance/open/short/leakage faults and source impedance. |
| Intermittent electrical faults | `IntermittentElectricalFaultEngine` | Deterministic seeded stochastic activation, Poisson hazard, exponential dwell time, environment-dependent temperature/vibration/humidity/current acceleration and activation statistics. |
| Software compatibility/deployment graph | `SoftwareCompatibilityDeploymentGraph` | Semantic-version bounds, API/schema/bootloader constraints, missing-node checks, cycle detection, deterministic topological installation order and target-version candidate validation. |
| Production OTA orchestration | `ProductionOtaCampaignOrchestrator` | Extends canonical per-ECU OTA lifecycle; payload SHA-256, target-version compatibility gate, dependency ordering, canary gate, stationary/SOC constraints, ECU health verification, fleet progress, failure collection and rollback orchestration. |
| Whole-vehicle startup | `WholeVehicleStartupAuthority` | Dependency DAG validation, missing/cyclic dependency detection, longest-path/critical-path calculation, concurrent runtime startup, node availability/blocking, completion timestamps and startup deadline misses. |

## Build integration

CMake target: `aesim_electronics_compute_v38`

Regression target: `automotive_electronics_compute_authority_tests`

The new target links the existing `aesim_advanced` authority so canonical electronics, power, security, NVM, compute and OTA implementations remain single-source rather than duplicated.

## Final integrated validation — 2026-08-28

The release tree was rebuilt after the transmission compatibility correction so every consumer of the public transmission authority header used one consistent ABI. The complete CMake build reached 100%, including `aesim_industrial`, `aesim_advanced`, `aesim_electronics_compute_v38`, all test executables, CLI libraries, `simulation_runtime.cpp`, and the final `muzixdiagsys` executable.

Runtime validation on the corrected build:

- `accuracy_depth_complete_tests`: PASS
- `transmission_authority_tests`: PASS
- `ecosystem_tests`: PASS
- `automotive_electronics_compute_authority_tests`: PASS
- `ecu_diagnostics_socketcan_v37_tests`: PASS during the integrated build/CTest campaign
- Full CTest campaign: 307/309 passed in the parallel run; the only two failures were PTY rendering/timing tests (`ui_professional_workflow_pty` and `completion_popup_scroll_pty`). Both were immediately rerun serially against the same binaries and passed, yielding 3/3 including the artifact-preparation fixture. No deterministic model, API, source-retention, duplicate-implementation, diagnostics, electronics, transmission, or network test remained failing.

The deterministic transmission regression discovered during integration was corrected without disabling either feature: explicit legacy `requested_gear` commands remain authoritative unless intelligent shift optimization is explicitly configured to own gear selection, and manual gear selection with the coupling clutch released retains the established API contract while the detailed synchronizer/dog model continues to calculate synchronization torque, sleeve engagement, impact, and wear telemetry.

Release-tree preservation versus the immediately preceding transmission-authority package:

- inherited files: 1,707
- inherited files removed: 0
- inherited files unchanged: 1,704
- inherited files modified intentionally: 3 (`CMakeLists.txt`, `include/aesim/high_fidelity/transmission_authority.hpp`, `src/vehicle/ecosystem_thermofluid_powertrain.cpp`)
- new files: 9
- unfinished implementation marker scan (`TODO`, `FIXME`, `STUB`, `PLACEHOLDER`, `NOT IMPLEMENTED`) across the new V38 public header, internal header, Phase A–E sources, and regression test: no matches
- generated runtime keys, Python bytecode caches, and test history artifacts were removed before packaging
- the project CTest `duplicate_implementation_regression`, `version20_feature_retention_regression`, `source_package_regression`, and electronics-assurance regressions pass on this source/build combination.

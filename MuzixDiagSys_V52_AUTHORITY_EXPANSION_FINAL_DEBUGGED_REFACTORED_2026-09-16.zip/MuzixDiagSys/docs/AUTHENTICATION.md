# MuzixDiagSys Authentication and User Administration

MuzixDiagSys authenticates an operator before the simulation thread, interactive dashboard, batch command processor, API server, or diagnostic command dispatcher is started. There is no unauthenticated simulator-command mode.

## Initial account

A new user database is bootstrapped with:

```text
Login:    jtmuzix
Password: T1k1@420
```

The bootstrap account can create and administer users. Change the bootstrap password after the first deployment:

```text
user passwd
```

The current password, new password, and confirmation are read without terminal echo. Passwords are never accepted as literal command-line arguments and therefore are not written to command history.

## Password protection

Passwords are not reversibly encrypted. They are stored as one-way PBKDF2-HMAC-SHA-256 verifiers using:

- a cryptographically random 256-bit salt for each newly created or changed password;
- 600,000 PBKDF2 iterations;
- a 256-bit derived verifier;
- constant-time verifier comparison;
- exclusive, owner-private, flush-before-rename atomic database replacement;
- owner-only permissions for database files and newly created authentication directories on supported filesystems;
- generic non-security atomic outputs preserve existing POSIX destination permissions and process-default creation semantics.

The bootstrap password is also represented by a salted one-way verifier; its plaintext is not embedded in the production authentication implementation or written to the user database.

## User database location

The default database is:

- Linux and other POSIX systems: `$XDG_CONFIG_HOME/muzixdiagsys/users.json`, or `~/.config/muzixdiagsys/users.json` when `XDG_CONFIG_HOME` is unset;
- Windows: `%APPDATA%\MuzixDiagSys\users.json`;
- fallback: `.muzixdiagsys/users.json` below the current directory.

Set `MUZIXDIAGSYS_USER_DB` to use a different database path. User-administration updates are protected by a cross-process lock and committed through atomic replacement.

### Custom database-directory behavior

When MuzixDiagSys creates the authentication directory, it restricts that new directory to its owner on supported POSIX filesystems. When a custom database path points into an **existing** directory, MuzixDiagSys does not change the parent directory's permissions. This prevents an application launch from accidentally converting a shared, mounted, or administrator-managed directory to mode `0700`.

The database file, audit log, audit head seal, lock artifacts, password files, and credential files still require appropriate protection. For a custom existing parent directory, configure ownership, access-control lists, mount options, and backup policy outside MuzixDiagSys. The database itself is written owner-private by default and remains owner-private after updates.

## Login methods

Interactive launch prompts for a login and a non-echoed password:

```bash
./build/muzixdiagsys
```

For protected local automation, supply a username and an owner-only password file:

```bash
./build/muzixdiagsys \
  --auth-user jtmuzix \
  --auth-password-file /secure/path/password.txt
```

A two-line credential file is also supported. Line 1 is the username and line 2 is the password:

```bash
./build/muzixdiagsys \
  --auth-credential-file /secure/path/muzixdiagsys.cred
```

`MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE` provides the same credential-file mechanism for service supervisors and test runners. Protect all password and credential files with owner-only access and delete temporary credential files promptly.

Informational startup modes such as `--help`, `--command-schema`, and completion queries do not start the simulator and therefore do not require authentication.

## User commands

Show the current identity and effective login-time permission:

```text
user whoami
```

List users. This requires user-management permission:

```text
user list
```

Create a user with the secure password prompt:

```text
user create technician1
```

**New users cannot create or administer users by default.** To delegate that right at creation time:

```text
user create supervisor1 --can-create-users
```

For automation, provide the new password in an owner-only one-line file:

```text
user create technician1 --password-file /secure/path/new-user-password.txt
```

Grant or revoke the right to create and administer users:

```text
user permission technician1 on
user permission technician1 off
```

MuzixDiagSys refuses to revoke or disable the final active account with user-management permission.

Enable or disable an account:

```text
user disable technician1
user enable technician1
```

Change the current user's password:

```text
user passwd
```

An authorized administrator can reset another user's password:

```text
user passwd technician1
```

End the authenticated session:

```text
logout
```

`quit` and `exit` also terminate the process normally.

## Password and username policy

Usernames must contain 3 to 32 characters, begin with a letter or digit, and use only letters, digits, `.`, `_`, and `-`.

Passwords must contain 8 to 256 characters and include at least one lowercase letter, uppercase letter, digit, and symbol. Passwords are not displayed, logged, serialized into project files, or included in simulation checkpoints.

## V46 browser deep links, recovery, and bearer-token boundary

The V46 browser workstation retains the existing authenticated server boundary. It does not introduce new unauthenticated endpoints: browser state, schema, streaming updates and command execution continue through `/api/state`, `/api/schema`, `/api/stream`, and `/api/command` respectively.

The **Share** control builds a deep link from engineering navigation state only. It removes any `token` query parameter before generating the link and stores workbench ID, typed engineering selection, selected signals, synchronized cursor times/range and workspace in the URL fragment. Bearer credentials are therefore not intentionally copied into shared engineering links.

Browser autosave and recovery do not bypass authentication. Local browser state can restore presentation context, while complete recovery uses the authenticated canonical `ui sessions` and `ui desktop` services. A recovered session is still subject to the same user/role permissions as any other canonical command execution.

Operational guidance remains unchanged: prefer loopback binding, do not place bearer-token URLs in tickets or shared documents, and require explicit `MUZIX_WEB_ALLOW_REMOTE=1` only when remote binding is deliberately protected by host/network controls.

# Motorsport CLI Command Reference

This document defines the additive Formula One, NASCAR, and IndyCar convenience command surface in `muzixdiagsys_advanced_platform` and documents the separate V35 cross-series motorsport qualification executable. The commands are routing aliases over existing production motorsport models; they do not replace or disable the original command families. The interactive bridge also exposes the public NASCAR ecosystem, frontier, and next-generation façade APIs as first-class command roots instead of requiring access only through the aggregate `nascar` dispatcher.

## Interactive `muzixdiagsys` integration

The same motorsport dispatcher is now available in-process from the primary `muzixdiagsys` interactive console. Existing motorsport implementations are shared rather than copied. Three equivalent discovery/execution styles are supported:

```text
motorsport list
motorsport f1 capabilities
f1 capabilities
indycar capabilities
nascar all-capabilities
nascar-ecosystem capabilities
nascar-frontier capabilities
nascar-next-generation capabilities
nhra capabilities
f1-race capabilities
indycar-timing capabilities
nascar-officiating capabilities
```

`motorsport list` enumerates all 39 aggregate, family, and shortcut roots. Formula One, IndyCar, NASCAR, and NHRA roots are also direct interactive commands, and they participate in the main CLI help, command palette, global command schema, and Tab completion. The standalone `muzixdiagsys_advanced_platform` syntax documented below remains supported unchanged.

## Common execution rules

All commands use canonical JSON input and output. A completed model whose engineering qualification has `passed=false` returns exit code 2. Malformed input or execution failure returns 1. Invalid top-level syntax returns 64. When a working directory is supplied, the underlying production platform writes the same evidence artifacts as the original command family.

### Formula One aggregate router

```bash
./build/full/muzixdiagsys_advanced_platform f1 capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform f1 list [output.json]
./build/full/muzixdiagsys_advanced_platform f1 self-test DIRECTORY [output.json]
./build/full/muzixdiagsys_advanced_platform f1 run \
  operations|regulatory|industrial DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`f1 capabilities` reports all 50 public JSON domains across the three existing Formula One command families. `f1 self-test` runs all three production self-tests and preserves a separate evidence directory for each family.

Formula One shortcuts:

| Command | Existing family/domain | Purpose |
|---|---|---|
| `f1-race` | `f1-regulatory full-field-competition` | 22-car/11-team full-field race simulation |
| `f1-ers` | `f1-regulatory ers-electrical-hardware` | 2026 ERS electrical/electrothermal and energy-metering analysis |
| `f1-scrutineering` | `f1-operations physical-scrutineering` | Physical scrutineering with uncertainty guard bands |
| `f1-race-control` | `f1-regulatory remote-race-control` | Remote race-control evidence fusion |
| `f1-aero` | `f1-industrial aero-raceability-design` | Aerodynamic raceability/rules-package design |
| `f1-setup` | `f1-industrial causal-setup-intelligence` | Causal setup analysis and constrained recommendation |
| `f1-wet` | `f1-operations wet-weather-visibility` | Spray, optical visibility, sensor degradation and raceability |
| `f1-driver` | `f1-industrial driver-medical-performance` | Driver medical/performance qualification |

Shortcut syntax:

```bash
./build/full/muzixdiagsys_advanced_platform f1-race capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform f1-race \
  examples/formula_one_regulatory_competition/full_field_competition.json \
  build/f1-race.json build/f1-race-evidence
```

### NASCAR aggregate routing

The existing `nascar capabilities`, `nascar self-test`, and direct 40-domain dispatch remain unchanged. The aggregate router exposes all six public NASCAR façade families while retaining the existing competition aggregate. The competition façade itself delegates the ecosystem, frontier, and next-generation domains, so aggregate accounting distinguishes unique domains from family endpoints:

```bash
./build/full/muzixdiagsys_advanced_platform nascar all-capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform nascar list-all [output.json]
./build/full/muzixdiagsys_advanced_platform nascar all-self-test DIRECTORY [output.json]
./build/full/muzixdiagsys_advanced_platform nascar run \
  competition|ecosystem|frontier|next-generation|integrated|assurance \
  DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]

./build/full/muzixdiagsys_advanced_platform nascar-ecosystem capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform nascar-frontier capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform nascar-next-generation capabilities [output.json]
```

The aggregate registry exposes **64 unique JSON domains** and **94 family-domain endpoints** across six public families. The endpoint count is intentionally larger because `nascar competition` already re-exports the 10 ecosystem, 10 frontier, and 10 next-generation domains. `nascar all-self-test` does not redundantly execute those 30 delegated domains twice; the competition self-test already qualifies them. Each façade can still be self-tested independently with `nascar-ecosystem self-test`, `nascar-frontier self-test`, or `nascar-next-generation self-test`.

NASCAR shortcuts:

| Command | Existing family/domain | Purpose |
|---|---|---|
| `nascar-pack` | `nascar superspeedway-pack` | Drafting, side draft, bump draft and pack-risk simulation |
| `nascar-race-control` | `nascar race-control` | Stages, cautions, choose rule, pit-road state, restarts and overtime |
| `nascar-pit` | `nascar single-lug-pit-crew` | Single-lug pit choreography, fueling, interference and penalties |
| `nascar-tyres` | `nascar goodyear-tyre` | Tire thermomechanics, pressure, wear and failure risk |
| `nascar-setup` | `nascar setup-rig` | K&C, damper, pull-down and seven-post correlation |
| `nascar-racecraft` | `nascar full-field-racecraft` | Full-field multi-agent racecraft and strategy |
| `nascar-telemetry` | `nascar-integrated telemetry-assimilation` | State estimation and parameter calibration |
| `nascar-officiating` | `nascar-assurance officiating-policy-lab` | Policy consistency, safety and competitive-impact analysis |

### IndyCar aggregate router

```bash
./build/full/muzixdiagsys_advanced_platform indycar capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform indycar list [output.json]
./build/full/muzixdiagsys_advanced_platform indycar self-test DIRECTORY [output.json]
./build/full/muzixdiagsys_advanced_platform indycar run \
  development|integrated|assurance DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`indy` is accepted as a short synonym for `indycar`. The aggregate registry exposes 34 JSON domains: 10 development/operations domains, 10 integrated-fidelity domains, and 14 engineering-assurance domains.

IndyCar shortcuts:

| Command | Existing family/domain | Purpose |
|---|---|---|
| `indycar-hybrid` | `indycar-integrated ecu-hybrid-control` | Hybrid deployment, regen, thermal, SOC and torque control |
| `indycar-pit` | `indycar-integrated pit-lane-twin` | Shared pit-lane service, queuing and release safety |
| `indycar-radio` | `indycar-integrated radio-timing` | Radio semantics/comprehension and timing reconciliation |
| `indycar-setup` | `indycar-development race-engineering-intelligence` | Race-engineering setup intelligence |
| `indycar-tyres` | `indycar-integrated tire-contact` | Combined-slip tire contact, thermal/wear and structural analysis |
| `indycar-safety` | `indycar-assurance crash-safer-fe` | Crash and SAFER-barrier engineering assurance |
| `indycar-timing` | `indycar-assurance timing-observation-fusion` | Multi-source timing/observation fusion |
| `indycar-driver` | `indycar-development driver-simulator-qualification` | Driver-in-the-loop simulator qualification |


## V35 cross-series motorsport qualification executable

V35 does **not** create a second set of F1/IndyCar/NASCAR aliases. Its ten cross-series engines live in the focused `aesim_motorsport_v35` library and are qualified by a separate executable:

```bash
./build/full/muzixdiagsys_motorsport_v35 capabilities
./build/full/muzixdiagsys_motorsport_v35 self-test
```

`capabilities` lists the ten V35 capability families. `self-test` executes one deterministic behavioral qualification for each family and exits non-zero if any check fails. Detailed scenario construction is intentionally a C++ API surface rather than a duplicate JSON router; include `aesim/advanced/motorsport_v35_platform.hpp` and link `aesim_motorsport_v35` (or consume it transitively through `aesim_advanced`).

Focused build and tests:

```bash
cmake --build build/full --parallel 2 --target \
  motorsport_v35_platform_tests muzixdiagsys_motorsport_v35
ctest --test-dir build/full --output-on-failure \
  -R '^motorsport_v35_(platform_unit_tests|source_regression|cli_self_test)$'
```

The full API/model description is in [`MOTORSPORT_V35_PLATFORM.md`](MOTORSPORT_V35_PLATFORM.md), and the integrated operator/developer workflow is User Manual Chapter 95.

## Why aliases exist

The aliases shorten common engineering workflows while preserving one implementation of the underlying model. For example, `f1-ers` and `f1-regulatory ers-electrical-hardware` call the same production platform; the alias does not maintain a second ERS model. This guarantees identical input validation, numerical behavior, findings, evidence digests, and working-directory artifacts.

## Regression qualification

```bash
cmake --build build/full --target muzixdiagsys_advanced_platform --parallel "$(nproc)"
ctest --test-dir build/full --output-on-failure -R '^motorsport_cli_commands_regression$'
```

The regression verifies aggregate registry counts, family routing, shortcut capability metadata, and successful execution of all 24 shortcut commands against canonical repository examples.

## V47 general tire/traction/performance commands

These commands are intentionally under the common `ui` engineering surface rather than an F1/IndyCar/NASCAR/NHRA namespace:

```text
ui tire-traction json [key=value ...]
ui acceleration-performance json [key=value ...]
ui acceleration-performance sensitivity [fraction=...] [key=value ...]
ui acceleration-performance convergence [tolerance=...] [key=value ...]
ui acceleration-performance monte-carlo [samples=...] [seed=...] [sigma=...] [key=value ...]
ui acceleration-performance calibrate <measurement.csv> [iterations=...] [key=value ...]
```

They provide common straight-line tire/traction/performance analysis and do not supersede series-specific motorsport authorities.

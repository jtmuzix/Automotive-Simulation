# MuzixDiagSys Beginner-to-Advanced Tutorial and Exact Command Guide

**Companion to the existing User Manual - updated 2026-09-10 for V47 Tire, Traction & Precision Performance Dynamics and the V46 Integrated Engineering Workstation, V45/Transmission domain visualization, native research workbenches, browser recovery/deep links, and completion-popup PTY hardening; prior V40.3 and Engineering Intelligence workflows retained.**

This guide intentionally concentrates on practical operating knowledge that is only lightly covered, scattered across implementation appendices, or absent from the User Manual: command side effects, state transitions, deterministic experiment discipline, standalone executables, automation, output artifacts, and the distinction between compiled libraries and interactive commands.

## Scope and verification basis

- The current executable reports **165 canonical root commands**, **49 accepted but hidden compatibility aliases**, **260 nested command contexts**, and **13,622 discoverable literal completion paths**.
- A literal completion path is not necessarily a separate operation. Many paths are combinations of one operation with signal names, identifiers, file paths, protocol payloads, presets, or delegated industrial routes.
- “Every command” in this guide therefore means every canonical root command, its principal operational forms, and every standalone executable command. Data values and every possible identifier are described by grammar rather than repeated as thousands of near-duplicates.
- Formula One and all six IndyCar modules are C++ library APIs and validation targets. NASCAR is available both through typed C++ APIs and the `muzixdiagsys_advanced_platform nascar` runtime family. Formula One, IndyCar, and NASCAR use the focused `aesim_formula_one`, `aesim_indycar`, and `aesim_nascar` libraries, which remain publicly and transitively available through `aesim_advanced`. These systems are not falsely presented as interactive console roots when no such root exists.

## Contents
- 1. Build and verify every feature
- 2. Runtime mental model
- 3. First 20 minutes
- 4. Beginner vehicle operation
- 5. Intermediate experiments and diagnostics
- 6. Advanced deterministic engineering
- 7. Automation and external interfaces
- 8. Standalone executable command guide
- 9. Engineering-platform CLI
- 10. Formula One, IndyCar, and NASCAR access model
- 11. Troubleshooting by symptom
- 12. Exact canonical command catalog
- 13. Emerging mobility laboratories
- 14. Formula One championship operations
- 15. IndyCar frontier expansion: complete engineering workflow
- 16. NASCAR next-generation engineering and operations workflow
- 40. V40.3 Browser Operations and Fault-Investigation Workflow
- 44. V46 Integrated Engineering Workstation Workflow
- 45. V47 Tire, traction, and precision acceleration workflow
- 17. Formula One regulatory and competition workflow
- 18. IndyCar development and operations workflow
- 19. Formula One industrial and ecosystem workflow
- 20. Formula One predictive-fidelity and telemetry-correlation workflow
- 31. Engineering Intelligence Platform workflow
- 32. V33 Generalized Engineering Operations workflow
- 33. V34 Native Qualification workflow
- 34. V35 Motorsport Expansion workflow
- 35. V36 Professional Authority workflow
- 36. V37 ECU / Diagnostics / SocketCAN Authority workflow

# 1. Build and verify every feature

Run the following from the extracted project root. The configuration builds the interactive simulator, all libraries, plugins, FMU, research utilities, standalone CLIs, and tests. SYCL and HIP are requested; each backend is compiled only when its toolchain is detected.
```bash
rm -rf build/full
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_POSITION_INDEPENDENT_CODE=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_SYCL=ON \
  -DAESIM_ENABLE_HIP=ON \
  -DAESIM_ENABLE_LTO=OFF \
  -DAESIM_ENABLE_NATIVE_OPTIMIZATION=OFF \
  -DAESIM_ENABLE_SANITIZERS=OFF \
  -DMUZIXDIAGSYS_ENABLE_SIZE_OPTIMIZATION=ON
CTEST_PARALLEL_LEVEL="$(nproc)" \
  cmake --build build/full --target aesim_check --parallel "$(nproc)"
```

## What every build command and flag does
- **`rm -rf build/full`** — Deletes only the selected out-of-source build tree. It guarantees that no stale cache, object, generated plugin, or old feature-detection result contaminates configuration.
- **`cmake -S . -B build/full`** — Uses the current directory as source and build/full as an isolated binary/generated-artifact directory.
- **`-G Ninja`** — Selects the Ninja generator for dependency-aware parallel builds.
- **`-DCMAKE_BUILD_TYPE=RelWithDebInfo`** — Enables optimized code plus debug information. The two very large console translation units deliberately use -Og under GCC; numerical libraries retain normal CMake optimization.
- **`-DBUILD_TESTING=ON`** — Enables CTest registration and builds test executables when the all target is built.
- **`-DAESIM_BUILD_TOOLS=ON`** — Builds study workers, reference generator, engineering CLI, causal lab, advanced safety, specification discovery, standards deployment, and advanced-platform CLI.
- **`-DAESIM_ENABLE_HARDENING=ON`** — Adds stack protection, release fortification, RELRO, and immediate symbol binding where supported.
- **`-DAESIM_ENABLE_POSITION_INDEPENDENT_CODE=ON`** — Builds static libraries as PIC and executables as PIE; avoids relocation failures and supports hardened link profiles.
- **`-DAESIM_ENABLE_STRICT_NUMERICS=ON`** — Disables fast-math and floating-point contraction/reassociation that can compromise reproducibility or numerical evidence.
- **`-DAESIM_ENABLE_SYCL=ON`** — Requests the native SYCL acceleration backend. Unsupported compilers do not gain a fake backend.
- **`-DAESIM_ENABLE_HIP=ON`** — Requests the ROCm/HIP backend when a HIP compiler is available.
- **`-DAESIM_ENABLE_LTO=OFF`** — Avoids interprocedural link-time optimization. Set ON only after CMake confirms IPO support and when longer links are acceptable.
- **`-DAESIM_ENABLE_NATIVE_OPTIMIZATION=OFF`** — Keeps binaries portable instead of emitting instructions specialized for the build host with -march=native/-mtune=native.
- **`-DAESIM_ENABLE_SANITIZERS=OFF`** — Produces a normal operational build. A separate debug build should enable ASan/UBSan.
- **`-DMUZIXDIAGSYS_ENABLE_SIZE_OPTIMIZATION=ON`** — Places functions/data in separate sections and garbage-collects unreachable sections without removing reachable features.
- **`cmake --build ... --target aesim_check --parallel`** — Transactionally builds every compiled target and launches CTest only after the build succeeds. A compiler or linker failure therefore remains the primary diagnostic instead of being followed by hundreds of missing-executable test failures.
- **`CTEST_PARALLEL_LEVEL`** — Controls CTest worker concurrency inside `aesim_check`; it is independent of Ninja's `--parallel` build concurrency.

## Know what was actually built
```bash
cmake --build build/full --target help | less
find build/full -maxdepth 2 -type f -perm -111 -printf '%p\n' | sort
./build/full/muzixdiagsys --command-schema
./build/full/muzixdiagsys_advanced_platform capabilities
```
The target help command lists build targets; `find` lists executable files; the schema command proves the console grammar; capabilities proves the advanced library/CLI feature inventory.

# 2. Runtime mental model

MuzixDiagSys has four different kinds of state. Correct operation depends on knowing which one a command changes:
- **Plant state.** Engine speed, pressures, temperatures, battery state, vehicle speed, tire state, faults, controller integrators, simulation time, and solver history.
- **Execution state.** Whether the background loop is running, real-time period, solver/fidelity selection, MIL/SIL/HIL scheduler, API servers, buses, plugins, and external interfaces.
- **Engineering evidence state.** Logs, scope buffers, journals, checkpoints, branches, replay records, workflow evidence, project manifests, validation results, and provenance.
- **Interface state.** Dashboard page, lower pane, filters, search match, watch panel, bookmarks, inspector, palette, and persisted UI preferences.

A command can be read-only in one state domain and mutating in another. For example, `page next` changes interface state only; `step 1` changes plant and evidence state; `report session file.md` writes an artifact but normally does not change physics; `checkpoint restore` replaces a broad state image.

## Continuous time versus deterministic time

- `run`, `pause`, and `loop` control a background integration flag.
- `step <seconds>` advances immediately on the command thread and is the preferred method for reproducible tutorials and regression investigations.
- Direct commands are serialized by the console. Engineering Studio commands temporarily pause the continuous loop, execute against synchronized bindings, and restore the prior loop state.
- A stopped loop is not an error. Inputs such as throttle and brake are stored, but speed and temperatures do not evolve until `step` or `run` executes.

## Query, mutate, verify

Use a three-command discipline for professional work: query the baseline, apply one change, and verify the result. Add a checkpoint before destructive or hard-to-reconstruct work.
```text
checkpoint save before_wet_test
road surface wet
step 2
status
health status
```

# 3. First 20 minutes

## 3.1 Start without guessing
```bash
./build/full/muzixdiagsys --advanced-help
./build/full/muzixdiagsys --completion-query="engine "
./build/full/muzixdiagsys
```
The first two commands exit before authentication. The third starts the authenticated console. For protected automation, use an owner-only credential file rather than placing a password on the command line.
```bash
printf '%s\n%s\n' 'USERNAME' 'PASSWORD' > /secure/path/muzix.credentials
chmod 600 /secure/path/muzix.credentials
./build/full/muzixdiagsys --auth-credential-file /secure/path/muzix.credentials
```
Do not keep bootstrap credentials in shell history or source control. Change the bootstrap password on first deployment.

## 3.2 Discover commands from the running build
```text
command-schema status
command-schema validate
command-schema aliases
command-schema complete engine 
command-schema complete industrial energy depth
```
`validate` is the fastest way to detect drift between dispatch, completion, and descriptions. `complete` uses the same registry as Tab completion; it is more authoritative than a copied command list.

## 3.3 Deterministic first drive
```text
reset
vehicle vw_gti_mk8_dsg
engine list
fuel premium_93
mode automatic
quickstart
clutch 0
throttle 20
step 2
status
drivecheck
brake 30
step 1
throttle 0
brake 0
```
`clutch 0` is harmlessly informative for a manual workflow but can be rejected for an automatic preset. Use the active vehicle’s transmission type rather than copying commands blindly.

## 3.4 Read the result, not only the dashboard
```text
metrics
page list
page engine
dict boost
dict page vehicle
view energy
physics status
health status
stability
```
Dashboard values are summaries. `dict` explains provenance and units; `physics`, `health`, and `stability` are the higher-value checks when a result looks surprising.

# 4. Beginner vehicle operation

## Manual-transmission start and shift
```text
reset
vehicle vw_gti_mk8_manual
mode manual
key start
clutch 0
gear 1
throttle 18
step 1.5
clutch 100
throttle 5
shift up
clutch 0
throttle 25
step 2
drivecheck
```
The clutch value is pedal depression: 0 means released/coupled; 100 means depressed/disengaged. This is the opposite of a “clutch engagement fraction,” a frequent source of user error.

## Automatic-transmission operation
```text
reset
vehicle vw_gti_mk8_dsg
mode automatic
quickstart
tcm mode sport
throttle 35
step 5
tcm status
driveline status
```
The TCM chooses gears from its strategy and physical shift state. A high throttle command does not guarantee immediate acceleration when brake, traction, converter, shift phase, protection, or road load limits torque.

## Surface and control-system experiment
```text
checkpoint save dry_baseline
road surface dry
traction on
abs on
throttle 45
step 3
tire status
checkpoint restore dry_baseline
road surface ice
throttle 45
step 3
tire status
drivecheck
```
This is a controlled A/B test because both branches start from the same checkpoint. Simply running dry and ice sequentially without restore would confound temperature, speed, controller integrators, and tire state.

# 5. Intermediate experiments and diagnostics

## 5.1 Drive-cycle validation
```text
cycle list
checkpoint save pre_cycle
cycle validate ftp75 results/ftp75_trace.csv
validation status
report validation results/ftp75_validation.md
checkpoint restore pre_cycle
cycle validate wltc3b results/wltc3b_trace.csv
```
A cycle runner can change substantial dynamic state. Checkpointing allows fair comparisons and makes the trace reproducible.

## 5.2 Fault-to-evidence-to-repair workflow
```text
checkpoint save healthy
fault list
fault inject sensor map bias 8
step 5
dtc active
dtc freeze
diagnose current
trace map
scope start
scope add map
scope add boost
step 2
scope stop
scope export results/map_fault_scope.csv
repair all
step 1
dtc active
health status
```
Do not clear DTC memory before capturing freeze frames and traces. `repair all` resets modeled causes; DTC clearing and readiness restoration are separate diagnostic actions.

## 5.3 Protocol-equivalence check
```text
diagnostics obd powertrain 010C
diagnostics uds powertrain 22F190
doip 10 22F190
elm ATZ
elm ATH1
elm ATSH7E0
elm 010C
sovd GET /entities/powertrain
```
These surfaces share authoritative diagnostic state but encode and route it differently. Compare semantic values, not textual formatting: ELM adds adapter prompts/headers, OBD uses PID formulas, UDS uses DIDs/services, DoIP uses logical addresses, and SOVD exposes resources.

## 5.4 Logging and artifact discipline
```text
log start
scope start
scope add rpm
scope add torque
scope add boost
step 10
scope stop
log stop
log export results/session.jsonl
dataset export results/snapshot.json
report session results/session.md
checkpoint save end_of_run
journal verify
```
Use one results directory per experiment. Keep input manifests immutable, export machine-readable data before narrative reports, and record a checkpoint/state hash with the result.

# 6. Advanced deterministic engineering

## 6.1 Solver and fidelity are separate controls
Fidelity chooses model depth; solver chooses numerical integration. A high-fidelity model with a loose/large-step solver can be less trustworthy than a balanced model with appropriate tolerances.
```text
fidelity status
solver status
checkpoint save solver_baseline
fidelity research
solver profile research
solver events on
solver multirate on
step 1
health status
stability
checkpoint restore solver_baseline
```

## 6.2 Checkpoint, branch, replay, and journal are not synonyms
- **checkpoint:** A complete restorable state image.
- **branch:** A named alternate line of deterministic experimentation created from a state image.
- **replay:** A command/state-hash record used to reproduce and verify an execution.
- **journal:** A tamper-evident record of commands and state transitions.
- **state:** Versioned serialization/diff tooling for simulator state documents.
```text
checkpoint save baseline
branch create wet_branch baseline
road surface wet
step 5
state save results/wet_state.json
branch select main
checkpoint restore baseline
road surface dry
step 5
state diff results/wet_state.json
replay export results/run.replay.json
journal verify
```

## 6.3 Calibration and uncertainty workflow
```text
cal status
map list
map inspect torque
checkpoint save stock_cal
cal sport
validate suite
uncertainty status
montecarlo status
optimize status
checkpoint restore stock_cal
```
For actual fit/uncertainty jobs, use explicit study documents and the engineering CLI so inputs, seed, parameter bounds, observations, and outputs are durable files rather than ephemeral terminal history.

## 6.4 MIL/SIL/HIL progression
```text
execution status
mil status
execution mode mil
step 1
sil status
execution mode shadow_sil
step 1
execution report
hil status
xil status
```
Shadow modes compare controller outputs without handing full authority to the candidate. Use them before direct SIL or hardware authority. HIL/XIL forms may open real or virtual I/O backends and therefore require explicit safe-state and close procedures.

## 6.5 FMI, SSP, XCP, and MDF workflow
```text
fmi3 status
fmi3 export results/powertrain_fmi3
ssp status
xcp status
xcp a2l results/calibration.a2l
mdf status
fmi status
```
FMI/FMI3 package models for co-simulation; SSP packages system structures and parameterizations; XCP/A2L exposes calibration/measurement semantics; MDF stores measured signals. They solve different interoperability problems and should not be treated as interchangeable export formats.

# 7. Automation and external interfaces

## Safe batch-console automation
```bash
cat > run.txt <<'EOF'
reset
vehicle vw_gti_mk8_dsg
quickstart
throttle 25
step 10
report session results/batch_session.md
quit
EOF
./build/full/muzixdiagsys --auth-credential-file /secure/muzix.credentials < run.txt > results/batch_console.log
```
Batch input is serialized exactly like typed commands. Preserve standard output and the exit code. A command-level error can appear in output even when the process continues, so automation should scan for structured error lines and verify artifacts.

## Completion-driven wrappers
```bash
./build/full/muzixdiagsys --completion-query="solver "
printf 'engine \nvehicle \nindustrial energy depth \n' |   ./build/full/muzixdiagsys --completion-batch
```
This is the correct way to build shell completion or a GUI command picker. Do not hard-code a command list that will drift from delegated registries.

## Local API
```text
api status
api start 7777
api request status
api stop
```
The simulator API command manages the bounded local JSON-over-HTTP facade. Starting a server changes execution state and opens a listening socket; verify bind address, port, authorization boundary, and shutdown behavior before using it outside a development host.

# 8. Standalone executable command guide
## `muzixdiagsys`
Interactive/batch simulator console.
- **`muzixdiagsys --help | -h | --advanced-help`** — Print the generated command reference and exit before authentication.
- **`muzixdiagsys --command-schema`** — Print the full command/completion schema, including all discoverable literal paths, and exit before authentication.
- **`muzixdiagsys --completion-query "PREFIX"`** — Print completion candidates for one command prefix and exit.
- **`muzixdiagsys --completion-query=PREFIX`** — Equivalent inline spelling of the completion query.
- **`muzixdiagsys --completion-batch`** — Read prefixes from standard input and print tab-separated completion candidates, one result line per input line.
- **`muzixdiagsys --auth-user USER --auth-password-file FILE`** — Authenticate non-interactively using a username and an owner-protected one-line password file.
- **`muzixdiagsys --auth-credential-file FILE`** — Authenticate using a two-line file: username on line one and password on line two. The environment variable MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE provides the same path.
## `muzixdiagsys_advanced_platform`
Advanced interoperability, optimization, safety, cybersecurity, homologation, distributed execution, and deterministic graph CLI.
- **`muzixdiagsys_advanced_platform capabilities [output.json]`** — Enumerate compiled advanced features. Writes JSON when an output path is supplied; otherwise prints JSON.
- **`muzixdiagsys_advanced_platform self-test DIRECTORY [output.json]`** — Run the integrated advanced-platform self-test using DIRECTORY for generated artifacts. Returns 2 when the result document contains passed=false.
- **`muzixdiagsys_advanced_platform interop probe OUTPUT.json`** — Probe installed/runtime integration adapters and write their availability/status document.
- **`muzixdiagsys_advanced_platform interop translate PLATFORM to|from INPUT OUTPUT`** — Translate a canonical document to or from a supported platform representation such as ROS 2, CARLA, Autoware, or Apollo.
- **`muzixdiagsys_advanced_platform rosbag2 create BAG.db3 METADATA.yaml TOPIC TYPE INPUT`** — Create a rosbag2-compatible SQLite database, register one topic/type, serialize INPUT as a CDR-labeled message, and write metadata YAML.
- **`muzixdiagsys_advanced_platform rl REQUEST.json OUTPUT.json`** — Execute the learning-environment request encoded in JSON and write the response.
- **`muzixdiagsys_advanced_platform optimize nsga2|bayesian SPEC OUTPUT.json`** — Run NSGA-II or Gaussian-process multi-objective Bayesian optimization from SPEC and write result JSON.
- **`muzixdiagsys_advanced_platform safety MODEL OUTPUT.json`** — Generate HARA/FMEA/FMEDA/fault-tree/STPA-oriented safety analysis from MODEL.
- **`muzixdiagsys_advanced_platform fuzz can|isotp|uds|doip|someip ITERATIONS OUTPUT.json`** — Run a stateful deterministic protocol fuzz campaign against the virtual ECU cyber range.
- **`muzixdiagsys_advanced_platform security self-test DIRECTORY OUTPUT.json`** — Run secure-boot, HSM, SecOC, OTA, attestation, and related security integration checks in DIRECTORY.
- **`muzixdiagsys_advanced_platform homologation PACK TRACE.csv OUTPUT.json`** — Evaluate a digital homologation pack against a CSV trace and write traceability/verdict evidence.
- **`muzixdiagsys_advanced_platform slurm manifest JOB.json OUTPUT.sbatch`** — Convert a distributed-job document into an sbatch script.
- **`muzixdiagsys_advanced_platform slurm submit SCRIPT`** — Submit SCRIPT with the configured Slurm command and print the returned job identifier.
- **`muzixdiagsys_advanced_platform slurm query JOB_ID [output.json]`** — Query job state; print or optionally write the result document.
- **`muzixdiagsys_advanced_platform slurm cancel JOB_ID`** — Cancel the selected Slurm job.
- **`muzixdiagsys_advanced_platform kubernetes manifest JOB.json OUTPUT.yaml [namespace]`** — Generate a Kubernetes job manifest, defaulting namespace to default.
- **`muzixdiagsys_advanced_platform kubernetes apply MANIFEST [namespace]`** — Apply the manifest through kubectl and return the created job name.
- **`muzixdiagsys_advanced_platform kubernetes query JOB [output.json] [namespace]`** — Query the Kubernetes job and print or write its state.
- **`muzixdiagsys_advanced_platform kubernetes delete JOB [namespace]`** — Delete the Kubernetes job.
- **`muzixdiagsys_advanced_platform graph DEFINITION.json OUTPUT.json [include-buffers]`** — Load and execute a deterministic execution graph. The optional flag includes buffer contents in the output document.
## `muzixdiagsys_causal_lab`
Standalone causal simulation and rare-event analysis.
- **`muzixdiagsys_causal_lab status`** — Print the implemented capability set.
- **`muzixdiagsys_causal_lab timeline-verify <timeline.json>`** — Load a deterministic time-travel timeline and print its validated status.
- **`muzixdiagsys_causal_lab diff <baseline.json> <candidate.json>`** — Compare two timelines and return exit code 0 when causally equivalent or 1 when differences remain.
- **`muzixdiagsys_causal_lab mine <log.csv> <scenarios.json> [clusters]`** — Load a real-world log, cluster/mine scenarios, export JSON, and report the number generated.
- **`muzixdiagsys_causal_lab rare-gaussian <threshold-sigma> [samples]`** — Estimate a one-dimensional Gaussian tail probability with cross-entropy importance sampling.
## `muzixdiagsys_advanced_safety`
Advanced safety discovery, intervention, and time-travel debugging.
- **`muzixdiagsys_advanced_safety capabilities`** — List the compiled advanced-safety capabilities.
- **`muzixdiagsys_advanced_safety self-test`** — Run deterministic integration smoke tests and return nonzero if falsification/intervention/compute checks fail.
- **`muzixdiagsys_advanced_safety debugger [FILE]`** — Open the interactive time-travel debugger and optionally load a timeline JSON file.
## `muzixdiagsys_specification_discovery`
Temporal-logic specification and monitor synthesis.
- **`muzixdiagsys_specification_discovery capabilities`** — List the implemented specification/discovery capabilities.
- **`muzixdiagsys_specification_discovery self-test`** — Run deterministic integration smoke tests.
- **`muzixdiagsys_specification_discovery synthesize-monitor EXPR`** — Parse a temporal expression and emit a self-contained C++ GeneratedTemporalMonitor implementation to standard output.
## `muzixdiagsys_standards_deployment`
OpenSCENARIO DSL compilation and standards/deployment checks.
- **`muzixdiagsys_standards_deployment capabilities`** — Print the standards/deployment capability inventory.
- **`muzixdiagsys_standards_deployment self-test`** — Run deterministic integration smoke tests.
- **`muzixdiagsys_standards_deployment compile-scenario INPUT.osc OUTPUT.json|OUTPUT.xosc`** — Compile the project DSL. A .xosc output receives OpenSCENARIO XML; other output extensions receive the normalized instance document.
## `aesim_study_worker`
Network worker for distributed study execution.
- **`aesim_study_worker [address] [port]`** — Start a StudyWorkerServer. Defaults are 127.0.0.1 and port 9100; port 0 requests an ephemeral port. It runs until SIGINT or SIGTERM, then stops cleanly.
## `research_reference_generator`
Generate the built-in research validation reference dataset.
- **`research_reference_generator [csv_path] [metadata_path]`** — Generate the validation CSV and metadata JSON. Defaults are data/research_validation_reference.csv and data/research_validation_reference.meta.json.

# 9. Engineering-platform CLI

The engineering CLI uses a persistent database and credential file. Its global options are `--database PATH --credential-file OWNER_ONLY_PATH`. Every command verifies the audit log before dispatch; a broken audit chain causes refusal rather than silent continuation.
- **`muzixdiagsys_engineering roles catalog`** — Print the built-in engineering role catalog.
- **`muzixdiagsys_engineering roles assign USER ROLE...`** — Replace USER’s engineering roles after authorization.
- **`muzixdiagsys_engineering audit verify`** — Verify the engineering audit hash chain before other work.
- **`muzixdiagsys_engineering audit read [N]`** — Read the most recent N audit records.
- **`muzixdiagsys_engineering workspace create ROOT NAME [DESCRIPTION]`** — Create a workspace directory and persisted workspace record.
- **`muzixdiagsys_engineering workspace list ROOT`** — List workspaces under ROOT.
- **`muzixdiagsys_engineering workspace member ROOT ID USER owner|editor|runner|viewer`** — Assign a workspace-specific member role.
- **`muzixdiagsys_engineering workspace add ROOT ID FILE ROLE`** — Add a resource file to a workspace with a semantic role.
- **`muzixdiagsys_engineering workspace manifest ROOT ID SEED OUTPUT`** — Write a deterministic campaign manifest for the workspace.
- **`muzixdiagsys_engineering scenario compose OUTPUT NAME [DURATION] [STEP]`** — Create a basic scenario specification document.
- **`muzixdiagsys_engineering scenario build SPEC_JSON OUTPUT`** — Build/normalize a scenario from a JSON specification.
- **`muzixdiagsys_engineering campaign run OUTPUT [BACKEND] [WORKERS]`** — Run the built-in campaign workflow with selected backend/worker count.
- **`muzixdiagsys_engineering campaign execute DEFINITION_JSON OUTPUT`** — Execute a persisted campaign definition.
- **`muzixdiagsys_engineering worker serve PORT [SECONDS]`** — Start an engineering worker service, optionally ending after SECONDS.
- **`muzixdiagsys_engineering worker run HOST PORT INDEX SEED key=value...`** — Submit/run one indexed deterministic worker job.
- **`muzixdiagsys_engineering replay demo DIRECTORY`** — Generate a replay demonstration and artifacts.
- **`muzixdiagsys_engineering replay verify REPLAY_JSON`** — Verify a replay document and state hashes.
- **`muzixdiagsys_engineering fault demo`** — Run the built-in fault demonstration.
- **`muzixdiagsys_engineering fault apply DEFINITIONS_JSON SAMPLES_JSON OUTPUT`** — Apply fault definitions to sampled input and write results.
- **`muzixdiagsys_engineering telemetry demo PORT COUNT`** — Run a bounded telemetry demonstration.
- **`muzixdiagsys_engineering telemetry serve PORT INPUT_JSONL [INTERVAL_MS] [LINGER_MS]`** — Serve JSONL telemetry at a controlled interval and optional linger period.
- **`muzixdiagsys_engineering diagnostics plan OUTPUT SYMPTOM cause=probability...`** — Build a probabilistic diagnostic plan.
- **`muzixdiagsys_engineering compare BASELINE CANDIDATE OUTPUT_PREFIX [ABS_TOL] [REL_TOL]`** — Compare datasets and write difference artifacts using absolute/relative tolerances.
- **`muzixdiagsys_engineering standards fmi FILE`** — Inspect/validate an FMI artifact.
- **`muzixdiagsys_engineering standards opendrive FILE`** — Inspect/validate OpenDRIVE.
- **`muzixdiagsys_engineering standards openscenario FILE [XODR]`** — Inspect/validate OpenSCENARIO, optionally against an OpenDRIVE map.
- **`muzixdiagsys_engineering learning courses`** — List interactive courses.
- **`muzixdiagsys_engineering learning lesson COURSE INDEX`** — Print one lesson.
- **`muzixdiagsys_engineering learning answer COURSE INDEX CHOICE`** — Submit a lesson answer and update progress.
- **`muzixdiagsys_engineering learning save COURSE OUTPUT`** — Persist course progress.
- **`muzixdiagsys_engineering learning load PROGRESS_FILE`** — Load persisted progress.
- **`muzixdiagsys_engineering units convert VALUE FROM TO`** — Convert a quantity using the engineering unit registry.
- **`muzixdiagsys_engineering units physics MASS_KG SPEED_M_S TORQUE_NM RPM`** — Calculate kinetic/power-related physics values.
- **`muzixdiagsys_engineering driver PROFILE STEPS DT TARGET_SPEED LEAD_DISTANCE LEAD_SPEED`** — Simulate a bounded driver model and print JSON samples.
- **`muzixdiagsys_engineering sensors STEPS DT TRUTH_VALUE [RAIN] [INTERFERENCE]`** — Simulate camera/radar/lidar/ultrasonic/GNSS/IMU/wheel measurements with latency, variance, weather, and interference.
- **`muzixdiagsys_engineering requirements evaluate REQUIREMENTS TRACE OUTPUT`** — Evaluate runtime requirements against a trace; write JSON and return 1 when any requirement fails.
- **`muzixdiagsys_engineering uncertainty run STUDY OUTPUT`** — Run seeded sampling and Sobol-style uncertainty analysis from a study document.
- **`muzixdiagsys_engineering calibration fit STUDY OUTPUT`** — Fit bounded parameters to observations using global and local calibration stages.
- **`muzixdiagsys_engineering fidelity train SAMPLES OUTPUT [linear|quadratic]`** — Train and persist a surrogate model.
- **`muzixdiagsys_engineering fidelity predict MODEL INPUT_JSON`** — Load a surrogate, evaluate one JSON input map, and report extrapolation status.
- **`muzixdiagsys_engineering experiment select CANDIDATES OUTPUT COUNT [maximin|doptimal]`** — Select informative experiments by maximin or D-optimal criterion.
- **`muzixdiagsys_engineering assurance evaluate CASE NODE`** — Evaluate a safety-case node and return nonzero when verdict is not pass.
- **`muzixdiagsys_engineering assurance impact CASE NODE`** — List nodes affected by a safety-case change.
- **`muzixdiagsys_engineering thermal run SPEC OUTPUT`** — Run the EV thermal/HVAC network for the requested steps and write final/history data.
- **`muzixdiagsys_engineering battery-life run DUTY OUTPUT`** — Accumulate battery lifecycle state across duty points.
- **`muzixdiagsys_engineering timing run SPEC OUTPUT`** — Run timing/schedulability analysis from a specification.
- **`muzixdiagsys_engineering xil run SPEC OUTPUT`** — Run the XIL timing/execution model.
- **`muzixdiagsys_engineering xil execute SPEC OUTPUT`** — Open the selected I/O backend, execute controller cycles, enter safe state, close the backend, and write I/O statistics/results.
- **`muzixdiagsys_engineering fleet run STUDY OUTPUT`** — Run a seeded virtual-fleet tolerance and acceptance simulation.
- **`muzixdiagsys_engineering maintenance estimate HISTORY OUTPUT [THRESHOLD]`** — Estimate remaining health/life from a history series.
- **`muzixdiagsys_engineering nvh analyze SAMPLES OUTPUT [RATE] [RPM]`** — Compute NVH spectrum/order metrics.
- **`muzixdiagsys_engineering consistency check MODEL TRACE OUTPUT`** — Check bounds and conservation/balance equations; return 1 when inconsistent.
- **`muzixdiagsys_engineering collaboration create ROOT ID AUTHOR CONTENT`** — Create revision 1 of a controlled artifact.
- **`muzixdiagsys_engineering collaboration revise ROOT ID REV AUTHOR CONTENT`** — Create a new revision from REV.
- **`muzixdiagsys_engineering collaboration submit ROOT ID REV ACTOR`** — Submit a revision for decision.
- **`muzixdiagsys_engineering collaboration comment ROOT ID REV ACTOR TEXT`** — Append a review comment.
- **`muzixdiagsys_engineering collaboration decide ROOT ID REV ACTOR DECISION [COMMENT]`** — Record approval/rejection and optional comment.
- **`muzixdiagsys_engineering collaboration latest ROOT ID`** — Print the latest revision.
- **`muzixdiagsys_engineering collaboration history ROOT ID`** — Print complete revision history.
- **`muzixdiagsys_engineering collaboration verify ROOT ID`** — Verify the revision chain.
- **`muzixdiagsys_engineering graph upsert FILE ID TYPE LABEL`** — Create or replace a knowledge-graph node and save FILE.
- **`muzixdiagsys_engineering graph edge FILE FROM TO RELATION`** — Add an edge and save FILE.
- **`muzixdiagsys_engineering graph search FILE TEXT [TYPE]`** — Search nodes by text and optional type.
- **`muzixdiagsys_engineering graph impact FILE ID`** — Return impacted node identifiers.
- **`muzixdiagsys_engineering graph path FILE FROM TO`** — Return a shortest path.
- **`muzixdiagsys_engineering graph remove FILE ID`** — Remove a node, save, and return 1 if nothing was removed.

# 10. Formula One, IndyCar, and NASCAR access model

Formula One and IndyCar are compiled C++ laboratories and validation targets. IndyCar now has four additive public modules, including the ten-domain frontier expansion. NASCAR has the same typed API model plus a 40-domain advanced-platform command family. Use the motorsport systems in four ways:
- Run focused CTest targets for qualification and regression evidence.
- Link Formula One or aggregate motorsport applications against `aesim_advanced`.
- Link IndyCar-only applications against `aesim_indycar`; the same APIs remain transitively available from `aesim_advanced`.
- Link NASCAR-only applications against `aesim_nascar`, or retain `aesim_advanced` for aggregate use.
- Use `muzixdiagsys_advanced_platform capabilities`, `self-test`, and `nascar ...` to verify runtime integration.

## Locate motorsport tests
```bash
ctest --test-dir build/full -N | grep -Ei 'formula_one|indycar|nascar'
ctest --test-dir build/full --output-on-failure -R '^formula_one_.*_unit_tests$'
ctest --test-dir build/full --output-on-failure -R '^indycar_.*_unit_tests$'
ctest --test-dir build/full --output-on-failure -R '^nascar_.*_unit_tests$'
```

## Focused IndyCar frontier build
```bash
cmake --build build/full --parallel --target \
  aesim_indycar \
  indycar_frontier_expansion_platform_tests
ctest --test-dir build/full --output-on-failure \
  -R '^indycar_frontier_expansion_platform_unit_tests$'
```

## Focused NASCAR build
```bash
cmake --build build/full --parallel --target \
  aesim_nascar \
  nascar_competition_platform_tests \
  nascar_ecosystem_platform_tests \
  nascar_frontier_platform_tests
```

## C++ integration pattern
```cpp
#include "aesim/advanced/formula_one_platform.hpp"
#include "aesim/advanced/indycar_platform.hpp"
#include "aesim/advanced/indycar_future_competition_platform.hpp"
#include "aesim/advanced/indycar_frontier_expansion_platform.hpp"
#include "aesim/advanced/nascar_competition_platform.hpp"
#include "aesim/advanced/nascar_ecosystem_platform.hpp"
#include "aesim/advanced/nascar_frontier_platform.hpp"

// Construct the specific laboratory type, populate its documented input
// structures, call the analysis/optimization method, and serialize the
// returned evidence/result document. Link NASCAR-only consumers to
// aesim_nascar; link aggregate consumers to aesim_advanced.
```
A capability being compiled does not imply a main-console root exists. Formula One and IndyCar remain typed advanced laboratories; NASCAR runtime requests use `muzixdiagsys_advanced_platform nascar`, not the interactive `muzixdiagsys` command shell.

# 11. Troubleshooting by symptom
- **Input changed but vehicle did not move.** Check `loop status`; use `step 1`; run `drivecheck`; verify ignition, engine running state, clutch, gear, brake, traction intervention, and road friction.
- **Command appears in old notes but not completion.** Run `command-schema aliases` and `command-schema complete <prefix>`. Aliases execute but are hidden from canonical discovery.
- **Tab completion suggests too many words after a leaf.** Use `command-schema paths` or the family’s help/status. Some legacy no-operand roots intentionally fall back to base completion words; those suggestions are not proof that a second root is a valid operand.
- **Results differ between two runs.** Reset or restore the same checkpoint, use deterministic `step`, keep seed/fidelity/solver/controller/plugin configuration identical, and compare state hashes/journal/replay evidence.
- **A fault was repaired but DTC remains.** Repair removes the modeled cause. Use `dtc active`, preserve freeze-frame evidence, then clear diagnostic memory separately when appropriate; readiness may need a new drive cycle.
- **External protocol values disagree.** Confirm ECU/logical address, units, scaling, session, headers, and whether comparing raw payload versus decoded value. All supported facades share state, but representations differ.
- **Full-feature build lacks SYCL or HIP.** The options request optional backends; actual compilation requires a compatible compiler/toolchain. Inspect CMake output and advanced capabilities rather than assuming ON created a backend.
- **Ninja reports `manifest 'build.ninja' still dirty after 100 tries` even though the system clock is correct.** A previously generated `build/full` tree can retain future-dated CMake metadata after a clock correction, VM/container snapshot restore, archive extraction, or checkout replacement. `tools/build_full_and_test.sh` now detects future-dated CMake/Ninja metadata, normalizes only those configuration timestamps, and restamps `build.ninja` after a successful configure. Ordinary source/object timestamps are not modified. If using Ninja manually instead of the wrapper, remove the affected build directory or regenerate it from a clean build tree.
- **HIP compilation reports `unknown argument: -fno-var-tracking-assignments`.** This indicates an older source tree in which a GCC-only C++ debug flag leaked into Clang/ROCm HIP compilation. Use the corrected tree, delete the affected build directory, reconfigure, and run `tools/build_full_and_test.sh --clean`. The current CMake policy gates host-only flags with `COMPILE_LANGUAGE`/`COMPILE_LANG_AND_ID`.
- **CTest reports a missing runtime artifact.** The `aesim_prepare_test_artifacts` fixture now builds the complete runtime/test artifact closure before normal tests start, including focused `ctest -R` invocations. Prefer `cmake --build build/full --target aesim_check` for a complete transaction. If the fixture fails, inspect its compiler or linker diagnostic; dependent tests are intentionally not run, preventing a misleading `FileNotFoundError` cascade.
- **Parallel CTest appears hung in PTY/UI tests.** Rerun the affected UI/PTY tranche serially. Terminal tests can contend for pseudo-terminals even when product behavior is correct.
- **Advanced motorsport command cannot be found.** Formula One and IndyCar use the C++ API/test-target model described in Chapter 10. NASCAR requests use `muzixdiagsys_advanced_platform nascar`; they are not roots in the interactive `muzixdiagsys` shell.
- **Automation exits zero despite a command error.** The batch console often continues after a handled command error. Inspect output for `error:` and verify expected artifacts/state hashes in addition to the process exit code.

# 12. Exact canonical command catalog

The following catalog is generated from the current canonical registry and then augmented with dispatcher and manual semantics. Aliases are accepted for compatibility but canonical spellings should be used in new scripts.

## Console & Session
### `bookmark`
- **Aliases:** None.
- **Exact role:** Create, annotate, navigate, delete, clear, or export stable output-record bookmarks.
- **Principal forms:** status, list, add, toggle, next, prev, delete, clear, export, latest
- **What it does:** Create, annotate, navigate, delete, clear, or export stable output-record bookmarks. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
bookmark export bookmarks.csv
```
### `command-schema`
- **Aliases:** `completion-schema`.
- **Exact role:** Inspect and validate the authoritative command/completion registry.
- **Principal forms:** status; validate; dump|paths; aliases; complete <command-prefix>
- **What it does:** status prints registry counts; validate checks canonical names, aliases, descriptions, nested contexts, and delegated industrial paths; dump/paths prints all discoverable literal paths; aliases prints accepted compatibility spellings; complete returns candidates for one prefix. These operations are read-only and can also be invoked before authentication with startup flags.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
command-schema validate
command-schema complete solver
```
### `dict`
- **Aliases:** `dictionary`.
- **Exact role:** Search the dashboard metric dictionary, including labels, units, equations, provenance, and page ownership.
- **Principal forms:** start, stop, status
- **What it does:** Passes the remaining text to the dashboard dictionary lookup. Empty input shows dictionary guidance; a term searches labels/equations/provenance; list/page forms enumerate dictionary entries.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
dict boost
```
### `docs`
- **Aliases:** `documentation`.
- **Exact role:** Generate command, dictionary, model, schema, and safety documentation artifacts.
- **Principal forms:** generate, dictionary, commands, schemas, model, docs_generated
- **What it does:** Generate command, dictionary, model, schema, and safety documentation artifacts. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::docs_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::docs_command()`.
- **Example:**
```text
docs generate
```
### `filter`
- **Aliases:** None.
- **Exact role:** Apply severity, text, case-sensitivity, or compiled field-expression filters non-destructively to structured output records.
- **Principal forms:** status, severity, text, case, clear
- **What it does:** Apply severity, text, case-sensitivity, or compiled field-expression filters non-destructively to structured output records. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
filter expr severity >= warning and subsystem == turbo
```
### `help`
- **Aliases:** `?`.
- **Exact role:** Print the complete command reference or open the modal, topic-oriented terminal help system.
- **Principal forms:** advanced; all
- **What it does:** Prints the generated help text. The command is read-only; help advanced and help all expose extended material where supported.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
help
```
### `inspect`
- **Aliases:** None.
- **Exact role:** Open or close the structured event inspector for the selected or most recent record.
- **Principal forms:** selected, latest, close
- **What it does:** Open or close the structured event inspector for the selected or most recent record. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
inspect latest
```
### `logout`
- **Aliases:** None.
- **Exact role:** End the current authenticated simulator session.
- **Principal forms:** logout
- **What it does:** The command is intercepted by the authentication console, sets the session keep-running flag to false, stops the simulator loop, joins the background thread, restores terminal state, and exits the process. It does not delete project or authentication data.
- **State and side effects:** Process/session control. It changes execution or session lifetime but does not by itself rewrite model calibration.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
logout
```
### `metrics`
- **Aliases:** `dashboard`, `dash`.
- **Exact role:** Emit the current dashboard page into the Command Activity pane; the pinned dashboard remains independently controllable.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Takes a snapshot and renders the currently selected dashboard page into the output stream. It does not toggle the pinned dashboard.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Implementation route:** `PowertrainSimulation::snapshot()`.
- **Example:**
```text
metrics status
```
### `output`
- **Aliases:** None.
- **Exact role:** Clear output or control visibility of the lower output/command pane.
- **Principal forms:** clear, pane show, pane hide, pane toggle, pane status
- **What it does:** Clear output or control visibility of the lower output/command pane. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
output pane toggle
```
### `page`
- **Aliases:** None.
- **Exact role:** List, select, or move among pinned dashboard pages.
- **Principal forms:** list, status, next, prev, main, engine, fuel, ecm, tcm, turbo, cylinders, thermal, vehicle, obd, emissions, diagnostics, energy, evap, readiness, plugins
- **What it does:** Delegates page list, next, previous, and named-page selection to the dashboard-page manager. It changes UI page selection, not physics state.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Implementation route:** `PowertrainSimulation::page_command_report()`.
- **Example:**
```text
page status
```
### `palette`
- **Aliases:** None.
- **Exact role:** Open or describe the fuzzy-searchable command palette.
- **Principal forms:** show, close
- **What it does:** Open or describe the fuzzy-searchable command palette. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
palette show
```
### `quit`
- **Aliases:** `exit`.
- **Exact role:** Exit cleanly and restore terminal modes; exit is an accepted alias.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Sets the process running flag false and exits the command loop. The background simulation thread is joined and terminal state is restored. Unlike shutdown, it does not first close the throttle or force ignition off inside the model.
- **State and side effects:** Process/session control. It changes execution or session lifetime but does not by itself rewrite model calibration.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
quit
```
### `scroll`
- **Aliases:** None.
- **Exact role:** Move through logical output records without changing the underlying scrollback.
- **Principal forms:** up, down, pageup, pagedown, top, bottom
- **What it does:** Move through logical output records without changing the underlying scrollback. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
scroll up
```
### `search`
- **Aliases:** None.
- **Exact role:** Search filtered output records and navigate matches with wraparound.
- **Principal forms:** status, next, prev, clear
- **What it does:** Search filtered output records and navigate matches with wraparound. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
search pressure
```
### `status`
- **Aliases:** None.
- **Exact role:** Print a grouped snapshot of engine, transmission, vehicle, controller, and numerical state.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Takes one coherent simulation snapshot and formats detailed engine, transmission, vehicle, controller, and diagnostic metrics. It does not advance time.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::snapshot()`.
- **Example:**
```text
status
```
### `ui`
- **Aliases:** None.
- **Exact role:** Inspect and configure dashboard visibility, lower-pane visibility, help, status bar, filters, search, watch panel, bookmarks, palette, and preferences.
- **Principal forms:** status, help, dashboard, lowerpane, statusbar, filter, search, watch, bookmark, inspect, palette, severity, prefs
- **What it does:** Inspect and configure dashboard visibility, lower-pane visibility, help, status bar, filters, search, watch panel, bookmarks, palette, and preferences. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
ui statusbar preset diagnostics
```
### `user`
- **Aliases:** `users`.
- **Exact role:** Manage the authenticated account, inspect roles and effective permissions, list users, assign roles, create accounts, enable or disable accounts, and change passwords.
- **Principal forms:** help; whoami/status; list; roles; role <username> <role...>; create <username> [--can-create-users] [--password-file <path>]; permission <username> on|off; enable|disable <username>; passwd [username] [--password-file <path>]
- **What it does:** This command is handled by the authentication layer before simulation dispatch. Read operations return identity or account data. Mutating operations write the encrypted authentication database and tamper-evident audit log after permission checks. Passwords are read without terminal echo or from owner-only files, validated, converted to salted PBKDF2-HMAC-SHA-256 verifiers, and then erased from process strings where implemented.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
user whoami
user roles
user list
```
### `watch`
- **Aliases:** None.
- **Exact role:** Configure the live watch panel, metric list, visibility, history depth, and compact sparklines.
- **Principal forms:** status, list, panel, on, off, toggle, add, remove, clear, history, rpm, torque, power, hp, boost, map, lambda, afr, coolant, oil, oil_pressure, egt, speed, acceleration, throttle, fuel_flow, bte
- **What it does:** Configure the live watch panel, metric list, visibility, history depth, and compact sparklines. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** UI/discovery state only, except export forms that write the requested file. Physics and solver state are not changed.
- **How to verify:** Use ui status, the status bar, or repeat the command’s status/list form.
- **Example:**
```text
watch add boost
```

## Diagnostics & Service
### `audit`
- **Aliases:** None.
- **Exact role:** Inspect the simulator engineering/security audit report.
- **Principal forms:** audit
- **What it does:** Calls the simulation audit reporter and prints the current audit evidence. It does not alter plant state. Authentication and engineering-tool audit logs are separate persistent chains and are accessed by their own commands.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::audit_report()`.
- **Example:**
```text
audit
```
### `causal`
- **Aliases:** `cause`, `causal-graph`.
- **Exact role:** Build and interrogate a provenance-aware diagnostic causal graph.
- **Principal forms:** status; load/save; node/edge operations; validate; explain; impact; export
- **What it does:** Routes arguments to the causal-graph subsystem. Graph-editing forms change the in-memory or persisted causal model; explanation and impact forms traverse causes, symptoms, evidence, and interventions without changing plant state.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::causal_graph_command()`.
- **Example:**
```text
causal status
```
### `diagbus`
- **Aliases:** None.
- **Exact role:** Compatibility root for the authoritative diagnostic transport facade.
- **Principal forms:** status; topology; json; elm ...; obd <ecu> <request>; uds <ecu> <request>; doip <logical-address> <payload>; sovd <method> <resource> [body]
- **What it does:** Prepends the selected transport operation and routes it through the same multi-ECU DiagnosticService used by diagnostics, elm, doip, and sovd. It does not create a second diagnostic state; clear operations therefore affect the same DTC memory.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::diagnostic_transport_command()`.
- **Example:**
```text
diagbus topology
diagbus uds powertrain 22F190
```
### `diagnose`
- **Aliases:** `advisor`.
- **Exact role:** Run symptom-oriented diagnostic reasoning over current simulator state.
- **Principal forms:** current, lean, rich, overboost, low_power, misfire, catalyst, knock
- **What it does:** Run symptom-oriented diagnostic reasoning over current simulator state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnose_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::diagnose_command()`.
- **Example:**
```text
diagnose current
```
### `diagnostics`
- **Aliases:** None.
- **Exact role:** Preserve the legacy diagnostic decision tree while exposing the authoritative multi-ECU OBD, UDS, DoIP, SOVD, topology, and ELM327-compatible services.
- **Principal forms:** status, topology, json, obd, uds, elm, doip, sovd; ECU names powertrain, transmission, brakes, battery, body.
- **What it does:** Preserve the legacy diagnostic decision tree while exposing the authoritative multi-ECU OBD, UDS, DoIP, SOVD, topology, and ELM327-compatible services. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnose_command(), PowertrainSimulation::diagnostic_transport_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::diagnose_command()`, `PowertrainSimulation::diagnostic_transport_command()`.
- **Example:**
```text
diagnostics
diagnostics topology
diagnostics json
diagnostics obd powertrain 010C
diagnostics uds powertrain 22F190
diagnostics doip 10 22F190
diagnostics sovd GET /entities
```
### `doctor`
- **Aliases:** None.
- **Exact role:** Run environment, resource, configuration, and runtime diagnostics.
- **Principal forms:** verbose, --verbose
- **What it does:** Run environment, resource, configuration, and runtime diagnostics. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::doctor_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::doctor_command()`.
- **Example:**
```text
doctor verbose
```
### `doip`
- **Aliases:** None.
- **Exact role:** Route a UDS payload by DoIP logical address through the same diagnostic service used by CAN-facing paths.
- **Principal forms:** Logical addresses 10, 18, 28, 30, 40 and UDS hexadecimal payloads such as 22F190.
- **What it does:** Route a UDS payload by DoIP logical address through the same diagnostic service used by CAN-facing paths. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnostic_transport_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::diagnostic_transport_command()`.
- **Example:**
```text
doip 10 22F190
```
### `dtc`
- **Aliases:** None.
- **Exact role:** Inspect active/history/freeze-frame records, clear memory, or inject a diagnostic trouble code.
- **Principal forms:** active, freeze, history, clear, inject, P0420, P0301, P0302, P0442, P0455, P0741, P0868
- **What it does:** active prints active codes; freeze/history optionally filters freeze-frame records by code; clear removes one code or all supported memory; inject creates a code with a freeze frame and optional meaning. The P0420 shorthand prints an explanation only.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::dtc_active_report()`, `PowertrainSimulation::dtc_clear()`, `PowertrainSimulation::dtc_freeze_report()`, `PowertrainSimulation::dtc_inject()`.
- **Example:**
```text
dtc active
```
### `elm`
- **Aliases:** None.
- **Exact role:** Operate the stateful ELM327-compatible virtual adapter against the authoritative virtual vehicle.
- **Principal forms:** ATZ, ATWS, ATI, ATD, ATE0|1, ATH0|1, ATS0|1, ATL0|1, ATSP0, ATDP, ATDPN, ATSH..., OBD hexadecimal requests, and supported UDS-style payloads.
- **What it does:** Operate the stateful ELM327-compatible virtual adapter against the authoritative virtual vehicle. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnostic_transport_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::diagnostic_transport_command()`.
- **Example:**
```text
elm ATZ
elm ATH1
elm ATSH7E0
elm 010C
```
### `monitor`
- **Aliases:** None.
- **Exact role:** Enable or disable the legacy monitoring stream where supported.
- **Principal forms:** on, off
- **What it does:** Enable or disable the legacy monitoring stream where supported. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
monitor on
```
### `readiness`
- **Aliases:** None.
- **Exact role:** Inspect, reset, or drive the simulated OBD readiness monitors.
- **Principal forms:** status, reset, drive_cycle
- **What it does:** Inspect, reset, or drive the simulated OBD readiness monitors. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::readiness_report(), PowertrainSimulation::readiness_reset(), PowertrainSimulation::run_drive_cycle(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::readiness_report()`, `PowertrainSimulation::readiness_reset()`, `PowertrainSimulation::run_drive_cycle()`.
- **Example:**
```text
readiness status
```
### `repair`
- **Aliases:** None.
- **Exact role:** Clear supported legacy convenience faults and restore nominal components.
- **Principal forms:** all
- **What it does:** With no operand or all, services all durability surfaces, resets the oil model, and clears repairable failures. Other operands are rejected in the main dispatcher.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::oil_command()`, `PowertrainSimulation::wear_command()`.
- **Example:**
```text
repair
```
### `sovd`
- **Aliases:** None.
- **Exact role:** Access SOVD-style entity, fault, data, and operation resources backed by authoritative diagnostic state.
- **Principal forms:** GET, POST, DELETE, /entities, and entity paths for powertrain, transmission, brakes, battery, and body.
- **What it does:** Access SOVD-style entity, fault, data, and operation resources backed by authoritative diagnostic state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnostic_transport_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::diagnostic_transport_command()`.
- **Example:**
```text
sovd GET /entities
sovd GET /entities/powertrain
```
### `workflow`
- **Aliases:** `diagnostic-workflow`.
- **Exact role:** Run stateful guided diagnostic test plans.
- **Principal forms:** list; load/start; status; step/measure; evidence; repair; verify; report
- **What it does:** Routes arguments to the diagnostic workflow engine. The engine advances a test-plan state machine, evaluates expected ranges, records evidence and provenance, follows branches, records repairs, verifies outcomes, and can emit a report. It changes workflow/evidence state but does not silently change plant physics unless a requested repair or test action does so.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::workflow_command()`.
- **Example:**
```text
workflow list
```

## Engine & Powertrain
### `accessory`
- **Aliases:** `accessories`.
- **Exact role:** Apply or inspect air-conditioning and electrical accessory loads.
- **Principal forms:** status, ac, on, off, electrical
- **What it does:** Apply or inspect air-conditioning and electrical accessory loads. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::accessory_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::accessory_command()`.
- **Example:**
```text
accessory status
```
### `actuator`
- **Aliases:** `actuators`.
- **Exact role:** Inspect, inject, and repair actuator authority, rate, or stuck faults.
- **Principal forms:** status, fault, repair, throttle, wastegate, egr, authority, rate, stuck
- **What it does:** Inspect, inject, and repair actuator authority, rate, or stuck faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::actuator_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::actuator_command()`.
- **Example:**
```text
actuator status
```
### `airpath`
- **Aliases:** `air`.
- **Exact role:** Configure dynamic manifold filling, VVT, EGR, intercooling, and air-path fidelity.
- **Principal forms:** status, mode, dynamic, instant, vvt, egr, intercooler
- **What it does:** Configure dynamic manifold filling, VVT, EGR, intercooling, and air-path fidelity. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::airpath_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::airpath_command()`.
- **Example:**
```text
airpath status
```
### `ambient`
- **Aliases:** `environment`, `weather`.
- **Exact role:** Inspect or set temperature, pressure, humidity, altitude, and wind boundary conditions.
- **Principal forms:** status, temperature, pressure, humidity, altitude, wind
- **What it does:** Inspect or set temperature, pressure, humidity, altitude, and wind boundary conditions. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::environment_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::environment_command()`.
- **Example:**
```text
ambient status
```
### `cal`
- **Aliases:** `calibration`.
- **Exact role:** Operate the calibration facade, including named calibrations and map workflows.
- **Principal forms:** status; reset; stock|economy|sport|track|valet|limp; set; fit; dyno; telemetry; map list|inspect|sample|load|export; import; validate
- **What it does:** Delegates to the calibration subsystem. Profile and set/import/load/fit forms replace bounded calibration values or maps. Sampling, status, inspection, and validation forms are read-only. Calibration changes affect subsequent controller and plant calculations and are journaled when command-state hashing is enabled.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::cal_command()`.
- **Example:**
```text
cal status
cal sport
cal validate
```
### `calibrate`
- **Aliases:** None.
- **Exact role:** Provide workflow-oriented wrappers around fitting and optimization operations.
- **Principal forms:** status, fit, research, dyno, telemetry, optimize, torque, economy, calibration
- **What it does:** Provide workflow-oriented wrappers around fitting and optimization operations. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::calibrate_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::calibrate_command()`.
- **Example:**
```text
calibrate status
```
### `catalyst`
- **Aliases:** `cat`.
- **Exact role:** Inspect or force catalyst aging, oxygen-storage state, capacity, and export.
- **Principal forms:** status, aging, oxygen, capacity, export
- **What it does:** Inspect or force catalyst aging, oxygen-storage state, capacity, and export. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::catalyst_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::catalyst_command()`.
- **Example:**
```text
catalyst status
```
### `coldstart`
- **Aliases:** `cold_start`.
- **Exact role:** Report cold-start battery, cranking, viscosity, enrichment, and warm-up behavior.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Report cold-start battery, cranking, viscosity, enrichment, and warm-up behavior. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::cold_start_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::cold_start_report()`.
- **Example:**
```text
coldstart
```
### `combustion`
- **Aliases:** None.
- **Exact role:** Select combustion fidelity and configure spark, burn duration, zones, residual/EGR fraction, knock model, and traces.
- **Principal forms:** status, mode, wiebe, map, spark, burn, step
- **What it does:** Select combustion fidelity and configure spark, burn duration, zones, residual/EGR fraction, knock model, and traces. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::combustion_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::combustion_command()`.
- **Example:**
```text
combustion model multi_zone
```
### `control`
- **Aliases:** `controller`.
- **Exact role:** Configure state-space/PID-style boost, lambda, and idle controllers and inspect step response.
- **Principal forms:** status, boost, lambda, idle, on, off, target, matrix, step-response, reset
- **What it does:** Configure state-space/PID-style boost, lambda, and idle controllers and inspect step response. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::control_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::control_command()`.
- **Example:**
```text
control status
```
### `cyl`
- **Aliases:** `cylinder`.
- **Exact role:** Inspect cylinder balance and run contribution, compression, leakdown, failure, repair, and export operations.
- **Principal forms:** status, balance, contribution, compression_test, leakdown_test, export, repair, 1, 2, 3, 4, fail, coil, injector, compression, valve, knock, preignition
- **What it does:** Inspect cylinder balance and run contribution, compression, leakdown, failure, repair, and export operations. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::cylinder_export(), PowertrainSimulation::cylinder_fail(), PowertrainSimulation::cylinder_repair(), PowertrainSimulation::cylinder_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::cylinder_export()`, `PowertrainSimulation::cylinder_fail()`, `PowertrainSimulation::cylinder_repair()`, `PowertrainSimulation::cylinder_report()`.
- **Example:**
```text
cyl status
```
### `dyno`
- **Aliases:** None.
- **Exact role:** Run a deterministic full-load engine-speed sweep and report torque and power.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Runs the deterministic full-load dyno sweep against the active engine, calibration, fuel, and model fidelity, then prints the generated table. It may advance temporary evaluation state but is intended as an analysis operation.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::dyno_sweep()`.
- **Example:**
```text
dyno
```
### `ecm`
- **Aliases:** None.
- **Exact role:** Inspect and configure ECM operating modes, targets, sensors, actuators, and resets.
- **Principal forms:** status, mode, stock, sport, closed_loop, open_loop, limp, target, lambda, boost, torque, knock, sensors, actuators, reset
- **What it does:** Inspect and configure ECM operating modes, targets, sensors, actuators, and resets. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::ecm_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::ecm_command()`.
- **Example:**
```text
ecm status
```
### `ecu`
- **Aliases:** None.
- **Exact role:** Configure the torque-based ECU strategy, pedal maps, targets, spark strategy, and active limiters.
- **Principal forms:** status, report, mode, stock, sport, closed_loop, open_loop, limp, torque_model, pedal_map, linear, eco, target, lambda, boost, torque, knock, spark_strategy, limiter, list, on, off, reset
- **What it does:** Configure the torque-based ECU strategy, pedal maps, targets, spark strategy, and active limiters. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::ecu_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::ecu_command()`.
- **Example:**
```text
ecu status
```
### `emissions`
- **Aliases:** `emission`.
- **Exact role:** Inspect and configure aftertreatment fidelity, aging, oxygen storage, capacity, cycles, and exports.
- **Principal forms:** status, model, thermal, aftertreatment, research, aging, oxygen, capacity, cycle, export
- **What it does:** Inspect and configure aftertreatment fidelity, aging, oxygen storage, capacity, cycles, and exports. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::emissions_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::emissions_command()`.
- **Example:**
```text
emissions model research
```
### `energy`
- **Aliases:** None.
- **Exact role:** Report or export first-law energy-flow and closure accounting.
- **Principal forms:** export
- **What it does:** Report or export first-law energy-flow and closure accounting. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::energy_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::energy_report()`.
- **Example:**
```text
energy export
```
### `engine`
- **Aliases:** None.
- **Exact role:** List, inspect, or apply an engine preset with associated geometry, breathing, torque, and control calibration.
- **Principal forms:** list, status, and the following canonical keys and aliases: - vw_gti_2.0_tsi_ea888_evo4, vw_golf_r_2.0_tsi_ea888_evo4, audi_s3_2.0_tfsi, audi_rs3_2.5_tfsi, audi_s4_3.0_tfsi - ford_mustang_gt_5.0_coyote, ford_mustang_dark_horse_5.0, ford_f150_3.5_ecoboost - gm_corvette_c8_lt2, gm_camaro_ss_lt1, gm_camaro_zl1_lt4 - toyota_gr_corolla_g16e_gts, honda_civic_type_r_k20c1, bmw_m3_competition_s58, mazda_mx5_skyactiv_g_2.0 - ram_hurricane_ho_3.0, gm_duramax_lz0_3.0, porsche_911_carrera_3.0_boxer, subaru_wrx_fa24_dit - gti, golf_r, rs3, s4, mustang, f150, corvette, camaro, zl1, gr_corolla, g16e, type_r, k20c1, m3, s58, mx5, miata, hurricane, duramax, lz0, 911, carrera, wrx, fa24
- **What it does:** List, inspect, or apply an engine preset with associated geometry, breathing, torque, and control calibration. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::apply_engine_preset(), PowertrainSimulation::engine_map_command(), PowertrainSimulation::engine_report(), PowertrainSimulation::list_engine_presets(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::apply_engine_preset()`, `PowertrainSimulation::engine_map_command()`, `PowertrainSimulation::engine_report()`, `PowertrainSimulation::list_engine_presets()`.
- **Example:**
```text
engine list
```
### `engines`
- **Aliases:** None.
- **Exact role:** List all installed engine presets.
- **Principal forms:** engines
- **What it does:** Prints the engine preset catalog and rated-data provenance. Unlike engine <preset>, it does not change the active engine.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::list_engine_presets()`.
- **Example:**
```text
engines
```
### `evap`
- **Aliases:** None.
- **Exact role:** Inspect and configure purge operation and EVAP leak/stuck faults.
- **Principal forms:** status, purge, auto, on, off, fail, leak, stuck_open, stuck_closed, repair
- **What it does:** Inspect and configure purge operation and EVAP leak/stuck faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::evap_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::evap_command()`.
- **Example:**
```text
evap status
```
### `friction`
- **Aliases:** `fmep`.
- **Exact role:** Report modeled friction mean effective pressure and parasitic-loss contributions.
- **Principal forms:** status
- **What it does:** Report modeled friction mean effective pressure and parasitic-loss contributions. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::friction_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::friction_command()`.
- **Example:**
```text
friction status
```
### `fuel`
- **Aliases:** None.
- **Exact role:** Select fuel chemistry or configure the low/high-pressure fuel delivery model.
- **Principal forms:** gasoline, e85, race, diesel, system, rail, pump, injector, ethanol, fault, repair
- **What it does:** Select fuel chemistry or configure the low/high-pressure fuel delivery model. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::current_fuel_properties_report(), PowertrainSimulation::fuel_system_command(), PowertrainSimulation::fuel_tank_command(), PowertrainSimulation::set_custom_fuel_command(), PowertrainSimulation::set_fuel(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::current_fuel_properties_report()`, `PowertrainSimulation::fuel_system_command()`, `PowertrainSimulation::fuel_tank_command()`, `PowertrainSimulation::set_custom_fuel_command()`, `PowertrainSimulation::set_fuel()`.
- **Example:**
```text
fuel gasoline
```
### `fuelprops`
- **Aliases:** None.
- **Exact role:** Show thermochemical and combustion properties for the active fuel.
- **Principal forms:** fuelprops
- **What it does:** Reads the currently selected fuel object and reports properties such as stoichiometric ratio, density, heating value, ethanol content, and modeled combustion implications. It does not change calibration.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::current_fuel_properties_report()`.
- **Example:**
```text
fuelprops
```
### `fuels`
- **Aliases:** None.
- **Exact role:** List the installed fuel catalog and modeled fuel choices.
- **Principal forms:** fuels
- **What it does:** Generates the fuel catalog report from the active simulator build. It is read-only and does not select a fuel.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::fuel_catalog_report()`.
- **Example:**
```text
fuels
```
### `identify`
- **Aliases:** None.
- **Exact role:** Estimate physical or calibration parameters from dyno, telemetry, or coastdown data.
- **Principal forms:** fit, dyno, telemetry, friction, report
- **What it does:** Estimate physical or calibration parameters from dyno, telemetry, or coastdown data. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::identify_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::identify_command()`.
- **Example:**
```text
identify report
```
### `ignition`
- **Aliases:** None.
- **Exact role:** Enable or disable ignition/combustion authority.
- **Principal forms:** on, off
- **What it does:** on or off changes combustion authority only. It does not crank the engine and does not automatically start or stop the loop.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::set_ignition()`.
- **Example:**
```text
ignition on
```
### `key`
- **Aliases:** None.
- **Exact role:** Set the simulated ignition-key state to off, run, or start.
- **Principal forms:** accessory; off; on; start
- **What it does:** off disables ignition and starter; run/on enables ignition and releases the starter; start enables both, performs fifty 0.01-second updates, then releases the starter.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::set_ignition()`, `PowertrainSimulation::set_starter()`, `PowertrainSimulation::update()`.
- **Example:**
```text
key
```
### `knock`
- **Aliases:** `preignition`.
- **Exact role:** Configure octane, spark, knock/pre-ignition control, and diagnostic export.
- **Principal forms:** status, octane, spark, control, on, off, export
- **What it does:** Configure octane, spark, knock/pre-ignition control, and diagnostic export. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::knock_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::knock_command()`.
- **Example:**
```text
knock status
```
### `map`
- **Aliases:** None.
- **Exact role:** List, inspect, sample, import where supported, or export multidimensional calibration maps.
- **Principal forms:** list, inspect, sample, export, bmep, torque, bsfc, ve, egt, mfb50
- **What it does:** List, inspect, sample, import where supported, or export multidimensional calibration maps. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::map_export_csv(), PowertrainSimulation::map_inspect_report(), PowertrainSimulation::map_list_report(), PowertrainSimulation::map_load_csv(), PowertrainSimulation::map_sample_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::map_export_csv()`, `PowertrainSimulation::map_inspect_report()`, `PowertrainSimulation::map_list_report()`, `PowertrainSimulation::map_load_csv()`, `PowertrainSimulation::map_sample_report()`.
- **Example:**
```text
map list
```
### `oil`
- **Aliases:** `lubrication`.
- **Exact role:** Inspect and configure lubricant viscosity, level, faults, and reset behavior.
- **Principal forms:** status, viscosity, 5w30, 5w40, level, fault, low_level, pump_wear, filter_restriction, reset
- **What it does:** Inspect and configure lubricant viscosity, level, faults, and reset behavior. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::oil_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::oil_command()`.
- **Example:**
```text
oil status
```
### `params`
- **Aliases:** None.
- **Exact role:** List runtime-settable scalar parameters and their accepted names.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Prints the authoritative list of runtime-settable scalar parameters and their current values. It is read-only.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
params
```
### `sensor`
- **Aliases:** `sensors`.
- **Exact role:** Inspect, inject, and repair sensor bias, noise, lag, dropout, or stuck faults.
- **Principal forms:** status, fault, repair, rpm, map, maf, lambda, coolant, oil_pressure, throttle, speed, bias, noise, lag, dropout, stuck
- **What it does:** Inspect, inject, and repair sensor bias, noise, lag, dropout, or stuck faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::sensor_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::sensor_command()`.
- **Example:**
```text
sensor status
```
### `set`
- **Aliases:** None.
- **Exact role:** Set a named runtime parameter after type, range, and finite-value validation.
- **Principal forms:** names printed by params, including engine geometry/limits, transmission ratios, and vehicle road-load, mass, speed-envelope, accessory, wheelbase, and CG parameters.
- **What it does:** Parses a parameter key and finite numeric value, validates it against the parameter registry and range rules, and applies it only on success.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::set_parameter()`.
- **Example:**
```text
set engine.redline_rpm 6500
set vehicle.half_pedal_target_kmh 148
set vehicle.accessory_power_kw 1.7
```
### `shutdown`
- **Aliases:** None.
- **Exact role:** Stop combustion and place the powertrain in a safe shutdown state.
- **Principal forms:** engine
- **What it does:** Sets throttle to zero, releases the starter, disables ignition, and stops the continuous loop. Model state remains available for inspection or restart.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::set_ignition()`, `PowertrainSimulation::set_starter()`, `PowertrainSimulation::set_throttle()`.
- **Example:**
```text
shutdown
```
### `soak`
- **Aliases:** None.
- **Exact role:** Apply a bounded cold-soak duration to thermal state.
- **Principal forms:** 12h; 1h; 24h; 4h; 8h
- **What it does:** Apply a bounded cold-soak duration to thermal state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::cold_soak(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::cold_soak()`.
- **Example:**
```text
soak
```
### `start`
- **Aliases:** None.
- **Exact role:** Apply the simulator start convenience sequence.
- **Principal forms:** engine
- **What it does:** Enables ignition and starter, performs fifty 0.01-second model updates (0.5 simulated seconds), and releases the starter. It does not enable the continuous loop.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::set_ignition()`, `PowertrainSimulation::set_starter()`, `PowertrainSimulation::update()`.
- **Example:**
```text
start
```
### `starter`
- **Aliases:** None.
- **Exact role:** Enable or disable starter torque independently of ignition.
- **Principal forms:** on, off
- **What it does:** on or off changes starter torque authority only. Leaving it on can continue cranking on later steps; key start, start, and quickstart release it automatically.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::set_starter()`.
- **Example:**
```text
starter on
```
### `thermal`
- **Aliases:** `thermalnet`, `thermal_network`.
- **Exact role:** Inspect and configure thermal-network fidelity, fan, pump, exchangers, aging, fouling, service, and export.
- **Principal forms:** status, report, model, simple, network, fan, auto, on, off, radiator, oil_cooler, intercooler, export
- **What it does:** Inspect and configure thermal-network fidelity, fan, pump, exchangers, aging, fouling, service, and export. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::thermal_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::thermal_command()`.
- **Example:**
```text
thermal model network
```
### `throttle`
- **Aliases:** `thr`.
- **Exact role:** Set or increment driver accelerator demand using normalized or percentage input.
- **Principal forms:** 0; 100; 25; 50; 75
- **What it does:** Accepts normalized 0..1 or percent 0..100 input. Absolute form sets demand; up/down changes demand by the supplied delta or ten percentage points. It prints a readiness warning when the loop is stopped. The value affects future integration only.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::set_throttle()`, `PowertrainSimulation::snapshot()`.
- **Example:**
```text
throttle 65
```
### `turbo`
- **Aliases:** None.
- **Exact role:** Inspect and configure compressor/turbine maps, boost target, intercooler, VVT/EGR interaction, and exports.
- **Principal forms:** status, report, load, loadmap, compressor, turbine, boost_target, intercooler, vvt, egr, export, data/sample_compressor_map.csv, data/sample_turbine_map.csv
- **What it does:** Inspect and configure compressor/turbine maps, boost target, intercooler, VVT/EGR interaction, and exports. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::turbo_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::turbo_command()`.
- **Example:**
```text
turbo status
```
### `validate`
- **Aliases:** None.
- **Exact role:** Run built-in, CSV-based, formal suite, or research validation and export reports.
- **Principal forms:** suite, research, export
- **What it does:** With no operand, compares against built-in dyno points; with a CSV path, loads rpm/torque and optional horsepower observations; suite runs the formal multi-domain suite; export writes the latest validation report; golden routes to golden-vector validation.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::built_in_dyno_points()`, `PowertrainSimulation::export_validation_report()`, `PowertrainSimulation::formal_validation_suite()`, `PowertrainSimulation::golden_validation_command()`, `PowertrainSimulation::validate_against()`.
- **Example:**
```text
validate suite
```
### `ve`
- **Aliases:** `vemap`.
- **Exact role:** Load, inspect, sample, export, or reset the volumetric-efficiency map.
- **Principal forms:** status, load, sample, export, reset, data/sample_ve_map.csv
- **What it does:** Load, inspect, sample, export, or reset the volumetric-efficiency map. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::ve_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::ve_command()`.
- **Example:**
```text
ve status
```

## Engineering Lifecycle
### `branch`
- **Aliases:** None.
- **Exact role:** Create, load, compare, list, or erase named in-memory state branches.
- **Principal forms:** list, create, load, compare, erase, baseline, candidate
- **What it does:** Create, load, compare, list, or erase named in-memory state branches. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::branch_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::branch_command()`.
- **Example:**
```text
branch list
```
### `checkpoint`
- **Aliases:** None.
- **Exact role:** Save, load, inspect, and verify complete simulator state images.
- **Principal forms:** status, save, load, verify, inspect, full_state.aecp
- **What it does:** Save, load, inspect, and verify complete simulator state images. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::checkpoint_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::checkpoint_command()`.
- **Example:**
```text
checkpoint save baseline.aecp
```
### `config`
- **Aliases:** None.
- **Exact role:** Check, migrate, compare, or upgrade supported configuration documents.
- **Principal forms:** migrate, check-version, diff, upgrade-all, data/scenario_example.yaml
- **What it does:** Check, migrate, compare, or upgrade supported configuration documents. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::config_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::config_command()`.
- **Example:**
```text
config migrate
```
### `dataset`
- **Aliases:** None.
- **Exact role:** List signals, calculate current snapshot statistics, and export CSV, JSON, or Markdown datasets.
- **Principal forms:** status, channels, stats, export, csv, json, markdown
- **What it does:** List signals, calculate current snapshot statistics, and export CSV, JSON, or Markdown datasets. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::dataset_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::dataset_command()`.
- **Example:**
```text
dataset status
```
### `experiment`
- **Aliases:** `provenance`.
- **Exact role:** Begin/end provenance sessions and record events and artifacts with hashes.
- **Principal forms:** status, begin, event, artifact, end, abort, verify
- **What it does:** Begin/end provenance sessions and record events and artifacts with hashes. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::experiment_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::experiment_command()`.
- **Example:**
```text
experiment status
```
### `fit`
- **Aliases:** None.
- **Exact role:** Fit selected calibration parameters to dyno or telemetry observations.
- **Principal forms:** status, dyno, telemetry, data/sample_dyno.csv, data/vw_gti_ea888_evo4_dyno.csv
- **What it does:** Fit selected calibration parameters to dyno or telemetry observations. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::built_in_dyno_points(), PowertrainSimulation::calibration_report(), PowertrainSimulation::fit_dyno(), PowertrainSimulation::fit_telemetry(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::built_in_dyno_points()`, `PowertrainSimulation::calibration_report()`, `PowertrainSimulation::fit_dyno()`, `PowertrainSimulation::fit_telemetry()`.
- **Example:**
```text
fit status
```
### `health`
- **Aliases:** `numerical-health`.
- **Exact role:** Inspect, configure, reset, or export rolling conservation, solver, deadline, and validity health state.
- **Principal forms:** status, report, reset, json, limits, health.json
- **What it does:** Inspect, configure, reset, or export rolling conservation, solver, deadline, and validity health state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::health_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::health_command()`.
- **Example:**
```text
health status
```
### `journal`
- **Aliases:** None.
- **Exact role:** Record commands and results to JSONL, replay them, or export an executable command script.
- **Principal forms:** start, stop, status, replay, export-script, session_journal.jsonl, journal_replay.csv
- **What it does:** Record commands and results to JSONL, replay them, or export an executable command script. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::journal_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::journal_command()`.
- **Example:**
```text
journal status
```
### `loadmap`
- **Aliases:** None.
- **Exact role:** Load compatible calibration or turbo map data through the retained convenience command.
- **Principal forms:** bmep; bsfc; egt; mfb50; torque; ve
- **What it does:** Loads a named calibration map from a CSV file through the map loader. The loader validates the file and replaces that map only when loading succeeds.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::map_load_csv()`.
- **Example:**
```text
loadmap
```
### `log`
- **Aliases:** None.
- **Exact role:** Configure channels, record bounded time-series data, inspect statistics, and export CSV/JSONL/Markdown logs.
- **Principal forms:** status, start, stop, clear, channels, add, remove, set, stats, max, export, csv, jsonl, markdown
- **What it does:** Configure channels, record bounded time-series data, inspect statistics, and export CSV/JSONL/Markdown logs. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::log_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::log_command()`.
- **Example:**
```text
log start 200
```
### `montecarlo`
- **Aliases:** `mc`.
- **Exact role:** Run deterministic seeded parameter-variation trials and export statistical outcomes.
- **Principal forms:** 25, 100, data/mc_results.csv
- **What it does:** Run deterministic seeded parameter-variation trials and export statistical outcomes. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::run_monte_carlo(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::run_monte_carlo()`.
- **Example:**
```text
montecarlo 25
```
### `project`
- **Aliases:** `workspace`.
- **Exact role:** Create and manage portable .muzixproj engineering workspaces.
- **Principal forms:** create; open/load; status; resources; topology; faults; checkpoints; artifacts; save/export forms
- **What it does:** Routes arguments to the project subsystem. Project commands create or update a versioned workspace containing manifest metadata, referenced resources, topology, fault definitions, checkpoints, and generated artifacts. File-writing forms persist atomically; status/list forms are read-only.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::project_command()`.
- **Example:**
```text
project status
```
### `replay`
- **Aliases:** None.
- **Exact role:** Record, save, execute, hash, and verify deterministic command/state replay artifacts.
- **Principal forms:** status, hash, start, stop, save, run, verify, session.aereplay
- **What it does:** Record, save, execute, hash, and verify deterministic command/state replay artifacts. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::deterministic_replay_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::deterministic_replay_command()`.
- **Example:**
```text
replay start run.aereplay
```
### `report`
- **Aliases:** None.
- **Exact role:** Generate a human-readable session report.
- **Principal forms:** session
- **What it does:** Generate a human-readable session report. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::diagnose_command(), PowertrainSimulation::dtc_active_report(), PowertrainSimulation::dyno_sweep(), PowertrainSimulation::energy_report(), PowertrainSimulation::formal_validation_suite(), PowertrainSimulation::snapshot(), PowertrainSimulation::validate_against(), PowertrainSimulation::write_session_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::diagnose_command()`, `PowertrainSimulation::dtc_active_report()`, `PowertrainSimulation::dyno_sweep()`, `PowertrainSimulation::energy_report()`, `PowertrainSimulation::formal_validation_suite()`, `PowertrainSimulation::snapshot()`, `PowertrainSimulation::validate_against()`, `PowertrainSimulation::write_session_report()`.
- **Example:**
```text
report session
```
### `requirements`
- **Aliases:** None.
- **Exact role:** Load, inspect, trace, or validate requirements and associated test evidence.
- **Principal forms:** clear; coverage; evidence; load; load-requirements; load-tests; matrix; save; status
- **What it does:** Load, inspect, trace, or validate requirements and associated test evidence. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
requirements
```
### `scenario`
- **Aliases:** None.
- **Exact role:** Validate, generate, or execute formal YAML/JSON experiment manifests.
- **Principal forms:** run, validate, template, data/scenario_example.yaml, data/scenario_example.json, studies/scenario_run
- **What it does:** Validate, generate, or execute formal YAML/JSON experiment manifests. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::run_scenario_manifest(), PowertrainSimulation::schema_validate(), PowertrainSimulation::write_scenario_template(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::run_scenario_manifest()`, `PowertrainSimulation::schema_validate()`, `PowertrainSimulation::write_scenario_template()`.
- **Example:**
```text
scenario validate data/scenario_example.yaml
```
### `scenario2`
- **Aliases:** `declarative-scenario`.
- **Exact role:** Validate and run versioned declarative scenarios with events, ramps, stop conditions, and temporal assertions.
- **Principal forms:** validate, run, data/professional_scenario.yaml, scenario_result.json
- **What it does:** Validate and run versioned declarative scenarios with events, ramps, stop conditions, and temporal assertions. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::scenario_v2_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::scenario_v2_command()`.
- **Example:**
```text
scenario2 validate data/professional_scenario.yaml
```
### `schema`
- **Aliases:** None.
- **Exact role:** Validate supported scenario, plugin, telemetry, calibration, and vehicle documents or dump schemas.
- **Principal forms:** validate, dump, scenario, plugin, telemetry, calibration, vehicle, powertrain_catalog, data/scenario_example.yaml, plugins/calibration_stage1.plugin, data/sample_telemetry.csv, configs/powertrain_catalog.yaml
- **What it does:** Validate supported scenario, plugin, telemetry, calibration, and vehicle documents or dump schemas. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::schema_dump(), PowertrainSimulation::schema_validate(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::schema_dump()`, `PowertrainSimulation::schema_validate()`.
- **Example:**
```text
schema validate
```
### `schema2`
- **Aliases:** `versioned-schema`.
- **Exact role:** List, validate, migrate, and dump versioned professional schemas.
- **Principal forms:** list, validate, migrate, dump, aesim.config, aesim.calibration, aesim.checkpoint, aesim.scenario
- **What it does:** List, validate, migrate, and dump versioned professional schemas. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::schema_v2_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::schema_v2_command()`.
- **Example:**
```text
schema2 list
```
### `stability`
- **Aliases:** `invariants`.
- **Exact role:** Audit numerical and physical invariants and export the findings.
- **Principal forms:** status, audit, check, report, export
- **What it does:** Audit numerical and physical invariants and export the findings. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::stability_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::stability_command()`.
- **Example:**
```text
stability status
```
### `state`
- **Aliases:** None.
- **Exact role:** Save, load, diff, report, or replay portable simulator-state documents.
- **Principal forms:** save, load, diff, replay, status, state_a.json, state_b.json, state_replay.csv
- **What it does:** Save, load, diff, report, or replay portable simulator-state documents. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::state_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::state_command()`.
- **Example:**
```text
state status
```
### `studio`
- **Aliases:** None.
- **Exact role:** Operate the integrated Engineering Studio command surface.
- **Principal forms:** status; action; signals; timeline; debug; contracts; validation; minimize; capsule; calibration; topology; performance; confidence; manufacturing
- **What it does:** The main loop pauses continuous integration while each studio action executes, then restores the prior loop state. Studio operations use synchronized runtime bindings for state capture/restore, signal capture, state hashing, command execution, and deterministic stepping. They can create checkpoints, reverse or advance time, edit calibration/topology, evaluate contracts, minimize failures, and package replayable bug capsules.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
studio status
studio signals list
studio timeline status
```
### `study`
- **Aliases:** None.
- **Exact role:** Run a scenario and create a reproducible study directory containing inputs, outputs, metadata, and reports.
- **Principal forms:** run, data/scenario_example.yaml, studies/example_study
- **What it does:** Run a scenario and create a reproducible study directory containing inputs, outputs, metadata, and reports. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::study_run(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::study_run()`.
- **Example:**
```text
study run
```
### `sweep`
- **Aliases:** None.
- **Exact role:** Run deterministic throttle or spark design-of-experiments sweeps.
- **Principal forms:** status, throttle, spark, 0, 100, 8, 0.05, sweep.csv
- **What it does:** Run deterministic throttle or spark design-of-experiments sweeps. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::sweep_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::sweep_command()`.
- **Example:**
```text
sweep status
```
### `traceability`
- **Aliases:** None.
- **Exact role:** Inspect digital-thread links among requirements, tests, evidence, models, and artifacts.
- **Principal forms:** clear; coverage; evidence; load; load-requirements; load-tests; matrix; save; status
- **What it does:** Inspect digital-thread links among requirements, tests, evidence, models, and artifacts. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
traceability
```
### `uncertainty`
- **Aliases:** None.
- **Exact role:** Perform Monte Carlo, Sobol-style sensitivity, and research uncertainty analyses.
- **Principal forms:** montecarlo, sobol, research, report
- **What it does:** Perform Monte Carlo, Sobol-style sensitivity, and research uncertainty analyses. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::uncertainty_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::uncertainty_command()`.
- **Example:**
```text
uncertainty report
```
### `units`
- **Aliases:** `unit`.
- **Exact role:** Operate the units command family in the compatibility and specialized operations surface. The command is retained as an executable compatibility or specialized entry point and is validated by the same parser, structured logging, and error-reporting path as the primary command families.
- **Principal forms:** audit, explain, convert, rpm, torque_nm, boost_kpa, lambda, catalyst_temp_c, 100, kpa, psi
- **What it does:** Operate the units command family in the compatibility and specialized operations surface. The command is retained as an executable compatibility or specialized entry point and is validated by the same parser, structured logging, and error-reporting path as the primary command families. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
units status
```
### `validation`
- **Aliases:** None.
- **Exact role:** Run formal validation reports or execute the measured-data comparison and parameter-identification pipeline.
- **Principal forms:** measured, identify, CSV path, time column, measured column, simulated column, optional weight column, JSON report path, and residual CSV path.
- **What it does:** Run formal validation reports or execute the measured-data comparison and parameter-identification pipeline. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::export_validation_report(), PowertrainSimulation::formal_validation_suite(), PowertrainSimulation::measured_validation_command(), PowertrainSimulation::research_validation_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::export_validation_report()`, `PowertrainSimulation::formal_validation_suite()`, `PowertrainSimulation::measured_validation_command()`, `PowertrainSimulation::research_validation_command()`.
- **Example:**
```text
validation measured data/measured_validation_example.csv time_s measured_torque_nm simulated_torque_nm weight reports/measured_validation.json reports/measured_residuals.csv
```

## Industrial & Standards
### `api`
- **Aliases:** `server`.
- **Exact role:** Start, stop, inspect, or exercise the bounded local command API server.
- **Principal forms:** status, start, stop, request, 7777
- **What it does:** Start, stop, inspect, or exercise the bounded local command API server. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::api_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::api_command()`.
- **Example:**
```text
api status
```
### `can`
- **Aliases:** None.
- **Exact role:** Inspect request/response frames and configure the timed CAN/CAN FD bus and bus faults.
- **Principal forms:** bus; dbc; export; signals; status
- **What it does:** Inspect request/response frames and configure the timed CAN/CAN FD bus and bus faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::can_bus_fault_command(), PowertrainSimulation::can_report(), PowertrainSimulation::dbc_export(), PowertrainSimulation::dbc_import(), PowertrainSimulation::dbc_report(), PowertrainSimulation::dbc_signal_fault_command(), PowertrainSimulation::j1939_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::can_bus_fault_command()`, `PowertrainSimulation::can_report()`, `PowertrainSimulation::dbc_export()`, `PowertrainSimulation::dbc_import()`, `PowertrainSimulation::dbc_report()`, `PowertrainSimulation::dbc_signal_fault_command()`, `PowertrainSimulation::j1939_command()`.
- **Example:**
```text
can
```
### `dbc`
- **Aliases:** None.
- **Exact role:** Import/export DBC signal definitions, inspect mapped signals, and inject signal-level faults.
- **Principal forms:** signals, import, export, fault, signal, EngineSpeed, BoostPressure, Lambda, stuck, noise, delay, dropout, scale, offset, data/muzixdiagsys_generated.dbc
- **What it does:** Import/export DBC signal definitions, inspect mapped signals, and inject signal-level faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::dbc_export(), PowertrainSimulation::dbc_import(), PowertrainSimulation::dbc_report(), PowertrainSimulation::dbc_signal_fault_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::dbc_export()`, `PowertrainSimulation::dbc_import()`, `PowertrainSimulation::dbc_report()`, `PowertrainSimulation::dbc_signal_fault_command()`.
- **Example:**
```text
dbc signals
```
### `faultlab`
- **Aliases:** None.
- **Exact role:** Operate the extended fault-laboratory workflow and evidence reporting.
- **Principal forms:** report; run; status; template
- **What it does:** Operate the extended fault-laboratory workflow and evidence reporting. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
faultlab
```
### `fmi`
- **Aliases:** None.
- **Exact role:** Export FMI 2.0 packages, run built-in co-simulation, and report FMI status.
- **Principal forms:** status, export, cosim, muzixdiagsys_model.fmu, 2.0, fmi_trace.csv
- **What it does:** Export FMI 2.0 packages, run built-in co-simulation, and report FMI status. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::fmi_cosim(), PowertrainSimulation::fmi_export(), PowertrainSimulation::fmi_status(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::fmi_cosim()`, `PowertrainSimulation::fmi_export()`, `PowertrainSimulation::fmi_status()`.
- **Example:**
```text
fmi status
```
### `fmi3`
- **Aliases:** None.
- **Exact role:** Export, inspect, import, step, co-simulate, and unload FMI 3 Model Exchange, Co-Simulation, or Scheduled Execution FMUs.
- **Principal forms:** status, export, inspect, import, step, cosim, unload, cs, me, se, model.fmu, fmi3_trace.csv
- **What it does:** Export, inspect, import, step, co-simulate, and unload FMI 3 Model Exchange, Co-Simulation, or Scheduled Execution FMUs. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::fmi3_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::fmi3_command()`.
- **Example:**
```text
fmi3 export model.fmu
```
### `hil`
- **Aliases:** None.
- **Exact role:** Configure hard-real-time/HIL timing, affinity, policy, warnings, and I/O behavior.
- **Principal forms:** status, on, off, period, warning, priority, strict, policy, affinity, io
- **What it does:** Configure hard-real-time/HIL timing, affinity, policy, warnings, and I/O behavior. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Example:**
```text
hil status
```
### `industrial`
- **Aliases:** None.
- **Exact role:** Access the integrated HIL, network, XCP, MDF, XIL, SSP, requirements, campaign, and signal operations surface.
- **Principal forms:** status, hil, network, xcp, mdf, xil, ssp, requirements, campaign, signal
- **What it does:** Access the integrated HIL, network, XCP, MDF, XIL, SSP, requirements, campaign, and signal operations surface. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::industrial_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::industrial_command()`.
- **Example:**
```text
industrial status
```
### `j1939`
- **Aliases:** None.
- **Exact role:** Inspect or export heavy-duty PGN/SPN diagnostic state.
- **Principal forms:** status, export
- **What it does:** Inspect or export heavy-duty PGN/SPN diagnostic state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::j1939_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::j1939_command()`.
- **Example:**
```text
j1939 status
```
### `mdf`
- **Aliases:** None.
- **Exact role:** Start/stop and validate MDF measurement recording.
- **Principal forms:** status, start, stop, validate
- **What it does:** Start/stop and validate MDF measurement recording. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Example:**
```text
mdf status
```
### `networklab`
- **Aliases:** `netfault`.
- **Exact role:** Configure, inspect, persist, and probe the deterministic CAN/CAN-FD, ISO-TP, DoIP, SOME/IP-SD, Ethernet, and TSN network fault laboratory.
- **Principal forms:** status, list, events, seed, clear, reset, set, remove, node, error, recover, can-probe, isotp-probe, doip-probe, someip-probe, ethernet-probe, save, load.
- **What it does:** Configure, inspect, persist, and probe the deterministic CAN/CAN-FD, ISO-TP, DoIP, SOME/IP-SD, Ethernet, and TSN network fault laboratory. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Example:**
```text
networklab reset 4242
networklab set can-bus-off 1 1 tx node=gateway recovery_ms=500
networklab can-probe tx 0x7E0 02 01 0C
networklab node gateway
networklab events 20
```
### `obd`
- **Aliases:** None.
- **Exact role:** Query simulated legislated OBD services, supported PIDs, raw encodings, freeze frames, DTCs, and monitor tests.
- **Principal forms:** live, pids, pid, raw, 010C, 010D, 0105, 010B, 0110, 0111, 0144, 015E
- **What it does:** Query simulated legislated OBD services, supported PIDs, raw encodings, freeze frames, DTCs, and monitor tests. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::dtc_active_report(), PowertrainSimulation::dtc_clear(), PowertrainSimulation::dtc_freeze_report(), PowertrainSimulation::formal_validation_suite(), PowertrainSimulation::obd_export_csv(), PowertrainSimulation::obd_live_report(), PowertrainSimulation::obd_pid_report(), PowertrainSimulation::obd_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::dtc_active_report()`, `PowertrainSimulation::dtc_clear()`, `PowertrainSimulation::dtc_freeze_report()`, `PowertrainSimulation::formal_validation_suite()`, `PowertrainSimulation::obd_export_csv()`, `PowertrainSimulation::obd_live_report()`, `PowertrainSimulation::obd_pid_report()`, `PowertrainSimulation::obd_report()`.
- **Example:**
```text
obd mode 01 0C
```
### `plugin`
- **Aliases:** None.
- **Exact role:** List, load, unload, configure, isolate, enable, or inspect ABI-v1/ABI-v2 and manifest plugins.
- **Principal forms:** list, status, effects, load, unload, native, v2, abi2, process, inprocess, enable, disable, timeout, plugins/sample_efficiency.plugin, plugins/calibration_stage1.plugin, plugins/turbo_is38.plugin, plugins/fuel_e30.plugin, plugins/tcm_sport.plugin, plugins/emissions_highflow.plugin, plugins/dashboard_research.plugin
- **What it does:** List, load, unload, configure, isolate, enable, or inspect ABI-v1/ABI-v2 and manifest plugins. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::native_plugin_command(), PowertrainSimulation::plugin_load(), PowertrainSimulation::plugin_report(), PowertrainSimulation::plugin_unload_all(), PowertrainSimulation::plugin_v2_command(), PowertrainSimulation::units_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::native_plugin_command()`, `PowertrainSimulation::plugin_load()`, `PowertrainSimulation::plugin_report()`, `PowertrainSimulation::plugin_unload_all()`, `PowertrainSimulation::plugin_v2_command()`, `PowertrainSimulation::units_command()`.
- **Example:**
```text
plugin list
```
### `ssp`
- **Aliases:** None.
- **Exact role:** Inspect, export, load, initialize, step, get/set, and unload system-structure packages.
- **Principal forms:** status, inspect, export, load, initialize, algorithm, step, get, set, unload
- **What it does:** Inspect, export, load, initialize, step, get/set, and unload system-structure packages. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Example:**
```text
ssp status
```
### `uds`
- **Aliases:** None.
- **Exact role:** Exercise supported Unified Diagnostic Services sessions, DIDs, DTC services, resets, and service directory.
- **Principal forms:** services, session, default, extended, read_did, F190, F187, F18C, F40D, read_dtc, clear_dtc, reset
- **What it does:** Exercise supported Unified Diagnostic Services sessions, DIDs, DTC services, resets, and service directory. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::uds_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::uds_report()`.
- **Example:**
```text
uds read_did F190
```
### `xcp`
- **Aliases:** None.
- **Exact role:** Start/stop XCP measurement/calibration service and generate A2L metadata.
- **Principal forms:** status, start, stop, a2l, cto
- **What it does:** Start/stop XCP measurement/calibration service and generate A2L metadata. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Example:**
```text
xcp status
```
### `xil`
- **Aliases:** None.
- **Exact role:** Execute ASAM XIL-oriented automation profiles.
- **Principal forms:** status, run
- **What it does:** Execute ASAM XIL-oriented automation profiles. This root is handled by the console/interface or a delegated subsystem rather than by a duplicate compatibility implementation. Query forms inspect current state; mutating forms apply only after parser and subsystem validation.
- **State and side effects:** Mixed external-I/O command family. Status/list forms are read-only; configure/start/load/import/export/request forms can alter runtime interfaces or write artifacts.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Example:**
```text
xil status
```

## Research & Analysis
### `core`
- **Aliases:** `researchcore`, `research-core`.
- **Exact role:** Inspect and configure the modular research core and subsystem coupling.
- **Principal forms:** status, on, off, reset, coupling, period, export, trace
- **What it does:** Inspect and configure the modular research core and subsystem coupling. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::research_core_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::research_core_command()`.
- **Example:**
```text
core status
```
### `durability`
- **Aliases:** None.
- **Exact role:** Inspect, reset, or export accumulated component damage and durability metrics.
- **Principal forms:** status, reset, export, durability.csv
- **What it does:** Inspect, reset, or export accumulated component damage and durability metrics. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::durability_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::durability_command()`.
- **Example:**
```text
durability status
```
### `explain`
- **Aliases:** None.
- **Exact role:** Produce subsystem-oriented explanation/provenance reports.
- **Principal forms:** ecu, tire, chassis, thermal, combustion, turbo, airpath
- **What it does:** Produce subsystem-oriented explanation/provenance reports. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::explain_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::explain_command()`.
- **Example:**
```text
explain ecu
```
### `fail`
- **Aliases:** None.
- **Exact role:** Apply legacy convenience failure injections retained for compatibility.
- **Principal forms:** boost_leak; can_dropout; catalyst; misfire
- **What it does:** Apply legacy convenience failure injections retained for compatibility. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::airpath_command(), PowertrainSimulation::cylinder_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::airpath_command()`, `PowertrainSimulation::cylinder_report()`.
- **Example:**
```text
fail
```
### `fault`
- **Aliases:** None.
- **Exact role:** Inject, list, clear, generate, run, and report deterministic fault campaigns.
- **Principal forms:** inject, clear, list, campaign, generate, run, report
- **What it does:** Inject, list, clear, generate, run, and report deterministic fault campaigns. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::fault_campaign_command(), PowertrainSimulation::fault_injection_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::fault_campaign_command()`, `PowertrainSimulation::fault_injection_command()`.
- **Example:**
```text
fault list
```
### `nvh`
- **Aliases:** None.
- **Exact role:** Configure and inspect noise/vibration/harshness and crank-torsion/order analysis.
- **Principal forms:** status, spectrum, export, nvh.csv
- **What it does:** Configure and inspect noise/vibration/harshness and crank-torsion/order analysis. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::nvh_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::nvh_command()`.
- **Example:**
```text
nvh status
```
### `optimize`
- **Aliases:** `optimise`.
- **Exact role:** Run bounded objective-driven optimization for torque, power, economy, or calibration targets.
- **Principal forms:** status, torque, power, economy, calibration, 36, optimize_results.csv
- **What it does:** Run bounded objective-driven optimization for torque, power, economy, or calibration targets. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::optimize_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::optimize_command()`.
- **Example:**
```text
optimize status
```
### `safety`
- **Aliases:** None.
- **Exact role:** Inspect or configure runtime safety limits and safety-watch policy.
- **Principal forms:** status, watch, on, off, limits, set, export, import, reset
- **What it does:** Inspect or configure runtime safety limits and safety-watch policy. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::safety_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::safety_command()`.
- **Example:**
```text
safety status
```
### `scope`
- **Aliases:** None.
- **Exact role:** Configure a triggered oscilloscope-style recorder, capture signals/events, and export traces.
- **Principal forms:** status, start, stop, clear, channels, add, rpm,boost,lambda, trigger, rpm, >, 900, events, export, scope.csv
- **What it does:** Configure a triggered oscilloscope-style recorder, capture signals/events, and export traces. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::scope_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::scope_command()`.
- **Example:**
```text
scope status
```
### `telemetry`
- **Aliases:** None.
- **Exact role:** Control legacy telemetry output and import, compare, replay, or export external telemetry data.
- **Principal forms:** on, off, import, status, columns, compare, replay, export-residuals, data/sample_telemetry.csv
- **What it does:** Control legacy telemetry output and import, compare, replay, or export external telemetry data. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::telemetry_compare(), PowertrainSimulation::telemetry_export_residuals(), PowertrainSimulation::telemetry_import(), PowertrainSimulation::telemetry_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::telemetry_compare()`, `PowertrainSimulation::telemetry_export_residuals()`, `PowertrainSimulation::telemetry_import()`, `PowertrainSimulation::telemetry_report()`.
- **Example:**
```text
telemetry status
```
### `trace`
- **Aliases:** None.
- **Exact role:** Explain runtime provenance and governing equations for selected metrics and subsystems.
- **Principal forms:** list, torque, power, boost, map, maf, airpath, turbo, combustion, mfb50, peak_pressure, thermal, coolant, oil_pressure, wheel_force, can, sensor
- **What it does:** Explain runtime provenance and governing equations for selected metrics and subsystems. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::trace_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::trace_report()`.
- **Example:**
```text
trace list
```
### `view`
- **Aliases:** None.
- **Exact role:** Print a focused subsystem report without changing the dashboard page.
- **Principal forms:** units, energy, emissions, vehicle, engine, validation, tcm, turbo, airpath, combustion, thermalnet, sensor, can, cyl, ve, knock, accessory, friction, ambient, catalyst, evap, readiness
- **What it does:** Renders a named report or fixed dashboard view. units, energy, emissions, vehicle, engine, validation, audit, scope, fuel, tire, wear, maps, hist, main, obd, visual/gauges/expert are supported. It is read-only.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::audit_report()`, `PowertrainSimulation::current_fuel_properties_report()`, `PowertrainSimulation::driveline_command()`, `PowertrainSimulation::emissions_report()`, `PowertrainSimulation::energy_report()`, `PowertrainSimulation::engine_report()`, `PowertrainSimulation::formal_validation_suite()`, `PowertrainSimulation::map_list_report()`, `PowertrainSimulation::scope_command()`, `PowertrainSimulation::snapshot()`, `PowertrainSimulation::unit_report()`, `PowertrainSimulation::vehicle_report()`, `PowertrainSimulation::wear_command()`.
- **Example:**
```text
view units
```
### `wear`
- **Aliases:** None.
- **Exact role:** Inspect, reset, fault, or export wear and lubrication-related damage state.
- **Principal forms:** status, reset, export, oil, damage, fault, low_level, pump_wear, filter_restriction
- **What it does:** Inspect, reset, fault, or export wear and lubrication-related damage state. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::wear_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::wear_command()`.
- **Example:**
```text
wear status
```

## Runtime & Execution
### `batch`
- **Aliases:** None.
- **Exact role:** Execute a bounded command file sequentially and export command/result status.
- **Principal forms:** run, data/batch_example.txt, data/batch_results.csv
- **What it does:** Execute a bounded command file sequentially and export command/result status. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::run_batch_manifest(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed engineering-lifecycle family. Query forms are read-only; run/create/load/save/export/clear/restore forms can change runtime evidence state or files.
- **How to verify:** Use the family’s status/report/validate form and verify any output file exists, parses, and contains the expected state hash or verdict.
- **Implementation route:** `PowertrainSimulation::run_batch_manifest()`.
- **Example:**
```text
batch run
```
### `benchmark`
- **Aliases:** None.
- **Exact role:** Measure deterministic model-execution performance for a bounded simulated interval.
- **Principal forms:** status, run, 0.25, 1.0
- **What it does:** Measure deterministic model-execution performance for a bounded simulated interval. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::benchmark_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::benchmark_command()`.
- **Example:**
```text
benchmark status
```
### `execution`
- **Aliases:** None.
- **Exact role:** Configure and inspect legacy, MIL, SIL, shadow-MIL, and shadow-SIL controller execution.
- **Principal forms:** status, report, mode, legacy, mil, sil, shadow_mil, shadow_sil, period, reset
- **What it does:** Configure and inspect legacy, MIL, SIL, shadow-MIL, and shadow-SIL controller execution. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::execution_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::execution_command()`.
- **Example:**
```text
execution status
```
### `fidelity`
- **Aliases:** None.
- **Exact role:** Select the active model-fidelity profile from fast/simple through research/crank-angle operation.
- **Principal forms:** status, fast, balanced, research, crank, profile
- **What it does:** Select the active model-fidelity profile from fast/simple through research/crank-angle operation. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::fidelity_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::fidelity_command()`.
- **Example:**
```text
fidelity research
```
### `loop`
- **Aliases:** None.
- **Exact role:** Start, stop, pause, or report the continuously integrated simulation loop.
- **Principal forms:** start, stop, status
- **What it does:** start/run sets continuous integration on; stop/pause sets it off; status or no operand reports the current flag. It never resets state.
- **State and side effects:** Process/session control. It changes execution or session lifetime but does not by itself rewrite model calibration.
- **How to verify:** Use loop status and compare simulation time in status before and after a short interval.
- **Example:**
```text
loop start
```
### `mil`
- **Aliases:** None.
- **Exact role:** Configure and inspect Model-in-the-Loop controller execution.
- **Principal forms:** status, configure, mode, period, reset
- **What it does:** Configure and inspect Model-in-the-Loop controller execution. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::execution_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::execution_command()`.
- **Example:**
```text
mil status
```
### `pause`
- **Aliases:** None.
- **Exact role:** Stop continuous integration without resetting state.
- **Principal forms:** pause
- **What it does:** Sets the loop-enabled flag to false. Simulation time, model state, faults, controller state, checkpoints, logs, and selected presets remain intact, so deterministic stepping or later resumption continues from the same state.
- **State and side effects:** Process/session control. It changes execution or session lifetime but does not by itself rewrite model calibration.
- **How to verify:** Use loop status and compare simulation time in status before and after a short interval.
- **Example:**
```text
pause
```
### `profile`
- **Aliases:** None.
- **Exact role:** Combine performance measurement with subsystem-state reporting.
- **Principal forms:** status, run, 0.25, 1.0
- **What it does:** Combine performance measurement with subsystem-state reporting. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::profile_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::profile_command()`.
- **Example:**
```text
profile status
```
### `quickstart`
- **Aliases:** None.
- **Exact role:** Perform a repeatable ignition and starter sequence that cranks and starts the current engine model.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Runs the simulator quick-start routine: ignition is enabled, the starter cranks the engine, and the starter is released while ignition remains on.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, and coldstart/engine state metrics.
- **Implementation route:** `PowertrainSimulation::quickstart()`.
- **Example:**
```text
quickstart
```
### `realtime`
- **Aliases:** None.
- **Exact role:** Configure deterministic fixed-step real-time scheduling, target rate, and time step.
- **Principal forms:** status, on, off, rate, dt, 1.0, 0.01
- **What it does:** Configure deterministic fixed-step real-time scheduling, target rate, and time step. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::realtime_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::realtime_command()`.
- **Example:**
```text
realtime status
```
### `reset`
- **Aliases:** None.
- **Exact role:** Restore the simulator and runtime controls to deterministic defaults while retaining the executable feature set.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Calls the simulator reset routine, restoring default dynamic state and parameters. Persisted files, authentication data, and previously exported artifacts are not deleted.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::journal_record()`, `PowertrainSimulation::reset()`, `PowertrainSimulation::state_hash()`.
- **Example:**
```text
reset
```
### `run`
- **Aliases:** None.
- **Exact role:** Start continuous integration of the active simulation state.
- **Principal forms:** run
- **What it does:** Sets the shared loop-enabled flag to true. The background simulation thread then calls the active solver at the configured real-time or default cadence. In a terminal, the pinned dashboard refreshes; in batch mode, output remains quiet unless legacy telemetry is enabled.
- **State and side effects:** Process/session control. It changes execution or session lifetime but does not by itself rewrite model calibration.
- **How to verify:** Use loop status and compare simulation time in status before and after a short interval.
- **Example:**
```text
run
```
### `sil`
- **Aliases:** None.
- **Exact role:** Load/unload and configure Software-in-the-Loop controller execution.
- **Principal forms:** status, load, unload, mode, period, reset
- **What it does:** Load/unload and configure Software-in-the-Loop controller execution. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::execution_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::execution_command()`.
- **Example:**
```text
sil status
```
### `solver`
- **Aliases:** None.
- **Exact role:** Select integration algorithm and configure step size, adaptive tolerance, event detection, and multi-rate periods.
- **Principal forms:** status, reset, euler, semi_implicit, rk2, rk4, rk45, dt, maxdt, mindt, substeps, adaptive, events, tolerance, multirate, combustion-dt, airpath-dt, thermal-dt, profile, research
- **What it does:** Select integration algorithm and configure step size, adaptive tolerance, event detection, and multi-rate periods. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::solver_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::solver_command()`.
- **Example:**
```text
solver rk45
```
### `step`
- **Aliases:** None.
- **Exact role:** Advance simulated time deterministically by a bounded duration without requiring the background loop.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Parses seconds, defaults to 0.1 when absent, clamps the value to 0.001 through 60.0 seconds, and advances through the active solver profile without enabling the continuous loop.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status or studio timeline status and confirm simulation time increased by the requested amount.
- **Implementation route:** `PowertrainSimulation::advance()`.
- **Example:**
```text
step 0.25
```

## Vehicle Dynamics
### `abs`
- **Aliases:** None.
- **Exact role:** Enable or disable anti-lock brake intervention through the retained direct command.
- **Principal forms:** on, off
- **What it does:** Enable or disable anti-lock brake intervention through the retained direct command. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::tire_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::tire_command()`.
- **Example:**
```text
abs on
```
### `brake`
- **Aliases:** None.
- **Exact role:** Set service-brake demand and feed the chassis, tire, ABS, and thermal models.
- **Principal forms:** 0; 100; 25; 50; 75
- **What it does:** Parses normalized or percent brake demand and stores it in the chassis input. The new demand is consumed by subsequent tire, ABS, thermal, and vehicle-dynamics steps.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::set_brake()`.
- **Example:**
```text
brake 20
```
### `chassis`
- **Aliases:** None.
- **Exact role:** Configure mass, aerodynamic drag, grade, rolling resistance, brakes, and chassis export.
- **Principal forms:** status, report, mass, cda, grade, rr, brake, export
- **What it does:** Configure mass, aerodynamic drag, grade, rolling resistance, brakes, and chassis export. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::chassis_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::chassis_command()`.
- **Example:**
```text
chassis status
```
### `clutch`
- **Aliases:** None.
- **Exact role:** Set manual clutch-pedal depression. 0 means the pedal is released and the driveline is coupled; 100 means the pedal is fully depressed and the driveline is disengaged.
- **Principal forms:** 0; 100; 25; 50; 75
- **What it does:** For manual transmissions, stores clutch-pedal depression using 0 as coupled and 100 as disengaged. Automatic-transmission configurations reject the command.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::set_clutch()`.
- **Example:**
```text
clutch
```
### `coastdown`
- **Aliases:** `roadload`.
- **Exact role:** Run a coastdown/road-load experiment and report estimated drag terms.
- **Principal forms:** start, run, report, 120
- **What it does:** Run a coastdown/road-load experiment and report estimated drag terms. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::coastdown_report(), PowertrainSimulation::run_coastdown(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::coastdown_report()`, `PowertrainSimulation::run_coastdown()`.
- **Example:**
```text
coastdown report
```
### `cycle`
- **Aliases:** None.
- **Exact role:** Operate the cycle command family in the compatibility and specialized operations surface. The command is retained as an executable compatibility or specialized entry point and is validated by the same parser, structured logging, and error-reporting path as the primary command families.
- **Principal forms:** list, run, urban, wltp, hwyfet, us06
- **What it does:** Operate the cycle command family in the compatibility and specialized operations surface. The command is retained as an executable compatibility or specialized entry point and is validated by the same parser, structured logging, and error-reporting path as the primary command families. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::drive_cycle_list(), PowertrainSimulation::run_drive_cycle(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::drive_cycle_list()`, `PowertrainSimulation::run_drive_cycle()`.
- **Example:**
```text
cycle list
```
### `drivecheck`
- **Aliases:** `drivetrain`.
- **Exact role:** Diagnose why vehicle speed is or is not changing by tracing torque through clutch, gearbox, driveline, tires, and road load.
- **Principal forms:** See help/command-schema for the validated operand grammar; the root itself is also meaningful where a status form exists.
- **What it does:** Builds a read-only readiness explanation from the current snapshot and loop state, tracing whether ignition, engine state, clutch, gear, torque, tire force, brake, or road load prevents acceleration.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::snapshot()`.
- **Example:**
```text
drivecheck
```
### `driveline`
- **Aliases:** `transmission`.
- **Exact role:** Configure transmission/driveline strategy, traction intervention, launch behavior, friction, and faults.
- **Principal forms:** status, mode, shiftmap, eco, normal, sport, traction, on, off, launch, mu, fault, reset
- **What it does:** Configure transmission/driveline strategy, traction intervention, launch behavior, friction, and faults. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::driveline_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::driveline_command()`.
- **Example:**
```text
driveline status
```
### `driver`
- **Aliases:** None.
- **Exact role:** Configure and inspect the closed-loop virtual driver.
- **Principal forms:** status; on|off; target <speed>; profile ...; limits ...; reset
- **What it does:** Collects the remaining tokens and delegates them to the driver subsystem. Mutating forms change target-following, acceleration, jerk, throttle, brake, and reaction constraints used on later integration steps; report forms read the current driver state.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::driver_command()`.
- **Example:**
```text
driver status
```
### `gear`
- **Aliases:** None.
- **Exact role:** Select neutral, reverse, or an available forward ratio.
- **Principal forms:** 1; 10; 2; 3; 4; 5; 6; 7; 8; 9; N; R
- **What it does:** Parses N/neutral as 0, R/reverse as -1, or a rounded numeric forward gear, then asks the transmission to validate and apply the request for the active vehicle.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::request_gear()`.
- **Example:**
```text
gear 3
```
### `mode`
- **Aliases:** `trans`.
- **Exact role:** Select manual or automatic transmission operation.
- **Principal forms:** manual, automatic
- **What it does:** Selects Manual or Automatic transmission mode. Accepted abbreviations are m and auto/a. It does not itself select a different gear.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::set_mode()`.
- **Example:**
```text
mode manual
```
### `physics`
- **Aliases:** None.
- **Exact role:** Audit the coupled first-law and longitudinal-physics ledger.
- **Principal forms:** status/report/audit forms supplied by the physics subsystem
- **What it does:** Delegates to the physics ledger, which reconciles fuel chemical energy, indicated and brake work, losses, heat rejection, wheel work, kinetic-energy change, and conservation residuals. Query forms do not modify state.
- **State and side effects:** Read-only analysis/reporting at the root-command level.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::physics_command()`.
- **Example:**
```text
physics status
```
### `road`
- **Aliases:** None.
- **Exact role:** Apply a named road-surface adhesion preset.
- **Principal forms:** road surface dry|wet|snow|ice
- **What it does:** Maps dry, wet, snow, and ice to tire-road friction coefficients 0.95, 0.62, 0.28, and 0.10 respectively, then routes the value through the driveline command layer. The new coefficient affects subsequent tire force, traction-control, ABS, and longitudinal-dynamics calculations.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::driveline_command()`.
- **Example:**
```text
road surface wet
```
### `shift`
- **Aliases:** None.
- **Exact role:** Request a one-ratio upshift or downshift.
- **Principal forms:** up, down
- **What it does:** Converts up/+ to +1 and down/- to -1, then requests a one-gear change. Transmission and clutch rules determine whether the request is accepted.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::request_shift()`.
- **Example:**
```text
shift up
```
### `tcm`
- **Aliases:** None.
- **Exact role:** Inspect and configure transmission-control mode, adaptation, and torque-converter clutch strategy.
- **Principal forms:** status, mode, eco, normal, sport, manual, adapt, reset, lockup, auto, force_on, force_off
- **What it does:** Inspect and configure transmission-control mode, adaptation, and torque-converter clutch strategy. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::tcm_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::tcm_command()`.
- **Example:**
```text
tcm status
```
### `tire`
- **Aliases:** `tires`.
- **Exact role:** Configure tire model, friction, ABS/ESC, differential, vehicle dynamics, and exports.
- **Principal forms:** status, report, model, simple, pacejka_lite, brush, mu, abs, esc, diff, open, lsd, locked, export
- **What it does:** Configure tire model, friction, ABS/ESC, differential, vehicle dynamics, and exports. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::tire_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::tire_command()`.
- **Example:**
```text
tire status
```
### `traction`
- **Aliases:** None.
- **Exact role:** Enable or disable traction intervention through the retained direct command.
- **Principal forms:** on, off
- **What it does:** Enable or disable traction intervention through the retained direct command. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::driveline_command(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use status, drivecheck, tire status, chassis status, or driveline status after at least one step.
- **Implementation route:** `PowertrainSimulation::driveline_command()`.
- **Example:**
```text
traction on
```
### `vehicle`
- **Aliases:** None.
- **Exact role:** List, inspect, or apply a vehicle preset including mass, gearing, aero, tires, and driveline configuration.
- **Principal forms:** list, status, generic_sedan, vw_gti_mk8_manual, vw_gti_mk8_dsg, vw_golf_r_mk8_dsg, audi_s3_8y, audi_rs3_8y, audi_s4_b9, ford_mustang_gt_s650_manual, ford_mustang_gt_s650_auto, ford_f150_3.5_ecoboost_10at, gm_corvette_c8_stingray, gm_camaro_ss_6mt, gm_camaro_zl1_10at, sport_coupe, pickup_tow, dyno_cell, gti, dsg, golf_r, rs3, s4, mustang, f150, corvette, camaro, zl1, toyota_gr_corolla_6mt, honda_civic_type_r_fl5_6mt, bmw_m3_competition_xdrive_8at, mazda_mx5_nd_6mt, ram_1500_rho_hurricane_8at, chevrolet_silverado_1500_duramax_10at, porsche_911_carrera_pdk, subaru_wrx_6mt, gr_corolla, grc, type_r, m3, m3_xdrive, mx5, miata, ram_rho, rho, silverado, duramax, 911, carrera, wrx
- **What it does:** List, inspect, or apply a vehicle preset including mass, gearing, aero, tires, and driveline configuration. The main dispatcher parses the root token, collects or validates the remaining operands, and routes the operation through PowertrainSimulation::apply_vehicle_preset(), PowertrainSimulation::list_vehicle_presets(), PowertrainSimulation::vehicle_report(). The delegated subsystem performs range, file, state, and consistency checks before committing a change; failures are printed as errors and preserve the last valid state where the subsystem supports transactional updates.
- **State and side effects:** Mixed simulator-state family. Status/report/list forms are read-only; configuration, fault, control, reset, or run forms affect later simulation results.
- **How to verify:** Use the command’s status/report form, then health status or stability to check for unintended numerical effects.
- **Implementation route:** `PowertrainSimulation::apply_vehicle_preset()`, `PowertrainSimulation::list_vehicle_presets()`, `PowertrainSimulation::vehicle_report()`.
- **Example:**
```text
vehicle vw_gti_mk8_dsg
```



# 13. Emerging mobility laboratories: beginner to advanced

Start with `emerging capabilities`; it only writes the domain registry and evidence digest. Then run `emerging self-test DIRECTORY OUTPUT.json`; it executes all ten deterministic positive workflows, creates individual domain reports in `DIRECTORY`, and writes the aggregate verdict.

The exact domain form is:

```bash
./build/full/muzixdiagsys_advanced_platform emerging DOMAIN \
  REQUEST.json OUTPUT.json WORKING_DIRECTORY
```

`DOMAIN` selects one implementation, `REQUEST.json` is parsed input, `OUTPUT.json` receives the complete report, and the optional directory receives the domain-specific evidence artifact. Read `passed`, then `findings`, then numerical metrics. Exit 2 means the analysis completed but failed its engineering gates; exit 1 means malformed input or an execution exception; exit 64 means command syntax was invalid.

Begin with the checked-in files under `examples/emerging_mobility/`. Controlled experiments should change one variable: voxel size versus Gaussian count/PSNR; cockpit load versus admission; HUD latency versus registration; inlet temperature versus hydrogen tank temperature; harness length versus Ethernet margin; fractional bits versus FPGA error. Preserve requests, outputs, artifact directories, build configuration, archive checksum, and evidence digests. Run `ctest --test-dir build/full --output-on-failure -R '^emerging_mobility_platform_unit_tests$'` after code or compiler changes.

# Appendix A. Exit-code interpretation

- Main interactive/batch console normally exits 0 after a clean `quit`/`logout`; authentication failure exits 3.
- Advanced platform returns 64 for usage errors, 1 for exceptions, and 2 when a result explicitly reports `passed=false`.
- Causal diff returns 0 for equivalent and 1 for non-equivalent timelines; malformed input returns 1 or usage 2 as coded.
- Validation-oriented engineering commands frequently return 1 for a validly executed but failing verdict. Treat nonzero as evidence to inspect, not automatically as a software crash.

# Appendix B. Reproducible experiment checklist
- Capture source/archive checksum and build configuration.
- Run command-schema validate before recording a new workflow.
- Record engine, vehicle, fuel, fidelity, solver, controller-execution mode, plugins, and random seed.
- Create a checkpoint immediately before the variable under study changes.
- Use deterministic step or a controlled real-time scheduler.
- Export machine-readable traces before narrative reports.
- Run health, stability, validation, and conservation checks.
- Preserve journal/replay/state hashes and all input files.
- Restore the same checkpoint for A/B comparisons.
- Keep external tool versions and hardware-I/O configuration in the study manifest.

# 14. Formula One championship operations: evidence to official decision

Begin by confirming the new registry:

```bash
./build/full/muzixdiagsys_advanced_platform f1-operations capabilities
```

This command does not run a race model. It returns the ten domain names and a digest that identifies the command registry. Next, execute the integrated positive-path exercise:

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-operations self-test \
  build/full/f1-operations-self-test \
  build/full/f1-operations-self-test.json
```

The first path is a directory. The program creates it, writes ten domain reports plus `f1_championship_operations_self_test.json`, and then writes the aggregate report to the second path. Inspect `results` to see which domain failed before reading its detailed artifact.

The general command is:

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-operations DOMAIN REQUEST.json OUTPUT.json WORKING_DIRECTORY
```

`DOMAIN` selects the exact model. `REQUEST.json` is never modified. `OUTPUT.json` receives the complete returned document. `WORKING_DIRECTORY` is optional and receives the domain-specific atomic evidence file. Exit 0 means the model executed and passed. Exit 2 means the model executed correctly but found a noncompliant or unsafe condition. Exit 1 means the request was malformed or execution raised an exception.

A recommended beginner sequence is:

1. Run `timing-scoring` and inspect the reconstructed lap times and final classification.
2. Add a five-second time penalty, rerun, and compare the classification digests.
3. Run `trackside-safety`, then remove the electrical-isolation resource from a high-voltage incident and confirm restart readiness fails.
4. Run `cost-cap-forensics`, then mark an unapproved category as excluded and confirm the adjusted relevant costs restore it.
5. Run `fluid-certification`, then add an unmatched chromatographic peak and observe the unknown-compound fraction.
6. Run `ers-safety`, then lower insulation resistance and confirm contactor shutdown.
7. Run `driver-cooling`, then inject `pump_failed=true` in the final profile sample.
8. Run `wet-weather-visibility`, then increase water depth while holding rain rate constant.
9. Run `active-aero-actuation`, then inject a jam into only one actuator and inspect asymmetry and fail-safe behavior.
10. Run `physical-scrutineering`, then change the middle load-deflection point to create a nonlinear stiffness transition.
11. Run `camera-evidence`, then supply four tyre points outside the legal polygon and inspect the generated incident.

For each experiment, preserve the original request, modified request, both outputs, the working directories, and the build/archive checksum. The evidence digest is deterministic only when the request, source version, and numerical environment are unchanged.

Run the focused regression after changing any Formula One operations source:

```bash
ctest --test-dir build/full \
  -R '^formula_one_championship_operations_unit_tests$' \
  --output-on-failure
```

# 15. IndyCar frontier expansion: complete engineering workflow

The frontier expansion is a typed C++ API, not an interactive console root. Start by building the dedicated test through the production `aesim_advanced` library:

```bash
cmake -S . -B build/indy-frontier -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_ENABLE_NATIVE_OPTIMIZATION=OFF
cmake --build build/indy-frontier --parallel "$(nproc)" --target \
  aesim_indycar \
  indycar_frontier_expansion_platform_tests
ctest --test-dir build/indy-frontier --output-on-failure \
  -R '^indycar_frontier_expansion_platform_unit_tests$'
```

The canonical copy-ready inputs are in `tests/indycar_frontier_expansion_platform_tests.cpp`. The test is preferable to an uncompiled prose example because it is built with the same C++17, warning, hardening, position-independent-code, and strict-numerics policies as the production library.

## 15.1 Power-unit co-design study

Include the public header, construct `IndyCar2028PowerUnitDesign`, define a duty cycle of `IndyCar2028PowerUnitDutyPoint` values, and call `IndyCar2028PowerUnitLaboratory::evaluate`.

A disciplined study changes one parameter at a time:

1. Establish a legal 2.4-liter, six-cylinder baseline.
2. Sweep boost while holding throttle, lambda, spark, and intake temperature fixed.
3. Compare peak power, compressor speed, turbine-inlet temperature, and knock margin.
4. Sweep compression ratio and renewable-ethanol fraction.
5. Inspect every cylinder peak-pressure vector and the maximum imbalance.
6. Reject a candidate when any homologation rule appears in `violations`.
7. Preserve the input and `evidence_sha256` for each design point.

The declared displacement and bore/stroke geometry are cross-checked. A geometrically inconsistent design fails before any duty-point calculation.

## 15.2 Hybrid hardware mission

Initialize exactly twenty cell voltages and twenty cell temperatures in `IndyCarUltracapacitorState`. Then pass deployment, regeneration, and self-start segments to `IndyCarHybridElectrothermalLaboratory::simulate`.

Review:

- delivered versus requested shaft torque;
- MGU field-weakening behavior;
- DC-bus voltage and current;
- inverter, MGU, bus, contactor, and cell losses;
- minimum and maximum cell voltage;
- cell, inverter, and MGU temperature;
- isolation state and contactor decision;
- deployed and recovered energy;
- equivalent-full-cycle accumulation and remaining useful cycles.

Lowering isolation resistance below the configured threshold must inhibit the contactors and produce an unsafe result. Increasing torque beyond the torque-speed or current envelope must be clipped and recorded.

## 15.3 Gearbox and driveline durability cycle

Call `IndyCarTransmissionDrivelineLaboratory::simulate`. Use one-based gear numbers in `IndyCarDrivelineCyclePoint`. A requested shift completes only when dog-ring speed mismatch and actuator duration both satisfy the configuration.

For a launch-to-upshift study:

1. Start with partial clutch engagement and a positive slip speed.
2. Confirm clutch slip power and temperature rise.
3. Reduce engagement during the shift.
4. Match engine speed to wheel speed multiplied by the requested gear and final-drive ratio.
5. Restore full clutch engagement after the shift.
6. Review gear damage, halfshaft damage, clutch wear, bellhousing margin, oil temperature, and missed-shift count.

A failed shift leaves the prior gear selected and records a failure; it does not silently accept the commanded ratio.

## 15.4 Carbon-brake and regenerative-blending study

Call `IndyCarBrakeSystemLaboratory::simulate`. Define each braking event with pedal force, front bias, vehicle speed, wheel speeds, regenerative torque, ambient temperature, duct setting, and knock-back volume.

Compare:

- hydraulic line pressure;
- front and rear friction torque;
- total rear torque after regeneration;
- deceleration;
- wheel-slip ratios and lock risk;
- front/rear disc temperatures;
- fluid temperature and boiling margin;
- pedal travel;
- pad/disc wear and fade margin.

Use a no-pedal cooling segment to verify duct-dependent thermal recovery. A high knock-back volume should increase pedal travel and reduce pressure rather than creating energy or torque.

## 15.5 Evolving track and weather study

Call `IndyCarTrackEnvironmentTwin::evolve`. Build an ordered laser-scan mesh with unique indices. Supply weather beginning at time zero and traffic events that reference valid mesh indices.

A wet-to-dry experiment should:

1. Begin with rainfall and low solar flux.
2. Transition to dry, warmer, windier weather.
3. Apply vehicle traffic and dedicated drying events.
4. Compare water film, rubber coverage, contamination, temperature, effective friction, and hydroplaning speed by cell.
5. Inspect dry-line fraction and hazard messages.

The twin rejects non-monotonic geometry, duplicate indices, unknown traffic references, and timeline events outside the simulation interval.

## 15.6 Full-field racecraft study

Call `IndyCarFullFieldCompetitionEngine::simulate`. Create two to thirty-five `IndyCarRaceEntrant` agents and one `IndyCarFullFieldRaceConfiguration`. Run the same seed twice before changing anything; the evidence digest must match.

Then vary:

- passing difficulty;
- wake loss or tow gain;
- caution probability;
- tire degradation;
- driver aggression and defense;
- pit intervals;
- reliability;
- restart field compression.

Evaluate overtakes, lead changes, cautions, field spread, classification, retirements, pit stops, and the normalized raceability index. Do not compare two rule packages with different seeds unless stochastic variation is the subject of the experiment.

## 15.7 Incident reconstruction study

Call `IndyCarIncidentReconstructionPlatform::reconstruct`. Calibrate each camera with offset, drift, a nonsingular 3 x 3 pixel-to-track homography, and pixel uncertainty. Supply video detections and telemetry in a common incident interval.

The reconstruction:

- corrects camera time;
- maps pixels to track coordinates;
- weights observations by uncertainty and confidence;
- fuses points within 25 ms;
- recovers video-only speed and heading;
- finds the minimum separation across cars;
- calculates closing speed and reduced-mass contact energy;
- reports uncertainty and avoidability scores.

Treat `primary_car_id` as a modeled attribution, not an automatic official decision. Review the fused trajectory, findings, uncertainty, and source evidence.

## 15.8 Pit-lane vision officiating study

Call `IndyCarPitLaneVisionOfficiating::adjudicate`. Define every assigned pit box before providing frames. Fuse high-confidence pit-loop speed observations with vision frames.

Exercise the taxonomy deliberately:

- exceed the speed limit;
- cross an entry or exit boundary;
- enter while the pits are closed;
- stop in the wrong box;
- place crew over the wall while the car is moving;
- exceed the crew limit;
- release an uncontrolled wheel;
- move with the fuel probe connected;
- release with air jacks active or wheel service incomplete;
- obstruct another box;
- stop in the fast lane;
- release into another car's conflict envelope.

Continuous frames of the same offense are merged into one interval. Review severity, confidence, and evidence references rather than counting raw frames as penalties.

## 15.9 Appeals and precedent review

Call `IndyCarAppealsPrecedentPlatform::adjudicate`. Create one `IndyCarAppealRule`, one filing, and a set of unique precedent cases. The platform first checks appealability, jurisdiction, filing time, fee, and conflict disclosure. Only a procedurally valid appeal reaches precedent normalization.

Precedent similarity combines rule identity, jurisdiction, tag overlap, facts severity, and evidence strength. Review:

- selected precedents and similarity;
- original and recommended penalty;
- consistency score;
- accepted, dismissed, modified, upheld, or remanded outcome;
- stay decision;
- public and complete audit digests.

A late or jurisdictionally invalid filing is dismissed without disguising the procedural reason as a merits decision.

## 15.10 Complete Month-of-May programme

Call `Indy500CompleteMonthOfMayOperationsTwin::simulate`. Create entries with driver status, no-tow speed, consistency, racecraft, pit-crew performance, reliability, mileage, tires, and budget. Schedule non-overlapping sessions from Open Test through Race.

The recommended progression is:

1. Run Rookie Orientation and Refresher sessions for affected drivers.
2. Allocate practice runs while monitoring engine mileage, tires, budget, and readiness.
3. Apply Fast Friday boost.
4. Run Qualifying Day One.
5. Re-rank Top Twelve and Fast Six attempts.
6. Resolve Last Chance and bumped entries.
7. Use Carb Day to close readiness gaps.
8. Run the Pit Stop Challenge.
9. Project the 200-lap race, pit plan, reliability exposure, and expected duration.

`event_ready` requires a complete starting field and qualified entries with orientation, readiness, mileage, tire, and race-plan viability. Weather interruptions reduce track availability deterministically from the supplied seed.

## 15.11 Whole-IndyCar regression

After changing any IndyCar source, run all four modules together:

```bash
cmake --build build/indy-frontier --parallel "$(nproc)" --target \
  indycar_platform_tests \
  indycar_operations_platform_tests \
  indycar_future_competition_platform_tests \
  indycar_frontier_expansion_platform_tests
ctest --test-dir build/indy-frontier --output-on-failure \
  -R '^indycar_.*_unit_tests$'
```

Use `docs/INDYCAR_FRONTIER_EXPANSION_PLATFORM.md` for the complete API and model-contract reference.

# NASCAR Competition Tutorial

Start by running the integrated regression:

```bash
./build/full/muzixdiagsys_advanced_platform nascar self-test \
  build/full/nascar-self-test build/full/nascar-self-test.json
```

The command executes one nominal workflow for every NASCAR domain and writes
both individual evidence files and one aggregate result. Inspect `passed` and
`evidence_digest` before using a model in an experiment.

A useful beginner workflow is:

1. Run `cup-next-gen-vehicle` with the supplied baseline setup.
2. Change only tyre pressure or rear anti-roll stiffness and compare the two
   evidence reports.
3. Run `track-surface` to generate a changed grip state.
4. Feed the resulting engineering interpretation into a second vehicle setup.
5. Run `goodyear-tyre` for the proposed stint and confirm pressure, temperature,
   wear and hydroplaning margins.

An advanced race-weekend workflow is:

1. Use `superspeedway-pack` to evaluate lane and cooling strategy.
2. Use `single-lug-pit-crew` to compare four-tyre and fuel-only stops.
3. Use `race-control` to replay caution, free-pass, choose and overtime events.
4. Use `timing-smt` to reconstruct the official result and caution freeze order.
5. Use `chase-championship` to propagate stage and finishing points.
6. Use `oss-inspection` for post-race technical clearance.
7. Use `crash-safety` for any significant incident reconstruction.

The exact domain command is:

```bash
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN \
  REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`capabilities` lists the registry and performs no simulation. `self-test` executes all 40 domains. Each domain invocation executes exactly one request.
Exit code 0 means the request executed and passed its gates; 2 means the request
executed but failed a safety or compliance gate; 1 means invalid input or an
execution error; and 64 means invalid top-level syntax.

See `docs/NASCAR_COMPETITION_PLATFORM.md` for every request group, equation,
state transition, finding and generated artifact.

# Advanced NASCAR ecosystem tutorial

Begin by verifying all 40 NASCAR domains:

```bash
mkdir -p build/tutorial/nascar
./build/full/muzixdiagsys_advanced_platform \
  nascar self-test \
  build/tutorial/nascar \
  build/tutorial/nascar/self-test.json
```

`nascar self-test` constructs deterministic nominal requests for every original and expanded NASCAR subsystem. It executes each model, records whether it passed, captures the SHA-256 evidence digest, and writes a combined report. A successful run establishes that the vehicle, race, officiating, business, repair, weather, and safety engines are linked and operational.

A useful progression is:

1. Run `multi-series` to compare the Cup, O’Reilly, Truck, and ARCA baseline architectures.
2. Run `manufacturer-homologation` to establish that body submissions occupy an acceptable parity window.
3. Run `v8-transaxle-durability` with a dyno or lap-derived duty cycle.
4. Construct a Daytona or All-Star lineup with `special-event-formats`.
5. Analyze the entrant portfolio with `charter-team-economics`.
6. Convert calibrated pit-road detections into official evidence with `pit-road-vision`.
7. Correlate spotter calls with traffic truth through `radio-intelligence`.
8. Determine post-incident restart time with `trackside-safety-drying`.
9. Schedule physical garage work with `dvp-garage-repair`.
10. Decide whether wet conditions remain raceable with `wet-weather-visibility`.

Each example under `examples/nascar_ecosystem/` is complete and can be copied before modification. Preserve the baseline request and output digest when conducting A/B studies so changes in physics, policy, or parameters remain traceable.


# NASCAR frontier correctness tutorial

The frontier examples are designed for controlled negative as well as positive studies. Start with the checked-in baseline, change one variable, and compare both the verdict and the evidence structure.

## Live-bracket tournament study

```bash
./build/full/muzixdiagsys_advanced_platform nascar in-season-challenge \
  examples/nascar_frontier/in_season_challenge.json \
  build/tutorial/nascar/in-season.json \
  build/tutorial/nascar
```

After adding a completed round, verify that eliminated drivers have probability `0.0`, surviving probabilities sum to `1.0` within numerical tolerance, and projections begin from the current bracket. A non-power-of-two field, duplicate seed, duplicate identifier, invalid finish, or negative performance sigma must be rejected.

## Rulebook conflict study

```bash
./build/full/muzixdiagsys_advanced_platform nascar rules-case-law \
  examples/nascar_frontier/rules_case_law.json \
  build/tutorial/nascar/rules.json \
  build/tutorial/nascar
```

Create a copy with two violated rules whose penalty intervals do not overlap. The expected result is a failed adjudication containing `RULE-PENALTY-CONFLICT` and `recommended_penalty: null`. Do not substitute zero for null; null means no valid recommendation exists. Also verify that malformed bulletin additions and replacements fail before altering the active rule map.

## Fuel-starvation conservation study

```bash
./build/full/muzixdiagsys_advanced_platform nascar fuel-mileage \
  examples/nascar_frontier/fuel_mileage.json \
  build/tutorial/nascar/fuel.json \
  build/tutorial/nascar
```

Reduce collector supply or pickup coverage until starvation occurs. Compare requested demand, delivered fuel, starvation duration, collector level, and cell inventory. `total_consumed` must track delivered fuel only; unmet demand is starvation and must not disappear from the mass balance as fictitious consumption.

## Dependency-failure logistics study

```bash
./build/full/muzixdiagsys_advanced_platform nascar team-logistics \
  examples/nascar_frontier/team_logistics.json \
  build/tutorial/nascar/logistics.json \
  build/tutorial/nascar
```

Reorder task declarations while preserving dependencies; the schedule should remain dependency-correct. Then remove a required part from an early task. That task must fail without consuming the part inventory or resource clock, and every dependent task must remain blocked. Distinguish an unknown dependency from a known prerequisite that failed and from a dependency cycle.

Run the focused regression after any NASCAR source or example change:

```bash
ctest --test-dir build/full --output-on-failure \
  -R '^nascar_.*_unit_tests$'
python3 tests/documentation_consistency_regression.py .
```

# 16. NASCAR next-generation engineering and operations workflow

The fourth NASCAR platform adds ten domains and raises the aggregate registry to
40. Direct C++ consumers use the public API:

```cpp
#include "aesim/advanced/nascar_next_generation_platform.hpp"

const aesim::advanced::nascar::NascarNextGenerationPlatform platform;
```

Begin with a clean focused build:

```bash
cmake -S . -B build/tutorial-nascar-next -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/tutorial-nascar-next --parallel --target \
  aesim_nascar \
  nascar_next_generation_platform_tests
ctest --test-dir build/tutorial-nascar-next --output-on-failure \
  -R '^nascar_next_generation_platform_unit_tests$'
```

Run the complete aggregate self-test before modifying any baseline:

```bash
mkdir -p build/tutorial/nascar-next/self-test
./build/full/muzixdiagsys_advanced_platform nascar self-test \
  build/tutorial/nascar-next/self-test \
  build/tutorial/nascar-next/self-test.json
```

The report must show `domain_count: 40`. Preserve the baseline JSON and digest
before changing one factor at a time.

## 16.1 Electrified architecture study

Create a request containing `architecture`, `vehicle`, `battery`, `motors`, and
`drive_cycle`. Use `battery-electric` for the first experiment. Include at least
one acceleration segment and one braking segment.

```bash
./build/full/muzixdiagsys_advanced_platform nascar electrified-stock-car \
  electrified-request.json \
  build/tutorial/nascar-next/electrified.json \
  build/tutorial/nascar-next
```

Check `final_soc`, `peak_pack_current_a`, `peak_pack_power_kw`, motor thermal
margins, regenerated energy, friction-brake energy, and `unmet_energy_kwh`.
Then copy the request, reduce pack current, and verify that motor wheel power and
SOC change consistently rather than leaving impossible delivered torque in the
report. For a hybrid experiment, select `parallel-hybrid` or `power-split`, add
an `engine` object, and compare battery energy against fuel mass.

## 16.2 Cylinder-resolved V8 and fuel study

Define an eight-cylinder engine, sustainable-fuel properties, homologation
power band, and a sweep of operating points.

```bash
./build/full/muzixdiagsys_advanced_platform nascar v8-combustion-fuel \
  v8-request.json \
  build/tutorial/nascar-next/v8.json \
  build/tutorial/nascar-next
```

Compare manifold pressure, tapered-spacer loss, torque, BMEP, BSFC, knock, EGT,
valvetrain stress, and all eight cylinder rows. Modify only renewable fraction,
octane, latent heat, or flow variation in each follow-up run. A six-cylinder
configuration, malformed flow-factor list, or non-finite operating point must be
rejected rather than silently converted.

## 16.3 Aerodynamic rules-package study

Supply at least two packages and several track scenarios. Include an
intermediate, short-track, and superspeedway case when evaluating a general
rules package.

```bash
./build/full/muzixdiagsys_advanced_platform nascar aero-raceability \
  aero-request.json \
  build/tutorial/nascar-next/aero.json \
  build/tutorial/nascar-next
```

Inspect following downforce loss, tow drag reduction, corner margin, closing
power, pass probability, multi-lane score, liftoff margin, and manufacturer
spread. Tighten `minimum_liftoff_margin` or `maximum_manufacturer_spread` to
observe a completed negative qualification. When no package qualifies,
`recommended_package` must be `null` rather than an arbitrary unsafe selection.

## 16.4 Full-field racecraft and strategy study

Create 12-40 drivers with distinct pace, aggression, tire, restart, fuel, and
reliability values. Define track type, lap count, stage ends, pit loss, fuel
window, and scheduled cautions.

```bash
./build/full/muzixdiagsys_advanced_platform nascar full-field-racecraft \
  race-request.json \
  build/tutorial/nascar-next/race.json \
  build/tutorial/nascar-next
```

Run the identical request twice and confirm the digest matches. Review the
end-of-lap `lap_history`, classification, stage points, incidents, pit stops,
`green_flag_overtakes`, and `pit_cycle_position_changes`. Green-flag overtake
counts exclude order changes caused by pit stops and retirements. Then change
only the seed to study stochastic variability.

## 16.5 Remote race-control fusion study

Create synchronized video, telemetry, radio, and timing observations for one or
more event identifiers. Give every item a unique `reference`. Add local and
remote network channels and a rules list.

```bash
./build/full/muzixdiagsys_advanced_platform nascar remote-race-control \
  race-control-request.json \
  build/tutorial/nascar-next/race-control.json \
  build/tutorial/nascar-next
```

Verify incident type, car key, fused confidence, event time, synchronization,
priority, rule recommendation, local/remote/combined availability, and the audit
hash chain. Lower one channel's availability or authentication state to test
failover and cyber qualification. Do not use the recommendation as an automatic
official ruling; it is evidence-oriented decision support.

## 16.6 Temporary venue study

Describe site capacity, barrier/fence requirements, routes, power assets,
network nodes, construction tasks, and weather scenarios.

```bash
./build/full/muzixdiagsys_advanced_platform nascar temporary-venue \
  venue-request.json \
  build/tutorial/nascar-next/venue.json \
  build/tutorial/nascar-next
```

Review barrier gap, evacuation time, emergency-route availability, power and
backup energy, network redundancy, project critical path, cost, and water depth.
Reorder construction tasks without changing dependencies; the schedule should
remain correct. Introduce a dependency cycle and confirm the request is rejected
before any partial schedule is committed.

## 16.7 Wheel-end durability study

Supply four corners named consistently with front identifiers beginning in `F`,
then define a braking/steering duty cycle.

```bash
./build/full/muzixdiagsys_advanced_platform nascar wheel-end-durability \
  wheel-end-request.json \
  build/tutorial/nascar-next/wheel-end.json \
  build/tutorial/nascar-next
```

Inspect disc, fluid, and bearing peak temperature, pad wear, fatigue damage,
remaining life, minimum single-lug clamp margin, and maximum steering force.
Use longer segments to verify thermal stability. Reduce lug torque or increase
vibration to produce a physically meaningful retention failure.

## 16.8 E/E architecture and cybersecurity study

Define nodes, signed firmware hashes, criticality, harness branches, buses,
messages, and optional faults.

```bash
./build/full/muzixdiagsys_advanced_platform nascar electrical-cyberphysical \
  electrical-request.json \
  build/tutorial/nascar-next/electrical.json \
  build/tutorial/nascar-next
```

Compare source and bus voltage, branch drop, overcurrent, bus utilization,
response time, critical availability, and fault evidence. Inject a firmware
tamper, replay, sensor spoof, brownout, or bus flood and confirm the appropriate
critical or security gate fails.

## 16.9 Causal setup-optimization study

Choose 1-20 setup features and provide more laps than model dimensions. Each lap
contains an ID, lap time, traffic loss, fuel mass, track temperature, and setup
object. Candidate setups may include per-feature constraints.

```bash
./build/full/muzixdiagsys_advanced_platform nascar race-engineering-intelligence \
  setup-request.json \
  build/tutorial/nascar-next/setup.json \
  build/tutorial/nascar-next
```

Inspect model RMSE, standardized and physical-unit effects, candidate
predictions, uncertainty, feature contributions, feasibility, and constraint
violations. Reject recommendations from poorly covered experiments even when
the arithmetic completes; the residual and intervention design remain part of
the engineering decision.

## 16.10 Broadcast and streaming study

Define camera coverage, race events, stream profiles, CDN regions, encoder and
contribution latency, QoE target, and latency target.

```bash
./build/full/muzixdiagsys_advanced_platform nascar broadcast-streaming \
  broadcast-request.json \
  build/tutorial/nascar-next/broadcast.json \
  build/tutorial/nascar-next
```

Review shot selection, replay packages, uncovered events, demand, effective CDN
capacity, load, buffering, end-to-end latency, QoE, redundancy, and hourly cost.
Move an event into an uncovered zone to verify the qualification fails. Increase
users until capacity is exceeded, then add an independent region and compare
load and QoE.

## 16.11 Complete NASCAR regression

After any NASCAR implementation, example, or documentation change, run:

```bash
cmake --build build/tutorial-nascar-next --parallel --target \
  nascar_competition_platform_tests \
  nascar_ecosystem_platform_tests \
  nascar_frontier_platform_tests \
  nascar_next_generation_platform_tests
ctest --test-dir build/tutorial-nascar-next --output-on-failure \
  -R '^nascar_.*_platform_unit_tests$'
python3 tests/nascar_next_generation_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```

# 17. Formula One regulatory and competition workflow

This workflow exercises the ten production systems in
`formula_one_regulatory_competition_platform.hpp`. Start with the canonical
requests in `examples/formula_one_regulatory_competition/`; copy them into a
working directory before changing parameters so the original evidence fixtures
remain reproducible.

## 17.1 Build and discover the platform

```bash
cmake -S . -B build/tutorial-f1-regulatory -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/tutorial-f1-regulatory --parallel --target \
  aesim_formula_one \
  muzixdiagsys_advanced_platform \
  formula_one_regulatory_competition_platform_tests
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory capabilities \
  build/tutorial-f1-regulatory/capabilities.json
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory self-test \
  build/tutorial-f1-regulatory/evidence \
  build/tutorial-f1-regulatory/self-test.json
```

The capability report must list ten domains. The self-test must execute each
domain and preserve a report plus `evidence_digest` for every result.

## 17.2 ERS hardware and Overtake Mode study

Use `ers_electrical_hardware.json` with
`F12026ErsElectrothermalLaboratory`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory ers-electrical-hardware \
  examples/formula_one_regulatory_competition/ers_electrical_hardware.json \
  build/tutorial-f1-regulatory/ers.json \
  build/tutorial-f1-regulatory/evidence
```

Review final SOC, true and reported meter energy, uncertainty, current, voltage,
shaft power, cell/MGU/inverter temperatures, and findings. Then set Overtake
Mode while proximity eligibility is false or a yellow condition is active; the
request must fail qualification. Increase segment duration to verify bounded
SOC and stable thermal integration.

## 17.3 Complete 22-car competition study

Use `full_field_competition.json` with `F1FullFieldCompetitionEngine`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory full-field-competition \
  examples/formula_one_regulatory_competition/full_field_competition.json \
  build/tutorial-f1-regulatory/race.json \
  build/tutorial-f1-regulatory/evidence
```

Confirm 22 unique cars, 22 unique drivers, 11 teams, and two cars per team.
Inspect end-of-lap classification, pit events, retirements, neutralizations,
overtakes, driver points, and constructor points. Repeat with the same seed and
compare canonical output. Delete one entrant to confirm the exact-grid
validation rejects a 21-car field.

## 17.4 Championship and Super-Licence study

Use `championship_governance.json` with
`F1ChampionshipGovernancePlatform`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory championship-governance \
  examples/formula_one_regulatory_competition/championship_governance.json \
  build/tutorial-f1-regulatory/championship.json \
  build/tutorial-f1-regulatory/evidence
```

Inspect race and Sprint points, exclusions, deductions, starts, wins,
countbacks, driver and constructor order, champion identity, and licence
eligibility. Create an equal-points scenario and verify countback resolves it
deterministically.

## 17.5 Power-unit homologation and customer-parity study

Use `power_unit_governance.json` with
`F1PowerUnitHomologationPlatform`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory power-unit-governance \
  examples/formula_one_regulatory_competition/power_unit_governance.json \
  build/tutorial-f1-regulatory/power-unit.json \
  build/tutorial-f1-regulatory/evidence
```

Review manufacturer capacity, hardware/software/calibration parity, element
serials, seals, allocations, and grid penalties. Give a customer team a
non-approved software version and confirm parity fails. Submit a specification
change with an expected performance gain and verify it is rejected.

## 17.6 ATR and operational-restrictions study

Use `operational_restrictions.json` with
`F1OperationalRestrictionsPlatform`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory operational-restrictions \
  examples/formula_one_regulatory_competition/operational_restrictions.json \
  build/tutorial-f1-regulatory/operations.json \
  build/tutorial-f1-regulatory/evidence
```

Compare entitled and used wind-on hours, run count, CFD compute units,
track-test mileage by category, and shutdown activity. Add overlapping tunnel
occupancy, exceed ATR compute entitlement, or schedule factory work within a
shutdown interval; each must produce a traceable finding.

## 17.7 Remote race-control fusion study

Use `remote_race_control.json` with
`F1RemoteRaceControlFusionCenter`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory remote-race-control \
  examples/formula_one_regulatory_competition/remote_race_control.json \
  build/tutorial-f1-regulatory/race-control.json \
  build/tutorial-f1-regulatory/evidence
```

Inspect corrected observation times, synchronization spread, weighted incident
type, involved cars, confidence, recommendation, local/remote availability,
primary control mode, and decision-chain hash. Mark both control paths
unauthenticated to verify the availability gate fails.

## 17.8 Pit-lane and parc ferme vision study

Use `pit_lane_vision.json` with
`F1PitLaneVisionOfficiatingPlatform`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory pit-lane-vision \
  examples/formula_one_regulatory_competition/pit_lane_vision.json \
  build/tutorial-f1-regulatory/pit-vision.json \
  build/tutorial-f1-regulatory/evidence
```

Inspect chronological violations, coalesced intervals, confidence, cars, and
evidence references. Add pit speeding, unsafe release, an uncontrolled wheel,
or unauthorized parc ferme work and confirm each violation is independently
identified.

## 17.9 Appeals and precedent study

Use `regulatory_case_law.json` with `F1RegulatoryCaseLawCompiler`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory regulatory-case-law \
  examples/formula_one_regulatory_competition/regulatory_case_law.json \
  build/tutorial-f1-regulatory/case-law.json \
  build/tutorial-f1-regulatory/evidence
```

Review standing, deadline, fee, evidence, jurisdiction, right-of-review gates,
precedent similarity, outcome, penalty units, and stay request. Move filing time
past the permitted window and verify the filing is procedurally invalid.

## 17.10 Accident reconstruction study

Use `accident_reconstruction.json` with
`F1AccidentReconstructionLaboratory`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory accident-reconstruction \
  examples/formula_one_regulatory_competition/accident_reconstruction.json \
  build/tutorial-f1-regulatory/accident.json \
  build/tutorial-f1-regulatory/evidence
```

Inspect fused trajectories, contact pair, closing speed, angle, impulse, delta-V,
energy, barrier deformation, acceleration, HIC15-like and neck-load estimates,
and uncertainty. Treat these as engineering estimates; they do not establish a
medical diagnosis or legal conclusion.

## 17.11 Grade 1 circuit study

Use `circuit_homologation.json` with `F1CircuitHomologationPlatform`.

```bash
./build/tutorial-f1-regulatory/muzixdiagsys_advanced_platform \
  f1-regulatory circuit-homologation \
  examples/formula_one_regulatory_competition/circuit_homologation.json \
  build/tutorial-f1-regulatory/circuit.json \
  build/tutorial-f1-regulatory/evidence
```

Review design speed, kinetic energy, required versus available runoff, required
versus available sight distance, barrier angle, drainage, pit geometry,
marshal-post spacing, medical readiness, light-panel coverage, and certificate
status. Reduce sight distance or runoff and confirm the certificate is
withheld.

## 17.12 Complete Formula One regression

```bash
cmake --build build/tutorial-f1-regulatory --parallel --target \
  formula_one_championship_operations_tests \
  formula_one_platform_tests \
  formula_one_race_engineering_tests \
  formula_one_performance_laboratory_tests \
  formula_one_team_competition_tests \
  formula_one_design_qualification_tests \
  formula_one_frontier_laboratory_tests \
  formula_one_physical_operations_laboratory_tests \
  formula_one_regulatory_competition_platform_tests
ctest --test-dir build/tutorial-f1-regulatory --output-on-failure \
  -R '^formula_one_.*_unit_tests$'
python3 tests/formula_one_regulatory_competition_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```



# 18. IndyCar development and operations workflow

The production API is declared in `indycar_development_operations_platform.hpp`, and the focused executable regression target is `indycar_development_operations_platform_tests`.

The callable classes are `IndyCarDevelopmentLadderPlatform`, `IndyCarFirestoneProductionMetrologyPlatform`, `IndyCarPowerUnitSupplyHomologationPlatform`, `IndyCarRenewableFuelLubricantLaboratory`, `IndyCarElectricalCyberPhysicalTwin`, `IndyCarRaceEngineeringIntelligence`, `IndyCarDriverSimulatorQualificationLaboratory`, `IndyCarTeamFactoryLogisticsTwin`, `IndyCarCircuitHomologationSafetyPlatform`, and `IndyCarMedicalOperationsBiomechanicsPlatform`.

## 18.1 Build and inspect the ten-domain platform

```bash
cmake -S . -B build/tutorial-indycar-development -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/tutorial-indycar-development --parallel --target \
  aesim_indycar \
  muzixdiagsys_advanced_platform \
  indycar_development_operations_platform_tests
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development capabilities \
  build/tutorial-indycar-development/capabilities.json
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development self-test \
  build/tutorial-indycar-development/evidence \
  build/tutorial-indycar-development/self-test.json
```

Confirm the capability report contains ten domains and every self-test result contains `passed` and a 64-character `evidence_digest`.

## 18.2 INDY NXT and driver-development ladder

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development development-ladder \
  examples/indycar_development_operations/development_ladder.json \
  build/tutorial-indycar-development/development-ladder.json \
  build/tutorial-indycar-development/evidence
```

Review readiness, ROP readiness, circuit-type experience, commercial feasibility, and seat assignment. Increase the oval-start requirement above the candidate's history and verify the candidate is not marked ROP-ready. Reduce seat budget below salary net of sponsorship and verify commercial feasibility fails.

## 18.3 Firestone production and allocation

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development firestone-production \
  examples/indycar_development_operations/firestone_production.json \
  build/tutorial-indycar-development/firestone.json \
  build/tutorial-indycar-development/evidence
```

Inspect batch yield, metrology findings, rejected serials, accepted inventory, and allocation. Mark a tire's X-ray or shearography status unacceptable; it must remain traceable but disappear from allocatable inventory. Request more accepted tires than remain and verify the allocation reports a shortage.

## 18.4 Power-unit supply and customer parity

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development power-unit-supply \
  examples/indycar_development_operations/power_unit_supply.json \
  build/tutorial-indycar-development/power-unit-supply.json \
  build/tutorial-indycar-development/evidence
```

Review hardware/software identity, calibration release, works/customer parity, serialized pool, seal state, life margin, and manufacturer capacity. Give a customer entrant an unapproved software ID or a different calibration release and confirm parity fails. Break a component seal or exceed its life limit and confirm the pool finding identifies the exact serial.

## 18.5 Renewable fuel and lubricant quality

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development renewable-fuel-quality \
  examples/indycar_development_operations/renewable_fuel_quality.json \
  build/tutorial-indycar-development/fuel-quality.json \
  build/tutorial-indycar-development/evidence
```

Review corrected density, batch energy, octane, renewable fraction, water, deposits, viscosity index, fuel dilution, wear metals, and oxidation. Increase water contamination independently of lubricant condition and verify only the affected batch fails. Increase fuel dilution in the lubricant sample and verify its service decision changes.

## 18.6 Electrical/electronic and cyber-physical twin

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development electrical-cyberphysical \
  examples/indycar_development_operations/electrical_cyberphysical.json \
  build/tutorial-indycar-development/electrical.json \
  build/tutorial-indycar-development/evidence
```

Inspect node voltage drop, firmware and calibration identity, secure boot, authentication, sensor bias, bus utilization, latency/loss risk, attack detection, and containment. Replace the approved firmware ID with a mismatched value and verify the platform fails qualification. Increase frame rate until bus utilization exceeds the allowed threshold and confirm a network-capacity finding.

## 18.7 Causal race-engineering optimizer

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development race-engineering-intelligence \
  examples/indycar_development_operations/race_engineering_intelligence.json \
  build/tutorial-indycar-development/race-engineering.json \
  build/tutorial-indycar-development/evidence
```

Inspect corrected observations, parameter effects, uncertainty, candidate constraints, predicted lap time, and ranking. Add observations at different fuel, track temperature, traffic loss, and tire age so setup effects remain identifiable. Submit a candidate outside its declared parameter bounds and verify it is excluded from the recommendation.

## 18.8 Driver and simulator qualification

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development driver-simulator-qualification \
  examples/indycar_development_operations/driver_simulator_qualification.json \
  build/tutorial-indycar-development/driver-simulator.json \
  build/tutorial-indycar-development/evidence
```

Review final core temperature, hydration reserve, neck and steering load, braking workload, cognitive and visual workload, reaction-time degradation, aggregate latency, force errors, and response correlation. Raise cockpit temperature or reduce cooling to test human-performance limits. Increase display latency or reduce vehicle-response correlation to test simulator qualification independently.

## 18.9 Team factory and event logistics

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development team-factory-logistics \
  examples/indycar_development_operations/team_factory_logistics.json \
  build/tutorial-indycar-development/factory-logistics.json \
  build/tutorial-indycar-development/evidence
```

Review ordered task start/finish times, resource usage, consumed and remaining parts, shipments, freight cost, critical completion, and deadline margin. Add a dependency cycle and confirm validation rejects the request. Remove a required part and confirm the task fails without consuming unrelated inventory or unblocking dependent tasks.

## 18.10 Circuit homologation and venue safety

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development circuit-homologation \
  examples/indycar_development_operations/circuit_homologation.json \
  build/tutorial-indycar-development/circuit.json \
  build/tutorial-indycar-development/evidence
```

Review segment kinetic energy, runoff and sight-distance demand, barrier angle and type, debris-fence height, drainage margin, pit-lane geometry, marshal spacing, medical response, and certificate status. Reduce debris-fence height or sight distance and verify the certificate is withheld. Change the circuit type to an oval without appropriate energy-absorbing barriers and verify the oval-specific finding.

## 18.11 Medical operations and injury biomechanics

```bash
./build/tutorial-indycar-development/muzixdiagsys_advanced_platform \
  indycar-development medical-operations \
  examples/indycar_development_operations/medical_operations.json \
  build/tutorial-indycar-development/medical.json \
  build/tutorial-indycar-development/evidence
```

Review velocity change, peak acceleration, HIC-like exposure, neck/chest/leg loads, combined injury probability, fire/smoke/electrical risk, egress, dispatch time, resource capacity, and hospital selection. Mark the high-voltage system as present but not isolated to verify the electrical-exposure finding. These outputs support training and resource planning; they are not clinical diagnoses.

## 18.12 Complete IndyCar regression and sanitizer workflow

```bash
cmake --build build/tutorial-indycar-development --parallel --target \
  indycar_platform_tests \
  indycar_operations_platform_tests \
  indycar_future_competition_platform_tests \
  indycar_frontier_expansion_platform_tests \
  indycar_development_operations_platform_tests
ctest --test-dir build/tutorial-indycar-development --output-on-failure \
  -R '^indycar_.*_unit_tests$'
python3 tests/indycar_development_operations_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .

cmake -S . -B build/tutorial-indycar-development-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF
cmake --build build/tutorial-indycar-development-sanitize --parallel --target \
  indycar_development_operations_platform_tests
ctest --test-dir build/tutorial-indycar-development-sanitize \
  --output-on-failure \
  -R '^indycar_development_operations_platform_unit_tests$'
```

# 19. Formula One industrial and ecosystem workflow

The public API is exported from `formula_one_industrial_ecosystem_platform.hpp`. The compiled `formula_one_industrial_ecosystem_platform_tests` target validates every production class and canonical request before the workflows below are used.

The ten domain/class pairs are:

- `pu-financial-compliance` — `F1PowerUnitFinancialCompliancePlatform`
- `tyre-supplier-production` — `F1TyreProductionMetrologyPlatform`
- `sustainable-fuel-production` — `F1SustainableFuelProductionLaboratory`
- `factory-manufacturing` — `F1FactoryManufacturingTwin`
- `vehicle-assembly-variation` — `F1VehicleAssemblyVariationTwin`
- `causal-setup-intelligence` — `F1CausalRaceEngineeringOptimizer`
- `aero-raceability-design` — `F1AerodynamicRaceabilityDesignLaboratory`
- `cyber-rf-resilience` — `F1CyberPhysicalSecurityLaboratory`
- `driver-medical-performance` — `F1DriverMedicalPerformanceLaboratory`
- `driver-development-ladder` — `F1DriverDevelopmentLadderPlatform`

## 19.1 Build and inspect the focused platform

```bash
cmake -S . -B build/tutorial-f1-industrial -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON
cmake --build build/tutorial-f1-industrial --parallel --target \
  aesim_formula_one_industrial \
  formula_one_industrial_ecosystem_platform_tests
ctest --test-dir build/tutorial-f1-industrial --output-on-failure \
  -R '^formula_one_industrial_ecosystem_platform_unit_tests$'

./build/full/muzixdiagsys_advanced_platform \
  f1-industrial capabilities \
  build/tutorial-f1-industrial/capabilities.json
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial self-test \
  build/tutorial-f1-industrial/evidence \
  build/tutorial-f1-industrial/self-test.json
```

Confirm the capability report lists ten domains and every self-test result contains a 64-character evidence digest.

## 19.2 Power-unit manufacturer financial study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial pu-financial-compliance \
  examples/formula_one_industrial_ecosystem/pu_financial_compliance.json \
  build/tutorial-f1-industrial/pu-finance.json \
  build/tutorial-f1-industrial/evidence
```

Review classified entries, relevant cost, permitted exclusions, reconciliation discrepancy, related-party cost, cap headroom, and overspend classification. Mark a claimed exclusion as not permitted and verify it remains relevant cost and produces a finding. Remove supporting evidence from a related-party entry and verify the submission fails independently of cap headroom.

## 19.3 Pirelli production and allocation study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial tyre-supplier-production \
  examples/formula_one_industrial_ecosystem/tyre_supplier_production.json \
  build/tutorial-f1-industrial/tyres.json \
  build/tutorial-f1-industrial/evidence
```

Inspect release yield, quarantine, metrology, traceability, capacity utilization, and allocation by specification. Increase radial-force variation or disable shearography to quarantine a batch. Increase event allocation beyond released quantity and confirm the shortage is detected.

## 19.4 Sustainable fuel production study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial sustainable-fuel-production \
  examples/formula_one_industrial_ecosystem/sustainable_fuel_production.json \
  build/tutorial-f1-industrial/fuel.json \
  build/tutorial-f1-industrial/evidence
```

Review feedstock eligibility, process efficiency, lifecycle carbon intensity, density, octane, lower heating value, latent heat, and oxygen fraction. Break chain of custody or raise process-energy carbon intensity and confirm release failure. Change component fractions without preserving a unit sum and confirm request validation rejects the blend.

## 19.5 Factory manufacturing study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial factory-manufacturing \
  examples/formula_one_industrial_ecosystem/factory_manufacturing.json \
  build/tutorial-f1-industrial/factory.json \
  build/tutorial-f1-industrial/evidence
```

Review task chronology, work-center use, parts consumed, inventory remaining, makespan, release margin, cost, and carbon. Add a dependency cycle and confirm validation rejects it. Remove prepreg and confirm the failed cure task consumes no unavailable material and blocks inspection.

## 19.6 Vehicle assembly and variation study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial vehicle-assembly-variation \
  examples/formula_one_industrial_ecosystem/vehicle_assembly_variation.json \
  build/tutorial-f1-industrial/assembly.json \
  build/tutorial-f1-industrial/evidence
```

Review every datum error, uncertainty-adjusted normalized error, RSS stack, predicted scrutineering margin, torque state, and operation duration. Move a floor datum beyond tolerance or alter a mandatory fastener torque and verify the virtual build fails.

## 19.7 Causal setup-intelligence study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial causal-setup-intelligence \
  examples/formula_one_industrial_ecosystem/causal_setup_intelligence.json \
  build/tutorial-f1-industrial/setup.json \
  build/tutorial-f1-industrial/evidence
```

Inspect covariate coefficients, residual noise, setup treatment effects, standard errors, constraint penalties, and recommendation. Add data across fuel mass, temperature, traffic, tyre age, and driver learning to reduce confounding. Make the faster setup violate ride-height or energy margin and verify the penalty can reverse the recommendation.

## 19.8 Aerodynamic raceability study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial aero-raceability-design \
  examples/formula_one_industrial_ecosystem/aero_raceability_design.json \
  build/tutorial-f1-industrial/aero.json \
  build/tutorial-f1-industrial/evidence
```

Review circuit-level pass probability, field convergence, efficiency, liftoff margin, manufacturer spread, and package score. Lower every package's liftoff margin and confirm no unsafe option is reported as compliant. Increase wake loss and recovery distance to observe the raceability penalty.

## 19.9 Garage cybersecurity and RF study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial cyber-rf-resilience \
  examples/formula_one_industrial_ecosystem/cyber_rf_resilience.json \
  build/tutorial-f1-industrial/cyber.json \
  build/tutorial-f1-industrial/evidence
```

Review node trust, bus utilization, packet loss, RF SNR margin, link resilience, attack residual risk, and aggregate qualification. Substitute an unapproved firmware ID, disable secure boot, remove encryption, increase frame loading, or lower transmit power to exercise independent cyber and RF failure modes.

## 19.10 Driver medical and egress study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial driver-medical-performance \
  examples/formula_one_industrial_ecosystem/driver_medical_performance.json \
  build/tutorial-f1-industrial/medical.json \
  build/tutorial-f1-industrial/evidence
```

Review core temperature, hydration reserve, reaction-time estimate, heat strain, cumulative load exposure, egress, electrical isolation, and medical response time. Raise cockpit temperature or remove cooling to study heat limits. Mark high voltage present but not isolated and verify the fatal response finding. The output is an engineering estimate, not a medical diagnosis.

## 19.11 Driver-development ladder study

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial driver-development-ladder \
  examples/formula_one_industrial_ecosystem/driver_development_ladder.json \
  build/tutorial-f1-industrial/ladder.json \
  build/tutorial-f1-industrial/evidence
```

Review normalized junior-series performance, academy preference, simulator correlation, FP1 readiness, Super-Licence eligibility, budget, and seat assignments. Remove both drivers' Super-Licence points and confirm the race seat remains unfilled while a non-race development role can still be evaluated under its own requirements.

## 19.12 Complete Formula One industrial regression

```bash
python3 tests/formula_one_industrial_ecosystem_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .

cmake -S . -B build/tutorial-f1-industrial-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build/tutorial-f1-industrial-sanitize --parallel --target \
  formula_one_industrial_ecosystem_platform_tests
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=print_stacktrace=1 \
ctest --test-dir build/tutorial-f1-industrial-sanitize --output-on-failure \
  -R '^formula_one_industrial_ecosystem_platform_unit_tests$'
```

# 20. Formula One predictive-fidelity and telemetry-correlation workflow

The predictive-fidelity platform is a typed C++ API, not a new interactive
console root. Link against `aesim_formula_one` directly or use the transitive
`aesim_advanced` dependency.

The integrated workflow uses `F1AdvancedTransientTyreModel`,
`F1FullyCoupledCarDynamicsKernel`, `F1SensorDaqPipeline`,
`F1ClockSynchronizationEstimator`, `F1TelemetryStateParameterEstimator`,
`F1ValidationFramework`, `F1UncertaintyQuantificationFramework`, and
`F1IdentifiabilityFramework`. These are production implementations in
`formula_one_fidelity_platform.hpp`; the focused executable is
`formula_one_fidelity_platform_tests`.

## 20.1 Focused build

```bash
cmake -S . -B build/tutorial-f1-fidelity -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/tutorial-f1-fidelity --parallel 2 --target \
  formula_one_fidelity_platform_tests
ctest --test-dir build/tutorial-f1-fidelity --output-on-failure \
  -R '^formula_one_fidelity_(platform_unit_tests|source_regression)$'
```

## 20.2 Create a full-car study

```cpp
#include "aesim/advanced/formula_one_fidelity_platform.hpp"

using namespace aesim::advanced;

F1FullyCoupledCarDynamicsKernel car;
F1CoupledCarState state = car.make_initial_state(40.0);
F1CoupledCarControl control;
F1CoupledCarEnvironment environment;
control.throttle = 0.55;
control.steering_wheel_angle_rad = 0.14;

for (int index = 0; index < 2500; ++index) {
    const auto step = car.step(0.002, control, environment, state);
    state = step.state;
}
```

Check speed, yaw rate, roll, pitch, corner loads, tyre slip, tyre temperature,
fuel mass, and the energy residual. Reduce `maximum_internal_step_s` and verify
important outputs converge rather than changing materially with step size.

## 20.3 Repeat the study with standing water

Set `environment.water_film_depth_m` independently at each corner. Compare dry
and wet longitudinal force, lateral force, aquaplaning fraction, drained water,
wet-friction scale, wheel speed, and vehicle trajectory. Do not represent a
partially wet circuit with one global friction multiplier when corner-local
water state is known.

## 20.4 Emulate the instrumentation chain

Create one `F1SensorChannelConfiguration` per telemetry channel. Use the real
sample rate, quantization, filter cutoff, latency, jitter, clock offset, drift,
and calibration uncertainty where available. Call `sample_until()` with
physical truth and `receive_until()` at the simulated logger or telemetry-server
time. Preserve source timestamp, arrival timestamp, sequence number, and
saturation status.

## 20.5 Synchronize clocks

Build `F1ClockSynchronizationObservation` values from shared trigger events,
logger correlation pulses, or known reference transitions. Fit the affine clock
map and reject a synchronization set when RMS or maximum residual exceeds the
study's timing requirement. Apply `correct()` before interpolating channels or
constructing estimator updates.

## 20.6 Estimate states and parameters

Initialize `F1TelemetryStateParameterEstimator` with physically justified prior
uncertainty. Predict at a fixed process rate and update only with measurements
that have arrived and been synchronized. Inspect normalized innovations,
accepted and rejected counts, posterior state, posterior parameter scale, and
posterior standard deviation.

Use wheel speed together with an independent longitudinal-speed measurement to
identify wheel-speed scale. Use yaw rate together with lateral acceleration and
steering excitation to separate yaw-rate bias from actual yaw motion. Constant
straight-line data is not sufficient to identify tyre-friction scale.

## 20.7 Prove the calibration is identifiable

Before interpreting a parameter fit, run `F1IdentifiabilityFramework::analyze()`
with the exact observation vector, parameter scales, and measurement standard
deviations used in the experiment. Require full numerical rank and an acceptable
condition number. Treat entries in `weak_parameter_names` as a test-design
problem, not as a reason to force the optimizer harder.

Add independent maneuvers or sensors when parameters are confounded. Examples
include a steering-frequency sweep, controlled brake event, coast-down segment,
heave excitation, independent ride-height measurement, or a different speed and
load range.

## 20.8 Validate on withheld data

Use `F1ValidationFramework` on laps or maneuvers excluded from calibration.
Review RMSE, normalized RMSE, bias, maximum error, correlation, residual
lag-one autocorrelation, and prediction-interval coverage. High correlation with
a large bias is not sufficient. Low RMSE with highly autocorrelated residuals
usually indicates missing dynamics.

## 20.9 Propagate uncertainty

Define uncertain tyre, aero, mass, wind, water, sensor, or driver parameters and
run `F1UncertaintyQuantificationFramework::propagate()`. Use a fixed random seed
and enough Latin-hypercube samples for stable quantiles. Report the median and
confidence interval, not only the mean. Compare Pearson sensitivity with the
multiple standardized regression coefficients to detect correlated inputs.

## 20.10 Complete fidelity regression

```bash
python3 tests/formula_one_fidelity_source_regression.py .
python3 tests/user_manual_regression.py .
python3 tests/documentation_consistency_regression.py .

clang++ -std=c++17 -O1 -g \
  -Wall -Wextra -Wpedantic -Wshadow -Wformat=2 \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Iinclude \
  tests/formula_one_fidelity_platform_tests.cpp \
  src/advanced/formula_one_fidelity_platform.cpp \
  -o build/tutorial-f1-fidelity-sanitized
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=print_stacktrace=1 \
  build/tutorial-f1-fidelity-sanitized
```



# 21. Formula One multiphysics, optimization, and real-time workflow

The integrated workflow uses `F1FlexibleBodyVehicleDynamics`,
`F1PersistentMultiCarWakeField`, `F1IntegratedThermalFluidNetwork`,
`F1PhysicsOfFailureLifing`, `F1OptimalExperimentDesigner`,
`F1AdvancedBayesianEstimator`, `F1AdaptiveMultifidelityManager`,
`F1DifferentiableFormulaOneRuntime`, `F1CompressiblePowerUnitGasDynamics`, and
`F1RealtimeEcuHilIntegration`. The public include is
`formula_one_multiphysics_platform.hpp`; the focused executable is
`formula_one_multiphysics_platform_tests`.

## 21.1 Focused build

```bash
cmake -S . -B build/tutorial-f1-multiphysics -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/tutorial-f1-multiphysics --parallel 2 --target \
  formula_one_multiphysics_platform_tests
ctest --test-dir build/tutorial-f1-multiphysics --output-on-failure \
  -R '^formula_one_multiphysics_(platform_unit_tests|source_regression)$'
```

## 21.2 Structural and wake study

Create `F1FlexibleBodyVehicleDynamics`, preserve `F1FlexibleBodyState`, and feed
it corner loads from the coupled-car model. Apply recovered corner deformation
to suspension geometry and recovered aero deformation to the selected aero
model. Advance `F1PersistentMultiCarWakeField` once per field step with every
car's position, velocity, downforce, drag, and spray source. Use the returned
axle-specific scales for each following car.

## 21.3 Thermal and life study

Build a closed `F1IntegratedThermalFluidNetwork` for each fluid circuit. Validate
flow direction, pressure, temperature, cavitation flags, and conservation
residuals before connecting component derating. Store stress, temperature, and
bearing-load histories and pass them to `F1PhysicsOfFailureLifing`. Carry the
returned state into the next session.

## 21.4 Calibration campaign

Construct candidate sensitivity matrices using the differentiable runtime or
controlled perturbations. Run `F1OptimalExperimentDesigner` and require full
rank. Execute the selected tests, then assimilate telemetry using the UKF or
particle filter. Keep withheld data for independent validation.

## 21.5 Adaptive fidelity and derivatives

Register map, transient, and high-fidelity models with calibrated errors and
runtimes. Request only the fidelity required by the study. Use
`F1DifferentiableFormulaOneRuntime` for smooth objective gradients and Hessians;
do not claim exact derivatives through unrepresented discrete events.

## 21.6 Power unit and HIL

Advance `F1CompressiblePowerUnitGasDynamics` with an internal step that satisfies
the acoustic CFL limit. Feed torque and thermal outputs into the vehicle and
thermal network. Register ECU tasks in `F1RealtimeEcuHilIntegration`, schedule
CAN messages, inject timing and signal faults, and inspect response time,
deadline misses, transport latency, and utilization.

# Generalized Scientific Simulation Platform Workflow

## Build only the generalized platform regression target

```bash
cmake -S . -B build/generalized -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/generalized --parallel 2 --target \
  generalized_simulation_platform_tests
ctest --test-dir build/generalized --output-on-failure \
  -R '^generalized_simulation_platform_(unit_tests|source_regression)$'
```

The unit target links `aesim_advanced`, so this command also verifies integration
with the existing advanced dependency graph. The source regression checks public
symbols, production source files, aggregate-header export, CMake registration,
Python SDK presence, documentation, and unfinished-marker absence.

## Python notebook control

Install the local package in editable mode:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -e python
```

Then connect to an application that has registered routes on
`GeneralizedHttpServer`:

```python
from muzixdiag.generalized import GeneralizedClient

client = GeneralizedClient("http://127.0.0.1:8080")
health = client.health()
table = client.query("SELECT * FROM telemetry LIMIT 20")
table
```

## Direct source-integrity check

```bash
python3 tests/generalized_simulation_platform_source_regression.py .
```

## Sanitizer build

```bash
cmake -S . -B build/generalized-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/generalized-sanitize --parallel 2 --target \
  generalized_simulation_platform_tests
ctest --test-dir build/generalized-sanitize --output-on-failure \
  -R '^generalized_simulation_platform_unit_tests$'
```

# Scientific Fidelity and Predictive Accuracy Workflow

## Build and run the focused platform suite

```bash
cmake -S . -B build/scientific-fidelity -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/scientific-fidelity --parallel 2 --target \
  scientific_fidelity_platform_tests
ctest --test-dir build/scientific-fidelity --output-on-failure \
  -R '^scientific_fidelity_platform_(unit_tests|source_regression)$'
```

## Recommended end-to-end sequence

1. Assemble and scale the strongly coupled residual blocks.
2. Verify nonlinear convergence and conservation.
3. Run h, p, and time-step studies for transport fields.
4. Resolve impact and friction with complementarity constraints.
5. Generate correlated random fields and condition them on inspections.
6. Propagate a field ensemble and assimilate measurements.
7. Run PDE-constrained parameter inversion with withheld validation data.
8. Validate Peng-Robinson properties against trusted mixture data.
9. Maintain posterior probability over competing models.
10. Build a correlated total error budget.
11. Pass truth signals through the virtual instrument chain.
12. Accumulate progressive material and cohesive-interface damage.

## Strict standalone compiler check

```bash
g++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  tests/scientific_fidelity_platform_tests.cpp \
  src/advanced/scientific_fidelity_platform_a.cpp \
  src/advanced/scientific_fidelity_platform_b.cpp \
  src/advanced/scientific_fidelity_platform_c.cpp \
  -o scientific_fidelity_platform_tests
./scientific_fidelity_platform_tests
```

## Sanitizer check

```bash
clang++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror -fsanitize=address,undefined \
  -fno-omit-frame-pointer \
  tests/scientific_fidelity_platform_tests.cpp \
  src/advanced/scientific_fidelity_platform_a.cpp \
  src/advanced/scientific_fidelity_platform_b.cpp \
  src/advanced/scientific_fidelity_platform_c.cpp \
  -o scientific_fidelity_platform_tests_sanitize
ASAN_OPTIONS=detect_leaks=1 ./scientific_fidelity_platform_tests_sanitize
```


## Formula One integrated realism focused build

```bash
cmake -S . -B build/f1-realism -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=OFF -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/f1-realism --parallel 2 --target formula_one_realism_platform_tests
ctest --test-dir build/f1-realism --output-on-failure \
  -R '^formula_one_realism_(platform_unit_tests|source_regression)$'
```


# Continuum Reality and Adaptive Resolution Workflow

## Focused build

```bash
cmake -S . -B build/continuum-reality -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/continuum-reality --parallel 2 --target \
  continuum_reality_platform_tests
ctest --test-dir build/continuum-reality --output-on-failure \
  -R '^continuum_reality_platform_(unit_tests|source_regression)$'
```

## Recommended engineering sequence

1. Run `AutomaticManufacturedSolutionVerifier` on the governing PDE and boundary treatment.
2. Configure `MovingBoundaryMultiphaseCfdSolver` and verify liquid-volume and divergence residuals.
3. Select and calibrate `TurbulenceHierarchySolver`.
4. Configure `GeneralizedPorousElectrodeSolver` or `TwoFluidPhaseChangeSolver` where electrochemical or two-phase behavior matters.
5. Couple radiative source terms through `ParticipatingMediaRadiationSolver`.
6. Assimilate measured fields with `ThreeDimensionalFieldAssimilationAndInversion`.
7. Evaluate soil and mobility response with `PoromechanicsTerrainSolver`.
8. Advance particle distributions with `AerosolPopulationBalanceSolver`.
9. Pass regional error, uncertainty, sensitivity, event, and cost metrics to `SimulationWideAdaptiveResolutionController`.
10. Repeat convergence, calibration, uncertainty, and independent validation.

## Strict standalone test

```bash
g++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  tests/continuum_reality_platform_tests.cpp \
  src/advanced/continuum_reality_platform_a.cpp \
  src/advanced/continuum_reality_platform_b.cpp \
  src/advanced/continuum_reality_platform_c.cpp \
  -o continuum_reality_platform_tests
./continuum_reality_platform_tests
```

# Formula One Integrated Operations, Safety, and Energy Workflow

## Focused build

```bash
cmake -S . -B build/f1-integrated-operations -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/f1-integrated-operations --parallel 2 --target \
  formula_one_integrated_operations_platform_tests
ctest --test-dir build/f1-integrated-operations --output-on-failure \
  -R '^formula_one_integrated_operations_(platform_unit_tests|source_regression)$'
```

## Recommended engineering sequence

1. Build pit-member geometry, task dependencies, tool cycles, and traffic-gap assumptions for `F1PitCrewGarageOperationsTwin`.
2. Validate crash pulses and restraint values before running `F1OccupantHansEgressBiomechanics`.
3. Calibrate participant, SNR, clipping, workload, and stress inputs for `F1TeamRadioSemanticComprehensionModel`.
4. Create the service-road graph, recovery resources, consumables, and task graph for `F1DynamicTracksideRecoveryOperations`.
5. Supply water displacement and wake conditions to `F1SprayOpticsVisibilityPhysics`.
6. Couple `F1CarbonBrakeTribologyThermomechanics` to wheel speed, brake pressure, cooling air, and water exposure.
7. Feed ride height, pitch, floor motion, and actuator sensors to `F1ActiveAeroGroundEffectTwin`.
8. Couple `F1SustainableFuelCombustionTurboTwin` to the gas-path and thermal-fluid models.
9. Run `F1SwitchingLevelErsEmcTwin` with a time step that resolves inverter switching.
10. Fuse CFD, tunnel, and track observations with `F1BayesianAeroFieldFusion`, then reserve independent data for validation.

## Strict compiler and sanitizer check

```bash
clang++ -std=c++17 -O1 -g -Iinclude \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror -fsanitize=address,undefined \
  -fno-omit-frame-pointer \
  src/advanced/formula_one_integrated_operations_platform_a.cpp \
  src/advanced/formula_one_integrated_operations_platform_b.cpp \
  src/advanced/formula_one_integrated_operations_platform_c.cpp \
  tests/formula_one_integrated_operations_platform_tests.cpp \
  -o formula_one_integrated_operations_platform_tests_sanitize
ASAN_OPTIONS=detect_leaks=1 \
  ./formula_one_integrated_operations_platform_tests_sanitize
```

The implementation is declared in
`include/aesim/advanced/formula_one_integrated_operations_platform.hpp` and the
focused executable target is `formula_one_integrated_operations_platform_tests`.


# IndyCar Integrated Fidelity Workflow

The public API is declared in
`include/aesim/advanced/indycar_integrated_fidelity_platform.hpp`. The focused
test target is `indycar_integrated_fidelity_platform_tests`. The ten public
classes are `IndyCarIntegratedCoSimulationRuntime`,
`IndyCarTelemetryAssimilationCalibration`, `IndyCarFullMultibodyVehicle`,
`IndyCarDetailedTireContactModel`, `IndyCarUnsteadyAeroelasticAerodynamics`,
`IndyCarClosedLoopEcuHybridControl`,
`IndyCarRadioSemanticsTimingUncertainty`, `IndyCarPitLaneDiscreteEventTwin`,
`IndyCarOccupantBiomechanics`, and
`IndyCarUncertaintyModelValidityFramework`.

## Focused configure and build

```bash
cmake -S . -B build/tutorial-indycar-integrated -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-indycar-integrated --parallel --target \
  aesim_indycar \
  indycar_integrated_fidelity_platform_tests \
  muzixdiagsys_advanced_platform
```

## Inspect and self-test the platform

```bash
./build/tutorial-indycar-integrated/muzixdiagsys_advanced_platform \
  indycar-integrated capabilities \
  build/tutorial-indycar-integrated/capabilities.json
./build/tutorial-indycar-integrated/muzixdiagsys_advanced_platform \
  indycar-integrated self-test \
  build/tutorial-indycar-integrated/evidence \
  build/tutorial-indycar-integrated/self-test.json
```

## Run all ten canonical requests

```bash
set -euo pipefail
for item in \
  integrated-cosimulation:integrated_cosimulation \
  telemetry-assimilation:telemetry_assimilation \
  full-multibody:full_multibody \
  tire-contact:tire_contact \
  aeroelastic-aerodynamics:aeroelastic_aerodynamics \
  ecu-hybrid-control:ecu_hybrid_control \
  radio-timing:radio_timing \
  pit-lane-twin:pit_lane_twin \
  occupant-biomechanics:occupant_biomechanics \
  uncertainty-validity:uncertainty_validity
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/tutorial-indycar-integrated/muzixdiagsys_advanced_platform \
    indycar-integrated "$domain" \
    "examples/indycar_integrated_fidelity/${stem}.json" \
    "build/tutorial-indycar-integrated/${stem}.result.json" \
    build/tutorial-indycar-integrated/evidence
done
```

## Interpretation sequence

1. Confirm the co-simulation rates are exact multiples of the base step and
   review energy/coupling residuals.
2. Review telemetry innovations and rejected measurements before accepting
   calibrated parameters.
3. Verify multibody wheel loads and suspension travel remain within the intended
   vehicle envelope.
4. Inspect tire utilization, temperature, pressure, wear, hydroplaning speed,
   and structural margin together.
5. Confirm aero stall/reattachment and modal states remain bounded.
6. Audit every ECU/hybrid intervention and protection override.
7. Treat radio comprehension and fused timing as probabilities with provenance,
   not exact truths.
8. Inspect pit-lane resource queues, double stacking, and release margins.
9. Treat occupant metrics as screening outputs pending validated biomechanical
   data and expert review.
10. Reject or mitigate any run that the unified validity framework places
    outside its calibration or numerical envelope.

## Regression and sanitizer workflow

```bash
ctest --test-dir build/tutorial-indycar-integrated --output-on-failure \
  -R '^indycar_.*(unit_tests|source_regression)$'
python3 tests/indycar_integrated_fidelity_source_regression.py .

cmake -S . -B build/tutorial-indycar-integrated-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-indycar-integrated-sanitize --parallel --target \
  indycar_integrated_fidelity_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --test-dir build/tutorial-indycar-integrated-sanitize --output-on-failure \
  -R '^indycar_integrated_fidelity_platform_unit_tests$'
```

# NASCAR Integrated Fidelity Workflow

This workflow exercises the additive twelve-domain NASCAR high-fidelity module.
It preserves the existing 40-domain `nascar` command and uses the separate
`nascar-integrated` command family.

## Configure and build

```bash
cmake -S . -B build/tutorial-nascar-integrated -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-nascar-integrated --parallel --target \
  aesim_nascar \
  nascar_integrated_fidelity_platform_tests \
  muzixdiagsys_advanced_platform
```

## Inspect and self-test the platform

```bash
./build/tutorial-nascar-integrated/muzixdiagsys_advanced_platform \
  nascar-integrated capabilities \
  build/tutorial-nascar-integrated/capabilities.json
./build/tutorial-nascar-integrated/muzixdiagsys_advanced_platform \
  nascar-integrated self-test \
  build/tutorial-nascar-integrated/evidence \
  build/tutorial-nascar-integrated/self-test.json
```

## Run all twelve canonical requests

```bash
set -euo pipefail
for item in \
  integrated-cosimulation:integrated_cosimulation \
  telemetry-assimilation:telemetry_assimilation \
  uncertainty-validity:uncertainty_validity \
  flexible-multibody:flexible_multibody \
  tire-construction-contact:tire_construction_contact \
  aeroelastic-wake:aeroelastic_wake \
  ecu-driveline-control:ecu_driveline_control \
  cranktrain-lubrication-fuel-thermal:cranktrain_lubrication_fuel_thermal \
  pit-road-twin:pit_road_twin \
  occupant-heat-egress:occupant_heat_egress \
  pavement-scanned-track:pavement_scanned_track \
  spray-optical-visibility:spray_optical_visibility
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/tutorial-nascar-integrated/muzixdiagsys_advanced_platform \
    nascar-integrated "$domain" \
    "examples/nascar_integrated_fidelity/${stem}.json" \
    "build/tutorial-nascar-integrated/${stem}.result.json" \
    build/tutorial-nascar-integrated/evidence
done
```

## Interpretation sequence

1. Confirm every subsystem rate is an exact multiple of the co-simulation base
   step; inspect scheduler counts, normalized energy residual, and coupling
   residual.
2. Review telemetry innovations, NIS gates, rejected measurements, posterior
   covariance, weighted residuals, and calibration conditioning.
3. Confirm `uncertainty-validity` uses justified distributions, correlations,
   and thresholds; do not use an output with `in_validity_domain=false` as an
   unconditional prediction.
4. Inspect 28-DOF multibody corner loads, suspension travel, flexible chassis
   modes, wheel-load loss, bottoming, and energy balance.
5. Review each tire's transient force, temperature, pressure, wear, structural
   margin, standing-wave state, and `belt_fatigue_damage` together.
6. Confirm wake transport, underfloor hysteresis, cooling reduction, flexible
   body modes, roof flap, and A-post flap remain bounded.
7. Audit every ECU limiter, sequential shift, over-rev rejection, torque cut,
   shaft torsion, differential torque split, and fuel result.
8. Correlate crank torsion, oil pressure/aeration, `bearing_film_ratio`, fuel
   pressure/starvation, fluid temperatures, and fatigue evidence.
9. Treat pit road as a shared event system: inspect queues, double stacking,
   speed, resource use, release margin, and traffic uncertainty.
10. Review crash injury screening separately from cockpit heat strain, CO dose,
    cognitive capacity, and egress margin.
11. Verify scan alignment, roughness, joints, wet friction, rutting, and pavement
    fatigue before using track inputs in vehicle studies.
12. Evaluate every observer's visibility, contamination, target contrast, and
    `brake_light_detection_probability` in spray scenarios.

## Regression and sanitizer workflow

```bash
ctest --test-dir build/tutorial-nascar-integrated --output-on-failure \
  -R '^nascar_integrated_fidelity_(platform_unit_tests|source_regression)$'
python3 tests/nascar_integrated_fidelity_source_regression.py .

cmake -S . -B build/tutorial-nascar-integrated-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-nascar-integrated-sanitize --parallel --target \
  nascar_integrated_fidelity_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --test-dir build/tutorial-nascar-integrated-sanitize --output-on-failure \
  -R '^nascar_integrated_fidelity_platform_unit_tests$'
```

The detailed request contracts, equations, output fields, and qualification
boundaries are documented in
`docs/NASCAR_INTEGRATED_FIDELITY_PLATFORM.md` and Chapter 58 of the user manual.

# NASCAR Engineering Assurance Workflow

This workflow exercises the additive twelve-domain `nascar-assurance` platform.
The original 40-domain `nascar` command and twelve-domain `nascar-integrated`
command remain available.

## Configure and build

```bash
cmake -S . -B build/tutorial-nascar-assurance -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-nascar-assurance --parallel --target \
  aesim_nascar \
  nascar_engineering_assurance_platform_tests \
  muzixdiagsys_advanced_platform
```

## Inspect capabilities and run self-test

```bash
./build/tutorial-nascar-assurance/muzixdiagsys_advanced_platform \
  nascar-assurance capabilities \
  build/tutorial-nascar-assurance/capabilities.json
./build/tutorial-nascar-assurance/muzixdiagsys_advanced_platform \
  nascar-assurance self-test \
  build/tutorial-nascar-assurance/evidence \
  build/tutorial-nascar-assurance/self-test.json
```

## Run all canonical requests

```bash
set -euo pipefail
for item in \
  regulation-digital-thread:regulation_digital_thread \
  dynamic-compliance:dynamic_compliance \
  prospective-oem-program:prospective_oem_program \
  timing-observation-fusion:timing_observation_fusion \
  officiating-policy-lab:officiating_policy_lab \
  contact-damage-raceability:contact_damage_raceability \
  crash-safer-fe:crash_safer_fe \
  fire-rescue-hazards:fire_rescue_hazards \
  debris-recovery:debris_recovery \
  composite-manufacturing:composite_manufacturing \
  fleet-reliability:fleet_reliability \
  test-design-calibration:test_design_calibration
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/tutorial-nascar-assurance/muzixdiagsys_advanced_platform \
    nascar-assurance "$domain" \
    "examples/nascar_engineering_assurance/${stem}.json" \
    "build/tutorial-nascar-assurance/${stem}.result.json" \
    build/tutorial-nascar-assurance/evidence
done
```

## Interpretation sequence

1. Resolve the exact event rule package and inspect every parameter's source.
2. Review compliance probability, first drift time, and recommended guard band.
3. Confirm OEM milestone dependencies, test limits, parity, cost, and supplier readiness.
4. Inspect timing residuals, confidence intervals, and alternative orders.
5. Compare policy safety, consistency, due process, and competitive impact separately.
6. Carry contact damage into aero, cooling, tire, alignment, DVP, and raceability results.
7. Audit crash time step, element failures, intrusion, HIC15, and energy residual.
8. Review fire heat release, smoke, CO, suppression, route risk, and rescue time together.
9. Inspect fragment trajectories, detection, puncture risk, cleanup route, and reopening confidence.
10. Verify cure, voids, stiffness, springback, bond strength, scan error, and process capability.
11. Replace parts based on conditional event risk and RUL, not age alone.
12. Confirm the selected test program covers required categories and reduces the intended uncertainties.

## Regression and sanitizer workflow

```bash
ctest --test-dir build/tutorial-nascar-assurance --output-on-failure \
  -R '^nascar_.*(platform_unit_tests|source_regression)$'
python3 tests/nascar_engineering_assurance_source_regression.py .

cmake -S . -B build/tutorial-nascar-assurance-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-nascar-assurance-sanitize --parallel --target \
  nascar_engineering_assurance_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ./build/tutorial-nascar-assurance-sanitize/nascar_engineering_assurance_platform_tests
```

See `docs/NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 59 of the user
manual for complete request contracts, algorithms, output interpretation, and
qualification boundaries.

# IndyCar Engineering Assurance Workflow

This workflow exercises the additive fourteen-domain `indycar-assurance` platform. Existing `indycar`, `indycar-operations`, `indycar-future`, `indycar-frontier`, `indycar-development`, and `indycar-integrated` workflows remain available.
The public C++ entry point is `indycar_engineering_assurance_platform.hpp`, exposed through the aggregate advanced-platform header.

## Configure and build

```bash
cmake -S . -B build/tutorial-indycar-assurance -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-indycar-assurance --parallel --target \
  aesim_indycar \
  indycar_engineering_assurance_platform_tests \
  muzixdiagsys_advanced_platform
```

## Inspect capabilities and execute self-test

```bash
./build/tutorial-indycar-assurance/muzixdiagsys_advanced_platform \
  indycar-assurance capabilities \
  build/tutorial-indycar-assurance/capabilities.json
./build/tutorial-indycar-assurance/muzixdiagsys_advanced_platform \
  indycar-assurance self-test \
  build/tutorial-indycar-assurance/evidence \
  build/tutorial-indycar-assurance/self-test.json
```

## Execute all fourteen canonical requests

```bash
set -euo pipefail
for item in \
  regulation-digital-thread:regulation_digital_thread \
  dynamic-compliance:dynamic_compliance \
  next-generation-certification:next_generation_certification \
  prospective-manufacturer-program:prospective_manufacturer_program \
  timing-observation-fusion:timing_observation_fusion \
  officiating-policy-lab:officiating_policy_lab \
  contact-damage-raceability:contact_damage_raceability \
  crash-safer-fe:crash_safer_fe \
  fire-rescue-hazards:fire_rescue_hazards \
  debris-recovery:debris_recovery \
  composite-manufacturing:composite_manufacturing \
  fleet-reliability:fleet_reliability \
  test-design-calibration:test_design_calibration \
  tire-material-digital-thread:tire_material_digital_thread
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/tutorial-indycar-assurance/muzixdiagsys_advanced_platform \
    indycar-assurance "$domain" \
    "examples/indycar_engineering_assurance/${stem}.json" \
    "build/tutorial-indycar-assurance/${stem}.result.json" \
    build/tutorial-indycar-assurance/evidence
done
```

## Interpretation sequence

1. Resolve the effective event rule package and inspect parameter provenance and invalidated studies.
2. Review time-dependent legality probability, first drift time, and measurement guard bands.
3. Inspect the 2028 verification matrix, provisional requirements, invalidated evidence, dependencies, and deployment readiness.
4. Review prospective manufacturer critical path, test allocation, parity, suppliers, cost, and launch readiness.
5. Inspect timing residuals, confidence intervals, source health, and alternative classifications.
6. Compare officiating safety, consistency, due process, proportionality, and competitive impact separately.
7. Carry progressive contact damage into alignment, tires, aero, cooling, thermal state, repairs, and raceability.
8. Audit crash time step, topology, element failures, intrusion, HIC15, barrier deflection, and energy residual.
9. Review fire release, heat, smoke, CO, visibility, suppression persistence, route risk, and extraction time together.
10. Inspect fragment trajectories, detection probability, puncture risk, cleanup route, and reopening confidence.
11. Verify composite cure, voids, laminate properties, spring-back, bonds, repairs, scan error, and capability.
12. Replace serialized parts using conditional next-event risk and remaining useful life rather than age alone.
13. Confirm the selected experiment program covers required categories and materially reduces target uncertainty.
14. Review tire-material genealogy, cure, crosslinking, strength, hysteresis, lot variability, sustainability, and circularity.

## Regression and sanitizer workflow

```bash
ctest --test-dir build/tutorial-indycar-assurance --output-on-failure \
  -R '^indycar_.*(platform_unit_tests|source_regression)$'
python3 tests/indycar_engineering_assurance_source_regression.py .

cmake -S . -B build/tutorial-indycar-assurance-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF -DAESIM_ENABLE_HIP=OFF
cmake --build build/tutorial-indycar-assurance-sanitize --parallel --target \
  indycar_engineering_assurance_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ./build/tutorial-indycar-assurance-sanitize/indycar_engineering_assurance_platform_tests
```

See `docs/INDYCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 60 of the user manual for complete request contracts, algorithms, evidence interpretation, and qualification boundaries.

# 22. Electronics engineering and assurance workflow

## Configure and build

```bash
cmake -S . -B build/tutorial-electronics -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON
cmake --build build/tutorial-electronics --parallel --target \
  aesim_advanced \
  electronics_power_distribution_platform_tests \
  electronics_circuit_conversion_platform_tests \
  embedded_electronics_assurance_platform_tests
```

## Run the focused qualification

```bash
ctest --test-dir build/tutorial-electronics --output-on-failure \
  -R '^(electronics_power_distribution|electronics_circuit_conversion|embedded_electronics_assurance)_platform_unit_tests$'
```

## Recommended engineering sequence

1. Build the low-voltage source, harness, load, and smart-fuse topology. Verify nominal voltage, loss, temperature, and brownout margin.
2. Add sleep/wake profiles and reproduce key-off quiescent current, wake dependencies, wake storms, and time to no-start state of charge.
3. Model PMIC rails, dependency order, current limits, UVLO, watchdog, and thermal shutdown.
4. Execute HV precharge, shutdown, isolation-fault, welded-contactor, and crash-isolation cases.
5. Configure analog front ends and converter errors from component and data-sheet values.
6. Import the ECAD connectivity baseline, verify its canonical digest, and construct PCB channel and PDN models.
7. Solve ground/bond paths at DC and representative switching frequencies.
8. Evaluate the selected Si, SiC, GaN, or IGBT device and gate driver at all inverter/charger operating corners.
9. Run double-pulse qualification and inspect overshoot, switching energy, avalanche, and SOA margin.
10. Evaluate onboard charger, isolated DC/DC, and wireless charging efficiency, harmonic, thermal, leakage, alignment, and field limits.
11. Qualify CAN, LIN, and Automotive Ethernet physical layers before applying protocol-level fault campaigns.
12. Program and activate A/B images, then test low-voltage interruption and anti-rollback behavior.
13. Execute AUTOSAR BSW/MCAL startup, communication, sleep, watchdog, and undervoltage cases.
14. Run RTL transactions and assertions, MBIST, LBIST, NVM endurance/retention, and mission-profile semiconductor aging.
15. Evaluate PCBA process yield and the AOI/AXI/ICT inspection plan.
16. Exercise secure provisioning transitions and physical side-channel/glitch campaigns.
17. Calibrate the EMC chamber instrumentation chain and run mitigation optimization against emission and immunity constraints.

## Example ECAD inputs

```bash
cat examples/electronics_engineering_assurance/reference_connectivity.csv
cat examples/electronics_engineering_assurance/reference_spice.cir
```

The complete class contracts, equations, report fields, and qualification boundaries are in `docs/ELECTRONICS_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 61 of the comprehensive user manual.

# 23. NHRA championship and strategy workflow

## 23.1 Build the platform and focused test

```bash
cmake -S . -B build/nhra -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON
cmake --build build/nhra --parallel --target \
  nhra_championship_strategy_platform_tests \
  muzixdiagsys_advanced_platform
ctest --test-dir build/nhra --output-on-failure \
  -R 'nhra_championship_strategy'
```

## 23.2 Inspect capabilities and run the self-test

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra capabilities \
  build/nhra/capabilities.json
./build/nhra/muzixdiagsys_advanced_platform nhra self-test \
  build/nhra/self-test-evidence build/nhra/self-test.json
```

## 23.3 Calculate Mission or Lucas Oil points

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra national_divisional_points \
  examples/nhra_championship_strategy/mission_points.json \
  build/nhra/mission-points.json build/nhra/evidence

./build/nhra/muzixdiagsys_advanced_platform nhra national_divisional_points \
  examples/nhra_championship_strategy/lucas_points.json \
  build/nhra/lucas-points.json build/nhra/evidence
```

The result identifies claimed, eligible, selected, and dropped events. Dropped events remain visible with a reason instead of disappearing from the record.

## 23.4 Forecast the Countdown

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra countdown_simulation \
  examples/nhra_championship_strategy/countdown.json \
  build/nhra/countdown.json build/nhra/evidence
```

Use the same seed to reproduce title probabilities exactly. Change `performance_strength`, `remaining_events`, or the Mission carry-in to evaluate a counterfactual championship path.

## 23.5 Resolve the Mission Challenge

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra mission_challenge \
  examples/nhra_championship_strategy/mission_challenge.json \
  build/nhra/mission-challenge.json build/nhra/evidence
```

The report preserves both rematches, final participants, winner, runner-up, quickest losing semifinalist, and 3/2/1 Countdown bonus points.

## 23.6 Optimize the tune-up

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra crew_chief_optimization \
  examples/nhra_championship_strategy/crew_chief.json \
  build/nhra/crew-chief.json build/nhra/evidence
```

The optimizer rejects candidates exceeding configured shake, failure, or lane-excursion limits. It returns one recommendation plus the ten strongest feasible alternatives.

## 23.7 Diagnose a run

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra causal_run_diagnosis \
  examples/nhra_championship_strategy/causal_diagnosis.json \
  build/nhra/diagnosis.json build/nhra/evidence
```

The result ranks causal mechanisms, allocates observed elapsed-time loss, and reports a counterfactual elapsed time with the primary mechanism removed.

## 23.8 Compare event strategies

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra monte_carlo_event_strategy \
  examples/nhra_championship_strategy/event_strategy.json \
  build/nhra/event-strategy.json build/nhra/evidence
```

The event model resolves each elimination round and reports win, final, semifinal, failure, points, and expected component-cost outcomes.

## 23.9 Validate a Heritage entry

```bash
./build/nhra/muzixdiagsys_advanced_platform nhra heritage_competition \
  examples/nhra_championship_strategy/heritage.json \
  build/nhra/heritage.json build/nhra/evidence
```

Use `{"operation":"profiles"}` to list profiles or `{"operation":"historical_event","year":1968}` to generate a period event context.


# 24. Frontier Systems: Exact Engineering Workflow

## 24.1 Discover native capabilities

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems capabilities \
  build/frontier-systems/capabilities.json
```

Read the capability JSON before selecting HDF5, NetCDF, OpenMP, Kokkos, MPI/CUDA RMA, or Enzyme. Native paths are reported only when present on the current machine.

## 24.2 Run the integrated qualification

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems self-test \
  build/frontier-systems/self-test-work \
  build/frontier-systems/self-test.json
```

A successful result reports `passed_domains: 12` and `passed: true`.

## 24.3 Run every canonical workflow

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems tsn \
  examples/frontier_systems/automotive_tsn.json build/frontier-systems/tsn.json
./build/full/muzixdiagsys_advanced_platform frontier-systems scientific-data \
  examples/frontier_systems/scientific_data.json build/frontier-systems/science.json build/frontier-systems/work
./build/full/muzixdiagsys_advanced_platform frontier-systems mesh \
  examples/frontier_systems/mesh_visualization.json build/frontier-systems/mesh.json build/frontier-systems/work
./build/full/muzixdiagsys_advanced_platform frontier-systems cae \
  examples/frontier_systems/cae_federation.json build/frontier-systems/cae.json build/frontier-systems/work
./build/full/muzixdiagsys_advanced_platform frontier-systems kernels \
  examples/frontier_systems/portable_kernel.json build/frontier-systems/kernel.json
./build/full/muzixdiagsys_advanced_platform frontier-systems pgas \
  examples/frontier_systems/pgas.json build/frontier-systems/pgas.json
./build/full/muzixdiagsys_advanced_platform frontier-systems robust-control \
  examples/frontier_systems/robust_control.json build/frontier-systems/robust-control.json
./build/full/muzixdiagsys_advanced_platform frontier-systems safety-mpc \
  examples/frontier_systems/safety_mpc.json build/frontier-systems/safety-mpc.json
./build/full/muzixdiagsys_advanced_platform frontier-systems compiler-ad \
  examples/frontier_systems/compiler_ad.json build/frontier-systems/compiler-ad.json build/frontier-systems/work
./build/full/muzixdiagsys_advanced_platform frontier-systems event-camera \
  examples/frontier_systems/event_camera.json build/frontier-systems/event-camera.json
./build/full/muzixdiagsys_advanced_platform frontier-systems raw-radar \
  examples/frontier_systems/raw_radar.json build/frontier-systems/raw-radar.json
./build/full/muzixdiagsys_advanced_platform frontier-systems physics-contract \
  examples/frontier_systems/physics_contract.json build/frontier-systems/physics-contract.json
```

### 24.4 Use the advanced modes

The canonical files are deliberately small. For engineering campaigns, the same domains expose additional executable controls:

- TSN: `synthesize_qbv`, finite queue limits, frame preemption, Qci policing, ATS/Qcr shaping, Qav idle slope, failed links, and `redundant_route`.
- Mesh: `operation=insitu-reduce` returns geometric and field statistics without writing the complete field state; native VTKHDF preserves explicit unstructured-grid topology and point/cell fields.
- Event camera: `operation=calibrate`, `flow`, or `ego-motion`; optional timestamp quantization and log-domain shot noise are available.
- Radar: target `multipath`, independent `interferers`, per-channel gain/phase/DC offsets, coupling matrices, and optional raw-I/Q or range-Doppler output are available.
- Physics contracts: add `differentiability`, `interpolation`, `extrapolation`, `numerical_abs_error`, `numerical_rel_error`, uncertainty limits, proper frame rotations, and `conservation-check` terms.

For field-level schemas, capability requirements, numerical assumptions, and engineering limitations, use `docs/FRONTIER_SYSTEMS_PLATFORM.md`.

# 25. Frontier Integration: Exact Engineering Workflow

## 25.1 Discover capabilities

```bash
./build/full/muzixdiagsys_advanced_platform frontier-integration capabilities \
  build/frontier-integration/capabilities.json
```

Check `lean_available`, `coq_available`, `isabelle_available`, and `verilator_available` before requesting native external proof/RTL qualification. SQLite and the internal numerical/physical implementations require no optional external executable.

## 25.2 Run all fourteen domains as one qualification

```bash
./build/full/muzixdiagsys_advanced_platform frontier-integration self-test \
  build/frontier-integration/self-test-work \
  build/frontier-integration/self-test.json
```

A complete success reports `domain_count: 14`, `passed: 14`, and `pass: true`.

## 25.3 Run every canonical request

```bash
./build/full/muzixdiagsys_advanced_platform frontier-integration dds-xrce-zenoh-edge-federation-platform \
  examples/frontier_integration/dds_xrce_zenoh.json build/frontier-integration/xrce.json
./build/full/muzixdiagsys_advanced_platform frontier-integration automotive-macsec-link-security-laboratory \
  examples/frontier_integration/macsec.json build/frontier-integration/macsec.json
./build/full/muzixdiagsys_advanced_platform frontier-integration automotive-emc-compliance-laboratory \
  examples/frontier_integration/emc.json build/frontier-integration/emc.json
./build/full/muzixdiagsys_advanced_platform frontier-integration wiring-harness-signal-power-integrity-platform \
  examples/frontier_integration/harness_si_pi.json build/frontier-integration/harness.json
./build/full/muzixdiagsys_advanced_platform frontier-integration continuous-frequency-hinf-mu-synthesis-laboratory \
  examples/frontier_integration/hinf_mu.json build/frontier-integration/hinf-mu.json
./build/full/muzixdiagsys_advanced_platform frontier-integration advanced-system-identification-laboratory \
  examples/frontier_integration/system_identification.json build/frontier-integration/system-id.json
./build/full/muzixdiagsys_advanced_platform frontier-integration formal-proof-assistant-bridge \
  examples/frontier_integration/proof_bridge.json build/frontier-integration/proof.json build/frontier-integration/proof-work
./build/full/muzixdiagsys_advanced_platform frontier-integration oslc-sacm-lifecycle-assurance-platform \
  examples/frontier_integration/oslc_sacm.json build/frontier-integration/oslc.json build/frontier-integration/lifecycle
./build/full/muzixdiagsys_advanced_platform frontier-integration rtl-verilator-hardware-cosimulation-platform \
  examples/frontier_integration/rtl_cosim.json build/frontier-integration/rtl.json build/frontier-integration/rtl-work
./build/full/muzixdiagsys_advanced_platform frontier-integration engineering-data-query-fabric \
  examples/frontier_integration/query_fabric.json build/frontier-integration/query.json build/frontier-integration/data
./build/full/muzixdiagsys_advanced_platform frontier-integration manufacturing-process-physics-platform \
  examples/frontier_integration/manufacturing_physics.json build/frontier-integration/manufacturing.json
./build/full/muzixdiagsys_advanced_platform frontier-integration cross-domain-error-propagation-engine \
  examples/frontier_integration/error_propagation.json build/frontier-integration/error.json
./build/full/muzixdiagsys_advanced_platform frontier-integration automatic-multifidelity-model-selection-platform \
  examples/frontier_integration/multifidelity.json build/frontier-integration/multifidelity.json
./build/full/muzixdiagsys_advanced_platform frontier-integration autonomous-experiment-campaign-manager \
  examples/frontier_integration/campaign.json build/frontier-integration/campaign.json
```

For exact request fields, numerical contracts and native-tool boundaries, use `docs/FRONTIER_INTEGRATION_PLATFORM.md`.

# 26. Frontier Next: Exact Engineering Workflow

## 26.1 Build and discover

Use the normal full build. The Frontier Next production source is part of `aesim_advanced` and the permanent advanced-platform CLI.

```bash
cmake --build build/full --target \
  frontier_next_platform_tests \
  muzixdiagsys_advanced_platform --parallel "$(nproc)"

./build/full/muzixdiagsys_advanced_platform frontier-next capabilities \
  build/frontier-next/capabilities.json
```

Inspect the capability booleans before selecting PETSc, SUNDIALS, HYPRE, ADIOS2, CGNS, Exodus, MPI/CUDA, or NCCL native execution. If a native package is absent, select the self-contained reference mode where the domain provides one; do not interpret an unavailable native backend as a completed native qualification.

## 26.2 Run all sixteen domains

```bash
./build/full/muzixdiagsys_advanced_platform frontier-next self-test \
  build/frontier-next/self-test-work \
  build/frontier-next/self-test.json
```

Expected aggregate fields are `domain_count: 16`, `passed: 16`, and `pass: true`.

## 26.3 Use the dedicated aliases

Every domain has a shorter first-class alias. The generic pattern is:

```bash
./build/full/muzixdiagsys_advanced_platform ALIAS capabilities
./build/full/muzixdiagsys_advanced_platform ALIAS self-test WORK_DIRECTORY [OUTPUT.json]
./build/full/muzixdiagsys_advanced_platform ALIAS run REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
./build/full/muzixdiagsys_advanced_platform ALIAS OPERATION REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Examples:

```bash
./build/full/muzixdiagsys_advanced_platform wireless-phy run \
  examples/frontier_next/wireless_phy.json \
  build/frontier-next/wireless.json

./build/full/muzixdiagsys_advanced_platform secure-ranging run \
  examples/frontier_next/secure_ranging.json \
  build/frontier-next/ranging.json

./build/full/muzixdiagsys_advanced_platform complex-mu run \
  examples/frontier_next/complex_mu.json \
  build/frontier-next/complex-mu.json

./build/full/muzixdiagsys_advanced_platform stochastic-id run \
  examples/frontier_next/stochastic_id.json \
  build/frontier-next/stochastic-id.json

./build/full/muzixdiagsys_advanced_platform protocol-verify run \
  examples/frontier_next/protocol_verify.json \
  build/frontier-next/protocol.json

./build/full/muzixdiagsys_advanced_platform static-verify run \
  examples/frontier_next/static_verify.json \
  build/frontier-next/static.json \
  build/frontier-next/static-work

./build/full/muzixdiagsys_advanced_platform native-solvers linear-solve \
  examples/frontier_next/native_solvers.json \
  build/frontier-next/solver.json

./build/full/muzixdiagsys_advanced_platform gpu-comm run \
  examples/frontier_next/gpu_comm.json \
  build/frontier-next/gpu-comm.json

./build/full/muzixdiagsys_advanced_platform adios2-stream run \
  examples/frontier_next/adios2_stream.json \
  build/frontier-next/adios2.json \
  build/frontier-next/adios2-work

./build/full/muzixdiagsys_advanced_platform mesh-interchange run \
  examples/frontier_next/mesh_interchange.json \
  build/frontier-next/mesh.json \
  build/frontier-next/mesh-work

./build/full/muzixdiagsys_advanced_platform ibis-ami run \
  examples/frontier_next/ibis_ami.json \
  build/frontier-next/ibis-ami.json

./build/full/muzixdiagsys_advanced_platform heat-pump run \
  examples/frontier_next/heat_pump.json \
  build/frontier-next/heat-pump.json

./build/full/muzixdiagsys_advanced_platform nde-metrology run \
  examples/frontier_next/nde_metrology.json \
  build/frontier-next/nde.json

./build/full/muzixdiagsys_advanced_platform model-maturity run \
  examples/frontier_next/model_maturity.json \
  build/frontier-next/maturity.json \
  build/frontier-next/maturity-store

./build/full/muzixdiagsys_advanced_platform scenario-coverage run \
  examples/frontier_next/scenario_coverage.json \
  build/frontier-next/coverage.json

./build/full/muzixdiagsys_advanced_platform model-form-uq run \
  examples/frontier_next/model_form_uq.json \
  build/frontier-next/model-form-uq.json
```

## 26.4 Native scientific solver workflow

Start with:

```bash
./build/full/muzixdiagsys_advanced_platform native-solvers capabilities \
  build/frontier-next/native-solvers-capabilities.json
```

`backend=reference` is always available. `backend=petsc` uses native PETSc AIJ/KSP/CG. `backend=hypre` uses native HYPRE IJ/ParCSR/PCG and MPI. For ODE requests, `backend=sundials` uses native CVODE/BDF with a dense SUNMatrix/SUNLinearSolver. A request for a backend not detected at configure time fails rather than silently substituting the reference solver.

## 26.5 Native data and mesh workflow

For ADIOS2:

```bash
./build/full/muzixdiagsys_advanced_platform adios2-stream capabilities
```

The always-available `memory-ring` backend reports retained/dropped steps and checksums. If native ADIOS2 is available, `backend=adios2` writes actual steps and `operation=roundtrip` reopens and verifies step count, shape, and checksum.

For meshes:

```bash
./build/full/muzixdiagsys_advanced_platform mesh-interchange capabilities
```

XDMF is always available. Native CGNS and Exodus require their detected libraries and perform real coordinate/connectivity/field writes followed by structural readback qualification.

## 26.6 IBIS/AMI channel workflow

The canonical `ibis_ami.json` combines Touchstone channel data, an IBIS driver subset, and AMI declarations. The platform extracts driver voltage, local pull-up/pull-down resistance, ramp slew, AMI equalization parameters, cascaded S-parameters, eye height/width and an engineering BER estimate.

Use actual vendor IBIS/AMI/Touchstone artifacts when validating a real link. The built-in parser intentionally rejects malformed Touchstone data and only applies the documented IBIS/AMI fields it recognizes.

## 26.7 Focused qualification

```bash
ctest --test-dir build/full --output-on-failure \
  -R '^frontier_next_(platform_unit_tests|source_regression|cli_regression)$'
```

Then execute the complete repository qualification with `aesim_check` or the full CTest workflow described in the build chapter.

For field-level request contracts, algorithms, optional-native boundaries, and all aliases, see `docs/FRONTIER_NEXT_PLATFORM.md`.

# 27. Formula One, NASCAR, and IndyCar convenience CLI workflow

The convenience commands route to the same production domain implementations as the original motorsport command families.

## 27.1 Discover complete motorsport surfaces

```bash
./build/full/muzixdiagsys_advanced_platform f1 capabilities build/f1-capabilities.json
./build/full/muzixdiagsys_advanced_platform nascar all-capabilities build/nascar-all-capabilities.json
./build/full/muzixdiagsys_advanced_platform indycar capabilities build/indycar-capabilities.json
```

Expected aggregate domain counts are 30 for Formula One, 64 for NASCAR, and 34 for IndyCar.

## 27.2 Route through a family explicitly

```bash
./build/full/muzixdiagsys_advanced_platform f1 run industrial causal-setup-intelligence \
  examples/formula_one_industrial_ecosystem/causal_setup_intelligence.json \
  build/f1-setup-routed.json build/f1-setup-routed-evidence

./build/full/muzixdiagsys_advanced_platform nascar run integrated telemetry-assimilation \
  examples/nascar_integrated_fidelity/telemetry_assimilation.json \
  build/nascar-telemetry-routed.json build/nascar-telemetry-routed-evidence

./build/full/muzixdiagsys_advanced_platform indycar run assurance timing-observation-fusion \
  examples/indycar_engineering_assurance/timing_observation_fusion.json \
  build/indycar-timing-routed.json build/indycar-timing-routed-evidence
```

## 27.3 Use direct shortcuts

```bash
./build/full/muzixdiagsys_advanced_platform f1-ers \
  examples/formula_one_regulatory_competition/ers_electrical_hardware.json build/f1-ers.json

./build/full/muzixdiagsys_advanced_platform nascar-pack \
  examples/nascar_competition/superspeedway_pack.json build/nascar-pack.json

./build/full/muzixdiagsys_advanced_platform indycar-hybrid \
  examples/indycar_integrated_fidelity/ecu_hybrid_control.json build/indycar-hybrid.json
```

Use `ALIAS capabilities [output.json]` to inspect the exact family/domain mapping before execution. See `docs/MOTORSPORT_CLI_COMMANDS.md` for all 24 shortcuts.

## 27.4 Run aggregate qualification

```bash
./build/full/muzixdiagsys_advanced_platform f1 self-test build/f1-suite build/f1-suite.json
./build/full/muzixdiagsys_advanced_platform nascar all-self-test build/nascar-suite build/nascar-suite.json
./build/full/muzixdiagsys_advanced_platform indycar self-test build/indycar-suite build/indycar-suite.json
```

The aggregate self-tests retain separate evidence directories for each underlying family.

# 28. Advanced API CLI engineering workflow

The additive advanced API registry exposes mature C++ engineering APIs without requiring a custom C++ harness. Existing command families remain available and unchanged.

## 28.1 Discover commands

```bash
./build/full/muzixdiagsys_advanced_platform commands
./build/full/muzixdiagsys_advanced_platform commands --category electronics
./build/full/muzixdiagsys_advanced_platform describe battery-abuse
./build/full/muzixdiagsys_advanced_platform credibility schema
./build/full/muzixdiagsys_advanced_platform credibility example build/credibility-example.json
```

The registry contains 214 commands. Category filtering is useful when working over SSH or from CI because it avoids parsing the much larger legacy help surface.

## 28.2 Validate before expensive execution

```bash
./build/full/muzixdiagsys_advanced_platform credibility run \
  examples/advanced_api_cli/nominal_request.json \
  build/credibility-validation.json \
  --validate-only --strict --explain
```

`--validate-only` and `--dry-run` parse and validate the request without executing the underlying engineering model. This is useful for CI schema gates and generated studies.

## 28.3 Execute with evidence and profiling

```bash
./build/full/muzixdiagsys_advanced_platform credibility run \
  examples/advanced_api_cli/nominal_request.json \
  build/credibility.json \
  build/credibility-work \
  --profile \
  --trace build/credibility-trace.json \
  --metrics build/credibility-metrics.json \
  --evidence-dir build/credibility-evidence \
  --backend cpu --precision double --threads 4 --deterministic --strict --explain
```

The execution metadata records requested backend, precision, thread policy, seed, deterministic/strict state, and measured wall time. The selected production API remains responsible for the engineering calculation and its pass/fail criteria.

## 28.4 Measurement and debugging examples

```bash
./build/full/muzixdiagsys_advanced_platform mdf self-test build/mdf build/mdf.json
./build/full/muzixdiagsys_advanced_platform a2l self-test build/a2l build/a2l.json
./build/full/muzixdiagsys_advanced_platform xcp self-test build/xcp build/xcp.json
./build/full/muzixdiagsys_advanced_platform clock-align self-test build/clock-align build/clock-align.json
./build/full/muzixdiagsys_advanced_platform time-travel self-test build/time-travel build/time-travel.json
./build/full/muzixdiagsys_advanced_platform regression-impact self-test build/regression-impact build/regression-impact.json
```

## 28.5 Physics, scientific, and numerical credibility examples

```bash
./build/full/muzixdiagsys_advanced_platform physics self-test build/physics build/physics.json
./build/full/muzixdiagsys_advanced_platform multiphysics-solve self-test build/multiphysics build/multiphysics.json
./build/full/muzixdiagsys_advanced_platform inverse-pde self-test build/inverse-pde build/inverse-pde.json
./build/full/muzixdiagsys_advanced_platform solver self-test build/solver build/solver.json
./build/full/muzixdiagsys_advanced_platform solver-diff self-test build/solver-diff build/solver-diff.json
./build/full/muzixdiagsys_advanced_platform benchmark self-test build/benchmark build/benchmark.json
./build/full/muzixdiagsys_advanced_platform credibility self-test build/credibility build/credibility.json
```

## 28.6 Electronics and vehicle-system examples

```bash
./build/full/muzixdiagsys_advanced_platform battery-abuse self-test build/battery-abuse build/battery-abuse.json
./build/full/muzixdiagsys_advanced_platform pcb-si self-test build/pcb-si build/pcb-si.json
./build/full/muzixdiagsys_advanced_platform double-pulse self-test build/double-pulse build/double-pulse.json
./build/full/muzixdiagsys_advanced_platform hv-precharge self-test build/hv-precharge build/hv-precharge.json
./build/full/muzixdiagsys_advanced_platform vecu self-test build/vecu build/vecu.json
./build/full/muzixdiagsys_advanced_platform sensor-render self-test build/sensor-render build/sensor-render.json
```

## 28.7 Alternative output formats

```bash
./build/full/muzixdiagsys_advanced_platform credibility --capabilities --output-format yaml
./build/full/muzixdiagsys_advanced_platform credibility --capabilities --output-format csv
./build/full/muzixdiagsys_advanced_platform credibility --capabilities --output-format jsonl
```

For automated consumers, JSON remains the richest format. CSV flattens only the top-level document and serializes nested values as compact JSON.

## 28.8 Regression gate

```bash
python3 tests/advanced_api_cli_commands_regression.py \
  build/full/muzixdiagsys_advanced_platform .
```

The regression hard-codes the complete registry, validates discovery, executes all 214 command self-tests, exercises the global option layer, and rejects unfinished implementation markers from the new CLI sources.

See `docs/ADVANCED_API_CLI_COMMANDS.md` for the complete categorized command inventory.

## 28.9 Lifecycle, transport, XIL, formal verification, and safety APIs

The 2026-08-08 lifecycle/system expansion adds 21 production API families. They use the same `capabilities`, `schema`, `example`, request-file, output-file, self-test, qualification, and interactive-completion conventions as the 194-command lifecycle/system revision; the current append-only registry contains 214 commands.

Use lifecycle governance before archiving long-lived studies:

```bash
./build/full/muzixdiagsys_advanced_platform api-version show \
  examples/advanced_api_cli/api-version-show.json build/api-version.json
./build/full/muzixdiagsys_advanced_platform api-migrate request \
  examples/advanced_api_cli/api-migrate-request.json build/migrated-request.json
./build/full/muzixdiagsys_advanced_platform api-baseline capture \
  examples/advanced_api_cli/api-baseline-capture.json build/baseline-capture.json
./build/full/muzixdiagsys_advanced_platform api-replay verify \
  examples/advanced_api_cli/api-replay-verify.json build/replay-verification.json
```

Use observability and artifact services around expensive simulations:

```bash
./build/full/muzixdiagsys_advanced_platform artifact-store put artifact-put.json artifact-result.json
./build/full/muzixdiagsys_advanced_platform api-metrics measure metrics-request.json metrics-result.json
./build/full/muzixdiagsys_advanced_platform api-trace trace trace-request.json trace-result.json
```

The gRPC backend is a real HTTP/2 + Protobuf/gRPC transport implemented with libnghttp2. A complete build therefore requires the libnghttp2 development headers/library in addition to the existing OpenSSL dependency. The built-in transport self-tests create ephemeral loopback listeners and perform actual protocol round trips:

```bash
./build/full/muzixdiagsys_advanced_platform grpc-server self-test build/grpc build/grpc.json
./build/full/muzixdiagsys_advanced_platform telemetry-stream self-test build/websocket build/websocket.json
```

Promoted engineering services reuse the simulator's production XIL, reachability, WCET/scheduling, EKF-SLAM, automotive-network, diagnostic, road-surface, SOTIF, and RSS implementations:

```bash
./build/full/muzixdiagsys_advanced_platform xil-orchestrator self-test build/xil build/xil.json
./build/full/muzixdiagsys_advanced_platform formal-reachability self-test build/reachability build/reachability.json
./build/full/muzixdiagsys_advanced_platform wcet self-test build/wcet build/wcet.json
./build/full/muzixdiagsys_advanced_platform schedulability self-test build/sched build/sched.json
./build/full/muzixdiagsys_advanced_platform slam self-test build/slam build/slam.json
./build/full/muzixdiagsys_advanced_platform network-digital-twin self-test build/network build/network.json
./build/full/muzixdiagsys_advanced_platform diagnostic-stack self-test build/diagnostics build/diagnostics.json
./build/full/muzixdiagsys_advanced_platform road-surface self-test build/road build/road.json
./build/full/muzixdiagsys_advanced_platform sotif self-test build/sotif build/sotif.json
./build/full/muzixdiagsys_advanced_platform rss-safety self-test build/rss build/rss.json
```

All of the same command names are direct roots in the authenticated `muzixdiagsys` interactive shell. The `advanced <command> ...` form is also available and remains collision-safe.

The complete operation/request/protocol reference is [`API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md`](API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md).


## 28.10 Control, physics, co-simulation, and qualification API expansion

The current registry contains **214 commands**. The newest 20 are direct interactive-shell roots and also accept the explicit `advanced` namespace. A useful smoke test is:

```bash
./build/full/muzixdiagsys_advanced_platform control-synthesis self-test build/control build/control.json
./build/full/muzixdiagsys_advanced_platform safety-shield self-test build/shield build/shield.json
./build/full/muzixdiagsys_advanced_platform aftertreatment self-test build/aftertreatment build/aftertreatment.json
./build/full/muzixdiagsys_advanced_platform fmi-cosim self-test build/fmi build/fmi.json
./build/full/muzixdiagsys_advanced_platform digital-key self-test build/digital-key build/digital-key.json
./build/full/muzixdiagsys_advanced_platform probabilistic-model-check self-test build/pmc build/pmc.json
```

From inside `muzixdiagsys`, omit the executable prefix, for example `control-synthesis capabilities` or `advanced control-synthesis capabilities`. See [`CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md`](CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md) for all operations and request semantics.

## 28.11 Frontier Professional Integration laboratory workflow

The 2026-08-10 Frontier Professional Integration is a focused additive executable rather than another entry in the 214-command advanced registry. Build and qualify it with:

```bash
cmake --build build/full --parallel --target \
  muzixdiagsys_frontier_professional frontier_professional_integration_tests
./build/full/frontier_professional_integration_tests
./build/full/muzixdiagsys_frontier_professional capabilities
./build/full/muzixdiagsys_frontier_professional self-test build/frontier-professional-selftest
```

Useful laboratory commands are:

```bash
./build/full/muzixdiagsys_frontier_professional opcua-aas build/vehicle.aasx
./build/full/muzixdiagsys_frontier_professional dil-openxr
./build/full/muzixdiagsys_frontier_professional hardware-probe
./build/full/muzixdiagsys_frontier_professional ns3-reference
./build/full/muzixdiagsys_frontier_professional prometheus
./build/full/muzixdiagsys_frontier_professional bayes
./build/full/muzixdiagsys_frontier_professional mlmc
./build/full/muzixdiagsys_frontier_professional acoustics
./build/full/muzixdiagsys_frontier_professional federated
```

Install `./python[research]` and set `MUZIXDIAGSYS_FRONTIER_PROFESSIONAL` to the built executable before opening `notebooks/` in JupyterLab. See `FRONTIER_PROFESSIONAL_INTEGRATION.md` and User Manual Chapter 73 for native dependency, hardware safety, privacy-accounting, Sigstore, ns-3, and conformance boundaries.

## 28.12 Run every standalone backend from the interactive shell

The interactive shell now exposes every non-test backend/tool executable through the same production dispatcher used by the standalone binary. Start the shell with your normal authentication method, then inspect the mapping:

```text
backend list
```

Representative standalone commands:

```bash
./build/full/muzixdiagsys_causal_lab status
./build/full/muzixdiagsys_advanced_safety capabilities
./build/full/muzixdiagsys_frontier_professional capabilities
./build/full/research_reference_generator build/reference.csv build/reference.json
```

Equivalent interactive commands:

```text
causal-lab status
advanced-safety-cli capabilities
frontier-professional capabilities
research-reference-generator build/reference.csv build/reference.json
```

The explicit namespace is useful in scripts/tutorials because it clearly identifies backend dispatch:

```text
backend causal-lab status
backend advanced-safety-cli capabilities
backend frontier-professional capabilities
backend research-reference-generator build/reference.csv build/reference.json
```

For the advanced-platform backend, use either:

```text
advanced-platform commands --compact
backend advanced-platform commands --compact
```

For engineering operations, authenticate only once when starting `muzixdiagsys`; the shell passes its authenticated identity/database to the shared engineering runner:

```text
engineering-cli roles catalog
backend engineering-cli audit verify
engineering-cli workspace list ./workspaces
```

This is not an authorization bypass. The same engineering permission checks and audit-log operations used by `muzixdiagsys_engineering` still execute.

`study-worker [address] [port]` is a long-running server command and therefore occupies the current shell until interrupted. Use a separate terminal/process for a worker that should remain available while you continue interactive simulation work.

Finish a parity-oriented smoke session with:

```text
command-schema validate
```

A release build should report `PASS`. The automated parity and all-command completion regressions provide the exhaustive checks; see `BACKEND_EXECUTABLE_CLI_PARITY.md` for the complete nine-executable mapping.

## 29. V16 graphical engineering desktop workflow

Start the authenticated browser desktop:

```text
ui web start 0 127.0.0.1
ui web status
```

Use the browser workbench library to open **Interactive Telemetry Plotting**, **Engineering Data Grid**, **3D Engineering Digital Twin**, **Calibration & Correlation Workbench**, **E/E Topology Canvas**, **Scenario Timeline**, **Visual Workflow Editor**, **Workflow Debugger**, **Track & Lap Analysis**, and **Graphical Semantic CLI & Problems**. Drag workbench tabs between dock groups, split groups from their tool controls/drop zones, and drag splitters to persist ratios.

Useful exact structured commands for reproducing GUI state at the terminal are:

```text
ui desktop workspace-json
ui digital-twin-3d json
ui scope storage
ui calibration-correlation json
ui topology json
ui scenario-timeline json
ui workflow-editor json <graph-id>
ui workflow-debugger json
ui run-compare track-json 2400
ui semantic json ui scope stats rpm
```

The GUI and these commands operate on the same authoritative backend objects; use the CLI forms when scripting or reproducing a graphical investigation.

## V19 help-first operating workflow

Before memorizing a large command tree, use the simulator's canonical discovery chain:

```text
help search battery
help battery
help ui scope
help errors CLI222
ui semantic throttle 40%
ui preview throttle 40
throttle 40
```

`help <path>` explains purpose, detailed behavior, syntax, aliases, state impact, next subcommands/values, examples, and recovery commands. `help search` is preferable to guessing names. If an operand fails, `ui semantic` explains the cause and recovery before execution; if execution itself fails, use the printed diagnostic code with `help errors <CODE>` and inspect the indicated subsystem status/doctor/access command.

F1/`ui help` remains the terminal shortcut/navigation overlay. It complements rather than replaces detailed command help. F2 remains the universal search across commands and non-command workspace actions.


## 30. V20.1.2 Unified Engineering Workspace workflow

Use this workflow when you want one coordinated engineering session instead of moving between isolated command families.

### 30.1 Open the workspace and discover commands

```text
ui desktop select unified-engineering
ui palette wheel slip
ui palette solver
ui equivalence search time
```

The workspace is a projection over the existing desktop. The palette searches both canonical actions and structured engineering objects. `ui equivalence` shows which canonical command a graphical action invokes.

### 30.2 Build and persist a telemetry dashboard

```text
ui dashboard-designer create braking "Braking Analysis" 12
ui dashboard-designer add braking speed 0 0 4 2 vehicle.speed "Vehicle Speed"
ui dashboard-designer add braking wheel 0 4 4 2 wheel.fl.speed "FL Wheel Speed"
ui dashboard-designer show braking
ui dashboard-designer save ./braking-dashboard.mzux
```

Later restore the exact collection with:

```text
ui dashboard-designer load ./braking-dashboard.mzux
```

### 30.3 Find and inspect signals

```text
ui signal-explorer search speed
ui signal-explorer inspect vehicle.speed
ui signal-explorer history vehicle.speed 10 20
```

If a custom signal needs engineering metadata:

```text
ui signal-explorer set-meta custom.slip label="Slip Ratio" unit=1 subsystem=tire source=derived tags=traction,validation min=-1 max=1 rate=200
```

This metadata augments the existing telemetry history; it does not create another signal stream.

### 30.4 Use the timeline safely

A bookmark moves/labels the analytical cursor only:

```text
ui time bookmark before-braking
ui time timeline
ui time goto-bookmark before-braking
```

A checkpoint captures real restorable simulator state:

```text
ui time checkpoint pre-fault
# run/inject/change the simulation
ui time restore pre-fault
```

Because restore changes simulator state, use checkpoints for reproducible branching and bookmarks for observation/navigation.

### 30.5 Manage experimental runs

```text
ui run-manager add run-A complete scenario=baseline vehicle=prototype seed=1001 param.pressure=220 obj.stop_m=35.7 tag.series=brake-study
ui run-manager annotate run-A "Baseline accepted"
ui run-manager artifact run-A reports/run-A.csv
ui run-manager inspect run-A
ui run-manager save ./brake-study-runs.mzux
```

The same runs remain available to Design-Space Explorer and N-way comparison because Run Manager extends `ExperimentMatrix` rather than storing a duplicate database.

### 30.6 Compare runs and inspect divergence evidence

First make the relevant runs available to the established run-comparison workbench. Then:

```text
ui causal-difference divergences run-B 1e-6 1e-4
ui causal-difference explain run-B vehicle.speed 1e-6 1e-4
ui causal-difference graph
```

Treat the result as dependency-constrained divergence evidence. It does not, by itself, prove physical causation.

### 30.7 Investigate failures from one center

```text
ui diagnostic-center status
ui diagnostic-center explain solver:latest
ui diagnostic-center explain alert:17
ui diagnostic-center explain regression:vehicle_dynamics_regression
```

The center correlates existing alert, regression, solver, and flight-recorder evidence. Acknowledging an alert still acts on Mission Control:

```text
ui diagnostic-center ack 17
```

### 30.8 Configure the SSH/TUI layout

```text
ui pane create analysis horizontal
ui pane add telemetry dashboard 2
ui pane add watches watch 1
ui pane add evidence diagnostics 1
ui pane focus telemetry
ui pane resize watches 1.5
ui pane save ./analysis-layout.mzux
```

Restore it later with `ui pane load ./analysis-layout.mzux`. Horizontal dashboard/watch composition automatically falls back to the existing terminal behavior when the viewport is too narrow.


# Research-Grade Engineering UI: Exact Command Quickstart

The following commands are implemented in the authenticated interactive shell and are the same commands invoked by the browser workbenches:

```text
ui formal-verification status
ui field-visualization status
ui jacobian-inspector status
ui distributed-trace status
ui hpc-placement status
ui safety-analysis status
ui temporal-bisection status
ui contract-monitor status
ui state-machine status
ui numerical-trust status
ui run-lineage status
ui realtime-deadline status
ui cosim-sync status
ui coverage-explorer status
ui cyber-attack status
ui engineering-notebook status
ui report-composer status
ui crdt-collaboration status
ui plugin-manager status
ui migration-center status
ui dependency-heatmap status
ui performance-investigator status
ui failure-clustering status
ui twin-measurement status
ui alert-rules status
ui product-line status
ui control-room status
```

`ui divergence-investigator` requires a candidate run ID: `ui divergence-investigator status <candidate-run> [target-signal]`.

For backend-owned operations use the same pre-existing top-level commands shown by the workbench: `specification-discovery ...`, `advanced-safety-cli ...`, `frontier-professional hardware-probe`, `frontier-professional jupyter ...`, `plugin ...`, and `config ...`. See User Manual Chapter 83 for complete examples and data semantics.

# Integrated Terminal Engineering Cockpit: Exact Command Quickstart

Start with the existing unified workspace and inspect the analytical lower-pane views:

```text
ui desktop select unified-engineering
ui lowerpane tabs
ui lowerpane view timeline
ui lowerpane view activity
```

Inspect telemetry and synchronized history:

```text
ui sparkline rpm 48
ui event-timeline 25 120
ui time-travel status
ui time-travel bookmark before-change
ui time-travel checkpoint baseline
```

Inspect the active model without leaving the InteractiveShell:

```text
ui navigator tree
ui navigator find powertrain
ui parameter-inspector list
ui doc-inspect set
ui doc-inspect rpm
```

Operate the existing experiment/job/alert stores through their cockpit projections:

```text
ui experiment-cockpit
ui jobs submit analysis "ui performance-profiler dashboard"
ui jobs list
ui notifications unread
```

For run-based causal/spatial analysis, load comparison telemetry that contains both the signal under investigation and track-coordinate channels:

```text
ui run-compare load-csv baseline ./baseline.csv time_s
ui run-compare load-csv candidate ./candidate.csv time_s
ui run-compare baseline baseline
ui causal-inspector divergences candidate 1e-9 1e-6
ui causal-inspector explain candidate speed_kmh 1e-9 1e-6
ui track-map 76 22 2400
```

Motorsport and dynamics views remain generic projections over whichever metrics the active backend exposes:

```text
ui pit-wall f1
ui friction-circle 45 17
ui uncertainty-view 100 24
ui performance-profiler dashboard
```

Use `ui undo` / `ui redo` for Experience/UI state history. Use `ui time-travel checkpoint|restore` for restorable simulator state. They intentionally remain separate mechanisms.


# 31. Engineering Intelligence Platform workflow

Use this workflow when a study must connect vehicle changes, E/E allocation, software timing, clock synchronization, physical conservation, calibration observability, signal provenance, causal diagnosis, quantitative requirements, and reproducible evidence. The twenty domains are implemented behind one `engineering-intelligence` facade; they are not twenty unrelated mock commands.

## 31.1 Discover and qualify the platform

```bash
./build/full/muzixdiagsys_advanced_platform engineering-intelligence capabilities \
  build/engineering-intelligence-capabilities.json

mkdir -p build/engineering-intelligence-self-test
./build/full/muzixdiagsys_advanced_platform engineering-intelligence self-test \
  build/engineering-intelligence-self-test \
  build/engineering-intelligence-self-test.json
```

The self-test is successful only when all twenty domains execute. The capabilities document also records the shared-graph and canonical-solver reuse invariants, including the expansion's reuse of canonical harness reliability, raw-sensor metrology, lubricant chemistry, J3400/ISO 15118, Bayesian experimental-design, and scenario-coverage/novelty services.

## 31.2 Analyze a proposed whole-vehicle change

Create `consequence.json`:

```json
{
  "nodes":[
    {"id":"battery_mass","domain":"energy","quantity":"mass","unit":"kg","baseline_value":480},
    {"id":"vehicle_mass","domain":"vehicle","quantity":"mass","unit":"kg","baseline_value":1700},
    {"id":"braking_energy","domain":"brakes","quantity":"energy","unit":"J","baseline_value":600000}
  ],
  "edges":[
    {"id":"b2v","from":"battery_mass","to":"vehicle_mass","kind":"physical","local_gain":1.0,"confidence":1.0},
    {"id":"v2e","from":"vehicle_mass","to":"braking_energy","kind":"physical","local_gain":350.0,"confidence":0.95}
  ],
  "changes":[{"node_id":"battery_mass","delta":12.0}]
}
```

Run:

```bash
./build/full/muzixdiagsys_advanced_platform engineering-intelligence \
  whole-vehicle-consequence-engine consequence.json consequence-result.json
```

Inspect `impacts`, `domain_absolute_effect`, causal paths, confidence, delay, diagnostics, and `evidence_sha256`. Use relative changes only when the graph's local gains have been defined consistently for that interpretation.

## 31.3 Reverse an anomaly with the causality microscope

Use the same nodes and edges, replace `changes` with:

```json
{
  "observed_node":"braking_energy",
  "observed_delta":4200.0,
  "maximum_depth":12,
  "maximum_candidates":10
}
```

Then run:

```bash
./build/full/muzixdiagsys_advanced_platform engineering-intelligence \
  simulation-causality-microscope causality.json causality-result.json
```

The important distinction is direction: the consequence engine propagates a declared change downstream; the microscope starts with an observed deviation and ranks upstream candidates. Both use the same dependency graph.

## 31.4 Qualify E/E, services, clocks, and requirements

Use these routes in sequence for a software-defined vehicle architecture:

```text
engineering-intelligence zonal-ee-architecture-synthesizer ee.json ee-result.json
engineering-intelligence vehicle-software-service-graph-simulator services.json services-result.json
engineering-intelligence end-to-end-timebase-laboratory clocks.json clocks-result.json
engineering-intelligence cross-layer-requirement-propagation requirements.json requirements-result.json
```

The E/E request should encode failure domains and power feeds for replicated safety functions. The service request should encode payload sizes because serialization delay participates in path selection. The timebase request should use realistic velocity when timestamp error must be interpreted as spatial sensor-registration error. The requirement graph must use compatible metrics/units and must remain acyclic.

## 31.5 Check physical credibility and calibration observability

Before trusting a calibration result, run:

```text
engineering-intelligence cross-domain-conservation-auditor conservation.json conservation-result.json
engineering-intelligence parameter-identifiability-sloppiness-laboratory identifiability.json identifiability-result.json
engineering-intelligence signal-lineage-calibration-provenance lineage.json lineage-result.json
```

A conservation failure should be resolved before interpreting downstream optimization results. Rank deficiency or extreme sloppiness means the requested parameters are not supported by the available measurement sensitivity. Lineage tracing provides the calibration/version/source chain for the controller-visible signal being fitted.

## 31.6 Seal the accepted run in a reproducibility capsule

After the study is accepted, create a capsule request containing the source revision, model version, exact command line, deterministic seed, configuration, required input artifacts, and only the environment variables that materially affect execution. Then run:

```text
engineering-intelligence computational-reproducibility-capsules capsule-create.json capsule-result.json build/capsules
```

Later, verify it with an input document containing:

```json
{"operation":"verify","capsule_directory":"build/capsules/<capsule-name>"}
```

Verification re-hashes required artifacts and configuration. A verified capsule demonstrates that the recorded inputs/configuration remain intact; it does not by itself establish physical-model validity or certification.

For every request field and output contract, see `docs/ENGINEERING_INTELLIGENCE_PLATFORM.md` and User Manual Chapter 91.


## 31.7 Qualify physical realization, freshness, and software-runtime interactions

After the logical E/E/service architecture is credible, exercise the newly added realization/runtime domains:

```text
engineering-intelligence geometric-wiring-harness-synthesizer harness.json harness-result.json
engineering-intelligence vehicle-function-actuator-arbitration arbitration.json arbitration-result.json
engineering-intelligence age-of-information-freshness-laboratory aoi.json aoi-result.json
engineering-intelligence adas-service-calibration-workshop-metrology workshop.json workshop-result.json
engineering-intelligence embedded-resource-degradation-laboratory resources.json resources-result.json
engineering-intelligence concurrent-ecu-race-lock-order-analyzer concurrency.json concurrency-result.json
```

Use geometric harness synthesis after zonal allocation so logical placement is converted into manufacturable physical routing, then pass the canonical harness reliability payload into the established electrical/reliability workflow. Use actuator arbitration to test simultaneous controller authority and ownership transitions, and use AoI together with service-graph/timebase outputs to detect stale information even when deadlines and clock synchronization individually pass. Workshop metrology should be exercised after service or sensor replacement. Embedded-resource and concurrency traces are long-duration software qualification tools: they expose fragmentation/leaks/queue or handle exhaustion, data races, lock-order cycles, starvation, and lock misuse that ordinary WCET checks do not capture.

## 31.8 Qualify service condition and charging-connector aging

```text
engineering-intelligence cross-fluid-condition-diagnostics fluids.json fluids-result.json
engineering-intelligence charging-connector-aging-laboratory connector.json connector-result.json
```

Cross-fluid diagnostics unifies service-condition scoring across oil, coolant, brake fluid, refrigerant oil, and hydraulic fluid while delegating oil chemistry to the existing lubricant-condition authority. Charging-connector aging evaluates mechanical/contact deterioration and then feeds the aged connector state into the existing J3400/ISO 15118 conformance laboratory. Treat the combined physical-plus-protocol result as the qualification output.

## 31.9 Plan discriminating experiments and suppress redundant HPC work

```text
engineering-intelligence scientific-hypothesis-experiment-planner hypothesis.json hypothesis-result.json
engineering-intelligence hpc-experiment-novelty-redundancy-controller campaign.json campaign-result.json
```

The hypothesis planner screens measured associations, penalizes confounding, keeps discovered relationships explicitly non-causal, and delegates expected-information-gain ranking to the canonical Bayesian experimental designer. The HPC controller compares normalized behavior embeddings against completed work, combines novelty with uncertainty and compute cost, and selects a bounded next batch while suppressing redundant experiments. Use these together: first choose experiments that best discriminate competing hypotheses, then allocate compute toward genuinely new behavior.

# 32. V33 Generalized Engineering Operations workflow

## 32.1 Focused build and discovery

```bash
cmake --build build/full --parallel 2 --target \
  generalized_engineering_operations_platform_tests \
  muzixdiagsys_generalized_ops
./build/full/muzixdiagsys_generalized_ops capabilities
```

## 32.2 Run deterministic integrated qualification

```bash
mkdir -p build/generalized-ops-self-test
./build/full/muzixdiagsys_generalized_ops self-test \
  build/generalized-ops-self-test \
  build/generalized-ops-self-test/result.json
ctest --test-dir build/full --output-on-failure \
  -R '^generalized_engineering_operations_'
```

## 32.3 Recommended engineering sequence

1. Record external nondeterminism with the hermetic I/O sandbox.
2. Compute changed-code coverage and affected tests.
3. Build a dependency/critical-path-aware adaptive test plan.
4. Explore alternate interleavings for concurrency-sensitive changes.
5. Run crash-consistency fault matrices on modified persistent stores.
6. Compare architecture fitness and build-cost baselines.
7. Perform long-run soak/resource/degradation qualification.
8. Admit new fuzz discoveries into the shared corpus and create deterministic reproducers.
9. Run compatibility governance before publishing an API/ABI/CLI/schema/configuration change.

The exact C++ APIs are documented in `GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md` and User Manual Chapter 93.

# 33. V34 Native Qualification workflow

## 33.1 Build and self-test

```bash
cmake --build build/full --parallel 2 --target \
  native_qualification_platform_tests \
  muzixdiagsys_native_qualification
./build/full/muzixdiagsys_native_qualification capabilities
./build/full/muzixdiagsys_native_qualification self-test \
  build/native-qualification-self-test \
  build/native-qualification-self-test/result.json
```

## 33.2 Qualification campaign order

1. Generate a sanitizer/toolchain compatibility matrix.
2. Generate pairwise or 3-way configuration covering arrays for high-risk build/runtime options.
3. Build the same target from two clean directories and run reproducibility forensics.
4. Compare binary/section/symbol size against the accepted baseline.
5. Audit named stochastic streams and unexpected RNG consumers.
6. Snapshot host resources before/after focused tests.
7. Exercise graceful shutdown and forced signal paths with the lifecycle chaos lab.
8. Normalize static-analysis findings and gate only new debt.
9. Use spectrum fault localization if regressions fail.
10. Run GCC/Clang O0/O2/O3 differential qualification on numerically sensitive targets.

Detailed semantics are in `NATIVE_QUALIFICATION_PLATFORM.md` and User Manual Chapter 94.

# 34. V35 Motorsport Expansion workflow

## 34.1 Build, discover, and qualify

```bash
cmake --build build/full --parallel 2 --target \
  aesim_motorsport_v35 \
  motorsport_v35_platform_tests \
  muzixdiagsys_motorsport_v35

./build/full/muzixdiagsys_motorsport_v35 capabilities
./build/full/muzixdiagsys_motorsport_v35 self-test
ctest --test-dir build/full --output-on-failure \
  -R '^motorsport_v35_(platform_unit_tests|source_regression|cli_self_test)$'
```

## 34.2 WEC/IMSA or GT endurance study

Use `EnduranceRaceEngineeringPlatform` for prototype/LMGT3 endurance studies or `GtCustomerRacingPlatform` for customer-racing lifecycle/operations. A recommended sequence is:

1. define the vehicle, fuel/energy limits, current wear/damage, and drivers;
2. configure driving-time/rest and pit-service concurrency rules;
3. initialize `SpatialTrackStateField` from current weather and track state;
4. simulate candidate stints and pit requests;
5. use `HierarchicalRaceStrategyAI` to rank feasible alternatives;
6. evaluate representative overtakes/defenses using `RacecraftInteractionPhysics`; and
7. classify/end the stint and persist the accepted run through the existing experiment/reproducibility framework.

Minimal C++ skeleton:

```cpp
#include "aesim/advanced/motorsport_v35_platform.hpp"
using namespace aesim::advanced::motorsport;

EnduranceVehicleSpec car;
car.id = "car-01";
car.category = EnduranceClass::Lmdh;
EnduranceRaceState state;
state.car_id = car.id;
state.fuel_kg = 80.0;
EnduranceDriver driver;
driver.id = "driver-a";
EnduranceStintConditions conditions;
conditions.duration_s = 2700.0;

auto report = EnduranceRaceEngineeringPlatform{}.simulate_stint(
    car, {driver}, state, conditions);
```

## 34.3 BoP analysis

Build a `BopObservation` set using like-for-like observations and explicit driver/tyre/weather/traffic offsets. Run `infer_latent_performance()` first and inspect standard error/anomaly score before calling `optimize()`. Validate any proposed bounded adjustment on independent tracks; do not treat the output as an official BoP ruling.

## 34.4 World Rally stage workflow

1. divide the stage into `RallyStageSegment` objects;
2. encode available `PaceNote` entries by distance/feature/severity/confidence;
3. set road position, weather, visibility, altitude, tyre, crew state, and deterministic seed;
4. call `run_stage()` and inspect segment times, cleaning loss, note loss, puncture probability, damage, and fatigue; and
5. call `service()` with the real service-window budget and inspect deferred repairs.

## 34.5 Formula E workflow

1. initialize usable energy, battery/brake temperature, and tyre state;
2. simulate candidate laps using pace, lift-and-coast, and front/rear regeneration commands;
3. monitor thermal derating and friction-brake contribution;
4. use `optimize_attack_mode()` over legal activation laps;
5. apply neutralization energy adjustment after FCY/Safety-Car periods; and
6. use `run_duel_qualifying()` for group/duel qualifying studies.

## 34.6 Driver digital twin and coaching loop

After every representative run, call `MotorsportDriverDigitalTwin::observe()` with the telemetry-derived observation and elapsed time. Feed the twin's `predict()` output into strategy/racecraft uncertainty. For lap improvement, synchronize the driver lap to a comparable reference and run `LapTimeAttributionCoach::analyze()`; prioritize the largest reported braking/entry/minimum-speed/traction/straight/traffic/tyre/energy/damage/weather losses.

## 34.7 Track-state and racecraft coupling

Initialize `SpatialTrackStateField` once, then evolve it with `advance_weather()` and `apply_vehicle_pass()` rather than resetting a scalar grip value every lap. Sample the local cell for strategy/racecraft/tyre studies. When two cars interact, pass their current local grip/tyre/aero state into `RacecraftInteractionPhysics::assess()` and honor infeasibility/collision-risk findings as hard constraints before strategy scoring.

## 34.8 GT3/GT4 customer-racing operations

Use `GtCustomerRacingPlatform` to include team cash and spares in addition to lap performance. A pit request can be physically desirable but rejected/limited when inventory or cash is insufficient. Track engine/gearbox mileage and replace components explicitly rather than erasing wear with a generic repair command.

The complete field-level reference is `MOTORSPORT_V35_PLATFORM.md`; User Manual Chapter 95 explains integrated operation and qualification boundaries.



# 35. V36 Professional Authority workflow

V36 is intended for a correlation-first workflow: preserve existing vehicle/motorsport authorities, attach the new high-fidelity authority only where it adds information, and validate every substitution against measured data.

## 35.1 Build and enumerate the authority surface

```bash
cmake -S . -B build/v36 -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/v36 --parallel 2 --target \
  professional_authority_platform_tests \
  muzixdiagsys_professional_authority_v36
./build/v36/muzixdiagsys_professional_authority_v36 capabilities
./build/v36/muzixdiagsys_professional_authority_v36 self-test
```

## 35.2 Recommended vehicle-correlation sequence

1. Load or fit `TireAuthorityModel` parameters from flat-trac measurements; use the MF-Swift state when transient relaxation/ring behavior matters.
2. Fit `NonlinearDamperLaboratory` against damper-dyno measurements.
3. Build `GeneralizedSuspensionKandC` from surveyed hardpoints and compare its sweep against K&C rig data.
4. Import measured laps with `MotorsportTelemetryInterop`, align timebases, normalize units, detect laps, and resample by distance.
5. Evolve `TrackStatePhysicsAssimilator` from weather/vehicle passes and assimilate grip observations rather than tuning a single global grip scalar.
6. Correlate brake and driveline residuals using `BrakeTribologyThermoelasticTwin` and `DrivelineTorsionalNvhPlatform`.
7. Use `ModelDiscrepancyValiditySupervisor` to distinguish calibration error from operation outside the validated domain.
8. Apply `AdvancedGlobalSensitivitySuite` before expensive optimization so weak parameters can be screened out.
9. Gate mesh/model changes through `CaeCorrelationQualificationPlatform` instead of accepting a visually converged CFD/FEA result.

## 35.3 Motorsport operations sequence

For endurance, continue using V35 vehicle/stint physics and feed timing-line events and penalties to `EnduranceTimingScoringRaceControl`. For rally, use V35 stage physics and `RallyEventOperationsPlatform` for time controls, assigned/cancelled-stage times, retirement/restart, and event classification. For Formula E, combine V35 lap/energy physics with `FormulaENextGenerationOperations` for charging and configured deployment rules.

## 35.4 HIL and external authority sequence

Use `EthercatProcessImage` for deterministic PDO mapping and `HilVendorIntegration` over the established `HilIoManager`; do not create a parallel transport loop. A licensed FTire/CDTire solver can be attached with the V36 tire-authority ABI, and CoolProp/REFPROP/Cantera property authorities can be loaded through `ThermophysicalAuthorityBackend`. Run the compiled V36 behavioral test after changing any adapter.

## 35.5 Research sequence

Use `RegulatoryKnowledgeIngestionPlatform` to review rule changes, `PhysicsEquationDiscoveryPlatform::sindy()` to propose interpretable reduced-order equations, then validate those equations against held-out data and the validity supervisor. Discovery output should not automatically replace an established physical authority without correlation evidence.

See `PROFESSIONAL_AUTHORITY_PLATFORM_V36.md` and User Manual Chapter 96 for the complete API and qualification boundary.


# 36. V37 ECU / Diagnostics / SocketCAN Authority workflow

## 36.1 Build and qualify

```bash
cmake -S . -B build/v37 -G Ninja \\
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \\
  -DBUILD_TESTING=ON \\
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/v37 --parallel 2 --target \\
  ecu_diagnostics_socketcan_v37_tests \\
  muzixdiagsys_ecu_diagnostics_v37
./build/v37/muzixdiagsys_ecu_diagnostics_v37 status
./build/v37/muzixdiagsys_ecu_diagnostics_v37 self-test
python3 tests/ecu_diagnostics_socketcan_v37_source_regression.py .
```

## 36.2 Software-only ECU/OBD bench

1. Prefer `vcan`/`vxcan` when no physical transceiver is required.
2. Instantiate the existing `DiagnosticService` and `EcmObdPlatform`; do not build an independent UDS/OBD responder.
3. Use `DiagnosticProtocolAuthority` for per-tester transactions and retain its transaction log as evidence.
4. Drive ECM operation cycles until monitor/IUPR conditions are meaningful.
5. Use `J1978ScanTool` for J1979/J1979-2/J1979-3 requests and run `RegulatoryObdAuthority::run_j1699_5_campaign()` for deterministic pre-compliance checks.
6. Inject plant/network faults through the established simulators and mirror diagnostic events through `AutosarDcmDemAuthority`.

## 36.3 Linux SocketCAN bench

Use `SocketCanRawAuthority` when you need real kernel filtering, error frames, CAN-FD, and timestamp ancillary data. Use `SocketCanBcmAuthority` for kernel-timed periodic traffic and timeout/content monitoring. Use `KernelJ1939Authority` only when kernel J1939 interoperability is required; retain the existing user-space J1939 implementation for deterministic pure simulation.

Inspect an interface before configuring it. Interface mutation and `vcan`/`vxcan` creation require normal Linux networking privileges and must be restricted to an isolated bench or deliberately created virtual network.

## 36.4 Engineering-data workflow

1. Import supplier/OEM ODX XML or a PDX package with `OdxPdxRuntime`.
2. Resolve and encode a known diagnostic service, then decode a representative response.
3. Execute the associated procedure with `OtxRuntime`; treat assertion/service failures as failed evidence.
4. Register canonical signals/diagnostic identifiers in `DiagnosticSemanticRegistry` and reject collisions/inconsistent units.
5. Validate A2L against `SignalRegistry` before using `XcpCalibrationAuthority` for CTO/event/STIM operations.
6. Import/capture candump, Vector ASC, PCAPNG, or CSV with `AutomotiveTrace`, then feed the normalized events to `DeterministicCanReplay` for reproducibility.

## 36.5 Release gate

Run the V37 behavioral test, CLI self-test, and source/anti-duplication regression together. A change is not accepted merely because one diagnostic request succeeds; session isolation, DTC lifecycle, regulatory behavior, kernel transport semantics, ODX/OTX execution, calibration consistency, and trace round-trips must remain qualified.

# 37. V38 Advanced Automotive Electronics & Compute Authority workflow

## 37.1 Build and qualify the complete release

Use the transactional build path when accepting a release or after cross-cutting changes:

```bash
./tools/build_full_and_test.sh --clean --jobs 2 --compile-jobs 2 --test-jobs 2
```

The script configures `BUILD_TESTING=ON`, hardening, position-independent code, strict numerics, SYCL/HIP discovery, bounded compile concurrency, and the complete `aesim_check` target. CTest is not started until the full runtime/test artifact closure builds successfully.

For an incremental V38-only edit after configuration:

```bash
cmake --build build/full --parallel 2 --target \
  aesim_electronics_compute_v38 \
  automotive_electronics_compute_authority_tests
ctest --test-dir build/full --output-on-failure \
  -R '^automotive_electronics_compute_authority_tests$'
```

## 37.2 Phase A — build an ECU electronics execution chain

1. Configure `McuPeripheralInterruptDmaAuthority` with interrupt vectors, peripherals, FIFOs, and DMA channels.
2. Schedule peripheral events and DMA requests, advance cycles, and inspect interrupt latency, preemption, FIFO overruns, DMA completions, and utilization.
3. Add `SafetyMcuSupervisor` to the same study for MBIST/LBIST, ECC, watchdog, clock/voltage monitoring, lockstep faults, and safe-state escalation.
4. Use `TransactionalNvmAuthority` for power-loss-safe calibration/adaptation blocks instead of inventing an independent NVM reliability model.
5. Use `ClockResetPowerSequencer` with the canonical PMIC/SBC model to reproduce rail enable, clock startup/PLL lock, reset release, and boot-stage dependencies.
6. Use `EcuBoardElectronicsAuthority` for AFE/ADC behavior, actuator-driver current/thermal stress, and board-component thermal state.

Always reject non-finite sensor/configuration values at ingestion. V38 now enforces this contract at public boundaries, so a `NaN` should be treated as an upstream data/model defect rather than a physical value.

## 37.3 Phase B — network and AUTOSAR communication workflow

Build the deterministic network stack from the physical/protocol layer upward:

1. Use `Lin2NetworkAuthority` for schedule tables, sporadic/event-triggered traffic, sleep/wake, NAD/diagnostic traffic, and response/checksum fault injection.
2. Use `FlexRayNetworkAuthority` for cold start, channel A/B availability, static slots, dynamic minislots, and synchronization/clock-error studies.
3. Use `AutomotiveEthernetPhyAuthority` for cable/connector loss, SNR/BER/FEC, link training, thermal behavior, and pair/link faults.
4. Feed frames through `EthernetSwitchSiliconAuthority` when finite buffers, VLAN policy, MAC learning, priority arbitration, PTP timestamps, or head-of-line effects matter.
5. Use `AutosarCommunicationStackAuthority` for signal packing, PDU routing/segmentation, and E2E counter/CRC/repetition/sequence protection.

Correlate a failed application signal with its lowest failing layer rather than attributing every failure to AUTOSAR COM.

## 37.4 Phase C — body, access, and distributed power workflow

Use `BodyControlModuleAuthority` for lighting, indicators, wipers, locks, and lamp-current diagnostics. Couple it to `SmartPowerDistributionController` and the existing `LowVoltagePowerNetwork` to observe how brownout and eFuse/load-shedding policy changes body functionality.

For doors/windows/seats/tailgates, use `DistributedBodyActuatorEcu` with explicit motor electrical/mechanical/thermal parameters, learned end stops, supply voltage, and obstruction force. Validate pinch reversal and stall/thermal diagnostics under degraded supply and increased mechanical load.

For access studies, configure at least four geometrically useful `UwbAnchor` instances, generate secure ranging observations, and call `PepsUwbDigitalKeyAuthority::localize()`. Review residual RMS and relay suspicion before using the inside/trunk/approach classification.

## 37.5 Phase D — centralized compute contention workflow

For cockpit/IVI studies, use `CockpitIviComputerAuthority` and submit `CockpitWorkload` instances with explicit CPU/GPU/NPU, memory, storage, deadline, priority, and safety relevance. Advance with a physical ambient temperature and correlate deadline misses with utilization and thermal throttling.

Use `DisplayPipelineAuthority` to separate GPU/compositor budget misses from serializer corruption. Use `AutomotiveAudioElectronicsAuthority` to assess DSP saturation, xruns, amplifier thermal state, and ANC degradation.

For ADAS SoC studies, use `AdasSocContentionAndSafetyAuthority` as the contention and safety-island authority:

1. register accelerator capacity/power/thermal characteristics;
2. define partitions with accelerator allow-lists and DDR/NoC/runtime/memory quotas;
3. submit workloads with operations, memory movement, NoC movement, working-set size, and deadline;
4. advance under the required ambient condition; and
5. inspect deadline misses, partition violations, watchdog termination, DVFS, temperature, and safety-island fault state.

## 37.6 Phase E — reliability, EMC, harness, OTA, and startup workflow

Run mission profiles through `EcuElectronicsAgingAuthority` to combine semiconductor, capacitor, solder, and oscillator degradation. Then evaluate transient susceptibility with `AutomotiveEmcTransientQualificationAuthority` using explicit source/protection parameters.

Use `WiringHarnessGroundingAuthority` for the DC grounding/resistance twin. Establish nodes/segments/source first, solve the nominal state, then inject added resistance, leakage, opens, or shorts and compare voltage/current/loss/noise results against the baseline.

Use `IntermittentElectricalFaultEngine` for seeded stochastic intermittent behavior. Keep the seed fixed for regression and vary temperature, vibration, humidity, and current in controlled campaigns.

For SDV deployment:

1. populate `SoftwareCompatibilityDeploymentGraph` with ECU versions and cross-ECU constraints;
2. reject an incompatible candidate before payload installation;
3. start `ProductionOtaCampaignOrchestrator` with canaries, dependencies, minimum SOC, and payloads;
4. advance only under the intended stationary/SOC/health conditions; and
5. analyze startup with `WholeVehicleStartupAuthority` after the software set is active.

## 37.7 Release acceptance checklist

A V38 change is not release-ready until the full build and CTest suite pass. At minimum, verify that the V38 unit test passes, the source/documentation/package regressions pass, no new compiler warnings are introduced, and no source feature has been removed or duplicated. See `AUTOMOTIVE_ELECTRONICS_COMPUTE_AUTHORITY_V38.md` and User Manual Chapter 98 for the complete API and authority boundary.


# 38. NHRA Phases A-J Deep Race Physics and Operations workflow

The NHRA A-J authority extends the established `nhra` facade; it does not replace the championship/strategy or race-engineering domains. Start with the focused authority tests, then qualify the complete facade.

## 38.1 Build and authority discovery

```bash
cmake --build build/full --parallel --target \
  nhra_deep_authority_platform_tests \
  nhra_championship_strategy_platform_tests \
  nhra_race_engineering_platform_tests \
  muzixdiagsys_advanced_platform
./build/full/muzixdiagsys_advanced_platform nhra capabilities
```

The `deep_authority` capability block enumerates `run-dynamics`, `driveline-torsion-tires-chassis`, `crank-angle-nitro-combustion`, `fuel-blower-ignition-failure`, `telemetry-ingestion`, `digital-twin-calibration`, `pro-stock-engineering`, `pro-stock-motorcycle-top-alcohol`, `four-wide-competition`, and `rules-scrutineering-event-operations`.

## 38.2 Coupled run and powertrain workflow

1. Execute `run-dynamics` with a spatial `track_points` field when measured/laser-derived geometry is available.
2. Use `driveline-torsion-tires-chassis` to inspect shaft twist, independent left/right tire state, yaw tendency, pitch, and wheelie-bar contact.
3. Use `crank-angle-nitro-combustion` for the 720-degree cylinder-cycle state and per-cylinder pressure/work response.
4. Use `fuel-blower-ignition-failure` to propagate fuel-rail, blower, magneto, cylinder-mixture/pressure/EGT, and failure state into available torque.
5. Re-run Phase A with calibrated parameters rather than applying post-hoc ET corrections.

## 38.3 Telemetry and digital-twin calibration

Phase E reuses `MotorsportTelemetryInterop`; do not create a parallel CSV/vendor reader. Import the run through `telemetry-ingestion`, then execute `digital-twin-calibration` for inverse drive/aero estimation, Bayesian segment-grip updates, causal A/B deltas, and seeded uncertainty propagation. Persist the evidence directory for run-to-run comparisons.

## 38.4 Additional classes and competition

Use `pro-stock-engineering` for the shared multi-ratio run kernel and dated Pro Stock profiles. Use `pro-stock-motorcycle-top-alcohol` for PSM and Top Alcohol class-specific states. Use `four-wide-competition` for four independent lanes, fouls, staging/reaction/ET classification, and two-entrant advancement.

## 38.5 Rules, scrutineering, and release gate

`rules-scrutineering-event-operations` uses dated engineering profiles and explicitly does not replace the controlling NHRA rulebook, bulletins, event instructions, or officials. Run:

```bash
ctest --test-dir build/full --output-on-failure \
  -R 'nhra_(championship_strategy|race_engineering|deep_authority)'
```

For implementation/API details use `NHRA_DEEP_RACE_PHYSICS_OPERATIONS_AUTHORITY.md` and User Manual Chapter 99.

# 39. MotoGP Phases A-J Engineering and Research workflow

MotoGP is a dedicated first-class authority under the `motogp` root while the pre-existing generic motorcycle and expanded-motorsport models remain available.

## 39.1 Build, discover, and self-test

```bash
cmake --build build/full --parallel --target \
  motogp_authority_platform_tests \
  muzixdiagsys_advanced_platform \
  muzixdiagsys
./build/full/muzixdiagsys_advanced_platform motogp capabilities
./build/full/muzixdiagsys_advanced_platform motogp self-test
ctest --test-dir build/full --output-on-failure \
  -R 'motogp_authority|interactive_advanced_motorsport'
```

## 39.2 Physical setup sequence

1. Run `multibody-dynamics` to establish speed/position, roll/pitch/yaw, steering, fork/shock, rider shift, and wheelie/stoppie margins.
2. Run `tire-contact-mechanics` with front/rear slip, camber, load, temperature, pressure, and wear; inspect combined-slip utilization and aligning moment.
3. Run `powertrain-driveline` for V4/inline-four firing pulses, explicit ratios, seamless shift, slipper clutch, chain state, and anti-squat.
4. Run `electronics-controls` to quantify traction, wheelie, and engine-braking interventions from simulated wheel-speed/IMU signals.
5. Run `aerodynamics` with lean/pitch/yaw/ride height, wake, rider tuck, and crosswind.

## 39.3 Rider, circuit, telemetry, and setup workflow

Use `rider-digital-twin` for articulated body position, hang-off optimization, confidence/fatigue/physiology. Feed circuit geometry and water-film state to `circuit-race-physics`. Import measured data through `telemetry-engineering`, which reuses `MotorsportTelemetryInterop`, then estimate effective grip/curvature and search bounded rake/trail/suspension/engine-map settings.

## 39.4 Operations, safety, and the 2027 laboratory

`operations-rules-safety` exposes dated 2026/2027 engineering profiles, Sprint/GP/session operations, bike swaps, penalties, runoff/slide, and airbag safety estimates. `2027-research-laboratory` compares 2026 1000 cc and 2027 850 cc concepts, reduced aero freedom, Pirelli tire transition, non-fossil-fuel effects, historical eras, and clearly labeled `NON_COMPETITION_RESEARCH` what-if states.

For implementation/API details use `MOTOGP_ENGINEERING_RESEARCH_AUTHORITY.md` and User Manual Chapter 100.

# 40. V40.3 Browser Operations and Fault-Investigation Workflow

Use this workflow when a live symptom must be connected to authoritative diagnostic, temporal, provenance, run-comparison, and solver/HPC evidence.

## 40.1 Start the authenticated browser and establish live context

```text
ui web start 0 127.0.0.1
ui web status
ui mission-control status
ui profiler status
ui solver-console status
```

Open **Live Operations Center** in the browser. Select the suspicious KPI so the signal is published to Shared Engineering Context. Use the canonical run/pause/step controls; browser widgets do not bypass the command/access authority.

## 40.2 Investigate first-out and correlated diagnostic evidence

```text
ui diagnostic-center status
ui soe first-out
ui alarm-flood 10 0.5 20
ui transient-lens first-out 5 5
ui what-changed event 2 2 20
ui incident-workspace first-out
```

In **Diagnostics / Fault Investigation Center**, select an evidence reference such as `alert:17`, `solver:latest`, `regression:<name>`, or `flight:<sequence>` and use the canonical explanation path:

```text
ui diagnostic-center explain alert:17
```

Acknowledgment and clearing remain mutating, role-aware operations:

```text
ui diagnostic-center ack 17
ui diagnostic-center clear 17
```

## 40.3 Move the investigation to exact simulation time and provenance

```text
ui time timeline
ui time previous-event
ui time next-event
ui time checkpoint pre-investigation
ui time bookmarks
```

Use **Provenance + Time-Travel State Inspector** to compare the nearest bounded browser frame at the linked cursor, optionally place A/B cursors, and inspect signal lineage:

```text
ui provenance-graph inspect rpm 4.286124
ui object-inspector inspect rpm
ui signal-explorer inspect rpm
ui flight-recorder show rpm
```

A browser frame is presentation evidence only. `ui time checkpoint` / `ui time restore` remain the authoritative restorable simulator-state mechanism.

## 40.4 Use the repaired Signal Explorer before or during streaming

The browser now loads the canonical catalog from:

```text
ui signal-explorer list
ui signal-explorer search pressure
ui signal-explorer inspect boost_kpa
ui signal-explorer history boost_kpa
```

Signal rows remain selectable while live values update. Selection is retained in application-level state, pointer selection is committed before the inspection request, and stale asynchronous inspection responses are discarded. A complete schema/workbench redraw therefore preserves the selected signal. The live stream enriches current values and bounded sample counts; it no longer determines whether the signal exists in the browser list.

## 40.5 Compare against a baseline and locate the first divergence

```text
ui run-compare list
ui run-compare json rpm time 1200
ui causal-difference divergences candidate-run 1e-9 1e-6
ui causal-difference explain candidate-run rpm 1e-9 1e-6
ui causal-difference graph
```

Use **Advanced Run Comparison + Causal Difference Analysis** to select a baseline/candidate, move the linked cursor to the first meaningful divergence, and inspect declared dependency evidence. If the comparison IDs are canonical Run Manager records, compare their metadata and parameters with:

```text
ui run-manager inspect baseline-run
ui run-manager inspect candidate-run
```

## 40.6 Exclude numerical or compute-health causes

```text
ui profiler json
ui solver-console json
ui solver-console thresholds
ui performance-investigator status
ui hpc-placement json
ui hardware-topology status
```

Use **Solver / HPC Health Dashboard** to correlate CPU/GPU/memory pressure, rejected solver steps, residual/condition/local/conservation errors, and distributed placement with the physical event time. Treat canonical solver thresholds as the pass/warn authority; the browser only presents them.

For the complete V40.3 browser behavior, see `WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md` and User Manual Chapter 101.

# 41. V40.4 Simulation Optimization Runtime Workflow

V40.4 is a C++ runtime API rather than a second simulator CLI. Existing physics modules continue to own their equations and canonical commands. Use `aesim::advanced::runtime::SimulationOptimizationRuntime` when composing high-throughput or heterogeneous simulations.

A practical workflow is:

1. Register each physical domain with its own `synchronization_period_s` and internal step bounds.
2. Declare validated fidelity levels and, where possible, provide a domain error estimator.
3. Register expensive derived calculations in the dependency graph instead of recomputing them unconditionally.
4. Select `RuntimeResource::Auto` unless a domain has a real accelerator implementation or must execute in an MPI-aware context.
5. Run to a meaningful branch point and create a COW checkpoint.
6. Use `branch_from()`, `restore()`, and `set_domain_state()` for counterfactual continuations. Checkpoint restore reinstates both physics state and adaptive execution-policy state; an actual `set_domain_state()` mutation invalidates the learned fidelity/solver policy only for the changed domain before continuation.
7. Use `run_ensemble()` for homogeneous Monte Carlo/DOE populations.
8. Inspect `optimization_report()` after representative workloads before changing solver or fidelity policy.

Do not mark a domain `require_accelerator=true` unless its callback actually uses the accelerator placement supplied in `DomainStepContext`. The scheduler reports lack of required hardware as an error rather than silently emulating an accelerator.

See `SIMULATION_OPTIMIZATION_RUNTIME_V40_4.md` and User Manual Chapter 102 for the full API and semantics.


# 42. V40.5 Engine Research Digital Twin Workflow

V40.5 is a C++ engine-research composition API, not a second engine CLI. Existing gas-dynamics, valvetrain/EHL, detailed injection/combustion, forced-induction, and calibration/UQ authorities remain canonical. Include `aesim/high_fidelity/engine_research_digital_twin.hpp`, configure `EngineResearchConfiguration`, then advance `EngineResearchDigitalTwin::step()` with `EngineResearchInput`.

A complete advanced workflow is: (1) select the established crank-angle engine and duct geometry; (2) select cranktrain/valvetrain/EHL and injection/spray configuration; (3) configure forced induction and the intake/plenum/header network; (4) configure EGR, oil system, reduced chemistry/turbulence, reduced-FE and thermal-clearance parameters; (5) configure aftertreatment and observer/control targets; (6) advance the coupled twin; (7) inspect conservation/margin/health/lifecycle state; (8) inject deterministic cylinder faults or advanced supplemental fueling when the experiment requires them; (9) correlate against measured dyno points; and (10) optionally run the durability-aware design/calibration optimizer.

Example:

```cpp
EngineResearchConfiguration cfg;
cfg.forced_induction_mode = EngineForcedInductionMode::Turbocharger;
cfg.dry_sump_enabled = true;

EngineResearchDigitalTwin engine(cfg);
EngineResearchInput input;
input.rpm = 4500.0;
input.load = 0.90;
input.external_egr_command_fraction = 0.035;
input.water_injection_kg_s = 0.003;
input.closed_loop_combustion_control = true;
for (int i = 0; i < 1000; ++i) engine.step(input, 0.0005);
std::cout << engine.report();
```

The new high-value state surfaces are `chemical_kinetics`, `chamber_turbulence`, `gas_wave_network`, `egr_transport`, `oil_hydraulics`, `flexible_body`, `clearances`, `aftertreatment`, `pressure_observers`, `combustion_controller`, `lifecycle`, and `advanced_fueling`. All previously documented V40.5 state remains available.

For an internal/external EGR study, set `external_egr_command_fraction`; a negative value preserves the earlier `egr_fraction` behavior. For oil-system studies, select `dry_sump_enabled`, set pump/scavenge parameters, and inspect gallery pressure, aeration, effective viscosity, bearing/jet flow, and mass residual. For advanced charge/fuel studies, use water, methanol, nitrous, and nitromethane inputs and inspect the resulting effective intake temperature, oxygen fraction, LHV/AFR, supplemental chemical power, and knock-suppression state.

For a fault campaign, set `input.fault_injections` to one or more `CylinderFaultInjection` entries. Fault severity is bounded to `[0,1]` and modifies corresponding physical/health state before the next coupled calculation.

For lifecycle work, use `engine.lifecycle()` to identify component RUL and `engine.rebuild_component(component_id)` to create a restored successor generation. Successful rebuilds create genealogy events rather than erasing predecessor history.

For dyno calibration, populate `std::vector<EngineDynoPoint>` with RPM, load, measured torque/MAP/fuel/EGT/peak-pressure and standard deviations, then call `EngineDynoCalibrationLab::calibrate()`. For durability-aware co-design, create `EngineDurabilityOptimizationRequest` and call `optimize_design_and_calibration()`. The outer design search reuses the same canonical calibration/UQ authority.

Recommended focused validation:

```bash
cmake -S . -B build/engine-validation -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build/engine-validation --target ecosystem_tests high_fidelity_vehicle_tests
./build/engine-validation/ecosystem_tests
./build/engine-validation/high_fidelity_vehicle_tests
python3 tests/user_manual_regression.py .
```

See `ENGINE_RESEARCH_DIGITAL_TWIN_V40_5.md` and User Manual Chapter 103 for complete state semantics, coupling/invariants, and qualification boundaries.


# 43. Transmission Authority Phases E-I Gearbox Workflow

The Phase E-I gearbox expansion is an additive C++ workflow over the existing `TransmissionAuthoritySystem` and `FullTransmissionSystem`. Do not create a separate shift scheduler, valve body, DCT/CVT solver, or durability model for the same transmission. The established Phase A-D authorities remain canonical.

A practical validation workflow is:

1. Configure the architecture and installed ratios in `FullTransmissionConfiguration`.
2. Validate the Phase E multi-body shaft/mesh and thermal states at steady gear before requesting shifts.
3. For automatic architectures, request a gear transition and record `clutch_to_clutch` phase, target/achieved pressure, off-going/on-coming commands, shaft speeds, slip energy, output torque, and TCU torque request.
4. For manual/sequential architectures, opt into the detailed driver model with `clutch_pedal_position >= 0`, then inspect pedal/selector/blocker/synchronization/rev-match/grind state. Leave the pedal input negative when validating legacy `clutch_command` behavior.
5. Exercise predictive TCU context by varying grade, predicted grade, lateral acceleration, wheel slip, braking, trailer mass, and battery SOC.
6. Inject pump, clutch-leak, actuator, low-oil, range-actuator, and speed-sensor faults and confirm that the physical hydraulic/actuator state changes before diagnostic/limp decisions.
7. Run thermal/duty cycles and inspect lubricant oxidation/TAN/debris/filter loading, component RUL, limiting component, and severe-shift count.
8. Call `service_lubricant()` and `rebuild_component()` to validate service state and genealogy without erasing unrelated damage history.
9. Inspect the durability optimizer's bounded pressure/shift-time/overlap solution and replay the candidate through representative operating cycles.
10. Repeat the matrix for AMT, DCT, torque-converter automatic, planetary automatic, CVT, planetary hybrid, multispeed e-axle, sequential dog, motorsport sequential, and heavy-truck range/splitter.

Example full-plant study:

```cpp
using namespace aesim::high_fidelity;

FullTransmissionConfiguration cfg;
cfg.architecture = TransmissionArchitecture::DualClutch;
FullTransmissionSystem transmission(cfg);

TransmissionInput in;
in.current_gear = 2;
in.requested_gear = 3;
in.input_torque_nm = 380.0;
in.engine_speed_rad_s = 340.0;
in.output_speed_rad_s = 58.0;
in.throttle_fraction = 0.75;
in.predicted_road_grade_fraction = 0.04;
in.battery_soc = 0.70;

for (int k = 0; k < 1200; ++k) {
    transmission.step(in, 0.001);
    in.current_gear = transmission.state().engaged_gear;
}

std::cout << transmission.report();
```

For a resolved manual experiment:

```cpp
in.clutch_pedal_position = 1.0;
in.driver_shift_force_n = 85.0;
in.driver_shift_aggressiveness = 0.6;
in.throttle_blip_fraction = 0.2;
in.double_clutch_command = true;
```

For a service/rebuild experiment:

```cpp
transmission.service_lubricant();
transmission.rebuild_component("synchronizer-pack");
const auto& life = transmission.lifecycle();
```

Focused validation:

```bash
cmake -S . -B build/gearbox-validation -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build/gearbox-validation --target transmission_authority_tests ecosystem_tests accuracy_depth_complete_tests
./build/gearbox-validation/transmission_authority_tests
./build/gearbox-validation/ecosystem_tests
./build/gearbox-validation/accuracy_depth_complete_tests
python3 tests/user_manual_regression.py .
```

See `TRANSMISSION_AUTHORITY_PHASES_E_I.md` and User Manual Chapter 104 for the full state/API contract and release boundaries.

# 44. V46 Integrated Engineering Workstation Workflow

This workflow exercises the V46 browser additions without bypassing canonical shell authorities. It assumes an authenticated `muzixdiagsys` session and a build with the engineering UI enabled.

## 44.1 Start the authenticated browser

```text
ui web start 0 127.0.0.1
ui web status
```

Open the token-bearing loopback URL printed by the start command. The browser moves the bearer credential into session storage and removes it from the visible shareable state. Keep loopback binding unless your deployment deliberately enables and protects remote access.

Use the Workbench Library to open **Simulation / Campaign Preflight Center**. You can also use the command palette/search by its ID `preflight-center`.

## 44.2 Run preflight before execution

The workbench aggregates these canonical checks:

```text
ui availability explain loop start
ui assumption-monitor violations
ui solver-console status
ui fidelity-operator status
ui verification-matrix coverage
ui campaign plan
```

Resolve blocking results before execution. **Stage run** executes:

```text
ui command-stage add loop start
```

Review the persistent transaction bar and the Command Staging workbench before committing:

```text
ui command-stage status
ui command-stage commit
```

The browser is not the final authority: command execution repeats authorization/semantic/runtime validation.

## 44.3 Build an investigation using typed engineering objects

1. Open Signal Explorer or a telemetry workbench and select a signal.
2. Drag the signal chip/row or the transaction-bar engineering-selection chip into **Investigation Evidence Tray**.
3. Add a run, event, parameter, requirement, artifact, checkpoint, snapshot, or configuration in the same way.
4. Use **Compare** on an evidence item to route it to the Universal Engineering Comparison Center.
5. If an Investigation Session is active, use **Investigation** to capture that typed context into the canonical investigation/notebook authority.
6. Use **Export JSON** when you need a portable list of the browser evidence references. Exporting does not duplicate canonical artifacts.

## 44.4 Compare engineering objects

Open `comparison-center` and populate A/B by drag/drop. The dispatcher uses the appropriate existing authority:

```text
ui checkpoint-store compare <a> <b>
ui compare show <a> <b>
ui schema-evolution diff <a> <b>
```

Signals use synchronized buffered browser telemetry for visual A/B plotting; browser workspace snapshots use a structural client-state diff. Mixed object types are inspected side-by-side through their existing canonical inspectors.

## 44.5 Navigate temporal evidence

Open `multilane-timeline`. The view combines:

```text
ui time timeline
ui soe waterfall 200
ui checkpoint-store status
```

Click an event to move the canonical primary linked cursor. Use **Set A to primary** and **Set B to primary** to bracket a transient, then move to Time Travel, Scope, Run Comparison or another context-aware workbench.

## 44.6 Capture and selectively restore a workspace

Use the existing workspace-snapshot controls to capture a full snapshot. In `snapshot-diff`, compare two snapshot objects. Restore only the presentation/context subset you intend (context, units, watchlist, shell/desktop) when that is sufficient; use the canonical full workspace/simulator restore only when you actually intend to restore authoritative state.

V46 also autosaves bounded browser state and the canonical desktop. On restart, choose **Browser state** to restore client/workstation context or **Complete session** to reattach the persistent simulator session when one is available and then restore the desktop.

## 44.7 Share a deep-linked engineering state

Set the workbench, selection, selected signals and primary/A/B cursors/range you want another engineer to inspect, then use **Share**. The URL fragment can encode those values plus the workspace. It intentionally excludes the bearer token. Recipients still need an authenticated browser session that can access the target workstation/state.

## 44.8 V45 Engine Cycle & Cylinder Laboratory

Open `engine-cycle-laboratory`, choose a cylinder (or all cylinders) and one of the available domains. Drop a signal if you want to force a specific shared signal context. When a crank-angle channel is published, the native plot uses it as X; otherwise the workbench clearly falls back to simulation time.

Use the view to correlate combustion/injection/ignition/valvetrain/pressure/mechanical telemetry with the existing V45 engine authority. For quantitative model validation, continue to use the canonical model-validity, calibration and pressure-correlation services rather than reading plots as certification evidence.

## 44.9 Transmission and four-corner dynamics

Open `transmission-engineering` to group canonical telemetry into shift/supervisory, clutch/converter, hydraulic/thermal, driveline/torsion and durability/health domains. Use **System flow** and **Time travel** to move into the existing authorities.

Open `four-corner-dynamics` for FL/FR/RL/RR wheel/tire/suspension/brake/load/slip/ride/force/temperature channels. Use the canonical four-corner report, friction-circle report and 3D twin for complementary views. If the active tire backend does not expose pressure, the UI reports it as unavailable rather than inventing it.

## 44.10 Workspace recipes

Open `motorsport-recipes`. The six implemented recipes are:

```text
Formula One Engineering
Endurance / WEC
NHRA Run Engineering
HIL / ECU Integration
Powertrain Calibration
Controls Development
```

Each recipe creates/selects an ordinary `ui desktop` workspace and opens existing workbench IDs. It is a layout accelerator, not another simulation configuration or physics model.

## 44.11 Protocol trace workflow

Open `protocol-analyzer`. Use the optional filter and the underlying canonical commands as needed:

```text
ui protocol-trace show
ui protocol-trace stats
ui protocol-trace inspect <sequence>
ui protocol-trace changed-bytes <identifier>
```

Selecting a frame moves the primary linked cursor to the frame time and publishes an event context. Clear the canonical trace only when intended:

```text
ui protocol-trace clear
```

## 44.12 Control stability workflow

Use `control-stability-lab` with an existing transfer-function ID, or add/update one using numerator/denominator coefficient CSVs. Equivalent commands include:

```text
ui control-stability add <id> <numerator-csv> <denominator-csv>
ui control-stability status <id>
ui control-stability bode <id> 0.01 1000 220
ui control-stability root-locus <id> "0,0.1,0.25,0.5,1,2,5,10,25,50,100"
```

Magnitude/phase plots and the root-locus report are projections of canonical control analysis.

## 44.13 Spectrogram workflow

Select or drop a telemetry signal into `spectrogram-lab`. The browser invokes:

```text
ui spectrogram json <signal>
```

This is the structured form of the existing C++ time-frequency authority. It returns sample-rate/window/hop metadata plus bounded frequency/magnitude bins and peak-frequency history. The browser performs rendering only.

## 44.14 Identifiability workflow

```text
ui identifiability parameters <p1> <p2> ...
ui identifiability observe <sensitivity-csv> [weight]
ui identifiability status
```

The native workbench renders reported uncertainty and high-correlation structure. Treat rank deficiency, large condition number and highly correlated parameters as experiment-design/calibration warnings, not merely display conditions.

## 44.15 Estimator-consistency workflow

Open `estimator-consistency-lab`, optionally synchronize observations from live metrics, then inspect the canonical structured state:

```text
ui estimator-consistency sync
ui estimator-consistency status
ui estimator-consistency json
```

Review NIS/NEES bounds, lag/innovation behavior and rejected measurements. The workbench does not tune or reset the estimator automatically.

## 44.16 Latency-budget workflow

Enter an existing latency path ID:

```text
ui latency-budget status <id>
ui latency-budget critical <id>
```

Use the stage table and budget-utilization plot to identify where observed/p95 latency consumes the assigned budget. Keep the path definition and observations in the canonical latency authority.

## 44.17 Telemetry schema-evolution workflow

```text
ui schema-evolution list
ui schema-evolution capture <snapshot-id>
ui schema-evolution diff <left> <right>
```

Use this before/after builds or telemetry changes to identify additions, removals, unit/metadata changes and breaking compatibility.

## 44.18 Numerical-forensics workflow

Open `numerical-forensics` after a suspicious run divergence. It aggregates:

```text
ui determinism-audit status
ui numerical-trust status
ui fp-inspector status
ui metamorphic-tests status
ui replay-compare
```

Capture a determinism trial from the workbench when you need a new comparison point. Move to the established replay/checkpoint tools for state restoration or detailed divergence bisection.

## 44.19 Source-to-simulation workflow

Configure the source tree root once for the active project, then locate a selected signal:

```text
ui source-trace root <source-tree-root>
ui source-trace locate <signal>
ui provenance-graph inspect <signal> <time-s>
```

The native view renders resolved category/path/line/excerpt entries and republishes the signal into shared engineering context so requirements, parameters, source code and provenance can be investigated together.

## 44.20 Focused V46 qualification

After a normal build, use these focused checks when modifying the browser/workstation surface:

```bash
./build/<config>/engineering_ui_platform_tests
python3 tests/engineering_ui_platform_regression.py .
ctest --test-dir build/<config> -R '^completion_popup_scroll_pty$' --output-on-failure
ctest --test-dir build/<config> -R 'engineering_ui|web_gui|completion_popup|ui_.*pty' --output-on-failure
python3 tests/source_package_regression.py .
```

For the completion popup specifically, repeated qualification can be useful on contended hosts:

```bash
ctest --test-dir build/<config> -R '^completion_popup_scroll_pty$' --repeat until-fail:10 --output-on-failure
```

The hardened PTY test now waits for candidate/selection/description state transitions rather than fixed millisecond sleeps, so a slow terminal frame is not misreported as a functional completion failure. A release still requires the complete project-wide CTest/package gates, not only these focused tests.

## 45. V47 Tire, traction, and precision acceleration workflow

### 45.1 Start with the canonical detailed run

```text
ui acceleration-performance json dt=0.004 max=32 drive=rwd tc=on
```

Do not infer accuracy from the number of decimal places. First verify that the target speed/distance events are reached and that force-balance residual is near numerical zero.

### 45.2 Configure real test conditions

Example:

```text
ui acceleration-performance json   mu=1.18 prep=0.70 rubber=0.45 moisture=0.00   pressure-kpa=225 ambient-c=21 surface-c=28 rho=1.205 wind=2.0   grade-deg=0.10 drive=awd launch-rpm=3100 rollout-m=0.3048 staging-depth-m=0.0
```

Positive `wind` is headwind. `grade-deg` applies a uniform grade. For a surveyed straight, use a profile:

```text
ui acceleration-performance json profile="0:1.00:0.00,100:1.02:0.08,250:0.99:-0.04,500:1.00:0.00"
```

### 45.3 Compare true and rollout timing

Read both `zero_to_60_mph_s` and `rollout_zero_to_60_mph_s`. The latter starts after the effective rollout distance. Staging depth reduces effective rollout; it does not subtract an arbitrary fixed time.

For drag-strip work, compare `quarter_mile_trap_m_s` with `finish_speed_m_s`. The former is a finite-distance timing-system trap speed and the latter is instantaneous finish-line speed.

### 45.4 Inspect tire and traction state

```text
ui tire-traction json mu=1.25 pressure-kpa=210 launch-rpm=3600 tc=on
```

Open `tire-traction-lab` in the browser for four-corner normal load, slip, friction utilization, tread temperature, inflation pressure, carcass twist and TC target tracking. The optimal-slip target comes from the current canonical tire law.

### 45.5 Separate traction limitation from power limitation

Repeat a run with only one controlled perturbation at a time:

```text
ui acceleration-performance json mu=0.90
ui acceleration-performance json mu=1.30
ui acceleration-performance json torque-scale=0.90
ui acceleration-performance json torque-scale=1.10
```

A low-speed ET that changes strongly with μ is traction-sensitive. A higher-speed interval that responds more strongly to torque/aero than μ is power/drag-sensitive. Confirm this quantitatively with the sensitivity command instead of relying only on visual interpretation.

### 45.6 Run local sensitivity

```text
ui acceleration-performance sensitivity fraction=0.03   mu=1.15 pressure-kpa=220 drive=rwd tc=on
```

Review the normalized 0-60 and quarter-mile sensitivities for surface μ, torque, drag, rolling resistance, shift time and mass.

### 45.7 Qualify timestep convergence

```text
ui acceleration-performance convergence dt=0.004 tolerance=0.003 max=32
```

The authority executes the same case at `dt`, `dt/2`, and `dt/4`. If the fine/medium difference exceeds the requested tolerance, reduce the base `dt` or inspect a stiff launch/tire/shift transient before quoting timing differences.

### 45.8 Run performance uncertainty

```text
ui acceleration-performance monte-carlo samples=64 seed=47 sigma=0.025   mu=1.15 pressure-kpa=220 drive=rwd
```

The seed makes the ensemble reproducible. The Monte Carlo path perturbs physical/model inputs and reruns the same detailed solver; it is not a post-hoc scale factor applied to one ET.

### 45.9 Calibrate against measured acceleration

Create a CSV with at least:

```csv
time_s,speed_m_s
0.000,0.000
0.100,0.320
```

Optional columns are `distance_m` and `engine_rpm`. Then run:

```text
ui acceleration-performance calibrate ./measured_run.csv iterations=4   pressure-kpa=225 rho=1.205 wind=2.0 grade-deg=0.10
```

The fit adjusts surface μ, torque, drag, rolling and shift scales. Preserve a separate validation run; fitting and validating on the same trace overstates predictive quality.

### 45.10 Use the two browser laboratories

Open `tire-traction-lab` for launch/tire state and `acceleration-performance-lab` for ET/trap/event/force/transmission analysis. The latter also launches Sensitivity, Convergence, Monte Carlo and CSV Calibration using the current UI configuration.

### 45.11 Focused V47 qualification

```bash
./build/v47/performance_reality_platform_tests
./build/v47/engineering_ui_platform_tests
python3 tests/engineering_ui_platform_regression.py .
ctest --test-dir build/v47 -R 'performance_reality|engineering_ui|web_gui' --output-on-failure
```

For a release, follow this with the complete CTest suite and deterministic source-package regression.


## V47.1 Debug/Refactor Qualification Notes

The tire/traction/performance command surface is unchanged. The refactored implementation tightens the semantics behind it. For regression work, qualify the performance path with:

```bash
./build/full/performance_reality_platform_tests
./build/full/high_fidelity_vehicle_tests
./build/full/engineering_ui_platform_tests
ctest --test-dir build/full -R 'performance_reality|high_fidelity_vehicle|engineering_ui_platform' --output-on-failure
```

Use malformed-number checks such as `mu=1.2junk`, `sigma=nan`, and invalid staging geometry to verify that inputs are rejected rather than partially parsed. Monte Carlo `p50`/`median` is now a true sample median; the reported rank sensitivities are tie-aware Spearman coefficients. Convergence output may additionally report observed order; when refinement is not asymptotic the error estimate intentionally falls back to the conservative fine/medium difference.


## 46. V50 integrated reality workflow

### 46.1 Build and run the native self-test

```bash
cmake -S . -B build/v50 -G Ninja -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build/v50 --target v50_reality_authority_tests muzixdiagsys_v50_reality --parallel
./build/v50/muzixdiagsys_v50_reality self-test
```

Confirm the output schema is `muzixdiagsys.v50-integrated-reality.v1`, GNSS is valid for the smoke constellation, SOTIF risk is finite, and `evidence_sha256` is present.

### 46.2 Run the supplied wet-road/urban-canyon example

```bash
./build/v50/muzixdiagsys_v50_reality run examples/v50_reality_request.json > v50-result.json
```

Inspect `evap.purge_hc_kg_s`, `purge_fuel_displacement_fraction`, reactive-cylinder emissions, `bore_distortion.blowby_multiplier`, catalyst activity/deposits, per-corner `spatial_tires`, GNSS DOP/NLOS evidence and SOTIF scenario contribution. Those fields expose the causal chain rather than only the final vehicle metric.

### 46.3 Use Python without duplicating physics

```bash
PYTHONPATH=python python3 - <<'PYCODE'
from muzixdiag.v50 import V50RealityClient, default_request
r = default_request()
r["steps"] = 20
r["input"]["tire_environment"]["water_depth_m"] = 0.003
client = V50RealityClient("./build/v50/muzixdiagsys_v50_reality")
state = client.run(r, timeout_s=30.0)
print(state["mean_tire_grip_multiplier"], state["evidence_sha256"])
PYCODE
```

### 46.4 Qualify the implementation

```bash
./build/v50/v50_reality_authority_tests
PYTHONPATH=python python3 tests/v50_python_api_tests.py . ./build/v50/muzixdiagsys_v50_reality
ctest --test-dir build/v50 -R 'v50_' --output-on-failure
```

For research conclusions, also perform timestep/grid refinement and compare against measured engine, emissions, wet-tire and navigation data. A passing software regression establishes implementation integrity, not empirical model validity.

## 47. V51 scientific credibility and adaptive-fidelity workflow

### 47.1 Build the focused V51 targets

```bash
cmake -S . -B build/v51 -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build/v51 --target v51_scientific_reality_tests muzixdiagsys_v51_reality --parallel
```

### 47.2 Run numerical verification before interpreting higher fidelity

```bash
./build/v51/muzixdiagsys_v51_reality verify examples/v51_reality_request.json > v51-verification.json
```

Inspect observed spatial/temporal order, manufactured-solution L2 error and normalized mass/energy residuals. A higher-order/adaptive configuration should not be accepted merely because it runs; it must satisfy the configured V51-A numerical-credibility gates.

### 47.3 Run the integrated authority and inspect fidelity evidence

```bash
./build/v51/muzixdiagsys_v51_reality self-test
./build/v51/muzixdiagsys_v51_reality run examples/v51_reality_request.json > v51-state.json
```

Read `fidelity` together with inherited V50 chamber, catalyst, tire, navigation and SOTIF evidence. Promotion to detailed chemistry/spray or external CFD is policy-driven and does not replace the canonical V50 plant.

### 47.4 Use a persistent campaign session

```python
from muzixdiag.v51 import V51RealityClient, default_request
client = V51RealityClient('./build/v51/muzixdiagsys_v51_reality')
r = default_request()
with client.persistent_session() as s:
    s.configure(r)
    first = s.run({**r, 'steps': 2})
    s.checkpoint('baseline')
    second = s.run({**r, 'steps': 4})
    s.restore('baseline')
```

Persistent operation removes process-start overhead while retaining C++ numerical ownership. Use checkpoints to branch campaign histories rather than reconstructing history-dependent catalyst/tire/SOTIF/learning state manually.

### 47.5 Store large scientific fields outside control JSON

Use the service `field-store` command or `V51ScientificFieldStore` to persist chamber/tire arrays to the canonical scientific-data layer. Prefer Zarr/HDF5/NetCDF datasets for large fields; leave compact JSON for commands, summaries and evidence references. Enable round-trip verification for release or archive artifacts.

### 47.6 Validate calibration rather than only fitting it

Run hierarchical calibration with distinct groups for vehicle, engine family, tire construction, sensor or test-session effects as appropriate. Check R-hat and effective sample size, then evaluate posterior-mean or posterior-predictive output against held-out measured data through `core::ValidationFramework`. Do not count the calibration dataset as independent validation evidence.

### 47.7 Qualify the complete V51 release surface

```bash
./build/v51/v51_scientific_reality_tests ./build/v51/v51_scientific_reality_unit_tests_data
PYTHONPATH=python python3 tests/v51_python_api_tests.py . ./build/v51/muzixdiagsys_v51_reality
python3 tests/v51_scientific_reality_source_regression.py .
tools/generate_user_manual_pdf.sh
python3 tests/v51_release_artifact_certification.py . ./build/v51/muzixdiagsys_v51_reality
ctest --test-dir build/v51 -R 'v51_' --output-on-failure
```

Finish release qualification with the established source-package, duplicate-implementation, consolidation-architecture, documentation-consistency and user-manual regressions. Preserve the resulting ZIP SHA-256 with the release evidence.


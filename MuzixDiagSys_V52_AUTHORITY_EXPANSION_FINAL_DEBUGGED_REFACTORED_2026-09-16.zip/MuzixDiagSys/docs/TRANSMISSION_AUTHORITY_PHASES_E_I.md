# Transmission Authority Phases E-I

## Prioritized gearbox implementation, validation, telemetry, and API specification

**Release scope:** 2026-09-01 gearbox depth expansion  
**Canonical implementation:** `aesim::high_fidelity::TransmissionAuthoritySystem` and `aesim::high_fidelity::FullTransmissionSystem`  
**Compatibility basis:** the established Phase A-D transmission authority remains authoritative and is extended in place.

## 1. Architectural contract

Phases E-I deepen the existing gearbox model without introducing a second transmission solver, second shift scheduler, second hydraulic valve body, second durability authority, or duplicate DCT/CVT/planetary implementation. The established Phase A-D authorities continue to provide gear contact/LTCA, synchronizer and dog mechanics, structural torsion, clutch tribology, torque-converter hydrodynamics, planetary constraints, DCT/CVT physics, lubrication, electrohydraulic mechatronics, adaptive TCM behavior, diagnostics, shift quality, fault injection, calibration/optimization, durability, NVH, and housing acoustics.

The expansion adds state and coupling where the prior implementation was intentionally reduced:

1. **Phase E — common-core physics:** stateful multi-shaft/per-gear dynamics, thermal-network state, and one clutch-to-clutch shift-phase authority.
2. **Phase F — manual and hydraulic depth:** resolved driver/pedal/selector/synchronizer behavior and deeper coupling of the existing valve-body plant to degradation/fault states.
3. **Phase G — supervisory control:** predictive TCU decisions, torque arbitration, adaptive pressure control, shift inhibition, diagnostics, and limp-home behavior.
4. **Phase H — lifecycle and optimization:** lubricant chemistry/debris, component RUL, rebuild genealogy, servicing, and durability-aware shift calibration.
5. **Phase I — specialized topologies:** DCT, AMT, sequential/dog, motorsport sequential, planetary automatic, CVT/IVT, planetary hybrid, multispeed e-axle, and heavy-truck range/splitter behavior reuse the common physical authorities.

`FullTransmissionSystem` remains the physical plant integration point. `TransmissionAuthoritySystem` computes supervisory, durability, topology, and shift-authority state; the full plant consumes those states when calculating pump flow, solenoid force, clutch pressure, transmitted torque, gear handoff, thermal response, and architecture behavior.

## 2. Phase E — common-core physics

### 2.1 Per-shaft/per-gear multi-body dynamics

`MultiBodyGeartrainState` resolves independent rotational state for the input, intermediate/countershaft, output, and coupled driveline nodes rather than collapsing the gearbox to a single equivalent inertia. It stores shaft angle, speed, acceleration, inter-shaft torque, total torsional energy, mesh loss, output reaction torque, and torque oscillation.

Every installed ratio receives a `GearMeshDynamicElementState` with:

- relative mesh twist and relative speed;
- dynamic backlash position and engagement state;
- time-varying mesh stiffness;
- transmitted mesh torque;
- contact and root stress;
- accumulated mesh/contact damage; and
- mesh loss power.

The implementation deliberately reuses the existing contact/LTCA results and durability authority. The new per-mesh states therefore add transient dynamic ownership without creating a competing tooth-contact model.

### 2.2 Transmission lubrication and thermal networks

The established lubrication network remains the hydraulic/lubricant flow authority. Phase E adds an eight-node thermal model across:

1. oil,
2. transmission case,
3. input shaft,
4. gearset,
5. primary clutch,
6. secondary clutch,
7. valve body/mechatronics,
8. output shaft.

Heat sources include gear-mesh loss, clutch slip, valve-body/hydraulic loss, and lubricant/churning loss. Conductive/convective paths exchange heat among components, oil, and ambient. The state exposes component temperatures, hottest-component temperature, and total thermal energy.

Phase H oil-condition state feeds back into the existing hydraulic plant through the viscosity multiplier. Low-oil and pump faults reduce physical pump delivery rather than merely setting a DTC.

### 2.3 True clutch-to-clutch automatic shift phases

`ClutchToClutchShiftState` is the single automatic shift-phase authority for AMT/DCT/conventional automatic/planetary automatic/hybrid/e-axle paths that require coordinated friction-element handoff. The phase machine is:

`Idle -> Fill -> TorqueTransfer -> Inertia -> Complete`, with `Fault` for invalid/degraded execution.

The state provides:

- off-going and on-coming clutch commands;
- target/apply pressure;
- slip target;
- tie-up fraction;
- accumulated slip energy;
- elapsed phase time; and
- explicit gear-handoff completion.

`FullTransmissionSystem` consumes these commands directly in the existing physical clutch hydraulic circuits. It does not maintain a parallel automatic shift ramp.

## 3. Phase F — manual-specific physics and automatic hydraulics

### 3.1 Resolved manual driver and clutch interface

`ManualDriverShiftState` resolves the human/mechanical shift chain when the additive driver inputs are supplied. The state includes:

- clutch-pedal position and velocity;
- selector position/velocity and driver force;
- blocker-ring force;
- synchronization progress;
- engine/input-shaft rev-match error;
- requested throttle blip;
- double-clutch state;
- flat-shift state;
- gear-grind energy;
- missed-shift probability; and
- final engagement permission.

This state is coupled to the existing synchronizer/dog authority, so cone synchronization and dog engagement are not duplicated.

### 3.2 Backward-compatible manual command contract

The historical low-level API is preserved. If `clutch_pedal_position < 0`, no explicit human pedal model is requested and `clutch_command` retains its legacy meaning. A manual shift requested while `clutch_command <= 0.10` therefore retains the prior direct disengaged-clutch shift contract.

When `clutch_pedal_position >= 0`, the new resolved pedal/selector/blocker/synchronizer path determines engagement permission. This separation prevents the new driver model from silently changing legacy automation, while allowing driver-training and race-shift studies to use the higher-fidelity path.

### 3.3 Detailed shift behaviors

The resolved manual model supports:

- ordinary H-pattern synchronization;
- double-clutch operation;
- throttle-blip/rev-match demand;
- flat/no-lift shift torque intervention;
- dog engagement and clash exposure;
- selector force and blocker load;
- missed-shift probability; and
- grind energy feeding diagnostics/lifecycle severity.

Sequential and motorsport dog boxes reuse the same synchronizer/dog state. Motorsport ignition/torque cut state derives from actual shift/dog/flat-shift conditions rather than from the automatic clutch-to-clutch timer.

### 3.4 Valve body, solenoids, and hydraulic fault coupling

The existing valve-body/mechatronics system remains authoritative. Phase F deepens its physical coupling:

- lubricant condition changes hydraulic viscosity;
- pump degradation and low oil scale actual pump flow;
- clutch-seal faults increase clutch-circuit leakage;
- shift-actuator faults scale solenoid force;
- clutch-to-clutch target pressure enters line-pressure demand;
- adaptive/Tcu pressure trims alter commanded pressure; and
- physical circuit pressure remains the quantity that governs clutch torque transfer.

No idealized pressure-only bypass is added.

## 4. Phase G — TCU closed-loop and degraded operation

### 4.1 Predictive gear supervision

The existing multidomain shift optimizer remains the gear-cost authority. `TcuSupervisoryState` adds supervisory constraints and predictions using available context including:

- current and predicted road grade;
- driver torque/load demand;
- trailer mass;
- lateral acceleration;
- driven-wheel slip;
- braking demand;
- transmission temperature; and
- battery SOC for electrified torque fill.

Explicit caller-requested gears remain respected unless the existing configuration authorizes automatic gear ownership.

### 4.2 Shift inhibition and torque arbitration

The TCU can inhibit or defer a shift under high lateral acceleration, excessive wheel slip, severe thermal derate, or invalid sensor/actuator conditions. During an allowed shift it produces:

- commanded and predictive gear;
- engine torque request/reduction;
- e-motor torque-fill request;
- line-pressure trim; and
- limp-home state/gear when required.

`FullTransmissionSystem` applies engine torque reduction and motor fill to the same physical input-torque path. The commands are not telemetry-only.

### 4.3 Adaptive pressure and clutch learning

The existing adaptive TCM/clutch learning authority is retained. New supervisory pressure correction uses the existing valve-body pressure error and learned terms, avoiding a second adaptive table. Durability-aware optimum pressure/shift-time/overlap values from Phase H are additional bounded calibration recommendations rather than a replacement learning controller.

### 4.4 Fault diagnostics and limp-home

Phase G extends deterministic fault injection with:

- pump failure/degradation;
- clutch-seal leakage;
- shift-actuator degradation;
- range-actuator degradation;
- low oil level; and
- speed-sensor dropout.

These faults change physical model parameters before diagnostics are evaluated. The TCU can enter a deterministic fixed-gear limp mode under severe hydraulic/sensor/oil failures. Diagnostic state adds representative pressure/speed/oil/grind evidence while retaining the established transmission diagnostic authority.

## 5. Phase H — durability, oil condition, RUL, genealogy, optimization

### 5.1 Lubricant condition and debris

`LubricantConditionState` tracks:

- oxidation fraction;
- total acid number (TAN);
- water fraction;
- ferrous debris mass;
- friction-material debris mass;
- filter loading;
- viscosity multiplier; and
- remaining oil-life fraction.

Oxidation evolves with thermal exposure; debris is tied to the established mechanical/clutch damage quantities. Filter loading and water/oxidation feed the viscosity multiplier, which then alters the physical hydraulic plant.

`service_lubricant()` resets serviceable lubricant/debris/filter state while recording the service in lifecycle genealogy. It does not erase component damage.

### 5.2 Component RUL and lifecycle

`TransmissionLifecycleState` tracks operating hours, total shifts, severe shifts, rebuild count, limiting component, component records, and genealogy events. The initial component registry includes:

- main gearset,
- bearing pack,
- primary clutch,
- secondary clutch,
- synchronizer pack,
- hydraulic/mechatronic assembly.

Component damage is derived from the established durability authority plus the added per-gear mesh/contact accumulation. Each component reports damage, RUL, generation, and service-due state.

`rebuild_component(component_id)` increments component generation and global rebuild count, restores the serviceable damage state appropriate to that component, and appends a genealogy event. Predecessor history is retained.

### 5.3 Durability-aware calibration optimizer

`DurabilityCalibrationOptimizerState` is produced by a deterministic bounded search over:

- line/apply pressure,
- shift time,
- clutch overlap.

The objective combines shift-quality, thermal, durability, and efficiency terms while respecting configured bounds and damage/temperature constraints. It reports solution status, evaluation count, objective value, and selected calibration values.

This is an outer calibration/design aid. It does not replace the existing adaptive TCM or multidomain shift optimizer.

## 6. Phase I — specialized transmission architectures

All specialized architectures reuse common shafts, gears, clutch/tribology, hydraulic, TCU, lubrication, thermal, diagnostics, and durability state wherever physically applicable.

### 6.1 Dual-clutch transmission

The established physical DCT preselection and clutch states remain authoritative. Phase E clutch-to-clutch coordination provides the phase/pressure handoff, and Phase G supplies supervisory torque intervention. DCT efficiency accounts for the existing tie-up state.

### 6.2 Automated manual transmission

AMT uses the manual gear/synchronizer mechanics with a modeled clutch actuator response. It consumes the common clutch-to-clutch phase when automated torque transfer requires it.

### 6.3 Sequential dog and motorsport sequential

`SequentialDog` and `MotorsportSequential` use the common synchronizer/dog mechanics plus actuator-position state. Motorsport operation adds torque-cut state and high-efficiency race-box behavior while retaining common durability and grind/missed-shift evidence.

### 6.4 Planetary automatic

`PlanetaryAutomatic` reuses the existing general planetary constraint solver and torque-converter/lockup model. Clutch-to-clutch off-going/on-coming commands are exposed in specialized state and drive the existing physical hydraulic circuits.

### 6.5 CVT/IVT

The existing CVT/IVT variator remains canonical. Phase I adds belt/chain temperature and fatigue accumulation driven by variator slip power and cooling, with fatigue reducing architecture efficiency within configured limits.

### 6.6 Planetary hybrid

The existing planetary network is reused with Phase G motor torque fill. Specialized state reports bounded hybrid torque fill and planetary-network efficiency.

### 6.7 EV multispeed/e-axle

`MultiSpeedEaxle` adds motor synchronization-error state and rate-limited synchronization, while using common gear and shift authorities. Electrified torque fill remains bounded by supervisory SOC and configured torque limits.

### 6.8 Heavy-truck range/splitter

`HeavyTruckRangeSplitter` adds pneumatic range/split state with finite pressure dynamics, range-actuator fault scaling, high/low range state, and split state. The pneumatic time constant means range engagement is not instantaneous; validation must simulate long enough for pressure thresholds to be crossed.

## 7. Required API and telemetry changes

### 7.1 Architecture enumeration

`TransmissionArchitecture` retains all previous values and adds:

- `PlanetaryAutomatic`,
- `SequentialDog`,
- `HeavyTruckRangeSplitter`,
- `MotorsportSequential`.

String parsing accepts the documented aliases in `ecosystem_integrated.cpp`.

### 7.2 Additive transmission inputs

The new optional context includes:

- explicit clutch pedal position;
- driver shift force/aggressiveness;
- throttle blip;
- double-clutch and flat-shift commands;
- current/predicted grade;
- lateral and demanded longitudinal acceleration;
- driven-wheel slip;
- braking fraction;
- battery SOC;
- trailer mass;
- truck range/split commands; and
- torque-request validity.

Defaults preserve the earlier calling contract.

### 7.3 State and report surfaces

`TransmissionAuthorityState` now includes:

- `multibody`,
- `thermal_network`,
- `clutch_to_clutch`,
- `manual_driver`,
- `tcu_supervisor`,
- `lubricant_condition`,
- `lifecycle`,
- `durability_optimizer`,
- `specialized`.

The text report exposes these under `phaseE.*` through `phaseI.*`. `FullTransmissionSystem` additionally reports the TCU engine torque request, motor torque fill, and physically applied input torque alongside its existing ratio, output torque, hydraulic, thermal, clutch, converter, planetary, DCT/CVT, loss, and durability state.

### 7.4 Service APIs

```cpp
bool service_lubricant(double water_fraction = 0.0002);
bool rebuild_component(const std::string& component_id);
const TransmissionLifecycleState& lifecycle() const noexcept;
```

These are available on both the authority and full transmission plant facade.

## 8. Validation specification

### 8.1 Common-core validation

The dedicated `transmission_authority_tests` must demonstrate:

- four resolved shaft states and one dynamic mesh state per installed ratio;
- finite torsional energy/reaction torque/mesh losses;
- thermal-network evolution and bounded hottest-component state;
- automatic `Fill -> TorqueTransfer -> Inertia -> Complete` progression;
- a completed physical gear handoff and return to idle.

### 8.2 Manual validation

Required cases include:

- explicit pedal and selector-force response;
- synchronization progress and blocker force;
- rev-match/throttle-blip behavior;
- double-clutch behavior;
- flat-shift torque intervention;
- grind-energy and missed-shift evidence; and
- preservation of the legacy disengaged-clutch shift API.

### 8.3 Automatic/TCU validation

Required cases include:

- corner/wheel-slip shift inhibition;
- predictive grade/load state;
- motor torque fill;
- pressure adaptation;
- deterministic pump, leakage, actuator, low-oil, and sensor faults;
- limp-home gear selection; and
- full-plant consumption of supervisory torque and pressure commands.

### 8.4 Durability validation

Required cases include:

- oxidation/TAN/viscosity evolution;
- debris/filter accumulation;
- component RUL/limiting-component calculation;
- lubricant service without component-history erasure;
- component rebuild generation/genealogy; and
- deterministic bounded durability-optimizer output.

### 8.5 Specialized architecture validation

The test matrix must execute DCT, AMT, torque-converter automatic, planetary automatic, CVT, planetary hybrid, multispeed e-axle, heavy-truck range/splitter, sequential dog, and motorsport sequential configurations. The test should check topology-specific state while also confirming shared authority state remains finite and valid.

### 8.6 Release qualification

Focused qualification is:

```bash
cmake -S . -B build/gearbox-validation -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build/gearbox-validation --target \
  transmission_authority_tests ecosystem_tests accuracy_depth_complete_tests
./build/gearbox-validation/transmission_authority_tests
./build/gearbox-validation/ecosystem_tests
./build/gearbox-validation/accuracy_depth_complete_tests
python3 tests/user_manual_regression.py .
```

A release package must additionally complete the project-wide CTest gate and deterministic source-package regression. Focused transmission success is not a substitute for package-wide qualification.

## 9. Engineering interpretation boundaries

The models are reduced-order engineering digital twins. Gear contact stress, oil chemistry, RUL, synchronizer grind probability, thermal state, and optimizer recommendations require correlation against appropriate test data before production decisions. Simulated DTCs, limp modes, shift quality, and durability margins are engineering evidence, not homologation or warranty certification.

## V47 performance-consumer integration note

The V47 detailed acceleration authority consumes `TransmissionAuthoritySystem` converter, clutch-capacity, shift-transfer, gear and torque-management states directly. It does not implement a second launch clutch, torque converter or shift-state machine. Consequently, future changes to transmission transient physics should be made in the canonical transmission authority and verified through both transmission tests and V47 performance regression.

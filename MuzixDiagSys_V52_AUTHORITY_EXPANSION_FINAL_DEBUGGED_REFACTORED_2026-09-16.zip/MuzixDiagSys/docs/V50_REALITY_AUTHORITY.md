# V50 Integrated Reality Authority

## Purpose

V50 deepens four existing domains instead of creating replacement vehicle authorities. The implementation is additive and composes the canonical `EngineResearchDigitalTwin`, `TireRoadWeatherLaboratory`, MLOps drift detector, provenance/document stack, and existing vehicle/research libraries.

The implementation is centered on:

- `include/aesim/advanced/v50_reality_authority.hpp`
- `src/advanced/v50_reality_authority.cpp`
- `tools/v50_reality_main.cpp`
- `python/muzixdiag/v50.py`
- `tests/v50_reality_authority_tests.cpp`
- `tests/v50_python_api_tests.py`

The integrated schema is `muzixdiagsys.v50-integrated-reality.v1`.

## Non-duplication boundary

V50 does **not** replace the canonical engine gas-exchange, crank-angle combustion, fuel-system, ring-pack, aftertreatment, tire force law, vehicle-dynamics, SOTIF falsification, MLOps drift, or provenance implementations. The V50 authorities are refinement/correction layers:

1. the 3-D chamber solver consumes canonical engine state and resolves spatial mixture/temperature/velocity/chemistry fields;
2. bore distortion consumes canonical thermal/structural state and the resolved chamber pressure field;
3. catalyst lifetime physics degrades the canonical aftertreatment conversion rather than recomputing the base catalyst;
4. the spatial tire solver consumes the canonical tire step and applies footprint-resolved wet/wear correction to its forces;
5. continual learning calls the established MLOps drift detector and owns only replay/EWC adaptation and governance;
6. every result uses the existing canonical JSON and SHA-256 provenance mechanism.

## 1. Three-dimensional reactive cylinder authority

`ReactiveCylinder3DAuthority` is a structured finite-volume arbitrary-Lagrangian/Eulerian chamber solver. The cylinder bore defines a Cartesian embedded-boundary mask and piston motion changes the axial cell height with crank angle.

For a transported scalar `phi`, V50 applies the conservative transport form represented numerically by upwind advection and central diffusion:

```text
d(phi)/dt + u grad(phi) = D laplacian(phi) + S(phi)
```

The velocity closure contains swirl, tumble and piston-driven squish. Chemical source terms resolve fuel consumption, oxygen consumption, CO formation/oxidation, thermal NO production, soot formation/oxidation, CO2, water, progress variable and heat release. Wall cells exchange heat with the canonical liner/coolant thermal state.

Fuel injection is a conservative finite-volume mass source. Adding fuel dilutes the existing species fractions and increases local mixture density rather than merely incrementing a mass fraction. The authority reports mass and energy residuals on every step.

The low-Mach mean pressure is anchored to the canonical engine pressure history. This preserves one gas-exchange/cranktrain authority while permitting the V50 field to resolve hot/rich pockets and provide bounded engine-out emissions corrections.

Important output includes:

- mean and maximum cylinder temperature;
- mean pressure and maximum velocity;
- burned mass fraction and heat-release rate;
- wall heat-transfer rate;
- NOx, soot and CO correction rates;
- mass and energy residuals;
- optional complete cell field;
- SHA-256 evidence digest.

## 2. Thermoelastic bore-distortion authority

`CylinderBoreDistortionAuthority` resolves axial/circumferential liner displacement. It combines:

- pressure-induced hoop strain;
- liner thermal expansion;
- deck and skirt constraints;
- localized head-bolt preload deformation;
- second- and fourth-order circumferential distortion harmonics.

The field is reduced to physically useful coupling quantities: peak-to-peak ovality, minimum running clearance, ring conformance, blow-by multiplier and ring-friction multiplier. V50 uses the blow-by multiplier to add a distortion-dependent engine-out HC penalty while leaving canonical ring-pack dynamics intact.

## 3. EVAP/ORVR fuel-vapor lifecycle

`EvapOrvrAuthority` provides a mass-conservative liquid/vapor/carbon-bed model. The inventory is partitioned into tank liquid, ullage vapor, carbon-canister loading and cumulative atmospheric discharge.

The implementation includes:

- Antoine vapor pressure;
- conservative evaporation and condensation;
- refueling vapor displacement;
- activated-carbon Langmuir equilibrium loading;
- finite adsorption/desorption kinetics;
- ORVR capture efficiency;
- pressure breathing/relief;
- manifold-vacuum purge of both tank vapor and the carbon bed;
- adsorption/desorption thermal effects;
- canister breakthrough and cumulative atmospheric HC;
- an explicit mass-balance residual.

In the integrated authority, purge hydrocarbons displace commanded injector fuel and perturb effective lambda. This creates the causal path:

```text
fuel volatility/refueling -> tank vapor -> canister -> purge -> commanded fueling/lambda -> combustion
```

## 4. Catalyst deposits and lifetime chemistry

`CatalystLifecycleAuthority` overlays long-duration degradation on the existing aftertreatment state. It models:

- DPF ash accumulation from oil consumption;
- sulfur storage and high-temperature desulfation;
- urea/DEF deposit accumulation in the deposit-temperature window;
- thermal decomposition of deposits;
- hydrothermal activity loss;
- ash/deposit backpressure;
- cumulative aged NOx and HC output.

The canonical tailpipe conversion is retained as the fresh/calibrated baseline. V50 computes the removed fraction between canonical engine-out and canonical tailpipe emissions and attenuates that conversion according to catalyst activity. Aging can therefore reduce conversion, but cannot spuriously improve it.

The complete emissions causality is:

```text
EVAP purge
  -> injected-fuel displacement / lambda
  -> canonical engine combustion
  -> resolved 3-D chemistry correction
  -> bore-distortion blow-by HC correction
  -> canonical aftertreatment conversion
  -> ash / sulfur / urea / hydrothermal aging
  -> aged tailpipe emissions and backpressure
```

## 5. Spatial tire authority

`SpatialTireAuthority` discretizes the contact patch into longitudinal/lateral cells. Every cell contains:

- tread depth;
- tread temperature;
- contact pressure;
- water-film depth;
- cumulative wear depth;
- local friction multiplier.

The pressure distribution is normalized to the requested normal load. Longitudinal groove channels and transverse sipes provide drainage capacity that continuously collapses as tread depth approaches the legal minimum. Water-film pressure/speed effects reduce local friction and create a footprint-level hydroplaning fraction.

Wear follows a load/slip-work form related to Archard wear. The resolved morphology yields center/shoulder depth differences and heel-toe index rather than a single scalar wear state. Tread temperature includes frictional heating, road/air cooling and neighbor conduction.

The existing `TireRoadWeatherLaboratory` remains the canonical constitutive tire authority. V50 multiplies its force/moment result by the spatially resolved grip state and then carries mean tread depth/temperature back into the canonical tire state for the next step. Thus:

```text
tread geometry -> drainage/water film -> local grip -> canonical force correction -> slip work -> wear -> new geometry
```

The corrected longitudinal/lateral forces and aligning moment are explicit outputs for the existing higher-level vehicle-dynamics authorities.

## 6. GNSS urban-canyon and IMU reality layer

`NavigationRealityAuthority` generates deterministic-reproducible satellite geometry and then applies structured navigation errors rather than a single Gaussian position perturbation.

Pseudorange error contains receiver clock, ionosphere, troposphere, NLOS reflection/multipath and elevation-dependent stochastic terms. Urban-canyon sectors define azimuth ranges, elevation masks and reflected excess path length. A weighted four-state ENU/clock least-squares solve produces position error and HDOP/VDOP/PDOP.

The IMU model uses white noise density and Gauss-Markov bias states parameterized by bias instability/correlation time, with accelerometer and gyro temperature coefficients. Randomness is seeded and deterministic for repeatable qualification.

An unavailable GNSS solution is represented by `valid=false` and finite zero DOP values so canonical JSON/evidence generation never contains NaN or infinity.

## 7. Exposure-weighted SOTIF posterior

`SotifExposureRiskAuthority` converts scenario-test evidence into fleet-relevant risk.

Scenario exposure proportions use a Dirichlet posterior. Failure, harmful-outcome and uncontrolled-outcome rates use Beta posteriors. Deterministic Monte Carlo propagates these distributions into per-operating-hour and annualized risk credible intervals.

Conceptually, each sample evaluates:

```text
risk = sum_s exposure(s) * failure(s) * harm(s) * uncontrolled(s) * severity(s)
```

The result reports posterior means, 2.5/97.5 percentiles, scenario contributions and the dominant scenario. This separates “a scenario is easy to break” from “the scenario materially contributes to fleet risk.”

## 8. Governed continual learning

`GovernedContinualLearningAuthority` reuses `VehicleCloudMlopsPlatform::detect_drift` and adds adaptation governance. It implements:

- drift-triggered or explicitly requested adaptation;
- replay-gradient regularization;
- Fisher-diagonal elastic-weight-consolidation penalty;
- bounded per-update parameter steps;
- shadow-candidate state;
- minimum validation sample gate;
- accuracy gate;
- safety-violation gate;
- catastrophic-forgetting/replay-loss gate;
- promotion and deterministic rollback accounting.

A candidate never silently becomes the champion. Promotion is explicit and evidence-bearing.

## 9. Integrated V50 step order

`V50RealityAuthority::step()` is intentionally ordered to preserve causality:

1. update EVAP/ORVR and determine purge HC;
2. displace injector fuel and adjust effective lambda;
3. advance the canonical engine;
4. advance the spatial 3-D reactive chamber;
5. evaluate thermoelastic bore distortion;
6. blend bounded resolved-chemistry corrections into canonical engine-out emissions;
7. add bore-distortion/blow-by HC correction;
8. update catalyst lifetime/deposits and aged tailpipe output;
9. step canonical tires and then spatial tread/water/wear refinement per corner;
10. feed spatial mean tread depth/temperature back to each canonical tire state;
11. advance navigation reality;
12. evaluate the SOTIF exposure posterior when evidence is supplied;
13. execute governed continual-learning adaptation/gating;
14. seal the integrated state with a SHA-256 evidence digest.

## 10. C++ usage

```cpp
#include "aesim/advanced/v50_reality_authority.hpp"

using namespace aesim::advanced;

V50RealityConfiguration cfg;
cfg.reactive_cylinder.nx = 10;
cfg.reactive_cylinder.ny = 10;
cfg.reactive_cylinder.nz = 8;
cfg.navigation.satellites = 24;

V50RealityAuthority v50(cfg);
V50RealityInput in;
in.engine.rpm = 3000.0;
in.engine.load = 0.70;
in.evap.purge_air_flow_kg_s = 0.012;
for (auto& road : in.tire_environment) road.water_depth_m = 0.002;
for (auto& op : in.tire_operating_point) {
    op.normal_load_n = 4000.0;
    op.hub_longitudinal_speed_m_s = 27.0;
    op.wheel_angular_speed_rad_s = 91.0;
}

const auto& state = v50.step(in, 0.001);
```

## 11. Native JSON CLI

Build tools and run the deterministic smoke scenario:

```bash
cmake -S . -B build/v50 -G Ninja -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build/v50 --target muzixdiagsys_v50_reality v50_reality_authority_tests --parallel
./build/v50/muzixdiagsys_v50_reality self-test
```

Run a request file:

```bash
./build/v50/muzixdiagsys_v50_reality run examples/v50_reality_request.json
```

The request accepts `configuration`, `input`, `dt_s`, `steps`, and `include_fields`. `include_fields=true` includes the resolved cylinder/tire fields and GNSS observations; keep it false for compact campaign outputs.

## 12. Python usage

The Python module is a process-isolated wrapper around the canonical C++ implementation:

```python
from muzixdiag.v50 import V50RealityClient, default_request

client = V50RealityClient("./build/v50/muzixdiagsys_v50_reality")
request = default_request()
request["steps"] = 100
request["input"]["engine"]["rpm"] = 3200.0
request["input"]["tire_environment"]["water_depth_m"] = 0.0025
result = client.run(request, timeout_s=30.0)
print(result["evidence_sha256"])
```

The Python API rejects NaN/Inf before invocation, writes request files with private POSIX permissions, validates the returned schema and requires a 64-character evidence digest.

## 13. Qualification

Focused qualification:

```bash
cmake -S . -B build/v50 -G Ninja -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build/v50 --target v50_reality_authority_tests muzixdiagsys_v50_reality --parallel
./build/v50/v50_reality_authority_tests
PYTHONPATH=python python3 tests/v50_python_api_tests.py . ./build/v50/muzixdiagsys_v50_reality
ctest --test-dir build/v50 -R 'v50_' --output-on-failure
```

The C++ regression exercises each V50 authority independently and then the complete integrated chain. The Python regression executes the native tool, verifies evidence/schema behavior and rejects non-finite input.

## Interpretation limits

The V50 3-D chamber solver is a native structured finite-volume reference model for system-level research and cross-domain causality. It is not claimed to be a replacement for a validated commercial moving-mesh DNS/LES/RANS engine CFD package with detailed chemical mechanisms and experimentally correlated spray submodels. Likewise, GNSS urban-canyon geometry is a deterministic statistical/ray-path abstraction rather than a full electromagnetic city ray tracer. These limits are deliberate: V50 increases internal physical resolution while preserving tractable integrated simulation and one canonical authority per domain.

# V37 ECU / Diagnostics / SocketCAN Authority Platform

V37 extends the canonical MuzixDiagSys diagnostic, ECM/OBD, SocketCAN, XCP/A2L, AUTOSAR assurance, and industrial data authorities. It does not replace or fork those services.

## Block A — Diagnostic protocol authority

The canonical `UdsServer` now supports per-tester state, S3 expiration, P2/P2-star timing data, services 0x24/0x29/0x2A/0x2C/0x83/0x84/0x86/0x87, secure HMAC-authenticated diagnostic envelopes, dynamic DIDs, periodic data, response-on-event, file transfer, and richer UDS DTC records. `AutosarDcmDemAuthority` adds operation-cycle event debouncing, confirmation/healing/aging, FDCs, snapshots, extended data, and synchronization into the existing UDS memory.

## Block B — Regulatory OBD

`J1978ScanTool` operates the existing legacy J1979, OBDonUDS J1979-2, and ZEVonUDS J1979-3 responders. `RegulatoryObdAuthority` executes deterministic J1699/5-oriented pre-compliance campaigns and exposes per-monitor IUPR numerator, denominator, and general-denominator lifecycle state from `EcmObdPlatform`.

## Block C — Linux CAN authority

Linux builds provide CAN_RAW error filters and error-frame decoding, software/hardware timestamp ancillary data, CAN_BCM cyclic transmission and receive supervision, kernel CAN_J1939 datagrams, rtnetlink interface inspection, controlled `ip link` configuration, vcan/vxcan laboratory management, and deterministic replay through the existing `CanTransport` abstraction. Live interface mutation requires the host privileges normally required by Linux networking.

## Block D — Engineering data authority

`OdxPdxRuntime` imports ODX documents and PDX ZIP containers, resolves diagnostic services/DOPs, and performs request encoding and physical response decoding. `OtxRuntime` executes variables, arithmetic, branches, loops, assertions, delays, UDS and VirtualRte actions. The semantic registry generates/validates DBC, A2L and ODX-facing representations. `XcpCalibrationAuthority` composes the canonical XCP server for CAN CTO, event triggering, STIM memory writes and A2L consistency checks. `AutomotiveTrace` round-trips candump, Vector ASC, PCAPNG CAN_SOCKETCAN and CSV traces.

## Qualification

Build and run `ecu_diagnostics_socketcan_v37_unit_tests` and `muzixdiagsys_ecu_diagnostics_v37 self-test`. The source regression enforces the additive architecture and rejects duplicate canonical UDS, XCP, ECM, or DiagnosticService declarations.


## Architecture and non-duplication contract

V37 is linked as `aesim_ecu_diagnostics_socketcan_v37` and is also transitively available through `aesim_advanced`. The canonical services remain:

- `UdsServer` / `DiagnosticService` for UDS and ECU routing;
- `EcmObdPlatform` for OBD monitor/DTC/readiness plant coupling;
- `SocketCanTransport` and `CanTransport` for the established transport abstraction;
- `XcpServer` and `SignalRegistry` for calibration/acquisition state; and
- `VirtualRte` for virtual ECU/application interaction.

The source regression rejects duplicate declarations of these authorities in the V37 public header/implementation.

## Diagnostic timing and tester isolation

Every tester is identified by ECU plus tester key. Session, S3, P2/P2-star configuration, security/authentication, transfer, dynamic DID, periodic-data, event, and secured-envelope state are isolated to that client context. Expiration returns the client to the configured default state rather than mutating unrelated testers. `DiagnosticProtocolAuthority` records timing evidence and NRC statistics around transactions through `DiagnosticService`.

## DCM/DEM lifecycle

`AutosarDcmDemAuthority` uses event configurations with fail/pass thresholds, confirmation/healing/aging cycle thresholds, severity, functional unit, and memory origin. Snapshot and extended-data records are retained with the event and synchronized into UDS DTC memory. Operation-cycle methods make confirmation/healing semantics deterministic in simulation.

## OBD qualification boundary

`RegulatoryObdAuthority` is a standards-oriented engineering campaign runner. It verifies protocol/profile consistency and observable requirements supported by the simulator. It intentionally identifies itself as pre-compliance because official certification depends on controlled external procedures, licensed normative text, approved test equipment, and regulatory interpretation outside this source package.

## Linux capability behavior

SocketCAN authorities compile with explicit operating-system capability boundaries. Linux-specific operations use the kernel APIs; unavailable facilities or insufficient privileges return/throw explicit failure rather than reporting synthetic success. The deterministic replay path remains portable because it targets `CanTransport`.

## ODX/PDX/OTX behavior

ODX import resolves diagnostic services and coded/physical data descriptions used by request encoding and response decoding. PDX import reads contained ODX documents from the ZIP container. OTX executes supported control-flow and diagnostic/application actions with explicit result state. Unknown or malformed executable operations do not become successful no-ops.

## Trace formats

`AutomotiveTrace` normalizes captured events and supports candump, Vector ASC, PCAPNG CAN_SOCKETCAN, and CSV. Use the normalized representation for deterministic replay, correlation, filtering, and evidence export; retain original files when source-format provenance is required.

## Recommended qualification commands

```bash
cmake --build build/v37 --parallel 2 --target \\
  ecu_diagnostics_socketcan_v37_tests \\
  muzixdiagsys_ecu_diagnostics_v37
./build/v37/ecu_diagnostics_socketcan_v37_tests
./build/v37/muzixdiagsys_ecu_diagnostics_v37 self-test
python3 tests/ecu_diagnostics_socketcan_v37_source_regression.py .
python3 tests/user_manual_regression.py .
python3 tests/documentation_consistency_regression.py .
```

## Public V37 authority classes

The release exposes `DiagnosticProtocolAuthority`, `AutosarDcmDemAuthority`, `J1978ScanTool`, `RegulatoryObdAuthority`, `SocketCanRawAuthority`, `SocketCanBcmAuthority`, `KernelJ1939Authority`, `SocketCanInterfaceManager`, `VirtualCanLaboratory`, `DeterministicCanReplay`, `OdxPdxRuntime`, `OtxRuntime`, `DiagnosticSemanticRegistry`, `XcpCalibrationAuthority`, and `AutomotiveTrace`. These classes compose the established diagnostic/network/calibration services described above.

## 2026-08-28 maintenance hardening

The V37 authority remains additive and feature-complete. The maintenance pass consolidates repeated trimming logic onto `aesim::core::trim_copy`, hardens finite/exact numeric parsing at telemetry and trace boundaries, rejects partial hexadecimal byte parses, prevents non-finite ECM harness-fault severity, and makes native-qualification readiness-pipe writes robust to interruption and short writes. Warning-prone aggregate initialization in schema-evolving DTC/test structures was replaced with explicit field assignment.

Release qualification includes the normal warning-enabled build, V35/V36/V37 preservation tests, anti-duplication regression, deterministic source-package regression, and focused ASan/UBSan builds/execution for the modified diagnostic, professional-authority, ECM/OBD, industrial-core, native-qualification, accuracy-depth, and terminal-workstation paths. No canonical UDS, OBD, SocketCAN, XCP, telemetry, or UI authority was removed or forked.

The final warning-clean audit also removed two behavior-neutral dead locals: the unused FDD segment counter in `src/advanced/experimental_mechanics_nvh.cpp` and the unused DOE separation-loop index in `src/ui/professional_engineering_desktop_v12.cpp`. All rebuilt translation units emit no warnings under the project warning policy. `src/ui/console_frontend.cpp`, whose optimized object generation exceeds the bounded build wrapper on the qualification host, was separately compiled with the same warning set in syntax-only mode and produced no warnings or errors.


# NHRA Deep Race Physics and Operations Authority — Phases A–J

## Scope and compatibility

`aesim::advanced::nhra::NhraDeepAuthorityPlatform` is an additive authority composed behind the existing `nhra` facade. It does **not** replace the seven championship/strategy domains or the ten established NHRA race-engineering domains. `NhraChampionshipStrategyPlatform::capabilities()` retains its original seven-item `domains` array and exposes the new implementation under `deep_authority`.

Public header:

```cpp
#include "aesim/advanced/nhra_deep_authority_platform.hpp"

aesim::advanced::nhra::NhraDeepAuthorityPlatform platform;
auto capabilities = platform.capabilities();
auto report = platform.execute("run-dynamics", request, "evidence/nhra");
auto qualification = platform.self_test("evidence/nhra-self-test");
```

The existing aggregate facade accepts the same domains:

```bash
muzixdiagsys_advanced_platform nhra capabilities
muzixdiagsys_advanced_platform nhra run-dynamics request.json report.json evidence/nhra
```

## Phase inventory

| Phase | Canonical domain | Production authority | Core solver/data path |
|---|---|---|---|
| A | `run-dynamics` | Full Run-Dynamics Digital Twin + high-resolution track geometry | Coupled longitudinal/pitch/yaw state integration, aero/load transfer, spatially interpolated lane surface |
| B | `driveline-torsion-tires-chassis` | Driveline torsion, independent L/R slicks, chassis and wheelie-bar | Two-inertia torsional mode, independent pressure/temperature/growth/slip, wheelie-bar contact |
| C | `crank-angle-nitro-combustion` | Crank-angle nitro combustion | Slider-crank cylinder volume, Wiebe heat release, pressure/work integration, per-cylinder mixture/timing |
| D | `fuel-blower-ignition-failure` | Fuel hydraulics + blower + magneto + cylinder failure propagation | Compressible rail pressure ODE, nozzle/bypass flow, compressor thermodynamics, spark margin and causal failures |
| E | `telemetry-ingestion` | NHRA telemetry ingestion/synchronization | Reuses `MotorsportTelemetryInterop`; Generic CSV, MoTeC, ATLAS, Cosworth, MDF4; unit normalization/resampling/alignment |
| F | `digital-twin-calibration` | Inverse identification + Bayesian track + causal delta + UQ | Regression, conjugate Bayesian segment grip, causal ranking, seeded Monte Carlo |
| G | `pro-stock-engineering` | Pro Stock rule-aware engineering | Naturally aspirated airflow/power model, five-speed shared run kernel, dated parity/induction profiles |
| H | `pro-stock-motorcycle-top-alcohol` | PSM + Top Alcohol shared-physics authority | Six-speed PSM rider/load-transfer model and Top Alcohol profiles feeding the common run kernel |
| I | `four-wide-competition` | Four-wide competition state machine | Four unique lanes, staging/foul precedence, reaction + ET + penalty ranking, two-entrant advancement |
| J | `rules-scrutineering-event-operations` | Versioned rules, scrutineering, event operations | Dated rule-profile validation plus session/track-delay/readiness accounting |

All phase implementations reject non-finite public numeric inputs through the shared advanced-platform finite-field validator. Reports are canonicalized, evidence-digested, and optionally written atomically to the supplied working directory.

## Shared run state

The Phase-A solver and class-specific Phase G/H models share one physical run kernel. Its principal state includes distance, speed, acceleration, pitch/pitch rate, yaw/yaw rate, engine angular speed, axle angular speed, driveline twist, independent left/right tire temperature, independent effective radii and slip. Spatial track samples provide elevation/grade, left/right grip, roughness and cross-slope.

Optional `gear_ratios` and `shift_rpm` extend the same solver from the single-ratio nitro configuration to multi-speed Pro Stock and Pro Stock Motorcycle. The selected gear alters reflected engine speed, clutch capacity, axle torque and engine reaction torque; it is not a post-processing approximation.

## High-resolution track geometry

Phase A accepts explicit `track_points` with distance, elevation, left/right grip, roughness and cross-slope. When no scan is supplied it constructs a deterministic high-resolution reference surface. Arbitrary vehicle distance is linearly interpolated between bracketing nodes. Surface grade participates in longitudinal force balance; cross-slope and lane grip asymmetry feed left/right normal load and yaw.

## Nitro combustion and auxiliaries

Phase C evaluates each cylinder through a full 720-degree four-stroke cycle. Slider-crank volume and `dV` drive compression/expansion work. A finite burn law generates crank-angle heat release and pressure/temperature evolution. Per-cylinder fuel/timing biases feed IMEP, peak pressure/temperature and knock/pre-ignition risk.

Phase D solves fuel-rail pressure dynamically from pump, bypass and nozzle flow using finite fluid compressibility. The blower model computes overdrive speed, pressure ratio, outlet temperature, parasitic power, inlet/outlet pressure, belt tooth load and failure risk. Magneto behavior reports spark-energy and voltage margin. Per-cylinder pressure/EGT/mixture/spark stress creates explicit failure modes and causal propagation into aggregate torque capability.

## Telemetry and calibrated digital twins

Phase E deliberately reuses the existing professional `MotorsportTelemetryInterop`; no competing telemetry parser was introduced. Inline telemetry is supported for deterministic API/test use, while file ingestion supports the existing vendor adapters. Phase F estimates effective drive force/aerodynamic resistance from time histories, updates segment grip distributions using a Bayesian prior/likelihood model, ranks run-to-run causal deltas, and propagates mass/torque/grip uncertainty through seeded run simulations.

## New class models

### Pro Stock

The 2026 post-Charlotte profile models the announced Ford/Dodge matched engine/body 11,000-rpm allowance while the baseline Chevrolet profile remains at 10,500 rpm. The separately selectable `nhra-pro-stock-2027-announced` profile models NHRA's announced hood-scoop return, dual top-mounted four-barrel-style throttle bodies and retained EFI. These are dated engineering profiles, not a claim to encode the complete licensed rulebook.

### Pro Stock Motorcycle and Top Alcohol

Phase H uses the same run kernel rather than duplicating a second drag solver. PSM adds a two-wheel mass/rider-shift and front-load/wheelie model plus a six-speed ratio set. Top Alcohol Dragster and Funny Car use class-specific mass, wheelbase, aero and powertrain profiles while sharing the core dynamics.

## Rules and official-source boundary

The dated profiles use public NHRA announcements as provenance:

- NHRA, 17 April 2026, Ford/Dodge Pro Stock engine parity initiative: https://www.nhra.com/news/2026/nhra-expands-pro-stock-competition-ford-and-dodge-engine-parity-initiative
- NHRA, 8 April 2026, 2027 Pro Stock hood-scoop/induction changes: https://nhra.com/news/2026/hood-scoops-set-return-nhra-pro-stock-category-2027-season

Phase J is an engineering scrutineering model. The current NHRA rulebook, amendments, technical bulletins, event instructions and officials remain controlling.

## Validation

Focused qualification:

```bash
cmake --build build/full --parallel --target \
  nhra_championship_strategy_platform_tests \
  nhra_race_engineering_platform_tests \
  nhra_deep_authority_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/full --output-on-failure \
  -R 'nhra_(championship_strategy|race_engineering|deep_authority)'
```

`nhra_deep_authority_platform_tests` executes all ten new phases, checks the Pro Stock 2026 parity profile, verifies four-wide classification, exercises telemetry, UQ and shared class physics, executes the authority self-test, and verifies non-finite input rejection.

## Source modules

- `include/aesim/advanced/nhra_deep_authority_platform.hpp`
- `src/advanced/nhra_deep_authority_internal.hpp`
- `src/advanced/nhra_deep_authority_platform.cpp`
- `src/advanced/nhra_deep_authority_a_b.cpp`
- `src/advanced/nhra_deep_authority_c_d.cpp`
- `src/advanced/nhra_deep_authority_e_f.cpp`
- `src/advanced/nhra_deep_authority_g_h.cpp`
- `src/advanced/nhra_deep_authority_i_j.cpp`
- `tests/nhra_deep_authority_platform_tests.cpp`

## V47 shared tire/traction/performance integration note

V47 adds a general-purpose detailed straight-line performance authority with continuous drag timing, carcass torsion, dynamic pressure/temperature, four-corner load transfer and finite trap-speed measurement. It is complementary to, not a replacement for, the NHRA deep full-run authority and its class-specific slick/chassis/nitro/race-operation logic. Use the general V47 laboratories for cross-vehicle acceleration/traction studies; retain the NHRA authority for NHRA-specific run dynamics, rules, lane/event and nitro reliability workflows.

# UI Customization Platform

## Purpose

The UI Customization Platform is the presentation infrastructure for MuzixDiagSys Version 20. It deliberately does **not** own simulation fidelity, vehicle physics, solver parameters, ECM calibration, diagnostic semantics, or backend execution. It composes the existing UI authorities and stores presentation-only state.

The V20 feature and CLI manifests remain additive compatibility baselines. The platform may add new UI commands, but it does not remove or rename protected V20 commands.

## Top 10 professional workflow enhancements

1. **Persistent UI profiles** — capture, clone, activate, import, and export complete presentation profiles without touching simulation state.
2. **Workspace/dashboard composition** — profiles snapshot the authoritative workspace and Dashboard Designer layouts; widget presentation supports visibility, display units, precision, groups, warning/critical thresholds, and refresh rates.
3. **Signal presentation catalog** — per-signal aliases, display units, precision, grouping, favorites, and requested UI refresh metadata. Unit conversion uses the existing semantic UnitRegistry.
4. **Semantic theme extension** — custom xterm-256 role themes integrate with the existing color/accessibility engine; built-in themes remain authoritative and reserved.
5. **Shortcut profile integration** — the existing `ui keys` keymap remains authoritative; profiles capture and restore validated keybindings and reject context/key collisions.
6. **Personalized universal palette** — existing search results are re-ranked using explicit favorites plus bounded recent-use frequency/recency without changing the command registry.
7. **Professional terminal presentation** — density override, Unicode/ASCII border policy, optional output timestamps, compact spacing, and animation throttling work with accessibility modes and SSH-safe rendering.
8. **UI resource/performance controls** — profile-specific frame/input/bandwidth/CPU budgets feed the existing UI resource governor. Rendering can be paused independently while simulation execution continues.
9. **Multi-monitor workspace maps** — named monitor geometry, scale, primary display, workspace, and dashboard assignments are persisted per profile and exposed to browser clients.
10. **Workflow/diagnostic specialization** — a profile can bind an existing guided workflow and the supplied diagnostics profile emphasizes ECM/OBD presentation without duplicating or mutating diagnostic backends.

## Command surface

Use `ui customize status` for the platform summary.

```text
ui customize profile list
ui customize profile apply diagnostics
ui customize profile capture my-lab "Powertrain diagnostic lab"
ui customize profile clone professional trackside
ui customize profile export ./trackside.mzui
ui customize profile import ./trackside.mzui

ui customize signal list
ui customize signal set speed alias="Road Speed" unit=mph precision=1 group=vehicle favorite=on refresh_ms=100
ui customize signal reset speed

ui customize theme list
ui customize theme create lab-blue 196 40 220 39 135 44 on
ui customize theme use lab-blue

ui customize terminal density compact
ui customize terminal borders ascii
ui customize terminal timestamps on
ui customize terminal animations off
ui customize terminal spacing compact

ui customize performance status
ui customize performance budget 40 30 512 10
ui customize performance governor on
ui customize performance render pause
ui customize performance render resume

ui customize monitor set center 0 0 2560 1440 1.25 on dashboard=diagnostics
ui customize monitor activate center
ui customize monitor list

ui customize favorite add ecm status
ui customize favorite list
ui customize shortcut capture
ui customize workflow bind diagnostic-scan
ui customize dashboard capture
ui customize diagnostics activate
ui customize validate
```

## Single-source-of-truth rules

- `ExperienceManager` remains authoritative for keybindings, workspaces, guided workflows, custom dashboards, discovery/accessibility modes, and command metadata.
- `DashboardDesigner` remains authoritative for engineering dashboard layout editing.
- `UnitRegistry` remains authoritative for compatible unit conversion.
- `UiResourceGovernor` remains authoritative for UI refresh/resource policy.
- Existing ECM/OBD, UDS, CAN, simulation, and engineering backends remain authoritative for domain behavior.
- The customization platform stores composition and presentation metadata only.

## Persistence

The normal UI preference location gains a sibling `.customization` file using the deterministic `MZUI 1` format. State is loaded transactionally: malformed or invalid files are rejected without partially applying a profile. User export/import uses the same format.

Project UI layout metadata records only the active customization profile, active monitor mapping, and UI-render pause state. No physics or fidelity parameter is persisted through this layer.

## Multi-monitor behavior

A monitor mapping records geometry and scale for external clients plus optional named workspace/dashboard assignments. Activating a mapping applies those existing UI objects. Browser `/api/state` also reports the active profile, theme, density, monitor and render-pause state so remote clients can honor the same presentation configuration.

## Safety and compatibility

Accessibility modes have priority over custom presentation. ASCII-only and screen-reader modes always remove ANSI color and Unicode decoration. Custom themes cannot overwrite reserved built-in semantic theme names. Factory profiles are protected baseline presets that cannot be deleted; clone one when you want a disposable variant. Profile edits remain presentation-only and are persisted normally.

`ui customize performance render pause` suspends automatic UI repaint only. It does not pause the simulation, modify solver cadence, or reduce simulation fidelity.

## Lower-pane view persistence

The core terminal preference transaction now persists the selected analytical lower-pane view in addition to lower-pane visibility. Valid persisted values are `activity`, `events`, `timeline`, `jobs`, `notifications`, `experiments`, `profiler`, `navigator`, and `causal`. Invalid values invalidate the preference transaction and recover to safe defaults rather than partially applying a profile. `ui prefs reset` restores the `activity` view.

This field belongs to core UI preferences/project layout state rather than customization profiles because it selects which canonical lower-pane projection is visible; it does not alter styling, physics, telemetry ownership, job state, or experiment state.

## V46 interaction-state persistence and workspace recipes

V46 composes customization state with a separate bounded interaction journal. Existing UI customization profiles remain the authority for theme, density, signal presentation, shortcuts, dashboards, monitor mappings and related preferences. The V46 journal adds only transient workflow context such as evidence-tray items, comparison A/B selections, active domain/research controls, browser shell state and the currently active workbench.

Autosave does not rewrite customization profiles. A browser recovery may restore the selected unit profile, watch list, favorite workbenches and shell dimensions from the captured client state, while the canonical desktop layout is restored by `ui desktop load`. Complete recovery can additionally reattach the existing persistent simulator session.

The Motorsport Workspace Recipes workbench creates or selects ordinary canonical desktop workspaces and opens existing workbench IDs into the established docking tree. The six implemented recipes are **Formula One Engineering**, **Endurance / WEC**, **NHRA Run Engineering**, **HIL / ECU Integration**, **Powertrain Calibration**, and **Controls Development**. Recipes are layout/workflow conveniences; they do not create alternate physics models, motorsport authorities or hidden profile types.

## V47 workbench persistence compatibility

The V47 tire/traction and acceleration-performance workbenches persist their browser presentation/configuration preferences through the established V46 interaction-storage namespace so existing autosave/recovery state migrates without a reset. This is intentional compatibility. Canonical physics state, track state, calibration state and performance results remain server-side authorities and are not stored as browser customization profiles.

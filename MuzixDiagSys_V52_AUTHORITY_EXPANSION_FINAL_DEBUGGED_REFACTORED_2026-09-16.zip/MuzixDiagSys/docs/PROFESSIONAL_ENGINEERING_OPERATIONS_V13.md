# Professional Engineering Operations V13

**V46 integration note (2026-09-09):** V13 services remain canonical and are reused by the V46 Integrated Engineering Workstation. V46 adds browser-native projections and cross-workbench interaction over these authorities; it does not replace runbooks, release qualification, engineering data catalog, calibration/correlation, collaboration, desktop layout, or command-dispatch services. Current browser workflows are documented in `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105.

V13 extends the schema-driven V12 desktop with six production engineering workbenches. All functionality is additive and uses the canonical interactive-shell command bus.

## 3D Engineering Digital-Twin Viewport

The 3D twin consumes live simulation telemetry and maintains a scene graph with stable engineering object identifiers, position, roll/pitch/yaw orientation, scale, metrics, camera state, JSON interchange, and browser/WebGL rendering data.

```text
ui digital-twin-3d status
ui digital-twin-3d object inverter component Inverter 1.2 0 0.4 0 0 0 0.5 0.4 0.2
ui digital-twin-3d camera 8 4 3 180 -12
ui digital-twin-3d json
ui digital-twin-3d remove inverter
```

## Electronic Qualification Runbook

Runbooks are versioned operator procedures with prerequisites, hold points, independent/dual approvals, pass/fail disposition, skip justification, SHA-256 evidence attachment and deterministic JSON records.

```text
ui runbook reset "Brake HIL qualification"
ui runbook add "Power on" "ui status" nominal - false false
ui runbook begin 1 operator-a
ui runbook complete 1 pass operator-a - nominal
ui runbook add "Safety signoff" "ui mission-control status" ready 1 dual hold
ui runbook begin 2 operator-a
ui runbook approve 2 reviewer-b
ui runbook approve 2 reviewer-c
ui runbook complete 2 pass operator-a reports/brake-evidence.json accepted
ui runbook ready
ui runbook save reports/brake-runbook.json
```

## Change Qualification & Release Planner

The planner reuses the global ContextGraph, Requirements–Verification–Evidence Matrix and Regression Triage Dashboard. It identifies affected objects, stale evidence and non-pass regressions, converts them into auditable release actions, and blocks release until mandatory actions and independent approval are complete.

```text
ui release-planner create CHG-104 "Brake calibration" ecu,brakes
ui release-planner status
ui release-planner action impact-1 running
ui release-planner action impact-1 passed
ui release-planner approve release-manager
ui release-planner releasable
ui release-planner save reports/CHG-104-release-plan.json
```

## Unified Engineering Data Catalog

The catalog indexes engineering telemetry, measurements, models, calibrations, evidence and reports with ownership, source, format, units, sample rate, uncertainty, provenance, consumers and SHA-256 integrity state.

```text
ui data-catalog add dyno42 "Dyno Run 42" telemetry results/dyno42.mf4 MDF4 mixed VnV dyno 1000 0.1
ui data-catalog verify dyno42
ui data-catalog consumer dyno42 REQ-BRAKE
ui data-catalog get dyno42
ui data-catalog list
ui data-catalog save reports/data-catalog.json
```

## Interactive Calibration & Correlation Workbench

The workbench directly wraps the existing production `CalibrationMapStudio`; it does not duplicate calibration-map interpolation or validation. It adds interactive editing, region changes, smoothing, measured-versus-simulated statistics, staged changes and independent approval.

```text
ui calibration-correlation create spark 2 2 deg
ui calibration-correlation set 0 0 10
ui calibration-correlation set 1 0 20
ui calibration-correlation set 0 1 15
ui calibration-correlation set 1 1 25
ui calibration-correlation validate
ui calibration-correlation correlate 1,2,3,4 1.1,1.9,3.2,3.8
ui calibration-correlation stage spark-v2 calibrator
ui calibration-correlation approve approver
ui calibration-correlation save reports/spark-v2.json
ui calibration-correlation export reports/spark-v2.csv
```

## Real-Time Collaborative Engineering Sessions

Live collaboration provides participant presence, heartbeat state, synchronized engineering-object cursors, shared simulation time, selections, anchored comments, resolution and presenter state. Persistent branches/commits/formal reviews remain owned by the existing Collaborative Engineering Studio.

```text
ui collaboration create brake-review "Brake transient review"
ui collaboration join alice Alice engineer
ui collaboration join bob Bob reviewer
ui collaboration cursor alice muzix://signal/brake 1.25 event-7
ui collaboration comment alice muzix://signal/brake 1.25 "Check transient"
ui collaboration resolve 1 bob
ui collaboration presenter bob
ui collaboration state
```

## Backend API / CLI parity

V13 retains the platform-wide backend parity contract. Standalone backend/tool executables are reachable through authenticated shell routes, advanced API families remain available through the advanced dispatcher and non-colliding direct roots, and every public V13 workbench operation above has command completion and canonical dispatch coverage.

## Integrated qualification workflow

A typical release flow is: inspect the live vehicle in the 3D twin; execute the controlled runbook; register generated datasets/evidence in the data catalog; correlate and approve calibration changes; generate the impact-based release plan; collaborate on anomalies with synchronized cursors/comments; close mandatory actions and approvals; persist runbook, release-plan and catalog evidence.

## V16 graphical frontend integration

The V13 production workbench backends remain authoritative in V16. The graphical browser now renders the existing 3D twin, calibration/correlation workbench, and related desktop state directly rather than duplicating their models. `ui calibration-correlation json` supplies structured calibration-map state; `ui digital-twin-3d json` continues supplying the WebGL scene. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 78.

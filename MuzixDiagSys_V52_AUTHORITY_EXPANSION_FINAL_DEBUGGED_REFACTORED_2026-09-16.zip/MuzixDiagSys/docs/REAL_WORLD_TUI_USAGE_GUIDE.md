# MuzixDiagSys TUI Real-World Usage Guide

**Version:** V20.1.2  
**Audience:** operators, students, technicians, engineers, and researchers who want practical terminal workflows without first learning the entire command catalog.

This guide complements the comprehensive User Manual. It intentionally uses short examples, explains what each command accomplishes, and shows how the terminal interface can be used during realistic automotive engineering work.

## 1. The TUI at a glance

The terminal interface has four practical regions:

1. **Dashboard** — current vehicle, powertrain, driver demand, thermal, diagnostic, and other engineering state.
2. **Command line** — where InteractiveShell commands are entered.
3. **Lower pane** — Command Activity by default, with optional Events, Timeline, Jobs, Notifications, Experiments, Profiler, Navigator, and Causal views.
4. **Status row** — editing mode, loop state, dashboard state, pane/filter/input/focus state, and concise operator feedback.

Percentage and utilization meters use high-resolution Unicode block cells. A partially filled cell conveys eighth-cell resolution instead of rounding everything to whole `#` characters. **Telemetry sparklines remain separate and unchanged**: they continue to show time history rather than percentage completion.

## 2. Selecting, copying, and pasting text

### Normal operating mode: terminal-native selection

Mouse capture is **off by default**. This is deliberate: your terminal emulator owns ordinary drag selection, so terminal text can be highlighted and copied normally.

Check the current policy:

```text
ui mouse status
```

Typical output explains that mouse capture is off and text selection is available.

To copy text:

1. Drag across the desired terminal text using the normal selection gesture provided by your terminal emulator.
2. Use that terminal's copy command. Common examples are `Ctrl+Shift+C` on many Linux/Windows terminal emulators and `Command+C` on macOS terminals. Your terminal may use a different shortcut.
3. Paste with the corresponding terminal paste command.

MuzixDiagSys keeps **bracketed-paste protection enabled**. Pasted text is treated as paste input, control characters are sanitized, multiline content is protected, and pasted material is not automatically executed merely because it contains a newline.

### Optional TUI mouse interaction

If you specifically want the application to receive button clicks or the mouse wheel:

```text
ui mouse on
```

The application enables button/wheel reporting, but deliberately does not enable continuous drag-motion reporting. This prevents mouse-motion floods and avoids the historical condition where a click could leave the InteractiveShell waiting for Escape.

Return to ordinary terminal selection with:

```text
ui mouse off
```

For SSH work, log review, and copying diagnostic evidence, keeping mouse capture off is usually the better choice.

## 3. Start a normal road-vehicle simulation

The following example selects a Volkswagen GTI model, initializes it, applies moderate throttle, advances the simulation, and checks the resulting state.

```text
engine vw_gti_2.0_tsi_ea888_evo4
vehicle vw_gti_mk8_dsg
quickstart
throttle 35
step 2
status
```

What these commands mean:

- `engine ...` selects the engine model.
- `vehicle ...` selects the vehicle model.
- `quickstart` initializes the coupled simulator into a ready/running configuration.
- `throttle 35` requests 35% accelerator input.
- `step 2` advances simulated time by two seconds.
- `status` produces a detailed state snapshot suitable for checking whether the requested operating condition was actually reached.

A useful habit is to change **one major operating condition at a time**, step the model, and inspect the response before making another change. This produces more interpretable engineering evidence.

## 4. Watch RPM as a time history

A dashboard value tells you what RPM is *now*. A sparkline tells you how RPM has been moving.

```text
ui sparkline rpm 64
```

The sparkline uses the existing telemetry workbench history and retains the dedicated sparkline glyph set. It is not converted into a progress/status bar.

Use this when diagnosing:

- hunting or oscillatory idle;
- shift transients;
- throttle response;
- controller limit cycling;
- transient overspeed.

For another signal, substitute the telemetry channel name. For example, where the active backend exposes it:

```text
ui sparkline engine.coolant_c 64
```

## 5. Use the lower pane as an engineering workspace

Command Activity remains the default because it is the best general-purpose record of what the operator has done. Switch views when the investigation changes:

```text
ui lowerpane tabs
ui lowerpane view timeline
ui lowerpane view notifications
ui lowerpane view jobs
ui lowerpane view profiler
ui lowerpane view navigator
ui lowerpane view causal
```

Practical interpretation:

- **Activity** — commands and command results.
- **Events/Timeline** — chronological simulator and engineering events.
- **Jobs** — long-running or queued engineering work.
- **Notifications** — actionable warnings/notices without searching scrollback.
- **Experiments** — experiment-matrix progress and status.
- **Profiler** — runtime resource/performance observations.
- **Navigator** — subsystem hierarchy and signal context.
- **Causal** — causal/comparison investigation output.

Return to the normal command log with:

```text
ui lowerpane view activity
```

## 6. Investigate a transient with the event timeline

When something unexpected happens, first establish *when* it happened.

```text
ui event-timeline 30 120
```

This displays a synchronized event-oriented view over the requested time window/width. Use it to correlate items such as:

- a driver input change;
- a controller transition;
- a warning threshold crossing;
- a diagnostic event;
- a fault or scenario event;
- an experiment or operator action.

The purpose is not merely to show another log. The timeline lets you reason in chronological order: **input → controller reaction → physical response → diagnostic consequence**.

## 7. Save a state before a risky investigation

The time-travel UI projects the existing synchronized time cursor and real backend state checkpoint facilities.

Before making an experimental change:

```text
ui time-travel checkpoint before-change
ui time-travel status
```

Navigate through recorded events:

```text
ui time-travel next-event
ui time-travel previous-event
```

Restore the saved UI/backend state when appropriate:

```text
ui time-travel restore before-change
```

This is especially useful when you want to compare several hypotheses from the same initial condition instead of repeatedly rebuilding the operating state manually.

## 8. Inspect the vehicle by subsystem instead of memorizing signal names

Open the hierarchy:

```text
ui navigator tree
```

Search it:

```text
ui navigator find battery
```

Inspect a subsystem:

```text
ui navigator inspect subsystem://electrification
```

Select or pin a signal when it exists in the active context:

```text
ui navigator select signal://battery.soc
ui navigator pin signal://battery.soc
ui navigator pins
```

This workflow is useful when you know *what system* you are investigating but do not yet know the exact signal or parameter spelling.

## 9. Inspect settable parameters before changing them

List the active backend's real settable parameters:

```text
ui parameter-inspector list
```

Inspect a known parameter:

```text
ui parameter-inspector engine.redline_rpm
```

The parameter inspector exists to answer three questions before you modify anything:

1. Is the parameter actually supported by the active backend?
2. What is its current engineering context/value?
3. What related metadata or signals should be considered before changing it?

This reduces blind trial-and-error in a simulator with a very large command surface.

## 10. Use inline documentation while staying in context

Instead of leaving the shell and searching a long manual, inspect the command or signal in place:

```text
ui doc-inspect set
ui doc-inspect throttle
```

The inline documentation inspector combines canonical command help with available signal/context metadata. It is most useful immediately before an unfamiliar command or while reviewing somebody else's recorded workflow.

## 11. Diagnose DTCs with chronology, evidence, and context

Start with the canonical diagnostic views:

```text
dtc active
dtc freeze
```

Then correlate the diagnostic result with the UI evidence surfaces:

```text
ui notifications unread
ui event-timeline
ui navigator tree
```

A practical diagnostic sequence is:

1. identify the active/pending code;
2. inspect its freeze-frame operating state;
3. locate nearby events in time;
4. inspect the affected subsystem;
5. compare related telemetry;
6. only then clear or alter the condition.

This approach avoids treating a DTC as an isolated text label when the simulator can expose the surrounding physical and control-system context.

## 12. Compare cause, not just outcome

When baseline and candidate runs are loaded in the run-comparison workbench, the causal inspector can identify where they begin to diverge.

```text
ui causal-inspector status
ui causal-inspector divergences candidate 1e-9 1e-6
ui causal-inspector explain candidate speed_kmh 1e-9 1e-6
```

The two tolerances define the numerical comparison sensitivity. The useful question is not only “Did speed change?” but “Which earlier state/control differences plausibly led to the speed difference?”

Use this after calibration edits, software/controller changes, altered initial conditions, or model-fidelity changes.

## 13. Run and monitor engineering jobs

The job UI uses the existing Mission Control `JobManager`; it is not a second task system.

Example:

```text
ui jobs submit thermal-sweep "ui run-manager list"
ui jobs list
ui jobs inspect 1
```

During work, progress/state can be updated through the existing job API/CLI:

```text
ui jobs progress 1 50 midpoint
ui jobs state 1 running
```

Cancel when necessary:

```text
ui jobs cancel 1
```

Use the job view for operations that are long enough that “nothing printed yet” would otherwise be ambiguous.

## 14. Monitor an experiment campaign

Open the experiment cockpit:

```text
ui experiment-cockpit
```

Or filter by a relevant series/tag when present:

```text
ui experiment-cockpit series:f1
```

The cockpit summarizes the existing experiment matrix and job state. It is intended to answer:

- how many cases are complete, active, proposed, or failed;
- what work is currently executing;
- whether a campaign is converging or accumulating failures;
- which case should be inspected next.

## 15. Use the motorsport pit wall

When the selected simulation exposes racing telemetry:

```text
ui pit-wall f1
ui pit-wall indycar
ui pit-wall nascar
```

The pit-wall view uses actual available channels for lap, position, delta, speed, RPM, gear, driver controls, fuel/energy, and tyre data. Missing data is shown as unavailable rather than invented.

Typical real-world questions include:

- Is the driver losing time because of entry speed, traction, or energy management?
- Are tyre temperatures diverging corner-to-corner?
- Is fuel/energy state compatible with the remaining run target?
- Did a performance loss begin before or after a setup/control change?

## 16. Plot a terminal track map from compared runs

After loading runs with coordinate telemetry:

```text
ui run-compare load-csv baseline ./baseline.csv time_s
ui run-compare load-csv candidate ./candidate.csv time_s
ui run-compare baseline baseline
ui track-map 76 22 2400
```

The terminal map uses coordinate histories already owned by the N-way comparison workbench. It is useful over SSH when a graphical plotting environment is unavailable.

Use it to check:

- different racing lines;
- path departures;
- localization drift;
- where two runs begin to separate spatially.

## 17. Read the friction circle

```text
ui friction-circle
```

The friction-circle view combines longitudinal and lateral acceleration. A point near the outer envelope means the vehicle is using more of the available combined acceleration capability.

Examples:

- high lateral / little longitudinal: steady cornering;
- strong negative longitudinal / modest lateral: straight-line braking;
- simultaneous braking and cornering: combined-load trail-braking region;
- acceleration plus lateral load: corner exit/traction demand.

If native `g` channels exist they are used directly. Acceleration channels in m/s² are converted semantically rather than guessed from their magnitude.

## 18. Check whether the simulator itself is the bottleneck

Use the runtime performance dashboard:

```text
ui performance-profiler dashboard
```

Collect another sample:

```text
ui performance-profiler sample
ui performance-profiler show
```

Use this when:

- real-time factor falls unexpectedly;
- a new model materially increases runtime;
- memory growth is suspected;
- a CPU/GPU/MPI configuration is being compared;
- an experiment case appears slower than its peers.

The profiler reports what the host exposes; unavailable hardware data is explicitly marked unavailable.

## 19. Read uncertainty without confusing it with a status bar

```text
ui uncertainty-view
```

The compact uncertainty view recognizes existing `.sigma`, `.stddev`, `.uncertainty`, `.lower`, `.upper`, `.lower95`, and `.upper95` channel conventions. It never invents an uncertainty interval when the active backend has not produced one.

Use it when interpreting quantities that should not be treated as exact, such as estimated states, identified parameters, model-form uncertainty, or propagated measurement uncertainty.

## 20. Understand high-resolution status bars

A meter such as:

```text
[████████▍░░░░░░░]
```

is a **bounded status/percentage meter**. Full blocks represent complete cells, a fractional block carries sub-cell resolution, and `░` represents remaining capacity/range.

This is intentionally different from a telemetry sparkline such as:

```text
▁▂▃▅▇█▆▄▃
```

The first communicates **how much of a range is occupied**; the second communicates **how a signal changed over time**. MuzixDiagSys keeps both visual forms because they answer different engineering questions.

## 21. A practical five-minute investigation pattern

For many problems, this compact sequence is enough to establish a disciplined starting point:

```text
status
ui notifications unread
ui event-timeline
ui navigator tree
ui sparkline rpm 64
ui performance-profiler dashboard
```

Then add the domain-specific view:

- diagnostics: `dtc active`, `dtc freeze`;
- causality: `ui causal-inspector ...`;
- experiment: `ui experiment-cockpit`;
- motorsport: `ui pit-wall ...`, `ui track-map`, `ui friction-circle`;
- uncertainty: `ui uncertainty-view`.

The principle is simple: **establish state, establish chronology, locate the subsystem, inspect the trend, then test a hypothesis**.

## 22. If the terminal appears to react badly to mouse input

First return application mouse capture to its safe default:

```text
ui mouse off
```

Then verify:

```text
ui mouse status
```

If the terminal emulator itself has a special “application mouse” or alternate-screen selection policy, its own modifier key may still be required for selecting text. MuzixDiagSys no longer enables application mouse reporting at startup, so ordinary terminal selection should remain available by default.

If a mouse escape sequence is received while capture is off, the input decoder consumes it as a no-op rather than inserting it into the command line or waiting for Escape. This specifically protects InteractiveShell responsiveness.

## 23. Where to go next

Use these references when a workflow in this guide becomes too simple for the task:

- `docs/MUZIXDIAGSYS_USER_MANUAL.md` — complete operator/engineering reference.
- `docs/ENGINEERING_UI_PLATFORM.md` — UI architecture and exact engineering-workbench commands.
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md` — broader beginner-to-advanced command tutorial.
- `docs/COMMAND_REGISTRY_AND_COMPLETION.md` — command discovery, completion, aliases, and schemas.

This guide intentionally favors a small number of understandable workflows over exhaustive command enumeration.

## 24. Read the professionalized dashboard layout

The default dashboard now follows a consistent engineering-instrument layout:

```text
│ RPM                 │ 0850 rpm                      [███▏░░░░░░░░░░░░] │
│ Torque / Power      │ 0.0 Nm / 0.0 hp               [░░░░░░░░░░░░░░░░] │
│ Coolant / Oil       │ 88.0 °C / 90.0 °C             [██████████▌░░░░░] │
│ DTC                 │ none  [CLEAR]                                     │
```

The three visual columns have distinct purposes:

- the **left column** is the engineering quantity or state;
- the **middle column** is the exact numeric/text value;
- the **right column** is reserved for a bounded high-resolution instrument when one is meaningful.

Because meters are right-aligned, the eye can compare multiple rows vertically without having to follow different value-string lengths. Boolean/discrete conditions such as `RUNNING`, `CLEAR`, `ACTIVE`, or `LIMITING` use explicit status badges rather than artificial percentage bars.

Every dashboard page also has a domain heading such as `ENGINE MECHANICS & COMBUSTION`, `THERMAL MANAGEMENT`, `OBD LIVE DATA`, or `ENERGY BALANCE`. This makes page changes immediately recognizable, particularly over SSH where rapid full-screen redraws can otherwise look similar.

The live watch panel uses the same visual grammar while preserving telemetry sparklines. Labels and live values are aligned, sparklines remain historical trend indicators, and the enclosing frame makes the watch panel visually distinct from command activity.

## Completion popup behavior on slow or heavily loaded hosts

The completion popup is driven by the canonical completion model and may render over more than one terminal refresh on a heavily loaded host or remote PTY. Operators should use the visible candidate/selection/description state rather than assuming that every pane changes in the same terminal frame. Arrow keys and Tab change the selected completion; mouse wheel over the left pane moves candidate selection, while mouse wheel/PageUp/PageDown over the description pane scrolls help text without changing the candidate.

The release regression now explicitly waits for those observable state transitions, so slow CI/SSH scheduling no longer creates false `completion_popup_scroll_pty` failures. No extra delay setting is required for normal operation.

## V47 tire/traction and acceleration-performance workflow

For a direct terminal study, start with:

```text
ui tire-traction json mu=1.15 pressure-kpa=220 drive=rwd tc=on
ui acceleration-performance json mu=1.15 pressure-kpa=220 drive=rwd tc=on
```

Use `sensitivity`, `convergence`, `monte-carlo`, and `calibrate` under `ui acceleration-performance` for research-grade follow-up. A measured calibration CSV requires `time_s,speed_m_s` and may include `distance_m,engine_rpm`. Browser users can open `tire-traction-lab` and `acceleration-performance-lab` for the same canonical operations.

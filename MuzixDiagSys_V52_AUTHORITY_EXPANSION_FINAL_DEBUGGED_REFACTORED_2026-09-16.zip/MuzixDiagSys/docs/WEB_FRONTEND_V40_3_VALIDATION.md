# MuzixDiagSys V40.3 Web Frontend Validation

**Current-status note (2026-09-09):** This document remains the authoritative historical record for the V40.3 validation record tranche. The current browser workstation is **V46**. V46 preserves these behaviors and adds structured schema-driven renderers, typed engineering-object drag/drop, transaction/autosave/recovery/deep-link infrastructure, integrated preflight/evidence/comparison/timeline/snapshot workflows, native V45 engine/transmission/four-corner views, and native research-grade analysis workbenches. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105 for current operation and qualification. Release-specific assertions in this document should not be read as a complete V46 feature inventory.

**Release:** V40.3  
**Validation date:** 2026-08-29  
**Scope:** Browser engineering operations/investigation tranche, Signal Explorer selection repair, documentation, source-package integrity, and feature-preservation regressions.

## 1. Release scope validated

V40.3 upgrades existing workbench identities rather than introducing duplicate backend authorities:

1. **Live Operations Center** (`live-operations`)
2. **Advanced Run Comparison + Causal Difference Analysis** (`run-comparison-studio` plus the retained `causal-difference` authority)
3. **Diagnostics / Fault Investigation Center** (`diagnostic-center`)
4. **Solver / HPC Health Dashboard** (`solver-observability` and retained performance/HPC authorities)
5. **Provenance + Time-Travel State Inspector** (`time-travel` plus retained provenance/object-inspection authorities)
6. **Signal Explorer selection repair** (`signal-explorer`)

The browser continues to use the authenticated `BrowserEngineeringServer` surfaces `/api/state`, `/api/schema`, `/api/stream`, and `/api/command`. Mutating actions continue to execute canonical commands and access checks; no feature-specific mutation REST service or second simulator state model was added.

## 2. Signal Explorer regression validation

The selection defect was traced to two interacting frontend behaviors: selectable names were primarily discovered from live telemetry, and live refresh could replace selectable row DOM while the operator was interacting with it.

The V40.3 implementation was validated for the following invariants:

- the canonical `ui signal-explorer list` result seeds a stable signal catalog before live telemetry exists;
- the visible list is the union of canonical catalog signals and any additional stream-discovered names;
- rows are focusable controls with `role="option"` and `aria-selected` state;
- pointer selection commits synchronously before asynchronous inspection;
- Arrow Up/Arrow Down move the persistent selection and Enter/Space activate inspection;
- streaming refresh updates values and sample counts without rebuilding the selectable row list;
- asynchronous inspection responses use a generation guard so a stale response cannot overwrite a newer selection;
- selection remains in Shared Engineering Context and survives workbench/schema redraws.

A headless Chromium interaction test executed the production embedded JavaScript in an in-memory document with mocked canonical `/api/schema`, `/api/state`, `/api/stream`, and `/api/command` responses. With an empty live stream, three canonical signals loaded and the test verified pointer selection, persistence across repeated stream refresh, persistence across a full desktop/schema rebuild, stale-response rejection during rapid A-to-B selection, Arrow navigation, Enter activation, `aria-selected`, the visible selection badge, and `app.signalExplorer.selected`. The interaction test passed.


## 3. Native build validation

The V40.3 build tree was configured with the project Release/hardening/strict-numerics policy. Validation included:

- direct compilation of `src/ui/engineering_ui_platform.cpp`;
- direct compilation of `tests/engineering_ui_platform_tests.cpp`;
- successful linked build of `engineering_ui_platform_tests`;
- successful complete `aesim_test_artifacts` dependency closure;
- successful final linkage of the main `muzixdiagsys` executable.

The only compiler diagnostic observed while completing the broad artifact closure was a pre-existing missing-field-initializer warning in `tests/terminal_workstation_platform_tests.cpp`; it did not fail the build and is unrelated to the browser frontend changes.

## 4. Engineering UI regressions

The V40.3 source/native regression contract preserves all previously guarded browser capabilities while adding explicit guards for the new tranche.

Validated results:

- `engineering_ui_platform_source_regression`: **PASS** - 93 guarded feature families retained;
- `engineering_ui_platform_unit_tests`: **PASS**;
- native served-page checks: **PASS**, including V40.3 branding, restrictive CSP, retained V18/V19/V40.2 assets, V40.3 investigation workbenches, canonical Signal Explorer catalog, Solver/HPC, provenance/time-travel, run comparison, and diagnostics assets;
- `engineering_ui_live_routing_pty`: **PASS**;
- legacy `web_gui_v19_pty`: **PASS**;
- UI input fuzz, golden-frame, lower-pane visibility, help focus, terminal-density/resize, completion, and professional-workflow PTY regressions: **PASS**.

The V40.3 source regression explicitly rejects returning to `root._refresh=renderList` for Signal Explorer and requires stable `refreshVisibleRows` behavior, persistent selection state, synchronous pointer selection, and stale asynchronous inspection rejection.

## 5. Documentation validation

The following documentation was updated for V40.3:

- `README.md`
- `docs/README.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/ENGINEERING_UI_PLATFORM.md`
- `docs/GLOBAL_UI_ARCHITECTURE.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md`
- `docs/WEB_FRONTEND_ENGINEERING_WORKSPACE_V40_2.md`
- `docs/WEB_FRONTEND_PROFESSIONAL_SHELL_V40.md`
- `docs/WEB_FRONTEND_V40_2_VALIDATION.md`
- this V40.3 validation record.

The comprehensive user manual now includes **Chapter 101: V40.3 Browser Engineering Operations and Investigation Workbenches**, including workflows for the five upgraded workbenches and the Signal Explorer selection repair.

Validated results:

- `user_manual_regression`: **PASS**;
- `documentation_consistency_regression`: **PASS**.

The PDF manual is regenerated from the authoritative Markdown source with `tools/generate_user_manual_pdf.sh` during release packaging and is rendered/preflight-checked after generation.

## 6. Source-package / consolidation integrity

Two source-package integrity defects were found during full validation and corrected at their source rather than weakening tests:

1. `consolidation_architecture_regression` initially reported four active frontend documentation files absent from `configs/source_package_manifest.json`. The manifest was updated to include the active V40.2/V40.3 frontend documentation.
2. `source_package_regression` then correctly reported that `approved_member_count` still described the previous manifest size. The count was updated to match the manifest contents.

Validated results after correction:

- `consolidation_architecture_regression` (test 188): **PASS**;
- `source_package_regression` (test 184): **PASS**;
- `duplicate_implementation_regression`: **PASS**;
- `clean_generated_artifacts_regression`: **PASS**;
- `build_footprint_regression`: **PASS**;
- `build_transaction_workflow_regression`: **PASS**;
- `ctest_artifact_fixture_regression`: **PASS**.

## 7. Complete CTest release gate

The configured suite contains **318 tests**. After the complete `aesim_test_artifacts` target was built, the final release gate was executed as one **normal-order sequential CTest run**. Sequential ordering was retained intentionally because earlier validation had exposed source-tree state contamination that only matters when tests execute in release order:

```text
100% tests passed, 0 tests failed out of 318
Total Test time (real) = 484.80 sec
```

Important release blockers were validated inside that same run rather than only in isolation:

- test 184 `source_package_regression`: **PASS**;
- test 188 `consolidation_architecture_regression`: **PASS** after all preceding source/PTY/runtime tests;
- test 218 `documentation_consistency_regression`: **PASS**;
- test 223 `engineering_ui_live_routing_pty`: **PASS**;
- test 244 `help_focus_pty`: **PASS**;
- test 245 `user_manual_regression`: **PASS**;
- test 258 `regulatory_cycle_tracking_regression`: **PASS**;
- test 297 `advanced_api_lifecycle_transport_system_regression`: **PASS**;
- test 298 `advanced_api_engineering_expansion_regression`: **PASS** with isolated temporary HSM/Digital-Key state;
- test 299 `interactive_advanced_motorsport_cli_regression`: **PASS**;
- test 318 `aesim_prepare_test_artifacts`: **PASS**.

The release also verified that PTY tests no longer create `.muzixdiagsys_history` in the source root. Interactive history persistence now writes to a user-state location (`MUZIX_HISTORY_FILE` override; XDG/`~/.local/state` on Unix-like systems; user-local application data on Windows) while retaining legacy project-root history as a read-only migration source.

## 8. Release hygiene

Before source packaging:

- temporary CMake/Ninja build output is excluded from the package;
- Python `__pycache__` / `.pyc` files are removed;
- test-generated `.muzixdiagsys` credential/HSM material is removed from the source tree;
- no browser test fixture or temporary extracted HTML is included;
- the deterministic source-package manifest is authoritative for final archive membership.

The final source archive is produced with `tools/package_source.py`, then ZIP integrity and SHA-256 are checked before delivery.

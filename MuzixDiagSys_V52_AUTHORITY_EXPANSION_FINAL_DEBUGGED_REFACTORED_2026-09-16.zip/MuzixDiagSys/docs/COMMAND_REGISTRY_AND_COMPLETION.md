# Canonical Command Registry and Contextual Tab Completion

**Documentation revision:** 2026-07-14

## Purpose

MuzixDiagSys treats execution compatibility and command discovery as related but distinct release interfaces. The dispatcher accepts the complete historical command vocabulary, while interactive discovery presents one canonical spelling for each behavior. This removes redundant choices without breaking scripts, journals, projects, replay manifests, training material, or existing operator workflows.

The current registry contains:

- **165 canonical root commands** shown by discovery.
- **49 compatibility root aliases** accepted by execution but hidden from ordinary discovery.
- **214 total accepted root spellings**.
- Context-sensitive nested rules, runtime presets, parameters, metrics, and delegated industrial routes.

The exact live counts are reported by `command-schema status`; tests consume those reported values rather than duplicating them in a second registry.

## Discovery policy

### Canonical roots

An empty-line Tab request, the F2/Ctrl-Space command palette, schema path enumeration, and root prefix completion expose canonical roots only. For example, `metrics` is discoverable while the legacy spellings `dashboard` and `dash` remain executable but do not appear as duplicate rows.

Typing an exact compatibility alias and pressing Tab migrates the editor to the canonical command. This is an explicit compatibility upgrade, not deletion. The same rule applies to registered engine and vehicle preset aliases.

### Hierarchical parameters

Settable scalar names are intentionally excluded from the root list because they are arguments, not commands. They remain fully discoverable through:

```text
set <Tab>
set engine.<Tab>
set vehicle.<Tab>
```

This reduces root-list noise while preserving complete parameter access.

### Contextual descendants

Nested candidates are derived from the active command context. Exact grammar rules outrank wildcard rules, and delegated platform providers remain authoritative for their own subtrees. Representative paths include:

```text
road surface <Tab>
fuel <Tab>
scope add <Tab>
ui statusbar preset <Tab>
industrial vehicle <Tab>
industrial assurance diagnostics odx <Tab>
industrial energy advanced architecture <Tab>
xcp <Tab>
diagnostics obd <Tab>
validation measured <Tab>
```

Dynamic providers expose current engine presets, vehicle presets, settable parameters, scope channels, loaded platform routes, and other runtime-dependent domains.

### Fuzzy root recovery

When a root prefix has no exact or prefix candidates, Tab performs bounded subsequence scoring against canonical roots only. A typo such as `throtle<Tab>` can recover `throttle`. Compatibility aliases are deliberately excluded from fuzzy recovery so typo assistance cannot recreate the duplicate list that canonical discovery removes.

## Split contextual inspector

Pressing Tab with multiple candidates opens **Canonical Command Completion**, a two-pane inspector.

### Left pane: candidates

The left pane displays the canonical candidate list and an active pointer. It is a real viewport: the visible range follows the selection, and the footer reports candidate range and selected index.

Controls:

| Input | Result |
|---|---|
| Tab / Down | Select next candidate |
| Shift-Tab / Up | Select previous candidate |
| Home / End | Select first / last candidate |
| Enter | Insert the selected canonical token |
| Mouse wheel over left pane | Move the selected candidate |
| Esc / Ctrl-G | Close completion |

### Right pane: selected-command description

The right pane updates whenever the pointer changes and now acts as a compact operator manual for **every parent command and every registered literal subcommand path**. It reports, as applicable:

- Canonical command or full completion path and its parent-path relationship.
- Command category, live availability, required permission, and match source.
- Concise purpose plus extended behavior explaining what the parent family owns and what the selected subcommand does inside that family.
- Accepted compatibility aliases while continuing to insert only canonical spellings.
- Syntax/expected input, literal next choices, and detailed per-choice explanations.
- State/side-effect classification, engineering workflow guidance, and read-only versus mutating behavior.
- Runnable examples, semantic preflight, non-executing preview, full-help, schema-completion, and error-recovery commands.
- Canonical insertion/discovery policy and completion-navigation controls.

The description owns an independent scroll offset. PageUp/PageDown scroll it without moving the selected command. A mouse wheel event over the right pane scrolls the description; the same event over the left pane changes the pointer. Selecting another candidate resets the description to its first line.

For narrow terminal widths, the renderer stacks the candidate list and selected-command detail rather than allowing the right pane to collapse or overwrite text.

## Architecture

### Root command registry

`console_root_command_specs()` is the authoritative source for accepted root spellings and canonical targets. The dispatcher resolves a spelling through this registry before entering a handler. Domain dispatch branches compare canonical roots only; alias-specific conditionals are not duplicated throughout the runtime. Discovery derives a canonical projection from the same registry rather than maintaining a second command list.

Every canonical root also has authoritative metadata: category and command summary. Schema validation fails when metadata is missing.

### Nested grammar and delegated registries

`nested_completion_rules()` describes integrated console descendants with exact and wildcard contexts. `IndustrialPlatform` and its vehicle, assurance, electrification, frontier, research, and federation providers own delegated routes. Dynamic model state supplies presets, settable parameters, metric domains, and other runtime candidates.

### Completion proposal model

The terminal catalog converts raw candidates into contextual proposals containing the canonical path, category, aliases, detail text, next-token preview, and match mode. The renderer consumes those proposals directly, so the right pane cannot drift into an unrelated hand-maintained help table.

## Runtime audit commands

```text
command-schema status
command-schema validate
command-schema aliases
command-schema dump
command-schema paths
command-schema complete <command-prefix>
```

- `status` reports accepted spellings, canonical roots, hidden compatibility aliases, discoverable roots, nested rules, literal paths, and policy labels.
- `validate` checks registry uniqueness, canonical resolution, metadata completeness, duplicate choices, exact/wildcard reachability, delegated visibility, and production completion reachability.
- `aliases` prints the compatibility-to-canonical migration table.
- `dump` and `paths` expose the machine-auditable grammar.
- `complete` queries the production non-interactive candidate provider.

Automation interfaces remain:

```text
muzixdiagsys --command-schema
muzixdiagsys --completion-query "road surface "
muzixdiagsys --completion-batch
```

## Regression protection

The release suite verifies:

1. Canonical root discovery contains no compatibility aliases or scalar parameters.
2. Every compatibility alias still resolves and exact-alias Tab migration inserts the canonical spelling.
3. Preset aliases migrate to canonical preset keys.
4. Every declared literal path is reachable through the production completion API.
5. Every canonical root has a category and non-placeholder description.
6. The split PTY inspector shows contextual metadata, follows pointer movement, scrolls the right pane independently, and routes mouse-wheel events according to pane position.
7. Fuzzy typo recovery inserts a canonical root.
8. Completed leaf commands do not restart unrelated grammars.
9. Existing UI, industrial, diagnostics, case-sensitive-path, and manual regressions remain valid.

## Extension requirements

When adding or changing a command:

1. Register accepted root spellings and the canonical target in `console_root_command_specs()`.
2. Add category and summary metadata for every new canonical root.
3. Route execution through canonical resolution; do not create an independent dispatcher alias table.
4. Add nested literal or enum candidates to the owning grammar/provider.
5. Keep filenames, IDs, numbers, payloads, and other free-form arguments free-form and case preserving.
6. Put model parameters under `set`, not in the root namespace.
7. Add a PTY regression for novel interaction behavior.
8. Run `command-schema validate` and the complete CTest matrix.

Do not add independent root lists to the editor, command palette, help overlay, schema reporter, or dispatcher.


## Declarative UI action metadata

The canonical root registry is also ingested by `ux::ExperienceManager`. Registry metadata is merged with richer nested parameter schemas; an untyped live root record cannot erase an existing generated-form schema. Each UI action can define title, category, summary, mutation classification, discovery-profile promotion, aliases, search tags, and typed parameters.

This metadata drives all of the following from one source:

- Universal action indexing and type-prefixed fuzzy search.
- Presentation-only discovery profiles.
- Generated forms and validation.
- Context-sensitive help.
- Preview and dry-run mutation classification.
- Typed command transaction labels.

All accepted aliases remain parser contracts. The universal action palette may match an alias, but it displays and invokes the canonical action. See `docs/STREAMLINED_UI_EXPERIENCE.md`.

## Advanced API engineering registry

`muzixdiagsys_advanced_platform` additionally exposes a machine-readable registry for the 146 advanced API command adapters:

```bash
muzixdiagsys_advanced_platform commands [--category CATEGORY] [output]
muzixdiagsys_advanced_platform describe COMMAND [output]
muzixdiagsys_advanced_platform COMMAND capabilities|describe|schema|example [output]
muzixdiagsys_advanced_platform COMMAND self-test DIRECTORY [output] [GLOBAL_OPTIONS]
muzixdiagsys_advanced_platform COMMAND run REQUEST OUTPUT [WORKING_DIRECTORY] [GLOBAL_OPTIONS]
```

This registry is additive and is separate from the legacy interactive command registry. It is intended for scripting, CI, SSH workflows, and direct access to advanced engineering APIs. Use `commands --category CATEGORY` for discovery and `describe COMMAND` for machine-readable schema/example metadata. The complete command list and global option semantics are documented in `ADVANCED_API_CLI_COMMANDS.md`.

## V16 graphical command adapters

V16 preserves the same canonical command registry and adds only nested GUI-support operations. The graphical browser never invents a second command namespace: docking mutations, semantic analysis, scenario resizing, workflow graph/debug inspection, calibration inspection, and track/lap extraction are submitted through the standard dispatcher. New nested forms include `ui semantic json`, `ui desktop activate`, `ui desktop reorder`, `ui scenario-timeline resize`, `ui workflow-editor json`, `ui workflow-debugger json`, `ui calibration-correlation json`, and `ui run-compare track-json`. Existing aliases, completion behavior, canonical roots, and legacy command contracts remain valid. See `ENGINEERING_UI_PLATFORM.md`.

## V19 help-generation contract

The canonical command registry is also the root of the detailed-help system. Root metadata supplies category, summary, aliases, mutability, and typed parameters. Nested completion rules supply literal subcommand/value grammar. The V19 help renderer combines both so `help <path>` and the completion detail pane cannot independently invent command semantics.

Extension rule: register one canonical root, add aliases only for compatibility, provide a precise root summary/category, define typed parameter constraints where applicable, and add nested literal grammar. Common operation descriptions (`status`, `validate`, `create`, `run`, `export`, `json`, `lod`, and similar) are generated centrally; add operation-specific wording only when the common semantic would be inaccurate. New parser-visible behavior should be covered by completion reachability and a help regression, not by a duplicated standalone command table.

Operator discovery surfaces are intentionally distinct: Tab is context completion, F2 is universal action search, `help search <term>` is command/subcommand search, and `command-schema complete <prefix>` is the machine-readable completion interface.


## V20.1.2 universal palette and CLI/GUI equivalence

The universal palette is now a federated **discovery** surface but not a federated command executor. In the terminal, the palette uses the same detailed-help authority as `help <path>` and Canonical Command Completion: wide terminals show matching commands on the left and a scrollable full-help pane for the selected parent/subcommand on the right; narrow terminals stack the same information. PageUp/PageDown scroll the selected-command help without moving the palette selection. This removes the former one-line-description limitation without introducing a second help registry.

`Screen::universal_palette()` merges:

1. the existing Experience Manager action/command index; and
2. `StructuredGlobalSearch`, which contains workbench, signal, diagnostic, run-management, and engineering-object metadata.

Results are deduplicated by canonical invocation, ranked, and passed through `UiAccessPolicy`. Therefore a structured engineering result cannot bypass the same capability or safety restrictions that apply when the command is typed directly.

```text
ui palette battery temperature
ui palette time checkpoint
ui palette regression
```

`CliGuiEquivalenceRegistry` complements discovery by making GUI action mappings inspectable:

```text
ui equivalence list
ui equivalence search dashboard
ui equivalence show dashboard.save
```

A mapping never executes simulator logic itself. The terminal palette, browser workbenches, help/completion system, and direct CLI all converge on canonical commands. New UI actions must therefore register or reference an existing canonical command rather than embedding independent model mutations in the frontend.


## Research-grade engineering UI command families

The interactive completion registry includes the following canonical `ui` families: `formal-verification`, `field-visualization`, `jacobian-inspector`, `distributed-trace`, `hpc-placement`, `safety-analysis`, `temporal-bisection`, `contract-monitor`, `state-machine`, `numerical-trust`, `run-lineage`, `realtime-deadline`, `cosim-sync`, `coverage-explorer`, `cyber-attack`, `engineering-notebook`, `report-composer`, `crdt-collaboration`, `plugin-manager`, `migration-center`, `dependency-heatmap`, `performance-investigator`, `divergence-investigator`, `failure-clustering`, `twin-measurement`, `alert-rules`, `product-line`, and `control-room`.

Browser action metadata uses these exact shell forms. Commands requiring arguments are templates in the schema and are not executed until the operator supplies those arguments. Plugin and configuration migration remain top-level canonical commands (`plugin ...`, `config ...`) and are intentionally not reimplemented as nested UI commands.

## V46 browser schema metadata and structured analysis actions

V46 adds browser presentation metadata to workbench schema without changing the canonical root-command compatibility policy. `WorkbenchSchema` can advertise a renderer name plus accepted/produced engineering-object types. These values describe how the browser presents and composes existing commands; they are not additional dispatch registries and do not grant permission to execute a command.

The V46 Time-Frequency / Spectrogram Laboratory also adds the structured nested action:

```text
ui spectrogram json <signal>
```

This action exposes bounded JSON returned by the existing C++ `TimeFrequencySpectrogramWorkbench`, including sample rate, window/hop metadata and per-frame frequency/magnitude bins/peak frequency. The browser uses this payload for its heatmap and dominant-frequency plot. FFT/spectral computation remains in the canonical C++ authority.

Other V46 native workbenches use the pre-existing command families such as `ui protocol-trace`, `ui control-stability`, `ui identifiability`, `ui estimator-consistency`, `ui latency-budget`, `ui schema-evolution`, `ui determinism-audit`, `ui numerical-trust`, `ui metamorphic-tests`, `ui source-trace`, `ui checkpoint-store`, `ui compare`, `ui workspace-snapshot`, and `ui command-stage`.

### Completion-popup regression under load

The user-visible completion contract has not been weakened. Test `completion_popup_scroll_pty` was changed from fixed post-input sleeps to semantic state waits after an intermittent full-suite race was reproduced under concurrent PTY load. Initial popup readiness now requires the candidate/selection/description state row, and each selection/detail-scroll action is verified only after its expected state transition is observed. This makes the test deterministic across slow or contended hosts while preserving the original functional assertions.

## V47 performance command-family integration

The canonical completion/registry surface now includes `ui tire-traction json` and `ui acceleration-performance` operations `json`, `sensitivity`, `convergence`, `monte-carlo`, and `calibrate`. These routes are registered through the existing nested command/completion machinery and do not add a second command parser.

The engineering-UI source contract is 113 features for the V47 browser revision. The V46 completion-popup PTY hardening remains unchanged: synchronization waits on semantic popup state and is independent of the new performance commands.


## V47.1 strict performance numeric parsing

`ui tire-traction` and `ui acceleration-performance` require full-token finite conversion for scalar options, profiles, Monte Carlo samples/seeds/sigma, convergence tolerance, sensitivity fraction and calibration iteration count. Inputs such as `mu=1.2junk`, `sigma=nan`, or partially numeric profile fields are rejected. This prevents C++ standard conversion routines from silently accepting valid numeric prefixes followed by garbage.

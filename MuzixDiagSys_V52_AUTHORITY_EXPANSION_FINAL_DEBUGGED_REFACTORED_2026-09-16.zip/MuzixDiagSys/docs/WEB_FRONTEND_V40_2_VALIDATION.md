# MuzixDiagSys V40.2 Web Frontend Validation

**Current-status note (2026-09-09):** This document remains the authoritative historical record for the V40.2 validation record tranche. The current browser workstation is **V46**. V46 preserves these behaviors and adds structured schema-driven renderers, typed engineering-object drag/drop, transaction/autosave/recovery/deep-link infrastructure, integrated preflight/evidence/comparison/timeline/snapshot workflows, native V45 engine/transmission/four-corner views, and native research-grade analysis workbenches. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105 for current operation and qualification. Release-specific assertions in this document should not be read as a complete V46 feature inventory.

> **Historical validation record:** V40.2 remains the validated foundation release. V40.3 adds operations/investigation workbench upgrades and the Signal Explorer selection repair; see [`WEB_FRONTEND_V40_3_VALIDATION.md`](WEB_FRONTEND_V40_3_VALIDATION.md).


Release date: 2026-08-28

## Scope validated

The V40.2 frontend tranche modifies the embedded browser application in `src/ui/engineering_ui_platform.cpp`, extends the browser/source regression tests, and adds operator documentation. The native `BrowserEngineeringServer`, canonical command dispatcher, and HTTP endpoint set remain unchanged.

## Validation results

- JavaScript extraction and `node --check`: **PASS**.
- `tests/engineering_ui_platform_regression.py`: **PASS**, reporting `ENGINEERING_UI_PLATFORM_SOURCE_REGRESSION_PASS features=93 gui=v20.1.2+professional-operator-tui`.
- CMake Release/Ninja configuration: **PASS**.
- Direct native compilation of `src/ui/engineering_ui_platform.cpp`: **PASS**.
- Direct native compilation of `tests/engineering_ui_platform_tests.cpp`: **PASS**.
- Full `engineering_ui_platform_tests` dependency target build and link: **PASS**.
- Native served-page/unit executable `engineering_ui_platform_tests`: **PASS**, reporting `ENGINEERING_UI_PLATFORM_PASS features=93`.
- Browser endpoint regression remains restricted to `/api/state`, `/api/schema`, `/api/stream`, and `/api/command`.
- Display-unit profiles remain presentation-only; canonical telemetry CSV values and backend state are not converted or rewritten.
- Temporary CMake/Ninja build output was removed before packaging.

## V40.2 regression coverage added

Regression guards now require the global engineering omnibox, Analysis Presets, engineering display-unit profiles, synchronized selected-signal/time-range context, enhanced Signal Explorer, telemetry range brushing, enhanced Run Manager browser, V40.2 branding, and continued canonical command routing.

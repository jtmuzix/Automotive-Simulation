# MotoGP Engineering and Research Authority — Phases A–J

## Purpose

MotoGP is now a first-class authoritative subsystem rather than only a generic `ExpandedMotorsportPlatform` discipline profile. The pre-existing generic motorcycle/rider and expanded-motorsport implementations remain intact; the new authority is additive and exposed through the `motogp` CLI root.

```cpp
#include "aesim/advanced/motogp_authority_platform.hpp"

aesim::advanced::motogp::MotoGpAuthorityPlatform platform;
auto caps = platform.capabilities();
auto dynamics = platform.execute("multibody-dynamics", request, "evidence/motogp");
```

```bash
muzixdiagsys_advanced_platform motogp capabilities
muzixdiagsys_advanced_platform motogp multibody-dynamics request.json report.json evidence/motogp
```

## Phase inventory

| Phase | Canonical domain | Implemented scope |
|---|---|---|
| A | `multibody-dynamics` | Coupled translation, roll/pitch/yaw, nonlinear steering/trail/rake, fork/shock states, rider lateral motion, wheelie/stoppie margins |
| B | `tire-contact-mechanics` | Combined longitudinal/lateral slip, camber thrust, load/temperature/pressure/wear sensitivity, aligning moment, high-side/low-side indicators |
| C | `powertrain-driveline` | V4/inline-four firing pulse model, indicated/BMEP torque, seamless gearbox, slipper clutch, chain elasticity/tension/anti-squat |
| D | `electronics-controls` | Deterministic ECU loop, wheel-speed/IMU sensing, traction control, wheelie control, engine braking and intervention accounting |
| E | `aerodynamics` | Lean/pitch/yaw/ride-height coefficients, rider tuck, wake/slipstream, downforce distribution, crosswind force/moments |
| F | `rider-digital-twin` | Articulated torso/pelvis/head/arms/legs masses, hang-off optimization, confidence, fatigue, reaction delay, thermal/hydration physiology |
| G | `circuit-race-physics` | Spatial segments, grade/bank/radius/roughness, rain/water-film grip, racing-line offset, lap integration, multi-bike wake/pass probability |
| H | `telemetry-engineering` | Existing professional telemetry interop, lap detection, inverse grip/curvature identification, bounded multi-parameter setup optimization |
| I | `operations-rules-safety` | Dated 2026/2027 rule profiles, scrutineering, Sprint/GP/session operation, bike swaps, penalties, runoff/slide/airbag safety estimates |
| J | `2027-research-laboratory` | 2026-vs-2027 1000/850 cc comparison, aero/tire/fuel effects, Michelin→Pirelli transition, historical eras, explicitly non-competition what-if cases |

## Phase A: motorcycle multibody and steering

The solver integrates speed and global position with roll, pitch, yaw, their rates, steering angle/rate, front-fork travel, rear-shock travel, rider lateral displacement and vertical motion. Front/rear normal loads change with longitudinal acceleration and aero. Steering torque is acted on by trail/alignment, steering damping and gyroscopic terms; tire forces feed roll/yaw moments. The implementation therefore models countersteering and load migration as coupled dynamics rather than a prescribed lean-angle curve.

## Phase B: motorcycle tire mechanics

The tire law computes longitudinal force, lateral force, camber thrust and aligning moment from normal load, slip ratio, slip angle, camber, effective friction, temperature, pressure and wear. Combined-slip saturation enforces a friction envelope. A thermal/pressure update estimates post-interval tire temperature, pressure and wear; front/rear utilization feeds low-side/high-side risk indicators.

## Phase C: powertrain and chain

The four-stroke engine derives mean torque from displacement and BMEP and superimposes crank-angle firing pulses across 720 degrees. V4 and inline-four phasing are separately selectable. Gear ratios are explicit, seamless-shift overlap preserves a modeled torque fraction, engine speed falls with the selected next ratio, and the slipper clutch limits negative engine-brake torque. Chain tension, elastic extension, torsional mode and swingarm-angle anti-squat force are calculated.

## Phase D: ECU and controls

The deterministic control loop generates noisy/biased wheel-speed and IMU observations, estimates rear slip and pitch, and combines traction-control and wheelie-control torque reductions. Engine-brake torque is modeled under closed throttle/braking. Reports include intervention cycles, ECU compute utilization/deadline status, peak state values, energy withheld by intervention and a time trace.

## Phase E/F: aero and rider

Aerodynamic coefficients vary with lean, pitch, yaw, ride height and rider tuck. Wake strength depends on leader separation and lateral offset; wake alters drag and downforce. Crosswind produces side force and roll moment.

The rider model allocates rider mass among five articulated lumped segments and performs a bounded hang-off search to reduce required motorcycle lean subject to aero/effort cost. Tire margin, prior slides, wind and tire-temperature error determine confidence; session duration, braking, steering and ambient heat determine fatigue, core temperature, sweat loss, hydration, reaction delay and control precision.

## Phase G/H: circuit, racecraft and engineering data

Circuit segments include length, radius, grade, bank, dry friction, water film and roughness. Rain/evaporation evolve water film, which reduces grip with speed. Segment target speed and lean are solved from the available lateral envelope; an acceleration/braking traversal estimates lap time. Multi-bike output includes wake tow and pass probability.

Phase H uses `MotorsportTelemetryInterop`, reusing Generic CSV, MoTeC, McLaren ATLAS, Cosworth and MDF4 ingestion. It normalizes units and detects laps, then estimates effective friction/curvature and evaluates a finite setup search over rake, trail, fork/rear stiffness scales and engine-map aggression.

## Dated MotoGP rules profiles

The authority includes:

- `motogp-2026-pre-assen`
- `motogp-2026-post-assen-pre-germany`
- `motogp-2026-post-germany`
- `motogp-2027`

The dated transitions are deliberate. MotoGP announced the 2026 holeshot-device prohibition from the Dutch GP and the subsequent grid-spacing change from the German GP. The 2027 profile models the FIM/MotoGP technical reset: 850 cc, 75 mm maximum bore, six engines per rider, 20 L race fuel, non-fossil fuel requirement, no ride-height/holeshot devices, tighter aero and Pirelli as sole supplier. The `aero_freedom_factor` is an internal research scaling parameter—not an official regulatory percentage.

Official public provenance:

- FIM Grand Prix Commission, 6 May 2024 (2027 850 cc / 75 mm technical decisions): https://www.fim-moto.com/fileadmin/user_upload/Documents/2024/Decisions_of_the_Grand_Prix_Commission__06_May_2024.pdf
- MotoGP 2027 rules overview: https://www.motogp.com/en/news/2024/05/06/motogp-announces-new-regulations-for-2027/497238
- MotoGP Pirelli 2027–2031 sole-supplier announcement: https://www.motogp.com/en/news/2025/03/06/pirelli-to-become-motogp-tyre-supplier-from-2027/520917
- MotoGP 2026 holeshot/grid decision: https://www.motogp.com/en/news/2026/06/22/holeshot-devices-banned-from-assen-grid-layout-to-change-from-germany/1074671

This simulation rules layer does not replace the controlling FIM Grand Prix Regulations, bulletins, technical directives, event instructions or official decisions.

## Historical and what-if research

Phase J supports explicit historical research labels (`500cc-two-stroke`, `990cc-four-stroke`, `800cc-four-stroke`, `1000cc-four-stroke`, `850cc-four-stroke`). Arbitrary displacement exploration is accepted only as a separate `NON_COMPETITION_RESEARCH` result so hypothetical engineering cannot be mistaken for a legal MotoGP configuration.

## Validation

```bash
cmake --build build/full --parallel --target \
  motogp_authority_platform_tests \
  muzixdiagsys_advanced_platform \
  muzixdiagsys

ctest --test-dir build/full --output-on-failure \
  -R 'motogp_authority|interactive_advanced_motorsport'
```

The C++ authority test executes all A–J phases, writes and ingests a temporary telemetry dataset through the real professional telemetry adapter, checks 2026 compliance and 2027 displacement state, runs the complete self-test and confirms infinity rejection.

## Source modules

- `include/aesim/advanced/motogp_authority_platform.hpp`
- `src/advanced/motogp_authority_internal.hpp`
- `src/advanced/motogp_authority_platform.cpp`
- `src/advanced/motogp_authority_a_b.cpp`
- `src/advanced/motogp_authority_c_d.cpp`
- `src/advanced/motogp_authority_e_f.cpp`
- `src/advanced/motogp_authority_g_h.cpp`
- `src/advanced/motogp_authority_i_j.cpp`
- `tests/motogp_authority_platform_tests.cpp`

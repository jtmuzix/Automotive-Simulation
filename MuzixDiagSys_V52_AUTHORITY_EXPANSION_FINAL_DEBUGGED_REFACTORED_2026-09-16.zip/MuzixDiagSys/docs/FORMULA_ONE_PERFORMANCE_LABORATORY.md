# Formula One Performance, Correlation, and Driver Laboratory

## Scope

This additive advanced-platform module provides five executable Formula One engineering systems:

1. Gearbox, differential, clutch, and launch-performance simulation.
2. Wind-tunnel, CFD, and track-correlation analysis.
3. Driver behavior, biomechanics, and driver-in-the-loop session evaluation.
4. Cooling, packaging, mass, and ballast co-optimization.
5. Cylinder-resolved sustainable-fuel combustion and turbocharger gas-path physics.

The module does not replace the existing FIA compliance, 2026 energy-management, active-aerodynamic, tire/track, race-strategy, suspension, brake, telemetry, circuit, or reliability systems.

## Public API

Include either:

```cpp
#include "aesim/advanced/formula_one_performance_laboratory.hpp"
```

or the umbrella header:

```cpp
#include "aesim/advanced/platform.hpp"
```

All result records provide `to_document()` serialization. Qualification-oriented top-level results also contain a deterministic SHA-256 evidence field calculated from canonical JSON.

## Driveline and launch laboratory

`F1DrivelineLaboratory` models an eight-speed sequential gearbox, final drive, finite shift interruption, torsional compliance, clutch capacity/slip/temperature/wear, power/coast differential locking, torque bias, tire-friction limits, longitudinal acceleration, and anti-stall clutch relief.

Call `step` at a fixed or variable integration interval while retaining `F1DrivelineState`. Gear requests initiate a finite-duration shift. The returned wheel torques are limited independently by left and right normal load and friction.

`simulate_launch` evaluates a clutch/throttle/differential candidate through a complete launch. `optimize_launch` ranks candidate maps using 0-100 km/h and 0-200 km/h time, clutch energy, clutch temperature, slip, and feasibility.

## Aerodynamic correlation laboratory

`F1AeroCorrelationLaboratory` accepts matched CFD, wind-tunnel, and track operating points. Wind-tunnel observations receive model-support, blockage, moving-ground, boundary-layer, and force-balance corrections.

The correlation engine performs weighted ridge-regularized least squares for lift, drag, and front balance. The model includes scale, bias, ride-height sensitivity, and yaw sensitivity. Results include RMSE, normalized chi-square, pressure-tap RMSE, outlier IDs, source counts, a bounded correlation score, and evidence.

Use identical operating-point IDs to match CFD predictions to wind-tunnel or track observations.

## Driver and driver-in-the-loop laboratory

`F1DriverInLoopLaboratory` closes the loop between previewed curvature, lateral and heading error, vehicle speed, grip, water, workload, visual occlusion, simulator latency, and driver controls.

The driver state includes steering, throttle, brake, cognitive load, fatigue, core temperature, hydration, neck load, reaction time, and accumulated path error. Driver profile parameters cover preview, steering response, pedal behavior, trail braking, risk, tire management, wet skill, consistency, neck strength, and heat tolerance.

`run_session` returns error statistics, fatigue and thermal maxima, neck loading, reaction time, control smoothness, limited-performance step count, final state, and evidence.

The biomechanics model is an engineering workload model, not a medical diagnostic tool.

## Cooling, packaging, mass, and ballast optimization

`F1CoolingPackagingOptimizer` combines thermal components, cooling circuits, package volumes, movable components, and ballast candidates.

For each duty point the evaluator computes component heat generation, radiator air-side effectiveness, coolant flow capacity, heat rejection, component temperature evolution, pump energy, and cooling drag. Packaging evaluation calculates axis-aligned volume overlap, total mass, center of gravity, and yaw inertia.

`optimize` selects the minimum objective candidate after thermal and packaging penalties. The objective combines cooling drag, mass, yaw inertia, pump energy, overlap, temperature exceedance, and center-of-gravity height.

## Cylinder-resolved sustainable-fuel power unit

`F1CylinderResolvedPowerUnit` models a six-cylinder four-stroke engine over a 720-degree firing cycle. Each cylinder maintains pressure, temperature, trapped mass, burned fraction, knock index, and cumulative indicated work.

The solver includes slider-crank volume, compression/expansion, Wiebe heat release, sustainable-fuel properties, wall heat transfer, friction mean effective pressure, cylinder torque, knock limitation, compressor power, turbine power, turbo shaft inertia, wastegate response, manifold pressures, manifold temperatures, fuel use, brake power, and brake thermal efficiency.

Use sufficiently small time steps to resolve crank-angle combustion. `simulate_cycle` provides a sequential trace while preserving full cylinder and turbo state.

## Build and validation

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --target formula_one_performance_laboratory_tests -j
ctest --test-dir build -R formula_one_performance_laboratory_unit_tests --output-on-failure
```

The dedicated suite verifies torque transfer, differential action, clutch heating, launch optimization, aero correlation, pressure residuals, driver workload and biomechanics, cooling/package optimization, sustainable-fuel consumption, cylinder pressure, turbo spool, and evidence generation.

## Limitations and interpretation

The module provides executable engineering reference models. Wind-tunnel and track correlation requires representative measured data and uncertainty estimates. Driver biomechanics are simplified workload indicators. Package collision uses oriented-to-vehicle axis-aligned boxes. The combustion model is crank-angle resolved but does not replace proprietary three-dimensional reactive CFD or physical dynamometer testing.

## V47 general straight-line performance integration note

The V47 `tire-traction-lab` and `acceleration-performance-lab` provide general four-wheel straight-line launch/performance analysis. They reuse canonical tire/chassis/transmission/track authorities but do not replace the Formula One Performance Laboratory's lap, aero, energy-deployment, race-engineering or F1-specific tire workflows. Use V47 when the engineering question is launch/straight-line ET/traction correlation; use this laboratory for Formula One race-performance analysis.

# MuzixDiagSys Professional Web Shell V40

**Current-status note (2026-09-09):** This document remains the authoritative historical record for the V40 professional shell tranche. The current browser workstation is **V46**. V46 preserves these behaviors and adds structured schema-driven renderers, typed engineering-object drag/drop, transaction/autosave/recovery/deep-link infrastructure, integrated preflight/evidence/comparison/timeline/snapshot workflows, native V45 engine/transmission/four-corner views, and native research-grade analysis workbenches. See `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 105 for current operation and qualification. Release-specific assertions in this document should not be read as a complete V46 feature inventory.

The MuzixDiagSys browser engineering desktop remains a canonical-model projection served by `BrowserEngineeringServer` in `src/ui/engineering_ui_platform.cpp`. The V40 professional shell enhancement is additive: it does not create a second backend, duplicate engineering authorities, or bypass role-aware canonical command execution.

## Operator-facing improvements

- Professional dark engineering-workstation visual system with stronger hierarchy, higher contrast, refined spacing, consistent controls, and dense data presentation.
- Persistent left workbench navigator, right engineering inspector, and command-console visibility controls.
- Persistent compact/comfortable browser-shell density selection.
- Fast workspace action bar for Command Palette, Live Operations, Signal Explorer, Requirements, Run Comparison, and Qualification workbenches.
- Collapsible sidebar cards with per-panel persistence in browser local storage.
- Reworked command console with a dedicated header, clear control, collapse/expand control, stronger command input emphasis, and preserved staging/access semantics.
- Connection-state indicator integrated into the header.
- Improved workbench cards, dock tabs, grids, metrics, graph/canvas surfaces, toast notifications, problem rows, floating panes, and selected/focused states.
- Keyboard navigation and visible focus treatment for improved operator ergonomics.
- Responsive behavior for narrower engineering workstations and laptop displays.
- Reduced-motion support for operators who request it through OS/browser accessibility preferences.
- No external web libraries, fonts, CDNs, or network dependencies were added; the existing restrictive CSP remains compatible with the shell.

## Browser-shell controls

| Control | Action |
| --- | --- |
| Header `L` | Show/hide the workbench navigator |
| Header `C` | Show/hide the command console |
| Header `R` | Show/hide the engineering inspector |
| Header `≡` | Toggle compact/comfortable shell density |
| `Ctrl/Cmd+B` | Toggle workbench navigator |
| `Ctrl/Cmd+J` | Toggle command console |
| `Ctrl/Cmd+I` | Toggle engineering inspector when focus is not in an editor/input |
| `/` | Focus the workbench filter when focus is not in an editor/input |
| `Ctrl/Cmd+K` | Existing workbench filter shortcut |
| `Ctrl/Cmd+L` | Existing canonical command-line shortcut |
| `Ctrl/Cmd+Shift+P` | Existing Command Palette shortcut |
| `Ctrl/Cmd+Shift+O` | Existing Live Operations shortcut |
| `Ctrl/Cmd+Shift+R` | Existing Requirements & Evidence shortcut |
| `Ctrl/Cmd+Shift+C` | Existing Run Comparison shortcut |
| `Ctrl/Cmd+Shift+Q` | Existing Qualification Dashboard shortcut |

Shell preferences are stored under the browser-local key `muzixProfessionalWebShellV40`. Existing command history, watchlist, favorites, canonical authorization, linked cursors, telemetry, workbench docking, and workspace persistence remain unchanged.

## Architecture and feature-preservation constraints

The browser remains a thin adapter over the existing `/api/state`, `/api/schema`, `/api/stream`, and `/api/command` endpoints. New shell controls only affect browser presentation state. Engineering workbench actions continue to route through the existing canonical commands, `semanticInfo`, `authorizedCommand`, and shared engineering-context mechanisms.

The implementation deliberately preserves the existing `MuzixDiagSys Engineering Desktop V19` compatibility marker and V19 workbench assets because regression coverage and downstream tooling use those identifiers to verify feature retention.

## Validation added/used

- `tests/engineering_ui_platform_regression.py` now asserts retention of the V40 professional-shell implementation markers and controls.
- `tests/engineering_ui_platform_tests.cpp` now verifies that professional-shell assets are present in the served browser page.
- `src/ui/engineering_ui_platform.cpp` and `tests/engineering_ui_platform_tests.cpp` were independently compiled as C++ translation units during the V40 shell integration validation.
- Embedded browser JavaScript was syntax-checked with Node.js.
- Existing engineering UI source regression passes with the V40 shell present.


## V40.2 engineering workspace foundation

The professional shell now adds an integration layer over the existing canonical workbenches rather than duplicating their authorities. The global engineering search (`Ctrl/Cmd+Shift+K` or `?` outside an editor) searches registered workbenches, browser-discovered canonical signals, recent canonical commands, and common engineering actions. Selecting an item routes to the existing workbench or command path.

The Shared Engineering Context now carries a bounded selected-signal set and a synchronized time range in addition to the existing primary/A/B linked cursors. In the telemetry scope, click sets cursor A, Shift-click sets cursor B, Shift-drag brushes a shared time range, wheel zooms, and ordinary drag pans. Participating panes receive context/range/unit callbacks without introducing a second backend state model.

Display-unit profiles are presentation-only: Canonical, Metric engineering, and US motorsport. Browser cards, signal values, and telemetry scale labels can be converted for operator readability while `/api/state`, `/api/stream`, canonical commands, telemetry export, simulation state, and persistence remain in canonical units.

Browser Analysis Presets persist a named operator view containing the display-unit profile, watchlist, selected signals, shared context/cursors/range, and active workbench hint. Restoring a preset uses existing `ui linked-cursor` and desktop workbench commands where backend mutation is required; presets do not create an alternate simulation or desktop authority.

## V40.3 continuation

The V40 professional shell remains the presentation foundation retained by later browser releases. V40.3 kept these shell controls/persistence while upgrading operations/investigation behavior; V41-V44 added professional workstation UX, and V46 is the current integrated browser layer. See `WEB_FRONTEND_ENGINEERING_OPERATIONS_V40_3.md` for the historical V40.3 tranche and `ENGINEERING_UI_PLATFORM.md` for current V46 behavior.


#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::motogp {

// Dedicated MotoGP Phases A-J authority. It is additive to the generalized
// motorcycle and V35 motorsport surfaces and deliberately reuses shared
// telemetry/numerical services instead of introducing duplicate frameworks.
class MotoGpAuthorityPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::motogp

#pragma once

#include "aesim/advanced/frontier_systems_platform.hpp"
#include "aesim/advanced/v50_reality_authority.hpp"
#include "aesim/core/calibration.hpp"
#include "aesim/core/validation.hpp"
#include "aesim/professional/checkpoint.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// V51-A - numerical verification and validation composition.
// -----------------------------------------------------------------------------

enum class V51TransportVerificationScheme { FirstOrderUpwind, MusclMinmod, MusclVanLeer };

struct V51ConvergencePoint {
    std::size_t cells = 0;
    double time_step_s = 0.0;
    double l1_error = 0.0;
    double l2_error = 0.0;
    double linf_error = 0.0;
    double conserved_mass_error = 0.0;
};

struct V51VerificationConfiguration {
    std::vector<std::size_t> spatial_grids{24,48,96};
    std::vector<double> temporal_steps_s{2.0e-3,1.0e-3,5.0e-4};
    double final_time_s = 0.04;
    double advection_speed_m_s = 0.7;
    double diffusivity_m2_s = 2.5e-3;
    V51TransportVerificationScheme transport_scheme = V51TransportVerificationScheme::MusclVanLeer;
    double minimum_observed_spatial_order = 1.55;
    double minimum_observed_temporal_order = 1.70;
    double maximum_manufactured_l2_error = 2.0e-3;
    double maximum_normalized_mass_residual = 5.0e-3;
    double maximum_normalized_energy_residual = 5.0e-2;
};

struct V51VerificationReport {
    std::vector<V51ConvergencePoint> spatial;
    std::vector<V51ConvergencePoint> temporal;
    double observed_spatial_order = 0.0;
    double observed_temporal_order = 0.0;
    double normalized_mass_residual = 0.0;
    double normalized_energy_residual = 0.0;
    bool manufactured_solution_passed = false;
    bool conservation_passed = false;
    bool passed = false;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51VerificationAuthority {
public:
    [[nodiscard]] V51VerificationReport verify_transport_and_conservation(
        const V51VerificationConfiguration& configuration,
        const V50RealityState* reality_state = nullptr) const;
    [[nodiscard]] core::ValidationResult validate_measured_dataset(
        const core::ValidationDataset& dataset,
        const core::ValidationFramework::Predictor& predictor,
        const std::vector<core::ValidationRequirement>& requirements = {}) const;
    [[nodiscard]] core::ValidationResult validate_measured_csv(
        const std::string& path,
        const core::ValidationFramework::Predictor& predictor,
        const std::vector<core::ValidationRequirement>& requirements = {},
        std::string name = {}, std::string source = {}, std::string version = "1") const;
};

// -----------------------------------------------------------------------------
// V51-C - generic detailed chemistry, Lagrangian spray, and canonical CAE
// federation. These are optional fidelity providers; the V50 engine remains the
// canonical coupled engine authority.
// -----------------------------------------------------------------------------

struct V51ChemicalSpecies {
    std::string name;
    double molecular_weight_kg_mol = 0.02897;
    double constant_cv_j_kg_k = 750.0;
};

struct V51ArrheniusReaction {
    std::string id;
    std::vector<double> reactant_stoich;
    std::vector<double> product_stoich;
    double pre_exponential = 0.0;
    double temperature_exponent = 0.0;
    double activation_energy_j_mol = 0.0;
    double heat_release_j_mol = 0.0;
};

struct V51ChemistryMechanism {
    std::vector<V51ChemicalSpecies> species;
    std::vector<V51ArrheniusReaction> reactions;
    [[nodiscard]] static V51ChemistryMechanism gasoline_surrogate();
    [[nodiscard]] static V51ChemistryMechanism from_document(const doc::Value& document);
    [[nodiscard]] doc::Value to_document() const;
};

struct V51ChemistryConfiguration {
    std::size_t maximum_newton_iterations = 14;
    std::size_t maximum_substeps = 128;
    double relative_tolerance = 1.0e-7;
    double absolute_tolerance = 1.0e-10;
    double minimum_temperature_k = 220.0;
    double maximum_temperature_k = 4500.0;
};

struct V51ChemistryState {
    double temperature_k = 300.0;
    double pressure_pa = 101325.0;
    std::vector<double> mass_fractions;
    double integrated_heat_release_j_kg = 0.0;
    std::size_t accepted_substeps = 0;
    std::size_t newton_iterations = 0;
    bool converged = true;
    double normalized_species_residual = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51DetailedChemistryAuthority {
public:
    void configure(V51ChemistryMechanism mechanism, V51ChemistryConfiguration configuration = {});
    [[nodiscard]] V51ChemistryState advance(double density_kg_m3, double pressure_pa,
                                             double temperature_k,
                                             const std::vector<double>& mass_fractions,
                                             double dt_s) const;
    [[nodiscard]] const V51ChemistryMechanism& mechanism() const noexcept { return mechanism_; }
private:
    V51ChemistryMechanism mechanism_ = V51ChemistryMechanism::gasoline_surrogate();
    V51ChemistryConfiguration configuration_;
};

struct V51SprayConfiguration {
    std::size_t parcels_per_injection = 96;
    std::size_t maximum_parcels = 20000;
    double injector_orifice_diameter_m = 1.6e-4;
    double injection_velocity_m_s = 85.0;
    double initial_droplet_diameter_m = 55.0e-6;
    double liquid_density_kg_m3 = 740.0;
    double liquid_heat_capacity_j_kg_k = 2200.0;
    double latent_heat_j_kg = 3.2e5;
    double d2_evaporation_constant_m2_s = 1.2e-8;
    double breakup_weber_threshold = 12.0;
    double breakup_time_constant_s = 2.0e-4;
    double restitution = 0.15;
    std::uint64_t random_seed = 0x5100A5ULL;
};

struct V51SprayParcel {
    std::array<double,3> position_m{};
    std::array<double,3> velocity_m_s{};
    double diameter_m = 0.0;
    double mass_kg = 0.0;
    double temperature_k = 298.15;
};

struct V51SprayState {
    std::vector<V51SprayParcel> parcels;
    double liquid_mass_kg = 0.0;
    double vaporized_mass_kg = 0.0;
    double wall_deposited_mass_kg = 0.0;
    double escaped_mass_kg = 0.0;
    double mass_residual_kg = 0.0;
    std::uint64_t breakup_events = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_parcels = false) const;
};

class V51SprayAuthority {
public:
    void configure(V51SprayConfiguration configuration,
                   high_fidelity::EngineResearchConfiguration engine_configuration);
    void reset();
    void inject(double fuel_mass_kg, double fuel_temperature_k);
    [[nodiscard]] const V51SprayState& advance(double gas_temperature_k,
                                               double gas_density_kg_m3,
                                               const std::array<double,3>& gas_velocity_m_s,
                                               double chamber_height_m,
                                               double dt_s);
    [[nodiscard]] const V51SprayState& state() const noexcept { return state_; }
private:
    V51SprayConfiguration configuration_;
    high_fidelity::EngineResearchConfiguration engine_configuration_;
    V51SprayState state_;
    std::mt19937_64 rng_{0x5100A5ULL};
    double injected_mass_kg_ = 0.0;
};

struct V51CfdReferenceConfiguration {
    std::string solver = "openfoam";
    std::string working_directory = "v51-cfd-reference";
    bool require_solver_available = false;
    double timeout_s = 120.0;
    double residual_tolerance = 1.0e-6;
};

struct V51CfdReferenceResult {
    bool available = false;
    bool executed = false;
    bool passed = false;
    std::string solver;
    std::string case_directory;
    double residual = 0.0;
    double elapsed_s = 0.0;
    std::string evidence_sha256;
    doc::Value native_result{doc::Value::Object{}};
    [[nodiscard]] doc::Value to_document() const;
};

class V51CfdReferenceFederation {
public:
    [[nodiscard]] V51CfdReferenceResult execute(const V51CfdReferenceConfiguration& configuration) const;
    [[nodiscard]] doc::Value capabilities() const;
private:
    systems::ExternalCaeSolverFederation federation_;
};

// -----------------------------------------------------------------------------
// V51-D - hierarchical Bayesian calibration and measured validation.
// -----------------------------------------------------------------------------

struct V51HierarchicalObservation {
    std::string id;
    std::string group;
    std::map<std::string,double> inputs;
    std::map<std::string,double> observed;
    std::map<std::string,double> standard_deviation;
};

struct V51BayesianCalibrationConfiguration {
    std::size_t chains = 4;
    std::size_t warmup = 300;
    std::size_t samples_per_chain = 700;
    std::size_t thinning = 1;
    double proposal_scale = 0.04;
    double group_prior_sigma = 0.10;
    double discrepancy_prior_sigma = 0.05;
    std::uint64_t random_seed = 0x51BA7E5ULL;
};

struct V51PosteriorParameter {
    std::string name;
    double mean = 0.0;
    double sd = 0.0;
    double q025 = 0.0;
    double median = 0.0;
    double q975 = 0.0;
    double rhat = 1.0;
    double effective_sample_size = 0.0;
};

struct V51BayesianCalibrationResult {
    bool converged = false;
    std::size_t retained_samples = 0;
    std::vector<V51PosteriorParameter> parameters;
    std::map<std::string,double> group_bias_mean;
    double discrepancy_sigma_mean = 0.0;
    double mean_acceptance_fraction = 0.0;
    core::ValidationResult posterior_predictive_validation;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51HierarchicalBayesianCalibrator {
public:
    using Model = core::CalibrationOptimizer::Model;
    [[nodiscard]] V51BayesianCalibrationResult calibrate(
        const std::vector<V51HierarchicalObservation>& observations,
        const std::vector<core::CalibrationParameter>& parameters,
        const Model& model,
        const V51BayesianCalibrationConfiguration& configuration = {}) const;
};

// -----------------------------------------------------------------------------
// V51-E/F - automatic fidelity promotion, checkpoint/replay, and scalable
// ensemble execution. Complex vehicle authority instances remain host objects;
// canonical OpenMP/Kokkos kernels are used for deterministic ensemble reductions.
// -----------------------------------------------------------------------------

enum class V51FidelityLevel : std::uint8_t { V50Reference=0, HighOrderAdaptive=1, DetailedChemistrySpray=2, ExternalCfdReference=3 };

struct V51FidelityPolicy {
    V51FidelityLevel minimum = V51FidelityLevel::V50Reference;
    V51FidelityLevel maximum = V51FidelityLevel::DetailedChemistrySpray;
    double promote_mass_residual = 2.5e-3;
    double promote_energy_residual = 2.0e-2;
    double promote_gradient_indicator = 0.12;
    double promote_sotif_relative_interval = 0.75;
    double demote_hysteresis = 0.45;
    std::size_t minimum_steps_between_transitions = 8;
};

struct V51FidelityDecision {
    V51FidelityLevel level = V51FidelityLevel::V50Reference;
    bool promoted = false;
    bool demoted = false;
    double score = 0.0;
    std::vector<std::string> reasons;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51FidelityController {
public:
    explicit V51FidelityController(V51FidelityPolicy policy = {});
    void configure(V51FidelityPolicy policy);
    void reset(V51FidelityLevel initial = V51FidelityLevel::V50Reference);
    [[nodiscard]] V51FidelityDecision decide(const V50RealityState& state);
private:
    V51FidelityPolicy policy_;
    V51FidelityLevel current_ = V51FidelityLevel::V50Reference;
    std::size_t since_transition_ = 0;
};

enum class V51EnsembleBackend { Serial, ThreadedCpu, SimdBatch, OpenMp, Kokkos };

struct V51EnsembleConfiguration {
    V51EnsembleBackend backend = V51EnsembleBackend::ThreadedCpu;
    std::size_t maximum_workers = 0;
    bool deterministic_reduction = true;
};

struct V51EnsembleMember {
    V50RealityConfiguration configuration;
    V50RealityInput input;
    double dt_s = 0.001;
    std::size_t steps = 1;
};

struct V51EnsembleResult {
    std::vector<V50RealityState> members;
    std::map<std::string,double> means;
    std::map<std::string,double> standard_deviations;
    std::string backend;
    double elapsed_s = 0.0;
    bool accelerated_reduction = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_members = false) const;
};

class V51EnsembleExecutor {
public:
    [[nodiscard]] V51EnsembleResult execute(const std::vector<V51EnsembleMember>& members,
                                            const V51EnsembleConfiguration& configuration = {}) const;
    [[nodiscard]] doc::Value capabilities() const;
private:
    systems::PortableHeterogeneousKernelRuntime kernels_;
};

// -----------------------------------------------------------------------------
// V51-G - persistent service support and scientific field storage.
// -----------------------------------------------------------------------------

struct V51FieldStoreConfiguration {
    std::string format = "zarr";
    std::string path = "v51-fields.zarr";
    std::string working_directory;
    bool roundtrip_verify = true;
};

class V51ScientificFieldStore {
public:
    [[nodiscard]] doc::Value write(const V50RealityState& state,
                                   const V51FieldStoreConfiguration& configuration) const;
    [[nodiscard]] doc::Value capabilities() const;
private:
    systems::NativeScientificDataInterchangePlatform storage_;
};

// -----------------------------------------------------------------------------
// V51-I - hierarchical ODD/SOTIF risk and champion/challenger deployment
// governance composed with the existing MLOps authority.
// -----------------------------------------------------------------------------

struct V51OddContext {
    std::string id;
    double exposure_weight = 1.0;
    double weather_factor = 1.0;
    double lighting_factor = 1.0;
    double traffic_factor = 1.0;
    double sensor_contamination_factor = 1.0;
};

struct V51SotifGovernanceResult {
    double correlated_risk_mean = 0.0;
    double correlated_risk_p975 = 0.0;
    double epistemic_fraction = 0.0;
    std::map<std::string,double> odd_risk_contribution;
    bool escalation_required = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51SotifGovernanceAuthority {
public:
    [[nodiscard]] V51SotifGovernanceResult evaluate(const SotifExposureRiskState& base,
                                                     const std::vector<V51OddContext>& contexts,
                                                     double escalation_threshold_per_hour) const;
};

struct V51LearningGovernanceConfiguration {
    AiDeploymentPolicy deployment_policy;
    double minimum_conformal_coverage = 0.95;
    double maximum_ood_fraction = 0.05;
};

struct V51LearningGovernanceState {
    std::string deployment_id;
    AiDeploymentStage deployment_stage = AiDeploymentStage::Registered;
    double deployed_fraction = 0.0;
    double conformal_coverage = 0.0;
    double ood_fraction = 0.0;
    bool promotion_allowed = false;
    bool rollback_required = false;
    std::vector<std::string> decisions;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class V51ContinualLearningGovernor {
public:
    void configure(V51LearningGovernanceConfiguration configuration);
    void register_assets(const AiDatasetAsset& dataset, const AiModelAsset& champion,
                         const AiModelAsset& challenger, std::string deployment_id);
    [[nodiscard]] V51LearningGovernanceState observe(const ContinualLearningState& learning,
                                                     std::size_t observations,
                                                     double accuracy,
                                                     double violation_rate,
                                                     double drift_psi,
                                                     double conformal_coverage,
                                                     double ood_fraction);
private:
    V51LearningGovernanceConfiguration configuration_;
    VehicleCloudMlopsPlatform mlops_;
    std::string deployment_id_;
    std::string challenger_model_id_;
    bool registered_ = false;
};

// -----------------------------------------------------------------------------
// V51 integrated authority and exact process-local checkpoint manager.
// -----------------------------------------------------------------------------

struct V51RealityConfiguration {
    V50RealityConfiguration v50;
    V51VerificationConfiguration verification;
    V51ChemistryConfiguration chemistry;
    V51SprayConfiguration spray;
    V51FidelityPolicy fidelity;
    V51CfdReferenceConfiguration cfd;
    V51LearningGovernanceConfiguration learning_governance;
    bool enable_detailed_chemistry = true;
    bool enable_spray = true;
    bool enable_cfd_reference = false;
};

struct V51RealityInput {
    V50RealityInput v50;
    std::vector<V51OddContext> odd_contexts;
    double sotif_escalation_threshold_per_hour = 1.0e-4;
    double conformal_coverage = 1.0;
    double ood_fraction = 0.0;
};

struct V51RealityState {
    double time_s = 0.0;
    V50RealityState v50;
    V51FidelityDecision fidelity;
    V51ChemistryState representative_chemistry;
    V51SprayState spray;
    V51CfdReferenceResult cfd_reference;
    V51SotifGovernanceResult sotif_governance;
    V51LearningGovernanceState learning_governance;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class V51RealityAuthority {
public:
    V51RealityAuthority();
    explicit V51RealityAuthority(const V51RealityConfiguration& configuration);
    void configure(const V51RealityConfiguration& configuration);
    void reset(double ambient_pressure_pa = 101325.0, double ambient_temperature_k = 298.15);
    [[nodiscard]] const V51RealityState& step(const V51RealityInput& input, double dt_s);
    [[nodiscard]] const V51RealityState& state() const noexcept { return state_; }
    [[nodiscard]] const V51RealityConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] V51VerificationReport verify() const;
private:
    V51RealityConfiguration configuration_;
    V50RealityAuthority v50_;
    V51DetailedChemistryAuthority chemistry_;
    V51SprayAuthority spray_;
    V51FidelityController fidelity_;
    V51CfdReferenceFederation cfd_;
    V51SotifGovernanceAuthority sotif_governance_;
    V51ContinualLearningGovernor learning_governance_;
    V51VerificationAuthority verification_;
    V51RealityState state_;
    V51FidelityLevel last_level_ = V51FidelityLevel::V50Reference;
    bool cfd_executed_at_current_level_ = false;
};

struct V51CheckpointRecord {
    std::string name;
    checkpoint::Image image;
    V51RealityAuthority authority_snapshot;
};

class V51CheckpointManager {
public:
    [[nodiscard]] checkpoint::Image capture(std::string name, const V51RealityAuthority& authority);
    [[nodiscard]] bool restore(const std::string& name, V51RealityAuthority& authority) const;
    [[nodiscard]] bool save(const std::string& name, const std::string& path, std::string& error) const;
    [[nodiscard]] std::vector<std::string> names() const;
private:
    checkpoint::Store store_;
    std::map<std::string,V51CheckpointRecord> records_;
};

[[nodiscard]] const char* v51_fidelity_level_name(V51FidelityLevel level) noexcept;
[[nodiscard]] const char* v51_ensemble_backend_name(V51EnsembleBackend backend) noexcept;

} // namespace aesim::advanced

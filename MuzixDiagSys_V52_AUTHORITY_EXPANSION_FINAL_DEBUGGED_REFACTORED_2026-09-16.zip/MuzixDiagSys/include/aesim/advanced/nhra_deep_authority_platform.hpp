#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::nhra {

// Additive NHRA Phases A-J authority. The class composes the existing NHRA
// championship/race-engineering platforms and does not replace their APIs.
class NhraDeepAuthorityPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::nhra

#pragma once

#include "aesim/advanced/v50_reality_authority.hpp"
#include "aesim/professional/document.hpp"

namespace aesim::advanced::v50io {

[[nodiscard]] V50RealityConfiguration configuration_from_request(const doc::Value& request);
[[nodiscard]] V50RealityInput input_from_request(const doc::Value& request);
[[nodiscard]] doc::Value execute_request(const doc::Value& request);
[[nodiscard]] doc::Value self_test_request();

} // namespace aesim::advanced::v50io

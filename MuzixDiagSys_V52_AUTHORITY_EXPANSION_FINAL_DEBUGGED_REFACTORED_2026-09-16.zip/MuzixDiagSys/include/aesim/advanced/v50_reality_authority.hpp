#pragma once

#include "aesim/advanced/mlops_laboratory.hpp"
#include "aesim/advanced/multiphysics_tire.hpp"
#include "aesim/high_fidelity/engine_research_digital_twin.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <random>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// V50 3-D reactive chamber authority.
//
// This is an additive, structured finite-volume ALE chamber solver.  It uses
// the canonical EngineResearchDigitalTwin for gas exchange, crank-angle
// mechanics, reduced chemistry, controls and lifecycle; V50 resolves the
// in-cylinder spatial fields and returns correction/evidence quantities rather
// than introducing a second engine authority.
// -----------------------------------------------------------------------------

enum class ReactiveTransportScheme { FirstOrderUpwind, MusclMinmod, MusclVanLeer };

struct ReactiveCylinder3DConfiguration {
    std::size_t nx = 12;
    std::size_t ny = 12;
    std::size_t nz = 10;
    double compression_ratio = 10.5;
    double connecting_rod_length_m = 0.145;
    double minimum_temperature_k = 250.0;
    double maximum_temperature_k = 3600.0;
    double scalar_diffusivity_m2_s = 2.0e-5;
    double thermal_diffusivity_m2_s = 2.4e-5;
    double turbulent_diffusivity_gain = 0.012;
    double swirl_ratio = 0.55;
    double tumble_ratio = 1.05;
    double squish_gain = 0.75;
    double fuel_preexponential_s = 2.0e8;
    double fuel_activation_temperature_k = 14500.0;
    double co_preexponential_s = 2.5e7;
    double co_activation_temperature_k = 11800.0;
    double no_preexponential_s = 7.0e8;
    double no_activation_temperature_k = 69000.0;
    double soot_preexponential_s = 3200.0;
    double soot_oxidation_preexponential_s = 1.2e5;
    double ignition_kernel_radius_m = 0.004;
    double fuel_lhv_j_kg = 42.7e6;
    double stoichiometric_afr = 14.7;
    double gas_constant_j_kg_k = 287.0;
    double cv_j_kg_k = 790.0;
    double wall_heat_transfer_w_m2_k = 650.0;
    double cfl_limit = 0.45;
    std::size_t maximum_substeps = 128;
    // V51-B: higher-order bounded transport and conservative adaptive regridding.
    // The V50 default remains first-order/non-adaptive for backwards compatibility;
    // V51 promotes these options through its fidelity policy.
    ReactiveTransportScheme transport_scheme = ReactiveTransportScheme::FirstOrderUpwind;
    bool adaptive_grid = false;
    std::size_t minimum_nx = 6;
    std::size_t minimum_ny = 6;
    std::size_t minimum_nz = 4;
    std::size_t maximum_nx = 48;
    std::size_t maximum_ny = 48;
    std::size_t maximum_nz = 40;
    double refinement_indicator = 0.16;
    double coarsening_indicator = 0.025;
    std::size_t adaptation_interval_steps = 8;
};

struct ReactiveCylinder3DCell {
    double density_kg_m3 = 1.18;
    double temperature_k = 300.0;
    double pressure_pa = 101325.0;
    double velocity_x_m_s = 0.0;
    double velocity_y_m_s = 0.0;
    double velocity_z_m_s = 0.0;
    double fuel_mass_fraction = 0.0;
    double oxygen_mass_fraction = 0.232;
    double co_mass_fraction = 0.0;
    double co2_mass_fraction = 0.0006;
    double water_mass_fraction = 0.012;
    double no_mass_fraction = 0.0;
    double soot_mass_fraction = 0.0;
    double progress_variable = 0.0;
};

struct ReactiveCylinder3DState {
    double time_s = 0.0;
    double crank_angle_deg = 0.0;
    double chamber_height_m = 0.0;
    double chamber_volume_m3 = 0.0;
    double mean_pressure_pa = 101325.0;
    double mean_temperature_k = 300.0;
    double maximum_temperature_k = 300.0;
    double burned_mass_fraction = 0.0;
    double heat_release_rate_w = 0.0;
    double wall_heat_transfer_w = 0.0;
    double nox_kg_s = 0.0;
    double soot_kg_s = 0.0;
    double co_kg_s = 0.0;
    double maximum_velocity_m_s = 0.0;
    double mass_residual_kg = 0.0;
    double energy_residual_j = 0.0;
    std::size_t grid_nx = 0;
    std::size_t grid_ny = 0;
    std::size_t grid_nz = 0;
    std::uint64_t refinement_events = 0;
    std::uint64_t coarsening_events = 0;
    double adaptation_indicator = 0.0;
    std::string transport_scheme;
    std::vector<ReactiveCylinder3DCell> cells;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class ReactiveCylinder3DAuthority {
public:
    void configure(const ReactiveCylinder3DConfiguration& configuration,
                   const high_fidelity::EngineResearchConfiguration& engine_configuration);
    void reset(double pressure_pa = 101325.0, double temperature_k = 298.15,
               double equivalence_ratio = 1.0);
    [[nodiscard]] const ReactiveCylinder3DState& step(
        const high_fidelity::EngineResearchInput& input,
        const high_fidelity::EngineResearchState& canonical_engine,
        double dt_s);
    [[nodiscard]] const ReactiveCylinder3DState& state() const noexcept { return state_; }
    void set_numerical_fidelity(ReactiveTransportScheme scheme, bool adaptive_grid);

private:
    ReactiveCylinder3DConfiguration configuration_;
    high_fidelity::EngineResearchConfiguration engine_configuration_;
    ReactiveCylinder3DState state_;
    std::vector<unsigned char> active_mask_;
    double previous_volume_m3_ = 0.0;
    std::uint64_t step_counter_ = 0;
    void rebuild_active_mask();
    void conservative_regrid(std::size_t nx, std::size_t ny, std::size_t nz);
    void adapt_grid_if_needed();
};

// -----------------------------------------------------------------------------
// Thermoelastic cylinder-bore distortion overlay.  The canonical ring-pack and
// structural authorities remain responsible for ring dynamics and stresses;
// this authority resolves circumferential/axial bore shape and supplies
// conformance/blow-by/friction multipliers back to V50 coupling.
// -----------------------------------------------------------------------------

struct BoreDistortionConfiguration {
    std::size_t circumferential_nodes = 48;
    std::size_t axial_nodes = 10;
    std::size_t head_bolt_count = 10;
    double liner_thickness_m = 0.0045;
    double liner_youngs_modulus_pa = 120.0e9;
    double liner_poisson_ratio = 0.28;
    double liner_thermal_expansion_per_k = 11.0e-6;
    double head_bolt_preload_n = 42000.0;
    double deck_constraint_fraction = 0.72;
    double skirt_constraint_fraction = 0.34;
    double pressure_compliance_gain = 1.0;
    double minimum_clearance_m = 2.0e-6;
    double ring_conformability_m = 35.0e-6;
};

struct BoreDistortionState {
    double maximum_outward_displacement_m = 0.0;
    double maximum_inward_displacement_m = 0.0;
    double peak_to_peak_ovality_m = 0.0;
    double second_harmonic_m = 0.0;
    double fourth_harmonic_m = 0.0;
    double minimum_running_clearance_m = 0.0;
    double ring_conformance_fraction = 1.0;
    double blowby_multiplier = 1.0;
    double ring_friction_multiplier = 1.0;
    std::vector<double> radial_displacement_m;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_field = false) const;
};

class CylinderBoreDistortionAuthority {
public:
    void configure(BoreDistortionConfiguration configuration,
                   const high_fidelity::EngineResearchConfiguration& engine_configuration);
    [[nodiscard]] BoreDistortionState evaluate(
        const high_fidelity::EngineResearchState& engine,
        const ReactiveCylinder3DState& reactive) const;
private:
    BoreDistortionConfiguration configuration_;
    high_fidelity::EngineResearchConfiguration engine_configuration_;
};

// -----------------------------------------------------------------------------
// EVAP / ORVR and aftertreatment lifetime-deposit extensions.
// -----------------------------------------------------------------------------

struct EvapOrvrConfiguration {
    double tank_volume_m3 = 0.060;
    double initial_fuel_volume_fraction = 0.55;
    double liquid_fuel_density_kg_m3 = 740.0;
    double fuel_molar_mass_kg_mol = 0.095;
    double antoine_a = 6.87987;
    double antoine_b = 1196.76;
    double antoine_c = 219.161;
    double canister_carbon_mass_kg = 0.85;
    double canister_capacity_kg_hc_per_kg_carbon = 0.12;
    double langmuir_pressure_half_pa = 12000.0;
    double adsorption_time_constant_s = 8.0;
    double desorption_time_constant_s = 18.0;
    double canister_heat_capacity_j_k = 1050.0;
    double adsorption_heat_j_kg = 360000.0;
    double vent_flow_coefficient_kg_s_pa_sqrt = 2.5e-6;
    double pressure_relief_pa = 6000.0;
    double orvr_capture_efficiency = 0.965;
    double purge_hc_fraction_limit = 0.20;
};

struct EvapOrvrInput {
    double ambient_pressure_pa = 101325.0;
    double ambient_temperature_k = 298.15;
    double fuel_temperature_k = 298.15;
    double vehicle_speed_m_s = 0.0;
    double fuel_consumption_kg_s = 0.0;
    double refuel_liquid_rate_kg_s = 0.0;
    double purge_air_flow_kg_s = 0.0;
    double intake_manifold_pressure_pa = 70000.0;
};

struct EvapOrvrState {
    double fuel_mass_kg = 0.0;
    double ullage_volume_m3 = 0.0;
    double vapor_pressure_pa = 0.0;
    double tank_pressure_pa = 101325.0;
    double vapor_mass_kg = 0.0;
    double canister_hc_loading_kg = 0.0;
    double canister_temperature_k = 298.15;
    double adsorption_rate_kg_s = 0.0;
    double purge_hc_kg_s = 0.0;
    double atmospheric_hc_kg_s = 0.0;
    double refueling_hc_generation_kg_s = 0.0;
    double canister_saturation_fraction = 0.0;
    double cumulative_evaporative_hc_kg = 0.0;
    double mass_residual_kg = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EvapOrvrAuthority {
public:
    void configure(EvapOrvrConfiguration configuration);
    void reset(double fuel_volume_fraction = -1.0, double temperature_k = 298.15);
    [[nodiscard]] const EvapOrvrState& step(const EvapOrvrInput& input, double dt_s);
    [[nodiscard]] const EvapOrvrState& state() const noexcept { return state_; }
private:
    EvapOrvrConfiguration configuration_;
    EvapOrvrState state_;
};

struct CatalystLifecycleConfiguration {
    double dpf_ash_capacity_kg = 0.18;
    double ash_capture_fraction = 0.92;
    double oil_ash_fraction = 0.010;
    double sulfur_storage_capacity_kg = 0.004;
    double sulfur_poisoning_gain = 0.42;
    double desulfation_temperature_k = 900.0;
    double urea_deposit_capacity_kg = 0.020;
    double urea_deposit_temperature_low_k = 420.0;
    double urea_deposit_temperature_high_k = 590.0;
    double urea_decomposition_temperature_k = 650.0;
    double hydrothermal_reference_temperature_k = 1023.15;
    double hydrothermal_preexponential_s = 1.2e-5;
    double hydrothermal_activation_temperature_k = 9500.0;
    double dpf_ash_backpressure_pa_per_kg = 280000.0;
    double urea_deposit_backpressure_pa_per_kg = 850000.0;
    double minimum_activity_fraction = 0.10;
};

struct CatalystLifecycleInput {
    double exhaust_mass_flow_kg_s = 0.0;
    double exhaust_temperature_k = 700.0;
    double oil_consumption_kg_s = 0.0;
    double fuel_flow_kg_s = 0.0;
    double fuel_sulfur_mass_fraction = 1.0e-5;
    double urea_dosing_kg_s = 0.0;
};

struct CatalystLifecycleState {
    double dpf_ash_loading_kg = 0.0;
    double sulfur_storage_kg = 0.0;
    double urea_deposit_kg = 0.0;
    double hydrothermal_age = 0.0;
    double catalyst_activity_fraction = 1.0;
    double additional_backpressure_pa = 0.0;
    double deposit_regeneration_kg_s = 0.0;
    high_fidelity::EngineOutEmissionsState aged_tailpipe;
    double cumulative_aged_nox_kg = 0.0;
    double cumulative_aged_hc_kg = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CatalystLifecycleAuthority {
public:
    void configure(CatalystLifecycleConfiguration configuration);
    void reset();
    [[nodiscard]] const CatalystLifecycleState& step(
        const high_fidelity::AftertreatmentState& canonical,
        const CatalystLifecycleInput& input,
        double dt_s);
    [[nodiscard]] const CatalystLifecycleState& state() const noexcept { return state_; }
private:
    CatalystLifecycleConfiguration configuration_;
    CatalystLifecycleState state_;
};

// -----------------------------------------------------------------------------
// Spatial tire authority.  It consumes the canonical TireRoadWeatherLaboratory
// result and resolves tread depth, temperature, pressure, water film and wear
// over the footprint.  Corrected forces therefore refine, not duplicate, the
// established tire constitutive law.
// -----------------------------------------------------------------------------

struct SpatialTireConfiguration {
    std::size_t longitudinal_cells = 18;
    std::size_t lateral_cells = 12;
    double initial_tread_depth_m = 0.008;
    double minimum_legal_tread_depth_m = 0.0016;
    double groove_land_fraction = 0.68;
    double groove_drainage_coefficient = 0.72;
    double tread_hardness_scale = 1.0;
    double archard_wear_coefficient = 1.4e-12;
    double tread_thermal_diffusivity_m2_s = 8.0e-8;
    double tread_heat_capacity_j_kg_k = 1900.0;
    double tread_density_kg_m3 = 1120.0;
    double contact_length_m = 0.14;
    double contact_width_scale = 0.92;
};

struct SpatialTireCell {
    double tread_depth_m = 0.008;
    double temperature_k = 293.15;
    double contact_pressure_pa = 0.0;
    double water_film_m = 0.0;
    double wear_depth_m = 0.0;
    double local_mu_scale = 1.0;
};

struct SpatialTireState {
    double mean_tread_depth_m = 0.008;
    double minimum_tread_depth_m = 0.008;
    double shoulder_depth_delta_m = 0.0;
    double center_depth_delta_m = 0.0;
    double heel_toe_index = 0.0;
    double wet_grip_multiplier = 1.0;
    double dry_grip_multiplier = 1.0;
    double drainage_fraction = 1.0;
    double hydroplaning_fraction = 0.0;
    double wear_rate_kg_s = 0.0;
    double corrected_longitudinal_force_n = 0.0;
    double corrected_lateral_force_n = 0.0;
    double corrected_aligning_moment_nm = 0.0;
    std::vector<SpatialTireCell> cells;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_field = false) const;
};

class SpatialTireAuthority {
public:
    void configure(SpatialTireConfiguration configuration, const TireDefinition& tire);
    void reset(double temperature_k = 293.15);
    [[nodiscard]] const SpatialTireState& step(
        const TireDefinition& tire,
        const TireRoadEnvironment& environment,
        const TireOperatingPoint& operating_point,
        const TireStepResult& canonical,
        double dt_s);
    [[nodiscard]] const SpatialTireState& state() const noexcept { return state_; }
private:
    SpatialTireConfiguration configuration_;
    TireDefinition tire_;
    SpatialTireState state_;
};

// -----------------------------------------------------------------------------
// Navigation reality: satellite geometry + atmospheric/NLOS/multipath effects
// and Allan-parameterized IMU stochastic errors.
// -----------------------------------------------------------------------------

struct UrbanCanyonSector {
    double azimuth_start_deg = 0.0;
    double azimuth_end_deg = 0.0;
    double elevation_mask_deg = 0.0;
    double reflection_excess_path_m = 0.0;
};

struct NavigationRealityConfiguration {
    std::size_t satellites = 18;
    std::uint64_t random_seed = 0x50A11ULL;
    double pseudorange_sigma_m = 0.65;
    double carrier_phase_sigma_m = 0.008;
    double receiver_clock_rw_m_sqrt_s = 0.20;
    double ionosphere_zenith_delay_m = 3.5;
    double troposphere_zenith_delay_m = 2.3;
    double nlos_additional_sigma_m = 8.0;
    double minimum_elevation_deg = 7.0;
    double imu_accel_noise_density_m_s2_sqrt_hz = 0.0025;
    double imu_gyro_noise_density_rad_s_sqrt_hz = 1.5e-4;
    double imu_accel_bias_instability_m_s2 = 0.0015;
    double imu_gyro_bias_instability_rad_s = 3.0e-5;
    double imu_bias_correlation_time_s = 180.0;
    double accel_temperature_coefficient_m_s2_k = 5.0e-5;
    double gyro_temperature_coefficient_rad_s_k = 1.2e-6;
    double reference_temperature_k = 298.15;
};

struct NavigationTruthState {
    double time_s = 0.0;
    std::array<double,3> position_enu_m{};
    std::array<double,3> velocity_enu_m_s{};
    std::array<double,3> specific_force_body_m_s2{};
    std::array<double,3> angular_rate_body_rad_s{};
    double imu_temperature_k = 298.15;
};

struct NavigationEnvironment {
    std::vector<UrbanCanyonSector> canyon_sectors;
    double ionosphere_scale = 1.0;
    double troposphere_scale = 1.0;
};

struct GnssSatelliteObservation {
    std::size_t satellite_id = 0;
    double azimuth_deg = 0.0;
    double elevation_deg = 0.0;
    double pseudorange_error_m = 0.0;
    double carrier_phase_error_m = 0.0;
    double cn0_db_hz = 0.0;
    bool nlos = false;
};

struct GnssSolutionState {
    bool valid = false;
    std::size_t visible_satellites = 0;
    std::array<double,3> position_error_enu_m{};
    double receiver_clock_bias_m = 0.0;
    // Zero denotes unavailable while valid == false.  Keeping serialized state
    // finite is required by the canonical evidence/provenance JSON pipeline.
    double hdop = 0.0;
    double vdop = 0.0;
    double pdop = 0.0;
    std::vector<GnssSatelliteObservation> observations;
};

struct ImuMeasurementState {
    std::array<double,3> measured_specific_force_m_s2{};
    std::array<double,3> measured_angular_rate_rad_s{};
    std::array<double,3> accel_bias_m_s2{};
    std::array<double,3> gyro_bias_rad_s{};
};

struct NavigationRealityState {
    double time_s = 0.0;
    GnssSolutionState gnss;
    ImuMeasurementState imu;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_satellites = false) const;
};

class NavigationRealityAuthority {
public:
    void configure(NavigationRealityConfiguration configuration);
    void reset();
    [[nodiscard]] const NavigationRealityState& step(
        const NavigationTruthState& truth,
        const NavigationEnvironment& environment,
        double dt_s);
    [[nodiscard]] const NavigationRealityState& state() const noexcept { return state_; }
private:
    NavigationRealityConfiguration configuration_;
    NavigationRealityState state_;
    std::mt19937_64 rng_{0x50A11ULL};
};

// -----------------------------------------------------------------------------
// Exposure-weighted SOTIF risk.  Scenario exposure uses a Dirichlet posterior;
// failure, harmful-outcome and loss-of-control probabilities use Beta
// posteriors.  Monte Carlo therefore carries epistemic uncertainty into the
// fleet-level risk result instead of multiplying point estimates.
// -----------------------------------------------------------------------------

struct SotifScenarioEvidence {
    std::string id;
    std::uint64_t exposure_count = 0;
    std::uint64_t evaluation_count = 0;
    std::uint64_t failure_count = 0;
    std::uint64_t harmful_outcome_count = 0;
    std::uint64_t uncontrolled_outcome_count = 0;
    double severity = 1.0;
};

struct SotifExposureConfiguration {
    std::size_t posterior_samples = 5000;
    std::uint64_t random_seed = 0x50F17ULL;
    double dirichlet_prior = 0.5;
    double beta_prior_alpha = 0.5;
    double beta_prior_beta = 0.5;
    double annual_vehicle_hours = 500.0;
};

struct SotifScenarioRisk {
    std::string id;
    double posterior_exposure_probability = 0.0;
    double posterior_failure_probability = 0.0;
    double posterior_harm_probability = 0.0;
    double posterior_uncontrolled_probability = 0.0;
    double severity = 0.0;
    double risk_contribution = 0.0;
};

struct SotifExposureRiskState {
    double risk_per_operating_hour_mean = 0.0;
    double risk_per_operating_hour_p025 = 0.0;
    double risk_per_operating_hour_p975 = 0.0;
    double annualized_risk_mean = 0.0;
    double annualized_risk_p975 = 0.0;
    std::vector<SotifScenarioRisk> scenarios;
    std::string dominant_scenario_id;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SotifExposureRiskAuthority {
public:
    void configure(SotifExposureConfiguration configuration);
    [[nodiscard]] SotifExposureRiskState evaluate(
        const std::vector<SotifScenarioEvidence>& evidence) const;
private:
    SotifExposureConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Governed continual-learning overlay.  It consumes drift evidence from the
// canonical MLOps detector, applies EWC/replay-regularized parameter updates,
// and promotes or rolls back candidates through explicit safety gates.
// -----------------------------------------------------------------------------

enum class ContinualLearningStage { Stable, ShadowCandidate, Promoted, RolledBack, Frozen };

struct ContinualLearningConfiguration {
    double learning_rate = 0.01;
    double replay_gradient_weight = 0.65;
    double ewc_lambda = 4.0;
    double maximum_parameter_step = 0.05;
    double drift_psi_threshold = 0.20;
    double minimum_accuracy = 0.95;
    double maximum_violation_rate = 0.001;
    double maximum_forgetting_loss = 0.03;
    std::size_t minimum_validation_observations = 100;
};

struct ContinualLearningObservation {
    std::string feature_name = "primary";
    std::vector<double> baseline_feature;
    std::vector<double> current_feature;
    std::vector<double> new_data_gradient;
    std::vector<double> replay_gradient;
    std::vector<double> fisher_diagonal;
    double new_data_loss = 0.0;
    double replay_loss = 0.0;
    double accuracy = 1.0;
    double safety_violation_rate = 0.0;
    std::size_t validation_observations = 0;
    bool request_adaptation = false;
};

struct ContinualLearningState {
    ContinualLearningStage stage = ContinualLearningStage::Stable;
    std::vector<double> champion_parameters;
    std::vector<double> candidate_parameters;
    std::vector<double> fisher_diagonal;
    double drift_psi = 0.0;
    double drift_mean_shift = 0.0;
    double drift_cdf_distance = 0.0;
    double champion_replay_loss = 0.0;
    double candidate_replay_loss = 0.0;
    double candidate_new_data_loss = 0.0;
    std::uint64_t adaptation_count = 0;
    std::uint64_t promotion_count = 0;
    std::uint64_t rollback_count = 0;
    std::string decision;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class GovernedContinualLearningAuthority {
public:
    void configure(ContinualLearningConfiguration configuration);
    void reset(std::vector<double> initial_parameters = {},
               double initial_replay_loss = 0.0);
    [[nodiscard]] const ContinualLearningState& step(const ContinualLearningObservation& observation);
    [[nodiscard]] const ContinualLearningState& state() const noexcept { return state_; }
private:
    ContinualLearningConfiguration configuration_;
    ContinualLearningState state_;
    VehicleCloudMlopsPlatform mlops_;
};

// -----------------------------------------------------------------------------
// V50 integrated coupling authority.
// -----------------------------------------------------------------------------

struct V50RealityConfiguration {
    high_fidelity::EngineResearchConfiguration engine;
    ReactiveCylinder3DConfiguration reactive_cylinder;
    BoreDistortionConfiguration bore_distortion;
    EvapOrvrConfiguration evap_orvr;
    CatalystLifecycleConfiguration catalyst_lifecycle;
    std::array<SpatialTireConfiguration,4> spatial_tires{};
    TireDefinition tire_definition;
    NavigationRealityConfiguration navigation;
    SotifExposureConfiguration sotif;
    ContinualLearningConfiguration continual_learning;
};

struct V50RealityInput {
    high_fidelity::EngineResearchInput engine;
    EvapOrvrInput evap;
    std::array<TireRoadEnvironment,4> tire_environment{};
    std::array<TireOperatingPoint,4> tire_operating_point{};
    NavigationTruthState navigation_truth;
    NavigationEnvironment navigation_environment;
    std::vector<SotifScenarioEvidence> sotif_evidence;
    ContinualLearningObservation continual_learning;
    double fuel_sulfur_mass_fraction = 1.0e-5;
};

struct V50RealityState {
    double time_s = 0.0;
    high_fidelity::EngineResearchState engine;
    ReactiveCylinder3DState reactive_cylinder;
    BoreDistortionState bore_distortion;
    EvapOrvrState evap;
    CatalystLifecycleState catalyst_lifecycle;
    std::array<TireStepResult,4> canonical_tires{};
    std::array<SpatialTireState,4> spatial_tires{};
    NavigationRealityState navigation;
    SotifExposureRiskState sotif;
    ContinualLearningState continual_learning;
    double purge_fuel_displacement_fraction = 0.0;
    double bore_distortion_hc_penalty_kg_s = 0.0;
    double mean_tire_grip_multiplier = 1.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class V50RealityAuthority {
public:
    V50RealityAuthority();
    explicit V50RealityAuthority(const V50RealityConfiguration& configuration);
    void configure(const V50RealityConfiguration& configuration);
    void reset(double ambient_pressure_pa = 101325.0,
               double ambient_temperature_k = 298.15);
    [[nodiscard]] const V50RealityState& step(const V50RealityInput& input, double dt_s);
    [[nodiscard]] const V50RealityState& state() const noexcept { return state_; }
    void set_reactive_numerical_fidelity(ReactiveTransportScheme scheme, bool adaptive_grid);
private:
    V50RealityConfiguration configuration_;
    high_fidelity::EngineResearchDigitalTwin engine_;
    ReactiveCylinder3DAuthority reactive_cylinder_;
    CylinderBoreDistortionAuthority bore_distortion_;
    EvapOrvrAuthority evap_;
    CatalystLifecycleAuthority catalyst_lifecycle_;
    TireRoadWeatherLaboratory canonical_tire_lab_;
    std::array<TireState,4> canonical_tire_state_{};
    std::array<SpatialTireAuthority,4> spatial_tires_;
    NavigationRealityAuthority navigation_;
    SotifExposureRiskAuthority sotif_;
    GovernedContinualLearningAuthority continual_learning_;
    V50RealityState state_;
};

[[nodiscard]] const char* continual_learning_stage_name(ContinualLearningStage stage) noexcept;
[[nodiscard]] const char* reactive_transport_scheme_name(ReactiveTransportScheme scheme) noexcept;

} // namespace aesim::advanced

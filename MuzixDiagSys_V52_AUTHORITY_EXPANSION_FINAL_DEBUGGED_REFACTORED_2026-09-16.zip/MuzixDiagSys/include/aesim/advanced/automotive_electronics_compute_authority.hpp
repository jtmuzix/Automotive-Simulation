#pragma once

#include "aesim/advanced/deep_engineering_platform.hpp"
#include "aesim/advanced/electronics_power_distribution_platform.hpp"
#include "aesim/advanced/embedded_electronics_assurance_platform.hpp"
#include "aesim/advanced/automotive_standards_conformance_platform.hpp"
#include "aesim/electrification/advanced_vehicle.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced::electronics {

// ============================================================================
// Phase A — ECU silicon, memory, clocks, reset and board electronics
// ============================================================================

enum class McuPeripheralType { Timer, Adc, Pwm, Spi, I2c, Uart, Gpio, Can, Lin, Ethernet, Watchdog, Custom };
enum class InterruptTrigger { Edge, Level, Software, DmaCompletion, TimerCompare };

struct McuInterruptConfig {
    std::string id;
    unsigned priority = 1;
    std::uint64_t vector_latency_cycles = 12;
    std::uint64_t handler_cycles = 100;
    bool preemptable = true;
};

struct McuPeripheralConfig {
    std::string id;
    McuPeripheralType type = McuPeripheralType::Custom;
    std::string interrupt_id;
    std::size_t fifo_capacity = 16;
    std::uint64_t service_cycles = 4;
};

struct DmaChannelConfig {
    std::string id;
    unsigned priority = 1;
    double maximum_bytes_per_cycle = 1.0;
    std::size_t burst_bytes = 16;
    std::string completion_interrupt_id;
};

struct DmaTransferRequest {
    std::string channel_id;
    std::string source;
    std::string destination;
    std::size_t bytes = 0;
};

struct McuPeripheralEvent {
    std::string peripheral_id;
    std::uint64_t arrival_cycle = 0;
    std::size_t payload_bytes = 1;
    InterruptTrigger trigger = InterruptTrigger::Edge;
};

struct McuExecutionReport {
    std::uint64_t elapsed_cycles = 0;
    std::uint64_t interrupt_cycles = 0;
    std::uint64_t dma_busy_cycles = 0;
    std::uint64_t dma_bytes_transferred = 0;
    std::size_t interrupts_serviced = 0;
    std::size_t interrupt_preemptions = 0;
    std::size_t fifo_overruns = 0;
    std::size_t dma_completions = 0;
    double maximum_interrupt_latency_cycles = 0.0;
    double cpu_interrupt_utilization = 0.0;
    double dma_bus_utilization = 0.0;
    std::map<std::string, std::size_t> pending_peripheral_events;
    std::map<std::string, std::size_t> pending_dma_transfers;
    std::vector<std::string> trace;
};

class McuPeripheralInterruptDmaAuthority {
public:
    explicit McuPeripheralInterruptDmaAuthority(double dma_bus_bytes_per_cycle = 8.0);
    void add_interrupt(McuInterruptConfig config);
    void add_peripheral(McuPeripheralConfig config);
    void add_dma_channel(DmaChannelConfig config);
    void submit_event(McuPeripheralEvent event);
    void trigger_interrupt(const std::string& interrupt_id, InterruptTrigger trigger = InterruptTrigger::Software);
    void submit_dma(DmaTransferRequest request);
    [[nodiscard]] McuExecutionReport advance(std::uint64_t cycles);
    void reset();
private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
};

enum class SafetyFaultKind { CorrectableEcc, UncorrectableEcc, LockstepDivergence, WatchdogTimeout,
                             ClockMonitor, VoltageMonitor, PeripheralLatentFault };
enum class SafetyEscalation { Normal, Corrected, Degraded, FunctionalReset, SafeState, PowerCycleRequired };

struct SafetyMcuConfig {
    double watchdog_window_s = 0.100;
    double minimum_supply_v = 3.0;
    double maximum_clock_error_ppm = 5000.0;
    std::size_t correctable_ecc_escalation_threshold = 100;
    std::size_t reset_escalation_threshold = 3;
    double scrub_period_s = 1.0;
};

struct SafetyMcuObservation {
    double supply_voltage_v = 3.3;
    double clock_error_ppm = 0.0;
    bool lockstep_match = true;
    bool watchdog_serviced = true;
    std::size_t corrected_ecc_events = 0;
    std::size_t uncorrectable_ecc_events = 0;
    bool peripheral_latent_fault = false;
};

struct SafetyMcuReport {
    SafetyEscalation escalation = SafetyEscalation::Normal;
    std::size_t corrected_ecc_events = 0;
    std::size_t uncorrectable_ecc_events = 0;
    std::size_t memory_scrubs = 0;
    std::size_t functional_resets = 0;
    bool watchdog_expired = false;
    bool lockstep_mismatch = false;
    bool voltage_fault = false;
    bool clock_fault = false;
    bool safe_state = false;
    BistReport mbist;
    BistReport lbist;
    std::vector<std::string> diagnostic_events;
};

class SafetyMcuSupervisor {
public:
    explicit SafetyMcuSupervisor(SafetyMcuConfig config = {});
    void configure_memory_image(std::vector<std::uint32_t> memory_words);
    void set_mbist_faults(std::map<std::size_t, std::uint32_t> stuck_masks);
    void set_lbist_faults(std::vector<std::uint64_t> faulty_masks);
    [[nodiscard]] SafetyMcuReport run_power_on_bist(std::uint64_t lbist_seed = 1, std::size_t lbist_patterns = 256);
    void inject_fault(SafetyFaultKind fault);
    [[nodiscard]] SafetyMcuReport advance(double dt_s, const SafetyMcuObservation& observation);
    void acknowledge_functional_reset();
private:
    SafetyMcuConfig config_;
    BuiltInSelfTestLaboratory bist_;
    std::vector<std::uint32_t> memory_;
    std::map<std::size_t, std::uint32_t> mbist_faults_;
    std::vector<std::uint64_t> lbist_faults_;
    SafetyMcuReport report_;
    double watchdog_elapsed_s_ = 0.0;
    double scrub_elapsed_s_ = 0.0;
    std::vector<SafetyFaultKind> injected_faults_;
};

struct TransactionalNvmBlockConfig {
    std::string id;
    std::size_t maximum_payload_bytes = 256;
    std::size_t redundant_slots = 2;
};

struct TransactionalNvmBlockReport {
    bool committed = false;
    bool recovered_previous_version = false;
    bool redundancy_degraded = false;
    std::uint64_t version = 0;
    std::size_t valid_copies = 0;
    std::uint32_t crc32 = 0;
    NvmReport physical;
    std::string diagnostic;
};

class TransactionalNvmAuthority {
public:
    explicit TransactionalNvmAuthority(NvmConfig config = {});
    void define_block(TransactionalNvmBlockConfig block);
    [[nodiscard]] TransactionalNvmBlockReport write_block(const std::string& block_id,
                                                           const std::vector<std::uint8_t>& payload,
                                                           double temperature_k,
                                                           bool power_loss_before_commit = false);
    [[nodiscard]] std::pair<std::vector<std::uint8_t>, TransactionalNvmBlockReport>
    read_block(const std::string& block_id, double elapsed_years, double temperature_k) const;
    void inject_byte_corruption(const std::string& block_id, std::size_t slot,
                                std::size_t record_byte, std::uint8_t xor_mask,
                                double temperature_k = 298.15);
private:
    struct BlockRuntime;
    NvmConfig config_;
    mutable NvmReliabilityLaboratory physical_;
    std::map<std::string, std::shared_ptr<BlockRuntime>> blocks_;
    std::size_t next_address_ = 0;
};

enum class ResetSource { PowerOn, Brownout, Watchdog, Software, ExternalPin, SafetyMonitor, ClockFailure };

struct ClockDomainConfig {
    std::string id;
    double nominal_hz = 100.0e6;
    double oscillator_start_s = 0.002;
    double pll_lock_s = 0.001;
    double tolerance_ppm = 100.0;
    bool uses_pll = true;
};

struct BootStageConfig {
    std::string id;
    double duration_s = 0.010;
    std::vector<std::string> dependencies;
    std::vector<std::string> required_clock_domains;
};

struct ClockResetPowerReport {
    PmicReport pmic;
    std::map<std::string, bool> clock_running;
    std::map<std::string, bool> pll_locked;
    std::map<std::string, double> clock_frequency_hz;
    std::map<std::string, bool> boot_stage_complete;
    bool reset_asserted = true;
    ResetSource reset_source = ResetSource::PowerOn;
    double boot_elapsed_s = 0.0;
    double time_to_application_ready_s = 0.0;
    std::vector<std::string> reset_history;
};

class ClockResetPowerSequencer {
public:
    ClockResetPowerSequencer();
    void configure_pmic(double uvlo_v, double overtemperature_k, double watchdog_window_s,
                        double thermal_resistance_k_per_w, double thermal_capacity_j_per_k);
    void add_power_rail(PmicRailConfig rail);
    void add_clock_domain(ClockDomainConfig clock);
    void add_boot_stage(BootStageConfig stage);
    void inject_clock_failure(const std::string& clock_id, bool failed = true);
    void request_reset(ResetSource source);
    [[nodiscard]] ClockResetPowerReport advance(double dt_s, const PmicInput& input);
    void reset();
private:
    PmicSystemBasisChip pmic_;
    std::map<std::string, ClockDomainConfig> clocks_;
    std::map<std::string, double> clock_elapsed_s_;
    std::map<std::string, bool> clock_failed_;
    std::map<std::string, BootStageConfig> stages_;
    std::map<std::string, double> stage_elapsed_s_;
    ClockResetPowerReport report_;
    bool external_reset_pending_ = false;
};

enum class BoardComponentKind { Mcu, Hsm, Pmic, Memory, Transceiver, SensorFrontend, ActuatorDriver, Oscillator, Regulator };

struct BoardComponentConfig {
    std::string id;
    BoardComponentKind kind = BoardComponentKind::Mcu;
    double static_power_w = 0.1;
    double dynamic_power_w = 0.5;
    double thermal_resistance_k_per_w = 25.0;
    double thermal_capacitance_j_per_k = 5.0;
    double maximum_temperature_k = 423.15;
};

struct AnalogFrontendConfig {
    std::string id;
    double gain = 1.0;
    double offset_v = 0.0;
    double input_noise_rms_v = 0.0;
    double low_pass_hz = 1000.0;
    unsigned adc_bits = 12;
    double reference_voltage_v = 5.0;
    double integral_nonlinearity_lsb = 0.5;
};

struct ActuatorDriverConfig {
    std::string id;
    double on_resistance_ohm = 0.05;
    double current_limit_a = 10.0;
    double thermal_resistance_k_per_w = 15.0;
    double thermal_capacitance_j_per_k = 3.0;
    double shutdown_temperature_k = 423.15;
};

struct EcuBoardInput {
    double dt_s = 0.001;
    double supply_voltage_v = 12.0;
    double ambient_temperature_k = 298.15;
    double activity_fraction = 0.5;
    double ground_offset_v = 0.0;
    std::map<std::string, double> analog_input_v;
    std::map<std::string, double> actuator_load_current_a;
};

struct EcuBoardReport {
    std::map<std::string, double> component_temperature_k;
    std::map<std::string, std::uint32_t> adc_codes;
    std::map<std::string, double> actuator_voltage_drop_v;
    std::map<std::string, bool> actuator_overcurrent;
    std::map<std::string, bool> actuator_thermal_shutdown;
    double board_power_w = 0.0;
    double maximum_temperature_k = 0.0;
    double ground_offset_v = 0.0;
    bool thermal_fault = false;
    std::vector<std::string> diagnostic_events;
};

class EcuBoardElectronicsAuthority {
public:
    void add_component(BoardComponentConfig component);
    void add_analog_frontend(AnalogFrontendConfig frontend);
    void add_actuator_driver(ActuatorDriverConfig driver);
    [[nodiscard]] EcuBoardReport advance(const EcuBoardInput& input);
private:
    std::map<std::string, BoardComponentConfig> components_;
    std::map<std::string, AnalogFrontendConfig> frontends_;
    std::map<std::string, ActuatorDriverConfig> drivers_;
    std::map<std::string, double> temperatures_;
    std::map<std::string, double> filtered_inputs_;
};

// ============================================================================
// Phase B — vehicle-network protocol and silicon depth
// ============================================================================

enum class LinChecksumModel { Classic, Enhanced };
enum class LinNodeRole { Master, Slave };
enum class LinFrameKind { Unconditional, Sporadic, EventTriggered, DiagnosticMasterRequest, DiagnosticSlaveResponse };

struct LinNodeConfig { std::string id; LinNodeRole role = LinNodeRole::Slave; double oscillator_error_ppm = 0.0; std::uint8_t nad = 0x7f; };
struct LinFrameConfig {
    std::uint8_t id = 0;
    std::string publisher;
    std::vector<std::string> subscribers;
    std::size_t length = 8;
    LinChecksumModel checksum = LinChecksumModel::Enhanced;
    bool diagnostic = false;
    std::vector<std::uint8_t> event_triggered_sources;
    LinFrameKind kind = LinFrameKind::Unconditional;
};
struct LinScheduleSlot { std::uint8_t frame_id = 0; double delay_s = 0.010; };
struct LinFrameObservation { std::uint8_t id = 0; std::vector<std::uint8_t> data; bool checksum_ok = true; double timestamp_s = 0.0; };
struct LinDiagnosticRequest { std::uint8_t nad = 0x7f; std::uint8_t service_id = 0; std::vector<std::uint8_t> payload; double response_timeout_s = 0.050; };
struct LinDiagnosticResponse { std::uint8_t nad = 0x7f; std::uint8_t service_id = 0; std::vector<std::uint8_t> payload; bool positive = false; bool timeout = false; std::size_t request_transport_frames = 0; std::size_t response_transport_frames = 0; double timestamp_s = 0.0; std::string diagnostic; };
using LinDiagnosticHandler = std::function<std::vector<std::uint8_t>(std::uint8_t,const std::vector<std::uint8_t>&)>;
struct LinNetworkReport {
    double elapsed_s = 0.0;
    std::size_t headers = 0;
    std::size_t frames = 0;
    std::size_t checksum_errors = 0;
    std::size_t response_timeouts = 0;
    std::size_t event_collisions = 0;
    std::size_t collision_resolutions = 0;
    std::size_t diagnostic_requests = 0;
    std::size_t diagnostic_responses = 0;
    std::size_t diagnostic_transport_frames = 0;
    std::size_t wakeups = 0;
    bool asleep = false;
    std::vector<LinFrameObservation> traffic;
    std::vector<std::string> diagnostics;
};

class Lin2NetworkAuthority {
public:
    explicit Lin2NetworkAuthority(double bitrate = 19200.0);
    void add_node(LinNodeConfig node);
    void add_frame(LinFrameConfig frame);
    void set_schedule(std::vector<LinScheduleSlot> slots);
    void write_frame(std::uint8_t id, std::vector<std::uint8_t> data);
    void mark_sporadic_pending(std::uint8_t frame_id);
    void register_diagnostic_service(const std::string& node_id, std::uint8_t service_id, LinDiagnosticHandler handler);
    void queue_diagnostic_request(LinDiagnosticRequest request);
    [[nodiscard]] std::vector<LinDiagnosticResponse> take_diagnostic_responses();
    void assign_nad(const std::string& node_id, std::uint8_t nad);
    void inject_no_response(const std::string& node_id, bool active = true);
    void inject_checksum_error(std::uint8_t frame_id, bool active = true);
    void request_sleep();
    void wake_bus();
    [[nodiscard]] LinNetworkReport advance(double dt_s);
private:
    double bitrate_;
    double elapsed_s_ = 0.0;
    double slot_elapsed_s_ = 0.0;
    std::size_t schedule_index_ = 0;
    bool asleep_ = false;
    std::map<std::string, LinNodeConfig> nodes_;
    std::map<std::uint8_t, LinFrameConfig> frames_;
    std::map<std::uint8_t, std::vector<std::uint8_t>> data_;
    std::vector<LinScheduleSlot> schedule_;
    std::set<std::string> no_response_;
    std::set<std::uint8_t> checksum_fault_;
    std::set<std::uint8_t> sporadic_pending_;
    std::map<std::string, std::map<std::uint8_t, LinDiagnosticHandler>> diagnostic_services_;
    std::deque<LinDiagnosticRequest> diagnostic_requests_;
    std::vector<LinDiagnosticResponse> diagnostic_responses_;
    LinNetworkReport report_;
};

enum class FlexRayChannel { A, B, AB };
struct FlexRayClusterConfig { double cycle_s = 0.005; std::size_t static_slots = 64; std::size_t dynamic_minislots = 128; double maximum_clock_error_ppm = 1500.0; };
struct FlexRayNodeConfig { std::string id; bool coldstart = false; double oscillator_error_ppm = 0.0; FlexRayChannel channels = FlexRayChannel::AB; };
struct FlexRayFrameConfig { std::string id; std::string publisher; std::vector<std::string> subscribers; bool dynamic = false; std::size_t slot = 1; std::size_t payload_bytes = 8; FlexRayChannel channel = FlexRayChannel::AB; unsigned priority = 1; };
struct FlexRayReport { std::size_t cycles = 0; std::size_t static_frames = 0; std::size_t dynamic_frames = 0; std::size_t sync_corrections = 0; std::size_t dropped_frames = 0; bool synchronized = false; bool channel_a_available = true; bool channel_b_available = true; double maximum_clock_error_ppm = 0.0; std::vector<std::string> diagnostics; };

class FlexRayNetworkAuthority {
public:
    explicit FlexRayNetworkAuthority(FlexRayClusterConfig config = {});
    void add_node(FlexRayNodeConfig node);
    void add_frame(FlexRayFrameConfig frame);
    void set_frame_payload(const std::string& frame_id, std::vector<std::uint8_t> data);
    void set_channel_available(FlexRayChannel channel, bool available);
    void start_cluster();
    [[nodiscard]] FlexRayReport advance(double dt_s);
private:
    FlexRayClusterConfig config_;
    std::map<std::string, FlexRayNodeConfig> nodes_;
    std::map<std::string, FlexRayFrameConfig> frames_;
    std::map<std::string, std::vector<std::uint8_t>> payloads_;
    FlexRayReport report_;
    double elapsed_in_cycle_s_ = 0.0;
    bool started_ = false;
};

enum class EthernetPhyStandard { BaseT1_100, BaseT1_1000, BaseT1_2500, BaseT1_5000, BaseT1_10000 };
struct EthernetPhyConfig { EthernetPhyStandard standard = EthernetPhyStandard::BaseT1_1000; double cable_length_m = 10.0; double insertion_loss_db_per_m = 0.08; double connector_loss_db = 1.0; double tx_power_dbm = 0.0; double receiver_noise_dbm = -85.0; double required_snr_db = 12.0; bool fec = true; double training_time_s = 0.050; double thermal_resistance_k_per_w = 30.0; double power_w = 0.7; };
struct EthernetPhyFault { double extra_loss_db = 0.0; double impedance_discontinuity_fraction = 0.0; double mode_conversion_db = 0.0; bool polarity_reversed = false; bool open_pair = false; bool short_pair = false; };
struct EthernetPhyReport { bool training = true; bool link_up = false; double elapsed_training_s = 0.0; double snr_db = 0.0; double raw_ber = 1.0; double residual_ber = 1.0; double link_rate_mbps = 0.0; double propagation_latency_us = 0.0; double junction_temperature_k = 298.15; std::size_t link_flaps = 0; std::string diagnostic; };

class AutomotiveEthernetPhyAuthority {
public:
    explicit AutomotiveEthernetPhyAuthority(EthernetPhyConfig config = {});
    void set_fault(EthernetPhyFault fault);
    void reset_link();
    [[nodiscard]] EthernetPhyReport advance(double dt_s, double ambient_temperature_k = 298.15);
private:
    EthernetPhyConfig config_;
    EthernetPhyFault fault_;
    EthernetPhyReport report_;
};

struct EthernetSwitchPortConfig { std::string id; double rate_mbps = 1000.0; std::size_t egress_buffer_bytes = 128 * 1024; bool cut_through = true; bool ptp_timestamping = true; std::set<std::uint16_t> allowed_vlans; };
struct EthernetSwitchFrame { std::string source_mac; std::string destination_mac; std::uint16_t vlan = 1; unsigned priority = 0; std::size_t bytes = 64; double ingress_time_s = 0.0; std::vector<std::uint8_t> payload; };
struct EthernetSwitchDeliveredFrame { EthernetSwitchFrame frame; std::string egress_port; double egress_time_s = 0.0; double latency_us = 0.0; std::uint64_t hardware_timestamp_ns = 0; };
struct EthernetSwitchReport { std::size_t forwarded = 0; std::size_t flooded = 0; std::size_t dropped_vlan = 0; std::size_t dropped_buffer = 0; std::size_t head_of_line_blocks = 0; std::size_t learned_macs = 0; double maximum_queue_occupancy_fraction = 0.0; std::map<std::string, std::size_t> queued_bytes; };

class EthernetSwitchSiliconAuthority {
public:
    explicit EthernetSwitchSiliconAuthority(double fabric_capacity_mbps = 10000.0);
    void add_port(EthernetSwitchPortConfig port);
    void receive(const std::string& ingress_port, EthernetSwitchFrame frame);
    [[nodiscard]] std::vector<EthernetSwitchDeliveredFrame> advance(double dt_s);
    [[nodiscard]] EthernetSwitchReport report() const;
    void clear_mac_table();
private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
};

enum class AutosarBusInterface { CanFd, Lin, FlexRay, Ethernet };
enum class AutosarE2eProfile { Profile1, Profile2, Profile4, Profile5, Profile6, Profile7 };
struct AutosarSignalConfig { std::string id; std::string pdu_id; std::size_t byte_offset = 0; std::size_t byte_length = 1; bool little_endian = true; };
struct AutosarPduConfig { std::string id; std::size_t payload_bytes = 8; AutosarE2eProfile e2e_profile = AutosarE2eProfile::Profile1; std::uint32_t data_id = 0; AutosarBusInterface interface = AutosarBusInterface::CanFd; std::size_t transport_mtu = 64; };
struct AutosarRouteConfig { std::string source_pdu; std::vector<std::string> destination_pdus; };
struct AutosarTransportFrame { std::string pdu_id; AutosarBusInterface interface = AutosarBusInterface::CanFd; std::size_t sequence = 0; bool first = false; bool last = false; std::vector<std::uint8_t> bytes; };
struct AutosarE2eStatus { bool valid = false; bool crc_ok = false; bool data_id_ok = false; bool repeated = false; bool sequence_gap = false; std::uint32_t counter = 0; std::string diagnostic; };
struct AutosarCommunicationReport { std::size_t com_updates = 0; std::size_t pdu_routes = 0; std::size_t transport_frames = 0; std::size_t e2e_crc_failures = 0; std::size_t e2e_sequence_errors = 0; std::map<std::string, AutosarE2eStatus> e2e_status; };

class AutosarCommunicationStackAuthority {
public:
    void add_signal(AutosarSignalConfig signal);
    void add_pdu(AutosarPduConfig pdu);
    void add_route(AutosarRouteConfig route);
    void write_signal(const std::string& signal_id, std::uint64_t value);
    [[nodiscard]] std::vector<AutosarTransportFrame> transmit(const std::string& pdu_id);
    [[nodiscard]] AutosarE2eStatus receive(const std::string& pdu_id, const std::vector<AutosarTransportFrame>& frames);
    [[nodiscard]] std::uint64_t read_signal(const std::string& signal_id) const;
    [[nodiscard]] AutosarCommunicationReport report() const;
private:
    std::map<std::string, AutosarSignalConfig> signals_;
    std::map<std::string, AutosarPduConfig> pdus_;
    std::map<std::string, AutosarRouteConfig> routes_;
    std::map<std::string, std::vector<std::uint8_t>> payloads_;
    std::map<std::string, std::uint32_t> transmit_counters_;
    std::map<std::string, std::uint32_t> receive_counters_;
    AutosarCommunicationReport report_;
};

// ============================================================================
// Phase C — body electronics, smart power and vehicle access
// ============================================================================

enum class WiperMode { Off, Intermittent, Low, High, Automatic };
struct BodyControlInput { bool ignition = false; bool hazard = false; bool left_indicator = false; bool right_indicator = false; bool high_beam_request = false; bool brake_pressed = false; bool reverse = false; bool lock_request = false; bool unlock_request = false; bool door_open = false; double ambient_lux = 1000.0; double rain_intensity = 0.0; WiperMode wiper_request = WiperMode::Off; double dt_s = 0.01; };
struct BodyControlOutput { double low_beam_duty = 0.0; double high_beam_duty = 0.0; double left_indicator_duty = 0.0; double right_indicator_duty = 0.0; double brake_lamp_duty = 0.0; double reverse_lamp_duty = 0.0; double interior_lamp_duty = 0.0; WiperMode effective_wiper_mode = WiperMode::Off; double wiper_position = 0.0; bool doors_locked = false; bool horn_active = false; std::vector<std::string> diagnostic_events; };
class BodyControlModuleAuthority { public: [[nodiscard]] BodyControlOutput advance(const BodyControlInput& input); void set_lamp_current_feedback(std::string circuit, double current_a); private: BodyControlOutput state_; std::map<std::string,double> lamp_current_a_; double blink_phase_s_=0.0; double wiper_phase_=0.0; };

struct SmartPowerChannelPolicy { std::string load_id; int priority = 0; bool essential = false; double retry_delay_s = 1.0; std::size_t maximum_retries = 3; };
struct SmartPowerDistributionReport { std::set<std::string> commanded_off; std::set<std::string> commanded_on; std::map<std::string,std::size_t> retries; bool emergency_load_shed = false; std::vector<std::string> diagnostics; };
class SmartPowerDistributionController {
public: void add_channel(SmartPowerChannelPolicy policy); [[nodiscard]] SmartPowerDistributionReport update(const PowerNetworkReport& network,double dt_s); void apply(LowVoltagePowerNetwork& network) const;
private: std::map<std::string,SmartPowerChannelPolicy> policies_; std::map<std::string,double> disabled_elapsed_s_; std::map<std::string,std::size_t> retries_; std::set<std::string> disabled_;
};

enum class BodyActuatorKind { Window, SeatAxis, MirrorAxis, Sunroof, Tailgate };
struct BodyActuatorConfig { std::string id; BodyActuatorKind kind=BodyActuatorKind::Window; double motor_resistance_ohm=1.0; double torque_constant_nm_a=0.05; double back_emf_v_per_rad_s=0.05; double inertia_kg_m2=0.002; double damping_nm_s_rad=0.002; double gear_ratio=50.0; double travel_units=1.0; double pinch_force_n=100.0; double thermal_resistance_k_w=10.0; double thermal_capacitance_j_k=10.0; };
struct BodyActuatorCommand { double target_position=0.0; double supply_voltage_v=12.0; double obstruction_force_n=0.0; bool enable=true; };
struct BodyActuatorReport { double position=0.0; double velocity=0.0; double motor_current_a=0.0; double motor_temperature_k=298.15; double pwm_duty=0.0; bool stalled=false; bool pinch_detected=false; bool reversed_for_pinch=false; bool end_stop_learned=false; std::string diagnostic; };
class DistributedBodyActuatorEcu { public: explicit DistributedBodyActuatorEcu(BodyActuatorConfig config); [[nodiscard]] BodyActuatorReport advance(double dt_s,const BodyActuatorCommand& command,double ambient_temperature_k=298.15); void learn_end_stops(double minimum,double maximum); private: BodyActuatorConfig config_; BodyActuatorReport state_; double motor_speed_rad_s_=0.0; double min_position_=0.0,max_position_=1.0; };

struct UwbAnchor { std::string id; std::array<double,3> position_m{0,0,0}; };
struct UwbRangingObservation { std::string anchor_id; double round_trip_time_ns=0.0; double rssi_dbm=-50.0; bool secure_timestamp=true; double nlos_bias_m=0.0; };
struct PepsLocalizationReport { std::array<double,3> position_m{0,0,0}; double residual_rms_m=0.0; double nearest_vehicle_distance_m=1e30; bool inside_vehicle=false; bool trunk_zone=false; bool approach_zone=false; bool relay_attack_suspected=false; bool localization_valid=false; std::vector<std::string> diagnostics; };
class PepsUwbDigitalKeyAuthority { public: void add_anchor(UwbAnchor anchor); void set_vehicle_bounds(std::array<double,3> minimum_m,std::array<double,3> maximum_m); [[nodiscard]] PepsLocalizationReport localize(const std::vector<UwbRangingObservation>& observations) const; private: std::map<std::string,UwbAnchor> anchors_; std::array<double,3> min_{-2,-1,-0.5},max_{2,1,1.5}; };

struct ProductionProvisioningRecord { std::string device_id; std::string vin; std::string calibration_digest; std::string immobilizer_peer; std::map<std::string,std::uint64_t> otp_words; bool debug_enabled=false; ProvisionedIdentity lifecycle_identity; std::vector<std::string> audit_log; };
class ProductionProvisioningAuthority {
public: explicit ProductionProvisioningAuthority(SecureProvisioningLifecycle& lifecycle,std::string debug_secret); void enroll(const std::string& device_id,const std::string& lot,const std::string& vin); void program_otp(const std::string& device_id,const std::string& word,std::uint64_t value); void set_calibration_digest(const std::string& device_id,std::string digest); void pair_immobilizer(const std::string& device_id,std::string peer_id); [[nodiscard]] std::string issue_debug_token(const std::string& device_id,bool enable) const; void authorize_debug(const std::string& device_id,bool enable,const std::string& token); void transition(const std::string& device_id,ProvisioningLifecycle target); [[nodiscard]] ProductionProvisioningRecord record(const std::string& device_id) const;
private: SecureProvisioningLifecycle& lifecycle_; std::string secret_; std::map<std::string,ProductionProvisioningRecord> records_;
};

// ============================================================================
// Phase D — cockpit/IVI, display/audio and centralized ADAS compute
// ============================================================================

struct CockpitWorkload { std::string id; double cpu_ms=1.0; double gpu_ms=0.0; double npu_ms=0.0; double memory_mb=1.0; double storage_mb=0.0; double deadline_ms=100.0; unsigned priority=1; bool safety_relevant=false; };
struct CockpitComputerConfig { double cpu_capacity_ms_per_ms=8.0; double gpu_capacity_ms_per_ms=2.0; double npu_capacity_ms_per_ms=1.0; double memory_bandwidth_gbps=20.0; double storage_bandwidth_mb_s=500.0; double thermal_limit_k=373.15; double thermal_resistance_k_w=2.0; double thermal_capacitance_j_k=50.0; };
struct CockpitComputerReport { std::size_t completed=0; std::size_t deadline_misses=0; std::size_t safety_deadline_misses=0; double cpu_utilization=0.0; double gpu_utilization=0.0; double npu_utilization=0.0; double memory_utilization=0.0; double temperature_k=298.15; bool thermal_throttling=false; std::vector<std::string> diagnostics; };
class CockpitIviComputerAuthority { public: explicit CockpitIviComputerAuthority(CockpitComputerConfig config={}); void submit(CockpitWorkload workload); [[nodiscard]] CockpitComputerReport advance(double dt_s,double ambient_temperature_k=298.15); private: struct RuntimeWork; CockpitComputerConfig config_; std::deque<std::shared_ptr<RuntimeWork>> queue_; CockpitComputerReport report_; };

struct DisplayPipelineConfig { std::size_t width=1920,height=1080; double refresh_hz=60.0; unsigned bits_per_pixel=32; double compositor_budget_ms=4.0; double gpu_render_budget_ms=8.0; double serializer_gbps=6.0; double panel_response_ms=8.0; std::size_t buffers=3; };
struct DisplayFrameRequest { std::uint64_t frame_id=0; double gpu_render_ms=1.0; double compositor_ms=1.0; std::size_t dirty_pixels=0; bool safety_critical=false; };
struct DisplayPipelineReport { std::size_t presented_frames=0; std::size_t missed_vsync=0; std::size_t dropped_frames=0; std::size_t safety_frame_misses=0; double last_frame_latency_ms=0.0; double serializer_utilization=0.0; bool tearing=false; bool frozen=false; std::vector<std::string> diagnostics; };
class DisplayPipelineAuthority { public: explicit DisplayPipelineAuthority(DisplayPipelineConfig config={}); void enqueue(DisplayFrameRequest frame); void inject_serializer_ber(double ber); void set_panel_reset(bool reset); [[nodiscard]] DisplayPipelineReport advance(double dt_s); private: DisplayPipelineConfig config_; std::deque<DisplayFrameRequest> queue_; DisplayPipelineReport report_; double time_s_=0.0,next_vsync_s_=0.0,serializer_ber_=0.0; bool panel_reset_=false; };

struct AudioElectronicsConfig { double sample_rate_hz=48000.0; std::size_t channels=8; double dsp_macs_per_s=2.0e9; double amplifier_efficiency=0.85; double amplifier_thermal_resistance_k_w=4.0; double amplifier_thermal_capacitance_j_k=20.0; double amplifier_shutdown_k=398.15; };
struct AudioProcessingRequest { std::size_t samples=480; double dsp_macs_per_sample=200.0; double requested_acoustic_power_w=10.0; double cabin_noise_rms_pa=0.1; double reference_noise_coherence=0.8; bool anc_enabled=true; };
struct AudioElectronicsReport { double dsp_utilization=0.0; double amplifier_input_power_w=0.0; double amplifier_temperature_k=298.15; double residual_noise_rms_pa=0.0; double anc_attenuation_db=0.0; bool xrun=false; bool thermal_shutdown=false; std::size_t underruns=0; };
class AutomotiveAudioElectronicsAuthority { public: explicit AutomotiveAudioElectronicsAuthority(AudioElectronicsConfig config={}); [[nodiscard]] AudioElectronicsReport process(double dt_s,const AudioProcessingRequest& request,double ambient_temperature_k=298.15); private: AudioElectronicsConfig config_; AudioElectronicsReport report_; };

enum class AcceleratorKind { Cpu, Gpu, Npu, Isp, Dsp, VideoCodec };
enum class SafetyCriticality { Qm, AsilB, AsilD };
struct ComputeAcceleratorConfig { std::string id; AcceleratorKind kind=AcceleratorKind::Cpu; double throughput_gops=100.0; double power_idle_w=1.0; double power_full_w=10.0; double thermal_resistance_k_w=2.0; double thermal_capacitance_j_k=20.0; };
struct ComputePartitionConfig { std::string id; SafetyCriticality criticality=SafetyCriticality::Qm; std::set<std::string> allowed_accelerators; double memory_bandwidth_quota_gbps=5.0; double noc_bandwidth_quota_gbps=5.0; double maximum_runtime_ms=100.0; std::size_t memory_quota_mb=1024; };
struct AdasComputeWorkload { std::string id; std::string partition; std::string accelerator; double operations_gop=1.0; double memory_read_mb=1.0; double memory_write_mb=1.0; double noc_mb=1.0; double deadline_ms=50.0; std::size_t working_set_mb=64; };
struct AdasSocReport { std::size_t completed_workloads=0; std::size_t deadline_misses=0; std::size_t safety_deadline_misses=0; std::size_t partition_violations=0; std::size_t watchdog_terminations=0; double ddr_utilization=0.0; double noc_utilization=0.0; std::map<std::string,double> accelerator_utilization; std::map<std::string,double> accelerator_temperature_k; std::map<std::string,double> dvfs_fraction; bool safety_island_fault=false; std::vector<std::string> diagnostics; };
class AdasSocContentionAndSafetyAuthority {
public: AdasSocContentionAndSafetyAuthority(double ddr_bandwidth_gbps=100.0,double noc_bandwidth_gbps=200.0); void add_accelerator(ComputeAcceleratorConfig accelerator); void add_partition(ComputePartitionConfig partition); void submit(AdasComputeWorkload workload); [[nodiscard]] AdasSocReport advance(double dt_s,double ambient_temperature_k=298.15); private: struct RuntimeWork; double ddr_gbps_,noc_gbps_; std::map<std::string,ComputeAcceleratorConfig> accelerators_; std::map<std::string,ComputePartitionConfig> partitions_; std::deque<std::shared_ptr<RuntimeWork>> queue_; AdasSocReport report_; std::map<std::string,double> temperatures_; };

// ============================================================================
// Phase E — reliability, EMC, harness faults, software/OTA and startup
// ============================================================================

struct EcuAgingComponent { std::string id; double capacitor_esr_ohm=0.02; double solder_reference_cycles=1.0e6; double oscillator_initial_ppm=10.0; };
struct EcuAgingReport { std::map<std::string,AgingReport> semiconductor; std::map<std::string,double> capacitor_esr_ohm; std::map<std::string,double> solder_damage; std::map<std::string,double> oscillator_drift_ppm; double system_failure_probability=0.0; std::string dominant_component; };
class EcuElectronicsAgingAuthority { public: void add_component(EcuAgingComponent component); [[nodiscard]] EcuAgingReport evaluate(const std::map<std::string,std::vector<AgingMissionPoint>>& missions) const; private: SemiconductorAgingLaboratory semiconductor_; std::map<std::string,EcuAgingComponent> components_; };

enum class EmcTransientKind { Iso7637Pulse1, Iso7637Pulse2a, Iso7637Pulse2b, Iso7637Pulse3a, Iso7637Pulse3b, LoadDump, Cranking, Esd, BulkCurrentInjection, RadiatedImmunity };
struct EmcTransientStimulus { EmcTransientKind kind=EmcTransientKind::LoadDump; double amplitude=0.0; double duration_s=0.0; double source_impedance_ohm=1.0; double frequency_hz=0.0; };
struct EmcProtectionConfig { double clamp_voltage_v=36.0; double series_resistance_ohm=0.1; double tvs_dynamic_resistance_ohm=0.05; double filter_attenuation_db=20.0; double ecu_uvlo_v=6.0; double ecu_ovlo_v=36.0; double immunity_field_v_m=100.0; };
struct EmcTransientReport { double ecu_terminal_voltage_v=12.0; double clamp_current_a=0.0; double dissipated_energy_j=0.0; double coupled_disturbance_v=0.0; double upset_probability=0.0; bool reset_expected=false; bool damage_expected=false; bool passed=false; std::vector<std::string> diagnostics; };
class AutomotiveEmcTransientQualificationAuthority { public: [[nodiscard]] EmcTransientReport evaluate(double nominal_supply_v,const EmcTransientStimulus& stimulus,const EmcProtectionConfig& protection) const; };

struct HarnessNode { std::string id; bool ground=false; double injected_current_a=0.0; };
struct HarnessSegmentElectrical { std::string id; std::string from; std::string to; double length_m=1.0; double resistance_ohm_per_m=0.02; double inductance_h_per_m=0.5e-6; double capacitance_f_per_m=50e-12; double contact_resistance_ohm=0.0; double shield_transfer_impedance_ohm_per_m=0.01; };
struct HarnessFault { std::string segment_id; double added_resistance_ohm=0.0; double leakage_to_ground_ohm=1e30; bool open=false; bool short_to_ground=false; };
struct HarnessElectricalReport { std::map<std::string,double> node_voltage_v; std::map<std::string,double> segment_current_a; std::map<std::string,double> ground_offset_v; std::map<std::string,double> coupled_noise_v; double harness_loss_w=0.0; bool converged=false; std::vector<std::string> diagnostics; };
class WiringHarnessGroundingAuthority { public: void add_node(HarnessNode node); void add_segment(HarnessSegmentElectrical segment); void set_source(std::string node,double voltage_v,double source_resistance_ohm=0.01); void set_fault(HarnessFault fault); [[nodiscard]] HarnessElectricalReport solve() const; private: std::map<std::string,HarnessNode> nodes_; std::map<std::string,HarnessSegmentElectrical> segments_; std::map<std::string,HarnessFault> faults_; std::string source_node_; double source_voltage_v_=12.0,source_resistance_ohm_=0.01; };

enum class IntermittentFaultTarget { ConnectorOpen, GroundResistance, HarnessShort, SolderCrack, NetworkTransient, MoistureLeakage };
struct IntermittentFaultConfig { std::string id; IntermittentFaultTarget target=IntermittentFaultTarget::ConnectorOpen; double base_rate_per_hour=1e-4; double temperature_coefficient=0.02; double vibration_coefficient=0.5; double humidity_coefficient=1.0; double current_coefficient=0.01; double mean_active_duration_s=0.1; };
struct IntermittentEnvironment { double temperature_k=298.15; double vibration_rms_g=0.0; double relative_humidity=0.5; double current_a=0.0; };
struct IntermittentFaultReport { std::set<std::string> active_faults; std::map<std::string,double> instantaneous_rate_per_hour; std::map<std::string,std::size_t> activation_count; };
class IntermittentElectricalFaultEngine { public: explicit IntermittentElectricalFaultEngine(std::uint64_t seed=1); void add_fault(IntermittentFaultConfig fault); [[nodiscard]] IntermittentFaultReport advance(double dt_s,const IntermittentEnvironment& environment); private: struct RuntimeFault; std::uint64_t rng_; std::map<std::string,std::shared_ptr<RuntimeFault>> faults_; double uniform01(); };

struct SoftwareComponentVersion { std::string ecu_id; std::string version; std::string api_version; std::string schema_version; std::string calibration_version; std::string bootloader_version; };
struct SoftwareCompatibilityRule { std::string source_ecu; std::string target_ecu; std::string minimum_target_version; std::string maximum_target_version; std::string required_api_version; std::string required_schema_version; std::string minimum_bootloader_version; };
struct SoftwareCompatibilityReport { bool compatible=true; std::vector<std::string> violations; std::vector<std::string> installation_order; };
class SoftwareCompatibilityDeploymentGraph { public: void set_component(SoftwareComponentVersion component); void add_rule(SoftwareCompatibilityRule rule); [[nodiscard]] SoftwareCompatibilityReport evaluate() const; [[nodiscard]] SoftwareCompatibilityReport evaluate_candidate(const std::map<std::string,SoftwareComponentVersion>& candidate) const; [[nodiscard]] SoftwareCompatibilityReport evaluate_versions(const std::map<std::string,std::string>& target_versions) const; private: std::map<std::string,SoftwareComponentVersion> components_; std::vector<SoftwareCompatibilityRule> rules_; };

struct OtaCampaignEcu { std::string ecu_id; std::string current_version; std::string target_version; std::vector<std::uint8_t> payload; double minimum_soc=0.30; std::vector<std::string> dependencies; bool canary=false; };
struct OtaCampaignReport { std::map<std::string,electrification::OtaLifecycleOutput> ecu_state; std::vector<std::string> completed_order; std::vector<std::string> failed_ecus; bool compatibility_blocked=false; bool campaign_complete=false; bool rollback_in_progress=false; double fleet_progress=0.0; std::vector<std::string> diagnostics; };
class ProductionOtaCampaignOrchestrator { public: explicit ProductionOtaCampaignOrchestrator(const SoftwareCompatibilityDeploymentGraph* graph=nullptr); void begin(std::string campaign_id,std::vector<OtaCampaignEcu> ecus); [[nodiscard]] OtaCampaignReport advance(double dt_s,bool vehicle_stationary,double battery_soc,const std::map<std::string,bool>& ecu_health); void request_campaign_rollback(); private: std::string campaign_id_; std::map<std::string,OtaCampaignEcu> configs_; std::map<std::string,electrification::OtaLifecycleManager> managers_; const SoftwareCompatibilityDeploymentGraph* graph_=nullptr; OtaCampaignReport report_; bool rollback_requested_=false; };

struct VehicleStartupNode { std::string id; double duration_s=0.010; double deadline_s=1.0; std::vector<std::string> dependencies; bool safety_relevant=false; };
struct VehicleStartupReport { bool valid_graph=false; bool complete=false; double elapsed_s=0.0; double critical_path_s=0.0; std::vector<std::string> critical_path; std::map<std::string,double> completion_time_s; std::vector<std::string> deadline_misses; std::vector<std::string> blocked_nodes; };
class WholeVehicleStartupAuthority { public: void add_node(VehicleStartupNode node); void set_node_available(const std::string& id,bool available); [[nodiscard]] VehicleStartupReport analyze() const; [[nodiscard]] VehicleStartupReport advance(double dt_s); void reset(); private: std::map<std::string,VehicleStartupNode> nodes_; std::map<std::string,bool> available_; std::map<std::string,double> elapsed_; std::map<std::string,double> completed_at_; double total_elapsed_s_=0.0; };

struct ElectronicsComputePhaseCoverage { std::map<std::string,bool> phase_a,phase_b,phase_c,phase_d,phase_e; [[nodiscard]] bool all_implemented() const; };
[[nodiscard]] ElectronicsComputePhaseCoverage electronics_compute_phase_coverage();

} // namespace aesim::advanced::electronics

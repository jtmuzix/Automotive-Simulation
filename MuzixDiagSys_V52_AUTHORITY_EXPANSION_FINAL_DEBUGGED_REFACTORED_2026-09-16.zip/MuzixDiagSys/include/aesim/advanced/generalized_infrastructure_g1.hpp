#pragma once

#include "aesim/advanced/execution_graph.hpp"
#include "aesim/core/provenance.hpp"
#include "aesim/core/validation.hpp"
#include "aesim/frontier/frontier.hpp"
#include "aesim/high_fidelity/vehicle_depth.hpp"
#include "aesim/industrial/signals.hpp"
#include "aesim/platform/engineering.hpp"
#include "aesim/professional/checkpoint.hpp"
#include "aesim/professional/document.hpp"
#include "aesim/professional/scenario.hpp"
#include "aesim/professional/units.hpp"
#include "aesim/research2/causal_simulation.hpp"

#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::g1 {

using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;

// Semi-explicit index-1 DAE contract: xdot=f(t,x,z,u), 0=g(t,x,z,u), y=h(t,x,z,u).
struct DaeCallbacks {
    std::function<Vector(double,const Vector&,const Vector&,const Vector&)> derivatives;
    std::function<Vector(double,const Vector&,const Vector&,const Vector&)> algebraic_residual;
    std::function<Vector(double,const Vector&,const Vector&,const Vector&)> outputs;
};

struct DaeStepResult {
    double time_s = 0.0;
    Vector state;
    Vector algebraic;
    Vector outputs;
    double algebraic_residual_norm = 0.0;
    std::size_t algebraic_iterations = 0;
};

class GeneralizedDaeSubsystem {
public:
    GeneralizedDaeSubsystem(std::string name,
                            std::vector<std::string> state_names,
                            std::vector<std::string> algebraic_names,
                            std::vector<std::string> input_names,
                            std::vector<std::string> output_names,
                            DaeCallbacks callbacks);
    void reset(Vector state, Vector algebraic = {});
    [[nodiscard]] const std::string& name() const noexcept { return name_; }
    [[nodiscard]] const Vector& state() const noexcept { return state_; }
    [[nodiscard]] const Vector& algebraic() const noexcept { return algebraic_; }
    [[nodiscard]] Vector derivative(double time_s, const Vector& state,
                                    const Vector& algebraic, const Vector& input) const;
    [[nodiscard]] Vector algebraic_residual(double time_s, const Vector& state,
                                            const Vector& algebraic, const Vector& input) const;
    [[nodiscard]] Vector output(double time_s, const Vector& state,
                                const Vector& algebraic, const Vector& input) const;
    [[nodiscard]] Vector solve_consistent_algebraic(double time_s, const Vector& state,
                                                    const Vector& input, Vector guess,
                                                    double tolerance = 1.0e-10,
                                                    std::size_t maximum_iterations = 32,
                                                    std::size_t* iterations = nullptr) const;
    [[nodiscard]] DaeStepResult step(double time_s, double dt_s, const Vector& input,
                                     double algebraic_tolerance = 1.0e-10,
                                     std::size_t maximum_algebraic_iterations = 32);
    [[nodiscard]] doc::Value checkpoint() const;
    void restore(const doc::Value& checkpoint);
private:
    std::string name_;
    std::vector<std::string> state_names_, algebraic_names_, input_names_, output_names_;
    DaeCallbacks callbacks_;
    Vector state_, algebraic_;
    void validate_state(const Vector& state, const Vector& algebraic, const Vector& input) const;
};

// Generalized adapter over the existing canonical differentiable-model authority.
class AutomaticDifferentiation {
public:
    void load_document(const doc::Value& definition);
    void reset();
    void set_input(const std::string& name, double value);
    void set_parameter(const std::string& name, double value);
    [[nodiscard]] ::aesim::frontier::GradientResult evaluate(const std::string& output) const;
    [[nodiscard]] ::aesim::frontier::DifferentiableStepResult step(double dt_s);
    [[nodiscard]] doc::Value jacobian() const;
    [[nodiscard]] std::string status() const;
private:
    ::aesim::frontier::DifferentiableModel model_;
};

enum class EventDirection { Any, Rising, Falling };
struct EventDefinition {
    std::string id;
    EventDirection direction = EventDirection::Any;
    bool terminal = false;
    double value_tolerance = 1.0e-10;
    double time_tolerance_s = 1.0e-9;
    std::function<double(double,const Vector&)> function;
};
struct DetectedEvent {
    std::string id;
    double time_s = 0.0;
    Vector state;
    double residual = 0.0;
    bool terminal = false;
};
class EventDetector {
public:
    void add(EventDefinition event);
    void clear();
    [[nodiscard]] std::vector<DetectedEvent> detect(double t0, const Vector& x0,
                                                     double t1, const Vector& x1) const;
private:
    std::vector<EventDefinition> events_;
};

struct ParameterDefinition {
    std::string name;
    std::string description;
    std::string unit = "1";
    double default_value = 0.0;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
    double uncertainty_sigma = 0.0;
    std::string source = "assumed";
    bool calibratable = true;
};
struct ParameterValue {
    ParameterDefinition definition;
    double value_si = 0.0;
    std::uint64_t revision = 0;
};
class ParameterRegistry {
public:
    void register_parameter(ParameterDefinition definition);
    [[nodiscard]] bool contains(const std::string& name) const;
    void set(const std::string& name, double value, const std::string& unit = {});
    [[nodiscard]] double get_si(const std::string& name) const;
    [[nodiscard]] double get(const std::string& name, const std::string& unit = {}) const;
    [[nodiscard]] ParameterValue value(const std::string& name) const;
    [[nodiscard]] std::vector<ParameterValue> values() const;
    [[nodiscard]] std::uint64_t revision() const noexcept { return revision_; }
    [[nodiscard]] doc::Value snapshot() const;
    void restore(const doc::Value& document);
private:
    std::map<std::string,ParameterValue> parameters_;
    std::uint64_t revision_ = 0;
};

struct ExperimentCaseResult {
    std::size_t index = 0;
    std::map<std::string,double> parameters_si;
    scenario::RunResult scenario;
    std::string parameter_sha256;
};
struct ExperimentResult {
    bool passed = true;
    std::vector<ExperimentCaseResult> cases;
    [[nodiscard]] doc::Value to_document() const;
};
class ExperimentScenarioEngine {
public:
    using ApplyParameters = std::function<void(const std::map<std::string,double>&)>;
    [[nodiscard]] static ExperimentResult run(const doc::Value& scenario_document,
                                              const std::vector<std::map<std::string,double>>& parameter_sets,
                                              const scenario::RuntimeCallbacks& callbacks,
                                              ApplyParameters apply_parameters = {});
};

// Metadata-rich wrapper over the canonical SignalRegistry + TelemetryBroker authorities.
class UniversalTelemetryRegistry {
public:
    UniversalTelemetryRegistry();
    void register_channel(industrial::SignalDescriptor descriptor, double initial_value = 0.0);
    [[nodiscard]] bool contains(const std::string& name) const;
    platform::TelemetryFrame publish(double time_s, const std::string& name, double value,
                                     doc::Value metadata = doc::Value::Object{});
    [[nodiscard]] industrial::SignalValue sample(const std::string& name) const;
    [[nodiscard]] std::vector<industrial::SignalDescriptor> descriptors() const;
    [[nodiscard]] std::vector<platform::TelemetryFrame> history(std::size_t maximum = 0) const;
    [[nodiscard]] industrial::SignalRegistry& signals() noexcept { return signals_; }
    [[nodiscard]] platform::TelemetryBroker& broker() noexcept { return broker_; }
private:
    industrial::SignalRegistry signals_;
    platform::TelemetryBroker broker_;
};

class CheckpointBranchReplay {
public:
    explicit CheckpointBranchReplay(std::string directory);
    [[nodiscard]] checkpoint::Image checkpoint_now(const doc::Value& state,
                                                   const doc::Value& scheduler,
                                                   const doc::Value& random_streams,
                                                   const std::string& branch = {});
    bool save_checkpoint(const checkpoint::Image& image, std::string& path, std::string& error);
    void create_branch(const std::string& name, const checkpoint::Image& image);
    [[nodiscard]] checkpoint::Image branch(const std::string& name) const;
    [[nodiscard]] std::vector<std::string> branches() const;
    void begin_recording(const checkpoint::Image& initial);
    void record(std::int64_t time_ns, const std::string& command,
                const doc::Value& before, const doc::Value& after,
                const doc::Value& random_before, const doc::Value& random_after,
                const std::string& output = {});
    [[nodiscard]] checkpoint::ReplayResult replay(
        const std::function<bool(const std::string&,std::string&)>& execute,
        const std::function<std::string()>& state_hash,
        const std::function<std::string()>& random_hash = {}) const;
private:
    platform::ReplayCoordinator coordinator_;
    checkpoint::BranchManager branches_;
};

struct ConvergenceMetric {
    std::string name;
    double observed_order = 0.0;
    double richardson_extrapolated = 0.0;
    double finest_absolute_error = 0.0;
    bool monotone = false;
};
struct ConvergenceResult {
    bool converged = false;
    std::vector<double> step_sizes;
    std::vector<std::map<std::string,double>> outputs;
    std::vector<ConvergenceMetric> metrics;
    [[nodiscard]] doc::Value to_document() const;
};
class GeneralizedValidationFramework {
public:
    using Evaluator = std::function<std::map<std::string,double>(double)>;
    [[nodiscard]] static core::ValidationResult validate(
        const core::ValidationDataset& dataset, const core::ValidationFramework::Predictor& predictor,
        const std::vector<core::ValidationRequirement>& requirements = {});
    [[nodiscard]] static ConvergenceResult convergence(std::vector<double> step_sizes,
                                                       const Evaluator& evaluator,
                                                       double relative_tolerance = 1.0e-3);
};

class FidelityPerformanceManager {
public:
    void register_domain(high_fidelity::FidelityDomain domain,
                         high_fidelity::FidelityLevel initial,
                         high_fidelity::FidelityDomainAdapter adapter);
    void set_budget(double normalized_budget);
    void update(double time_s, double error_indicator, double event_severity,
                double wall_time_ms = 0.0);
    [[nodiscard]] high_fidelity::FidelityLevel level(high_fidelity::FidelityDomain domain) const;
    [[nodiscard]] double mean_wall_time_ms() const noexcept;
    [[nodiscard]] const std::vector<high_fidelity::FidelityTransition>& transitions() const noexcept;
private:
    high_fidelity::MultiFidelityCoordinator coordinator_;
    double wall_time_sum_ms_ = 0.0;
    std::uint64_t samples_ = 0;
};

struct ValidityBound {
    std::string signal;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
    std::string unit = "1";
};
struct ValidityViolation {
    std::string signal;
    double value_si = 0.0;
    double minimum_si = 0.0;
    double maximum_si = 0.0;
    double normalized_extrapolation = 0.0;
};
struct ValidityResult {
    bool inside = true;
    std::vector<ValidityViolation> violations;
    [[nodiscard]] doc::Value to_document() const;
};
class ModelValidityEnvelope {
public:
    explicit ModelValidityEnvelope(std::string id = {});
    void add(ValidityBound bound);
    [[nodiscard]] ValidityResult evaluate(const std::map<std::string,std::pair<double,std::string>>& values) const;
    [[nodiscard]] const std::string& id() const noexcept { return id_; }
private:
    std::string id_;
    std::map<std::string,ValidityBound> bounds_;
};

class ProvenanceAuthority {
public:
    [[nodiscard]] static platform::ReproducibilityManifest create(
        std::string run_id, std::string workspace_id, std::uint64_t seed,
        const doc::Value& configuration, std::string source_revision,
        std::map<std::string,std::string> input_sha256 = {},
        std::string compute_backend = "cpu");
};

class RuntimeDependencyCausalGraph {
public:
    void add(research2::CausalDependency dependency);
    void clear();
    [[nodiscard]] std::vector<std::string> upstream(const std::string& signal) const;
    [[nodiscard]] std::vector<std::string> downstream(const std::string& signal) const;
    [[nodiscard]] std::vector<std::string> topological_order() const;
    [[nodiscard]] research2::RunDifferenceReport compare(
        const std::vector<research2::TimelineRecord>& baseline,
        const std::vector<research2::TimelineRecord>& candidate,
        double absolute_tolerance = 1.0e-9,
        double relative_tolerance = 1.0e-6) const;
    [[nodiscard]] doc::Value to_document() const;
private:
    std::vector<research2::CausalDependency> dependencies_;
};

// Single integration point for G1. Existing authorities remain canonical and are exposed/composed here.
class GeneralizedInfrastructurePlatform {
public:
    GeneralizedInfrastructurePlatform();
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
    [[nodiscard]] doc::Value execute(const std::string& domain, const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] ParameterRegistry& parameters() noexcept { return parameters_; }
    [[nodiscard]] UniversalTelemetryRegistry& telemetry() noexcept { return telemetry_; }
    [[nodiscard]] DeterministicExecutionGraph& execution_graph() noexcept { return execution_graph_; }
    [[nodiscard]] RuntimeDependencyCausalGraph& dependency_graph() noexcept { return dependency_graph_; }
private:
    mutable ParameterRegistry parameters_;
    mutable UniversalTelemetryRegistry telemetry_;
    mutable DeterministicExecutionGraph execution_graph_;
    mutable RuntimeDependencyCausalGraph dependency_graph_;
};

} // namespace aesim::advanced::g1

#pragma once

#include "aesim/advanced/assured_engineering_operations_platform.hpp"
#include "aesim/advanced/qualification_science_platform.hpp"
#include "aesim/advanced/scientific_fidelity_platform.hpp"
#include "aesim/core/mathematical_assurance.hpp"
#include "aesim/core/provenance.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::research_authority {

using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;
using ScalarFunction = std::function<double(const Vector&)>;
using VectorFunction = std::function<Vector(const Vector&)>;

// ============================================================================
// R1 — Scientific Credibility
// ============================================================================

struct VerificationEvidence {
    std::string id;
    std::string kind;
    double score = 0.0;
    double uncertainty = 0.0;
    double weight = 1.0;
    bool passed = false;
    std::string evidence_sha256;
};

struct CodeVerificationReport {
    core::math_assurance::ConvergenceReport convergence;
    double expected_order = 0.0;
    double observed_order_margin = 0.0;
    bool passed = false;
    std::string evidence_sha256;
};

struct SolutionVerificationReport {
    core::math_assurance::ConvergenceReport convergence;
    double discretization_standard_uncertainty = 0.0;
    double numerical_standard_uncertainty = 0.0;
    double expanded_numerical_uncertainty = 0.0;
    bool asymptotic = false;
    bool passed = false;
    std::string evidence_sha256;
};

class ExplicitVerificationLaboratory {
public:
    [[nodiscard]] CodeVerificationReport verify_code_order(
        std::vector<core::math_assurance::RefinementSample> samples,
        double expected_order,
        double minimum_order_fraction = 0.90) const;

    [[nodiscard]] SolutionVerificationReport verify_solution(
        std::vector<core::math_assurance::RefinementSample> samples,
        double iterative_standard_uncertainty = 0.0,
        double input_numerical_standard_uncertainty = 0.0,
        double coverage_factor = 1.96) const;
};

struct PredictiveCheckStatistic {
    std::string name;
    double observed = 0.0;
    double replicated_mean = 0.0;
    double replicated_standard_deviation = 0.0;
    double posterior_predictive_p_value = 0.0;
    double z_score = 0.0;
    bool tail_flag = false;
};

struct PosteriorPredictiveCheckReport {
    std::vector<PredictiveCheckStatistic> statistics;
    double minimum_two_sided_p_value = 1.0;
    double fraction_flagged = 0.0;
    bool passed = false;
    std::string evidence_sha256;
};

class PosteriorPredictiveChecker {
public:
    using Statistic = std::function<double(const Vector&)>;
    [[nodiscard]] PosteriorPredictiveCheckReport evaluate(
        const Vector& observed,
        const std::vector<Vector>& replicated,
        const std::vector<std::pair<std::string, Statistic>>& statistics,
        double tail_probability = 0.025) const;
};

struct SimulationCalibrationDimension {
    std::string parameter;
    double rank_mean = 0.0;
    double rank_variance = 0.0;
    double chi_square = 0.0;
    double chi_square_p_value = 0.0;
    double coverage_50 = 0.0;
    double coverage_90 = 0.0;
    double coverage_95 = 0.0;
    bool calibrated = false;
};

struct SimulationBasedCalibrationReport {
    std::size_t replications = 0;
    std::size_t posterior_draws = 0;
    std::vector<SimulationCalibrationDimension> dimensions;
    bool passed = false;
    std::string evidence_sha256;
};

class SimulationBasedCalibration {
public:
    [[nodiscard]] SimulationBasedCalibrationReport evaluate(
        const std::vector<std::string>& parameter_names,
        const std::vector<Vector>& true_parameters,
        const std::vector<std::vector<Vector>>& posterior_draws,
        std::size_t histogram_bins = 10,
        double minimum_chi_square_p_value = 0.01) const;
};

struct PriorPredictiveCheck {
    std::string name;
    double lower_bound = 0.0;
    double upper_bound = 0.0;
    double fraction_inside = 0.0;
    double q025 = 0.0;
    double q50 = 0.0;
    double q975 = 0.0;
    bool passed = false;
};

struct PriorPredictiveValidationReport {
    std::vector<PriorPredictiveCheck> checks;
    double joint_pass_fraction = 0.0;
    bool passed = false;
    std::string evidence_sha256;
};

class PriorPredictiveValidator {
public:
    [[nodiscard]] PriorPredictiveValidationReport evaluate(
        const std::map<std::string, Vector>& prior_predictive_samples,
        const std::map<std::string, std::pair<double, double>>& physically_plausible_bounds,
        double required_inside_fraction = 0.95) const;
};

struct CredibilityAssessmentInput {
    SimulationQualityRequest quality_request;
    CodeVerificationReport code_verification;
    SolutionVerificationReport solution_verification;
    BayesianModelAverageReport model_comparison;
    PosteriorPredictiveCheckReport posterior_predictive;
    SimulationBasedCalibrationReport simulation_calibration;
    PriorPredictiveValidationReport prior_predictive;
    double validation_score = 0.0;
    double validation_uncertainty = 0.0;
};

struct CredibilityAssessment {
    SimulationQualityContract qualification;
    double credibility_score = 0.0;
    double lower_confidence_score = 0.0;
    bool defensible_for_intended_use = false;
    std::vector<VerificationEvidence> evidence;
    std::vector<std::string> restrictions;
    std::string evidence_sha256;
};

class FormalVVCredibilityAuthority {
public:
    [[nodiscard]] CredibilityAssessment assess(const CredibilityAssessmentInput& input) const;
};

// Existing BayesianMultimodelInference remains the canonical Bayesian model
// comparison engine. This adapter adds pairwise Bayes-factor diagnostics without
// duplicating the model-evidence implementation.
struct BayesianComparisonDiagnostic {
    BayesianModelAverageReport model_average;
    std::map<std::string, double> pairwise_log_bayes_factor;
    double posterior_entropy_nats = 0.0;
    std::string evidence_sha256;
};
class BayesianModelComparisonAuthority {
public:
    [[nodiscard]] BayesianComparisonDiagnostic compare(
        const std::vector<BayesianModelEvidence>& evidence) const;
};

// ============================================================================
// R2 — Inference Laboratory
// ============================================================================

struct TimeObservation {
    std::size_t step = 0;
    Vector value;
    Matrix covariance;
};

struct FourDVarProblem {
    Vector background_state;
    Matrix background_covariance;
    std::vector<Vector> controls;
    std::vector<TimeObservation> observations;
    std::function<Vector(const Vector&, const Vector&, double)> transition;
    std::function<Vector(const Vector&)> observation_operator;
    double time_step = 1.0;
};

struct VariationalIteration {
    std::size_t iteration = 0;
    double objective = 0.0;
    double gradient_norm = 0.0;
    double step_length = 0.0;
};

struct FourDVarResult {
    Vector analysis_initial_state;
    std::vector<Vector> trajectory;
    Matrix analysis_covariance;
    std::vector<VariationalIteration> history;
    double background_cost = 0.0;
    double observation_cost = 0.0;
    double final_cost = 0.0;
    bool converged = false;
    std::string evidence_sha256;
};

class FourDVarSolver {
public:
    [[nodiscard]] FourDVarResult solve(
        const FourDVarProblem& problem,
        std::size_t maximum_iterations = 80,
        double gradient_tolerance = 1.0e-7) const;
};

struct HybridEnVarProblem {
    Vector background_state;
    Matrix static_covariance;
    std::vector<Vector> ensemble;
    double ensemble_weight = 0.5;
    std::vector<TimeObservation> observations;
    std::vector<Vector> controls;
    std::function<Vector(const Vector&, const Vector&, double)> transition;
    std::function<Vector(const Vector&)> observation_operator;
    double time_step = 1.0;
};
struct HybridEnVarResult {
    Vector analysis_state;
    Matrix hybrid_covariance;
    Matrix analysis_covariance;
    std::vector<Vector> trajectory;
    double cost = 0.0;
    bool converged = false;
    std::string evidence_sha256;
};
class HybridEnVarSolver {
public:
    [[nodiscard]] HybridEnVarResult solve(const HybridEnVarProblem& problem,
                                           std::size_t maximum_iterations = 60,
                                           double gradient_tolerance = 1.0e-7) const;
};

struct ParameterBound { double lower = -1.0e300; double upper = 1.0e300; };
struct ProfilePoint { double fixed_value = 0.0; double optimized_log_likelihood = 0.0; Vector nuisance_parameters; };
struct ProfileLikelihoodParameterReport {
    std::string parameter;
    std::vector<ProfilePoint> profile;
    double mle = 0.0;
    double lower_confidence = 0.0;
    double upper_confidence = 0.0;
    bool lower_bounded = false;
    bool upper_bounded = false;
    bool identifiable = false;
};
struct ProfileLikelihoodReport {
    Vector mle_parameters;
    double maximum_log_likelihood = 0.0;
    std::vector<ProfileLikelihoodParameterReport> parameters;
    bool locally_identifiable = false;
    std::string evidence_sha256;
};
class ProfileLikelihoodIdentifiability {
public:
    [[nodiscard]] ProfileLikelihoodReport analyze(
        const std::vector<std::string>& parameter_names,
        const ScalarFunction& log_likelihood,
        Vector initial,
        std::vector<ParameterBound> bounds,
        std::size_t grid_points = 31,
        double confidence = 0.95) const;
};

struct HessianFisherReport {
    Matrix hessian;
    Matrix fisher_information;
    Matrix covariance;
    Vector hessian_eigenvalues;
    Vector fisher_eigenvalues;
    Vector parameter_standard_deviation;
    Vector correlation_condition_indices;
    std::size_t numerical_rank = 0;
    double condition_number = 0.0;
    bool positive_definite = false;
    bool identifiable = false;
    std::string evidence_sha256;
};
class HessianFisherDiagnostics {
public:
    [[nodiscard]] HessianFisherReport from_objective(
        const ScalarFunction& negative_log_posterior,
        const Vector& optimum) const;
    [[nodiscard]] HessianFisherReport from_sensitivities(
        const Matrix& jacobian,
        const Matrix& observation_covariance,
        const std::optional<Matrix>& prior_precision = std::nullopt) const;
};

struct ExperimentCandidate {
    std::string id;
    Vector sensitivity;
    double measurement_variance = 1.0;
    double cost = 1.0;
    std::string category;
};
struct ExperimentSelection {
    std::string id;
    double marginal_information_gain_nats = 0.0;
    double cumulative_information_gain_nats = 0.0;
    double cumulative_cost = 0.0;
};
struct BayesianExperimentDesignReport {
    std::vector<ExperimentSelection> selected;
    Matrix posterior_covariance;
    double prior_entropy_proxy = 0.0;
    double posterior_entropy_proxy = 0.0;
    double total_information_gain_nats = 0.0;
    bool budget_exhausted = false;
    std::string evidence_sha256;
};
class BayesianInformationGainDesigner {
public:
    [[nodiscard]] BayesianExperimentDesignReport design(
        const Matrix& prior_covariance,
        const std::vector<ExperimentCandidate>& candidates,
        double budget,
        std::size_t maximum_experiments = 0) const;
};

struct ModelResidualSeries { std::string model_id; Vector pointwise_log_likelihood; std::size_t parameter_count = 0; };
struct ModelDiscriminationEntry {
    std::string model_id;
    double log_likelihood = 0.0;
    double aic = 0.0;
    double aicc = 0.0;
    double bic = 0.0;
    double akaike_weight = 0.0;
    double bic_weight = 0.0;
};
struct ModelDiscriminationReport {
    std::vector<ModelDiscriminationEntry> models;
    std::string preferred_aic_model;
    std::string preferred_bic_model;
    double vuong_z = 0.0;
    double vuong_two_sided_p = 1.0;
    std::string vuong_pair;
    std::string evidence_sha256;
};
class ModelDiscriminationTester {
public:
    [[nodiscard]] ModelDiscriminationReport compare(
        const std::vector<ModelResidualSeries>& models) const;
};

// ============================================================================
// R3 — Numerical Research Authority
// ============================================================================

struct ProbabilisticState {
    double time = 0.0;
    Vector mean;
    Matrix covariance;
};
struct ProbabilisticIntegrationResult {
    std::vector<ProbabilisticState> states;
    std::size_t accepted_steps = 0;
    std::size_t rejected_steps = 0;
    double maximum_local_error = 0.0;
    bool converged = false;
    std::string evidence_sha256;
};
class ProbabilisticNumericsIntegrator {
public:
    using ODE = std::function<Vector(double, const Vector&)>;
    [[nodiscard]] ProbabilisticIntegrationResult integrate(
        const ODE& ode, double t0, double t1, const Vector& initial,
        double initial_step, double absolute_tolerance = 1e-8,
        double relative_tolerance = 1e-6) const;
};

enum class SolverKind { DormandPrince45, RosenbrockEuler, ImplicitTrapezoid };
struct SolverSwitchRecord { double time = 0.0; SolverKind from = SolverKind::DormandPrince45; SolverKind to = SolverKind::DormandPrince45; double stiffness_indicator = 0.0; };
struct SolverPortfolioResult {
    std::vector<double> time;
    std::vector<Vector> states;
    std::vector<SolverSwitchRecord> switches;
    std::size_t explicit_steps = 0;
    std::size_t implicit_steps = 0;
    std::size_t rejected_steps = 0;
    bool converged = false;
    std::string evidence_sha256;
};
class AdaptiveSolverPortfolio {
public:
    using ODE = std::function<Vector(double, const Vector&)>;
    [[nodiscard]] SolverPortfolioResult integrate(
        const ODE& ode, double t0, double t1, const Vector& initial,
        double initial_step, double absolute_tolerance = 1e-8,
        double relative_tolerance = 1e-6,
        double stiffness_switch_threshold = 2.5) const;
};

struct LinearDaeSystem { Matrix E; Matrix A; Vector b; };
struct DaeReductionResult {
    Matrix reduced_mass;
    Matrix reduced_dynamics;
    Vector reduced_forcing;
    std::vector<std::size_t> differential_variables;
    std::vector<std::size_t> algebraic_variables;
    std::size_t estimated_index = 0;
    bool reduction_successful = false;
    double algebraic_residual = 0.0;
    std::string evidence_sha256;
};
class DaeIndexReducer {
public:
    [[nodiscard]] DaeReductionResult reduce(const LinearDaeSystem& system,
                                             double rank_tolerance = 1e-10) const;
};

struct GoalOrientedCellContribution { std::size_t cell = 0; double residual = 0.0; double adjoint_weight = 0.0; double contribution = 0.0; };
struct GoalOrientedErrorReport {
    double estimated_goal_error = 0.0;
    double absolute_estimated_goal_error = 0.0;
    std::vector<GoalOrientedCellContribution> contributions;
    std::vector<std::size_t> refinement_priority;
    std::string evidence_sha256;
};
class GoalOrientedErrorEstimator {
public:
    [[nodiscard]] GoalOrientedErrorReport estimate(const Vector& primal_residual,
                                                    const Vector& adjoint_solution) const;
};

struct MechanicalState { Vector position; Vector momentum; };
struct EnergyMomentumSample { double time = 0.0; MechanicalState state; double energy = 0.0; };
struct EnergyMomentumResult {
    std::vector<EnergyMomentumSample> samples;
    double maximum_relative_energy_drift = 0.0;
    double momentum_drift_norm = 0.0;
    bool converged = false;
    std::string evidence_sha256;
};
class EnergyMomentumIntegrator {
public:
    using Potential = std::function<double(const Vector&)>;
    using PotentialGradient = std::function<Vector(const Vector&)>;
    [[nodiscard]] EnergyMomentumResult integrate(
        const Matrix& mass_matrix,
        const Potential& potential,
        const PotentialGradient& gradient,
        MechanicalState initial,
        double t0, double t1, double step,
        std::size_t nonlinear_iterations = 20,
        double tolerance = 1e-10) const;
};

class NonsmoothContactAuthority {
public:
    [[nodiscard]] ContactSolveReport solve(
        std::vector<ContactBodyState>& bodies,
        const std::vector<ContactConstraint>& contacts,
        double time_step,
        std::size_t maximum_iterations = 500,
        double tolerance = 1e-10,
        double relaxation = 1.0) const;
};

struct TimeParallelIteration { std::size_t iteration = 0; double maximum_correction = 0.0; };
struct TimeParallelResult {
    std::vector<double> slice_times;
    std::vector<Vector> states;
    std::vector<TimeParallelIteration> history;
    std::size_t fine_propagations = 0;
    bool converged = false;
    std::string evidence_sha256;
};
class TimeParallelIntegrator {
public:
    using Propagator = std::function<Vector(double, double, const Vector&)>;
    [[nodiscard]] TimeParallelResult parareal(
        const Propagator& coarse,
        const Propagator& fine,
        double t0, double t1,
        const Vector& initial,
        std::size_t slices,
        std::size_t maximum_iterations,
        double tolerance = 1e-8) const;
};

// ============================================================================
// R4 — Co-Simulation and Multi-Fidelity
// ============================================================================

struct PassivitySample { double time = 0.0; double effort = 0.0; double flow = 0.0; };
struct PassivityReport {
    double supplied_energy = 0.0;
    double extracted_energy = 0.0;
    double minimum_energy_margin = 0.0;
    bool passive = true;
    std::string evidence_sha256;
};
struct PassivityControlResult {
    Vector corrected_flow;
    double dissipated_energy = 0.0;
    double final_energy_tank = 0.0;
    bool intervention = false;
    std::string evidence_sha256;
};
class PassivityObserverController {
public:
    [[nodiscard]] PassivityReport observe(const std::vector<PassivitySample>& samples,
                                           double initial_stored_energy = 0.0) const;
    [[nodiscard]] PassivityControlResult control(const Vector& effort,
                                                  const Vector& proposed_flow,
                                                  double step_s,
                                                  double initial_energy_tank,
                                                  double minimum_energy_tank = 0.0) const;
};

struct CoSimulationStepProposal { std::string participant; double preferred_step_s = 0.0; double minimum_step_s = 0.0; double maximum_step_s = 0.0; double local_error = 0.0; double tolerance = 1e-6; bool rollback = true; };
struct StepNegotiationResult { double accepted_step_s = 0.0; assured::CouplingAction action = assured::CouplingAction::Accept; std::map<std::string,double> participant_suggestions; std::vector<std::string> reasons; };
class AdaptiveCoSimulationStepNegotiator {
public:
    [[nodiscard]] StepNegotiationResult negotiate(const std::vector<CoSimulationStepProposal>& proposals,
                                                   double current_step_s) const;
};

class ConservativeEnergyAccountingAuthority {
public:
    [[nodiscard]] assured::ConservationDiagnosticAudit audit(
        const std::vector<assured::ConservationInterfaceSample>& samples,
        bool rollback_available,
        double abort_multiple = 100.0) const;
};

struct MultiFidelityLevel { std::string id; double cost = 1.0; double variance = 1.0; };
struct MlmcLevelResult { std::string id; std::size_t samples = 0; double mean_correction = 0.0; double variance_correction = 0.0; double cost = 0.0; };
struct MultiFidelityMonteCarloReport {
    std::vector<MlmcLevelResult> levels;
    double estimate = 0.0;
    double estimated_standard_error = 0.0;
    double total_cost = 0.0;
    std::size_t total_samples = 0;
    std::string evidence_sha256;
};
class MultiFidelityMonteCarlo {
public:
    using Sampler = std::function<double(std::size_t level, std::uint64_t sample)>;
    [[nodiscard]] MultiFidelityMonteCarloReport estimate(
        const std::vector<MultiFidelityLevel>& levels,
        const Sampler& sampler,
        double target_standard_error,
        std::uint64_t seed = 1,
        std::size_t pilot_samples = 32) const;
};

struct CoKrigingSample { Vector x; double low_fidelity = 0.0; std::optional<double> high_fidelity; };
struct CoKrigingPrediction { double mean = 0.0; double variance = 0.0; double rho = 1.0; };
class CoKrigingMultiFidelityGP {
public:
    void fit(std::vector<CoKrigingSample> samples,
             double low_length_scale = 1.0,
             double discrepancy_length_scale = 1.0,
             double nugget = 1e-10);
    [[nodiscard]] CoKrigingPrediction predict(const Vector& x) const;
    [[nodiscard]] double rho() const noexcept { return rho_; }
private:
    std::vector<CoKrigingSample> samples_;
    double low_length_scale_ = 1.0;
    double discrepancy_length_scale_ = 1.0;
    double nugget_ = 1e-10;
    double rho_ = 1.0;
    double low_mean_ = 0.0;
    double discrepancy_mean_ = 0.0;
    Matrix low_inverse_;
    Matrix discrepancy_inverse_;
    Vector low_values_;
    std::vector<Vector> high_points_;
    Vector discrepancy_values_;
};

// ============================================================================
// R5 — Laboratory Metrology
// ============================================================================

struct CalibrationReference {
    std::string id;
    std::string quantity;
    std::string unit;
    double value = 0.0;
    double standard_uncertainty = 0.0;
    std::string calibration_certificate_id;
    std::string traceability_uri;
};
struct InstrumentAuthorityRecord {
    std::string instrument_id;
    std::string manufacturer;
    std::string model;
    std::string serial_number;
    std::string quantity;
    std::string unit;
    std::string calibration_date;
    std::string calibration_due_date;
    std::vector<CalibrationReference> references;
    double resolution = 0.0;
    bool environment_within_limits = true;
};
struct InstrumentAuthorityAssessment {
    bool authorized = false;
    bool calibration_current = false;
    bool traceability_complete = false;
    double calibration_chain_standard_uncertainty = 0.0;
    std::vector<std::string> findings;
    std::string evidence_sha256;
};
class Iso17025InstrumentAuthority {
public:
    [[nodiscard]] InstrumentAuthorityAssessment assess(const InstrumentAuthorityRecord& record,
                                                        const std::string& measurement_date) const;
};

enum class GumDistribution { Normal, Rectangular, Triangular, UShaped };
struct GumInputQuantity { std::string name; double estimate = 0.0; double standard_uncertainty = 0.0; double sensitivity = 1.0; double degrees_of_freedom = 1e300; GumDistribution distribution = GumDistribution::Normal; };
struct GumUncertaintyContribution { std::string name; double standard_contribution = 0.0; double variance_fraction = 0.0; };
struct GumUncertaintyReport {
    double estimate = 0.0;
    double combined_standard_uncertainty = 0.0;
    double effective_degrees_of_freedom = 0.0;
    double coverage_factor = 1.96;
    double expanded_uncertainty = 0.0;
    std::vector<GumUncertaintyContribution> contributions;
    std::string evidence_sha256;
};
class GumUncertaintyEngine {
public:
    [[nodiscard]] GumUncertaintyReport propagate(double output_estimate,
                                                  const std::vector<GumInputQuantity>& inputs,
                                                  double confidence = 0.95,
                                                  Matrix correlation = {}) const;
};

struct GageStudyObservation { std::string part; std::string operator_id; std::size_t repeat = 0; double value = 0.0; };
struct GageRrReport {
    double repeatability_variance = 0.0;
    double reproducibility_variance = 0.0;
    double part_to_part_variance = 0.0;
    double total_gage_rr_variance = 0.0;
    double total_variation = 0.0;
    double percent_gage_rr = 0.0;
    double ndc = 0.0;
    bool acceptable = false;
    std::string evidence_sha256;
};
class GageRrAnalyzer {
public:
    [[nodiscard]] GageRrReport crossed_anova(const std::vector<GageStudyObservation>& observations,
                                              double acceptable_percent = 10.0) const;
};

struct DigitalCalibrationCertificate {
    std::string certificate_id;
    std::string issuer;
    std::string issue_date;
    InstrumentAuthorityRecord instrument;
    GumUncertaintyReport uncertainty;
    std::map<std::string,std::string> metadata;
    std::string payload_sha256;
};
class DigitalCalibrationCertificateAuthority {
public:
    [[nodiscard]] DigitalCalibrationCertificate issue(std::string certificate_id,
                                                       std::string issuer,
                                                       std::string issue_date,
                                                       InstrumentAuthorityRecord instrument,
                                                       GumUncertaintyReport uncertainty,
                                                       std::map<std::string,std::string> metadata = {}) const;
    [[nodiscard]] bool verify(const DigitalCalibrationCertificate& certificate) const;
    void write_json(const DigitalCalibrationCertificate& certificate, const std::string& path) const;
};

struct TraceabilityNode { std::string id; std::string role; std::string certificate; double standard_uncertainty = 0.0; };
struct TraceabilityEdge { std::string child; std::string parent; };
struct MeasurementTraceabilityReport {
    bool complete = false;
    bool acyclic = false;
    std::vector<std::string> terminal_references;
    double chain_standard_uncertainty = 0.0;
    std::vector<std::string> findings;
    std::string evidence_sha256;
};
class MeasurementTraceabilityAuthority {
public:
    [[nodiscard]] MeasurementTraceabilityReport verify(const std::vector<TraceabilityNode>& nodes,
                                                        const std::vector<TraceabilityEdge>& edges,
                                                        const std::string& measurement_node) const;
};

// ============================================================================
// R6 — Research Reproducibility
// ============================================================================

struct ProvEntity { std::string id; std::string type; std::map<std::string,std::string> attributes; };
struct ProvActivity { std::string id; std::string type; std::string started_utc; std::string ended_utc; std::map<std::string,std::string> attributes; };
struct ProvAgent { std::string id; std::string type; std::map<std::string,std::string> attributes; };
struct ProvRelation { std::string type; std::string subject; std::string object; };
class W3cProvGraph {
public:
    void add_entity(ProvEntity entity);
    void add_activity(ProvActivity activity);
    void add_agent(ProvAgent agent);
    void add_relation(ProvRelation relation);
    [[nodiscard]] std::string json_ld() const;
    [[nodiscard]] std::string digest() const;
private:
    std::map<std::string,ProvEntity> entities_;
    std::map<std::string,ProvActivity> activities_;
    std::map<std::string,ProvAgent> agents_;
    std::vector<ProvRelation> relations_;
};

struct ResearchCard {
    std::string kind; // dataset or model
    std::string name;
    std::string version;
    std::string purpose;
    std::vector<std::string> intended_uses;
    std::vector<std::string> limitations;
    std::map<std::string,std::string> metadata;
};
struct CitationMetadata {
    std::string title;
    std::string version;
    std::string date_released;
    std::vector<std::string> authors;
    std::string doi;
    std::string repository;
    std::string license;
};
struct ImmutableManifestEntry { std::string path; std::uintmax_t size = 0; std::string sha256; };
struct ReproducibilityBundleReport {
    std::filesystem::path root;
    std::vector<ImmutableManifestEntry> manifest;
    std::string manifest_sha256;
    bool verified = false;
};
class ResearchReproducibilityAuthority {
public:
    [[nodiscard]] ReproducibilityBundleReport create_bundle(
        const std::filesystem::path& output_directory,
        const std::vector<std::filesystem::path>& artifacts,
        const W3cProvGraph& provenance,
        const std::vector<ResearchCard>& cards,
        const CitationMetadata& citation,
        const std::map<std::string,std::string>& run_metadata) const;
    [[nodiscard]] ReproducibilityBundleReport verify_bundle(
        const std::filesystem::path& output_directory) const;
};

// ============================================================================
// R7 — HPC Science
// ============================================================================

struct HardwareCounterObservation {
    double wall_seconds = 0.0;
    std::uint64_t cycles = 0;
    std::uint64_t instructions = 0;
    std::uint64_t cache_references = 0;
    std::uint64_t cache_misses = 0;
    std::uint64_t branches = 0;
    std::uint64_t branch_misses = 0;
    double floating_point_operations = 0.0;
    double bytes_transferred = 0.0;
    bool hardware_backed = false;
};
struct RooflinePoint { double operational_intensity_flop_per_byte = 0.0; double achieved_gflop_s = 0.0; double bandwidth_gb_s = 0.0; double compute_ceiling_gflop_s = 0.0; double memory_ceiling_gflop_s = 0.0; double roofline_efficiency = 0.0; std::string bound; };
class RooflineAnalyzer {
public:
    [[nodiscard]] RooflinePoint analyze(const HardwareCounterObservation& observation,
                                         double peak_gflop_s,
                                         double peak_bandwidth_gb_s) const;
};

struct PerformanceSampleSet { std::string label; Vector seconds; };
struct PerformanceRegressionReport {
    double baseline_mean = 0.0;
    double candidate_mean = 0.0;
    double relative_change = 0.0;
    double welch_t = 0.0;
    double approximate_two_sided_p = 1.0;
    double bootstrap_ci95_low = 0.0;
    double bootstrap_ci95_high = 0.0;
    double effect_size_cohens_d = 0.0;
    bool statistically_significant = false;
    bool practically_significant = false;
    bool regression = false;
    std::string evidence_sha256;
};
class PerformanceRegressionAuthority {
public:
    [[nodiscard]] PerformanceRegressionReport compare(
        const PerformanceSampleSet& baseline,
        const PerformanceSampleSet& candidate,
        double practical_regression_threshold = 0.03,
        std::uint64_t bootstrap_seed = 1,
        std::size_t bootstrap_resamples = 4000) const;
};

struct InSituField { std::string name; std::vector<std::size_t> shape; Vector values; };
struct InSituFrame { std::uint64_t step = 0; double simulation_time = 0.0; std::vector<InSituField> fields; std::map<std::string,double> metrics; };
class InSituVisualizationPipeline {
public:
    using Sink = std::function<void(const InSituFrame&)>;
    void configure(std::size_t stride, Sink sink, std::size_t maximum_values_per_field = 1000000);
    bool publish(InSituFrame frame);
    [[nodiscard]] std::uint64_t published_frames() const noexcept { return published_frames_; }
private:
    std::size_t stride_ = 1;
    std::size_t maximum_values_per_field_ = 1000000;
    Sink sink_;
    std::uint64_t published_frames_ = 0;
};

struct SteeringParameter { std::string name; double value = 0.0; double minimum = -1e300; double maximum = 1e300; bool mutable_during_run = true; };
struct SteeringAuditRecord { std::uint64_t sequence = 0; std::string parameter; double old_value = 0.0; double new_value = 0.0; std::string actor; std::string reason; };
class ComputationalSteeringAuthority {
public:
    void register_parameter(SteeringParameter parameter);
    bool update(const std::string& name, double value, std::string actor, std::string reason, std::string& error);
    [[nodiscard]] double value(const std::string& name) const;
    [[nodiscard]] std::vector<SteeringAuditRecord> audit() const;
private:
    std::map<std::string,SteeringParameter> parameters_;
    std::vector<SteeringAuditRecord> audit_;
    std::uint64_t next_sequence_ = 1;
};

struct TimeParallelJob { std::size_t slice = 0; double begin_time = 0.0; double end_time = 0.0; std::size_t iteration = 0; std::size_t resource = 0; };
struct TimeParallelProductionSchedule { std::vector<TimeParallelJob> jobs; std::size_t resources = 0; std::size_t waves = 0; double ideal_parallel_efficiency = 0.0; std::string evidence_sha256; };
class TimeParallelProductionScheduler {
public:
    [[nodiscard]] TimeParallelProductionSchedule schedule(double t0, double t1,
                                                           std::size_t slices,
                                                           std::size_t parareal_iterations,
                                                           std::size_t resources) const;
};

struct ResearchAuthorityCapabilities {
    std::vector<std::string> ordered_tranches;
    std::map<std::string,std::vector<std::string>> capabilities;
    std::map<std::string,std::string> reused_authorities;
};
[[nodiscard]] ResearchAuthorityCapabilities capabilities();
[[nodiscard]] std::string capabilities_json();

} // namespace aesim::advanced::research_authority

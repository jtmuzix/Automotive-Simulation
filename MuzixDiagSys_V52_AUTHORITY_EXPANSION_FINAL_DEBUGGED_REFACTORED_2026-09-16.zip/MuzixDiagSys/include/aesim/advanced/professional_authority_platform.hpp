#pragma once

#include "aesim/advanced/motorsport_v35_platform.hpp"
#include "aesim/core/mathematical_assurance.hpp"
#include "aesim/core/uncertainty.hpp"
#include "aesim/industrial/hil_io.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::authority {

[[nodiscard]] std::vector<std::string> professional_authority_v36_capabilities();

// V36 Professional Authority Platform. All quantities are SI unless the member
// name explicitly states otherwise. Implementations are deterministic for
// identical inputs/seeds and reject non-finite or physically invalid inputs.

// ---------------------------------------------------------------------------
// 1. MF-Tyre / MF-Swift and licensed external tyre-authority integration.
// ---------------------------------------------------------------------------

enum class TireAuthorityKind { MagicFormula, MagicFormulaSwift, ExternalFTire, ExternalCDTire };

struct MagicFormulaAxis {
    double B = 10.0;
    double C = 1.9;
    double D = 1.0;
    double E = 0.97;
    double horizontal_shift = 0.0;
    double vertical_shift = 0.0;
};

struct MagicFormulaParameters {
    double reference_load_n = 4000.0;
    double reference_pressure_pa = 190000.0;
    double unloaded_radius_m = 0.33;
    double vertical_stiffness_n_m = 250000.0;
    double vertical_damping_n_s_m = 1200.0;
    double nominal_mu = 1.75;
    double load_sensitivity = -0.12;
    double pressure_sensitivity = 0.08;
    double camber_stiffness_n_rad = 1000.0;
    double rolling_resistance_coefficient = 0.012;
    MagicFormulaAxis longitudinal{};
    MagicFormulaAxis lateral{8.5, 1.3, 1.0, -1.6, 0.0, 0.0};
    MagicFormulaAxis aligning{4.0, 1.1, 0.06, -1.0, 0.0, 0.0};
    double longitudinal_relaxation_m = 0.30;
    double lateral_relaxation_m = 0.45;
    double ring_mass_kg = 8.0;
    double ring_radial_stiffness_n_m = 380000.0;
    double ring_radial_damping_n_s_m = 1800.0;
    double ring_bending_stiffness_nm_rad = 1800.0;
};

struct TireOperatingPoint {
    double normal_load_n = 4000.0;
    double longitudinal_speed_m_s = 30.0;
    double wheel_angular_speed_rad_s = 90.0;
    double lateral_speed_m_s = 0.0;
    double camber_rad = 0.0;
    double pressure_pa = 190000.0;
    double surface_temperature_k = 303.15;
    double water_depth_m = 0.0;
    double road_roughness_m = 0.0;
    double dt_s = 0.001;
};

struct TireDynamicState {
    double relaxed_slip_ratio = 0.0;
    double relaxed_slip_angle_rad = 0.0;
    double ring_radial_deflection_m = 0.0;
    double ring_radial_velocity_m_s = 0.0;
};

struct TireForceResult {
    TireDynamicState state{};
    double slip_ratio = 0.0;
    double slip_angle_rad = 0.0;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double vertical_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double overturning_moment_nm = 0.0;
    double rolling_resistance_nm = 0.0;
    double effective_radius_m = 0.0;
    double friction_scale = 1.0;
    bool finite = true;
};

struct TireMeasurement {
    TireOperatingPoint input{};
    double measured_fx_n = 0.0;
    double measured_fy_n = 0.0;
    double measured_mz_nm = 0.0;
    double weight = 1.0;
};

struct TireFitReport {
    MagicFormulaParameters parameters{};
    double initial_rmse = 0.0;
    double final_rmse = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
};

class TireAuthorityModel {
public:
    explicit TireAuthorityModel(MagicFormulaParameters parameters = {}, TireAuthorityKind kind = TireAuthorityKind::MagicFormula);
    [[nodiscard]] TireForceResult evaluate(const TireOperatingPoint& input) const;
    [[nodiscard]] TireForceResult step(const TireOperatingPoint& input, const TireDynamicState& state) const;
    [[nodiscard]] const MagicFormulaParameters& parameters() const noexcept { return parameters_; }
    [[nodiscard]] TireAuthorityKind kind() const noexcept { return kind_; }
    [[nodiscard]] static MagicFormulaParameters load_tir(const std::string& path);
    static void save_tir(const MagicFormulaParameters& parameters, const std::string& path);
    [[nodiscard]] static TireFitReport fit(const std::vector<TireMeasurement>& measurements,
                                           MagicFormulaParameters initial = {}, std::size_t maximum_iterations = 160);
private:
    MagicFormulaParameters parameters_;
    TireAuthorityKind kind_;
};

class ExternalTireAuthority {
public:
    ExternalTireAuthority();
    ~ExternalTireAuthority();
    ExternalTireAuthority(const ExternalTireAuthority&) = delete;
    ExternalTireAuthority& operator=(const ExternalTireAuthority&) = delete;
    void open(const std::string& shared_library, TireAuthorityKind kind);
    void close() noexcept;
    [[nodiscard]] bool available() const noexcept;
    [[nodiscard]] TireForceResult evaluate(const TireOperatingPoint& input, const TireDynamicState& state) const;
    [[nodiscard]] std::string description() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// ---------------------------------------------------------------------------
// 2. Nonlinear damper/suspension laboratory.
// ---------------------------------------------------------------------------

struct DamperConfiguration {
    double piston_area_m2 = 0.0018;
    double low_speed_bump_n_s_m = 9000.0;
    double high_speed_bump_n_s_m = 3500.0;
    double low_speed_rebound_n_s_m = 11500.0;
    double high_speed_rebound_n_s_m = 4200.0;
    double knee_speed_m_s = 0.075;
    double digressivity = 2.2;
    double bleed_fraction = 0.08;
    double shim_stiffness_n_m = 950000.0;
    double shim_damping_n_s_m = 700.0;
    double gas_pressure_pa = 1.2e6;
    double gas_volume_m3 = 2.5e-4;
    double oil_bulk_modulus_pa = 1.4e9;
    double oil_mass_kg = 0.65;
    double oil_heat_capacity_j_kg_k = 1900.0;
    double housing_thermal_conductance_w_k = 14.0;
    double viscosity_reference_pa_s = 0.045;
    double viscosity_temperature_coefficient_k_inv = 0.028;
    double static_friction_n = 85.0;
    double coulomb_friction_n = 55.0;
    double stribeck_speed_m_s = 0.008;
    double cavitation_pressure_pa = 35000.0;
    double bump_stop_gap_m = 0.045;
    double bump_stop_rate_n_m = 500000.0;
    double inerter_kg = 0.0;
};

struct DamperState {
    double oil_temperature_k = 303.15;
    double gas_pressure_pa = 1.2e6;
    double shim_deflection_m = 0.0;
    double shim_velocity_m_s = 0.0;
    double aeration_fraction = 0.0;
};

struct DamperInput {
    double displacement_m = 0.0;
    double velocity_m_s = 0.0;
    double acceleration_m_s2 = 0.0;
    double ambient_temperature_k = 298.15;
    double dt_s = 0.001;
};

struct DamperResult {
    DamperState state{};
    double hydraulic_force_n = 0.0;
    double friction_force_n = 0.0;
    double gas_spring_force_n = 0.0;
    double bump_stop_force_n = 0.0;
    double inerter_force_n = 0.0;
    double total_force_n = 0.0;
    double dissipated_power_w = 0.0;
    double cavitation_fraction = 0.0;
    double fade_fraction = 0.0;
};

struct DamperDynoPoint { double displacement_m = 0.0; double velocity_m_s = 0.0; double measured_force_n = 0.0; double temperature_k = 303.15; };
struct DamperFitReport { DamperConfiguration configuration{}; double initial_rmse_n = 0.0; double final_rmse_n = 0.0; std::size_t iterations = 0; bool converged = false; };

class NonlinearDamperLaboratory {
public:
    explicit NonlinearDamperLaboratory(DamperConfiguration configuration = {});
    [[nodiscard]] DamperResult step(const DamperInput& input, const DamperState& state) const;
    [[nodiscard]] DamperFitReport fit_dynograph(const std::vector<DamperDynoPoint>& points, std::size_t maximum_iterations = 120) const;
    [[nodiscard]] const DamperConfiguration& configuration() const noexcept { return configuration_; }
private:
    DamperConfiguration configuration_;
};

// ---------------------------------------------------------------------------
// 3. Motorsport telemetry interoperability and correlation.
// ---------------------------------------------------------------------------

enum class TelemetryVendor { GenericCsv, Motec, McLarenAtlas, Cosworth, Mdf4 };
struct TelemetryChannel { std::string name; std::string unit; double sample_rate_hz = 0.0; };
struct TelemetrySample { double time_s = 0.0; std::map<std::string, double> values; };
struct TelemetryDataset {
    TelemetryVendor vendor = TelemetryVendor::GenericCsv;
    std::vector<TelemetryChannel> channels;
    std::vector<TelemetrySample> samples;
    std::vector<std::size_t> lap_start_indices;
};
struct TelemetryAlignment { double offset_s = 0.0; double drift_ppm = 0.0; double correlation = 0.0; double uncertainty_s = 0.0; };

class MotorsportTelemetryInterop {
public:
    [[nodiscard]] TelemetryDataset import_delimited(const std::string& path, TelemetryVendor vendor = TelemetryVendor::GenericCsv) const;
    static void normalize_units(TelemetryDataset& dataset);
    static void detect_laps(TelemetryDataset& dataset, const std::string& lap_channel = "Lap", const std::string& distance_channel = "Distance");
    [[nodiscard]] static TelemetryDataset resample_distance(const TelemetryDataset& dataset, double spacing_m,
                                                            const std::string& distance_channel = "Distance");
    [[nodiscard]] static TelemetryAlignment align(const TelemetryDataset& reference, const TelemetryDataset& candidate,
                                                  const std::string& channel, double maximum_offset_s = 5.0);
};

// ---------------------------------------------------------------------------
// 4. Generalized hardpoint-based suspension MBD/K&C authority.
// ---------------------------------------------------------------------------

struct Vec3 { double x = 0.0; double y = 0.0; double z = 0.0; };
enum class SuspensionTopology { DoubleWishbone, Pushrod, Pullrod, MacPherson, MultiLink, TrailingArm, SemiTrailingArm, DeDion, LiveAxle, TorsionBeam };
struct SuspensionCornerDefinition {
    SuspensionTopology topology = SuspensionTopology::DoubleWishbone;
    Vec3 wheel_center{};
    Vec3 upper_joint{};
    Vec3 lower_joint{};
    Vec3 tie_outer{};
    Vec3 tie_inner{};
    Vec3 upper_inner_front{};
    Vec3 upper_inner_rear{};
    Vec3 lower_inner_front{};
    Vec3 lower_inner_rear{};
    Vec3 spring_chassis{};
    Vec3 spring_upright{};
    double wheel_radius_m = 0.33;
    double compliance_camber_rad_n = 0.0;
    double compliance_toe_rad_n = 0.0;
};
struct SuspensionInput { double wheel_travel_m = 0.0; double steer_rack_displacement_m = 0.0; double vertical_load_n = 0.0; double lateral_force_n = 0.0; };
struct SuspensionKandCResult {
    double camber_rad = 0.0;
    double toe_rad = 0.0;
    double caster_rad = 0.0;
    double kingpin_inclination_rad = 0.0;
    double scrub_radius_m = 0.0;
    double mechanical_trail_m = 0.0;
    double motion_ratio = 1.0;
    double bump_steer_rad_m = 0.0;
    double camber_gain_rad_m = 0.0;
    double instantaneous_center_height_m = 0.0;
    double roll_center_height_m = 0.0;
    double anti_dive_fraction = 0.0;
    double anti_squat_fraction = 0.0;
    bool finite = true;
};
class GeneralizedSuspensionKandC {
public:
    explicit GeneralizedSuspensionKandC(SuspensionCornerDefinition definition);
    [[nodiscard]] SuspensionKandCResult solve(const SuspensionInput& input) const;
    [[nodiscard]] std::vector<SuspensionKandCResult> sweep(double travel_min_m, double travel_max_m, std::size_t points,
                                                           double vertical_load_n = 0.0) const;
private:
    SuspensionCornerDefinition definition_;
};

// ---------------------------------------------------------------------------
// 5. Conservative track-state physics + Bayesian assimilation V2.
// ---------------------------------------------------------------------------

struct TrackPhysicsCell {
    double elevation_m = 0.0;
    double cross_slope = 0.0;
    double drainage_rate_m_s = 2.0e-5;
    double water_m = 0.0;
    double rubber_kg_m2 = 0.0;
    double marbles_kg_m2 = 0.0;
    double debris_kg_m2 = 0.0;
    double temperature_k = 298.15;
    double grip = 1.0;
    double grip_variance = 0.04;
};
struct TrackPhysicsWeather { double rain_m_s = 0.0; double ambient_temperature_k = 293.15; double solar_w_m2 = 0.0; double wind_m_s = 0.0; };
struct TrackGripObservation { std::size_t longitudinal = 0; std::size_t lateral = 0; double measured_grip = 1.0; double variance = 0.01; };
struct TrackGripForecast { double mean = 1.0; double standard_deviation = 0.0; };
class TrackStatePhysicsAssimilator {
public:
    void initialize(std::size_t longitudinal_cells, std::size_t lateral_cells, double ds_m, double dy_m,
                    std::vector<TrackPhysicsCell> cells = {});
    void advance(double dt_s, const TrackPhysicsWeather& weather);
    void apply_vehicle(std::size_t longitudinal, std::size_t lateral, double slip_energy_j, double water_displaced_m3, double debris_kg);
    void assimilate(const std::vector<TrackGripObservation>& observations);
    [[nodiscard]] TrackGripForecast forecast(std::size_t longitudinal, std::size_t lateral, double horizon_s,
                                             const TrackPhysicsWeather& weather) const;
    [[nodiscard]] const std::vector<TrackPhysicsCell>& cells() const noexcept { return cells_; }
private:
    std::size_t nx_ = 0, ny_ = 0;
    double ds_m_ = 1.0, dy_m_ = 1.0;
    std::vector<TrackPhysicsCell> cells_;
};

// ---------------------------------------------------------------------------
// 6. Brake tribology / thermoelastic digital twin.
// ---------------------------------------------------------------------------

struct BrakeConfiguration {
    double rotor_mass_kg = 6.0;
    double rotor_heat_capacity_j_kg_k = 510.0;
    double pad_mass_kg = 0.7;
    double pad_heat_capacity_j_kg_k = 1000.0;
    double effective_radius_m = 0.16;
    double nominal_mu = 0.46;
    double optimal_temperature_k = 650.0;
    double fade_temperature_k = 950.0;
    double rotor_wear_coefficient = 2.0e-12;
    double pad_wear_coefficient = 1.0e-11;
    double convection_w_k = 120.0;
    double thermoelastic_gain = 1.0e-9;
    double fluid_boiling_temperature_k = 510.0;
};
struct BrakeState { double rotor_temperature_k = 300.0; double pad_temperature_k = 300.0; double transfer_layer = 0.5; double rotor_wear_m = 0.0; double pad_wear_m = 0.0; double hot_spot_amplitude_k = 0.0; double coning_m = 0.0; double fluid_temperature_k = 320.0; };
struct BrakeInput { double clamp_force_n = 0.0; double wheel_speed_rad_s = 0.0; double vehicle_speed_m_s = 0.0; double ambient_temperature_k = 298.15; double duct_airflow_kg_s = 0.0; double dt_s = 0.001; };
struct BrakeResult { BrakeState state{}; double friction_coefficient = 0.0; double brake_torque_nm = 0.0; double heat_generation_w = 0.0; double fade_fraction = 0.0; double judder_index = 0.0; double pedal_travel_growth_m = 0.0; bool fluid_boiling = false; };
class BrakeTribologyThermoelasticTwin { public: explicit BrakeTribologyThermoelasticTwin(BrakeConfiguration configuration = {}); [[nodiscard]] BrakeResult step(const BrakeInput& input, const BrakeState& state) const; private: BrakeConfiguration configuration_; };

// ---------------------------------------------------------------------------
// 7. Driveline torsional dynamics / NVH platform.
// ---------------------------------------------------------------------------

struct TorsionalNode { std::string id; double inertia_kg_m2 = 0.1; double angle_rad = 0.0; double speed_rad_s = 0.0; };
struct TorsionalConnection { std::size_t a = 0; std::size_t b = 0; double stiffness_nm_rad = 1000.0; double damping_nm_s_rad = 3.0; double backlash_rad = 0.0; double gear_ratio = 1.0; double mesh_stiffness_modulation = 0.0; std::size_t teeth = 0; };
struct DrivelineState { std::vector<double> angle_rad; std::vector<double> speed_rad_s; };
struct DrivelineInput { std::vector<double> applied_torque_nm; double dt_s = 0.0001; };
struct DrivelineResult { DrivelineState state{}; std::vector<double> connection_torque_nm; double mesh_excitation_nm = 0.0; double dissipated_power_w = 0.0; };
struct SpectrumPoint { double frequency_hz = 0.0; double amplitude = 0.0; };
class DrivelineTorsionalNvhPlatform {
public:
    DrivelineTorsionalNvhPlatform(std::vector<TorsionalNode> nodes, std::vector<TorsionalConnection> connections);
    [[nodiscard]] DrivelineState initial_state() const;
    [[nodiscard]] DrivelineResult step(const DrivelineInput& input, const DrivelineState& state) const;
    [[nodiscard]] static std::vector<SpectrumPoint> spectrum(const std::vector<double>& samples, double sample_rate_hz, std::size_t bins = 256);
private: std::vector<TorsionalNode> nodes_; std::vector<TorsionalConnection> connections_; };

// ---------------------------------------------------------------------------
// 8. DIL qualification, gaze, motion cueing, latency and sickness metrics.
// ---------------------------------------------------------------------------

struct GazeSample { double time_s = 0.0; double yaw_rad = 0.0; double pitch_rad = 0.0; double pupil_mm = 3.0; bool blink = false; };
struct DilLatencySample { double command_time_s = 0.0; double response_time_s = 0.0; };
struct MotionCueInput { double longitudinal_accel_m_s2 = 0.0; double lateral_accel_m_s2 = 0.0; double yaw_rate_rad_s = 0.0; double dt_s = 0.01; };
struct MotionCueState { double x_m = 0.0; double y_m = 0.0; double x_velocity_m_s = 0.0; double y_velocity_m_s = 0.0; double roll_rad = 0.0; double pitch_rad = 0.0; };
struct MotionCueResult { MotionCueState state{}; double residual_accel_m_s2 = 0.0; bool workspace_limited = false; };
struct DilQualificationReport { double mean_fixation_s = 0.0; double saccades_per_min = 0.0; double blinks_per_min = 0.0; double mean_pupil_mm = 0.0; double mean_latency_ms = 0.0; double p95_latency_ms = 0.0; double jitter_ms = 0.0; double sickness_exposure = 0.0; bool qualified = false; };
class DriverInLoopQualificationPlatform {
public:
    [[nodiscard]] static MotionCueResult cue(const MotionCueInput& input, const MotionCueState& state, double workspace_m = 0.45, double tilt_limit_rad = 0.18);
    [[nodiscard]] static DilQualificationReport qualify(const std::vector<GazeSample>& gaze, const std::vector<DilLatencySample>& latency,
                                                        const std::vector<double>& motion_residuals);
};

// ---------------------------------------------------------------------------
// 9. WEC / IMSA timing, scoring, neutralization and race-control authority.
// ---------------------------------------------------------------------------

enum class EndurancePenaltyKind { Time, DriveThrough, StopGo, LapDeletion };
struct TimingCrossing { std::string car_id; std::string class_id; double time_s = 0.0; std::size_t line_id = 0; bool pit_lane = false; };
struct EndurancePenalty { std::string car_id; EndurancePenaltyKind kind = EndurancePenaltyKind::Time; double value_s = 0.0; bool served = false; };
struct TimingClassification { std::string car_id; std::string class_id; std::size_t laps = 0; double elapsed_s = 0.0; double adjusted_s = 0.0; std::size_t overall_position = 0; std::size_t class_position = 0; bool classified = true; };
class EnduranceTimingScoringRaceControl {
public:
    void set_lap_line(std::size_t line_id) noexcept { lap_line_id_ = line_id; }
    void record_crossing(const TimingCrossing& crossing);
    void add_penalty(EndurancePenalty penalty);
    void set_neutralization(motorsport::NeutralizationMode mode, double start_s, double end_s = -1.0);
    [[nodiscard]] std::vector<TimingClassification> classify(double event_time_s) const;
private:
    std::size_t lap_line_id_ = 0;
    std::vector<TimingCrossing> crossings_;
    std::vector<EndurancePenalty> penalties_;
    struct Neutralization { motorsport::NeutralizationMode mode; double start_s; double end_s; };
    std::vector<Neutralization> neutralizations_;
};

// ---------------------------------------------------------------------------
// 10. Rally event operations platform.
// ---------------------------------------------------------------------------

struct RallyEntrantState { std::string id; double total_time_s = 0.0; double penalties_s = 0.0; bool retired = false; std::size_t completed_stages = 0; };
struct RallyTimeControl { std::string id; double due_time_s = 0.0; double early_penalty_s_per_s = 10.0; double late_penalty_s_per_s = 0.1; };
struct RallyArrivalResult { double deviation_s = 0.0; double penalty_s = 0.0; };
class RallyEventOperationsPlatform {
public:
    void register_entrant(std::string id);
    [[nodiscard]] RallyArrivalResult arrive_time_control(const std::string& entrant, const RallyTimeControl& control, double arrival_time_s);
    void record_stage(const std::string& entrant, double stage_time_s, bool cancelled = false, std::optional<double> assigned_time_s = std::nullopt);
    void retire(const std::string& entrant, bool restart_allowed, double restart_penalty_s = 0.0);
    [[nodiscard]] std::vector<RallyEntrantState> classification() const;
private: std::map<std::string, RallyEntrantState> entrants_; };

// ---------------------------------------------------------------------------
// 11. Formula-E charging / next-generation operations.
// ---------------------------------------------------------------------------

enum class FormulaEDriveMode { RearOnly, FrontRegen, AllWheelDrive };
struct FormulaEChargeConfig { double maximum_power_w = 600000.0; double efficiency = 0.94; double taper_start_soc = 0.78; double minimum_stationary_s = 20.0; double connector_temperature_limit_k = 353.15; double cooling_w_k = 150.0; };
struct FormulaEChargeState { double battery_energy_j = 0.0; double battery_capacity_j = 1.8e8; double battery_temperature_k = 315.0; double connector_temperature_k = 300.0; double charged_energy_j = 0.0; double stationary_s = 0.0; bool completed = false; };
struct FormulaEChargeInput { double requested_power_w = 0.0; double ambient_temperature_k = 298.15; double dt_s = 0.1; bool connected = true; };
struct FormulaEChargeResult { FormulaEChargeState state{}; double accepted_power_w = 0.0; double losses_w = 0.0; bool thermally_limited = false; bool rule_compliant = false; };
class FormulaENextGenerationOperations { public: explicit FormulaENextGenerationOperations(FormulaEChargeConfig configuration = {}); [[nodiscard]] FormulaEChargeResult step_charge(const FormulaEChargeInput& input, const FormulaEChargeState& state) const; [[nodiscard]] static double deployment_limit(FormulaEDriveMode mode, double speed_m_s, bool attack_mode); private: FormulaEChargeConfig configuration_; };

// ---------------------------------------------------------------------------
// 12. Electric-machine electromagnetic NVH / demagnetization.
// ---------------------------------------------------------------------------

struct EMachineConfig { std::size_t pole_pairs = 4; std::size_t slots = 48; double torque_constant_nm_a = 0.55; double cogging_fraction = 0.015; double radial_force_coefficient_n_a2 = 0.012; double magnet_temperature_limit_k = 423.15; double irreversible_demag_temperature_k = 473.15; double thermal_capacity_j_k = 12000.0; double thermal_conductance_w_k = 180.0; double bearing_capacitance_f = 2.0e-10; };
struct EMachineState { double magnet_temperature_k = 320.0; double demagnetization_fraction = 0.0; double insulation_damage = 0.0; };
struct EMachineInput { double phase_current_a = 0.0; double mechanical_speed_rad_s = 0.0; double dc_bus_voltage_v = 800.0; double switching_frequency_hz = 12000.0; double common_mode_voltage_v = 0.0; double ambient_temperature_k = 300.0; double dt_s = 0.001; };
struct EMachineResult { EMachineState state{}; double mean_torque_nm = 0.0; double torque_ripple_nm = 0.0; double cogging_torque_nm = 0.0; double electrical_order_hz = 0.0; double radial_force_n = 0.0; double shaft_voltage_v = 0.0; double bearing_current_a = 0.0; double acoustic_excitation = 0.0; };
class EMachineNvhReliabilityPlatform { public: explicit EMachineNvhReliabilityPlatform(EMachineConfig configuration = {}); [[nodiscard]] EMachineResult step(const EMachineInput& input, const EMachineState& state) const; private: EMachineConfig configuration_; };

// ---------------------------------------------------------------------------
// 13. Battery chemo-mechanical aging / pack compression.
// ---------------------------------------------------------------------------

struct BatteryChemoMechanicalConfig { double nominal_thickness_m = 0.008; double electrode_modulus_pa = 5.0e8; double separator_modulus_pa = 1.5e8; double swelling_per_soc = 0.035; double swelling_per_capacity_loss = 0.15; double crack_rate_coefficient = 2.0e-8; double preload_pa = 1.0e5; double tab_fatigue_limit_pa = 8.0e7; double nominal_contact_resistance_ohm = 1.0e-4; };
struct BatteryChemoMechanicalState { double swelling_strain = 0.0; double stack_pressure_pa = 0.0; double particle_crack_fraction = 0.0; double separator_compression = 0.0; double tab_damage = 0.0; double contact_resistance_ohm = 1.0e-4; double internal_short_probability = 0.0; };
struct BatteryChemoMechanicalInput { double soc = 0.5; double capacity_loss_fraction = 0.0; double temperature_k = 298.15; double current_a = 0.0; double pack_constraint_stiffness_n_m = 1.0e7; double dt_s = 1.0; };
struct BatteryChemoMechanicalResult { BatteryChemoMechanicalState state{}; double thickness_m = 0.0; double mechanical_energy_j_m2 = 0.0; double thermal_contact_scale = 1.0; double resistance_scale = 1.0; };
class BatteryChemoMechanicalAgingPlatform { public: explicit BatteryChemoMechanicalAgingPlatform(BatteryChemoMechanicalConfig configuration = {}); [[nodiscard]] BatteryChemoMechanicalResult step(const BatteryChemoMechanicalInput& input, const BatteryChemoMechanicalState& state) const; private: BatteryChemoMechanicalConfig configuration_; };

// ---------------------------------------------------------------------------
// 14. HIL vendor / EtherCAT / ASAM-XIL integration.
// ---------------------------------------------------------------------------

enum class HilVendor { Generic, DSpace, Speedgoat, OpalRt, NiVeristand, EtasLabcar, VectorVt };
struct EthercatPdoEntry { std::uint16_t index = 0; std::uint8_t subindex = 0; std::size_t bit_length = 0; std::size_t bit_offset = 0; double scale = 1.0; double offset = 0.0; std::string signal; };
struct HilProcessImage { std::vector<std::uint8_t> input_bytes; std::vector<std::uint8_t> output_bytes; std::uint64_t timestamp_ns = 0; std::uint16_t working_counter = 0; };
class EthercatProcessImage {
public:
    void configure(std::size_t input_bytes, std::size_t output_bytes, std::vector<EthercatPdoEntry> input_map, std::vector<EthercatPdoEntry> output_map);
    void write_signal(const std::string& name, double value);
    [[nodiscard]] double read_signal(const std::string& name) const;
    [[nodiscard]] const HilProcessImage& image() const noexcept { return image_; }
    void update_inputs(const std::vector<std::uint8_t>& bytes, std::uint16_t working_counter, std::uint64_t timestamp_ns);
private: HilProcessImage image_; std::vector<EthercatPdoEntry> inputs_, outputs_; };
struct HilVendorProfile { HilVendor vendor = HilVendor::Generic; double cycle_time_s = 0.001; bool hardware_timestamping = false; std::map<std::string,std::string> signal_aliases; };
class HilVendorIntegration {
public:
    explicit HilVendorIntegration(HilVendorProfile profile = {});
    void bind(aesim::industrial::HilIoManager& manager);
    [[nodiscard]] std::vector<aesim::industrial::IoValue> exchange(const std::vector<aesim::industrial::IoValue>& outputs,
                                                                  std::chrono::nanoseconds timeout = std::chrono::milliseconds(2));
    [[nodiscard]] std::string xil_profile_name() const;
private: HilVendorProfile profile_; aesim::industrial::HilIoManager* manager_ = nullptr; };

// ---------------------------------------------------------------------------
// 15. Model discrepancy / validity-domain supervisor.
// ---------------------------------------------------------------------------

struct ValidationResidual { std::vector<double> operating_point; double measured = 0.0; double simulated = 0.0; double measurement_variance = 0.0; };
struct ValidityAssessment { double corrected_prediction = 0.0; double discrepancy_mean = 0.0; double discrepancy_standard_deviation = 0.0; double extrapolation_distance = 0.0; double validity_confidence = 0.0; bool extrapolated = false; };
class ModelDiscrepancyValiditySupervisor {
public:
    void fit(std::vector<ValidationResidual> residuals, std::vector<std::pair<double,double>> validity_bounds, double kernel_length = 0.25);
    [[nodiscard]] ValidityAssessment assess(const std::vector<double>& operating_point, double simulated_prediction) const;
private: std::vector<ValidationResidual> residuals_; std::vector<std::pair<double,double>> bounds_; double kernel_length_ = 0.25; };

// ---------------------------------------------------------------------------
// 16. Advanced global sensitivity suite.
// ---------------------------------------------------------------------------

using ScalarModel = std::function<double(const std::vector<double>&)>;
struct MorrisEffect { std::size_t parameter = 0; double mu = 0.0; double mu_star = 0.0; double sigma = 0.0; };
struct ShapleyEffect { std::size_t parameter = 0; double effect = 0.0; };
struct ActiveSubspaceMode { double eigenvalue = 0.0; std::vector<double> direction; };
struct GlobalSensitivityReport { std::vector<MorrisEffect> morris; std::vector<ShapleyEffect> shapley; std::vector<ActiveSubspaceMode> active_subspace; std::vector<aesim::core::SensitivityIndex> sobol; };
class AdvancedGlobalSensitivitySuite {
public:
    [[nodiscard]] static GlobalSensitivityReport analyze(const std::vector<std::pair<double,double>>& bounds, const ScalarModel& model,
                                                         std::size_t samples = 512, std::uint64_t seed = 12345);
};

// ---------------------------------------------------------------------------
// 17. CAE convergence / correlation qualification manager.
// ---------------------------------------------------------------------------

struct CaeRunSample { double characteristic_step = 0.0; double quantity = 0.0; std::size_t dof = 0; double residual = 0.0; double y_plus = 0.0; };
struct CaeCorrelationPair { double measured = 0.0; double simulated = 0.0; };
struct CaeQualificationReport { aesim::core::math_assurance::ConvergenceReport convergence{}; double rmse = 0.0; double r_squared = 0.0; double bias = 0.0; double maximum_residual = 0.0; double maximum_y_plus = 0.0; bool mesh_qualified = false; bool correlation_qualified = false; };
class CaeCorrelationQualificationPlatform { public: [[nodiscard]] static CaeQualificationReport qualify(const std::vector<CaeRunSample>& runs, const std::vector<CaeCorrelationPair>& correlation, double max_gci = 0.05, double min_r2 = 0.90, double max_nrmse = 0.10); };

// ---------------------------------------------------------------------------
// 18. Rulebook/bulletin ingestion and semantic regulation diff.
// ---------------------------------------------------------------------------

struct RegulationClause { std::string id; std::string heading; std::string text; std::string normalized; std::uint64_t fingerprint = 0; };
enum class RegulationChangeKind { Added, Removed, Modified, Unchanged };
struct RegulationChange { RegulationChangeKind kind = RegulationChangeKind::Unchanged; std::string clause_id; std::string old_text; std::string new_text; double similarity = 0.0; };
class RegulatoryKnowledgeIngestionPlatform {
public:
    [[nodiscard]] static std::vector<RegulationClause> ingest_text(const std::string& text);
    [[nodiscard]] static std::vector<RegulationClause> ingest_file(const std::string& path);
    [[nodiscard]] static std::vector<RegulationChange> semantic_diff(const std::vector<RegulationClause>& old_version,
                                                                    const std::vector<RegulationClause>& new_version);
};

// ---------------------------------------------------------------------------
// 19. SINDy / constrained symbolic equation discovery.
// ---------------------------------------------------------------------------

struct TimeSeries { std::vector<double> time_s; std::vector<std::vector<double>> state; std::vector<std::string> names; };
struct DiscoveredTerm { std::string expression; double coefficient = 0.0; };
struct DiscoveredEquation { std::string derivative; std::vector<DiscoveredTerm> terms; double rmse = 0.0; };
struct EquationDiscoveryReport { std::vector<DiscoveredEquation> equations; bool stable = false; };
class PhysicsEquationDiscoveryPlatform {
public:
    [[nodiscard]] static EquationDiscoveryReport sindy(const TimeSeries& series, double sparsity_threshold = 1.0e-4, std::size_t polynomial_degree = 2);
};

// ---------------------------------------------------------------------------
// 20. CoolProp / REFPROP / Cantera thermophysical authority backends.
// ---------------------------------------------------------------------------

enum class ThermophysicalBackendKind { Native, CoolProp, Refprop, Cantera };
struct ThermophysicalState { double temperature_k = 298.15; double pressure_pa = 101325.0; double density_kg_m3 = 0.0; double enthalpy_j_kg = 0.0; double cp_j_kg_k = 0.0; double cv_j_kg_k = 0.0; double viscosity_pa_s = 0.0; double conductivity_w_m_k = 0.0; };
class ThermophysicalAuthorityBackend {
public:
    ThermophysicalAuthorityBackend();
    ~ThermophysicalAuthorityBackend();
    ThermophysicalAuthorityBackend(const ThermophysicalAuthorityBackend&) = delete;
    ThermophysicalAuthorityBackend& operator=(const ThermophysicalAuthorityBackend&) = delete;
    [[nodiscard]] bool load(ThermophysicalBackendKind kind, const std::string& library_path = {});
    void unload() noexcept;
    [[nodiscard]] ThermophysicalBackendKind kind() const noexcept;
    [[nodiscard]] bool available() const noexcept;
    [[nodiscard]] ThermophysicalState evaluate(const std::string& fluid, double temperature_k, double pressure_pa) const;
    [[nodiscard]] std::string diagnostic() const;
private: struct Impl; std::unique_ptr<Impl> impl_; };

} // namespace aesim::advanced::authority

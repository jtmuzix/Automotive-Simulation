#pragma once

#include "aesim/core/numerical_rigor.hpp"

#include <complex>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace aesim::advanced::runtime {

using StateVector = std::vector<double>;
using ParameterizedResidual = std::function<StateVector(const StateVector&, double)>;
using ParameterizedOde = std::function<StateVector(double, const StateVector&, double)>;

// -----------------------------------------------------------------------------
// 1. Nonlinear dynamics and bifurcation laboratory
// -----------------------------------------------------------------------------
enum class BifurcationKind { None, SaddleNode, Hopf, Pitchfork, PeriodDoubling, NeimarkSacker };
[[nodiscard]] const char* to_string(BifurcationKind kind) noexcept;

struct EquilibriumPoint {
    double parameter = 0.0;
    StateVector state;
    std::vector<std::complex<double>> eigenvalues;
    double residual_norm = std::numeric_limits<double>::infinity();
    bool converged = false;
    bool stable = false;
    BifurcationKind bifurcation = BifurcationKind::None;
};

struct ContinuationOptions {
    double arclength_step = 0.05;
    double minimum_arclength_step = 1e-5;
    double maximum_arclength_step = 0.25;
    double newton_tolerance = 1e-9;
    std::size_t maximum_newton_iterations = 20;
    std::size_t maximum_points = 200;
    double eigenvalue_tolerance = 1e-5;
};

struct EquilibriumBranch {
    std::vector<EquilibriumPoint> points;
    std::vector<std::size_t> bifurcation_indices;
};

struct PoincareCrossing {
    double time = 0.0;
    StateVector state;
    int direction = 0;
};

struct PoincareResult {
    std::vector<PoincareCrossing> crossings;
    bool converged = false;
};

struct LyapunovResult {
    std::vector<double> exponents;
    double integration_time = 0.0;
    std::size_t renormalizations = 0;
    bool converged = false;
};

struct FloquetResult {
    std::vector<std::complex<double>> multipliers;
    double spectral_radius = 0.0;
    bool orbit_stable = false;
};

struct LimitCycleResult {
    double parameter = 0.0;
    StateVector initial_state;
    double period = 0.0;
    double shooting_residual = std::numeric_limits<double>::infinity();
    std::size_t newton_iterations = 0;
    bool converged = false;
    FloquetResult floquet;
    BifurcationKind bifurcation = BifurcationKind::None;
};

class NonlinearDynamicsLaboratory {
public:
    [[nodiscard]] static EquilibriumPoint solve_equilibrium(
        const ParameterizedResidual& residual, const StateVector& initial_state,
        double parameter, double tolerance = 1e-10, std::size_t maximum_iterations = 30);

    // Pseudo-arclength continuation. symmetry_indicator may be supplied for a
    // symmetry-breaking branch; near-zero symmetry indicator at a real zero-
    // eigenvalue crossing is classified as a pitchfork rather than a fold.
    [[nodiscard]] static EquilibriumBranch continue_equilibria(
        const ParameterizedResidual& residual, const StateVector& initial_state,
        double initial_parameter, double parameter_direction,
        const ContinuationOptions& options = {},
        const std::function<double(const StateVector&)>& symmetry_indicator = {});

    [[nodiscard]] static PoincareResult poincare_section(
        const ParameterizedOde& ode, double parameter, const StateVector& initial_state,
        double initial_time, double final_time,
        const std::function<double(const StateVector&)>& section,
        int required_direction = 0, double maximum_step = 1e-2);

    [[nodiscard]] static LyapunovResult lyapunov_spectrum(
        const ParameterizedOde& ode, double parameter, const StateVector& initial_state,
        double initial_time, double final_time, double renormalization_interval = 0.1,
        double perturbation = 1e-7);

    [[nodiscard]] static FloquetResult floquet_multipliers(
        const ParameterizedOde& ode, double parameter, const StateVector& cycle_state,
        double period, double perturbation = 1e-7);

    [[nodiscard]] static LimitCycleResult shoot_limit_cycle(
        const ParameterizedOde& ode, double parameter, const StateVector& initial_cycle_state,
        double initial_period, double tolerance = 1e-8, std::size_t maximum_iterations = 20);

    [[nodiscard]] static std::vector<LimitCycleResult> continue_limit_cycles(
        const ParameterizedOde& ode, const LimitCycleResult& seed, double parameter_step,
        std::size_t points, double tolerance = 1e-8, std::size_t maximum_iterations = 20);
};

// -----------------------------------------------------------------------------
// 3. Adaptive hybrid integrator supervisor
// -----------------------------------------------------------------------------
enum class IntegrationMethod { DormandPrince45, RosenbrockW, Bdf2, RadauIIA };
[[nodiscard]] const char* to_string(IntegrationMethod method) noexcept;

struct IntegratorSwitch {
    double time = 0.0;
    IntegrationMethod from = IntegrationMethod::DormandPrince45;
    IntegrationMethod to = IntegrationMethod::DormandPrince45;
    double stiffness_indicator = 0.0;
    double event_density = 0.0;
};

struct HybridIntegratorOptions {
    double initial_step = 1e-3;
    double minimum_step = 1e-10;
    double maximum_step = 0.05;
    double absolute_tolerance = 1e-9;
    double relative_tolerance = 1e-7;
    std::size_t maximum_steps = 1000000;
    double rosenbrock_stiffness_threshold = 0.75;
    double bdf_stiffness_threshold = 3.0;
    double radau_stiffness_threshold = 12.0;
    double high_event_density = 8.0; // crossings per simulated second
};

struct HybridIntegrationResult {
    std::vector<double> time;
    std::vector<StateVector> states;
    std::vector<IntegrationMethod> methods;
    std::vector<IntegratorSwitch> switches;
    std::size_t accepted_steps = 0;
    std::size_t rejected_steps = 0;
    std::size_t rhs_evaluations = 0;
    std::size_t nonlinear_iterations = 0;
    std::size_t event_crossings = 0;
    double maximum_error_ratio = 0.0;
    bool converged = false;
    std::string diagnostic;
};

class AdaptiveHybridIntegratorSupervisor {
public:
    using OdeFunction = core::numerics::OdeFunction;
    using EventFunction = std::function<double(double, const StateVector&)>;

    [[nodiscard]] HybridIntegrationResult integrate(
        const OdeFunction& rhs, double initial_time, double final_time,
        const StateVector& initial_state, const HybridIntegratorOptions& options = {},
        const std::vector<EventFunction>& events = {}) const;
};

// -----------------------------------------------------------------------------
// 4. Copy-on-write simulation fork/branch engine
// -----------------------------------------------------------------------------
class CowStateStore {
public:
    explicit CowStateStore(std::size_t scalar_count = 0, std::size_t page_scalars = 256);
    [[nodiscard]] std::size_t size() const noexcept;
    [[nodiscard]] std::size_t page_size() const noexcept;
    [[nodiscard]] double read(std::size_t index) const;
    void write(std::size_t index, double value);
    void write_range(std::size_t offset, const StateVector& values);
    [[nodiscard]] StateVector materialize() const;
    [[nodiscard]] CowStateStore fork() const;
    [[nodiscard]] std::size_t shared_pages_with(const CowStateStore& other) const;
    [[nodiscard]] std::vector<std::size_t> differing_pages(const CowStateStore& other) const;
    [[nodiscard]] std::size_t private_bytes() const noexcept;
    [[nodiscard]] std::size_t logical_bytes() const noexcept;
    [[nodiscard]] std::uint64_t generation() const noexcept;
private:
    struct Page;
    std::size_t scalar_count_ = 0;
    std::size_t page_scalars_ = 256;
    std::vector<std::shared_ptr<Page>> pages_;
    std::uint64_t generation_ = 0;
    void ensure_unique(std::size_t page);
};

struct SimulationBranch {
    std::uint64_t id = 0;
    std::uint64_t parent_id = 0;
    double fork_time = 0.0;
    CowStateStore state;
};

class SimulationForkEngine {
public:
    explicit SimulationForkEngine(CowStateStore root);
    [[nodiscard]] const SimulationBranch& root() const noexcept;
    [[nodiscard]] SimulationBranch fork(std::uint64_t branch_id, double time);
    void commit(SimulationBranch branch);
    [[nodiscard]] const SimulationBranch& branch(std::uint64_t id) const;
    [[nodiscard]] std::vector<std::uint64_t> branch_ids() const;
private:
    std::map<std::uint64_t, SimulationBranch> branches_;
    std::uint64_t next_branch_id_ = 1;
};

// -----------------------------------------------------------------------------
// 5. SIMD/batched ensemble execution engine
// -----------------------------------------------------------------------------
class BatchedStateSoA {
public:
    BatchedStateSoA() = default;
    BatchedStateSoA(std::size_t members, std::size_t dimensions, double initial = 0.0);
    [[nodiscard]] std::size_t members() const noexcept { return members_; }
    [[nodiscard]] std::size_t dimensions() const noexcept { return dimensions_; }
    [[nodiscard]] double& operator()(std::size_t member, std::size_t dimension);
    [[nodiscard]] double operator()(std::size_t member, std::size_t dimension) const;
    [[nodiscard]] double* dimension_data(std::size_t dimension);
    [[nodiscard]] const double* dimension_data(std::size_t dimension) const;
    [[nodiscard]] const std::vector<double>& raw() const noexcept { return data_; }
    [[nodiscard]] std::vector<double>& raw() noexcept { return data_; }
private:
    std::size_t members_ = 0;
    std::size_t dimensions_ = 0;
    std::vector<double> data_;
};

struct BatchEventHit { std::size_t member = 0; std::size_t event = 0; double time = 0.0; };
struct BatchExecutionResult {
    BatchedStateSoA state;
    std::vector<BatchEventHit> events;
    std::size_t steps = 0;
    std::size_t rhs_evaluations = 0;
    double elapsed_ms = 0.0;
    std::string cpu_backend;
};

class BatchedEnsembleExecutor {
public:
    using BatchRhs = std::function<void(double, const BatchedStateSoA&, BatchedStateSoA&)>;
    using BatchEvent = std::function<double(double, std::size_t, const BatchedStateSoA&)>;

    [[nodiscard]] BatchExecutionResult integrate_rk4(
        const BatchRhs& rhs, double initial_time, double final_time, double step,
        const BatchedStateSoA& initial, const std::vector<BatchEvent>& events = {}) const;

    [[nodiscard]] static std::vector<double> deterministic_sum_by_dimension(const BatchedStateSoA& state);

    // Uses the existing heterogeneous-compute subsystem (CUDA/HIP/SYCL/Vulkan/
    // CPU as available) for a separable affine batch kernel y = scale*x+bias.
    [[nodiscard]] static BatchedStateSoA affine_accelerated(
        const BatchedStateSoA& input, double scale, double bias,
        const std::string& preferred_backend = "");
};

// -----------------------------------------------------------------------------
// 6. Coverage-guided physical scenario fuzzer
// -----------------------------------------------------------------------------
struct ScenarioParameter { std::string name; double minimum = 0.0; double maximum = 1.0; };
using PhysicalScenario = std::map<std::string, double>;
struct PhysicalExecution {
    std::set<std::uint64_t> state_coverage;
    std::set<std::string> transitions;
    std::set<std::string> events;
    StateVector behavior;
    bool failed = false;
    double severity = 0.0;
    std::string failure_signature;
};
struct PhysicalFuzzOptions {
    std::uint64_t seed = 1;
    std::size_t executions = 1000;
    std::size_t maximum_corpus = 512;
    double mutation_sigma_fraction = 0.10;
    double novelty_threshold = 0.05;
    std::size_t minimization_passes = 8;
};
struct PhysicalFinding { PhysicalScenario scenario; PhysicalExecution execution; PhysicalScenario minimized; };
struct PhysicalFuzzResult {
    std::size_t executions = 0;
    std::size_t unique_state_coverage = 0;
    std::size_t unique_transitions = 0;
    std::size_t unique_events = 0;
    std::size_t corpus_size = 0;
    std::vector<PhysicalFinding> findings;
};
class PhysicalScenarioFuzzer {
public:
    using Runner = std::function<PhysicalExecution(const PhysicalScenario&)>;
    [[nodiscard]] PhysicalFuzzResult run(const std::vector<ScenarioParameter>& parameters,
                                         const std::vector<PhysicalScenario>& seeds,
                                         const Runner& runner,
                                         const PhysicalFuzzOptions& options = {}) const;
};

// -----------------------------------------------------------------------------
// 7. Revolve-style adjoint checkpoint scheduler
// -----------------------------------------------------------------------------
enum class CheckpointActionKind { Advance, Store, Restore, Reverse, Release };
inline constexpr std::size_t kInitialCheckpointSlot = std::numeric_limits<std::size_t>::max();
struct CheckpointAction {
    CheckpointActionKind kind;
    std::size_t from_step = 0;
    std::size_t to_step = 0;
    // Store/Restore/Release address a concrete memory slot. The sentinel
    // kInitialCheckpointSlot denotes the externally supplied initial state.
    std::size_t checkpoint_slot = kInitialCheckpointSlot;
};
struct CheckpointPlan {
    std::size_t forward_steps = 0;
    std::size_t checkpoint_slots = 0;
    std::uint64_t total_forward_advances = 0;
    std::uint64_t recomputed_advances = 0;
    std::size_t maximum_live_checkpoints = 0;
    std::vector<CheckpointAction> actions;
};
class RevolveCheckpointScheduler {
public:
    [[nodiscard]] static CheckpointPlan plan(std::size_t forward_steps, std::size_t checkpoint_slots);
};

// -----------------------------------------------------------------------------
// 9. Hierarchical simulation-state fingerprinting
// -----------------------------------------------------------------------------
struct FingerprintDifference { std::string path; std::string left_hash; std::string right_hash; };
class StateFingerprintTree {
public:
    void set(const std::string& path, double value);
    void set_bytes(const std::string& path, const void* data, std::size_t size);
    [[nodiscard]] std::string root_hash() const;
    [[nodiscard]] std::string hash(const std::string& path) const;
    [[nodiscard]] std::vector<FingerprintDifference> differences(const StateFingerprintTree& other) const;
    [[nodiscard]] std::size_t leaf_count() const noexcept;
private:
    std::map<std::string, std::string> leaves_;
    mutable std::map<std::string, std::string> cache_;
    void invalidate_ancestors(const std::string& path);
    [[nodiscard]] std::string compute_hash(const std::string& path) const;
};
struct FingerprintFrame { double time = 0.0; StateFingerprintTree tree; };
struct FirstFingerprintDivergence { bool found = false; double time = 0.0; std::vector<FingerprintDifference> differences; };
class FingerprintTimeline {
public:
    void record(double time, const StateFingerprintTree& tree);
    [[nodiscard]] FirstFingerprintDivergence first_divergence(const FingerprintTimeline& other) const;
    [[nodiscard]] const std::vector<FingerprintFrame>& frames() const noexcept { return frames_; }
private:
    std::vector<FingerprintFrame> frames_;
};

// -----------------------------------------------------------------------------
// 10. Continuous performance contract engine
// -----------------------------------------------------------------------------
struct PerformanceMetricContract {
    std::string name;
    double maximum = std::numeric_limits<double>::infinity();
    double minimum = -std::numeric_limits<double>::infinity();
    double maximum_regression_fraction = std::numeric_limits<double>::infinity();
    double baseline = std::numeric_limits<double>::quiet_NaN();
    double quantile = 0.50;
    bool lower_is_better = true;
};
struct PerformanceMetricResult {
    std::string name;
    double observed = 0.0;
    double normalized_observed = 0.0;
    double regression_fraction = 0.0;
    bool passed = false;
    std::string diagnostic;
};
struct PerformanceContractReport { bool passed = true; std::vector<PerformanceMetricResult> metrics; };
class PerformanceContractEngine {
public:
    void set_hardware_calibration(double reference_score, double measured_score);
    void add_contract(PerformanceMetricContract contract);
    void record(const std::string& metric, double value);
    [[nodiscard]] PerformanceContractReport evaluate() const;
    [[nodiscard]] static std::vector<double> benchmark_wall_ns(const std::function<void()>& operation,
                                                               std::size_t warmup, std::size_t repetitions);
private:
    double normalization_ = 1.0;
    std::vector<PerformanceMetricContract> contracts_;
    std::map<std::string, std::vector<double>> samples_;
};

// -----------------------------------------------------------------------------
// 18. Incremental sparse dependency execution engine
// -----------------------------------------------------------------------------
struct DependencyExecutionStats {
    std::uint64_t evaluations = 0;
    std::uint64_t cache_hits = 0;
    std::uint64_t dirty_propagations = 0;
};
class IncrementalDependencyEngine {
public:
    using Compute = std::function<StateVector(const std::vector<StateVector>&)>;
    void add_source(const std::string& id, StateVector value,
                    double absolute_change_threshold = 0.0, double relative_change_threshold = 0.0);
    void add_node(const std::string& id, std::vector<std::string> dependencies, Compute compute);
    void set_source(const std::string& id, StateVector value);
    [[nodiscard]] const StateVector& evaluate(const std::string& id);
    [[nodiscard]] std::map<std::string, StateVector> evaluate(const std::vector<std::string>& ids);
    [[nodiscard]] bool dirty(const std::string& id) const;
    [[nodiscard]] const DependencyExecutionStats& stats() const noexcept { return stats_; }
    void reset_stats() noexcept { stats_ = {}; }
private:
    struct Node {
        std::vector<std::string> dependencies;
        std::vector<std::string> dependents;
        Compute compute;
        StateVector value;
        bool source = false;
        bool dirty = true;
        double abs_threshold = 0.0;
        double rel_threshold = 0.0;
    };
    std::map<std::string, Node> nodes_;
    DependencyExecutionStats stats_;
    void mark_dirty(const std::string& id);
    const StateVector& evaluate_impl(const std::string& id, std::set<std::string>& stack);
};

// -----------------------------------------------------------------------------
// 19. Conservative/optimistic parallel discrete-event Time-Warp engine
// -----------------------------------------------------------------------------
struct DiscreteEvent {
    std::uint64_t id = 0;
    std::uint64_t sender = 0;
    std::uint64_t receiver = 0;
    double timestamp = 0.0;
    std::string kind;
    StateVector payload;
};
struct OutgoingEvent {
    std::uint64_t receiver = 0;
    double timestamp = 0.0;
    std::string kind;
    StateVector payload;
};
enum class PdesMode { Conservative, OptimisticTimeWarp };
struct PdesOptions {
    PdesMode mode = PdesMode::Conservative;
    double lookahead = 0.0;
    double optimism_window = 1.0;
    std::size_t worker_threads = 0;
    std::size_t maximum_events = 1000000;
    std::size_t gvt_interval_events = 128;
};
struct PdesStats {
    std::uint64_t processed_events = 0;
    std::uint64_t rollbacks = 0;
    std::uint64_t anti_messages = 0;
    std::uint64_t fossilized_checkpoints = 0;
    std::uint64_t parallel_batches = 0;
    std::uint64_t parallel_events = 0;
    double global_virtual_time = 0.0;
};
class TimeWarpEngine {
public:
    using Handler = std::function<std::vector<OutgoingEvent>(const DiscreteEvent&, StateVector&)>;
    void add_logical_process(std::uint64_t id, StateVector initial_state, Handler handler);
    std::uint64_t schedule(DiscreteEvent event);
    [[nodiscard]] PdesStats run(double until_time, const PdesOptions& options = {});
    [[nodiscard]] const StateVector& state(std::uint64_t logical_process) const;
    [[nodiscard]] double local_virtual_time(std::uint64_t logical_process) const;
private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
    void ensure_impl();
};


// -----------------------------------------------------------------------------
// 20. V40.4 unified simulation optimization runtime
// -----------------------------------------------------------------------------
// This layer composes the existing hybrid integrator, COW branching engine,
// SoA ensemble executor, incremental dependency engine, heterogeneous compute
// backends, hardware-aware placement authority, and performance contracts.  It
// deliberately does not introduce competing solver/checkpoint/scheduler state.

enum class RuntimeResource { Auto, Cpu, Gpu, Mpi };
[[nodiscard]] const char* to_string(RuntimeResource resource) noexcept;

struct MutableStateSlice {
    double* data = nullptr;
    std::size_t size = 0;
    [[nodiscard]] double& operator[](std::size_t index) const;
    [[nodiscard]] bool empty() const noexcept { return size == 0; }
};
struct ConstStateSlice {
    const double* data = nullptr;
    std::size_t size = 0;
    [[nodiscard]] double operator[](std::size_t index) const;
    [[nodiscard]] bool empty() const noexcept { return size == 0; }
};

class AlignedMemoryArena {
public:
    explicit AlignedMemoryArena(std::size_t capacity_bytes = 64u * 1024u * 1024u,
                                std::size_t alignment = 64u);
    ~AlignedMemoryArena();
    AlignedMemoryArena(const AlignedMemoryArena&) = delete;
    AlignedMemoryArena& operator=(const AlignedMemoryArena&) = delete;
    AlignedMemoryArena(AlignedMemoryArena&&) noexcept;
    AlignedMemoryArena& operator=(AlignedMemoryArena&&) noexcept;
    [[nodiscard]] MutableStateSlice allocate_doubles(std::size_t count);
    void reset() noexcept;
    [[nodiscard]] std::size_t capacity_bytes() const noexcept;
    [[nodiscard]] std::size_t used_bytes() const noexcept;
    [[nodiscard]] std::size_t alignment() const noexcept;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

struct FidelityLevel {
    std::string name;
    double estimated_error_fraction = 0.0;
    double relative_cost = 1.0;
    double integration_step_scale = 1.0;
};
struct FidelityPolicy {
    double maximum_error_fraction = 1.0e-3;
    double target_realtime_factor = 1.0;
    double hysteresis_fraction = 0.10;
    bool prefer_accuracy = false;
};
struct FidelityDecision {
    std::string level;
    double estimated_error_fraction = 0.0;
    double relative_cost = 1.0;
    double integration_step_scale = 1.0;
    std::string reason;
};
struct FidelityControllerRuntimeState {
    std::size_t current_level_index = 0;
    double achieved_realtime_factor = 0.0;
    double measured_error_fraction = 0.0;
    bool observed = false;
};
using FidelityControllerSnapshot = std::map<std::string, FidelityControllerRuntimeState>;
class DynamicFidelityController {
public:
    void set_policy(FidelityPolicy policy);
    void register_domain(const std::string& domain, std::vector<FidelityLevel> levels);
    void observe(const std::string& domain, double achieved_realtime_factor,
                 double measured_error_fraction);
    void reset_domain(const std::string& domain);
    [[nodiscard]] FidelityControllerSnapshot snapshot() const;
    void restore(const FidelityControllerSnapshot& snapshot);
    [[nodiscard]] FidelityDecision decide(const std::string& domain) const;
    [[nodiscard]] std::string report() const;
private:
    struct DomainState;
    FidelityPolicy policy_{};
    std::map<std::string, std::shared_ptr<DomainState>> domains_;
};

struct SolverTuningPolicy {
    double minimum_absolute_tolerance = 1.0e-12;
    double maximum_absolute_tolerance = 1.0e-6;
    double minimum_relative_tolerance = 1.0e-10;
    double maximum_relative_tolerance = 1.0e-4;
    double target_error_ratio = 0.45;
    double maximum_reject_fraction = 0.10;
};
struct SolverObservation {
    std::size_t accepted_steps = 0;
    std::size_t rejected_steps = 0;
    double maximum_error_ratio = 0.0;
    double stiffness_indicator = 0.0;
    double wall_time_ms = 0.0;
};
struct SolverTuningDecision {
    IntegrationMethod method = IntegrationMethod::DormandPrince45;
    double absolute_tolerance = 1.0e-9;
    double relative_tolerance = 1.0e-7;
    double maximum_step_scale = 1.0;
    std::string reason;
};
struct SolverTunerRuntimeState {
    double absolute_tolerance = 1.0e-9;
    double relative_tolerance = 1.0e-7;
    double ema_error = 0.0;
    double ema_reject = 0.0;
    double ema_stiffness = 0.0;
    std::size_t observations = 0;
};
using SolverTunerSnapshot = std::map<std::string, SolverTunerRuntimeState>;
class AutomaticSolverToleranceTuner {
public:
    void set_policy(SolverTuningPolicy policy);
    void register_domain(const std::string& domain, double initial_absolute_tolerance,
                         double initial_relative_tolerance);
    void observe(const std::string& domain, const SolverObservation& observation);
    void reset_domain(const std::string& domain, double absolute_tolerance,
                      double relative_tolerance);
    [[nodiscard]] SolverTunerSnapshot snapshot() const;
    void restore(const SolverTunerSnapshot& snapshot);
    [[nodiscard]] SolverTuningDecision decision(const std::string& domain) const;
    [[nodiscard]] HybridIntegratorOptions options(const std::string& domain,
                                                   const HybridIntegratorOptions& base) const;
    [[nodiscard]] std::string report() const;
private:
    struct DomainState;
    SolverTuningPolicy policy_{};
    std::map<std::string, std::shared_ptr<DomainState>> domains_;
};

struct RuntimePlacement {
    RuntimeResource resource = RuntimeResource::Cpu;
    int numa_node = -1;
    std::vector<int> cpus;
    std::optional<std::size_t> gpu_index;
    int mpi_rank = 0;
    int mpi_size = 1;
    std::string reason;
};
struct RuntimeTaskContext { RuntimePlacement placement; };
struct RuntimeTask {
    std::string id;
    std::vector<std::string> dependencies;
    RuntimeResource preferred_resource = RuntimeResource::Auto;
    std::size_t cpu_threads = 1;
    std::uint64_t memory_bytes = 0;
    bool require_accelerator = false;
    std::function<void(const RuntimeTaskContext&)> execute;
};
struct RuntimeTaskRecord {
    std::string id;
    RuntimePlacement placement;
    double wall_time_ms = 0.0;
    bool succeeded = false;
    std::string error;
};
struct RuntimeScheduleReport {
    bool succeeded = false;
    double wall_time_ms = 0.0;
    std::vector<RuntimeTaskRecord> tasks;
    std::string diagnostic;
};
class GlobalHeterogeneousTaskScheduler {
public:
    GlobalHeterogeneousTaskScheduler();
    [[nodiscard]] RuntimeScheduleReport execute(const std::vector<RuntimeTask>& tasks,
                                                bool deterministic_order = false) const;
    [[nodiscard]] std::string hardware_report() const;
private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
};

struct OptimizationProfileSample {
    std::string name;
    std::string category;
    RuntimeResource resource = RuntimeResource::Cpu;
    double wall_time_ms = 0.0;
    std::uint64_t work_items = 0;
    std::uint64_t bytes_touched = 0;
};
struct OptimizationProfileAggregate {
    std::string name;
    std::string category;
    double total_wall_time_ms = 0.0;
    double share_fraction = 0.0;
    std::uint64_t samples = 0;
    std::uint64_t work_items = 0;
    std::uint64_t bytes_touched = 0;
};
class IntegratedPerformanceProfiler {
public:
    void record(OptimizationProfileSample sample);
    void clear();
    [[nodiscard]] double total_wall_time_ms() const noexcept;
    [[nodiscard]] std::vector<OptimizationProfileAggregate> aggregates() const;
    [[nodiscard]] const std::vector<OptimizationProfileSample>& samples() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    std::vector<OptimizationProfileSample> samples_;
    double total_wall_time_ms_ = 0.0;
};

struct AdvisorRecommendation {
    enum class Priority { Low, Medium, High, Critical };
    Priority priority = Priority::Low;
    std::string subsystem;
    std::string finding;
    std::string action;
    double estimated_speedup_lower = 1.0;
    double estimated_speedup_upper = 1.0;
};
struct OptimizationAdvisorInput {
    std::vector<OptimizationProfileAggregate> profile;
    DependencyExecutionStats dependency_stats;
    std::size_t accepted_steps = 0;
    std::size_t rejected_steps = 0;
    std::size_t fidelity_transitions = 0;
    std::size_t ensemble_members = 1;
    double checkpoint_private_fraction = 1.0;
    double achieved_realtime_factor = 0.0;
    double target_realtime_factor = 0.0;
};
class OptimizationAdvisor {
public:
    [[nodiscard]] std::vector<AdvisorRecommendation> analyze(const OptimizationAdvisorInput& input) const;
    [[nodiscard]] std::string report(const OptimizationAdvisorInput& input) const;
};

using CoupledStateView = std::map<std::string, ConstStateSlice>;
struct DomainStepContext {
    FidelityDecision fidelity;
    SolverTuningDecision solver;
    RuntimeTaskContext task;
};
struct MultiRateDomainConfig {
    std::string id;
    StateVector initial_state;
    double synchronization_period_s = 1.0e-3;
    double minimum_internal_step_s = 1.0e-8;
    double maximum_internal_step_s = 1.0e-3;
    double absolute_tolerance = 1.0e-9;
    double relative_tolerance = 1.0e-7;
    RuntimeResource preferred_resource = RuntimeResource::Auto;
    std::size_t cpu_threads = 1;
    std::uint64_t memory_bytes = 0;
    bool require_accelerator = false;
    std::vector<FidelityLevel> fidelity_levels;
    std::function<StateVector(double, const StateVector&, const CoupledStateView&,
                              const DomainStepContext&)> rhs;
    std::function<double(const StateVector&)> error_estimator;
};
struct MultiRateDomainStats {
    std::string id;
    std::uint64_t synchronization_steps = 0;
    std::uint64_t accepted_steps = 0;
    std::uint64_t rejected_steps = 0;
    std::uint64_t rhs_evaluations = 0;
    std::uint64_t solver_switches = 0;
    std::uint64_t fidelity_transitions = 0;
    double wall_time_ms = 0.0;
    double simulated_time_s = 0.0;
    double achieved_realtime_factor = 0.0;
    std::string active_fidelity;
    IntegrationMethod active_solver = IntegrationMethod::DormandPrince45;
};
struct SimulationOptimizationConfig {
    std::size_t arena_capacity_bytes = 64u * 1024u * 1024u;
    std::size_t arena_alignment = 64u;
    bool deterministic_task_order = false;
    double target_realtime_factor = 1.0;
    double maximum_fidelity_error_fraction = 1.0e-3;
};
struct OptimizationRunReport {
    bool converged = false;
    double initial_time_s = 0.0;
    double final_time_s = 0.0;
    double wall_time_ms = 0.0;
    double achieved_realtime_factor = 0.0;
    std::vector<MultiRateDomainStats> domains;
    RuntimeScheduleReport last_schedule;
    std::vector<AdvisorRecommendation> recommendations;
    std::string diagnostic;
};
struct RuntimeCheckpointInfo {
    std::uint64_t id = 0;
    std::uint64_t parent_id = 0;
    std::string label;
    double time_s = 0.0;
    std::size_t shared_pages_with_parent = 0;
    std::size_t private_bytes = 0;
    std::size_t logical_bytes = 0;
};

class SimulationOptimizationRuntime {
public:
    explicit SimulationOptimizationRuntime(SimulationOptimizationConfig config = {});
    ~SimulationOptimizationRuntime();
    SimulationOptimizationRuntime(const SimulationOptimizationRuntime&) = delete;
    SimulationOptimizationRuntime& operator=(const SimulationOptimizationRuntime&) = delete;
    SimulationOptimizationRuntime(SimulationOptimizationRuntime&&) noexcept;
    SimulationOptimizationRuntime& operator=(SimulationOptimizationRuntime&&) noexcept;

    void add_domain(MultiRateDomainConfig domain);
    [[nodiscard]] std::vector<std::string> domain_ids() const;
    [[nodiscard]] StateVector domain_state(const std::string& domain) const;
    [[nodiscard]] ConstStateSlice domain_state_view(const std::string& domain) const;
    void set_domain_state(const std::string& domain, StateVector state);

    void add_dependency_source(const std::string& id, StateVector value,
                               double absolute_change_threshold = 0.0,
                               double relative_change_threshold = 0.0);
    void add_dependency_node(const std::string& id, std::vector<std::string> dependencies,
                             IncrementalDependencyEngine::Compute compute);
    void set_dependency_source(const std::string& id, StateVector value);
    [[nodiscard]] const StateVector& evaluate_dependency(const std::string& id);
    [[nodiscard]] const DependencyExecutionStats& dependency_stats() const noexcept;

    [[nodiscard]] OptimizationRunReport run(double initial_time_s, double final_time_s);

    [[nodiscard]] RuntimeCheckpointInfo checkpoint(const std::string& label,
                                                    std::optional<std::uint64_t> parent_id = {});
    [[nodiscard]] RuntimeCheckpointInfo branch_from(std::uint64_t checkpoint_id,
                                                     const std::string& label);
    void restore(std::uint64_t checkpoint_id);
    [[nodiscard]] std::vector<RuntimeCheckpointInfo> checkpoints() const;

    [[nodiscard]] BatchExecutionResult run_ensemble(
        const BatchedEnsembleExecutor::BatchRhs& rhs, double initial_time_s,
        double final_time_s, double step_s, const BatchedStateSoA& initial,
        const std::vector<BatchedEnsembleExecutor::BatchEvent>& events = {});

    [[nodiscard]] const IntegratedPerformanceProfiler& profiler() const noexcept;
    [[nodiscard]] std::string optimization_report() const;
    [[nodiscard]] std::string hardware_report() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace aesim::advanced::runtime

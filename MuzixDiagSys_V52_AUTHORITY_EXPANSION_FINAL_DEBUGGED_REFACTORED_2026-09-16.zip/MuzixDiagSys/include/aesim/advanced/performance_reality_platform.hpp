#pragma once

#include "aesim/advanced/optimization.hpp"
#include "aesim/core/uncertainty.hpp"
#include "aesim/core/accuracy.hpp"
#include "aesim/high_fidelity/engine_research_digital_twin.hpp"
#include "aesim/high_fidelity/integrated_vehicle.hpp"
#include "aesim/high_fidelity/vehicle_depth.hpp"
#include "aesim/high_fidelity/transmission_authority.hpp"
#include "aesim/high_fidelity/ecosystem.hpp"
#include "aesim/vehicle/advanced_dynamics.hpp"
#include "aesim/vehicle/perception_realism.hpp"
#include "modules/research_systems.hpp"
#include "modules/realism_systems.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

struct MassComponent {
    std::string id;
    double mass_kg = 0.0;
    std::array<double,3> position_m{};
    std::array<double,3> inertia_kg_m2{};
};

struct VehicleMassProperties {
    double total_mass_kg = 0.0;
    std::array<double,3> cg_m{};
    std::array<double,3> inertia_kg_m2{};
};

struct DrivelineLossConfiguration {
    double mesh_efficiency = 0.975;
    double differential_efficiency = 0.975;
    double bearing_loss_nm = 4.0;
    double churning_loss_w_per_rad_s2 = 0.003;
    double nominal_oil_temperature_k = 353.15;
    double cold_viscosity_penalty_per_k = 0.0025;
    double hot_viscosity_penalty_per_k = 0.0007;
};

struct TorqueAuthorityConfiguration {
    double driveline_limit_nm = 1800.0;
    double minimum_knock_factor = 0.35;
    double minimum_thermal_factor = 0.25;
    double minimum_fuel_factor = 0.20;
    double minimum_traction_factor = 0.0;
    double maximum_positive_slew_nm_s = 8500.0;
    double maximum_negative_slew_nm_s = 18000.0;
};

struct TorqueAuthorityState {
    double requested_engine_torque_nm = 0.0;
    double engine_available_torque_nm = 0.0;
    double knock_factor = 1.0;
    double thermal_factor = 1.0;
    double fuel_factor = 1.0;
    double traction_factor = 1.0;
    double esc_factor = 1.0;
    double driveline_factor = 1.0;
    double delivered_engine_torque_nm = 0.0;
    double wheel_torque_nm = 0.0;
    double driveline_efficiency = 1.0;
    std::string limiting_authority = "engine";
};

struct PerformanceRealityConfiguration {
    high_fidelity::EngineResearchConfiguration engine;
    high_fidelity::DetailedBrakeConfiguration brakes;
    DrivelineLossConfiguration driveline_losses;
    TorqueAuthorityConfiguration torque_authority;
    std::vector<MassComponent> mass_components;
    double frontal_area_m2 = 2.20;
    double wheel_radius_m = 0.335;
    double rolling_resistance_coefficient = 0.012;
    double maximum_brake_force_n = 18500.0;
    std::vector<double> gear_ratios{3.70,2.19,1.52,1.16,0.93,0.78};
    double final_drive_ratio = 3.55;
    double shift_time_s = 0.085;
    double redline_rpm = 7200.0;
    double idle_rpm = 850.0;
    double reliability_minimum_safety_factor = 1.30;
    double reliability_maximum_failure_probability = 0.05;
    double reliability_maximum_brake_temperature_k = 1100.0;
    double reliability_maximum_tire_temperature_c = 145.0;
};

struct VariableValvetrainCommand {
    double intake_cam_phase_deg = 0.0;
    double exhaust_cam_phase_deg = 0.0;
    double intake_lift_fraction = 1.0;
    double exhaust_lift_fraction = 1.0;
    double cylinder_activation_fraction = 1.0;
};

struct PerformanceStepInput {
    double throttle = 0.0;
    double brake = 0.0;
    double steering_rad = 0.0;
    double engine_rpm = 1000.0;
    double vehicle_speed_m_s = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    double ambient_pressure_pa = 101325.0;
    double ambient_temperature_k = 298.15;
    double road_mu = 1.0;
    double road_grade_rad = 0.0;
    double road_roughness_m = 0.002;
    double road_water_depth_m = 0.0;
    double road_loose_depth_m = 0.0;
    double lambda = 1.0;
    double spark_deg_btdc = 16.0;
    double requested_fuel_mass_kg_cycle = 2.2e-5;
    double egr_fraction = 0.0;
    double wastegate_position = 0.72;
    double oil_temperature_k = 368.0;
    double coolant_temperature_k = 365.0;
    double drivetrain_oil_temperature_k = 353.15;
    double gear_ratio = 3.0;
    double yaw_error_rad_s = 0.0;
    double target_slip_ratio = 0.08;
    double measured_driven_slip_ratio = 0.0;
    std::array<double,4> wheel_speed_rad_s{};
    std::array<double,4> abs_release_fraction{};
    VariableValvetrainCommand valvetrain;

    // R1 cross-domain feedback. Defaults preserve the P1-P4 steady-aero and
    // rigid-pickup behavior, while the reality-depth platform can feed modal
    // chassis deflection and unsteady aerodynamic coefficients into the same
    // canonical integrated vehicle solve.
    std::array<std::array<double,3>,4> chassis_pickup_displacement_m{};
    bool use_external_aero = false;
    vehicle::AeroMapPoint external_aero{};
};

struct PerformanceRealityState {
    double time_s = 0.0;
    high_fidelity::EngineResearchState engine;
    high_fidelity::DetailedBrakeState brakes;
    high_fidelity::IntegratedVehicleState vehicle;
    vehicle::AeroMapPoint aero;
    VehicleMassProperties mass_properties;
    TorqueAuthorityState torque;
    double traction_control_factor = 1.0;
    double esc_torque_factor = 1.0;
    double brake_force_n = 0.0;
    double aerodynamic_drag_n = 0.0;
    double rolling_resistance_n = 0.0;
    std::uint64_t ecu_deadline_misses = 0;
};

struct TelemetrySample {
    double time_s = 0.0;
    double speed_m_s = std::numeric_limits<double>::quiet_NaN();
    double engine_rpm = std::numeric_limits<double>::quiet_NaN();
    double torque_nm = std::numeric_limits<double>::quiet_NaN();
    double throttle = std::numeric_limits<double>::quiet_NaN();
    double brake = std::numeric_limits<double>::quiet_NaN();
    double boost_kpa = std::numeric_limits<double>::quiet_NaN();
    double fuel_flow_kg_s = std::numeric_limits<double>::quiet_NaN();
    double brake_temperature_k = std::numeric_limits<double>::quiet_NaN();
    double tire_temperature_c = std::numeric_limits<double>::quiet_NaN();
};

struct TelemetryCorrelation {
    std::size_t samples = 0;
    std::map<std::string,double> rmse;
    std::map<std::string,double> bias;
    std::map<std::string,double> correlation;
    double normalized_cost = 0.0;
};

struct PerformanceEnvelopePoint {
    double speed_m_s = 0.0;
    double maximum_acceleration_m_s2 = 0.0;
    double maximum_braking_m_s2 = 0.0;
    double maximum_lateral_m_s2 = 0.0;
    double engine_limited_acceleration_m_s2 = 0.0;
    double traction_limited_acceleration_m_s2 = 0.0;
    std::size_t best_gear = 1;
};

struct AccelerationMetrics {
    double zero_to_60_mph_s = std::numeric_limits<double>::infinity();
    double zero_to_100_kph_s = std::numeric_limits<double>::infinity();
    double sixty_to_130_mph_s = std::numeric_limits<double>::infinity();
    double hundred_to_200_kph_s = std::numeric_limits<double>::infinity();
    double quarter_mile_s = std::numeric_limits<double>::infinity();
    double quarter_mile_trap_m_s = 0.0;
    double standing_kilometre_s = std::numeric_limits<double>::infinity();
    double top_speed_m_s = 0.0;
    std::vector<std::pair<double,double>> speed_trace;
};

// -----------------------------------------------------------------------------
// V47 Tire, Traction & Precision Performance Dynamics
// -----------------------------------------------------------------------------

enum class PerformanceEventType { SpeedCrossing, DistanceCrossing };

struct PerformanceEventDefinition {
    std::string id;
    PerformanceEventType type = PerformanceEventType::SpeedCrossing;
    double threshold = 0.0;
};

struct PerformanceEvent {
    std::string id;
    PerformanceEventType type = PerformanceEventType::SpeedCrossing;
    double threshold = 0.0;
    double absolute_time_s = std::numeric_limits<double>::infinity();
    double elapsed_from_stage_s = std::numeric_limits<double>::infinity();
    double distance_m = 0.0;
    double speed_m_s = 0.0;
};

// Single continuous-event authority used by every straight-line performance
// result. It interpolates within a solver interval rather than quantizing a
// crossing to the end of a timestep.
class PerformanceEventDetector {
public:
    void clear();
    void add_speed_event(std::string id, double speed_m_s);
    void add_distance_event(std::string id, double distance_m);
    void reset(double time_s = 0.0, double speed_m_s = 0.0, double distance_m = 0.0);
    std::vector<PerformanceEvent> update(double time_s, double speed_m_s, double distance_m);
    [[nodiscard]] const std::vector<PerformanceEvent>& events() const noexcept { return events_; }
    [[nodiscard]] bool has_event(const std::string& id) const;
    [[nodiscard]] const PerformanceEvent* find_event(const std::string& id) const;
    [[nodiscard]] static double speed_crossing_time(double t0_s, double v0_m_s,
                                                    double t1_s, double v1_m_s,
                                                    double target_m_s);
    [[nodiscard]] static double distance_crossing_time(double t0_s, double x0_m,
                                                       double v0_m_s, double t1_s,
                                                       double x1_m, double v1_m_s,
                                                       double target_m);
private:
    std::vector<PerformanceEventDefinition> definitions_;
    std::vector<PerformanceEvent> events_;
    double previous_time_s_ = 0.0;
    double previous_speed_m_s_ = 0.0;
    double previous_distance_m_ = 0.0;
    bool initialized_ = false;
};

struct StraightLineSurfacePoint {
    double distance_m = 0.0;
    double grip_scale = 1.0;
    double grade_rad = 0.0;
};

struct StraightLineSurfaceConfiguration {
    double baseline_mu = 1.15;
    double preparation_fraction = 0.65;
    double rubber_fraction = 0.35;
    double moisture_fraction = 0.0;
    double surface_temperature_c = 32.0;
    double cell_spacing_m = 2.0;
    std::vector<StraightLineSurfacePoint> profile;
};

enum class PerformanceCouplingMode { Explicit, ImplicitAitken };

struct DetailedAccelerationConfiguration {
    StraightLineSurfaceConfiguration surface;
    double ambient_air_density_kg_m3 = 1.225;
    double ambient_temperature_c = 25.0;
    double headwind_m_s = 0.0; // positive = headwind, negative = tailwind
    double tire_cold_pressure_pa = 220000.0;
    double dt_s = 0.002;
    double maximum_time_s = 120.0;
    double tire_rollout_m = 0.3048; // one-foot rollout reference
    double staging_depth_m = 0.0;
    double quarter_mile_trap_length_m = 20.1168; // 66 ft
    double eighth_mile_trap_length_m = 20.1168;
    double torque_scale = 1.0;
    double aerodynamic_drag_scale = 1.0;
    double rolling_resistance_scale = 1.0;
    double shift_time_scale = 1.0;
    double vehicle_mass_scale = 1.0;
    double launch_rpm = 3200.0;
    double clutch_engagement_time_s = 0.55;
    bool traction_control_enabled = true;
    double traction_control_kp = 2.2;
    double traction_control_ki = 4.5;
    double minimum_traction_factor = 0.15;
    bool front_wheel_drive = false;
    bool rear_wheel_drive = true;
    high_fidelity::TransmissionArchitecture transmission_architecture =
        high_fidelity::TransmissionArchitecture::TorqueConverterAutomatic;
    double engine_rotational_inertia_kg_m2 = 0.22;
    double gearbox_input_inertia_kg_m2 = 0.065;
    double propshaft_inertia_kg_m2 = 0.045;
    double differential_inertia_kg_m2 = 0.085;

    // V48-A: strongly coupled tire/suspension/driveline execution. Explicit
    // preserves the V47 single-pass behavior; ImplicitAitken rolls all three
    // established authorities back to the beginning of the macro-step until
    // the interface loads converge.
    PerformanceCouplingMode coupling_mode = PerformanceCouplingMode::ImplicitAitken;
    unsigned coupling_maximum_iterations = 10;
    double coupling_normal_load_tolerance_n = 2.0;
    double coupling_wheel_speed_tolerance_rad_s = 0.05;
    double coupling_initial_relaxation = 0.55;
    double differential_lock_command = 0.0;
    double awd_front_torque_fraction = 0.50;

    // V48-B: actual road microgeometry. If opencrg_path is non-empty the
    // existing RoadSurfaceField OpenCRG authority is used. Otherwise a
    // deterministic procedural field is generated when roughness > 0.
    std::string opencrg_path;
    double road_roughness_rms_m = 0.0;
    std::uint64_t road_seed = 48;
    double road_width_m = 8.0;
    std::size_t road_contact_samples = 9;

    // V48-A research fidelity: deterministic firing-order torque ripple is
    // superimposed on the established mean torque surface without replacing
    // the engine authority.
    bool transient_engine_torque = false;
    double engine_torque_ripple_fraction = 0.035;
    unsigned engine_firing_events_per_revolution = 2;
};

struct DetailedAccelerationTraceSample {
    double time_s = 0.0;
    double elapsed_from_stage_s = 0.0;
    double distance_m = 0.0;
    double speed_m_s = 0.0;
    double acceleration_m_s2 = 0.0;
    double engine_rpm = 0.0;
    int gear = 1;
    double surface_mu = 1.0;
    double road_grade_rad = 0.0;
    double surface_temperature_c = 25.0;
    double air_relative_speed_m_s = 0.0;
    double tractive_force_n = 0.0;
    double aerodynamic_drag_n = 0.0;
    double rolling_resistance_n = 0.0;
    double grade_force_n = 0.0;
    double force_balance_residual_n = 0.0;
    double traction_control_factor = 1.0;
    double optimal_driven_slip = 0.08;
    double converter_torque_ratio = 1.0;
    double shift_torque_transfer = 1.0;
    unsigned coupling_iterations = 1;
    double coupling_residual_n = 0.0;
    double coupling_wheel_speed_residual_rad_s = 0.0;
    double stored_mechanical_energy_j = 0.0;
    double cumulative_engine_work_j = 0.0;
    double cumulative_transmission_output_work_j = 0.0;
    double cumulative_external_loss_j = 0.0;
    double conservation_energy_residual_j = 0.0;
    double conservation_momentum_residual_kg_m_s = 0.0;
    std::array<double,4> drive_torque_nm{};
    std::array<double,4> normal_load_n{};
    std::array<double,4> slip_ratio{};
    std::array<double,4> utilization{};
    std::array<double,4> tread_temperature_c{};
    std::array<double,4> inflation_pressure_pa{};
    std::array<double,4> carcass_twist_rad{};
    std::array<double,4> longitudinal_force_n{};
};

struct DetailedAccelerationResult {
    AccelerationMetrics metrics;
    double rollout_zero_to_60_mph_s = std::numeric_limits<double>::infinity();
    double sixty_foot_s = std::numeric_limits<double>::infinity();
    double three_thirty_foot_s = std::numeric_limits<double>::infinity();
    double eighth_mile_s = std::numeric_limits<double>::infinity();
    double eighth_mile_trap_m_s = 0.0;
    double thousand_foot_s = std::numeric_limits<double>::infinity();
    double quarter_mile_instantaneous_finish_speed_m_s = 0.0;
    double stage_clear_time_s = std::numeric_limits<double>::infinity();
    double peak_acceleration_m_s2 = 0.0;
    double peak_driven_slip = 0.0;
    double minimum_traction_control_factor = 1.0;
    double maximum_force_balance_residual_n = 0.0;
    unsigned maximum_coupling_iterations = 1;
    double maximum_coupling_residual_n = 0.0;
    double maximum_coupling_wheel_speed_residual_rad_s = 0.0;
    double maximum_energy_conservation_residual_j = 0.0;
    double maximum_momentum_conservation_residual_kg_m_s = 0.0;
    double cumulative_engine_work_j = 0.0;
    double cumulative_transmission_output_work_j = 0.0;
    double cumulative_aerodynamic_work_j = 0.0;
    double cumulative_rolling_work_j = 0.0;
    double cumulative_grade_work_j = 0.0;
    double cumulative_tire_dissipation_j = 0.0;
    double cumulative_driveline_dissipation_j = 0.0;
    std::vector<PerformanceEvent> events;
    std::vector<DetailedAccelerationTraceSample> trace;
};

struct AccelerationMeasurementSample {
    double time_s = 0.0;
    double speed_m_s = std::numeric_limits<double>::quiet_NaN();
    double distance_m = std::numeric_limits<double>::quiet_NaN();
    double engine_rpm = std::numeric_limits<double>::quiet_NaN();
    double longitudinal_acceleration_m_s2 = std::numeric_limits<double>::quiet_NaN();
    double speed_sigma_m_s = 0.15;
    double distance_sigma_m = 0.25;
    double engine_rpm_sigma = 50.0;
    double acceleration_sigma_m_s2 = 0.20;
};

struct AccelerationCalibrationResult {
    DetailedAccelerationConfiguration calibrated;
    double speed_rmse_m_s = std::numeric_limits<double>::infinity();
    double objective = std::numeric_limits<double>::infinity();
    std::size_t evaluations = 0;
    std::map<std::string,double> fitted_parameters;
};

struct AccelerationBayesianCalibrationResult {
    DetailedAccelerationConfiguration posterior_mean_configuration;
    std::size_t samples = 0;
    double acceptance_rate = 0.0;
    double effective_sample_size_min = 0.0;
    double rhat_max = 1.0;
    std::size_t divergent_transitions = 0;
    std::size_t chains = 1;
    double discrepancy_amplitude_m_s = 0.0;
    double discrepancy_length_scale_s = 0.0;
    std::size_t fisher_numerical_rank = 0;
    double fisher_condition_number = std::numeric_limits<double>::infinity();
    bool fisher_identifiable = false;
    std::map<std::string,std::pair<double,double>> profile_likelihood_95;
    std::map<std::string,double> posterior_mean;
    std::map<std::string,double> posterior_stddev;
    std::map<std::string,std::pair<double,double>> credible_interval_95;
    std::map<std::string,std::map<std::string,double>> posterior_correlation;
    double posterior_predictive_speed_rmse_m_s = std::numeric_limits<double>::infinity();
    double identifiability_condition_number = std::numeric_limits<double>::infinity();
    std::vector<std::string> weakly_identified_parameters;
};

struct AccelerationUncertaintyResult {
    core::UncertaintyResult latin_hypercube;
    core::UncertaintyResult quasi_monte_carlo;
    std::vector<core::SensitivityIndex> sobol_indices;
};

struct AccelerationSensitivityEntry {
    std::string parameter;
    double zero_to_60_normalized_sensitivity = 0.0;
    double quarter_mile_normalized_sensitivity = 0.0;
};

struct AccelerationSensitivityResult {
    DetailedAccelerationResult baseline;
    std::vector<AccelerationSensitivityEntry> entries;
};

struct AccelerationConvergenceResult {
    std::array<double,3> dt_s{};
    std::array<double,3> zero_to_60_s{};
    std::array<double,3> quarter_mile_s{};
    double estimated_zero_to_60_error_s = std::numeric_limits<double>::infinity();
    double estimated_quarter_mile_error_s = std::numeric_limits<double>::infinity();
    double observed_zero_to_60_order = std::numeric_limits<double>::quiet_NaN();
    double observed_quarter_mile_order = std::numeric_limits<double>::quiet_NaN();
    double tolerance_s = 0.002;
    bool converged = false;
};

struct TrackSegment {
    double length_m = 0.0;
    double radius_m = std::numeric_limits<double>::infinity();
    double grade_rad = 0.0;
    double friction = 1.0;
    double banking_rad = 0.0;
    double roughness_m = 0.002;
    double water_depth_m = 0.0;
};

enum class PerformancePropulsionArchitecture { InternalCombustion, ParallelHybrid, BatteryElectric };
enum class PerformanceDriveLayout { FrontWheelDrive, RearWheelDrive, AllWheelDrive };

struct IndependentEnergyLedger {
    double fuel_chemical_kwh = 0.0;
    double battery_electrical_kwh = 0.0;
    double engine_mechanical_kwh = 0.0;
    double motor_mechanical_kwh = 0.0;
    double transmission_output_kwh = 0.0;
    double wheel_work_kwh = 0.0;
    double aerodynamic_loss_kwh = 0.0;
    double rolling_loss_kwh = 0.0;
    double grade_potential_kwh = 0.0;
    double brake_heat_kwh = 0.0;
    double tire_dissipation_kwh = 0.0;
    double driveline_dissipation_kwh = 0.0;
    double powertrain_thermal_rejection_kwh = 0.0;
    double stored_energy_change_kwh = 0.0;
    double residual_kwh = 0.0;
    double normalized_residual = 0.0;
};

struct DynamicLapConfiguration {
    double ambient_air_density_kg_m3 = 1.225;
    double ambient_temperature_k = 298.15;
    double dt_s = 0.01;
    double initial_speed_m_s = 8.0;
    double torque_limit_scale = 1.0;
    double frontal_area_scale = 1.0;
    double brake_capacity_scale = 1.0;
    double final_drive_ratio_scale = 1.0;
    double initial_tire_temperature_c = 70.0;
    double initial_brake_temperature_k = 330.0;
    double initial_tire_wear_fraction = 0.0;
    double initial_brake_wear_fraction = 0.0;
    double initial_engine_damage_fraction = 0.0;
    double initial_fuel_kg = 60.0;
    // Optional per-corner endurance handoff. NaN means use the scalar value above.
    std::array<double,4> initial_tire_temperature_c_by_corner{{std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN()}};
    std::array<double,4> initial_tire_wear_fraction_by_corner{{std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN()}};
    std::array<double,4> initial_brake_temperature_k_by_corner{{std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN()}};
    std::array<double,4> initial_brake_wear_fraction_by_corner{{std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::quiet_NaN()}};
    double initial_transmission_damage_fraction = 0.0;
    double initial_differential_damage_fraction = 0.0;
    double initial_battery_capacity_loss_fraction = 0.0;
    double initial_inverter_damage_fraction = 0.0;
    bool closed_loop_driver = true;

    // V49-A/B: high-fidelity four-corner lap composition. The legacy V48
    // reduced dynamic-lap implementation remains available by setting this false.
    bool four_corner_dynamics = true;
    std::string driver_profile = "track";
    double driver_preview_s = 0.75;
    PerformanceDriveLayout drive_layout = PerformanceDriveLayout::RearWheelDrive;
    vehicle::DrivelineConfiguration::DifferentialType front_differential =
        vehicle::DrivelineConfiguration::DifferentialType::Open;
    vehicle::DrivelineConfiguration::DifferentialType rear_differential =
        vehicle::DrivelineConfiguration::DifferentialType::ClutchLsd;
    vehicle::DrivelineConfiguration::DifferentialType center_differential =
        vehicle::DrivelineConfiguration::DifferentialType::Open;
    double awd_front_torque_fraction = 0.50;
    double center_lock_command = 0.0;
    high_fidelity::TransmissionArchitecture transmission_architecture =
        high_fidelity::TransmissionArchitecture::TorqueConverterAutomatic;
    PerformancePropulsionArchitecture propulsion_architecture =
        PerformancePropulsionArchitecture::InternalCombustion;
    bool dynamic_aero = true;

    // V49-C adaptive co-simulation/passivity controls.
    bool adaptive_step_enabled = true;
    double minimum_step_s = 0.0005;
    double local_error_tolerance = 2.5e-3;
    unsigned maximum_step_refinements = 8;
    bool passivity_control_enabled = true;
    double initial_passivity_tank_j = 5000.0;

    // V49-B electrified propulsion. These configure the established switching
    // machine and particle-battery authorities rather than a parallel EV model.
    double electric_maximum_torque_nm = 420.0;
    double electric_maximum_power_kw = 220.0;
    double electric_dc_bus_voltage_v = 400.0;
    double battery_capacity_kwh = 60.0;
    double initial_battery_soc = 0.85;
    double hybrid_electric_torque_fraction = 0.30;
    double regenerative_braking_fraction = 0.55;
};

struct LapSimulationResult {
    double lap_time_s = 0.0;
    double distance_m = 0.0;
    double fuel_kg = 0.0;
    double energy_kwh = 0.0;
    double maximum_speed_m_s = 0.0;
    double minimum_speed_m_s = 0.0;
    double maximum_lateral_acceleration_m_s2 = 0.0;
    double maximum_brake_temperature_k = 0.0;
    double maximum_tire_temperature_c = 0.0;
    double reliability_risk = 0.0;
    // Numerical credibility is reported independently from physical reliability.
    // A large value flags conservation/coupling evidence and must not masquerade
    // as component failure probability or prematurely terminate endurance runs.
    double numerical_credibility_risk = 0.0;
    double final_tire_temperature_c = 0.0;
    double final_brake_temperature_k = 0.0;
    double tire_wear_fraction = 0.0;
    double brake_wear_fraction = 0.0;
    double engine_damage_fraction = 0.0;
    double transmission_damage_fraction = 0.0;
    double differential_damage_fraction = 0.0;
    double battery_capacity_loss_fraction = 0.0;
    double inverter_damage_fraction = 0.0;
    double final_fuel_kg = 0.0;
    double final_battery_soc = 1.0;
    double maximum_inverter_temperature_k = 0.0;
    double driver_rms_speed_error_m_s = 0.0;
    double driver_maximum_speed_error_m_s = 0.0;
    std::size_t adaptive_step_refinements = 0;
    std::size_t rejected_steps = 0;
    std::size_t passivity_interventions = 0;
    double minimum_accepted_step_s = std::numeric_limits<double>::infinity();
    std::array<double,4> final_tire_temperature_c_by_corner{};
    std::array<double,4> final_tire_wear_fraction_by_corner{};
    std::array<double,4> final_normal_load_n{};
    std::array<double,4> final_wheel_speed_rad_s{};
    IndependentEnergyLedger independent_energy;
    std::vector<double> segment_entry_speed_m_s;
    std::vector<double> segment_exit_speed_m_s;
    std::vector<double> segment_crossing_time_s;
};

struct EnduranceResult {
    std::size_t completed_laps = 0;
    double elapsed_s = 0.0;
    double fuel_kg = 0.0;
    double mean_lap_s = 0.0;
    double best_lap_s = std::numeric_limits<double>::infinity();
    double worst_lap_s = 0.0;
    double tire_wear_fraction = 0.0;
    double brake_wear_fraction = 0.0;
    double engine_damage_fraction = 0.0;
    double reliability_risk = 0.0;
    double maximum_numerical_credibility_risk = 0.0;
    double final_tire_temperature_c = 0.0;
    double final_brake_temperature_k = 0.0;
    double final_fuel_kg = 0.0;
    double final_battery_soc = 1.0;
    double transmission_damage_fraction = 0.0;
    double differential_damage_fraction = 0.0;
    double battery_capacity_loss_fraction = 0.0;
    double inverter_damage_fraction = 0.0;
    std::vector<double> lap_times_s;
    std::vector<double> tire_temperature_history_c;
    std::vector<double> brake_temperature_history_k;
    std::vector<double> fuel_history_kg;
    std::vector<double> battery_soc_history;
    std::vector<double> transmission_damage_history;
    std::vector<double> differential_damage_history;
};

struct EnergyAccounting {
    double fuel_chemical_kwh = 0.0;
    double brake_output_kwh = 0.0;
    double wheel_output_kwh = 0.0;
    double aerodynamic_loss_kwh = 0.0;
    double rolling_loss_kwh = 0.0;
    double brake_heat_kwh = 0.0;
    double driveline_loss_kwh = 0.0;
    double thermal_rejection_kwh = 0.0;
    double residual_kwh = 0.0;
};

struct PredictivePerformanceUncertaintyResult {
    core::CorrelatedUncertaintyResult correlated;
    double cross_entropy_failure_probability = 0.0;
    double cross_entropy_standard_error = 0.0;
    double subset_failure_probability = 0.0;
    double subset_standard_error = 0.0;
    std::size_t rare_event_model_evaluations = 0;
    std::vector<std::pair<std::string,double>> recommended_experiments_information_gain_nats;
};

struct MultiFidelityOptimizationEvidence {
    std::size_t low_fidelity_evaluations = 0;
    std::size_t high_fidelity_evaluations = 0;
    std::size_t surrogate_evaluations = 0;
    double lap_time_rho = 1.0;
    double fuel_rho = 1.0;
    double risk_rho = 1.0;
};

struct ReliabilityOptimizationResult {
    OptimizationResult optimization;
    std::vector<std::string> variable_names;
    std::vector<std::string> objective_names;
    MultiFidelityOptimizationEvidence multifidelity;
};

struct MonteCarloPerformanceResult {
    std::size_t samples = 0;
    std::uint64_t seed = 0;
    std::map<std::string,realism::MetricInterval> metrics;
    std::map<std::string,double> rank_correlation_sensitivity;
};

class PerformanceRealityPlatform {
public:
    PerformanceRealityPlatform();
    explicit PerformanceRealityPlatform(PerformanceRealityConfiguration configuration);

    void configure(PerformanceRealityConfiguration configuration);
    void reset(const PerformanceStepInput& initial = {});
    const PerformanceRealityState& step(const PerformanceStepInput& input, double dt_s);

    [[nodiscard]] const PerformanceRealityConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] const PerformanceRealityState& state() const noexcept { return state_; }
    [[nodiscard]] const high_fidelity::EngineResearchDigitalTwin& engine() const noexcept { return engine_; }
    [[nodiscard]] const high_fidelity::IntegratedHighFidelityVehicle& vehicle() const noexcept { return vehicle_; }
    [[nodiscard]] const high_fidelity::DetailedBrakeHydraulicSystem& brakes() const noexcept { return brakes_; }
    [[nodiscard]] const vehicle::ProductionEcuScheduler& ecu_scheduler() const noexcept { return ecu_scheduler_; }
    [[nodiscard]] const research::SensorActuatorLayer& sensor_actuator_layer() const noexcept { return sensor_actuators_; }

    [[nodiscard]] VehicleMassProperties compute_mass_properties() const;
    [[nodiscard]] double driveline_efficiency(double input_torque_nm, double shaft_speed_rad_s,
                                              double oil_temperature_k) const;

    [[nodiscard]] high_fidelity::EngineDynoCorrelationMetrics correlate_engine_dyno(
        const std::vector<high_fidelity::EngineDynoPoint>& measured,
        const std::vector<high_fidelity::EngineDynoPoint>& predicted) const;
    [[nodiscard]] high_fidelity::EngineDynoCalibrationResult calibrate_engine_dyno(
        const std::vector<high_fidelity::EngineDynoPoint>& measured) const;

    [[nodiscard]] std::vector<TelemetrySample> ingest_telemetry_csv(const std::string& path) const;
    [[nodiscard]] TelemetryCorrelation correlate_telemetry(const std::vector<TelemetrySample>& measured,
                                                           const std::vector<TelemetrySample>& predicted) const;
    [[nodiscard]] realism::VehicleCalibrationResult estimate_vehicle_parameters(
        const realism::VehicleCalibrationContext& context,
        const std::vector<realism::CalibrationObservation>& observations,
        std::size_t iterations = 180) const;
    [[nodiscard]] vehicle::BayesianCalibrationResult bayesian_calibrate_vehicle_csv(
        const std::string& path, std::size_t burn_in, std::size_t draws, std::uint64_t seed) const;
    [[nodiscard]] realism::VehicleUncertaintyResult propagate_vehicle_uncertainty(
        const realism::VehicleCalibrationContext& context,
        const realism::VehicleCalibrationParameters& nominal,
        std::size_t samples, std::uint64_t seed) const;

    [[nodiscard]] std::vector<PerformanceEnvelopePoint> generate_ggv_envelope(
        double minimum_speed_m_s, double maximum_speed_m_s, double step_m_s,
        double road_mu = 1.0, double ambient_air_density_kg_m3 = 1.225) const;
    [[nodiscard]] AccelerationMetrics simulate_acceleration(double road_mu = 1.0,
                                                           double ambient_air_density_kg_m3 = 1.225,
                                                           double dt_s = 0.01,
                                                           double maximum_time_s = 120.0) const;
    [[nodiscard]] DetailedAccelerationResult simulate_detailed_acceleration(
        const DetailedAccelerationConfiguration& configuration = {}) const;
    [[nodiscard]] std::vector<AccelerationMeasurementSample> ingest_acceleration_measurement_csv(
        const std::string& path) const;
    [[nodiscard]] AccelerationCalibrationResult calibrate_acceleration_measurement(
        const std::vector<AccelerationMeasurementSample>& measured,
        DetailedAccelerationConfiguration initial = {}, std::size_t iterations = 4) const;
    [[nodiscard]] AccelerationBayesianCalibrationResult bayesian_calibrate_acceleration_measurement(
        const std::vector<AccelerationMeasurementSample>& measured,
        DetailedAccelerationConfiguration initial = {}, std::size_t warmup = 64,
        std::size_t samples = 128, std::uint64_t seed = 48,
        std::size_t chains = 4, bool infer_model_discrepancy = true) const;
    [[nodiscard]] AccelerationUncertaintyResult acceleration_uncertainty_sobol(
        const DetailedAccelerationConfiguration& configuration, std::size_t lhs_samples = 32,
        std::size_t sobol_base_samples = 16, std::uint64_t seed = 48) const;
    [[nodiscard]] AccelerationSensitivityResult acceleration_sensitivity(
        const DetailedAccelerationConfiguration& configuration = {}, double perturbation_fraction = 0.03) const;
    [[nodiscard]] AccelerationConvergenceResult acceleration_convergence(
        DetailedAccelerationConfiguration configuration = {}, double tolerance_s = 0.002) const;
    [[nodiscard]] MonteCarloPerformanceResult monte_carlo_acceleration(
        const DetailedAccelerationConfiguration& configuration, std::size_t samples,
        std::uint64_t seed, double sigma_fraction = 0.03) const;
    [[nodiscard]] LapSimulationResult simulate_lap(const std::vector<TrackSegment>& track,
                                                   double ambient_air_density_kg_m3 = 1.225) const;
    [[nodiscard]] LapSimulationResult simulate_dynamic_lap(
        const std::vector<TrackSegment>& track,
        const DynamicLapConfiguration& configuration = {}) const;
    [[nodiscard]] LapSimulationResult simulate_four_corner_lap(
        const std::vector<TrackSegment>& track,
        const DynamicLapConfiguration& configuration = {}) const;
    [[nodiscard]] PredictivePerformanceUncertaintyResult predictive_performance_uncertainty(
        const DetailedAccelerationConfiguration& configuration, std::size_t samples = 64,
        std::uint64_t seed = 49, double quarter_mile_failure_threshold_s = 14.0) const;
    [[nodiscard]] EnduranceResult simulate_endurance(const std::vector<TrackSegment>& track,
                                                     std::size_t laps,
                                                     double ambient_air_density_kg_m3 = 1.225) const;
    [[nodiscard]] EnduranceResult simulate_endurance(const std::vector<TrackSegment>& track,
                                                     std::size_t laps,
                                                     DynamicLapConfiguration configuration) const;
    [[nodiscard]] EnergyAccounting energy_accounting(const LapSimulationResult& lap) const;
    [[nodiscard]] ReliabilityOptimizationResult optimize_reliability_constrained(
        const std::vector<TrackSegment>& track,
        std::size_t population = 32, std::size_t generations = 24,
        std::uint64_t seed = 1) const;
    [[nodiscard]] MonteCarloPerformanceResult monte_carlo_production_variation(
        std::size_t samples, std::uint64_t seed,
        double sigma_fraction = 0.03) const;

    [[nodiscard]] std::string report() const;

private:
    PerformanceRealityConfiguration configuration_;
    PerformanceRealityState state_;
    high_fidelity::EngineResearchDigitalTwin engine_;
    high_fidelity::IntegratedHighFidelityVehicle vehicle_;
    high_fidelity::DetailedBrakeHydraulicSystem brakes_;
    vehicle::AerodynamicCoefficientMap aero_map_;
    vehicle::ProductionEcuScheduler ecu_scheduler_;
    research::SensorActuatorLayer sensor_actuators_;
    double previous_delivered_torque_nm_ = 0.0;

    [[nodiscard]] TorqueAuthorityState arbitrate_torque(const PerformanceStepInput& input,
                                                        const high_fidelity::EngineResearchState& engine_state,
                                                        double dt_s) const;
    [[nodiscard]] double available_engine_torque_at_speed(double rpm, double throttle = 1.0) const;
    [[nodiscard]] std::pair<double,std::size_t> best_wheel_force(double speed_m_s,
                                                                double driveline_eff = 0.93) const;
    static void validate_configuration(const PerformanceRealityConfiguration& configuration);
};

} // namespace aesim::advanced

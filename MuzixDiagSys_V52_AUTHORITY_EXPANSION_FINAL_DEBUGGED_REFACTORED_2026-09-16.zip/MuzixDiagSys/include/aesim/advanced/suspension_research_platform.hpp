#pragma once

#include "aesim/advanced/professional_authority_platform.hpp"
#include "aesim/high_fidelity/vehicle_systems.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced::authority {

// S4 Suspension Research / Digital-Twin Platform.  This layer composes the
// canonical high-fidelity MultibodySuspensionSystem with the existing V36 K&C,
// nonlinear damper, telemetry and UQ authorities. It does not maintain a
// competing suspension state or duplicate the runtime vehicle model.

struct SevenPostExcitationSample {
    double time_s = 0.0;
    std::array<double,4> wheel_post_displacement_m{};
    double aero_heave_force_n = 0.0;
    double aero_roll_moment_nm = 0.0;
    double aero_pitch_moment_nm = 0.0;
};

struct SuspensionRigTraceSample {
    double time_s = 0.0;
    double heave_m = 0.0;
    double heave_velocity_m_s = 0.0;
    double roll_rad = 0.0;
    double pitch_rad = 0.0;
    std::array<double,4> wheel_travel_m{};
    std::array<double,4> wheel_load_n{};
    std::array<double,4> damper_velocity_m_s{};
    std::array<double,4> damper_temperature_k{};
    std::array<double,4> camber_rad{};
    std::array<double,4> toe_rad{};
};

struct SevenPostStudyResult {
    std::vector<SuspensionRigTraceSample> trace;
    double heave_rms_m = 0.0;
    double roll_rms_rad = 0.0;
    double pitch_rms_rad = 0.0;
    double tire_load_variation_rms_n = 0.0;
    double maximum_suspension_travel_m = 0.0;
    double peak_damper_temperature_k = 0.0;
    double dissipated_energy_j = 0.0;
};

struct KandCCornerStudy {
    std::vector<SuspensionKandCResult> sweep;
    double camber_gain_at_static_rad_m = 0.0;
    double bump_steer_at_static_rad_m = 0.0;
    double motion_ratio_at_static = 0.0;
    double roll_center_migration_m = 0.0;
};

struct KandCStudyResult {
    std::array<KandCCornerStudy,4> corners;
};

struct VirtualDamperDynoRequest {
    std::size_t corner = 0;
    double stroke_amplitude_m = 0.025;
    double frequency_hz = 2.0;
    double duration_s = 4.0;
    double time_step_s = 0.001;
    double ambient_temperature_k = 298.15;
};

struct VirtualDamperDynoSample {
    double time_s = 0.0;
    double displacement_m = 0.0;
    double velocity_m_s = 0.0;
    double force_n = 0.0;
    double oil_temperature_k = 0.0;
    double cavitation_fraction = 0.0;
};

struct VirtualDamperDynoResult {
    std::vector<VirtualDamperDynoSample> samples;
    double peak_bump_force_n = 0.0;
    double peak_rebound_force_n = 0.0;
    double hysteresis_energy_j = 0.0;
    double peak_temperature_k = 0.0;
    double peak_cavitation_fraction = 0.0;
};

struct SuspensionTelemetryRecord {
    double time_s = 0.0;
    high_fidelity::MultibodySuspensionInput input{};
    double observed_heave_m = 0.0;
    double observed_roll_rad = 0.0;
    double observed_pitch_rad = 0.0;
    std::array<double,4> observed_travel_m{};
    std::array<double,4> observed_wheel_load_n{};
    double sigma_heave_m = 0.002;
    double sigma_angle_rad = 0.002;
    double sigma_travel_m = 0.003;
    double sigma_load_n = 100.0;
};

struct TelemetryCorrelationMetric {
    std::string channel;
    double correlation = 0.0;
    double rmse = 0.0;
    double bias = 0.0;
};

struct TelemetryCorrelationResult {
    std::vector<TelemetryCorrelationMetric> channels;
    double aggregate_normalized_rmse = 0.0;
};

struct SuspensionCalibrationParameter {
    std::string name;
    double initial = 1.0;
    double lower = 0.5;
    double upper = 1.5;
    double finite_difference_step = 0.01;
};

struct SuspensionParameterEstimationOptions {
    std::size_t maximum_iterations = 35;
    double convergence_tolerance = 1.0e-5;
    double initial_learning_rate = 0.35;
};

struct SuspensionParameterEstimate {
    std::map<std::string,double> values;
    double initial_cost = 0.0;
    double final_cost = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
};

struct SuspensionBayesianOptions {
    std::size_t samples = 1200;
    std::size_t burn_in = 300;
    std::size_t thinning = 2;
    double proposal_fraction_of_range = 0.025;
    std::uint64_t seed = 0x5A5A1042ULL;
};

struct SuspensionPosteriorParameter {
    double mean = 0.0;
    double standard_deviation = 0.0;
    double lower_95 = 0.0;
    double upper_95 = 0.0;
};

struct SuspensionBayesianCalibrationResult {
    std::map<std::string,SuspensionPosteriorParameter> posterior;
    double acceptance_rate = 0.0;
    double best_cost = 0.0;
    std::map<std::string,double> maximum_posterior_parameters;
};

struct SuspensionUncertaintyParameter {
    std::string name;
    double mean = 1.0;
    double standard_deviation = 0.05;
    double lower = 0.5;
    double upper = 1.5;
};

struct SuspensionUncertaintyOptions {
    std::size_t samples = 400;
    std::uint64_t seed = 0x51A17EULL;
};

struct SuspensionMetricDistribution {
    double mean = 0.0;
    double standard_deviation = 0.0;
    double lower_95 = 0.0;
    double upper_95 = 0.0;
};

struct SuspensionUncertaintyResult {
    std::map<std::string,SuspensionMetricDistribution> metrics;
    std::size_t successful_samples = 0;
    std::size_t failed_samples = 0;
};

struct SuspensionSetupObjectiveWeights {
    double tire_load_variation = 1.0;
    double body_heave = 0.35;
    double body_roll = 0.30;
    double body_pitch = 0.20;
    double suspension_travel = 0.30;
    double damper_temperature = 0.05;
};

struct SuspensionSetupOptimizationOptions {
    std::size_t maximum_iterations = 24;
    double convergence_tolerance = 1.0e-4;
    SuspensionSetupObjectiveWeights weights{};
};

struct SuspensionSetupOptimizationResult {
    std::map<std::string,double> parameters;
    double initial_objective = 0.0;
    double final_objective = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
};

struct SuspensionWearDutyCycle {
    std::vector<SevenPostExcitationSample> excitation;
    std::size_t repetitions = 1;
};

struct SuspensionWearCornerResult {
    double damper_energy_j = 0.0;
    double peak_temperature_k = 0.0;
    double wear_fraction = 0.0;
    std::size_t bump_stop_events = 0;
    std::size_t rebound_stop_events = 0;
    bool failed = false;
};

struct SuspensionWearResult {
    std::array<SuspensionWearCornerResult,4> corners{};
    double maximum_wear_fraction = 0.0;
    bool any_failure = false;
};

struct SuspensionToleranceCampaign {
    std::size_t samples = 300;
    std::uint64_t seed = 0x70AE4A9ULL;
    double hardpoint_sigma_m = 0.00075;
    double spring_rate_sigma_fraction = 0.025;
    double damper_sigma_fraction = 0.04;
    double bushing_sigma_fraction = 0.06;
    double tire_vertical_rate_sigma_fraction = 0.025;
};

struct SuspensionToleranceResult {
    SuspensionMetricDistribution peak_travel_m{};
    SuspensionMetricDistribution tire_load_variation_n{};
    SuspensionMetricDistribution peak_roll_rad{};
    SuspensionMetricDistribution peak_damper_temperature_k{};
    std::size_t completed_samples = 0;
};

class SuspensionResearchDigitalTwin {
public:
    explicit SuspensionResearchDigitalTwin(high_fidelity::MultibodySuspensionConfiguration configuration = {});

    void configure(const high_fidelity::MultibodySuspensionConfiguration& configuration);
    [[nodiscard]] const high_fidelity::MultibodySuspensionConfiguration& configuration() const noexcept { return configuration_; }

    [[nodiscard]] SevenPostStudyResult run_seven_post(const std::vector<SevenPostExcitationSample>& excitation) const;
    [[nodiscard]] KandCStudyResult run_kandc(double travel_min_m, double travel_max_m, std::size_t points,
                                             double vertical_load_n = 3500.0) const;
    [[nodiscard]] VirtualDamperDynoResult run_virtual_damper_dyno(const VirtualDamperDynoRequest& request) const;
    [[nodiscard]] TelemetryCorrelationResult correlate_telemetry(const std::vector<SuspensionTelemetryRecord>& records,
                                                                 const std::map<std::string,double>& parameter_values = {}) const;
    [[nodiscard]] SuspensionParameterEstimate estimate_parameters(const std::vector<SuspensionTelemetryRecord>& records,
                                                                  const std::vector<SuspensionCalibrationParameter>& parameters,
                                                                  const SuspensionParameterEstimationOptions& options = {}) const;
    [[nodiscard]] SuspensionBayesianCalibrationResult bayesian_calibrate(const std::vector<SuspensionTelemetryRecord>& records,
                                                                         const std::vector<SuspensionCalibrationParameter>& parameters,
                                                                         const SuspensionBayesianOptions& options = {}) const;
    [[nodiscard]] SuspensionUncertaintyResult propagate_uncertainty(const std::vector<SevenPostExcitationSample>& excitation,
                                                                    const std::vector<SuspensionUncertaintyParameter>& parameters,
                                                                    const SuspensionUncertaintyOptions& options = {}) const;
    [[nodiscard]] SuspensionSetupOptimizationResult optimize_setup(const std::vector<SevenPostExcitationSample>& excitation,
                                                                   const std::vector<SuspensionCalibrationParameter>& parameters,
                                                                   const SuspensionSetupOptimizationOptions& options = {}) const;
    [[nodiscard]] SuspensionWearResult simulate_wear(const SuspensionWearDutyCycle& duty_cycle) const;
    [[nodiscard]] SuspensionToleranceResult monte_carlo_tolerances(const std::vector<SevenPostExcitationSample>& excitation,
                                                                   const SuspensionToleranceCampaign& campaign = {}) const;

private:
    high_fidelity::MultibodySuspensionConfiguration configuration_;
    [[nodiscard]] high_fidelity::MultibodySuspensionConfiguration with_parameters(const std::map<std::string,double>& values) const;
    [[nodiscard]] double telemetry_cost(const std::vector<SuspensionTelemetryRecord>& records,
                                        const std::map<std::string,double>& parameter_values) const;
};

} // namespace aesim::advanced::authority

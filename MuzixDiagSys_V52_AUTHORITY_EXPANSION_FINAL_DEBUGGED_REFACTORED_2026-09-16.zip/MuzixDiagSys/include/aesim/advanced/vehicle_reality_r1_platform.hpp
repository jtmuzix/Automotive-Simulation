#pragma once

#include "aesim/advanced/performance_reality_platform.hpp"
#include "aesim/advanced/professional_authority_platform.hpp"
#include "aesim/experience/simulation_experience.hpp"
#include "aesim/high_fidelity/lifecycle.hpp"
#include "aesim/high_fidelity/vehicle_depth.hpp"
#include "aesim/high_fidelity/vehicle_systems.hpp"
#include "aesim/vehicle/perception_realism.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

struct UnsteadyAeroConfiguration {
    double coefficient_time_constant_s = 0.035;
    double stall_onset_time_constant_s = 0.018;
    double recovery_time_constant_s = 0.12;
    double stall_front_ride_height_m = 0.045;
    double stall_rear_ride_height_m = 0.050;
    double stall_pitch_rad = 0.095;
    double stall_yaw_rad = 0.18;
    double maximum_lift_loss_fraction = 0.72;
    double maximum_drag_rise_fraction = 0.38;
};

struct UnsteadyAeroState {
    double time_s = 0.0;
    vehicle::AeroMapPoint target{};
    vehicle::AeroMapPoint effective{};
    double separation_fraction = 0.0;
    double stall_drive = 0.0;
    double aerodynamic_power_loss_w = 0.0;
    bool stalled = false;
};

class UnsteadyAerodynamicResponse {
public:
    explicit UnsteadyAerodynamicResponse(UnsteadyAeroConfiguration configuration = {});
    void configure(UnsteadyAeroConfiguration configuration);
    void reset();
    const UnsteadyAeroState& step(double speed_m_s, double yaw_rad, double pitch_rad,
                                  double front_ride_height_m, double rear_ride_height_m,
                                  double frontal_area_m2, double air_density_kg_m3,
                                  double dt_s);
    [[nodiscard]] const UnsteadyAeroState& state() const noexcept { return state_; }
    [[nodiscard]] const vehicle::AerodynamicCoefficientMap& map() const noexcept { return map_; }
private:
    UnsteadyAeroConfiguration configuration_;
    vehicle::AerodynamicCoefficientMap map_;
    UnsteadyAeroState state_;
};

struct RealityPlausibilityIssue {
    std::string category;
    std::string code;
    std::string message;
    double severity = 0.0;
    double value = 0.0;
    double limit = 0.0;
};

struct RealityAuditState {
    double maximum_severity = 0.0;
    std::uint64_t evaluations = 0;
    std::uint64_t cumulative_violations = 0;
    std::vector<RealityPlausibilityIssue> issues;
};

struct VehicleRealityR1Configuration {
    PerformanceRealityConfiguration performance;
    high_fidelity::DistributedThermalConfiguration thermal;
    high_fidelity::FlexibleBodyConfiguration chassis;
    experience::ProceduralRoadConfiguration road;
    UnsteadyAeroConfiguration aero;
    std::array<authority::BrakeConfiguration,4> brake_thermoelastic{};
    double wheelbase_m = 2.75;
    double track_width_m = 1.62;
    double frontal_area_m2 = 2.20;
    // High-frequency canonical vehicle/engine plant substep. The public R1 step
    // may be coarser; it is deterministically subcycled at this interval while
    // slower domains are dispatched by ConservativeMultiRateSolver.
    double plant_period_s = 0.0005;
    double structure_period_s = 0.001;
    double thermal_period_s = 0.02;
    double tribology_period_s = 0.005;
    double aero_period_s = 0.005;
    double contact_patch_period_s = 0.002;
    double brake_period_s = 0.002;
    double sensor_period_s = 0.01;
    double audit_period_s = 0.02;
};

struct VehicleRealityR1Input {
    PerformanceStepInput performance;
    double yaw_rad = 0.0;
    double pitch_rad = 0.0;
    double front_ride_height_m = 0.12;
    double rear_ride_height_m = 0.12;
    double vehicle_x_m = 0.0;
    double vehicle_y_m = 0.0;
    double tire_tread_depth_m = 0.007;
    double brake_duct_airflow_fraction = 0.35;
    double underhood_ventilation_fraction = 0.45;
    double oil_contamination_ppm = 0.0;
    double oil_water_fraction = 0.0;
};

struct VehicleRealityR1State {
    double time_s = 0.0;
    PerformanceRealityState performance;
    high_fidelity::DistributedThermalState thermal;
    high_fidelity::FlexibleBodyState chassis;
    high_fidelity::LubricationNetworkState lubrication;
    high_fidelity::TribologyState tribology;
    UnsteadyAeroState aero;
    std::array<experience::DistributedContactState,4> contact_patch{};
    std::array<authority::BrakeResult,4> brake_thermoelastic{};
    std::map<std::string,high_fidelity::SensorOutput> measurements;
    RealityAuditState audit;
    double contact_patch_mean_mu = 1.0;
    double brake_effectiveness = 1.0;
    double protection_derate = 1.0;
    double aggregate_energy_residual_j = 0.0;
    std::string latest_causal_trace;
};

class VehicleRealityR1Platform {
public:
    VehicleRealityR1Platform();
    explicit VehicleRealityR1Platform(VehicleRealityR1Configuration configuration);

    void configure(VehicleRealityR1Configuration configuration);
    void reset(const VehicleRealityR1Input& initial = {});
    const VehicleRealityR1State& step(const VehicleRealityR1Input& input, double dt_s);

    [[nodiscard]] const VehicleRealityR1Configuration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] const VehicleRealityR1State& state() const noexcept { return state_; }
    [[nodiscard]] const PerformanceRealityPlatform& performance() const noexcept { return performance_; }
    [[nodiscard]] const high_fidelity::ConservativeMultiRateSolver& solver() const noexcept { return solver_; }
    [[nodiscard]] const experience::CausalExplanationEngine& causal_engine() const noexcept { return causal_; }
    [[nodiscard]] std::string report() const;

private:
    VehicleRealityR1Configuration configuration_;
    VehicleRealityR1State state_;
    VehicleRealityR1Input current_input_;
    PerformanceRealityPlatform performance_;
    high_fidelity::ConservativeMultiRateSolver solver_;
    high_fidelity::DistributedVehicleThermalNetwork thermal_;
    high_fidelity::FlexibleBodyModalSystem chassis_;
    high_fidelity::LubricationHydraulicNetwork lubrication_;
    high_fidelity::UnifiedTribologyWearSystem tribology_;
    UnsteadyAerodynamicResponse aero_;
    experience::RoadSurfaceField road_;
    std::array<experience::DistributedTireContactModel,4> contact_patch_;
    std::array<authority::BrakeTribologyThermoelasticTwin,4> brake_thermoelastic_;
    std::array<authority::BrakeState,4> brake_states_{};
    high_fidelity::SensorFaultInjectionSuite measurements_;
    experience::CausalExplanationEngine causal_;
    std::map<std::string,std::uint64_t> last_event_by_category_;
    std::map<std::string,double> last_issue_severity_;
    double previous_chassis_dissipated_j_ = 0.0;

    void configure_chassis_defaults();
    void configure_lubrication_and_tribology();
    void configure_measurements();
    void configure_solver_tasks();
    void update_structural(double dt_s);
    void update_thermal(double dt_s);
    void update_tribology(double dt_s);
    void update_aero(double dt_s);
    void update_contact_patch();
    void update_brakes(double dt_s);
    void update_measurements(double dt_s);
    void update_audit_and_causality();
    [[nodiscard]] RealityAuditState evaluate_plausibility() const;
};

} // namespace aesim::advanced

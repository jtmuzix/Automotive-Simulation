#pragma once

#include "aesim/advanced/ads_cad.hpp"
#include "aesim/advanced/frontier_expansion_platform.hpp"
#include "aesim/advanced/frontier_runtime_sensing_platform.hpp"
#include "aesim/advanced/next_generation_autonomy_platform.hpp"
#include "aesim/advanced/v51_scientific_reality.hpp"
#include "aesim/industrial/signals.hpp"
#include "aesim/industrial/xcp.hpp"
#include "aesim/professional/document.hpp"
#include "aesim/research2/standards_deployment_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <deque>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <tuple>
#include <vector>

namespace aesim::advanced::v52 {

// -----------------------------------------------------------------------------
// External formal-solver federation (Z3 / cvc5 / dReal)
// -----------------------------------------------------------------------------

enum class FormalSolverBackend { Z3, Cvc5, DReal };
enum class FormalSolverStatus { Sat, DeltaSat, Unsat, Unknown, Error, Unavailable };

struct FormalSolverRequest {
    FormalSolverBackend backend = FormalSolverBackend::Z3;
    std::string smtlib2;
    double timeout_s = 30.0;
    bool request_model = true;
    bool request_unsat_core = true;
    bool require_backend = false;
};

struct FormalSolverResult {
    FormalSolverBackend backend = FormalSolverBackend::Z3;
    FormalSolverStatus status = FormalSolverStatus::Unknown;
    bool available = false;
    int exit_code = -1;
    double elapsed_s = 0.0;
    std::string executable;
    std::string version;
    std::string raw_output;
    std::map<std::string, std::string> model;
    std::vector<std::string> unsat_core;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct FormalDifferentialResult {
    std::vector<FormalSolverResult> results;
    bool status_consensus = false;
    std::string consensus;
    std::vector<std::string> disagreements;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ExternalFormalSolverFederation {
public:
    [[nodiscard]] static std::map<FormalSolverBackend, std::string> discover();
    [[nodiscard]] FormalSolverResult solve(const FormalSolverRequest& request,
                                           const std::string& working_directory = {}) const;
    [[nodiscard]] FormalDifferentialResult differential(
        const std::string& smtlib2,
        const std::vector<FormalSolverBackend>& backends,
        double timeout_s = 30.0,
        const std::string& working_directory = {}) const;
};

// -----------------------------------------------------------------------------
// Sparse/symbolic probabilistic model checking with reduced MTBDDs.
// -----------------------------------------------------------------------------

enum class SymbolicProbabilisticSemantics { Dtmc, Ctmc, Mdp };

struct SymbolicTransition {
    std::uint64_t source = 0;
    std::uint64_t target = 0;
    std::string action;
    double probability = 1.0;
    double reward = 0.0;
    double rate_per_s = 0.0; // Used for CTMC semantics.
};

struct SymbolicProbabilisticModel {
    std::size_t state_bits = 1;
    std::uint64_t initial_state = 0;
    std::vector<SymbolicTransition> transitions;
    std::set<std::uint64_t> target_states;
    std::set<std::uint64_t> avoid_states;
    SymbolicProbabilisticSemantics semantics = SymbolicProbabilisticSemantics::Dtmc;
};

struct MtBddNode {
    int variable = -1;
    std::size_t low = 0;
    std::size_t high = 0;
    double terminal = 0.0;
    bool is_terminal = true;
};

struct SymbolicModelCheckResult {
    bool valid_model = false;
    bool converged = false;
    double initial_probability = 0.0;
    double initial_expected_reward = 0.0;
    std::size_t iterations = 0;
    std::size_t reachable_states = 0;
    std::size_t mtbdd_nodes = 0;
    std::map<std::uint64_t, double> values;
    std::map<std::uint64_t, std::string> policy;
    std::vector<MtBddNode> mtbdd;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] double evaluate_mtbdd(std::uint64_t state) const;
    [[nodiscard]] doc::Value to_document(bool include_values = true) const;
};

enum class ProbabilisticPropertyKind { Reachability, TimeBoundedReachability, SteadyState, ExpectedRewardUntilTarget };
enum class ProbabilisticComparator { Query, Less, LessEqual, Greater, GreaterEqual };
struct ProbabilisticProperty {
    ProbabilisticPropertyKind kind = ProbabilisticPropertyKind::Reachability;
    ProbabilisticComparator comparator = ProbabilisticComparator::Query;
    double threshold = 0.0;
    double time_bound_s = 0.0;
    bool maximize = true;
    std::string raw;
};
struct ProbabilisticPropertyResult {
    ProbabilisticProperty property;
    SymbolicModelCheckResult numerical;
    double value = 0.0;
    bool holds = false;
    bool is_query = true;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
enum class ProbabilisticExternalBackend { Storm, Prism };
struct ProbabilisticExternalResult {
    ProbabilisticExternalBackend backend = ProbabilisticExternalBackend::Storm;
    bool available = false;
    bool completed = false;
    int exit_code = -1;
    double elapsed_s = 0.0;
    std::string executable;
    std::string version;
    std::string generated_model;
    std::string generated_property;
    std::string raw_output;
    std::optional<double> value;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_model=false) const;
};

class SymbolicProbabilisticModelChecker {
public:
    [[nodiscard]] SymbolicModelCheckResult reachability(
        const SymbolicProbabilisticModel& model,
        bool maximize = true,
        double tolerance = 1.0e-12,
        std::size_t maximum_iterations = 100000) const;
    [[nodiscard]] SymbolicModelCheckResult expected_reward_until_target(
        const SymbolicProbabilisticModel& model,
        bool minimize = true,
        double tolerance = 1.0e-12,
        std::size_t maximum_iterations = 100000) const;
    [[nodiscard]] SymbolicModelCheckResult steady_state(
        const SymbolicProbabilisticModel& model,
        double tolerance = 1.0e-12,
        std::size_t maximum_iterations = 100000) const;
    [[nodiscard]] SymbolicModelCheckResult ctmc_time_bounded_reachability(
        const SymbolicProbabilisticModel& model,double time_bound_s,
        double tolerance=1.0e-12,std::size_t maximum_poisson_terms=100000) const;
    [[nodiscard]] static ProbabilisticProperty parse_property(const std::string& property);
    [[nodiscard]] ProbabilisticPropertyResult check_property(
        const SymbolicProbabilisticModel& model,const ProbabilisticProperty& property,
        double tolerance=1.0e-12,std::size_t maximum_iterations=100000) const;
    [[nodiscard]] static std::string render_prism_model(const SymbolicProbabilisticModel& model);
    [[nodiscard]] static std::string render_prism_property(const ProbabilisticProperty& property);
    [[nodiscard]] ProbabilisticExternalResult verify_external(
        const SymbolicProbabilisticModel& model,const ProbabilisticProperty& property,
        ProbabilisticExternalBackend backend,double timeout_s=60.0,
        const std::string& working_directory={}) const;
};

// -----------------------------------------------------------------------------
// Unbounded protocol-verifier federation (Tamarin / ProVerif).
// -----------------------------------------------------------------------------

enum class ProtocolVerifierBackend { Tamarin, ProVerif };
struct ProtocolVerificationResult {
    ProtocolVerifierBackend backend = ProtocolVerifierBackend::Tamarin;
    bool available = false;
    bool verified = false;
    bool secure = false;
    int exit_code = -1;
    double elapsed_s = 0.0;
    std::string executable;
    std::string generated_model;
    std::string raw_output;
    std::vector<std::string> claims;
    std::vector<std::string> counterexample_trace;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_model = false) const;
};
class UnboundedSecurityProtocolFederation {
public:
    [[nodiscard]] static std::string render_tamarin(const research2::SecurityProtocol& protocol);
    [[nodiscard]] static std::string render_proverif(const research2::SecurityProtocol& protocol);
    [[nodiscard]] ProtocolVerificationResult verify(
        const research2::SecurityProtocol& protocol,
        ProtocolVerifierBackend backend,
        double timeout_s = 60.0,
        const std::string& working_directory = {}) const;
};

// -----------------------------------------------------------------------------
// ALE moving-mesh compressible CFD + overset masking + conservative remapping.
// -----------------------------------------------------------------------------

enum class TurbulenceClosure { Laminar, SmagorinskyLes, KOmegaSst };
struct AleCfdCellState {
    double density_kg_m3 = 1.2;
    double momentum_x_kg_m2_s = 0.0;
    double momentum_y_kg_m2_s = 0.0;
    double total_energy_j_m3 = 253312.5;
    double turbulent_k_j_kg = 0.0;
    double turbulent_omega_per_s = 1.0;
    double solid_temperature_k = 300.0;
    bool active = true;
};
struct AleStructuredGrid2d {
    std::size_t nx = 2, ny = 2;
    double length_x_m = 1.0, length_y_m = 1.0;
    std::vector<double> x_nodes_m;
    std::vector<double> y_nodes_m;
    void validate() const;
};
struct AleBoundaryMotion {
    double top_velocity_m_s = 0.0;
    double bottom_velocity_m_s = 0.0;
    double left_velocity_m_s = 0.0;
    double right_velocity_m_s = 0.0;
};
struct AleCfdOptions {
    double gamma = 1.4;
    double gas_constant_j_kg_k = 287.05;
    double molecular_viscosity_pa_s = 1.8e-5;
    double thermal_conductivity_w_m_k = 0.026;
    double wall_heat_capacity_j_m2_k = 2.0e4;
    double wall_conductance_w_m2_k = 80.0;
    double cfl = 0.35;
    TurbulenceClosure turbulence = TurbulenceClosure::Laminar;
    double smagorinsky_constant = 0.17;
};
struct AleCfdReport {
    std::vector<AleCfdCellState> cells;
    AleStructuredGrid2d grid;
    double advanced_time_s = 0.0;
    double mass_kg_per_m = 0.0;
    double energy_j_per_m = 0.0;
    double mass_conservation_error = 0.0;
    double energy_conservation_error = 0.0;
    double minimum_density = 0.0;
    double minimum_pressure_pa = 0.0;
    std::size_t remaps = 0;
    std::size_t inactive_overset_cells = 0;
    bool stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};
class AleMovingMeshCfdAuthority {
public:
    [[nodiscard]] AleCfdReport advance(
        AleStructuredGrid2d grid,
        std::vector<AleCfdCellState> cells,
        const AleBoundaryMotion& motion,
        double duration_s,
        const AleCfdOptions& options = {},
        const std::vector<std::array<double,4>>& overset_holes = {}) const;
};

// -----------------------------------------------------------------------------
// CHEMKIN / Cantera-YAML mechanism interchange and mechanism reduction.
// -----------------------------------------------------------------------------

struct Nasa7ThermoRange { double t_min_k=200, t_max_k=6000, t_mid_k=1000; std::array<double,7> low{}, high{}; };
struct DetailedSpecies { std::string name; double molecular_weight_kg_mol=0.02897; Nasa7ThermoRange thermo; std::map<std::string,double> composition; };
enum class DetailedReactionKind { Arrhenius, ThreeBody, FalloffTroe, FalloffSri, PLog, Chebyshev };
struct DetailedReaction {
    std::string equation;
    DetailedReactionKind kind = DetailedReactionKind::Arrhenius;
    std::map<std::string,double> reactants, products, third_body_efficiencies;
    double A=0.0, b=0.0, Ea_j_mol=0.0;
    std::vector<std::array<double,4>> plog; // pressure Pa, A, b, Ea J/mol
    std::vector<double> falloff_parameters;
    std::vector<std::vector<double>> chebyshev;
    double chebyshev_t_min_k=300, chebyshev_t_max_k=2500, chebyshev_p_min_pa=1e4, chebyshev_p_max_pa=1e7;
    bool reversible = true;
};
struct DetailedMechanism {
    std::vector<DetailedSpecies> species;
    std::vector<DetailedReaction> reactions;
    std::map<std::string,std::string> metadata;
    [[nodiscard]] doc::Value to_document() const;
};
struct MechanismReductionReport {
    DetailedMechanism reduced;
    std::map<std::string,double> importance;
    std::vector<std::string> removed_species;
    std::vector<std::size_t> retained_reactions;
    std::set<std::string> quasi_steady_species;
    std::string method;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct DetailedKineticsState {
    double temperature_k=1000.0;
    double pressure_pa=101325.0;
    std::map<std::string,double> concentration_mol_m3;
};
struct SparseJacobianEntry { std::size_t row=0,column=0; double value=0.0; };
struct DetailedKineticsEvaluation {
    std::vector<std::string> species_order;
    std::vector<double> net_production_mol_m3_s;
    std::vector<double> reaction_progress_mol_m3_s;
    std::vector<SparseJacobianEntry> concentration_jacobian;
    double heat_release_w_m3=0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_jacobian=false) const;
};
struct IgnitionDelayReport {
    bool ignited=false;
    double ignition_delay_s=0.0;
    double peak_temperature_k=0.0;
    std::vector<double> time_s,temperature_k;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history=false) const;
};
struct LaminarFlameReport {
    bool converged=false;
    double flame_speed_m_s=0.0;
    double burned_temperature_k=0.0;
    std::size_t iterations=0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct CanteraDifferentialReport {
    bool available=false,completed=false,within_tolerance=false;
    double maximum_relative_rate_error=0.0;
    std::string version,raw_output,evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
class DetailedChemistryInterchange {
public:
    [[nodiscard]] static DetailedMechanism parse_chemkin(const std::string& mechanism_text,
                                                         const std::string& thermo_text = {});
    [[nodiscard]] static DetailedMechanism parse_cantera_yaml(const std::string& yaml_text);
    [[nodiscard]] static std::string emit_cantera_yaml(const DetailedMechanism& mechanism);
    [[nodiscard]] static V51ChemistryMechanism compile_v51_arrhenius_subset(const DetailedMechanism& mechanism);
    [[nodiscard]] static MechanismReductionReport reduce_drgep(
        const DetailedMechanism& mechanism,
        const std::set<std::string>& target_species,
        double threshold = 0.05);
    [[nodiscard]] static MechanismReductionReport reduce_qssa(
        const DetailedMechanism& mechanism,const DetailedKineticsState& reference_state,
        double lifetime_threshold_s=1.0e-5);
    [[nodiscard]] static MechanismReductionReport reduce_csp(
        const DetailedMechanism& mechanism,const DetailedKineticsState& reference_state,
        const std::set<std::string>& protected_species,double stiffness_threshold=0.01);
    [[nodiscard]] static DetailedKineticsEvaluation evaluate_kinetics(
        const DetailedMechanism& mechanism,const DetailedKineticsState& state,bool compute_jacobian=true);
    [[nodiscard]] static IgnitionDelayReport ignition_delay_constant_volume(
        const DetailedMechanism& mechanism,DetailedKineticsState initial,double end_time_s,
        double initial_step_s=1.0e-8,double ignition_delta_k=400.0);
    [[nodiscard]] static LaminarFlameReport validate_laminar_flame(
        const DetailedMechanism& mechanism,const DetailedKineticsState& unburned,
        double thermal_diffusivity_m2_s=2.0e-5,double domain_m=0.02,
        std::size_t nodes=101,std::size_t maximum_iterations=20000);
    [[nodiscard]] static CanteraDifferentialReport differential_verify_cantera(
        const DetailedMechanism& mechanism,const DetailedKineticsState& state,
        double relative_tolerance=1.0e-5,const std::string& working_directory={});
};

// -----------------------------------------------------------------------------
// General implicit nonlinear finite-element authority.
// -----------------------------------------------------------------------------

enum class FeElementType { CorotationalTruss2, Tetrahedron4, EulerBernoulliBeam2, ReissnerMindlinShell3 };
enum class FeMaterialModel { LinearElastic, StVenantKirchhoff, NeoHookean, OrthotropicElastic, BilinearJ2Plastic };
struct FeNode3d { std::array<double,3> x{}; };
struct FeMaterial { FeMaterialModel model=FeMaterialModel::StVenantKirchhoff; double young_pa=2.1e11, poisson=0.3, density_kg_m3=7800, area_m2=1.0e-4; double second_moment_y_m4=1.0e-8,second_moment_z_m4=1.0e-8,torsion_constant_m4=2.0e-8,shell_thickness_m=1.0e-3; double yield_stress_pa=2.5e8,hardening_modulus_pa=1.0e9; double young_y_pa=0.0,shear_xy_pa=0.0; };
struct FeElement { FeElementType type=FeElementType::CorotationalTruss2; std::vector<std::size_t> nodes; std::size_t material=0; std::array<double,3> orientation{0,0,1}; };
struct FeConstraint { std::size_t node=0, dof=0; double value=0.0; };
struct FeMpcTerm { std::size_t node=0, dof=0; double coefficient=1.0; };
struct FeMpcConstraint { std::vector<FeMpcTerm> terms; double rhs=0.0; };
struct FePlaneContact { std::array<double,3> normal{0,0,1}; double offset_m=0.0; double penalty_n_m=1e9; double friction_coefficient=0.0; };
struct FeLoad { std::size_t node=0, dof=0; double value_n=0.0; };
struct FeModel {
    std::vector<FeNode3d> nodes;
    std::vector<FeMaterial> materials;
    std::vector<FeElement> elements;
    std::vector<FeConstraint> constraints;
    std::vector<FeMpcConstraint> mpcs;
    std::vector<FePlaneContact> contacts;
    std::vector<FeLoad> loads;
};
enum class FeNonlinearStrategy { NewtonDirect, NewtonKrylov, TrustRegion };
struct FeSolveOptions { std::size_t load_steps=10, maximum_newton_iterations=40; double residual_tolerance=1e-8, displacement_tolerance=1e-10; bool line_search=true; FeNonlinearStrategy nonlinear_strategy=FeNonlinearStrategy::NewtonDirect; double trust_radius_m=0.05; };
struct FeSolveResult {
    bool converged=false;
    std::vector<double> displacement_m;
    std::vector<double> reaction_n;
    std::size_t newton_iterations=0;
    double final_residual_norm=0.0;
    double strain_energy_j=0.0;
    std::vector<double> load_history;
    std::vector<double> residual_history;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_vectors=false) const;
};
struct FeModalResult { std::vector<double> frequencies_hz; std::vector<std::vector<double>> modes; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_modes=false) const; };
struct FeBucklingResult { bool converged=false; std::vector<double> load_factors; std::vector<std::vector<double>> modes; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_modes=false) const; };
struct FeDynamicsOptions { double time_step_s=1.0e-4,end_time_s=0.01,newmark_beta=0.25,newmark_gamma=0.5,rayleigh_mass=0.0,rayleigh_stiffness=0.0; std::size_t maximum_newton_iterations=25; double residual_tolerance=1.0e-7; };
struct FeDynamicsResult { bool converged=false; std::vector<double> time_s; std::vector<std::vector<double>> displacement_history; std::vector<std::vector<double>> velocity_history; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_history=false) const; };
struct FeArcLengthOptions { std::size_t maximum_steps=50,maximum_iterations=30; double arc_length=0.01,load_scale=1.0,residual_tolerance=1.0e-7; };
struct FeArcLengthResult { bool converged=false; std::vector<double> load_factor; std::vector<std::vector<double>> displacement_path; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_path=false) const; };
class ImplicitNonlinearFeaAuthority {
public:
    [[nodiscard]] FeSolveResult solve_static(const FeModel& model,const FeSolveOptions& options={}) const;
    [[nodiscard]] FeModalResult modal_analysis(const FeModel& model,std::size_t requested_modes=10) const;
    [[nodiscard]] FeBucklingResult linearized_buckling(const FeModel& model,double preload_fraction=1.0,std::size_t requested_modes=10) const;
    [[nodiscard]] FeDynamicsResult solve_implicit_dynamics(const FeModel& model,const FeDynamicsOptions& options={}) const;
    [[nodiscard]] FeArcLengthResult solve_arc_length(const FeModel& model,const FeArcLengthOptions& options={}) const;
};

// -----------------------------------------------------------------------------
// STEP AP242 Part-21 semantic exchange with lossless unknown-entity roundtrip.
// -----------------------------------------------------------------------------

struct StepEntity { std::uint64_t id=0; std::string type; std::string arguments; };
struct StepNurbsCurve {
    std::uint64_t entity_id=0; int degree=0; std::vector<std::uint64_t> control_points;
    std::vector<double> knots,weights; bool closed=false;
};
struct StepNurbsSurface {
    std::uint64_t entity_id=0; int u_degree=0,v_degree=0;
    std::vector<std::vector<std::uint64_t>> control_points;
    std::vector<double> u_knots,v_knots;
    std::vector<std::vector<double>> weights;
    bool u_closed=false,v_closed=false;
};
struct StepSemanticDocument {
    std::string header;
    std::vector<StepEntity> entities;
    std::map<std::uint64_t,std::array<double,3>> cartesian_points;
    std::vector<std::uint64_t> nurbs_curve_entities;
    std::vector<std::uint64_t> nurbs_surface_entities;
    std::vector<std::uint64_t> assembly_entities;
    std::vector<std::uint64_t> pmi_entities;
    std::vector<std::uint64_t> gdt_entities;
    std::vector<std::uint64_t> presentation_entities;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_entities=false) const;
};
class StepAp242SemanticExchange {
public:
    [[nodiscard]] StepSemanticDocument parse(const std::string& part21) const;
    [[nodiscard]] std::string serialize(const StepSemanticDocument& document) const;
    [[nodiscard]] CadMesh tessellate_nurbs_control_nets(const StepSemanticDocument& document) const;
    [[nodiscard]] std::optional<StepNurbsCurve> decode_nurbs_curve(const StepSemanticDocument& document,std::uint64_t entity_id) const;
    [[nodiscard]] std::optional<StepNurbsSurface> decode_nurbs_surface(const StepSemanticDocument& document,std::uint64_t entity_id) const;
    [[nodiscard]] std::array<double,3> evaluate_nurbs_curve(const StepSemanticDocument& document,std::uint64_t entity_id,double parameter) const;
    [[nodiscard]] std::array<double,3> evaluate_nurbs_surface(const StepSemanticDocument& document,std::uint64_t entity_id,double u,double v) const;
    [[nodiscard]] CadMesh tessellate_nurbs_surfaces(const StepSemanticDocument& document,std::size_t u_segments=24,std::size_t v_segments=24) const;
};

// -----------------------------------------------------------------------------
// ASAM MCD-3 MC compatible in-process server API over SignalRegistry/XCP.
// -----------------------------------------------------------------------------

enum class McTaskState { Created, Configured, Running, Stopped, Error };
struct McMeasurementSample { std::uint64_t timestamp_ns=0; std::map<std::string,double> values; };
struct McTask {
    std::string id;
    McTaskState state=McTaskState::Created;
    std::vector<std::string> measurements;
    std::vector<std::string> characteristics;
    std::uint16_t event_channel=0;
    std::size_t raster_prescaler=1;
    std::vector<McMeasurementSample> recording;
};
class Mc3MeasurementCalibrationServer {
public:
    explicit Mc3MeasurementCalibrationServer(industrial::SignalRegistry& registry);
    std::string create_project(const std::string& name);
    std::string open_device(const std::string& project_id,const std::string& name);
    std::string create_task(const std::string& device_id,const std::string& task_name);
    void configure_task(const std::string& task_id,std::vector<std::string> measurements,
                        std::vector<std::string> characteristics,std::uint16_t event_channel,
                        std::size_t raster_prescaler=1);
    void start_task(const std::string& task_id);
    void stop_task(const std::string& task_id);
    [[nodiscard]] McMeasurementSample sample(const std::string& task_id,std::uint64_t timestamp_ns);
    void write_characteristic(const std::string& task_id,const std::string& name,double value);
    [[nodiscard]] double read_characteristic(const std::string& task_id,const std::string& name) const;
    [[nodiscard]] const McTask& task(const std::string& task_id) const;
    [[nodiscard]] std::string generate_a2l(const std::string& project_name="MUZIXDIAGSYS_MCD3") const;
    std::string create_client(const std::string& name);
    bool acquire_device(const std::string& client_id,const std::string& device_id);
    void release_device(const std::string& client_id,const std::string& device_id);
    void select_calibration_page(const std::string& task_id,std::uint32_t page);
    [[nodiscard]] std::uint32_t calibration_page(const std::string& task_id) const;
    void begin_calibration_transaction(const std::string& task_id);
    void stage_characteristic(const std::string& task_id,const std::string& name,double value);
    void commit_calibration_transaction(const std::string& task_id);
    void rollback_calibration_transaction(const std::string& task_id);
    [[nodiscard]] std::optional<McMeasurementSample> on_event(const std::string& task_id,std::uint16_t event_channel,std::uint64_t event_counter,std::uint64_t timestamp_ns);
    void export_recording_csv(const std::string& task_id,const std::string& path) const;
    [[nodiscard]] doc::Value inventory() const;
private:
    industrial::SignalRegistry& registry_;
    std::map<std::string,std::string> projects_,devices_;
    std::map<std::string,McTask> tasks_;
    std::map<std::string,std::string> task_devices_;
    std::map<std::string,std::string> clients_,device_locks_;
    std::map<std::string,std::uint32_t> pages_;
    std::map<std::string,std::map<std::string,double>> staged_transactions_;
    std::set<std::string> active_transactions_;
    std::uint64_t sequence_=0;
};

// -----------------------------------------------------------------------------
// Uptane/TUF asymmetric metadata verification.
// -----------------------------------------------------------------------------

enum class TufKeyType { Ed25519, EcdsaP256Sha256, RsaPssSha256 };
struct TufKey { std::string key_id; TufKeyType type=TufKeyType::Ed25519; std::string public_key_pem; };
struct TufSignature { std::string key_id; std::string signature_base64; };
struct TufSignedMetadata {
    std::string role;
    std::uint64_t version=1;
    std::int64_t expires_epoch_s=0;
    doc::Value signed_body;
    std::vector<TufSignature> signatures;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] std::string canonical_signed_json() const;
};
struct TufRolePolicy { std::set<std::string> key_ids; std::size_t threshold=1; };
struct UptaneVerificationReport {
    bool signatures_valid=false, not_expired=false, rollback_protected=false, threshold_met=false, target_hash_valid=false;
    std::size_t valid_signatures=0;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct TufRootTrust { std::map<std::string,TufKey> keys; std::map<std::string,TufRolePolicy> roles; std::uint64_t version=0; };
struct TufTargetDescription { std::string path,sha256; std::uint64_t length=0; doc::Value custom; };
struct UptaneRepositoryBundle { TufSignedMetadata root,timestamp,snapshot,targets; std::optional<TufSignedMetadata> director_targets; std::map<std::string,TufSignedMetadata> delegated_targets; };
struct UptaneRepositoryReport { bool root_rotation_valid=false,timestamp_valid=false,snapshot_valid=false,targets_valid=false,director_consistent=true,repository_consistent=false; std::vector<std::string> findings; std::string evidence_sha256; [[nodiscard]] doc::Value to_document() const; };
class UptaneTufVerifier {
public:
    [[nodiscard]] static bool verify_signature(const TufKey& key,const std::string& message,const TufSignature& signature);
    [[nodiscard]] UptaneVerificationReport verify_metadata(const TufSignedMetadata& metadata,
                                                           const std::map<std::string,TufKey>& keys,
                                                           const TufRolePolicy& policy,
                                                           std::uint64_t trusted_version,
                                                           std::int64_t now_epoch_s) const;
    [[nodiscard]] UptaneVerificationReport verify_target_file(const std::string& path,
                                                              const std::string& expected_sha256,
                                                              std::uint64_t expected_length) const;
    [[nodiscard]] bool verify_root_rotation(const TufSignedMetadata& new_root,
                                            const TufRootTrust& trusted_root,
                                            TufRootTrust* accepted_root=nullptr,
                                            std::int64_t now_epoch_s=0) const;
    [[nodiscard]] UptaneRepositoryReport verify_repository(const UptaneRepositoryBundle& bundle,
                                                            const TufRootTrust& trusted_root,
                                                            const std::map<std::string,std::uint64_t>& trusted_versions,
                                                            std::int64_t now_epoch_s) const;
    [[nodiscard]] static std::map<std::string,TufTargetDescription> target_descriptions(const TufSignedMetadata& targets);
};

// -----------------------------------------------------------------------------
// Native third-party ZFP/SZ3 bitstream interoperability.
// -----------------------------------------------------------------------------

enum class NativeCompressionBackend { Zfp, Sz3 };
enum class NativeCompressionMode { AbsoluteError, FixedRate, FixedPrecision, RelativeError };
struct NativeCompressionOptions { NativeCompressionMode mode=NativeCompressionMode::AbsoluteError; double tolerance=1.0e-6; double rate_bits_per_value=8.0; unsigned precision_bits=32; };
struct NativeCompressedArray {
    NativeCompressionBackend backend=NativeCompressionBackend::Zfp;
    std::vector<std::size_t> shape;
    std::vector<std::uint8_t> bitstream;
    double absolute_error_bound=0.0;
    NativeCompressionMode mode=NativeCompressionMode::AbsoluteError;
    double configured_parameter=0.0;
    std::string backend_version;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_payload=false) const;
};
class NativeScientificCompressionInterop {
public:
    [[nodiscard]] static bool available(NativeCompressionBackend backend) noexcept;
    [[nodiscard]] static NativeCompressedArray compress(const std::vector<double>& values,
                                                         const std::vector<std::size_t>& shape,
                                                         NativeCompressionBackend backend,
                                                         double absolute_error_bound);
    [[nodiscard]] static NativeCompressedArray compress(const std::vector<double>& values,
                                                         const std::vector<std::size_t>& shape,
                                                         NativeCompressionBackend backend,
                                                         const NativeCompressionOptions& options);
    [[nodiscard]] static std::vector<double> decompress(const NativeCompressedArray& compressed);
};

// -----------------------------------------------------------------------------
// Modelica source expansion / flattening into the existing DAE compiler.
// -----------------------------------------------------------------------------

struct ModelicaFlattenResult {
    bool success=false;
    std::string model_name;
    std::string flattened_source;
    std::vector<std::string> inheritance_chain;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_source=false) const;
};
class ModelicaLanguageExpander {
public:
    void add_source(const std::string& source_name,const std::string& source);
    [[nodiscard]] ModelicaFlattenResult flatten(const std::string& qualified_model_name) const;
    [[nodiscard]] doc::Value validate_with_openmodelica(const std::string& qualified_model_name,const std::string& working_directory={},double timeout_s=60.0) const;
private:
    std::map<std::string,std::string> sources_;
};

// -----------------------------------------------------------------------------
// ASAM CMP interoperable transport/session + PCAPNG export.
// -----------------------------------------------------------------------------

struct CmpSessionConfig { std::uint8_t major=1,minor=1; std::uint16_t capture_module_id=0,data_sink_id=0; };
struct CmpSessionReport { std::uint64_t sent=0,received=0,duplicates=0,gaps=0,reordered=0; std::string evidence_sha256; [[nodiscard]] doc::Value to_document() const; };
class AsamCmpInteropSession {
public:
    explicit AsamCmpInteropSession(CmpSessionConfig config={});
    [[nodiscard]] expansion::CmpRecord make_record(std::uint16_t source_interface_id,
                                                  std::uint16_t message_type,
                                                  std::uint64_t timestamp_ns,
                                                  std::vector<std::uint8_t> payload);
    void ingest(const std::vector<std::uint8_t>& frame);
    [[nodiscard]] CmpSessionReport report() const;
    void export_pcapng(const std::string& path) const;
private:
    CmpSessionConfig config_;
    std::uint32_t next_sequence_=0;
    std::optional<std::uint32_t> highest_;
    std::set<std::uint32_t> seen_;
    std::vector<std::vector<std::uint8_t>> frames_;
    CmpSessionReport report_;
};

// -----------------------------------------------------------------------------
// Standards-conformance orchestration.
// -----------------------------------------------------------------------------

struct ConformanceTool {
    std::string id;
    std::string executable;
    std::vector<std::string> arguments;
    std::set<int> passing_exit_codes{0};
    double timeout_s=120.0;
};
struct ConformanceExecution {
    std::string tool_id,executable,version,artifact;
    bool available=false,passed=false,timed_out=false;
    int exit_code=-1;
    double elapsed_s=0.0;
    std::string output,evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct ConformanceMatrix {
    std::vector<ConformanceExecution> executions;
    bool all_required_passed=false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
class ConformanceWorkbench {
public:
    [[nodiscard]] ConformanceMatrix run(const std::string& artifact,
                                        const std::vector<ConformanceTool>& tools,
                                        const std::string& working_directory={}) const;
};

// -----------------------------------------------------------------------------
// Production-oriented hybrid CFD meshing: prism boundary layers + tetra core.
// -----------------------------------------------------------------------------

struct HybridMesh3d {
    std::vector<std::array<double,3>> vertices;
    std::vector<std::array<std::size_t,4>> tetrahedra;
    std::vector<std::array<std::size_t,6>> prisms;
    std::vector<std::array<std::size_t,3>> boundary_triangles;
};
struct HybridMeshOptions { std::size_t prism_layers=5; double first_layer_m=1e-4,growth_ratio=1.25; double maximum_tetra_edge_m=0.05; std::size_t smoothing_iterations=10; };
struct HybridMeshReport {
    HybridMesh3d mesh;
    double minimum_tetra_quality=0.0,minimum_prism_quality=0.0,maximum_aspect_ratio=0.0;
    bool positive_jacobians=false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_mesh=false) const;
};
class HybridCfdMesher {
public:
    [[nodiscard]] HybridMeshReport generate(const CadMesh& watertight_surface,
                                            const HybridMeshOptions& options={}) const;
};

// -----------------------------------------------------------------------------
// Higher-order PNT stochastic bias/clock state propagation and smoothing.
// -----------------------------------------------------------------------------

struct StochasticProcessSpec { std::string state_name; double correlation_time_s=1e9, driving_sigma=0.0, initial_sigma=0.0; };
struct AllanDeviationPoint { double tau_s=1.0,sigma=0.0; };
struct HigherOrderPntOptions {
    std::vector<StochasticProcessSpec> processes;
    std::vector<AllanDeviationPoint> clock_allan_deviation;
    bool rts_smoothing=true;
};
struct HigherOrderPntResult {
    std::vector<double> time_s;
    std::vector<std::map<std::string,double>> mean;
    std::vector<std::map<std::string,double>> standard_deviation;
    std::map<std::string,double> smoothed_final_mean;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history=false) const;
};
class HigherOrderPntStochasticPropagator {
public:
    [[nodiscard]] HigherOrderPntResult propagate(const std::vector<double>& time_s,
                                                 const HigherOrderPntOptions& options,
                                                 std::uint64_t deterministic_seed=0x52A11AULL) const;
};

// -----------------------------------------------------------------------------
// MQTT 5 / Sparkplug B / Kafka-compatible wire codecs and deterministic gateway.
// -----------------------------------------------------------------------------

struct MqttProperty { std::uint8_t id=0; std::vector<std::uint8_t> value; };
struct MqttPublishPacket { std::string topic; std::vector<std::uint8_t> payload; std::uint8_t qos=0; bool retain=false,dup=false; std::uint16_t packet_id=0; std::vector<MqttProperty> properties; };
class Mqtt5Codec {
public:
    [[nodiscard]] static std::vector<std::uint8_t> encode_publish(const MqttPublishPacket& packet);
    [[nodiscard]] static MqttPublishPacket decode_publish(const std::vector<std::uint8_t>& bytes);
};
struct SparkplugMetric { std::string name; std::uint64_t timestamp_ms=0; double value=0.0; std::string unit; bool transient=false; };
struct SparkplugPayload { std::uint64_t timestamp_ms=0,seq=0; std::vector<SparkplugMetric> metrics; };
class SparkplugBCodec {
public:
    [[nodiscard]] static std::vector<std::uint8_t> encode(const SparkplugPayload& payload);
    [[nodiscard]] static SparkplugPayload decode(const std::vector<std::uint8_t>& bytes);
};
struct KafkaRecord { std::vector<std::uint8_t> key,value; std::int64_t timestamp_ms=0; };
struct KafkaRecordBatch { std::int64_t base_offset=0; std::vector<KafkaRecord> records; };
class KafkaRecordBatchCodec {
public:
    [[nodiscard]] static std::vector<std::uint8_t> encode(const KafkaRecordBatch& batch);
    [[nodiscard]] static KafkaRecordBatch decode(const std::vector<std::uint8_t>& bytes);
};
struct StreamingGatewayRecord { std::uint64_t sequence=0; std::string channel; std::int64_t timestamp_ns=0; std::vector<std::uint8_t> payload; std::string sha256; std::string idempotency_key; std::size_t delivery_attempts=0; bool acknowledged=false; };
enum class StreamingBackpressurePolicy { RejectNewest, DropOldest, BlockEquivalent };
struct StreamingGatewayPolicy { std::size_t maximum_pending=10000,maximum_delivery_attempts=5; StreamingBackpressurePolicy backpressure=StreamingBackpressurePolicy::RejectNewest; bool deduplicate=true; };
struct StreamingDeliveryReport { std::size_t attempted=0,acknowledged=0,failed=0,deduplicated=0,dropped=0; std::vector<std::uint64_t> pending_sequences; std::string evidence_sha256; [[nodiscard]] doc::Value to_document() const; };
class DeterministicStreamingGateway {
public:
    explicit DeterministicStreamingGateway(StreamingGatewayPolicy policy={}) : policy_(policy) {}
    void publish(std::string channel,std::int64_t timestamp_ns,std::vector<std::uint8_t> payload,std::string idempotency_key={});
    [[nodiscard]] StreamingDeliveryReport deliver(const std::function<bool(const StreamingGatewayRecord&)>& transport);
    void acknowledge(std::uint64_t sequence);
    [[nodiscard]] std::vector<StreamingGatewayRecord> replay(std::uint64_t first_sequence,std::optional<std::uint64_t> last_sequence=std::nullopt) const;
    [[nodiscard]] const std::vector<StreamingGatewayRecord>& records() const noexcept { return records_; }
    void save(const std::string& path) const;
    [[nodiscard]] static DeterministicStreamingGateway load(const std::string& path);
private:
    StreamingGatewayPolicy policy_;
    std::vector<StreamingGatewayRecord> records_;
    std::set<std::string> idempotency_seen_;
    std::size_t dropped_=0,deduplicated_=0;
};

class V52AuthorityExpansionPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

} // namespace aesim::advanced::v52

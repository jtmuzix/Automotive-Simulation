# MuzixDiagSys V11 Professional UI Workbenches - Implementation Report

**Release date:** 2026-08-10  
**Baseline:** V10 FINAL debugged/refactored source  
**Compatibility contract:** additive implementation; no existing simulator feature, command family, backend, dashboard, workflow, vehicle model, motorsport module, research platform, file format, or API was removed.

## Scope

V11 fully implements five integrated professional engineering UI/workflow capabilities:

1. Engineering Mission Control
2. N-Way Run Comparison Workbench
3. Requirements-Verification-Evidence Matrix
4. Design-Space Explorer
5. Engineering Flight Recorder

The implementation deliberately reuses the established MuzixDiagSys UI architecture instead of creating a second simulation or analysis backend. Terminal, browser, completion/search, and future presentation surfaces therefore resolve to the same canonical command handlers and authoritative simulator state.

## Source architecture

### Public UI API

`include/aesim/app/engineering_ui_platform.hpp` adds production data contracts and workbench classes for mission health/jobs/alerts, comparison runs/statistics, requirements/verifications/evidence, design-space analysis, and flight records. `EngineeringUiSuite` owns the five workbench instances together with the pre-existing UI subsystems.

### Production implementation

`src/ui/advanced_engineering_workbenches.cpp` contains the complete algorithms and state management. It is compiled into `aesim_console_support`; no header-only placeholder or demo-only implementation is used.

### Canonical shell integration

`src/ui/console_frontend.cpp` adds command completion and executable handlers for:

- `ui mission-control ...` / `ui mission ...`
- `ui run-compare ...` / `ui nway-compare ...`
- `ui verification-matrix ...` / `ui vve-matrix ...`
- `ui design-space ...` / `ui design-space-explorer ...`
- `ui flight-recorder ...` / `ui flight ...`

The same command families are searchable from Structured Search and launchable from the browser UI. Browser controls submit canonical commands; analysis logic is not duplicated in JavaScript.

## 1. Engineering Mission Control

Mission Control aggregates operational state from the real `globalui::JobManager`, loaded regression-triage results, live runtime profiling, subsystem readiness, and operator alerts.

Implemented behavior includes:

- queued/running/paused/blocked/completed/failed/cancelled job states;
- validated job progress and log updates;
- cancellation and state transitions;
- host RSS/process CPU/GPU profiling when available;
- explicit subsystem nominal/degraded/critical/offline status;
- alert severity/title/detail/object identity, de-duplication, repeat counts, acknowledgement, and clearing;
- thread-safe runtime/subsystem/alert snapshots for reports.

`mission-control submit` intentionally registers a managed work item instead of falsely claiming asynchronous command execution. Existing job/workflow execution mechanisms remain authoritative.

## 2. N-Way Run Comparison Workbench

The comparison workbench stores complete numeric signal histories and supports in-memory telemetry capture or external CSV import.

Implemented analysis includes:

- robust CSV parsing including quoted fields and escaped quotes;
- automatic or explicit time-column selection;
- time, sample-index, and arbitrary numeric-channel alignment (for example distance, lap position, or crank angle);
- overlap-domain interpolation onto baseline coordinates;
- deterministic point reduction for very large histories;
- paired sample count, baseline mean, candidate mean, bias, MAE, RMSE, maximum absolute delta, and Pearson correlation;
- N-run min/mean/max/count envelopes over a common coordinate domain;
- baseline selection, run inspection/removal, and complete clear/reset.

No synthetic waveform is generated when real histories are unavailable. Capture uses the telemetry workbench's actual stored samples; a current backend metric snapshot is used only as the truthful one-sample fallback.

## 3. Requirements-Verification-Evidence Matrix

The V&V matrix provides executable traceability rather than a cosmetic requirements table.

Implemented behavior includes:

- requirement records with standard, clause, owner, criticality, tags, and stable IDs;
- verification records linked to one or more requirements;
- explicit verdicts plus tolerance-derived pass/fail evaluation from observed/expected/tolerance data;
- run/metric/detail associations;
- SHA-256 evidence attachment using the production provenance implementation;
- file-size and digest retention;
- evidence re-hashing during traceability evaluation;
- deleted, unreadable, or modified evidence reported as stale;
- aggregate requirement verdict propagation with fail/stale/inconclusive/unverified/pass distinctions;
- verification/evidence coverage accounting, orphan detection, stale-artifact reporting, and requirement trace reports.

A supporting artifact therefore cannot be modified after registration while leaving the requirement silently green.

## 4. Design-Space Explorer

Design-Space Explorer analyzes the existing `ExperimentMatrix`; it does not create a parallel DOE database.

Implemented analysis includes:

- selected-run summary and parameter/objective ranges;
- Pearson sensitivity ranking against an objective;
- pairwise-complete parameter/objective correlation matrices;
- normalized parallel-coordinate tabulation suitable for terminal/SSH operation;
- multi-constraint feasibility filtering;
- constraint operators `<`, `<=`, `>`, `>=`, `=`, `==`, and `!=`;
- `obj.`, `p.`, `param.`, and unprefixed field addressing;
- AND semantics across constraints and conservative rejection when a required field is missing;
- direct use of the existing experiment matrix Pareto implementation from the command surface.

## 5. Engineering Flight Recorder

Flight Recorder is connected to the canonical command lifecycle, not merely exposed as a manual log command.

Implemented behavior includes:

- automatic command-submitted events from `Session::next_command`;
- automatic command-result events from UI and normal simulator command paths;
- result severity derived from command outcome text;
- bounded live engineering telemetry capture at approximately one-second simulation-time cadence;
- manual events and synchronized-time bookmarks;
- immutable monotonic sequence IDs;
- wall-clock timestamp, simulation time, severity, kind, title, detail, object URI, command, correlation ID, and numeric metric maps;
- bounded FIFO retention with validated capacity from 100 to 5,000,000 events;
- structured filtering by `kind:`, `severity:`, `uri:`, `command:`, `after:`, `before:`, free text, and leading `-` negation;
- sequence inspection;
- lossless JSONL export including metrics;
- interoperable CSV export.

## Integration and discoverability

The five workbenches are registered in:

- shell completion;
- engineering UI structured search;
- browser launch controls;
- the canonical command dispatcher;
- `EngineeringUiSuite` lifecycle/state;
- the engineering UI source regression;
- the C++ feature regression;
- a new authenticated executable-level CLI regression.

## Tests added or expanded

`tests/engineering_ui_platform_tests.cpp` now exercises 25 feature families. New test groups cover:

- Mission Control job transitions, subsystem health, alerts, and acknowledgement;
- N-way time/distance alignment, statistics, envelope output, and CSV import;
- V&V tolerance verdicts, SHA-backed evidence, coverage, and tamper/stale detection;
- Design-Space summary, sensitivity, correlations, parallel coordinates, and feasibility;
- Flight Recorder command/result/event/telemetry capture, rate limiting, query, lookup, capacity behavior, and JSONL/CSV export.

`tests/professional_ui_workbenches_cli_regression.py` drives all five features through the fully linked authenticated `muzixdiagsys` executable using temporary CSV/evidence inputs and validates exported Flight Recorder data.

`tests/engineering_ui_platform_regression.py` now requires the five concrete classes, new implementation source, command routes, CMake integration, browser/search exposure, and rejects unfinished implementation markers.

## Documentation

Updated operator/developer documentation:

- `README.md`
- `docs/ENGINEERING_UI_PLATFORM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md` (Chapter 75)
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf` (regenerated from authoritative Markdown)
- `docs/DOCUMENTATION_INDEX.md`

## Compatibility and non-removal guarantee

V11 is an additive source evolution of V10 FINAL. Existing source files remain present. The five workbenches consume existing jobs, telemetry, experiments, evidence/provenance, regression, time-cursor, profiler, browser, and command infrastructure; they do not replace those systems.

# Frontier Next Implementation Report — 2026-08-08

## Scope and compatibility policy

This release adds sixteen requested engineering/research domains to the existing MuzixDiagSys Advanced Automotive Simulator. The change is additive: existing simulator features, Formula One/IndyCar/NASCAR platforms, command families, public APIs, numerical-assurance facilities, diagnostics, UI workflows, tests, and prior frontier platforms remain available.

The aggregate production command family is:

```text
muzixdiagsys_advanced_platform frontier-next ...
```

The public C++ API is exported by:

```text
include/aesim/advanced/frontier_next_platform.hpp
```

The implementation is compiled into `aesim_advanced` from `src/advanced/frontier_next_platform.cpp` and exported through the existing advanced platform umbrella header.

## Expanded CLI surface

Every domain is available through the aggregate dispatcher and through a dedicated top-level alias. Each alias supports `capabilities`, `self-test`, `run`, and operation-specific invocation where the request schema exposes an operation.

| Domain | CLI alias |
|---|---|
| automotive-wireless-phy-coexistence-laboratory | `wireless-phy` |
| secure-uwb-bluetooth-ranging-platform | `secure-ranging` |
| dynamic-complex-mu-synthesis-laboratory | `complex-mu` |
| stochastic-subspace-identification-platform | `stochastic-id` |
| distributed-formal-protocol-verification-platform | `protocol-verify` |
| automotive-software-static-verification-laboratory | `static-verify` |
| native-petsc-sundials-hypre-solver-platform | `native-solvers` |
| advanced-distributed-gpu-communication-runtime | `gpu-comm` |
| adios2-high-rate-scientific-streaming-platform | `adios2-stream` |
| cgns-xdmf-exodus-mesh-interchange-platform | `mesh-interchange` |
| automotive-ibis-ami-sparameter-platform | `ibis-ami` |
| advanced-refrigerant-heat-pump-laboratory | `heat-pump` |
| advanced-nde-metrology-platform | `nde-metrology` |
| model-maturity-validity-registry | `model-maturity` |
| scenario-space-coverage-metrics-platform | `scenario-coverage` |
| probabilistic-model-form-uncertainty-platform | `model-form-uq` |

Generic alias syntax:

```text
muzixdiagsys_advanced_platform ALIAS capabilities [output.json]
muzixdiagsys_advanced_platform ALIAS self-test DIRECTORY [output.json]
muzixdiagsys_advanced_platform ALIAS run REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
muzixdiagsys_advanced_platform ALIAS OPERATION REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The prior `frontier-runtime`, `frontier-expansion`, `frontier-systems`, `frontier-integration`, motorsports, standards, diagnostics, and other command families were not removed or renamed.

## Implemented domains

### 1. Automotive wireless PHY/coexistence laboratory

Implemented a physical/system-level wireless link laboratory with OFDM/QAM MCS profiles, free-space/log-distance propagation, Rician fading, receiver noise figure and thermal noise, co-channel/adjacent interferers with duty/spectral overlap, Doppler/coherence calculations, uncoded BER, coded packet-error estimation from decoding margin and packet length, PHY rate/goodput, and optional deterministic raw complex I/Q generation. Power aggregation is performed in the linear domain. A regression anchors the conversion with a -90 dBm interferer at 50% duty yielding approximately -93.0103 dBm average interference power.

### 2. Secure UWB/Bluetooth ranging platform

Implemented UWB single-sided and double-sided two-way ranging plus Bluetooth channel-sounding-style ranging. The model includes clock offset/drift, antenna delay, timestamp quantization/noise, NLOS and multipath bias, relay/wormhole delay, range covariance, array angle-of-arrival estimation, and optional prior-state fusion.

### 3. Dynamic complex-mu synthesis laboratory

Implemented continuous-frequency robust-analysis workflows over state-space plants with complex matrix evaluation, frequency sweeps, structured complex uncertainty blocks, iterative D-scaling-style upper bounds, deterministic complex-phase lower-bound witness searches, worst-frequency extraction, robust-performance margins, and evidence output. This extends the earlier structured-real affine robustness implementation rather than replacing it.

### 4. Stochastic subspace identification platform

Implemented block-Hankel/subspace realization workflows with N4SID/MOESP/CVA-style weighting/realization behavior plus iterative ARMAX innovation regression. Outputs include identified state-space or polynomial models, fit/error metrics, order information, and deterministic evidence.

### 5. Distributed formal protocol verification platform

Implemented explicit reachable-state graph exploration for bounded distributed protocols. Requests define integer state variables, guarded transitions, updates, invariants, and goal predicates. The verifier performs breadth-first state exploration, invariant checking, deadlock discovery, predecessor/reverse-graph liveness-to-goal analysis, counterexample state reporting, and bounded-state qualification.

### 6. Automotive software static verification laboratory

Implemented internal MISRA/AUTOSAR/security-oriented source checks for dangerous C interfaces, dynamic-allocation policies, `reinterpret_cast`, `goto`, dangerous shifts, and related coding hazards. Optional native compiler analysis directly invokes Clang or GCC without shell interpolation using syntax/warning/conversion/shadow checks and optional GCC analyzer support. Findings, tool capability, exit status, and evidence are returned.

### 7. Native PETSc/SUNDIALS/HYPRE solver platform

Implemented deterministic reference linear/ODE solvers plus real capability-gated native adapters:

- PETSc: sequential AIJ matrix/vector construction, KSP/CG solve, convergence qualification, extraction, and independent residual recomputation.
- SUNDIALS: CVODE BDF integration for a linear ODE, dense SUNMatrix/SUNLinearSolver integration, context handling for modern SUNDIALS, solution extraction, and step evidence.
- HYPRE: IJ/ParCSR matrix/vector construction, PCG execution, convergence/iteration extraction, and independent residual recomputation.

Requests for an unavailable native backend fail explicitly; native execution is never emulated as successful.

### 8. Advanced distributed GPU communication runtime

Implemented deterministic ring communication/reduction cost analysis, native MPI `Allreduce` where MPI is initialized, CUDA device memory transfer qualification where CUDA is available, and a real NCCL all-reduce path when MPI + CUDA + NCCL are all compiled and available. NCCL results are independently compared against MPI reduction evidence. Runtime capability reporting also exposes UCX/NVSHMEM/NCCL availability without fabricating execution.

### 9. ADIOS2 high-rate scientific streaming platform

Implemented an always-available bounded in-memory scientific step ring with generated step data, capacity eviction/drop accounting, checksums, and throughput evidence. When ADIOS2 is available, the native backend writes BP-style step data and the `roundtrip` operation reopens the stream, reads all steps, validates variable shapes/step counts, and verifies checksums.

### 10. CGNS/XDMF/Exodus mesh interchange platform

Implemented XDMF 3.0 mixed-topology output plus capability-gated native CGNS and Exodus II adapters. Supported mesh cells include line, triangle, quadrilateral, tetrahedron, and hexahedron types. Native CGNS writes base/zone, coordinates, sections/connectivity and optional vertex fields and then reopens the database for qualification. Native Exodus writes initialization metadata, coordinates, per-cell element blocks/connectivity and optional nodal variables and then reopens it for count verification.

### 11. Automotive IBIS-AMI/S-parameter platform

Implemented Touchstone S2P RI/MA/DB parsing, frequency-aligned two-port cascading through ABCD parameters, insertion/return loss and phase extraction, and engineering eye/BER calculations. A practical IBIS electrical parser consumes `[Voltage Range]`, `[Pullup]`, `[Pulldown]`, and `[Ramp]` data to estimate swing, driver output resistance and slew. AMI parameter parsing recognizes initialization/GetWave declarations and equalization parameters including FFE, CTLE and DFE behavior and feeds them into the channel/eye calculation.

### 12. Advanced refrigerant/heat-pump laboratory

Implemented R1234yf and R744/CO2 cycle calculations with refrigerant-specific pressure approximations, transcritical-capable R744 high-side operation, charge fraction, mass flow, compressor efficiency/work/discharge temperature, heating/cooling capacity, COP and frost behavior. The model supports coupled operating-condition qualification rather than static property lookup only.

### 13. Advanced NDE/metrology platform

Implemented ultrasonic pulse-echo attenuation/reflection/time-of-flight/probability-of-detection analysis, eddy-current skin-depth/response/POD analysis, thermographic diffusion/contrast/POD analysis, and digital-image-correlation affine displacement-to-strain analysis with planar/principal strain output.

### 14. Model maturity/validity registry

Implemented a persistent JSON-backed model registry supporting register/upsert/query/assess workflows. Records carry calibration/validation evidence, parameter and numerical uncertainty, validity ranges, maturity scoring/levels, provenance/evidence digests, and applicability assessment including explicit outside-applicability and extrapolation states.

### 15. Scenario-space coverage metrics platform

Implemented discretized ODD-space coverage, occupied-cell accounting, one-/two-/three-way parameter interaction coverage, boundary coverage, and optional behavior-space novelty based on nearest-neighbor distances. The output identifies coverage deficiencies quantitatively for use by scenario-generation/falsification workflows.

### 16. Probabilistic model-form uncertainty platform

Implemented Gaussian-process discrepancy modeling over physical-minus-simulation residuals using squared-exponential covariance. The platform produces discrepancy posterior mean, epistemic standard deviation, total uncertainty combining measurement/parameter/numerical terms, corrected predictions, and 95% predictive intervals.

## Documentation and examples

Added/updated:

- `README.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/FRONTIER_INTEGRATION_PLATFORM.md` compatibility note
- `docs/FRONTIER_NEXT_PLATFORM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`
- `examples/frontier_next/README.md`
- sixteen executable canonical JSON requests under `examples/frontier_next/`

The authoritative PDF user manual is 314 pages and contains Chapter 68 for Frontier Next. Pages 310-314 were rendered and visually inspected after the final edits; an initially overlong API identifier was shortened in prose and the PDF regenerated/re-inspected.

## Reliability/correctness corrections made during integration

- Corrected an RF dB/dBm conversion defect in the new wireless path: call sites no longer divide by 10 before a helper that already applies `10^(dB/10)`.
- Corrected the wireless packet-loss abstraction so pre-FEC QAM BER is reported separately while coded packet error is derived from MCS decoding margin and packet length.
- Ensured optional non-finite IBIS metrics serialize as JSON `null` instead of invalid `NaN` when IBIS input is absent.
- Hardened `dashboard_visibility_pty.py` against host-load races by synchronizing hide/show/help/status/step/run interactions on actual rendered state markers instead of fixed sleeps.
- Increased only the source-package member-count safety ceiling from 1400 to 1450 to accommodate intentional new source/docs/tests/examples; compressed-size, expanded-size, and largest-member anti-bloat limits remain unchanged.

## Native capability boundaries on the qualification host

The qualification host did not provide native PETSc, SUNDIALS, HYPRE, ADIOS2, CGNS, Exodus, MPI, CUDA or NCCL. Their adapters are real capability-gated implementations in source, but those native code paths could not be compiled/executed on this host. The simulator reports them unavailable instead of returning fake native success. GCC/Clang-driven static verification and all always-available/reference implementations were exercised.

## No-stub policy

The Frontier Next production/API source is covered by a source regression that rejects TODO/FIXME/placeholder/not-implemented/stub markers. The domains execute concrete numerical algorithms, physical calculations, parsers/serializers, persistent registries, graph exploration, source analysis, uncertainty calculations, and capability-gated native APIs rather than placeholder responses.

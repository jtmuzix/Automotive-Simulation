model ElectricalThermalRC
  parameter Real R(unit="Ohm") = 2.0;
  parameter Real C(unit="F") = 5.0;
  input Real u(unit="V") = 0.0;
  output Real v(start=0.0, unit="V");
  Real i(start=0.0, unit="A");
equation
  C * der(v) = i;
  v = u - R * i;
end ElectricalThermalRC;

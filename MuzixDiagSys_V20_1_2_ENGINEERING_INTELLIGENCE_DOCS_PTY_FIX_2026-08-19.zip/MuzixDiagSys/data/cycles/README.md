# Regulatory drive-cycle traces

- `epa_ftp75.csv`, `epa_hwyfet.csv`, and `epa_us06.csv` are converted from the one-hertz, tab-delimited chassis dynamometer schedules published by the U.S. EPA. Original speeds are mph; stored values are km/h.
- `wltc_class3a.csv` and `wltc_class3b.csv` are the one-hertz WLTC Class 3 traces corresponding to the UNECE WLTP development data and UN Regulation No. 154 phase definitions.

Columns are `time_s,speed_kmh`. Runtime validation verifies monotonic time, finite speeds, expected duration, peak speed, and distance before use.

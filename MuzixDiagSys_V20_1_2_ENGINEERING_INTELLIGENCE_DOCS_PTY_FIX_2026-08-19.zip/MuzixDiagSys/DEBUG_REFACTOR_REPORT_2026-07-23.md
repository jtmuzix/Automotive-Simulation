# MuzixDiagSys Debug and Refactor Report

**Release:** 2026-07-23  
**Baseline:** `MuzixDiagSys_indycar_frontier_2026-07-22.zip`  
**Scope:** complete codebase build/integration validation, with a deep semantic audit of the most recently added IndyCar frontier module.  
**Compatibility policy:** additive fixes only; no public class, header, target, command, test, or existing feature was removed.

## Executive summary

The codebase was configured and rebuilt with GCC 14.2 under its strict warning, hardening, position-independent-code, and strict-numerics policies. The complete default build graph—including libraries, tools, plugins, the primary simulator, and all test executables—now compiles and links successfully.

The audit found two categories of defects:

1. **Production semantic and numerical defects** in the IndyCar frontier expansion, including inconsistent hybrid power/torque reporting, unbounded long-duration electrothermal states, incorrect race-position/overtake accounting, evidence fusion that could certify the wrong vehicle pair, and resource consumption by ineligible Indianapolis 500 entrants.
2. **Build and regression architecture defects**, including a focused IndyCar test unnecessarily compiling the complete advanced platform and three PTY regressions that depended on fixed sleeps or blocking writes.

All identified defects were corrected and covered by deterministic regression tests.

## Production corrections

### Hybrid MGU, inverter, and ultracapacitor laboratory

- Recomputed delivered shaft power and torque after pack current, voltage, and transfer-power limits are applied. The result can no longer report torque that the electrical system did not supply.
- Added voltage-headroom current limiting so long deployment or regeneration segments cannot drive cell voltage beyond configured limits.
- Made self-start contingent on available current and voltage headroom.
- Corrected regenerative MGU loss accounting. Regeneration now uses recovered mechanical power multiplied by `(1 - efficiency)` rather than the motoring loss formula.
- Included total pack current, including self-start demand, in throughput-energy accounting.
- Replaced explicit thermal Euler updates with exact first-order thermal integration for MGU, inverter, and cell temperatures. This prevents unstable long-step overshoot while preserving the same reduced-order physical model.
- Initialized reported peak temperatures from the initial physical state rather than zero.

### Gearbox, clutch, bellhousing, and driveline twin

- Gear-mesh losses and fatigue now use clutch-transmitted torque rather than raw engine torque.
- An open clutch no longer loads or damages the gearbox.
- History records now report transmitted input torque consistently.
- Gearbox-oil and clutch temperatures use stable exact first-order thermal integration.
- Initial component temperatures are included in peak-temperature results.

### Hydraulic and carbon-brake laboratory

- Carbon-disc cooling now uses an exact first-order solution and cannot numerically undershoot ambient temperature during long coast/cooling intervals.
- Peak temperatures are initialized from the supplied initial state.

### Laser-scanned track, grip, and weather twin

- Surface-temperature evolution now uses stable first-order thermal integration.
- Non-finite evolved track states are rejected explicitly.
- Weather samples exactly at simulation end are now applied to final crosswind and environment results.

### Full-field racecraft and raceability engine

- Lap records are emitted after end-of-lap sorting and caution compression, so recorded positions represent completed-lap classification rather than pre-lap order.
- Overtakes are computed from pairwise order inversions.
- Position changes caused solely by a pit stop or retirement are excluded from overtake counts.
- Event reliability is converted to an exact per-lap failure probability using `1 - reliability^(1/laps)`.
- Per-lap pit, participation, retirement, fuel-save, and lap-time state is tracked explicitly.

### Synchronized incident reconstruction

- Video observations contribute position without diluting valid telemetry speed, heading, brake, or steering channels.
- Heading fusion uses a circular mean rather than an arithmetic mean across the 0/360-degree discontinuity.
- Negative synchronized camera times are rejected.
- Video-only speed and heading estimates are generated only when telemetry kinematics are absent.
- Contact evidence is vehicle-pair specific. Contact involving unrelated vehicles can no longer certify the selected incident pair.

### Pit-lane computer-vision officiating

- Raw violations are globally sorted and then coalesced by car, violation type, and time, eliminating backward intervals caused by camera-processing order.
- Coalesced events use minimum start, maximum end, and deduplicated evidence.
- Overlapping pit-box assignments in the same lane are rejected.
- Pit-loop observations for unassigned cars are rejected.
- Final violation output is chronological.

### Appeals, protests, precedent, and audit compiler

- Empty and duplicate tags are rejected for rules, precedents, and appeal filings.
- Existing filing-window, jurisdiction, evidence, precedent, and audit behavior remains intact.

### Indianapolis 500 Month-of-May twin

- Duplicate singleton sessions are rejected for first qualifying, Top 12, Fast Six, Last Chance, Pit Stop Challenge, and race sessions.
- Session chronology is enforced: qualifying must precede later qualifying phases and the race.
- Race mileage and budget are applied only to provisionally qualified, orientation-complete entrants.
- Bumped or otherwise ineligible entries no longer consume race resources.
- Event readiness requires qualified entrants to have started when a race session is scheduled.
- Pit Stop Challenge times are generated only when the run was actually completed.
- Last Chance selection uses the unlocked tail of the field.
- Top 12, Fast Six, and Last Chance sorting is restricted to the applicable subset instead of reordering the complete field.

## Build-system refactor

A dedicated static library, `aesim_indycar`, now owns all four IndyCar production modules:

- base IndyCar platform;
- operations platform;
- future competition platform;
- frontier expansion platform.

`aesim_advanced` links `aesim_indycar` publicly and transitively, so existing aggregate consumers retain the same public APIs. Focused IndyCar tests now link `aesim_indycar` directly.

This reduced the clean four-suite IndyCar validation graph from the prior complete advanced dependency surface (193 build steps for the frontier-focused request) to the core/professional/IndyCar graph (46 build steps), while the complete `aesim_advanced` aggregate still compiles and links successfully.

## Regression-harness corrections

- `completion_popup_scroll_pty.py` now waits for all expected popup-state markers instead of relying on a fixed render delay.
- `ui_golden_frames.py` synchronizes on `DASH OFF`, `PANE OFF`, or the help-overlay content marker before capturing a golden frame.
- `ui_input_fuzz_pty.py` uses nonblocking PTY mode and bounded writes so a full terminal buffer cannot deadlock the test harness.
- Source and documentation regressions now require the `aesim_indycar` target and its public transitive integration.

## Added regression coverage

The IndyCar frontier test suite now covers, among other boundary cases:

- hybrid power/torque consistency after electrical limiting;
- cell-voltage invariants during long deployment;
- regenerative loss correctness;
- open-clutch gearbox isolation;
- stable long-duration driveline, brake, and track thermal behavior;
- end-of-lap position records;
- exclusion of pit-cycle position changes from overtake counts;
- exact zero-reliability retirement behavior;
- telemetry-preserving video fusion;
- pair-specific incident contact evidence;
- monotonic pit-violation intervals;
- rejection of unknown pit-loop cars;
- rejection of duplicate appeal tags;
- preservation of bumped-entry race resources;
- rejection of race-before-qualifying chronology;
- absence of phantom Pit Stop Challenge times.

## Documentation updates

The README, comprehensive Markdown user manual, tutorial, IndyCar frontier guide, implementation record, documentation index, source-completeness regression, and documentation-consistency regression now describe the focused `aesim_indycar` architecture and its compatibility relationship with `aesim_advanced`.

## Qualification boundary

The corrected models remain engineering-grade simulation and evidence-generation systems. They do not replace manufacturer dynamometers, accredited metrology, official INDYCAR homologation, certified timing systems, steward decisions, or trackside safety authority.

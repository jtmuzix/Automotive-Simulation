# MuzixDiagSys Debug and Refactor Report — 2026-07-27

## Executive summary

This pass concentrated on the newly added fundamental-physics and runtime-
credibility subsystem because it contained independently reproducible
correctness, numerical-stability, and build-scalability defects. Existing public
class names, method signatures, aggregate headers, and advanced-platform access
were preserved.

The module was reformatted from compressed one-line implementation code into a
maintainable C++17 implementation with explicit contracts, checked arithmetic,
algorithm-specific stability controls, deterministic failure behavior, and
expanded regression coverage. The implementation was also extracted into the
focused `aesim_fundamental_physics` library. `aesim_advanced` links it publicly,
so no aggregate feature was removed.

## Correctness defects corrected

### 1. Invalid structural topology could access memory out of bounds

Element node indices were used without validation. An element referencing a
node beyond the configured node array could cause undefined behavior.
Configuration now validates every index, rejects repeated indices and
zero-length reference segments, and validates all material and node properties.

### 2. Structural iteration accounting and stability evidence were inaccurate

The former iteration count could report `max_iterations + 1`, and the minimum
tangent eigenvalue was a constant success flag rather than a stiffness measure.
Iteration accounting is now bounded and exact. The report uses the minimum
active diagonal tangent stiffness as a conservative stability indicator.

### 3. Structural solve repeated expensive topology searches

Each displacement component and nonlinear iteration repeatedly scanned every
element and rebuilt edge lists. The refactor precomputes segment reference
length, effective area, and axial stiffness once per solve. Nonlinear iterations
operate directly on this compact segment representation.

### 4. Surface chemistry accepted invalid and non-finite inputs

Zero temperature, negative time step, invalid coverage, duplicate species,
nonpositive stoichiometry, and rate overflow were not reliably rejected.
Arrhenius rates are now evaluated in logarithmic form. Coverage updates are
limited by available reactant coverage and bounded by site capacity.

### 5. Rarefied-gas updates were order dependent

Velocity and temperature were updated in place while neighboring cells from the
same time level were still being read. Results therefore depended on traversal
order and could become unstable for large time steps. The solver now uses
separate current and next buffers and automatic explicit subcycling.

### 6. Phase-field integration lacked configuration and stability contracts

Invalid spacing, mobility, energy coefficients, empty initial conditions, and
unstable explicit steps could propagate non-finite fields. The solver now
validates the complete configuration, derives Allen-Cahn and Cahn-Hilliard
stability bounds, subcycles automatically, and applies a roundoff correction to
preserve mass in conserved evolution.

### 7. Acoustic coupling boundary erased incoming pressure

The fluid interface pressure was overwritten by the structure-velocity
impedance condition before the incoming wave could load the structure. The
corrected boundary retains the adjacent incoming acoustic characteristic and
subtracts the velocity-impedance contribution. Coupled tests now verify that an
acoustic pulse produces nonzero structural displacement.

### 8. Reduced-order dimensions could overrun vectors

Ragged snapshots, mismatched forcing, and incorrectly sized full operators were
not validated. These cases could drive out-of-range access through inner
products and matrix loops. All dimensions and values are now validated before
projection or advancement.

### 9. Reduced basis and time integration were insufficiently rigorous

The former basis was an order-dependent Gram-Schmidt pass over snapshots and the
reported retained energy was not the actual POD energy fraction. The refactor
uses the method of snapshots with a symmetric Jacobi eigensolver, includes the
snapshot-mean affine drift in the reduced equations, and advances the reduced
state with fourth-order Runge-Kutta integration.

### 10. Model-validity checks could be bypassed by negative calibration distance

Calibration distance was not converted to magnitude while the other signals
were. A negative out-of-domain value could therefore appear valid. All signals
are now assessed by absolute normalized magnitude, and all thresholds must be
finite and strictly positive.

### 11. Sensor placement did not compute actual D-optimal gain

Selection previously used squared sensitivity divided by variance and cost,
without accounting for information already provided by selected sensors. It
also estimated conditioning from diagonal entries only. Selection now uses a
Cholesky solve and the matrix-determinant lemma for incremental log-determinant
gain. Conditioning uses symmetric information-matrix eigenvalues.

### 12. Causal graphs accepted duplicate, unknown, and cyclic topology

Duplicate identifiers were silently overwritten, unknown parents were ignored,
and cycles were only incidentally limited by a visited set. Graph installation
now validates identifiers, parent references, uncertainty, and acyclicity.
Localization and tie breaking are deterministic.

### 13. Thermodynamic auditing lacked robust input and accumulation checks

Port values, temperature, species fractions, and chemical-potential dimensions
were not validated. Accumulations could overflow silently. The audit now uses
extended precision, checked conversion, normalized species contracts, and a
scale-aware entropy tolerance.

## Build-system refactor

A new focused target was added:

```cmake
add_library(aesim_fundamental_physics STATIC
  src/advanced/fundamental_physics_platform.cpp
)
```

The aggregate library retains the feature through:

```cmake
target_link_libraries(aesim_advanced PUBLIC
  aesim_formula_one aesim_indycar aesim_nascar
  aesim_fundamental_physics ...)
```

`fundamental_physics_platform_tests` now links directly to the focused library.
A clean focused build requires four Ninja steps: compile the library source,
compile the test source, archive the library, and link the test executable.

## Regression coverage added

The expanded C++ suite verifies:

- thermodynamic species and temperature contracts;
- structural invalid-index rejection and bounded iteration accounting;
- surface occupancy and negative-step rejection;
- rarefied-gas stability under automatic subcycling;
- phase-field mass conservation;
- acoustic-to-structural energy transfer;
- RK4 reduced-order accuracy and dimension rejection;
- negative validity-signal handling;
- D-optimal sensor selection and identifier uniqueness; and
- causal path construction and cycle rejection.

The source regression also verifies focused-library linkage and the presence of
critical topology, dimension, stability, and numerical-linear-algebra guards.

## Files modified

- `CMakeLists.txt`
- `include/aesim/advanced/fundamental_physics_platform.hpp`
- `src/advanced/fundamental_physics_platform.cpp`
- `tests/fundamental_physics_platform_tests.cpp`
- `tests/fundamental_physics_platform_source_regression.py`
- `README.md`
- `docs/FUNDAMENTAL_PHYSICS_PLATFORM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/DOCUMENTATION_INDEX.md`

## Compatibility

No public class, method, result field, aggregate include, racing-series library,
CLI command family, or existing advanced-platform target was removed. The
focused library is additive, and `aesim_advanced` continues to expose the
fundamental-physics implementation transitively.

## Validation boundary

Focused sanitizer and optimized builds were completed. Repository-wide source,
documentation, user-manual, generated-artifact, regulatory-cycle asset, and
accelerator-linkage regressions were also completed. A full all-target build was
started in the initial audit but did not complete within the execution window;
therefore this report does not claim a newly completed full-repository binary
build.

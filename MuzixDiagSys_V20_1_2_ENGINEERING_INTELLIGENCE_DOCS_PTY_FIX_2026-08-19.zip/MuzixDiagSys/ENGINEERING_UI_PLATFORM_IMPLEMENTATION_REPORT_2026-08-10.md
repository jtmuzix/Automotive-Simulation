# Engineering UI Platform Implementation Report — 2026-08-10

## Scope

This release adds the requested twenty engineering UI capabilities without removing existing commands, backend executables, feature families, compatibility aliases, or simulator options. The implementation extends the existing `globalui` architecture and canonical authenticated shell rather than creating a second simulation-control stack.

## Production integration

Primary implementation files:

- `include/aesim/app/engineering_ui_platform.hpp`
- `src/ui/engineering_ui_platform.cpp`
- `src/ui/console_frontend.cpp`
- `src/simulation_runtime.cpp`
- `tests/engineering_ui_platform_tests.cpp`
- `tests/engineering_ui_platform_regression.py`
- `docs/ENGINEERING_UI_PLATFORM.md`

`Backend::engineering_ui_metrics()` is an additive virtual interface with a safe empty default. The production runtime overrides it with live powertrain, vehicle, solver, energy, and tire channels. Existing backend CLI parity remains implemented through the shared dispatchers introduced in V7.

## Implemented capabilities

1. **Terminal capability negotiation** — TTY/environment capability detection with terminal geometry, color, Unicode/Braille, SGR mouse, focus, bracketed paste, synchronized output, Sixel, Kitty graphics, OSC-8/52, and enhanced-keyboard reporting.
2. **SGR mouse interaction and hit testing** — parser for press/release/drag/motion/wheel/modifiers plus z-ordered rendered-region hit testing and shell interactions for focus, output selection, contextual inspection/bookmarks, pane/page scrolling, and overlay navigation.
3. **Dashboard/layout designer** — transactional create/add/remove/clone/move/resize/set operations, grid/bounds/overlap validation, and undo/redo.
4. **Global synchronized time cursor** — live follow, historical cursor, speed, play/pause, window, events, and bookmarks; shared by telemetry, trace, solver, capture, and vehicle visualization paths.
5. **Multi-signal telemetry workbench** — timestamped histories, interpolation, descriptive statistics, RMS, histogram, Hann-windowed spectrum analysis, correlation, and signal rendering.
6. **Network/protocol trace analyzer** — trace storage/filtering and protocol-aware UDS, DoIP, SOME/IP and CAN-family decode with raw visibility for CAN/CAN-FD/CAN-XL/LIN/FlexRay/Ethernet/XCP/DDS/ROS2/V2X/OPC-UA/custom records.
7. **Configuration/result diff and merge** — property-bag comparison, changed-only reporting, production three-way merge and conflict handling, explicit field acceptance, and synchronized result capture.
8. **Workflow graph editor** — graph create/read/update/delete, nodes, directed edges, start node, and rendering over `globalui::WorkflowGraph`; existing workflow execution surfaces remain intact.
9. **Solver/convergence console** — real timestep/local-error history, synchronized window reporting, and explicit `n/a` for diagnostics the active solver does not expose.
10. **Runtime CPU/GPU/MPI profiler** — Linux process RSS/I/O/CPU sampling, MPI environment detection, NVIDIA telemetry from an absolute `nvidia-smi` path, and AMDGPU sysfs telemetry.
11. **Experiment matrix UI** — parameter/objective/tag/state rows, filtering, mutation, rendering and Pareto-front computation.
12. **Artifact/evidence browser** — recursive filesystem indexing, actual SHA-256, size/mtime metadata and signature/bundle-sidecar detection.
13. **Regression triage dashboard** — robust CTest result parsing with pass/fail/timeout/skip classification.
14. **Automotive visualizations** — four-corner tire state, powertrain/system flow and live energy flow; unavailable quantities are not synthesized.
15. **Persistent attach/detach/observer sessions** — restorable simulator/UI state snapshots, owner/control and read-only observer metadata, safe identifiers, persistent registry, and owner-only POSIX session-state permissions.
16. **High-resolution rendering** — portable ASCII/Unicode plus actual Braille packing, Sixel output, and Kitty graphics protocol output with capability negotiation.
17. **Structured global search** — free text, field filtering and negation over existing command metadata, workbenches, dashboards and live signal documents.
18. **OSC-8/OSC-52 integration** — control-character-safe hyperlinks and opt-in bounded clipboard output with sensitive-value rejection.
19. **Context navigation** — breadcrumbs, independent back/forward history, peek target and pinned inspectors over the shared context graph.
20. **Browser engineering UI** — local HTTP engineering client with live state, metric cards/RPM plot, workbench launch controls, inspector and canonical command terminal; authenticated APIs use a per-process 128-bit token, constant-time comparison, restrictive CSP, bounded requests/queue, and explicit remote-bind opt-in.

## Data-integrity and security decisions

- The UI never fabricates tire pressure, solver residuals/condition numbers, GPU counters, artifact hashes, or other unavailable engineering data.
- Tire pressure is rendered only if the backend actually exposes a pressure channel.
- Artifact SHA-256 is computed from file bytes through the existing provenance implementation.
- Session IDs reject path traversal and session registry/state files are owner-only on POSIX.
- The source packager explicitly excludes persistent UI/session runtime state.
- OSC-52 is disabled by default and refuses sensitive payloads.
- OSC-8 strips/rejects terminal control characters.
- The browser defaults to loopback; non-loopback binding requires `MUZIX_WEB_ALLOW_REMOTE=1`.
- Browser APIs require the generated token, compare tokens in constant time, and do not provide unauthenticated synthetic state/command fallbacks.
- Browser UI text is assigned with DOM `textContent`, and its CSP denies unrelated network/resource origins.

## Compatibility

All V7 standalone backend/tool executables retain their direct and `backend ...` shell routes through the same reusable C++ dispatchers. The new `ui ...` namespace is additive. Existing `ui` operations predating this expansion remain present, and the expanded global completion/schema registry continues to validate.

## Qualification boundary

Persistent UI sessions preserve and restore simulator/UI state plus owner/observer metadata. They do not daemonize the simulator process; operators who require a process to survive terminal/SSH teardown should continue to run MuzixDiagSys under a service manager, scheduler, or terminal multiplexer. This distinction is deliberate and documented rather than hidden behind a simulated background process.

The browser frontend is a real authenticated client of the canonical shell dispatcher. It is intentionally thin: simulation logic remains native C++ and is not duplicated in JavaScript.

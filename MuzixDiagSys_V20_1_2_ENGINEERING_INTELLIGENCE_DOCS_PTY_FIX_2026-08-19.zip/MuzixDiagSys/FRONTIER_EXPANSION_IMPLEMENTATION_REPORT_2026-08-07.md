# Frontier Expansion Implementation Report — 2026-08-07

## Scope

This release adds the fourteen requested domains to the existing MuzixDiagSys advanced automotive simulator without removing existing simulator, command-line, motorsport, diagnostics, numerical-assurance, UI, or research functionality.

The production entry point is the existing permanent advanced-platform CLI:

```text
muzixdiagsys_advanced_platform frontier-expansion ...
```

The public C++ API is exported by:

```text
include/aesim/advanced/frontier_expansion_platform.hpp
```

The implementation is compiled into `aesim_advanced` and is covered by C++ unit, source-registration, CLI, source-package, documentation-consistency, and advanced-platform self-tests.

## Implemented domains

### 1. safe-reinforcement-learning-laboratory

Implemented deterministic constrained policy learning against the existing vector vehicle environment. The trainer performs population-based cross-entropy policy search over a linear continuous-action policy, evaluates multiple seeded episodes, tracks return and safety cost, selects elites, updates the search distribution, and applies a lane/proximity invariant runtime shield. Training produces collision/lane-departure rates, mean safety cost, policy parameters, and a SHA-256 evidence seal. Invalid training dimensions, generation/population/elite settings, non-finite policy values, and incompatible observation/action sizes are rejected.

### 2. asam-cmp-capture-platform

Implemented a deterministic CMP-oriented capture/emulation profile with module/sink/interface/type identifiers, sequence and timestamp fields, payload length, CRC32 integrity, binary encoding/decoding, duplicate/reorder/gap accounting, corruption rejection, and length-delimited capture archive save/load. The documentation intentionally distinguishes this simulator profile from third-party certification claims.

### 3. asam-traffic-participants-platform

Implemented normalized passenger-car, truck, bus, motorcycle, bicycle, pedestrian, trailer, emergency-vehicle, and other participant definitions with dimensions, mass, dynamic limits, classification properties, articulated-child relationships, schema validation, duplicate detection, canonical catalog generation, OpenSCENARIO-style catalog mapping, and OSI-style object mapping.

### 4. sysml-v2-repository-integration

Implemented a local deterministic content-addressed SysML v2-oriented repository with immutable commits, parent links, branch references, preserved element identity, upsert/erase operations, type/text queries, tree and commit SHA-256 identifiers, branch head resolution, and commit-to-commit diffs. Repository state is persisted on disk and validates branch/element/change inputs.

### 5. scientific-streaming-io-platform

Implemented an append-only scientific stream container. Canonical JSON scientific records are individually zlib-compressed, length-delimited, CRC32-protected, read back with truncation/corruption checks, and inspectable by time range and variable. The reader supports complete replay and variable filtering and reports a file SHA-256 digest.

### 6. modern-mpi-transport-runtime

Implemented runtime capability discovery, deterministic balanced rank partitioning, deterministic pairwise reduction, persistent all-reduce execution when supported, MPI Session world-size discovery when supported, and serial behavior when MPI is absent. MPI 4 features are compile-time/runtime gated rather than represented as unavailable placeholders. Existing ULFM capability detection is preserved. The current validation environment does not provide MPI, so the native MPI execution path was not compiled here.

### 7. qualified-external-solver-backends

Implemented native dense partial-pivoting LU, conjugate-gradient, and BiCGSTAB solvers, independent L2 residual verification, cross-solver consensus checks, maximum solution-disagreement checks, and SHA-256 evidence. Also implemented a real external-process backend protocol: deterministic JSON input/output files, direct POSIX process execution without shell interpolation, timeout/termination, output dimension and finiteness validation, and independent residual recomputation. Regression coverage invokes an actual temporary external Python solver through this protocol.

### 8. automotive-sensor-bus-physical-layer

Implemented SENT, PSI5, DSI3, and CXPI waveform generation/decoding with protocol-specific timing representation, checksum/parity handling, deterministic jitter/edge-loss fault injection, measured bitrate reporting, and successful round-trip qualification for all four buses.

### 9. materialx-gltf-asset-pipeline

Implemented glTF 2.0 and MaterialX 1.38 material import/export, metallic/roughness PBR data, base/emissive colors, IOR and transmission, engineering LiDAR reflectivity, radar permittivity/loss tangent properties, XML escaping/parsing, glTF extension data, and deterministic numeric round-trip comparison.

### 10. gpu-particle-multiphysics-runtime

Implemented host SPH and DEM particle stepping using cell-linked spatial hashing and deterministic neighbor construction. SPH includes Poly6 density, Spiky pressure-gradient, viscosity and gravity/integration. DEM includes contact detection, overlap spring force, damping, gravity and integration. The optional HIP backend contains out-of-place GPU kernels for SPH density/integration and DEM integration to avoid cross-thread in-place state races. Native HIP is capability-gated; the current machine does not contain a HIP compiler/device, so the host implementation is the validated execution backend here.

### 11. lubricant-chemistry-condition-monitoring

Implemented coupled lubricant condition evolution for oxidation, nitration, additive reserve, soot, water, fuel dilution, TAN, TBN, viscosity, wear metals, and varnish. Evolution responds to temperature, load, oxygen/blow-by/contamination conditions and produces a condition score plus normal/monitor/service-soon/service-now classifications and alerts.

### 12. tire-acoustic-and-uniformity-laboratory

Implemented rotational/cavity/tread characteristic frequencies and harmonics, speed-dependent acoustic level estimation, radial/lateral force variation, conicity, ply-steer, imbalance force, flat-spot effects, and a normalized uniformity score.

### 13. hazop-bowtie-barrier-assurance

Implemented HAZOP guideword generation for No/More/Less/Reverse/Early/Late deviations, bow-tie causes/consequences, prevention and mitigation barriers, availability, demand failure probability, common-cause beta effects, top-event/consequence frequency propagation, and dynamic barrier-state event-tree enumeration for bounded barrier sets.

### 14. software-supply-chain-evidence-platform

Implemented SPDX 2.3-oriented component evidence, source/artifact cryptographic hashes, vulnerability findings, VEX disposition handling, SARIF-oriented finding ingestion, CVSS release gates, denied-license policy checks, reproducible-build hash comparison, evidence-document generation, and SHA-256 evidence sealing.

## Integration

The following existing surfaces were extended additively:

- `CMakeLists.txt`: advanced-library sources, optional HIP source, MPI definitions, unit/source/CLI regressions.
- `include/aesim/advanced/platform.hpp`: exports the new public platform header.
- `tools/advanced_platform_cli.cpp`: adds the `frontier-expansion` command family and incorporates the fourteen-domain self-test into the advanced-platform self-test.
- `README.md`: top-level discovery and CLI usage.
- `docs/DOCUMENTATION_INDEX.md`: documentation and example indexing.
- `docs/FRONTIER_EXPANSION_PLATFORM.md`: detailed operational/API documentation.
- `examples/frontier_expansion/*.json`: one executable request for every requested domain.

## Additional reliability correction found during integration

A pre-existing `MixedCriticalityVecu::analyze_wcet()` regression could become non-deterministically unschedulable under heavily parallel CTest execution because the measurement loop used wall-clock elapsed time, which includes unrelated host scheduling/preemption delay. The sampler now uses process CPU time for measurement while preserving static WCET costs, declared LO/HI budgets, measured timing evidence, and response-time analysis. This removes host-load sensitivity from the measurement evidence without weakening task budgets or schedulability tests.

## No-stub policy

The new domains execute real algorithms, parsing/serialization, file round trips, process execution, integrity checks, numerical computations, physical updates, assurance calculations, and qualification logic. Optional MPI/HIP native paths are feature-detected and cleanly unavailable when their toolchains are absent; their absence is not represented by fake successful native execution.

# Formula One Multiphysics Platform Implementation Report

**Date:** 2026-07-26

## Scope

This revision adds ten production C++17 subsystems to `aesim_formula_one` while
retaining every existing Formula One and general automotive capability:

- `F1FlexibleBodyVehicleDynamics`
- `F1PersistentMultiCarWakeField`
- `F1IntegratedThermalFluidNetwork`
- `F1PhysicsOfFailureLifing`
- `F1OptimalExperimentDesigner`
- `F1AdvancedBayesianEstimator`
- `F1AdaptiveMultifidelityManager`
- `F1DifferentiableFormulaOneRuntime`
- `F1CompressiblePowerUnitGasDynamics`
- `F1RealtimeEcuHilIntegration`

## Source integration

Public API:

- `include/aesim/advanced/formula_one_multiphysics_platform.hpp`

Implementations:

- `src/advanced/formula_one_multiphysics_platform_a.cpp`
- `src/advanced/formula_one_multiphysics_platform_b.cpp`
- `src/advanced/formula_one_multiphysics_platform_c.cpp`

Regression coverage:

- `tests/formula_one_multiphysics_platform_tests.cpp`
- `tests/formula_one_multiphysics_source_regression.py`

The sources are compiled directly into `aesim_formula_one`. The aggregate
`formula_one_platform.hpp` and `platform.hpp` headers export the new API.

## Numerical methods

### Structural dynamics

The flexible-body solver uses modal superposition and the average-acceleration
Newmark method. It recovers corner deformation, aero deformation, steering
compliance, modal energies, stress, and fatigue damage.

### Wake transport

The wake model emits counter-rotating persistent elements and performs wind
advection, turbulent diffusion, exponential strength decay, moisture decay,
pruning, and spatial sampling. Following-car severity uses velocity deficit
projected onto the receiving vehicle's travel direction.

### Thermal fluids

The thermal-fluid graph solves nonlinear pressure-flow relationships iteratively,
then transports mass and enthalpy. Pumps, valves, heat exchangers, ambient loss,
pressure limits, vapor fraction, and conservation residuals are implemented. The
energy audit includes fluid heat capacity and configured solid thermal mass at
every node.

### Lifing

The lifing solver performs turning-point extraction, rainflow cycle counting,
mean-stress correction, stress-life damage, Paris crack growth, bearing damage,
thermal-cycle damage, and creep acceleration.

### Experiment design

The design engine greedily maximizes D-, A-, or E-optimal information per unit
cost. It returns Fisher information, regularized covariance, rank, and selected
experiment settings.

### Bayesian estimation

The estimator provides a scaled unscented Kalman filter and a particle filter.
Both use user-supplied nonlinear transition and observation functions. The
particle implementation includes likelihood normalization, effective sample
size, and systematic resampling. The UKF covariance correction is applied once,
explicitly symmetrized, bounded on the diagonal, and checked for positive
definiteness.

### Multifidelity management

Registered models are filtered by capability, domain, runtime, and error.
Validation observations update running error and runtime estimates. Extrapolation
inflates predicted error.

### Automatic differentiation

Second-order forward automatic differentiation propagates a full gradient and
Hessian through arithmetic and common smooth nonlinear functions.

### Power-unit gas dynamics

Intake and exhaust ducts use conservative finite-volume states and Rusanov
fluxes. The integrated model includes friction, wall heat transfer, plenums,
combustion energy, lambda, turbo machinery, wastegate, and shaft inertia.

### ECU and HIL

The real-time layer implements fixed-priority periodic scheduling, deadline
analysis, CAN serialization and latency, shared signals, optional pacing, and
fault injection.

## Defects found during implementation

Focused regression exposed an axial wake-loss sign defect. The initial
calculation used the negative magnitude of induced velocity, which could never
produce a positive deficit fraction. It was replaced with the negative axial
projection of induced velocity onto the receiving car's direction of travel.
This restores physically meaningful downforce, drag, and cooling changes.

## Compatibility

No existing source file, target, public class, command, test, or document was
removed. Existing Formula One fidelity, regulatory, industrial, race-engineering,
performance, competition, qualification, frontier, physical-operations, and
championship APIs remain compiled into the same library.

## Documentation

Updated current documentation includes:

- `README.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/FORMULA_ONE_PLATFORM.md`
- `docs/FORMULA_ONE_FIDELITY_PLATFORM.md`
- `docs/FORMULA_ONE_MULTIPHYSICS_PLATFORM.md`
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`

## Qualification boundary

These are executable research-grade reduced and intermediate-order models. They
are not a substitute for constructor geometry, material characterization,
wind-tunnel data, dyno data, telemetry, structural test data, physical HIL, or
independent validation. Numerical convergence and parameter identifiability must
be demonstrated for each intended use.

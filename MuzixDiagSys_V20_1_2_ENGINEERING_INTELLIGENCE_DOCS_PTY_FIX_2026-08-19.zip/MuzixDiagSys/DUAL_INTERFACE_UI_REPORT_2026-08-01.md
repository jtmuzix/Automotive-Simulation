# MuzixDiagSys Dual-Interface UI Implementation Report

**Date:** 2026-08-01  
**Scope:** Persistent expert command line, additive beginner menus, semantic color themes, concise shortcut navigation, and regression qualification.

## Executive summary

The simulator now provides a dual-interface terminal experience without removing, replacing, hiding, or reducing the command line. The command line remains the authoritative execution interface and stays available in the normal workspace. Beginner menus are an additive discovery layer that expose concise categories and canonical commands while continuing to use the existing parser and dispatcher.

The implementation adds a semantic theme system, persistent theme preferences, `NO_COLOR` compliance, accessible text-state fallbacks, F7/Alt-M beginner-menu shortcuts, command previews, command insertion for editing, and direct menu execution through the normal command pipeline.

No simulator subsystem, command family, script interface, batch workflow, SSH workflow, project format, dashboard, preference, undo mechanism, command history mechanism, or keyboard-driven expert workflow was removed.

## Non-negotiable command-line contract

The following invariants are implemented and documented:

1. The CLI remains a permanent, first-class interface.
2. Menus are additive and do not create a separate product mode.
3. Menu actions store ordinary canonical command strings.
4. Pressing **Enter** on a menu action routes that command through the existing command parser and dispatcher.
5. Pressing **Tab** inserts the canonical command into the persistent command editor for review or modification.
6. Menu-launched commands retain normal validation, transaction logging, state capture, command history, output formatting, and result behavior.
7. Direct typing, scripts, redirected input, SSH sessions, and automation remain supported.
8. `NO_COLOR` and accessibility modes can suppress styling without suppressing command output or textual state information.

## Beginner menu system

The menu can be opened using:

```text
F7
Alt-M
ui menu
ui menu open
```

It can be closed using:

```text
Esc
ui menu close
ui menu hide
```

The concise top-level categories are:

1. Home
2. Model
3. Scenario
4. Run
5. Monitor
6. Analyze
7. Validate
8. Help

The overlay retains the lower command pane and visibly reinforces that the CLI is preserved. Users may navigate with arrow keys or category numbers, select actions using their displayed mnemonic, execute with Enter, insert with Tab, or close with Esc.

### Command transparency

Every selected menu action displays its canonical command. This makes the menu useful as both a beginner interface and a command-learning mechanism. Read-only list and help operations are not mislabeled as state-changing. Actual simulation-run operations retain an explicit mutation/execution warning.

## Semantic theme system

The following themes are available:

- `professional-dark`
- `professional-light`
- `high-contrast`
- `colorblind-safe`
- `monochrome`
- `amber-terminal`
- `system`

Commands:

```text
ui theme list
ui theme status
ui theme set professional-dark
ui theme set professional-light
ui theme set high-contrast
ui theme set colorblind-safe
ui theme set monochrome
ui theme set amber-terminal
ui theme set system
```

Themes assign consistent semantic roles to focus, information, success, warning, failure, metadata, and disabled or secondary content. Theme changes invalidate the incremental-render cache so the entire frame is repainted consistently.

### Accessibility and terminal compatibility

- `NO_COLOR` suppresses ANSI color output regardless of the stored theme.
- Text labels and symbols remain present, so color is never the sole state indicator.
- Existing no-color, ASCII-only, high-contrast, and screen-reader accessibility modes retain precedence.
- Theme preference is persisted through the existing atomic UI preference mechanism.
- Plain terminal, PTY, SSH, and automated test workflows remain supported.

## Shortcut and discovery integration

Default profiles now bind:

```text
F7      beginner-menu
Alt-M   beginner-menu
```

Existing command palette, completion, help, editor, navigation, modified-key, and dashboard bindings remain intact. F7/Alt-M are documented in the home screen and context help rather than forcing an additional default status-bar segment that would displace higher-priority operational indicators on constrained terminals.

Optional status-bar segments named `menu` and `theme` are available for users who want them. They are intentionally not forced into the default full preset so loop, filter, focus, bookmark, and validation state retain priority.

## Shared execution architecture

The implemented execution flow is conceptually:

```text
Typed CLI command ─────────────┐
Menu Enter action ─────────────┼─> existing parser/validation/dispatcher/result pipeline
Menu Tab insertion -> editor ──┤
Command palette insertion ─────┘
```

This avoids duplicated simulator logic and ensures behavioral equivalence between beginner and expert interaction paths.

## Source changes

Primary implementation and documentation changes:

- `src/ui/console_frontend.cpp`
  - Beginner-menu state, rendering, input handling, semantic theme selection, preference persistence, command preview/insertion, and CLI command routing.
- `src/ui/ui_experience.cpp`
  - Default F7/Alt-M bindings and associated UI metadata.
- `CMakeLists.txt`
  - Registration of the beginner-menu/theme and `NO_COLOR` PTY regressions.
- `tests/ui_experience_tests.cpp`
  - Keybinding, metadata, and persistent-CLI contract coverage.
- `tests/ui_beginner_menu_theme_pty.py`
  - End-to-end menu, command insertion, dispatcher, theme, and persistence coverage.
- `tests/ui_no_color_pty.py`
  - End-to-end `NO_COLOR` override and text-state preservation coverage.
- `README.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/STREAMLINED_UI_EXPERIENCE.md`
- Updated intentional terminal golden frames under `tests/golden/`.

## Compatibility retained

The following existing behavior was specifically preserved and regression-tested:

- Persistent prompt and command editor
- Direct command execution
- Command history
- Completion and completion-detail panes
- Command palette insertion
- Help overlay
- Dashboard navigation and visibility
- Lower-pane visibility
- Resize adaptation and information density
- Scroll-anchor behavior
- Modified-key handling
- Preference persistence and malformed-preference recovery
- Input fuzz robustness
- Professional and streamlined workflows
- Golden terminal-frame baselines
- Scriptable and source-audited command grammar

## Validation summary

Final registered CTest matrix:

```text
100% tests passed, 0 tests failed out of 213
Total Test time (real) = 238.71 sec
```

Execution accounting:

- 212 tests executed and passed.
- 1 optional test was skipped: `advanced_platform_python_runtime`.
- The skip is caused by the optional `gymnasium` Python dependency and is not a simulator or UI failure.

Additional checks passed:

- Complete production and test-artifact build
- No pending Ninja build work
- Documentation consistency regression
- User-manual command and glossary regression
- Source-package regression
- Generated-artifact cleanup regression
- Git whitespace/error check
- ZIP integrity validation
- Deterministic source-package reproduction

## Result

MuzixDiagSys now supports beginners through concise, themed menus while retaining the full command line as the permanent expert interface and common execution foundation. The implementation improves discoverability without sacrificing precision, scriptability, terminal compatibility, or established engineering workflows.

## Deliverable integrity

The final deterministic source archive contains 1,276 files. It excludes build trees, object files, caches, generated runtime history, exported simulation artifacts, and other reproducible output. The archive was generated twice from the same qualified source tree and the two outputs compared byte-for-byte. ZIP decompression integrity testing reported no errors.

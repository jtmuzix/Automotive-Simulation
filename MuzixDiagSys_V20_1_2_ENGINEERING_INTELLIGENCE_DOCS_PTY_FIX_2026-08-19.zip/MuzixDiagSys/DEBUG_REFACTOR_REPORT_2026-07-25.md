# MuzixDiagSys Debug and Refactor Report — 2026-07-25

## Executive summary

This pass focused on the Formula One industrial and ecosystem subsystem in the uploaded advanced automotive simulator. Public APIs, domain names, evidence schemas, examples, CMake targets, and the ten existing Formula One industrial domains were preserved.

The principal correctness defect was an order-dependent greedy driver-seat allocator. It has been replaced by deterministic minimum-cost maximum-flow matching that maximizes assignment cardinality first and total engineering score second. Additional changes validate tyre and sustainable-fuel limit windows before evaluation and harden causal-regression and aerodynamic calculations against non-finite intermediate values.

## Defects corrected

### 1. Driver-seat assignment was request-order-dependent

The former implementation processed seats sequentially. A flexible reserve or simulator seat could take the only rookie-qualified driver before an `fp1-rookie` seat was processed. The later seat then failed even when another driver could have filled the flexible seat.

The replacement constructs a bipartite residual network:

- one capacity-one node per seat;
- one capacity-one node per candidate;
- eligibility edges only when medical, budget, rookie, and Super-Licence constraints are satisfied;
- edge cost equal to the negative assignment score;
- successive shortest augmenting paths to obtain minimum-cost maximum flow.

This gives the maximum number of valid assignments and, among those assignments, the maximum total score. Stable graph construction and strict distance improvement preserve deterministic behavior. Reports now include:

```json
"assignment_strategy": "maximum-cardinality-maximum-score"
```

### 2. Tyre release limits were repeatedly read but not validated as a coherent set

Metrology thresholds were previously fetched inside every batch predicate. Negative maxima or an inverted cure-temperature window silently converted an invalid request into universal batch quarantine.

The limits are now read once and validated before batch processing:

- dimensional, force-variation, and mass-error maxima are nonnegative;
- minimum cure temperature is positive;
- maximum cure temperature is not below the minimum;
- material traceability is within `[0, 1]`.

This is both a correctness and maintainability improvement: the batch loop now operates on an immutable validated configuration.

### 3. Sustainable-fuel release windows could be inverted

Density and lower-heating-value minima/maxima are now validated as ordered positive intervals. Minimum octane and lifecycle-carbon limits are also bounded before any release decision is made.

### 4. Causal-regression arithmetic could overflow

Although request values were individually finite, products and accumulations in the normal equations could overflow. Gaussian elimination, prediction, residual variance, constraint penalties, and final decision scores could then propagate infinity or NaN.

Finite-result guards now cover:

- normal-matrix and right-hand-side accumulation;
- ridge-diagonal updates;
- pivot normalization and elimination;
- prediction and residual accumulation;
- residual sigma and sample means;
- engineering-constraint penalties;
- final setup decision scores.

### 5. Aerodynamic scoring could produce non-finite evidence

Very large but finite aerodynamic coefficients could overflow efficiency or package score calculations. Weighted pass-probability, field-convergence, efficiency, and final design-score calculations now require finite results.

## Regression coverage added

The focused compiled suite now verifies:

- inverted tyre cure-temperature windows are rejected;
- inverted sustainable-fuel density windows are rejected;
- extreme causal-regression input is rejected before non-finite evidence is generated;
- extreme aerodynamic scoring input is rejected;
- a flexible seat cannot starve an FP1 rookie seat;
- the same optimal driver-seat mapping is produced when seat input order is reversed;
- the report identifies the global assignment strategy.

## Files modified

- `src/advanced/formula_one_industrial_ecosystem_platform_a.cpp`
- `src/advanced/formula_one_industrial_ecosystem_platform_b.cpp`
- `src/advanced/formula_one_industrial_ecosystem_platform_c.cpp`
- `tests/formula_one_industrial_ecosystem_platform_tests.cpp`
- `README.md`
- `docs/FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_PLATFORM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/DOCUMENTATION_INDEX.md`

## Compatibility

No source file, class, public method, CLI domain, CMake target, example, or racing-series implementation was removed. Existing report keys remain available; the only additive report field is `assignment_strategy` in the driver-development report.

## Validation boundary

The focused Formula One industrial target was built and tested with GCC 14.2 and Clang 17.0. GCC AddressSanitizer and UndefinedBehaviorSanitizer execution passed. The complete all-target build was attempted, but the repository's remaining 355-step build graph did not complete within the execution window; the first 63 steps produced no compiler warnings or errors. Therefore this report does not claim a newly completed full-repository build.

# MuzixDiagSys Must-Have Platform Implementation Report

Date: 2026-07-16

## Scope

This change adds six production-oriented reference engines without deleting or replacing existing behavior:

1. Full-wave electromagnetic, antenna, and EMC laboratory.
2. Native CPU/CUDA/multi-GPU/HPC execution.
3. Exact analytic CAD/CSG, volumetric meshing, and unstructured multiphysics.
4. Production-grade heterogeneous virtual ECU 2.0.
5. Advanced tire-road-terrain and adverse-weather physics.
6. Learned-component robustness and neural safety verification.

## Added files

- `include/aesim/advanced/must_have_platform.hpp`
- `src/advanced/must_have_platform.cpp`
- `tests/must_have_platform_tests.cpp`
- `docs/MUST_HAVE_PLATFORM.md`
- `MUST_HAVE_PLATFORM_IMPLEMENTATION_REPORT_2026-07-16.md`

## Modified files

- `CMakeLists.txt`
- `README.md`
- `include/aesim/advanced/platform.hpp`

## Electromagnetic implementation

The full-wave solver advances three-dimensional electric and magnetic fields using finite differences of Maxwell curl equations. The implementation includes material-dependent epsilon, mu, conductivity, graded absorbing layers, Courant-limit enforcement, pulsed and CW sources, field probes, DFT phasors, and energy accounting.

The antenna solver constructs a complex thin-wire EFIE/MoM system, solves segment currents with pivoted complex Gaussian elimination, calculates input impedance and loss, and integrates a normalized far-field pattern. EMC field-to-cable coupling includes orientation, line length, shield transfer impedance, termination, and power.

## HPC implementation

The native executor provides deterministic multithreaded CPU AXPY, fixed-order compensated reductions, and exception-propagating parallel loops. On compatible Linux systems it dynamically loads the CUDA Driver API without requiring CUDA headers or a CUDA build toolchain. It discovers devices and launches embedded PTX directly. Work is partitioned concurrently across all selected CUDA devices.

The CPU path is a complete execution backend, not a no-op fallback. CUDA results are checked against the scalar equation before a report is marked deterministic.

## CAD and multiphysics implementation

The CAD kernel provides analytic signed-distance definitions for boxes, spheres, and cylinders, plus exact Boolean membership for union, intersection, and difference. The mesher generates conforming tetrahedra, removes unused background nodes, extracts boundary faces, and computes volume and quality.

Thermal FEA assembles tetrahedral conductivity matrices and solves prescribed-temperature/source problems. Structural FEA assembles a full 3D isotropic stiffness matrix, applies nodal loads, supports, and thermal strain, then recovers displacement and von Mises stress.

A defect discovered during testing was corrected: CSG subtraction left unused lattice nodes in the initial mesh, causing zero matrix rows and a singular thermal system. The final mesher compacts and remaps only referenced nodes.

## Virtual ECU 2.0 implementation

The new virtual ECU executes existing RV32IM machine code across multiple cores and adds coherent shared memory, MMU permission mappings, cache telemetry, ELF32 RISC-V loading, DMA, CAN/CAN-FD, Ethernet, round-robin scheduling, and lockstep comparison.

Lockstep comparison is performed only after peer cores have executed equal instruction counts, avoiding false divergence during sequential host scheduling.

## Tire and terrain implementation

The tire model integrates a damped flexible ring, road-profile excitation, transient longitudinal and lateral slip, pressure-sensitive contact, combined-friction saturation, pneumatic trail, thermal behavior, wear, inflation leakage, hydroplaning, snow and ice reductions, and deformable-terrain pressure/sinkage and shear.

## Neural safety implementation

The neural subsystem validates layer dimensions and numeric finiteness, evaluates dense networks, differentiates outputs with reverse accumulation, propagates intervals, performs branch-and-bound robustness certification, finds adversarial inputs, calibrates conformal intervals, and computes closed-loop interval reachability. Affine controllers are algebraically composed with the plant to avoid dependency blow-up.

## Compatibility

All new functionality is additive. Existing command-line tools, libraries, tests, schemas, simulator behavior, FMI/SSP support, plugins, and public APIs remain present.

## Validation

- Complete CMake Debug configuration: passed.
- Complete project build and link: passed.
- Dedicated `must_have_platform_unit_tests`: passed.
- Adjacent advanced-platform unit tests: passed.
- Broad registered CTest inventory: no observed assertion failures.
- Optional Python runtime test: skipped by its existing design.
- Several pre-existing Debug workflow tests exceeded the execution window and are identified in the final validation record rather than represented as passes or failures.

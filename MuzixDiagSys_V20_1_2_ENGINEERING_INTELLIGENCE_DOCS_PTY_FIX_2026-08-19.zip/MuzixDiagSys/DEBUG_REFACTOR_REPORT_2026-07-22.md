# MuzixDiagSys Debug and Refactor Report

**Project:** MuzixDiagSys advanced automotive and motorsport simulator  
**Input archive:** `MuzixDiagSys_nascar_frontier_expansion_fully_implemented_2026-07-21(1).zip`  
**Refactor date:** 2026-07-22  
**Scope:** Defect correction, validation hardening, build-graph refactoring, regression expansion, and deterministic UI-test repair.  
**Feature-preservation policy:** Existing simulator features and public command surfaces were retained.

## 1. Executive result

The source tree was configured and compiled with the project's strict warning and hardening configuration. The primary `muzixdiagsys` executable, the optional `aesim_advanced` aggregate, all tools, plugins, and test targets compiled and linked successfully.

The final 157-test matrix is fully accounted for:

- **156 tests passed**.
- **1 test was intentionally skipped** because the optional Python package `gymnasium` is not installed.
- **0 unresolved test failures remain**.
- The three focused NASCAR suites also passed under AddressSanitizer and UndefinedBehaviorSanitizer.

The work corrected substantive state-model and validation defects in the newest NASCAR frontier platform, reduced unnecessary build coupling for NASCAR tests, and removed a race condition from the terminal golden-frame regression harness.

## 2. Principal defects corrected

### 2.1 In-season tournament projections ignored completed rounds

**Previous behavior:** Championship Monte Carlo projections restarted from the original entrant list after completed tournament rounds. Drivers already eliminated could retain nonzero championship probability, and probabilities were not conditioned on the live bracket.

**Correction:** Future simulations now begin from the current surviving bracket. Completed race results are validated and applied before projection. Eliminated drivers receive zero conditional probability, surviving probabilities normalize correctly, and additional rounds are rejected after a champion has been determined.

**Additional hardening:**

- Driver count must be a power of two.
- Driver identifiers must be nonempty and unique.
- Seeds must be positive integral values and unique.
- Ratings, finishes, penalties, performance sigma, and simulation inputs must be finite and within valid ranges.
- Race identifiers must be nonempty and unique.

### 2.2 Rule bulletins bypassed rule validation

**Previous behavior:** Bulletin-based rule replacement could install malformed rules without passing through the validation used for initial rule definitions. Invalid penalty ranges and malformed conditions could therefore enter the compiled rulebook.

**Correction:** All added or replaced bulletin rules are normalized and validated before they can alter the rule map. Duplicate bulletin identifiers, adding an existing rule, replacing a missing rule, invalid conditions, and inverted penalty ranges are rejected.

### 2.3 Conflicting penalty ranges produced arbitrary recommendations

**Previous behavior:** When multiple violated rules had disjoint penalty ranges, the implementation could clamp into an invalid interval and return an arbitrary recommended penalty.

**Correction:** Empty intersections now generate a `RULE-PENALTY-CONFLICT` error finding, set `recommended_penalty` to `null`, and fail the adjudication result. Appeal inputs and precedent records receive stronger finite/range/reference validation.

### 2.4 Fuel starvation counted unavailable fuel as consumed

**Previous behavior:** Requested fuel demand was added to total consumption even when the collector could not deliver that volume. This violated mass conservation and overstated fuel consumption during pickup starvation.

**Correction:** Consumption now accumulates delivered fuel only. Starvation time is calculated fractionally from unmet demand, collector transfer and cell inventory remain bounded, refueling is validated, and projection inputs are checked for finite and physically valid values.

### 2.5 Failed shop tasks consumed resources and unblocked dependents

**Previous behavior:** Tasks that failed because of missing parts or unavailable resources could still consume capacity and be recorded as completed. Their dependent tasks could then execute incorrectly. Input order could also influence scheduling when dependencies appeared later in the task list.

**Correction:**

- Tasks are parsed first and scheduled through dependency-aware topological progress.
- Unknown dependencies, failed prerequisites, and dependency cycles are distinguished.
- A failed task does not consume parts or resource capacity.
- A failed task does not satisfy downstream dependencies.
- Out-of-order task definitions schedule correctly.
- Inventory, resource, cargo, route, capacity, probability, delay, and simulation inputs are validated.
- Stochastic readiness is bounded by deterministic task/event readiness.
- Lognormal transport delay now uses a mean-corrected parameterization.

### 2.6 Golden-frame UI test raced terminal rendering

**Previous behavior:** `tests/ui_golden_frames.py` used a fixed sleep after sending F1. Under concurrent CTest load, it occasionally captured the command prompt before the help overlay completed, causing a false golden mismatch.

**Correction:** The help-overlay case now synchronizes on stable content near the bottom of the rendered modal (`Commands: ui help topics`) and then drains the PTY briefly. This converts timing-based synchronization into observable-state synchronization. The repaired test passes independently and in failed-test reruns.

## 3. Build-system refactor

### 3.1 Dedicated NASCAR library

A new `aesim_nascar` static library contains:

- `nascar_competition_platform.cpp`
- `nascar_ecosystem_platform.cpp`
- `nascar_frontier_platform.cpp`

`aesim_advanced` links this library publicly, so downstream consumers retain the existing transitive capability. The three NASCAR test targets link directly to `aesim_nascar` instead of pulling the complete industrial and advanced aggregate into focused unit-test builds.

**Result:** The isolated NASCAR validation graph builds in 38 Ninja steps while preserving full compatibility with the complete advanced platform.

### 3.2 Documented test-option compatibility

The documented historical `AESIM_BUILD_TESTS` switch previously did not control CTest's canonical `BUILD_TESTING` option. CMake now mirrors an explicitly supplied `AESIM_BUILD_TESTS` value before `include(CTest)`, preserving existing documentation and automation while retaining standard CTest behavior.

## 4. Regression coverage added

`tests/nascar_frontier_platform_tests.cpp` now verifies:

1. Domain enumeration and self-test health.
2. Conditional tournament probabilities after a completed round.
3. Zero probability for eliminated drivers.
4. Probability normalization across surviving drivers.
5. Rejection of negative performance sigma.
6. Rejection of invalid appeals.
7. Failure and null recommendation for disjoint penalty ranges.
8. Rejection of malformed bulletin replacements.
9. Correct fuel accounting during pickup starvation.
10. Technical anti-cheating rejection behavior.
11. Correct scheduling of out-of-order dependencies.
12. Blocking of dependents after prerequisite failure.
13. Preservation of shared resources when an earlier task fails.

## 5. Validation performed

### 5.1 Strict source syntax

The refactored NASCAR frontier implementation passed a standalone GCC syntax and warning check using:

```bash
g++ -std=c++17 -Iinclude -Wall -Wextra -Wpedantic -Wshadow \
    -Wformat=2 -fsyntax-only src/advanced/nascar_frontier_platform.cpp
```

No warnings or errors were emitted.

### 5.2 Focused normal build and tests

The dedicated NASCAR target and its three suites compiled successfully. All three passed:

- `nascar_competition_platform_unit_tests`
- `nascar_ecosystem_platform_unit_tests`
- `nascar_frontier_platform_unit_tests`

### 5.3 Sanitizer validation

The same three suites passed in an AddressSanitizer/UndefinedBehaviorSanitizer build. No sanitizer diagnostics were reported.

### 5.4 Complete build

The following completed successfully:

- Primary hardened PIE executable: `muzixdiagsys`
- Optional aggregate: `aesim_advanced`
- Full default Ninja target graph
- Command-reference/help smoke execution

### 5.5 Complete test accounting

The comprehensive CTest execution covered all 157 registered tests. A heavy EPA/WLTP tracking regression legitimately required 286.62 seconds and passed. One UI golden test initially exposed the synchronization race described above; after correction, `ctest --rerun-failed` passed it.

Final accounting:

| Result | Count |
|---|---:|
| Passed | 156 |
| Skipped | 1 |
| Unresolved failures | 0 |
| Total | 157 |

The skipped test was `advanced_platform_python_runtime`; it reports:

```text
SKIP: optional Python runtime dependency unavailable: No module named 'gymnasium'
```

This is an optional-environment skip, not a simulator defect.

## 6. Toolchain used

- C++ compiler: GCC 14.2.0
- CMake: 3.31.6
- Ninja: 1.12.1
- Python: 3.13.5
- Build type: Debug
- Test configuration: `BUILD_TESTING=ON`
- Generator: Ninja

The validated executable SHA-256 was:

```text
b42d10aad3ba85a0b43ba39598b5c76eb9afa44f808e3687fcc183f6d9f96338
```

## 7. Files intentionally modified

- `CMakeLists.txt`
- `src/advanced/nascar_frontier_platform.cpp`
- `tests/nascar_frontier_platform_tests.cpp`
- `tests/ui_golden_frames.py`
- `DEBUG_REFACTOR_REPORT_2026-07-22.md`
- `DEBUG_REFACTOR_VALIDATION_2026-07-22.txt`

No simulator feature source was removed. Build trees, object files, caches, runtime histories, generated study artifacts, and test output are excluded from the delivered source archive.

## 8. Recommended build sequence

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DAESIM_BUILD_TESTS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

For focused NASCAR sanitizer validation:

```bash
cmake -S . -B build-nascar-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DAESIM_BUILD_TESTS=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined' \
  -DCMAKE_SHARED_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-nascar-sanitize --parallel --target \
  nascar_competition_platform_tests \
  nascar_ecosystem_platform_tests \
  nascar_frontier_platform_tests
ctest --test-dir build-nascar-sanitize -R nascar --output-on-failure
```

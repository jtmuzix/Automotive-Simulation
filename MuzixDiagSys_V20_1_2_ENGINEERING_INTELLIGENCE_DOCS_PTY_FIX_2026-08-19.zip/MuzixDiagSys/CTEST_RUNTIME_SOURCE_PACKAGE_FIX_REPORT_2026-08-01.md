# CTest Python Runtime and Source-Package Corrective Refactor

Date: 2026-08-01

## Scope

This maintenance pass corrects two CTest outcomes without removing simulator,
command-line, menu, Python, packaging, or automation functionality:

- `advanced_platform_python_runtime` previously returned CTest skip code 77
  whenever one optional third-party adapter dependency was unavailable.
- `source_package_regression` rejected the valid deterministic source archive
  because a stale 6,500,000-byte compressed-size threshold was 363 bytes below
  the current archive size.

## Runtime-test correction

`tests/advanced_python_runtime_tests.py` now always qualifies the dependency-free
C++ reinforcement-learning JSON backend. The mandatory checks cover:

- deterministic seeded reset;
- vector dimensions and schema;
- finite observation fields;
- snapshot production;
- deterministic snapshot replay; and
- step result cardinality.

Gymnasium/PettingZoo and Arrow/Parquet adapter checks remain additive. They run
when their declared optional dependencies are installed. Missing optional
packages are reported as unavailable coverage rather than causing the entire
backend runtime test to be skipped.

Dependency-complete CI can enforce all optional adapter checks with:

```bash
cmake -S . -B build -G Ninja \
  -DBUILD_TESTING=ON \
  -DMUZIXDIAGSYS_REQUIRE_OPTIONAL_PYTHON_RUNTIME=ON
```

The default remains portable and dependency-light. Strict mode converts missing
optional adapter coverage into a test failure rather than silently weakening a
release gate.

## Source-package correction

The package regression now uses four named, independent budgets:

- compressed archive bytes;
- archive member count;
- expanded source bytes; and
- largest individual member bytes.

Generated-directory, forbidden-file, executable-mode, deterministic-output,
path-traversal, in-tree-output, and symbolic-link protections remain in force.
The revised limits retain bounded headroom for legitimate source, tests, and
operator documentation while still rejecting build trees and generated studies.

## Compatibility

No CLI command, beginner menu, key binding, theme, Python API, build target,
packaging command, or simulation feature was removed. The source packager
continues to produce deterministic POSIX-mode-preserving ZIP archives.

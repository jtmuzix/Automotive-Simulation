# MuzixDiagSys Accuracy and Simulation-Depth Implementation Report

**Date:** July 12, 2026  
**Baseline:** `advanced_engine_sim_brake_clutch_yaml_fixed_2026-07-12`  
**Result:** Full additive implementation with existing GUI/TUI, commands, presets, plugins, and subsystem functionality retained.

## Executive summary

The simulator now contains a cohesive accuracy and validation layer rather than isolated reporting utilities. The work adds physical conservation accounting, measurement ingestion, robust calibration, residual diagnostics, correlated uncertainty, cryptographic provenance, deterministic replay, automatic differentiation, stiff implicit DAE solving, event localization, rollback, iterative multi-rate coupling, high-voltage parasitic/EMI physics, risk-weighted fault campaigns, environmentally degraded sensors, and a dynamic transmission electrohydraulic control plant.

The implementation added more than 3,700 lines in the new accuracy header, implementation, and dedicated tests alone, plus integration changes across the runtime, high-fidelity vehicle, industrial, professional, and transmission modules. The modified implementation files contain explanatory comments around sign conventions, numerical acceptance, rollback, environmental mechanisms, resource/state ownership, compatibility behavior, and physical assumptions.

No requested feature is represented by a stub, placeholder, unimplemented branch, or TODO marker in the modified implementation set.

## Implemented requirements

### 1. Conservation auditing

Added `ConservationAuditor` with energy, mass, charge, linear momentum, and angular momentum ledgers. It supports multiple domains, signed external rates, conservative inter-domain transfers, normalized residuals, tolerance policies, history, reports, and CSV export.

Runtime integration audits engine thermofluid storage and vehicle longitudinal energy/momentum on every accepted plant step. `health conservation` exposes the result. Full-state restore now re-anchors conservation history, correcting a rollback/replay defect discovered during qualification.

### 2. Test-data ingestion

Added delimiter detection, quoted-field parsing, semantic channel roles, unit parsing and SI conversion, validity masks, missing-value handling, timestamp sorting, duplicate merging, resampling, multi-source synchronization, and source SHA-256. Role-qualified keys preserve observed and uncertainty channels with the same metric name.

### 3. Automated calibration

The telemetry fitting workflow now uses deterministic multi-start optimization, robust reweighting, bounded parameters, cross-validation, candidate ranking, and identifiability diagnostics. Live simulator parameters are restored if any candidate or export fails.

### 4. Residual analysis

Added channel-level bias, MAE, RMSE, normalized RMSE, residual standard deviation, maximum error, R², Durbin-Watson, lag-one autocorrelation, Ljung-Box Q, drift, phase lag, spectral RMSE, low-frequency power fraction, and segmented statistics. CSV and JSON exports are supported.

### 5. Uncertainty propagation

Added deterministic Latin-hypercube sampling with Gaussian-copula correlation, bounded distributions, output intervals, covariance/sensitivity information, and threshold-failure probability. The runtime command accepts an explicit seed and restores the nominal state after each run.

### 6. Configuration and result provenance

Added `aesim.provenance.v3` and upgraded runtime experiment packages to `aesim.experiment.v3`. New records authenticate metadata, environment, tags, executable identity, individual configuration/result files, the configuration set, and the canonical record. Runtime experiment checksums include the manifest and canonical configuration. Legacy formats remain verifiable.

### 7. Deterministic replay

Replay v3 now verifies state hashes, random-stream hashes, command-output hashes, ordered chain hashes, timestamps, and the embedded initial checkpoint. It reports the first mismatch sequence. Replay v2 remains readable.

### 8. Multi-rate integration

Added an iterative multi-rate coordinator with per-domain periods, deterministic substeps, snapshots, relaxation, convergence criteria, timing data, residual history, power-balance mismatch, and rollback. The existing integer-tick research scheduler remains intact and synchronized with the public solver periods.

### 9. Implicit DAE solvers

Implemented backward Euler, BDF2, and implicit midpoint for residual equations `F(t,y,ydot)=0`. The solver includes Newton iteration, line search, pivoted linear solves, adaptive full-versus-half-step estimation, finite bounds, rejection accounting, and non-finite-state protection.

### 10. Event localization

Implemented direction-aware zero-crossing detection, in-step localization, event tolerance, named event records, and state-modifying event handlers.

### 11. Automatic Jacobians

Implemented dynamic forward-mode dual numbers and complete Jacobian extraction. The DAE solver uses automatic Jacobians when supplied and retains finite-difference fallback for ordinary residuals and independent comparison.

### 12. Solver rollback

DAE trials and multi-rate macro steps use explicit snapshots. Failed Newton iterations, error rejections, non-finite states, and coupling non-convergence restore the last accepted state. Checkpoint and branch restore also reset path-dependent conservation history.

### 13. Cross-domain coupling diagnostics

Each multi-rate macro step reports convergence, iterations, maximum coupling residual, residual history, per-domain substeps and execution time, rollback state, and net power mismatch.

### 14. High-voltage parasitics and EMI/EMC

Implemented a source/cable/DC-link RLC network with implicit modified-nodal integration, capacitor ESR/ESL, switching-edge displacement current, common-mode current, environmental insulation leakage, motor-bearing current, harmonic conducted emissions, radiated-field estimation, shielding, regulatory-style limits, stored energy, and residual accounting. The results are integrated into the vehicle-depth status, replay, fidelity, and energy diagnostics.

### 15. Fault injection and diagnostic coverage

Extended the fault campaign with duration-correct clearing, no-fault controls, expected/unexpected DTC analysis, detection latency, safe-state checks, confusion-matrix counts, severity/exposure/controllability/occurrence risk, residual risk, weighted coverage, group coverage, and CSV/JSON/Markdown/template output.

### 16. Sensor imperfection and environmental degradation

Added temperature, humidity, pressure, vibration, contamination, radiation, aging, supply, EMI, cross-axis, hysteresis, dropout, self-heating, and maintenance/calibration effects. The integrated vehicle runtime now supplies these environmental inputs. Named configuration assignment corrected a potential field-shift defect caused by aggregate initialization after adding new sensor coefficients.

### 17. Detailed transmission hydraulic-control model

Replaced simplified pressure scaling with a dynamic electrohydraulic plant: pump, line compliance, viscosity, regulator, leakage, RL solenoids, spools, orifices, clutch cavity fill, accumulators, piston travel, clamp force, wet-clutch capacity, thermal fade, wear, lockup, shift phases, hydraulic power, and energy residual. Existing transmission status markers remain compatible.

## Principal files

### New files

- `include/aesim/core/accuracy.hpp`
- `src/core/accuracy.cpp`
- `tests/accuracy_depth_complete_tests.cpp`
- `tests/accuracy_depth_cli_regression.py`
- `docs/ACCURACY_DEPTH_FRAMEWORK.md`
- `ACCURACY_DEPTH_IMPLEMENTATION_REPORT_2026-07-12.md`

### Major modified files

- `src/muzixdiagsys.cpp`
- `src/core/provenance.cpp`
- `include/aesim/professional/checkpoint.hpp`
- `src/professional/checkpoint.cpp`
- `include/aesim/industrial/fault_campaign.hpp`
- `src/industrial/fault_campaign.cpp`
- `include/aesim/high_fidelity/vehicle_systems.hpp`
- `src/vehicle/high_fidelity_controls.cpp`
- `include/aesim/high_fidelity/integrated_vehicle.hpp`
- `src/vehicle/high_fidelity_integrated.cpp`
- `include/aesim/high_fidelity/vehicle_depth.hpp`
- `src/vehicle/depth_electrical_aero_brake.cpp`
- `include/aesim/high_fidelity/integrated_depth.hpp`
- `src/vehicle/depth_integrated.cpp`
- `include/aesim/high_fidelity/ecosystem.hpp`
- `src/vehicle/ecosystem_thermofluid_powertrain.cpp`
- `CMakeLists.txt`

## Compatibility defects found and corrected during qualification

1. **Observed/sigma ingestion collision:** `observed.speed` and `sigma.speed` previously normalized to the same map key. Storage is now role-qualified.
2. **Sensor aggregate-initialization drift:** inserting environmental coefficients could shift old positional fields, including deterministic seeds. Configurations now use named assignments.
3. **Checkpoint conservation timeline:** branch/replay restoration could move time backward while retaining later conservation history. Restoration now re-anchors the ledger.
4. **Fault-report marker:** the enhanced fault-campaign title initially changed an established output marker. The original marker is retained with an explanatory subtitle.
5. **Transmission-report marker:** the detailed hydraulic report initially changed an established transmission title. The original title is retained with an explanatory subtitle.

## Validation

### Build

- Complete GNU Debug build: **PASS**, including all libraries, plugins, tools, simulator executable, and compiled test targets.
- GNU Release libraries: compiled successfully through `aesim_core`, `aesim_professional`, and `aesim_industrial` with the modified files.
- The final monolithic `muzixdiagsys.cpp` Release object did not finish inside the repeated command-execution windows. No compiler diagnostic was produced for that source; the complete Debug executable and Release libraries compile successfully. This is recorded as an incomplete Release-link qualification, not as a passing Release executable build.

### Registered tests

Forty-eight distinct registered tests were verified as passing during this implementation session. They include all 19 compiled unit/core tests, baseline CLI/build/linkage checks, the new accuracy-depth unit and CLI regressions, completion and golden-frame tests, vehicle/brake/clutch/catalog tests, professional replay/checkpoint tests, industrial fault-campaign tests, electrification/transmission tests, assurance, federation, research, command-surface, terminal-formatting, plugin, and non-finite-input regressions.

The final isolated qualification set passed:

- `accuracy_depth_complete_unit_tests`
- `high_fidelity_vehicle_unit_tests`
- `vehicle_depth_unit_tests`
- `ecosystem_unit_tests`
- `research_core_unit_tests`
- `professional_core_unit_tests`
- `industrial_core_unit_tests`
- `professional_platform_v2_regression`
- `industrial_platform_regression`
- `electrification_platform_regression`
- `accuracy_depth_cli_regression`
- `all_commands_completion_regression`
- `ui_golden_frames`
- `driver_control_and_catalog_regression`
- `terminal_formatting_regression`
- `nonfinite_input_regression`

The aggregate CTest controller intermittently stalls after one subprocess-heavy test completes. The same registered tests pass in fresh isolated CTest processes. This is a test-orchestration/container behavior; the implementation does not classify aggregate runs that stalled as passing.

## User-visible commands added or enhanced

```text
health conservation [status|report]
health conservation reset
health conservation export <csv>

telemetry import <csv>
telemetry compare
telemetry export-residuals <csv|json>

uncertainty correlated <samples> <csv|json> [seed]

experiment begin <name> <directory> [seed]
experiment event <message>
experiment end
experiment verify <run-directory>

replay start|stop|save|run|verify|hash
```

## GUI and functionality preservation

The terminal GUI layout was not redesigned or removed. Golden-frame validation passes. Existing commands, completion, presets, reports, plugins, FMI, industrial, professional, electrification, assurance, federation, and research functionality remain available. The changes are additive or replace internal simplified calculations behind existing interfaces.

# Motorsport CLI Expansion Implementation Report - 2026-08-08

## Scope

This release adds an additive convenience command layer for Formula One, NASCAR, and IndyCar to the existing `muzixdiagsys_advanced_platform` executable. No existing motorsport command family, domain implementation, C++ API, test family, or simulator feature was intentionally removed or disabled.

## New aggregate routers

### Formula One

- `f1 capabilities|list`
- `f1 self-test DIRECTORY [output.json]`
- `f1 run operations|regulatory|industrial DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]`

The router exposes the existing 30 public Formula One JSON domains across championship operations, regulatory/competition, and industrial/ecosystem platforms.

### IndyCar

- `indycar capabilities|list`
- `indycar self-test DIRECTORY [output.json]`
- `indycar run development|integrated|assurance DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]`
- `indy` is accepted as a synonym for `indycar`.

The router exposes 34 existing domains: 10 development/operations, 10 integrated-fidelity, and 14 engineering-assurance domains.

### NASCAR

The existing `nascar capabilities`, `nascar self-test`, and 40-domain direct dispatcher are preserved. Additions are:

- `nascar all-capabilities|list-all`
- `nascar all-self-test DIRECTORY [output.json]`
- `nascar run competition|integrated|assurance DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]`

The combined registry exposes 64 domains: 40 competition/ecosystem/frontier/next-generation, 12 integrated-fidelity, and 12 engineering-assurance domains.

## New direct shortcuts

Formula One:

`f1-race`, `f1-ers`, `f1-scrutineering`, `f1-race-control`, `f1-aero`, `f1-setup`, `f1-wet`, `f1-driver`.

NASCAR:

`nascar-pack`, `nascar-race-control`, `nascar-pit`, `nascar-tyres`, `nascar-setup`, `nascar-racecraft`, `nascar-telemetry`, `nascar-officiating`.

IndyCar:

`indycar-hybrid`, `indycar-pit`, `indycar-radio`, `indycar-setup`, `indycar-tyres`, `indycar-safety`, `indycar-timing`, `indycar-driver`.

Each shortcut supports `capabilities [output.json]` plus direct `REQUEST.json OUTPUT.json [WORKING_DIRECTORY]` execution. Shortcuts call the existing production family/domain implementation directly; there is no duplicated motorsport physics or rules implementation.

## Regression integration

Added `tests/motorsport_cli_commands_regression.py` and registered `motorsport_cli_commands_regression` with CTest. The regression validates:

- Formula One, NASCAR, and IndyCar aggregate registry counts;
- explicit family routing for all three sports;
- capability metadata for every shortcut;
- successful production execution of all 24 shortcuts using canonical repository examples.

## Documentation

Added `docs/MOTORSPORT_CLI_COMMANDS.md` and updated:

- `README.md`;
- `docs/DOCUMENTATION_INDEX.md`;
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`;
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`;
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`;
- Formula One championship-operations, regulatory, and industrial platform guides;
- IndyCar development, integrated-fidelity, and assurance platform guides;
- NASCAR competition, integrated-fidelity, and assurance platform guides.

The user manual now contains Chapter 69 for the motorsport CLI convenience layer.

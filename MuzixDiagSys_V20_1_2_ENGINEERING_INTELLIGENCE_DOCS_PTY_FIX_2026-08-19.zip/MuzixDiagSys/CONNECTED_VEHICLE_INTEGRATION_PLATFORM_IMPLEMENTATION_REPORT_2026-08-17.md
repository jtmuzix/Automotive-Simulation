# Connected Vehicle Integration Platform — Implementation Report

Date: 2026-08-17
Release line: MuzixDiagSys V20.1.2 additive extension

## Implemented

Eight new native subsystems were added without deleting or replacing existing features:

- J2735 BSM/SPaT/MAP/PSM/TIM application-message model plus IEEE 1609.2-oriented P-256 signing, PSID policy, validity, revocation, freshness, and replay controls.
- DDS Security / SROS2 participant identity, governance, permissions, AES-256-GCM secure transport, signatures, replay protection, and XML policy export.
- RAW Bayer/HDR camera ISP from black-level correction through gamma output and auto-exposure recommendation.
- DMS/OMS RGB/NIR/radar sensor digital twin with PERCLOS, distraction, drowsiness, liveness, occupancy, child, respiration, and belt fusion.
- RTOS discrete-event co-simulation with preemption, multi-core execution, ISR precedence, mutex blocking, priority inheritance, deadline/response metrics, and trace evidence.
- PCIe/CXL central-compute fabric with routing, serialization/contention, IOMMU/TLB, SR-IOV, AER/fault behavior, and coherent transaction overhead.
- Wireless BMS RF/electrothermal/estimation loop with fading, interference/jamming, retries, degraded estimation, balancing, compromise behavior, and safety contactor logic.
- LTE/5G NR/NTN telematics modem with eSIM roaming policy, registration, RRC-like connected/idle behavior, handover, QoS, throughput/latency, power, and thermal throttling.

## Non-duplication

The platform is additive. Existing NR-V2X link simulation, networking, realtime/AUTOSAR, camera rendering, battery physics, cybersecurity, diagnostics, and compute models remain unchanged. The new classes provide missing higher-layer behavior and closed-loop integrations rather than cloning those implementations.

## Standards boundary

The J2735 application codec is a deterministic simulator interchange representation of the implemented message fields. It is not labeled as an SAE-certified ASN.1/UPER codec because the licensed normative SAE J2735 ASN.1 module set and certification vectors are not shipped in this source package. IEEE 1609.2-oriented security semantics use real P-256 signatures and enforce identity/policy/freshness/replay behavior, but external conformance certification remains separate from simulation implementation.

## Regression protection

The new source files are compiled into `aesim_advanced`; `connected_vehicle_integration_platform_tests` is registered as a native CTest target; a source-level retention regression rejects missing build wiring and stub/TODO markers; and the V20 feature/source-package manifests protect the added artifacts from silent removal.

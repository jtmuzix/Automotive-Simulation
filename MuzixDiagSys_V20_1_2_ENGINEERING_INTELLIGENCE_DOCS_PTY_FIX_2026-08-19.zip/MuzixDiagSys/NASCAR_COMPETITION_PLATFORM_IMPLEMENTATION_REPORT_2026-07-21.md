# MuzixDiagSys NASCAR Competition Platform Implementation Report

**Date:** 2026-07-21
**Integration type:** Additive C++17 advanced-platform subsystem
**Public command family:** `nascar`

## Executive summary

This release adds a dedicated NASCAR competition platform to the existing MuzixDiagSys advanced automotive simulator without removing or replacing any existing feature. The implementation introduces ten independently executable domains, deterministic SHA-256 evidence, ten public example requests, a dedicated C++ regression executable, full CLI integration, full-system self-test integration, and expanded User Manual/tutorial documentation.

The implementation is not a set of marker classes or placeholder adapters. Each domain performs bounded numerical simulation, state-machine execution, deterministic scoring, metrology, or evidence reconstruction and rejects malformed, unsafe, or nonconforming inputs.

## Public API and integration

New public header:

- `include/aesim/advanced/nascar_competition_platform.hpp`

New implementation:

- `src/advanced/nascar_competition_platform.cpp`

New test:

- `tests/nascar_competition_platform_tests.cpp`

New documentation and examples:

- `docs/NASCAR_COMPETITION_PLATFORM.md`
- `examples/nascar_competition/README.md`
- Ten JSON request packages under `examples/nascar_competition/`

The platform is compiled into `aesim_advanced`, exposed through `include/aesim/advanced/platform.hpp`, registered with CTest, integrated into the broad advanced-platform self-test, and dispatched by `muzixdiagsys_advanced_platform`.

## Implemented domains

### 1. Cup Next Gen vehicle laboratory

Implements a dedicated stock-car vehicle model with independent suspension, sprung/unsprung dynamics, heave/roll/pitch response, aerodynamic balance, ride-height and bottoming checks, sequential gear selection, transaxle/differential behavior, brake limits, tyre load capacity, fuel use, thermal behavior, and setup comparison outputs.

### 2. Superspeedway pack racing and drafting

Implements multi-car oval motion, wake-dependent drag reduction, cooling-flow loss, side-draft yaw moments, lane interaction, bumper contact impulses, bump-draft stability, engine/coolant temperatures, fuel use, pack cohesion, lane entropy, closing-rate analysis, and severe-contact/Big-One risk metrics.

### 3. NASCAR race-control and procedure engine

Implements stages, caution state, pit-road opening and closure, free-pass assignment, wave-around handling, choose-rule selections, restart-zone enforcement, double-file restarts, red flags, damaged-vehicle policy state, garage repair and return, overtime extension, finish certification, and procedure findings.

### 4. 2026 Chase and stage championship engine

Implements configurable race and stage points, 55-point wins, regular-season ranking, Chase-field selection, 2026 seed values, Chase-only earned points, manufacturer standings, deterministic tiebreaking, and bounded Monte Carlo championship probabilities.

### 5. Official timing, scoring, and SMT data

Implements timing-loop hit validation and deduplication, lap reconstruction, penalties and disqualifications, caution freeze order, official classification, pit-road-speed checks, and high-rate SMT analytics for speed, throttle, brake, steering, gear, RPM, drafting distance, and vehicle-health observations.

### 6. Single-lug pit-crew operations

Implements a dependency-directed pit-task graph, crew roles, skill/fatigue effects, deterministic and Monte Carlo execution, jack/fuel/wheel choreography, single-lug torque and retention checks, wheel indexing, equipment containment, pit-entry-speed checks, interference risk, loose-wheel probability, and percentile stop times.

### 7. Goodyear tyre and wet-weather laboratory

Implements left/right tyre construction behavior, pressure growth, tread/carcass/gas temperatures, stagger, wear, heat cycles, camber/loading effects, inner-liner and damage state, failure-risk metrics, water-film interaction, treaded wet-tyre behavior, hydroplaning analysis, and slick/wet crossover decisions.

### 8. Track-surface and rubber-evolution twin

Implements asphalt/concrete surface state, initial and event-driven temperature, rubber deposition, marbles, rain wash, drainage, water film, resin/traction treatment, repave state, multiple racing lines, grip evolution, abrasion, and best-line selection.

### 9. OSS inspection and technical enforcement

Implements reference/scan point alignment, dimensional residuals, measurement uncertainty and guard bands, mass and crossweight, component serial/seal verification, load-deflection tests, nonlinearity, rate and temperature sensitivity, hidden-mechanism indicators, escalating inspection failures, post-race enforcement, and disqualification decisions.

### 10. Next Gen crash, roof-flap, and SAFER-barrier safety

Implements impact decomposition, vehicle and barrier energy absorption, peak deceleration, delta-v, intrusion, SAFER-versus-rigid response, roof/A-post flap deployment, aerodynamic lift and roll moments, liftoff/rollover state, occupant injury proxies, fuel-cell/fire state, and modular repairability.

## Deterministic evidence

Every capabilities, domain, and self-test report is canonicalized and assigned a SHA-256 evidence digest. Stable output artifacts can be written to a caller-supplied working directory. The ten public examples were executed twice after the final source changes and produced identical nonempty evidence digests in both runs.

## Negative regression coverage

The dedicated suite verifies rejection or failure findings for:

- Restart acceleration outside the configured restart zone
- Incorrect 2026 winner/stage points
- Unsafe single-lug torque
- Post-race OSS noncompliance requiring disqualification
- High-speed/high-yaw crash operation without roof flaps

The integrated self-test also exercises malformed and unsafe paths within all ten domains.

## Command surface

```bash
./build/full/muzixdiagsys_advanced_platform nascar capabilities [output.json]
./build/full/muzixdiagsys_advanced_platform nascar self-test DIRECTORY [output.json]
./build/full/muzixdiagsys_advanced_platform \
  nascar DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Supported domain identifiers:

```text
cup-next-gen-vehicle
superspeedway-pack
race-control
chase-championship
timing-smt
single-lug-pit-crew
goodyear-tyre
track-surface
oss-inspection
crash-safety
```

## Compatibility

The implementation is additive. Existing Formula One, IndyCar, automotive standards, emerging mobility, vehicle, diagnostics, engineering, UI, plugin, FMU, API, and test targets remain in the build graph. No source file or public command was intentionally deleted.

## Engineering boundary

The platform is an engineering simulation, pre-conformance, training, and evidence-generation environment. Configured rules, limits, points tables, procedures, inspection tolerances, safety thresholds, and vehicle parameters must be reviewed against the licensed rulebook, official technical bulletins, event-specific instructions, and approved measurement procedures applicable to the intended season and series.

# Global Mathematical Assurance Implementation Report

**Date:** 2026-07-30  
**Project:** MuzixDiagSys Advanced Automotive Simulator  
**Change type:** Additive mathematical-rigor expansion  
**Compatibility:** Existing features, APIs, commands, models, tests, and options retained

## Executive summary

This implementation adds a production-grade, frontend-neutral mathematical assurance layer to `aesim_core`. It does not replace the existing numerical-rigor kernel. Instead, it certifies and supplements existing dense solves, quadrature, ODE integration, optimization, convergence, uncertainty, and evidence workflows.

The public API is:

```cpp
#include "aesim/core/mathematical_assurance.hpp"
```

The namespace is:

```cpp
aesim::core::math_assurance
```

The API is re-exported by `aesim/advanced/platform.hpp` and is therefore available to every advanced platform.

## Production source

Added:

- `include/aesim/core/mathematical_assurance.hpp`
- `src/core/mathematical_assurance.cpp`
- `tests/mathematical_assurance_tests.cpp`
- `tests/mathematical_assurance_source_regression.py`
- `docs/GLOBAL_MATHEMATICAL_ASSURANCE.md`
- `examples/mathematical_assurance_example.cpp`

Updated:

- `CMakeLists.txt`
- `include/aesim/advanced/platform.hpp`
- `README.md`
- `docs/README.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/GLOBAL_NUMERICAL_RIGOR.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`

The implementation contains 384 lines of public API, approximately 1,570 lines of production C++, 219 lines of focused C++ regression coverage, a static source-contract regression, and a complete operator/developer reference.

## 1. Automatic error budgets

`ErrorBudgetBuilder` accepts explicit error contributions classified as:

- floating point;
- linear solver;
- nonlinear solver;
- time discretization;
- spatial discretization;
- interpolation;
- quadrature;
- sampling;
- surrogate;
- parameter;
- measurement;
- model form;
- other.

Each contribution stores an absolute bound, standard uncertainty, confidence level, correlation group, rationale, and evidence name.

Combination methods:

- root-sum-square;
- conservative worst-case addition;
- correlation-group combination.

The summary separately reports numerical, parameter, measurement, model-form, and total predictive uncertainty and ranks dominant sources.

Adapters automatically ingest `DenseSolveResult`, `QuadratureResult`, and `OdeResult` diagnostics.

## 2. Adaptive precision escalation

`evaluate_adaptive_precision` supports:

- IEEE binary64;
- platform extended precision;
- 50-decimal-digit arithmetic;
- 100-decimal-digit arithmetic.

The controller:

1. evaluates available tiers in ascending order;
2. computes absolute and relative inter-tier changes;
3. estimates retained decimal digits;
4. discounts digits predicted to be lost through condition-number amplification;
5. stops only when agreement and minimum-digit requirements are met;
6. returns an explicitly unqualified result when the maximum tier remains insufficient.

`make_polynomial_precision_problem` supplies complete evaluators for cancellation-sensitive polynomial calculations.

Boost.Multiprecision is header-only; no new runtime library dependency is introduced.

## 3. Multiprecision and verified reference calculations

The platform provides decimal50 and decimal100 evaluations and exact dyadic references for finite binary64 inputs.

`exact_sum`, `exact_dot`, and `exact_polynomial_reference`:

1. decode each IEEE-754 sign, exponent, and fraction;
2. reconstruct the exact integer significand and power-of-two exponent;
3. perform arithmetic using unbounded `cpp_int` values;
4. normalize the resulting dyadic rational;
5. expose the exact numerator and denominator;
6. render 100 decimal digits;
7. explicitly round to binary64 using nearest-even rules.

The conversion handles:

- ordinary normal values;
- subnormal results;
- exact halfway cases;
- ties to even;
- underflow to zero;
- rounding into the smallest normal value;
- overflow to infinity;
- negative values.

`compare_with_reference` reports absolute error, relative error, ULP distance, and verified digits.

## 4. Reproducible exact reductions

The exact reduction result is independent of:

- input order;
- thread scheduling;
- SIMD width;
- GPU reduction shape;
- MPI tree topology.

The original compensated sum and dot APIs remain unchanged for high-throughput production use. The exact reduction APIs serve as deterministic qualification references and difficult-case fallbacks.

## 5. Convergence and manufactured-solution testing

`analyze_convergence` provides:

- observed order;
- Richardson extrapolation;
- fine- and coarse-grid GCI;
- asymptotic ratio;
- monotonic/oscillatory classification;
- asymptotic-range qualification.

When exact errors are supplied, the order is fitted by log-log regression across all levels. Without exact errors, the finest three solution values are used.

Manufactured-solution services:

- fourth-order fixed-step Runge-Kutta ODE verification;
- second-order central-difference Poisson verification;
- `L1`, `L2`, and `L-infinity` norms;
- configurable expected-order gates.

These are executable templates for extending manufactured-solution coverage to every PDE and dynamics subsystem.

## 6. Unified derivative certification

`certify_derivative` cross-checks:

- analytic derivatives;
- complex-step derivatives;
- five-point finite differences;
- Richardson-extrapolated five-point derivatives;
- Taylor-remainder scaling.

A derivative passes only when independent methods agree within combined absolute/relative tolerances and the Taylor remainder exhibits the expected second-order behavior.

## 7. Optimization certification

`certify_optimization` evaluates:

- equality feasibility;
- inequality feasibility;
- bound feasibility;
- nonnegative inequality multipliers;
- complementarity;
- Lagrangian stationarity;
- projected gradient at active bounds;
- aggregate KKT residual;
- minimum eigenvalue of a supplied symmetric Lagrangian Hessian.

A Jacobi symmetric eigensolver is used for the curvature check. Solver termination alone is not treated as an optimality certificate.

## 8. Cross-solver consensus

`cross_solver_consensus` accepts named scalar or vector outputs. It:

- requires consistent dimensions and unique solver names;
- counts independently implemented methods;
- forms a componentwise median consensus;
- computes every pairwise absolute and relative disagreement;
- marks solver outliers;
- enforces configurable agreement tolerances.

## 9. Deterministic property-based testing

`run_property_test` supplies:

- finite bounded input domains;
- deterministic `std::mt19937_64` sampling;
- explicit trial count and seed;
- caller-provided predicates and diagnostics;
- first-failure retention;
- coordinate-wise counterexample shrinking.

This supports conservation, symmetry, reciprocity, positivity, monotonicity, invariance, and metamorphic testing.

## 10. Per-result mathematical evidence

`MathematicalEvidenceCertificate` stores:

- result, operation, method, and precision identity;
- tolerances and iteration counts;
- residual, backward error, condition estimate, and verified digits;
- convergence and qualification state;
- complete error budget;
- optional convergence, derivative, optimization, and consensus records;
- property-test summaries;
- sorted metadata.

`seal()` emits canonical JSON and computes a SHA-256 digest using the existing provenance implementation. `verify_digest()` detects later alteration.

Automatic certificate factories were added for:

- `DenseSolveResult`;
- `QuadratureResult`;
- `OdeResult`.

These factories derive the error budget and core evidence fields directly from existing solver diagnostics.

## Build integration

`src/core/mathematical_assurance.cpp` is compiled into `aesim_core`.

The complete dependency graph was built successfully:

- `aesim_core`;
- `muzixdiagsys`;
- `aesim_formula_one`;
- `aesim_indycar`;
- `aesim_nascar`;
- `aesim_fundamental_physics`;
- `aesim_advanced`;
- `muzixdiagsys_advanced_platform`;
- `aesim_test_artifacts` and every registered C++ test/tool/plugin target.

## Compatibility

No existing public API was changed or removed. The existing `numerical_rigor.hpp` algorithms, tolerances, solver result structures, commands, build targets, project formats, and evidence systems remain intact.

The new services are additive and can be adopted incrementally. Existing users do not need to modify code unless they choose to request mathematical assurance evidence.

## Qualification boundary

Mathematical certification does not establish physical-model validity. A result may be numerically precise yet physically inaccurate because of invalid constitutive laws, geometry, boundary conditions, calibration, measurement data, scenario distributions, or applicability assumptions. The new evidence should be combined with experimental validation and model-applicability review.

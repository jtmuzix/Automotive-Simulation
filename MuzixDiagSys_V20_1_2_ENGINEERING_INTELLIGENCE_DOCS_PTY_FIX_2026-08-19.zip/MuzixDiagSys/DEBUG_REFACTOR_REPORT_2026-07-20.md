# MuzixDiagSys Debug and Refactor Report

**Date:** 2026-07-20
**Input:** `MuzixDiagSys_indycar_future_competition_fully_implemented_2026-07-20(1).zip`
**Scope:** Safe archive inspection, clean configuration, complete compilation/link validation, full regression execution, strict compiler analysis, sanitizer validation, targeted production defect correction, internal utility refactoring, portability hardening, and regression-test expansion.

## Executive summary

The supplied source archive is a large C++17/CMake automotive simulation platform with 151 registered CTest tests. The unmodified baseline configured and completed all 358 build actions successfully under the repository's existing strict compiler-warning and hardening configuration. The initial regression sweep did not expose a compile or link failure, so the debugging effort proceeded into focused source review of the newly added IndyCar future-competition subsystem and boundary-condition testing.

The review identified concrete correctness defects in official timing/stewarding, championship economics, transition planning, multi-car strategy, and aero-test optimization. The most consequential defect allowed photo-finish evidence for an unrelated car to rotate that car into the winning position. Position penalties were also represented as one-millisecond time additions, only the first position penalty was considered, and official winners could be declared when all classified competitors were disqualified.

The defects were corrected without removing existing features or changing public C++ API signatures. Shared private helpers were consolidated into a single internal header, overflow-safe arithmetic was introduced, OpenSSL digest context management was converted to RAII, and a GNU-specific population-count intrinsic was replaced with a portable implementation. Regression coverage was expanded for every corrected behavior.

## Production defects corrected

### Official timing, photo finish, and stewarding

File: `src/advanced/indycar_future_competition_platform_a.cpp`

- Restricts photo-finish adjudication to the two electronically tied leading classified cars.
- Requires valid photo observations for both tied leaders before declaring that photo-finish evidence was used.
- Prevents observations for unrelated cars from promoting those cars into the lead classification.
- Applies a deterministic tie-break order using effective crossing time, nose position, and car identity.
- Aggregates every position penalty assigned to a car rather than considering only the first decision.
- Applies position penalties as actual classification demotions instead of artificial `0.001 s` time additions.
- Applies simultaneous demotions from the rear of the classification toward the leader to preserve cumulative effects.
- Prevents incidents involving an unknown or untimed car from fabricating a zero-lap classification entry.
- Leaves the winner empty when no classified competitor remains after disqualification.
- Validates all timing hits, photo observations, and incidents before adjudication begins.
- Refactors compressed timing-state and penalty logic into explicit, reviewable control flow.

### Championship and entrant economics

File: `src/advanced/indycar_future_competition_platform_a.cpp`

- Rejects an event whose `baseline_expected_points` exceeds `maximum_driver_points`.
- Clamps conservative fallback points to the legal event range before prize and sponsor revenue are calculated.
- Prevents malformed event inputs from creating impossible points and revenue values.

### 2028 transition planning and numeric safety

Files:

- `src/advanced/indycar_future_competition_platform_a.cpp`
- `src/advanced/indycar_future_competition_internal.hpp` (new)

- Replaces unchecked `teams * cars_per_team` and race-car/prototype addition with checked `std::size_t` arithmetic.
- Throws `std::overflow_error` rather than silently wrapping fleet cardinalities.
- Adds finite and representable-range checks to ceiling-to-count conversion.
- Uses `long double` for the conversion boundary so a rounded `double` value above `SIZE_MAX` cannot be cast unsafely.

### Multi-car strategy engine

File: `src/advanced/indycar_future_competition_platform_b.cpp`

- Caps non-crash expected points to the modeled event maximum of 50.
- Rejects duplicate pit laps, which previously double-counted pit losses and distorted pit-conflict probability.
- Rejects pit lap zero.
- Rejects pit stops scheduled beyond the race distance.
- Retains sorted-lap validation and all existing strategy enumeration behavior.

### Aero-development optimizer portability

Files:

- `src/advanced/indycar_future_competition_platform_b.cpp`
- `src/advanced/indycar_future_competition_internal.hpp` (new)

- Replaces `__builtin_popcountll`, which is compiler-specific, with a portable C++17 64-bit population-count helper.
- Preserves the exact subset optimizer and its existing 22-opportunity bound.

## Internal refactor

New file: `src/advanced/indycar_future_competition_internal.hpp`

The two large IndyCar implementation translation units previously duplicated finite-value validation, `[0,1]` clamping, SHA-256 code, and gravity constants. The new private header centralizes:

- finite scalar validation;
- unit-interval clamping;
- SHA-256 calculation;
- checked addition and multiplication;
- checked ceiling-to-count conversion;
- portable 64-bit population count;
- the shared gravity constant.

The SHA-256 helper now manages `EVP_MD_CTX` with `std::unique_ptr` and `EVP_MD_CTX_free`, eliminating manual cleanup paths while retaining the same evidence-digest algorithm and output format.

An unused air-density constant was removed. No new external dependency was introduced.

## Regression coverage added

File: `tests/indycar_future_competition_platform_tests.cpp`

New regression assertions cover:

1. transition fleet-size multiplication overflow;
2. baseline expected points above the event maximum;
3. unrelated photo-finish observations being ignored for winner selection;
4. photo-finish use requiring observations for both tied leaders;
5. accumulation of multiple position penalties;
6. actual classification demotion and winner change after position penalties;
7. prevention of incident-only ghost classifications;
8. no winner when every competitor is disqualified;
9. strategy expected-points upper bound;
10. duplicate pit-lap rejection;
11. pit-lap-zero rejection;
12. pit stops beyond race distance.

## Validation performed

### Baseline and final compilation

- Safe ZIP path inspection and extraction: passed.
- Clean CMake/Ninja Debug configuration: passed.
- Baseline complete build: **358/358 build actions passed**.
- Final incremental complete build and relink: passed.
- GCC project warning set (`-Wall -Wextra -Wpedantic -Wshadow -Wformat=2`): zero diagnostics observed in modified code.
- Independent Clang strict syntax analysis, including conversion and sign-conversion warnings: zero diagnostics.
- GCC `-fanalyzer` on both modified production translation units: zero diagnostics.

### Runtime and regression validation

- Dedicated IndyCar future-competition regression: passed.
- Combined registered IndyCar test group: **3/3 passed**.
- AddressSanitizer: passed.
- UndefinedBehaviorSanitizer: passed.
- Leak detection: passed.
- Full registered CTest suite: **150 passed, 0 failed, 1 skipped (151 registered tests)**.
- Skipped test: `advanced_platform_python_runtime`; its optional `gymnasium` dependency is not installed.
- Serial CTest wall time: **835.73 seconds**.
- PTY/UI tests were executed serially in the final sweep to avoid pseudo-terminal contention observed under parallel CTest scheduling.

### Packaging and source hygiene

- `git diff --check`: passed.
- Stub/TODO/FIXME/placeholder scan of modified and new code: passed.
- Source-package regression: passed.
- Generated-artifact cleanliness regression: passed.
- Build-footprint regression: passed.
- PIC/PIE configuration regression: passed.
- User-manual regression: passed.
- Branding regression: passed.

## Files changed

### Production

- `src/advanced/indycar_future_competition_platform_a.cpp`
- `src/advanced/indycar_future_competition_platform_b.cpp`
- `src/advanced/indycar_future_competition_internal.hpp` (new)

### Tests

- `tests/indycar_future_competition_platform_tests.cpp`
- `tests/source_package_regression.py`

### Engineering records

- `DEBUG_REFACTOR_REPORT_2026-07-20.md` (new)
- `DEBUG_REFACTOR_VALIDATION_2026-07-20.txt` (new)

## Compatibility considerations

- No existing feature was removed.
- No public class, structure, function, or command signature was removed or renamed.
- Evidence digests remain SHA-256 hexadecimal strings with the existing canonical payloads; only helper ownership was refactored.
- Invalid championship events and invalid pit schedules that were previously accepted now throw `std::invalid_argument`.
- Transition cardinalities that would previously wrap now throw `std::overflow_error`.
- Official classification results can change where prior behavior incorrectly treated position penalties as milliseconds, used unrelated photo evidence, fabricated untimed cars, or declared a disqualified winner.

## Remaining engineering observations

The repository is functionally broad and passed its registered regressions, but several translation units remain very large. In particular, the central simulation runtime and terminal UI implementation continue to carry substantial compilation and review surface. A future architectural pass should split those files by subsystem behind stable interfaces, but that work was intentionally not mixed into this defect-focused correction because it would create a much larger regression and merge risk.

# NASCAR Ecosystem Expansion — Implementation Report

Date: 2026-07-21

## Scope

This release extends the existing ten-domain NASCAR Competition Platform to twenty domains. The work is additive. No existing source file, command family, public API, test, Formula One subsystem, IndyCar subsystem, standards subsystem, emerging-mobility subsystem, plugin, FMU, UI workflow, or simulator feature was removed.

## New architecture

A new public class, `aesim::advanced::nascar::NascarEcosystemPlatform`, is implemented in:

- `include/aesim/advanced/nascar_ecosystem_platform.hpp`
- `src/advanced/nascar_ecosystem_platform.cpp`

`NascarCompetitionPlatform` delegates the ten new identifiers to this platform, combines both capability catalogues, and executes both self-test groups under the existing `nascar` command family. The combined capability and self-test count is twenty.

## Implemented domains

### `multi-series`

Provides immutable 2026 profiles for Cup, O'Reilly Auto Parts, Craftsman Truck, and ARCA. It calculates fuel-adjusted mass, bank-assisted corner speed, power-limited top speed, mean lap speed, lap time, aerodynamic load, fuel rate, and tyre-energy demand.

### `manufacturer-homologation`

Evaluates manufacturer bodies over a speed/yaw/ride-height matrix. It computes drag, downforce, side force, yaw moment, wake recovery, and drafting efficiency, then applies normalized drag, downforce, and drafting parity limits.

### `v8-transaxle-durability`

Models a pushrod V8 and sequential transaxle over an arbitrary duty cycle. It includes piston speed, volumetric and combustion efficiency, torque, power, valve-spring surge, valvetrain fatigue, transaxle mesh loads, bearing damage, dog engagement life, missed shifts, over-rev exposure, and effective engine/oil/coolant thermal masses.

### `special-event-formats`

Constructs starting lineups for Daytona 500, All-Star, and group-qualifying formats. Daytona processing locks the front row, integrates Duel finishing order, and applies open-exemption, charter, owner-points, and speed provisionals. All-Star processing includes eligibility, pit-challenge order, and fan-vote state.

### `charter-team-economics`

Calculates purse participation, sponsorship, manufacturer support, entry fees, payroll, shop, travel, parts, debt service, expected crash cost, profit, cash runway, discounted charter value, and financial-distress probability.

### `pit-road-vision`

Projects calibrated camera detections into pit-road coordinates using a full projective homography. It reconstructs object motion, counts unique crew tracks over the wall, detects pit-box boundary violations, uncontrolled tyres, equipment escape, and fueler protective-equipment deficiencies.

### `radio-intelligence`

Correlates spotter calls with time-indexed traffic truth, evaluates RF SNR, intelligibility, latency, urgency, acknowledgement, and ambiguous terminology, and computes an explainable communication score.

### `trackside-safety-drying`

Dispatches recovery, cleanup, barrier-repair, and drying resources using shortest closed-circuit travel distance, resource speed, setup time, and capacity. It models natural evaporation plus equipment removal, reports zone readiness, and enforces daylight and unresolved-hazard gates.

### `dvp-garage-repair`

Builds a dependency-safe physical repair schedule from damage, parts inventory, mechanics, skill, and task severity. It consumes parts, propagates failed dependencies, calculates repair time, laps lost, alignment recovery, residual drag loss, minimum-speed capability, and return authorization. Nonrecoverable schedules serialize unavailable times as JSON `null` rather than non-finite numbers.

### `wet-weather-visibility`

Integrates rain deposition, wiper clearing, aerodynamic removal, cabin dew drive, defogging, windshield fog, following-car spray, optical extinction, driver recognition distance, camera transmission, and rain-light performance. It recommends green, caution/pace-car, or red-flag operation.

## Safety and correctness corrections found during implementation

- Increased V8 thermal capacitance from fluid-only approximations to effective engine/oil/coolant system thermal masses.
- Replaced non-finite DVP failure times with explicit JSON null state and `repair_complete=false`.
- Propagated failed repair dependencies instead of scheduling downstream work at infinite time.
- Counted unique pit-road crew tracks rather than duplicate multicamera observations.
- Marked track zones raceable after modeled resource completion rather than retaining the initial hazard state.

## Public command surface

```bash
./build/full/muzixdiagsys_advanced_platform nascar capabilities
./build/full/muzixdiagsys_advanced_platform nascar self-test DIRECTORY OUTPUT.json
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

New domain identifiers:

```text
multi-series
manufacturer-homologation
v8-transaxle-durability
special-event-formats
charter-team-economics
pit-road-vision
radio-intelligence
trackside-safety-drying
dvp-garage-repair
wet-weather-visibility
```

## Tests and examples

- Added `nascar_ecosystem_platform_unit_tests`.
- Expanded the original NASCAR integrated test from 10 to 20 domains.
- Added negative tests for manufacturer parity, unsafe spotter evidence, missing repair parts, and failed wet-weather equipment.
- Added ten executable JSON examples under `examples/nascar_ecosystem/`.
- Updated the NASCAR guide, User Manual Markdown, and tutorial/exact-command guide.

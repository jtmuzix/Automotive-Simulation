# Frontier Runtime and Sensing Platform - Implementation Report

**Date:** 2026-08-07  
**Status:** Production implementation complete; release qualification recorded separately.

## Delivered scope

This additive C++17 expansion implements:

1. ULFM-resilient distributed execution semantics with optional native MPIX communicator repair.
2. Error-bounded ZFP fixed-accuracy and SZ3 predictive checkpoint profiles with persistent integrity verification.
3. File-backed out-of-core binary64 arrays with bounded LRU caching and dirty writeback.
4. CPU-package/NUMA/GPU topology discovery, constraint-based placement, and Linux CPU affinity.
5. Machine-checkable floating-point forward-error certificates for sum, dot, and Horner operations.
6. Quaternion Lie-group rigid-body integration and Störmer-Verlet variational integration.
7. Two-stage third-order Radau IIA, Rosenbrock-W1, and IMEX Heun/trapezoid stiff integration.
8. Carrier-phase GNSS factor graphs supporting Standalone/PPP/RTK/PPP-RTK, dual-frequency combinations, Doppler/clock drift, ambiguity fixing, sliding windows, IMU, wheel, and map factors.
9. SPAD photon-counting LiDAR with detector statistics, jitter, dead time, and background/dark counts.
10. Coherent FMCW LiDAR with joint range/velocity recovery from up/down chirps.
11. Radar micro-Doppler and complex HH/HV/VH/VV polarimetry with Pauli powers.

No existing command, public header, simulator model, project format, UI feature, SARR capability, or compatibility alias is intentionally removed.

## Public integration

Header:

```text
include/aesim/advanced/frontier_runtime_sensing_platform.hpp
```

Implementation:

```text
src/advanced/frontier_runtime_sensing_platform.cpp
```

Aggregate export:

```text
include/aesim/advanced/platform.hpp
```

CLI:

```text
muzixdiagsys_advanced_platform frontier-runtime ...
```

Dedicated unit test:

```text
tests/frontier_runtime_sensing_platform_tests.cpp
```

End-to-end CLI test:

```text
tests/frontier_runtime_sensing_cli_regression.py
```

Canonical examples:

```text
examples/frontier_runtime/
```

## Portability contracts

The deterministic resilient-distribution layer is always compiled. CMake additionally probes for a true ULFM MPI implementation and enables the native `MPIX_Comm_revoke`/`MPIX_Comm_shrink`/`MPIX_Comm_agree` path only when those symbols compile and link.

The built-in checkpoint codecs implement the documented ZFP fixed-accuracy and SZ3 predictive operating profiles within MuzixDiagSys. They enforce the numerical error contract and persistence/integrity behavior without requiring external libraries. They do not claim external ZFP/SZ3 bitstream compatibility.

Linux-specific scheduler discovery uses sysfs and `sched_setaffinity`; other platforms receive the portable topology fallback and explicit unsupported-affinity result.

## Error handling

All public feature paths validate dimensions, finite numerical inputs, error bounds, file sizes, indices, codec IDs, variable-length integers, rank IDs, solver convergence, and required measurement fields. Persistence uses the existing atomic byte writer. Corrupt compressed payloads and invalid out-of-core backing sizes fail before returning data.

## Numerical integration

The stiff solvers reuse the qualified `aesim::core::numerics` dense solve and QR infrastructure. Radau IIA performs a coupled two-stage Newton solve, Rosenbrock-W performs a linearly implicit Jacobian solve, and IMEX Newton-solves the implicit partition while retaining the explicit Heun contribution.

The GNSS batch optimizer uses weighted QR rather than forming normal equations, and its factors are normalized by their measurement uncertainty.

## Documentation

The authoritative references are:

- `docs/FRONTIER_RUNTIME_SENSING_PLATFORM.md`
- Chapter 64 of `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `FRONTIER_RUNTIME_SENSING_IMPLEMENTATION_REPORT_2026-08-07.md`
- `FRONTIER_RUNTIME_SENSING_VALIDATION_2026-08-07.txt`

## Final qualification

The complete Release test-artifact closure builds successfully. A single final CTest run reports **218/218 tests passed, 0 failures** in 183.34 seconds, including the 124.77-second regulatory-cycle regression and the new Frontier Runtime/Sensing CLI regression. Focused AddressSanitizer, UndefinedBehaviorSanitizer, and leak-detection qualification of the new implementation reports zero findings. The Markdown/PDF user manual, documentation-consistency, source-integration, and deterministic source-package regressions pass. Full release details and explicit portability boundaries are recorded in `FRONTIER_RUNTIME_SENSING_VALIDATION_2026-08-07.txt`.

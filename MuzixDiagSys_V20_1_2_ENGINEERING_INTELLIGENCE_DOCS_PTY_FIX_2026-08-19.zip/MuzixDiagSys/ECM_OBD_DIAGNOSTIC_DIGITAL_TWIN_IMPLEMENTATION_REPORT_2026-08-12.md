# ECM / OBD-II Diagnostic Digital Twin Implementation Report

Implemented 2026-08-12 as an additive refactor over the existing diagnostic architecture. No existing unique command or backend was removed.

## Architectural rule

`aesim::industrial::DiagnosticService` remains the single authoritative protocol semantic service. Existing ISO-TP, CAN/CAN-FD, SocketCAN, DoIP, ELM327, SOVD, diagnostic workflow, causal graph and network-fault components are reused. New ECM behavior is implemented in `EcmObdPlatform`; the existing `UdsServer` and Mode 01 PID encoder are extended in place rather than duplicated.

## Implemented scope

1. Virtual ECM runtime and scheduler/diagnostic executive.
2. DTC debounce/lifecycle, freeze frame, MIL and permanent-code aging.
3. Extended legacy OBD-II services/PID set and correct supported-PID discovery.
4. Physical-to-diagnostic signal provenance.
5. Misfire, fuel-system, comprehensive-component, catalyst, oxygen-sensor and EVAP monitor models.
6. Expanded UDS service server.
7. Regulatory OBDonUDS profile.
8. ISO-TP CAN/CAN-FD deterministic transport fault simulation.
9. DoIP routing through the canonical service.
10. WWH-OBD regulatory profile.
11. ZEVonUDS propulsion DIDs/profile.
12. Calibration and flash/bootloader state machine with CRC32 and recovery.
13. Shared electrical/harness fault propagation.
14. Bidirectional active-test state.
15. Automated diagnostic causal ranking.
16. Guided technician test plans.
17. Virtual J2534 surface plus reuse of the existing ELM327 adapter.
18. Conformance and fuzzing framework.
19. HIL/real scan-tool configuration over existing SocketCAN/kernel ISO-TP infrastructure.
20. Deterministic regulatory/monitor diagnostic campaigns.

## Regression coverage

`tests/ecm_obd_platform_tests.cpp` exercises all twenty requested areas and is registered as `ecm_obd_platform_unit_tests`.

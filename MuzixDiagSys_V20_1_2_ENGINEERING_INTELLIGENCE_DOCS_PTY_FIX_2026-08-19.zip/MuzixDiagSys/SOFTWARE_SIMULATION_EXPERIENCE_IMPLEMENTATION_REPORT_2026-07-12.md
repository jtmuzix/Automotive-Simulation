# MuzixDiagSys Software-Only Simulation Experience Implementation Report

**Date:** 2026-07-12  
**Baseline:** `advanced_engine_sim_accuracy_depth_complete_2026-07-12.zip`  
**Scope:** Fully implement the requested realism and operator-experience systems without removing existing functionality or changing the established terminal GUI layout.

## Executive summary

The simulator now contains a unified software-only experience platform that operates with a normal keyboard, monitor, and speakers/headphones. The implementation adds persistent vehicle ownership and maintenance, deterministic scenario timelines and branches, causal event explanations, physics-driven audio synthesis, OpenCRG and generated road surfaces, distributed tire contact, suspension compliance, evolving weather and road state, heterogeneous traffic, diagnostic workshop cases, terminal/SVG visualization, measured-reference ghost comparison, adaptive fidelity, uncertainty-aware reports, and a live human driver skill model.

The feature is integrated into the existing `VehiclePlatform`, `IndustrialPlatform`, signal registry, OSI-oriented world, advanced vehicle dynamics, command schema, Tab completion, and top-level powertrain actuator path. It is not a detached demonstration library.

No existing command, plugin, vehicle preset, engine preset, GUI frame, automation interface, or physics subsystem was removed. The golden-frame UI regression and exhaustive completion audit pass.

## Implementation inventory

### New public API

- `include/aesim/experience/simulation_experience.hpp`

The header defines typed configuration, state, and service APIs for:

- `PersistentVehicleGarage`
- `ScenarioTimeline`
- `CausalExplanationEngine`
- `ProceduralAudioSynthesizer`
- `RoadSurfaceField`
- `DistributedTireContactModel`
- `SuspensionComplianceModel`
- `DynamicWeatherRoadModel`
- `HeterogeneousTrafficEcology`
- `WorkshopDiagnostics`
- `SimulationVisualizer`
- `AdaptiveExperienceFidelity`
- `AutomaticExperienceReport`
- `HumanDriverSkillModel`
- `SimulationExperiencePlatform`

### New implementation units

- `src/vehicle/experience_lifecycle_timeline.cpp`
- `src/vehicle/experience_physics_world.cpp`
- `src/vehicle/experience_workshop_visual.cpp`

The implementation is divided by responsibility instead of adding more code to the already monolithic simulator translation unit.

### Existing-system integrations

Modified:

- `src/vehicle/platform.cpp`
- `src/industrial/platform.cpp`
- `src/muzixdiagsys.cpp`
- `include/aesim/vehicle/vehicle.hpp`
- `include/aesim/industrial/platform.hpp`
- `CMakeLists.txt`
- `README.md`

### Documentation and sample assets

Added:

- `docs/SOFTWARE_SIMULATION_EXPERIENCE_PLATFORM.md`
- `data/experience/urban_wet_timeline.yaml`
- `data/experience/reference_ghost.csv`
- `data/experience/diagnostic_underboost.yaml`
- `data/experience/example_surface.crg`

## Feature implementation details

## 1. Persistent vehicles, wear, damage, and maintenance

Persistent vehicles are stored as versioned JSON records in a configurable garage directory. The persisted state includes:

- Vehicle and engine preset identities.
- Odometer, engine hours, and idle hours.
- Cold and hot starts.
- Launches and shifts.
- Clutch-slip and brake-energy histories.
- Electrical energy throughput.
- Rain, salt, thermal, impact, and roughness exposure.
- Active diagnostic faults.
- Maintenance history with mileage, engine hours, action, component, quality, cost, and notes.
- Component wear, damage, contamination, thermal age, equivalent cycles, condition, and estimated remaining useful life.

Operating-point accumulation is driven by real runtime quantities. Component aging is therefore load- and environment-dependent rather than a generic timer.

Maintenance actions implement distinct physical effects:

- Replacement and rebuild reduce reversible wear, damage, contamination, and cycle history according to service quality.
- Fluid service, cleaning, and flushing primarily remove contamination and a small amount of reversible wear.
- Calibration and alignment correct a bounded fraction of misalignment/damage state.
- Inspection creates a service record without falsely repairing the component.

Writes are atomic to avoid corrupting a persistent vehicle after interruption.

## 2. Interactive scenario and timeline tools

`ScenarioTimeline` provides:

- YAML ingestion.
- Live event creation.
- Priority ordering.
- Pause and resume.
- Fixed-duration stepping.
- Step-to-next-event operation.
- Arbitrary seeking.
- Named branches.
- Branch selection and comparison.
- Trace export.

Supported operations are `set`, `add`, `multiply`, `minimum`, `maximum`, and `toggle`.

Timeline events use the existing signal registry and environment state. They do not bypass signal validation or create a second actuator pathway. Supported aliases map human-facing names such as `brake`, `throttle`, and `steering` to existing writable signals.

## 3. Causal simulation explanations

The causal engine stores a directed event graph containing:

- Stable event identifier.
- Simulation timestamp.
- Subsystem.
- Human-readable observation.
- Numeric evidence.
- Parent-event identifiers.
- Recommended corrective action.

Explanations recursively traverse parent events and report a causal chain. Live integration records significant shifts, high brake-energy events, hydroplaning, invalid timeline targets, and audio capture-limit events.

The graph can be queried by event identifier, queried for the latest event, cleared, and exported to JSON.

## 4. Procedurally synthesized audio

The audio engine produces standard stereo PCM WAV files from physical state. It synthesizes:

- Engine firing orders derived from cylinder count and RPM.
- Load-dependent combustion harmonics.
- Gear-mesh tones and harmonics.
- Tire/road roughness excitation.
- Wind excitation.
- Brake friction excitation.
- Clutch-slip excitation.
- Seeded stochastic texture.

Oscillator phases remain continuous across render blocks, preventing block-boundary clicks. The synthesizer supports configurable sample rate, channel count, deterministic seed, reset, bounded live capture, and WAV export.

The capture-duration limit prevents unbounded memory growth during long simulations.

## 5. OpenCRG and generated road surfaces

`RoadSurfaceField` supports:

- Rectilinear OpenCRG-style header and grid ingestion.
- Extent and data-count validation.
- Bilinear interpolation.
- Surface-normal calculation.
- Local friction.
- Local roughness.
- Water and snow depth.
- Temperature.
- Road material.

Procedural roads combine:

- Seeded multiband smooth noise.
- Long-wave surface variation.
- Crown and grade.
- Wheel-path rutting.
- Expansion joints.
- Spatially distributed potholes.

The same seed and configuration reproduce the same road exactly.

The experience surface feeds actual per-wheel advanced-vehicle road inputs when the pre-existing vehicle OpenCRG surface is not active. Existing OpenCRG workflows retain precedence.

## 6. Distributed tire contact and suspension compliance

The tire contact patch is discretized into configurable longitudinal and lateral cells. Each cell tracks:

- Position and road height.
- Normal load and pressure.
- Longitudinal and lateral slip contribution.
- Friction utilization.
- Temperature.
- Wear.
- Water support and hydroplaning state.

The aggregate state calculates:

- Longitudinal force.
- Lateral force.
- Aligning moment.
- Contact area.
- Effective friction.
- Mean temperature.
- Slip power.
- Hydroplaning fraction.

The suspension model resolves each wheel independently with spring/damper behavior, bump and droop stops, road displacement, bushing compliance, compliance steer, camber and toe change, caster, and dissipated bushing energy.

Suspension compliance steering is coupled to the existing advanced wheel-angle inputs.

## 7. Dynamic weather, road state, and heterogeneous traffic

Weather uses moving spatial cells with independent:

- Position and radius.
- Velocity.
- Rain and snow rates.
- Fog visibility.
- Wind components.
- Temperature.

The road evolves through:

- Rain and snow accumulation.
- Drainage.
- Traffic spray.
- Snow compaction.
- Freezing and ice formation.
- Melting and refreezing.
- Surface-temperature change.
- Friction scaling.

Traffic includes passenger cars, heavy trucks, buses, motorcycles, bicycles, pedestrians, emergency vehicles, construction vehicles, and disabled vehicles. Every agent has individual speed preference, reaction time, desired gap, aggression, courtesy, rule compliance, distraction, and lane-change behavior.

Traffic is published into the existing OSI-oriented world. Weather is published into the shared world environment. Perception, autonomy, visualization, and vehicle systems therefore consume a common world state.

## 8. Workshop diagnostics and fault-solving scenarios

The workshop system includes complete cases for:

- Restricted injector.
- Weak battery.
- Transmission pressure leakage.
- Wheel-speed dropout.
- Cooling-system air pocket.
- Turbo underboost.
- Clutch slip.

Each case defines allowed tests and hidden evidence. All 29 advertised diagnostic tests map to numeric, case-specific evidence. Missing evidence mappings raise an internal logic error rather than returning generic or placeholder text.

Diagnostic scoring considers:

- Exact or partial diagnosis correctness.
- Evidence gathered.
- Number of tests.
- Test cost.
- Elapsed diagnostic time.

Workshop reports export the test sequence, measurements, actual fault, solution state, cost, time, and score.

## 9. Two-dimensional/three-dimensional visualization and ghost comparison

Visualization includes:

- Top-down ASCII terminal rendering.
- Self-contained two-dimensional SVG export.
- Perspective three-dimensional SVG export.
- Host vehicle and traffic objects.
- Reference ghost import from CSV.
- Simulation sample history.
- Time-aligned ghost residual export.

Ghost comparison reports position, speed, engine-speed, and gear differences. No dedicated graphics hardware or external viewer beyond a normal browser is required.

## 10. Adaptive fidelity, automatic reports, and uncertainty visualization

Fidelity levels are:

- Fast.
- Interactive.
- Engineering.
- Validation.
- Full research.

The automatic manager uses event severity, model uncertainty, and compute load to select model depth. A decision controls tire contact resolution, suspension/weather/traffic periods, and audio sample rate. Transition history is retained for auditability.

Automatic Markdown and JSON reports include:

- Run metadata.
- Persistent vehicle identity and odometer when active.
- Speed and engine-speed metrics.
- Road friction and water depth.
- Effective tire friction.
- Dynamic environment status.
- Traffic status.
- Human-driver status.
- Fidelity state.
- User sections and warnings.

Each uncertainty metric contains nominal value, measurement standard uncertainty, model-form uncertainty, combined standard uncertainty, and a 95% interval.

## 11. Human driver skill model

The driver model includes:

- Reaction delay.
- Attention.
- Fatigue.
- Distraction probability.
- Car-following response.
- Lane-error and heading-error correction.
- Throttle and brake smoothness.
- Steering skill.
- Aggression and economy tendency.
- Manual clutch skill.
- Shift timing.
- Rev matching.
- Missed shifts.
- Stalls.
- Harsh clutch events.

When live control is enabled:

- Throttle and brake outputs are applied after the legacy speed controller so the controllers cannot fight each other.
- Steering is applied through the existing vehicle steering signal.
- Manual clutch-pedal depression is applied to the actual `DriverInputs` clutch state.
- Requested gears are applied to the actual transmission only with a fully depressed clutch.
- Automatic transmissions ignore clutch and manual gear requests.

This converts the driver from a reporting model into a real actuator owner.

## Command and completion integration

The feature is available through:

```text
industrial experience ...
industrial simulation-experience ...
industrial vehicle experience ...
```

The completion hierarchy covers:

- `garage`
- `timeline`
- `explain` / `causal`
- `audio`
- `road` / `opencrg`
- `tire` / `contact`
- `weather`
- `traffic`
- `workshop` / `diagnostics`
- `visual` / `visualization` / `ghost`
- `fidelity`
- `report` / `uncertainty`
- `driver` / `human-driver`
- `status`

The exhaustive completion audit passes with 229 root commands, 12,014 command paths, and 11,817 nested checks.

## Code comments and maintainability

Comments were added around:

- Persistent degradation and maintenance reversibility.
- Timeline signal ownership and validation.
- Procedural surface generation.
- OpenCRG validation and interpolation.
- Distributed contact pressure and hydroplaning.
- Suspension compliance calculations.
- Weather accumulation and phase changes.
- Traffic substepping.
- Human driver shift and clutch sequencing.
- Live actuator arbitration.
- Diagnostic evidence completeness.
- Audio phase continuity and capture bounds.
- Adaptive-fidelity selection.
- Uncertainty interval calculation.

The new implementation is split across three focused translation units. A scan of the new C++ and test code found no TODO, FIXME, stub, placeholder, or “not implemented” markers.

## Compatibility and preservation

Preserved:

- Existing terminal GUI layout.
- Existing command names and aliases.
- Existing vehicle and engine YAML catalog.
- Existing brake and clutch semantics.
- Existing plugins and plugin ABI.
- Existing FMI, OSI, OpenDRIVE, OpenSCENARIO, HLA/DCP, VSS/VISS, HIL, SIL, and research functions.
- Existing vehicle OpenCRG precedence.
- Existing professional, industrial, electrification, lifecycle, assurance, and federation platforms.

The golden-frame UI regression passes.

## Qualification

### Builds

- Complete GNU Debug build: **passed at 100%**.
- All libraries, plugins, tools, simulator executable, and compiled tests: **passed**.
- Release libraries and `aesim_study_worker`: **passed**.
- Release `muzixdiagsys.cpp`: **incomplete qualification**. The pre-existing 1.2 MB monolithic translation unit exceeded repeated 30-minute GNU Release optimization windows without a compiler diagnostic. This is not recorded as a pass or as a source failure.

### Tests

Fifty distinct tests passed, including:

- All 20 compiled core/unit suites.
- New simulation-experience unit suite.
- New complete experience CLI workflow.
- All-command completion regression.
- Golden-frame UI regression.
- Driver-control and YAML catalog regression.
- CLI, PIC/PIE, and accelerator linkage regressions.
- Drivetrain and automatic-shift regressions.
- Coupled-realism regression.
- Preset readability, resource lookup, and metric dictionary regressions.
- Research feature regression.
- Professional and industrial platform regressions.
- Advanced vehicle and electrification regressions.
- Accuracy-depth regression.
- Perception-realism and assurance regressions.
- Vehicle, federation, research-integration, and frontier regressions.
- Command-surface regression.
- Terminal-formatting regression.
- Non-finite input regression.

The workshop test explicitly covers all seven diagnostic fault families and all 29 available test paths.

### Known test-harness limitation

The repository retains a known CTest/PTTY orchestration issue in which some long subprocess-heavy tests can stall when chained inside one CTest controller process. The relevant tests were executed directly or in fresh processes. A single uninterrupted 88-test CTest run is therefore not claimed.

## Conclusion

All requested software-only realism and experience systems are implemented, integrated, documented, command-accessible, completion-accessible, and tested. The implementation introduces no intentional GUI changes and removes no existing functionality.

# MuzixDiagSys HIP Build Debug and Refactor Report

Date: 2026-07-28

## Incident summary

The reported full RelWithDebInfo build configured successfully, then failed while compiling `src/electrification/acceleration_hip.hip` with the ROCm Clang frontend. The compile command contained GCC's `-fno-var-tracking-assignments`, which Clang does not recognize. Ninja stopped at that first compiler error. CTest was subsequently invoked against the incomplete build directory, so most unit-test executables and production CLIs did not exist; those missing binaries produced 167 secondary failures.

## Root cause

`aesim_configure_target()` selected the GCC optimization because `CMAKE_CXX_COMPILER_ID` was `GNU`, then applied the option at target scope. `aesim_industrial` is a mixed-language target containing ordinary C++ and a HIP translation unit. CMake therefore forwarded the target-wide GCC option to the independently selected HIP compiler, `/usr/lib64/rocm/llvm/bin/clang++`.

The same target-level pattern could also leak host-only hardening, native-CPU, sanitizer, sectioning, or SYCL driver flags into accelerator-language compilation under other feature combinations.

## Refactor

### Compiler and language isolation

`aesim_configure_target()` now uses generator-expression language gates:

- GCC variable tracking is restricted to `COMPILE_LANG_AND_ID:CXX,GNU`.
- Stack protection and `_FORTIFY_SOURCE` are restricted to host C++ compilation.
- Function/data sectioning is restricted to host C++ compilation.
- `-march=native` and `-mtune=native` are restricted to host C++ compilation.
- ASan/UBSan compile instrumentation is restricted to host C++ compilation while link instrumentation remains target-level.
- The SYCL `-fsycl` compile driver option is restricted to C++ sources, preventing conflict if SYCL and HIP are both detected.
- Strict numerical flags remain available to both C++ and HIP because ROCm Clang accepts them and they are part of the deterministic numerical contract.

### Transactional build and test workflow

A new `aesim_check` CMake target:

1. Depends on every buildable executable, static library, shared library, module library, and object library in the project directory.
2. Builds the complete graph first.
3. Runs CTest only after all dependencies complete successfully.
4. Preserves the primary compiler or linker diagnostic and prevents missing-executable cascades.

A new `tools/build_full_and_test.sh` wrapper provides validated options for build directory, build type, job count, clean rebuild, HIP discovery, and SYCL discovery. It uses `set -Eeuo pipefail` and invokes `aesim_check` transactionally.

### Regression protection

Two new source-level regressions were added:

- `hip_compile_option_isolation_regression`
- `build_transaction_workflow_regression`

They prevent reintroduction of the target-wide GCC/HIP flag leak and verify that the documented workflow cannot launch CTest after a failed build.

## Documentation updates

Updated:

- `README.md`
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`

The documents now use `aesim_check`, explain `CTEST_PARALLEL_LEVEL`, document the HIP compiler symptom, and explain why missing test executables are normally a build-cascade symptom rather than independent test failures.

## Validation

Validated on the available Linux toolchain:

- GCC 14.2 RelWithDebInfo configure: passed.
- Complete production and test build: passed.
- `aesim_industrial` focused build: passed.
- All registered CTest tests: 194/194 passed.
- Long regulatory-cycle tracking regression: passed in 123.45 seconds.
- New HIP option-isolation regression: passed.
- New transactional workflow regression: passed.
- Clang 17 RelWithDebInfo configuration: passed.
- Clang compile database contains no `-fno-var-tracking-assignments`: verified.
- Clang 17 `aesim_core` build: passed.
- Documentation consistency regression: passed.
- User-manual regression: passed.
- Source-package regression: passed before final packaging and rerun after report creation.

## HIP qualification boundary

The execution environment used for this repair does not contain a ROCm/HIP toolchain or GPU runtime, so an actual `.hip` object could not be compiled locally. The original failure is nevertheless addressed at the CMake generation layer: the offending GCC option is now conditioned on both the C++ language and GNU compiler identity, and a regression test rejects the previous target-wide form. The full corrected command should be verified once on the user's ROCm host with `tools/build_full_and_test.sh --clean --hip ON`.

## Compatibility

- Existing source files deleted: 0.
- Existing public APIs removed: 0.
- Existing features disabled: 0.
- HIP remains enabled by default when its compiler is detected.
- SYCL remains enabled by default when supported.
- The original standalone `cmake --build` and `ctest` workflow remains available; `aesim_check` is the safer combined path.

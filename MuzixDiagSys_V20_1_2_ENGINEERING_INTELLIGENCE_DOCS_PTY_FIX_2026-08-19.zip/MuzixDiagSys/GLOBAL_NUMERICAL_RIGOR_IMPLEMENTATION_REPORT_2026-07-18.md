# MuzixDiagSys Global Numerical Rigor Implementation Report

Date: 2026-07-18

## Request

Increase the rigor and accuracy of the mathematics globally, without stubs or placeholders and without removing existing functionality.

## Implementation strategy

The work was implemented as a cross-cutting numerical qualification layer rather than a disconnected new simulation subsystem. A shared core numerical kernel was added, every configured C++ target was placed under a strict floating-point policy, and high-impact local solvers and reductions were migrated to the common implementation. Existing physical models, public APIs, commands, plugins, packages, and tests were retained.

## Added files

- `include/aesim/core/numerical_rigor.hpp`
- `src/core/numerical_rigor.cpp`
- `tests/numerical_rigor_tests.cpp`
- `docs/GLOBAL_NUMERICAL_RIGOR.md`
- `GLOBAL_NUMERICAL_RIGOR_IMPLEMENTATION_REPORT_2026-07-18.md`
- `GLOBAL_NUMERICAL_RIGOR_VALIDATION_2026-07-18.txt`

## Build-system policy

`AESIM_ENABLE_STRICT_NUMERICS` defaults to `ON`.

- GCC/Clang targets use `-fno-fast-math -ffp-contract=off`.
- Microsoft Visual C++ targets use `/fp:strict`.
- `AESIM_STRICT_NUMERICS=1` is propagated through target interfaces.
- All 226 entries in the generated Linux `compile_commands.json` contain both strict flags.
- All concrete top-level libraries and executables are configured through `aesim_configure_target`.

## Shared numerical kernel

### Tolerance policies

Implemented `Fast`, `Engineering`, and `Qualification` policies with magnitude-scaled absolute, relative, pivot, rank, iterative-refinement, and equilibration controls.

### Stable accumulation and statistics

Implemented compensated summation, compensated dot products, scaled L2 norms, stable RMS, mergeable online moments through fourth order, and online covariance/correlation. These replace cancellation-sensitive accumulation in calibration, uncertainty, optimization, reliability, validation, and surrogate workflows.

### Dense linear algebra

The real dense solver implements row/column equilibration, scaled partial pivoting, long-double work, numerical rank detection, iterative refinement, residual and backward-error calculation, reciprocal-condition estimation, and pivot-growth reporting. The complex solver applies equivalent techniques to antenna, electromagnetic, and electrical-network systems. Dense inversion uses qualified solves against identity columns.

### Least squares

Implemented column-pivoted Householder QR with weighting, ridge regularization, rank detection, residual/RMS diagnostics, coefficient permutation recovery, condition estimation, and covariance.

### Numerical differentiation

Implemented five-point central differences and fourth-order one-sided differences near parameter bounds, with scale-aware steps, error estimates, and evaluation accounting.

### Roots, quadrature, and ODEs

Implemented Brent bracketed root finding, adaptive Gauss-Kronrod 15 quadrature, and adaptive Dormand-Prince 5(4) time integration with local error control and rejected-step reporting.

### Invariant auditing

Implemented combined absolute/relative invariant audits for conservation, energy, charge, probability, geometry, and other qualification quantities.

## Migrated implementation families

The shared numerical kernel was integrated into:

- core accuracy and design-of-experiments calculations;
- core calibration and covariance;
- core uncertainty propagation;
- automated assurance;
- measured validation and metrology;
- electrical and battery network solvers;
- Modelica nonlinear equation execution;
- sparse nonlinear, CFD, CHT, FSI, and assimilation routines;
- full-wave electromagnetic, antenna, thermal, and structural solvers;
- flexible-ring tire finite elements;
- raw-sensor calibration and Gauge R&R;
- Gaussian-process and Bayesian optimization;
- surrogate analytics and multi-fidelity prediction;
- rare-event FORM reliability analysis;
- state-space code generation and controller norms;
- Formula One aerodynamic correlation and calibration.

## Dynamic-system improvements

The general multibody implementation now advances quaternion attitude using an exponential-map increment and normalization instead of first-order componentwise Euler integration. Modelica Newton iterations use high-order Jacobians and qualified linear solves. Krylov solvers and residual tests use compensated products and scaled norms.

## Compatibility

No existing public class, function, command, plugin, schema, model format, FMI/SSP behavior, or test target was removed. `aesim/core/numerical_rigor.hpp` is also re-exported by `aesim/advanced/platform.hpp`.

## Qualification boundaries

The production API remains based on IEEE binary64 with long-double internal work where beneficial. It is not arbitrary-precision arithmetic. Improved numerical solution does not correct an invalid constitutive equation, poor boundary condition, inadequate mesh, unidentifiable parameter, or unrepresentative measurement. Model qualification still requires convergence studies, experimental correlation, uncertainty analysis, and applicability review.

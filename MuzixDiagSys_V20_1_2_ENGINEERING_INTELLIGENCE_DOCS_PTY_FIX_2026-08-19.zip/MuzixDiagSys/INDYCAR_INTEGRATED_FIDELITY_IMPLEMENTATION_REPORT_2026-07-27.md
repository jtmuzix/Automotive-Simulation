# IndyCar Integrated Fidelity Platform Implementation Report

**Date:** 2026-07-27  
**Module:** Sixth additive IndyCar production module  
**Focused library:** `aesim_indycar`  
**Aggregate library:** `aesim_advanced`

## 1. Scope

This change implements ten requested IndyCar capabilities as executable C++17
systems. No existing IndyCar source, public API, command family, test, example,
or documentation asset was removed. The implementation follows the project's
existing JSON request/result contract, deterministic evidence-digest behavior,
focused-library architecture, exception-based input rejection, and CTest
registration conventions.

The implemented capabilities are:

1. integrated multi-rate co-simulation;
2. telemetry assimilation and calibration;
3. full multibody vehicle dynamics;
4. detailed tire contact and thermo-mechanical evolution;
5. unsteady aeroelastic aerodynamics;
6. closed-loop ECU and hybrid control;
7. radio semantics and timing uncertainty;
8. multi-car pit-lane discrete-event simulation;
9. occupant, helmet, HANS, restraint, and egress biomechanics;
10. unified uncertainty quantification and model-validity supervision.

## 2. Source architecture

### Public API

- `include/aesim/advanced/indycar_integrated_fidelity_platform.hpp`

The public namespace is `aesim::advanced::indyint`. The focused test target is
`indycar_integrated_fidelity_platform_tests`. The ten domain classes are
`IndyCarIntegratedCoSimulationRuntime`,
`IndyCarTelemetryAssimilationCalibration`, `IndyCarFullMultibodyVehicle`,
`IndyCarDetailedTireContactModel`, `IndyCarUnsteadyAeroelasticAerodynamics`,
`IndyCarClosedLoopEcuHybridControl`,
`IndyCarRadioSemanticsTimingUncertainty`, `IndyCarPitLaneDiscreteEventTwin`,
`IndyCarOccupantBiomechanics`, and
`IndyCarUncertaintyModelValidityFramework`.
`IndyCarIntegratedFidelityPlatform` provides capability discovery, domain
dispatch, and deterministic self-test operation. The header is exported by
`include/aesim/advanced/platform.hpp`.

### Implementation

- `src/advanced/indycar_integrated_fidelity_internal.hpp`
- `src/advanced/indycar_integrated_fidelity_platform_a.cpp`
- `src/advanced/indycar_integrated_fidelity_platform_b.cpp`
- `src/advanced/indycar_integrated_fidelity_platform_c.cpp`
- `src/advanced/indycar_integrated_fidelity_platform_d.cpp`

The internal support layer implements strict JSON extraction, finite/range
validation, deterministic report finalization, atomic evidence writes, dense
linear algebra with pivoting, symmetric matrix operations, low-discrepancy
sampling, inverse-normal transformation, and quantile utilities. The source is
partitioned by domain to limit translation-unit size while preserving one
focused static library.

### Build and command integration

`CMakeLists.txt` compiles all four production translation units into
`aesim_indycar`, registers the C++ unit target and Python source regression, and
keeps transitive linkage through `aesim_advanced`. The advanced CLI adds the
`indycar-integrated` family without changing existing command dispatch.

## 3. Numerical implementations

### 3.1 Integrated co-simulation runtime

The scheduler advances one integer base-tick clock and requires controller,
vehicle, aero, thermal, and output periods to be exact multiples. This removes
fractional-rate drift and makes event counts reproducible. The runtime couples
vehicle velocity and attitude, tire capacity/temperature/wear, unsteady aero,
engine torque, boost, hybrid power/SOC, fuel energy, and thermal states. It
reports scheduler counts, checkpoints, extrema, energy balance, normalized
energy residual, and coupling residual. Excessive tick counts, invalid rate
ratios, non-finite states, and thermal limit violations are rejected or
reported explicitly.

### 3.2 Telemetry assimilation and calibration

The state estimator performs linear prediction and scalar measurement updates
in timestamp order. Normalized innovation squared gates outliers. Accepted
measurements use the Joseph covariance form to preserve covariance symmetry and
positive semidefiniteness. The calibration path solves weighted ridge
regression with optional priors using scaled pivoted elimination. Results expose
accepted/rejected counts, innovations, final state/covariance, parameters,
residuals, and conditioning evidence.

### 3.3 Full multibody vehicle

The vehicle model integrates twenty-two generalized coordinates covering six
chassis degrees of freedom, four unsprung vertical coordinates, four suspension
coordinates, and four wheel rotations. It establishes static suspension preload
before transient integration, couples spring/damper/anti-roll/bump-stop forces,
road height, aerodynamic loads, tire normal forces, wheel torque, and body
inertia, then advances states semi-implicitly. Load loss, excessive travel,
non-finite state growth, and invalid mass/inertia/geometry are diagnosed.

### 3.4 Detailed tire contact

The tire model combines longitudinal, lateral, and camber demand through a
smooth friction ellipse with transient relaxation. Friction depends on load,
pressure, temperature, wear, tread, water, and road state. Slip work and
hysteresis heat the tire; convection and conduction cool it. Gas-law pressure,
carcass deflection, contact area, wear, hydroplaning speed, cord stress, and
structural safety margin evolve with the sample history.

### 3.5 Unsteady aeroelastic aerodynamics

Quasi-steady targets depend on ride height, pitch, roll, yaw, steering, wheel
state, wake deficit, wall proximity, and gust. First-order aerodynamic lag and
bounded diffuser-stall/reattachment hysteresis represent transient flow.
Structural modes use mass, damping, stiffness, and generalized aerodynamic load
with an implicit velocity update. Modal deformation feeds back into force and
moment coefficients.

### 3.6 Closed-loop ECU and hybrid control

The controller includes driver torque interpretation, throttle and boost PI
loops with anti-windup, tire-utilization and traction limits, shift validation,
torque cuts, gear engagement, hybrid deployment/regeneration arbitration, SOC
protection, current/voltage constraints, pit-speed limiting, isolation checks,
and battery/inverter/coolant thermal derating. Every intervention and saturation
is retained in the output history.

### 3.7 Radio semantics and timing uncertainty

Radio messages are tokenized and classified into operational intents. Delivery
and comprehension probabilities use signal-to-noise ratio, clipping,
interference, packet loss, latency, workload, urgency, semantic match,
ambiguity, and read-back state. Critical comprehension failures become errors.
Timing observations are combined by inverse total variance, including clock and
quantization uncertainty, with 95-percent intervals and reduced-chi-square
consistency evidence.

### 3.8 Pit-lane discrete-event twin

A deterministic event scheduler enforces task dependencies, crew/tool/fuel and
pit-box resource availability, car arrival chronology, service duration, lane
occupancy, double stacking, and release traffic. The report records every task
start/finish, wait and service time, resource utilization, queueing, release
margin, unsafe-release findings, and the ordered event trace.

### 3.9 Occupant biomechanics

Head/helmet, thorax, and pelvis lumped states are integrated against a supplied
crash pulse. Harness, seat, HANS, headrest, and cockpit contacts use bounded
stiffness/damping laws. The result computes HIC15, normalized neck injury
criterion, chest acceleration/compression, femur load, harness/tether load,
head excursion, contact events, and self/assisted egress margins.

### 3.10 Uncertainty and model validity

Deterministic Halton samples are transformed to declared uniform or normal
marginals and correlated by a validated factor. A quadratic response model is
propagated to mean, standard deviation, quantiles, exceedance probability, and
ranked sensitivities. Model-validity supervision evaluates calibration distance,
residual bias/correlation, conservation drift, numerical error, model
disagreement, sensor innovation, and surrogate extrapolation against positive
thresholds, returning explicit mitigation actions when invalid.

## 4. Reliability and integrity controls

- All external numeric values are checked for finiteness.
- Dimensions, identifiers, chronology, topology, and physical parameters are
  validated before calculation.
- Solvers reject singular systems instead of returning fabricated results.
- Runtime sizes and tick counts are bounded.
- Every result receives a canonical SHA-256 evidence digest.
- Evidence files are written atomically when a working directory is supplied.
- Aggregate self-tests exercise every domain.
- Canonical JSON examples are parsed and executed by the C++ test target.
- Negative tests cover invalid chronology, non-integral scheduler rates,
  unknown domains, and validity-envelope extrapolation.

## 5. Tests and examples

New tests:

- `tests/indycar_integrated_fidelity_platform_tests.cpp`
- `tests/indycar_integrated_fidelity_source_regression.py`

New examples:

- `examples/indycar_integrated_fidelity/integrated_cosimulation.json`
- `examples/indycar_integrated_fidelity/telemetry_assimilation.json`
- `examples/indycar_integrated_fidelity/full_multibody.json`
- `examples/indycar_integrated_fidelity/tire_contact.json`
- `examples/indycar_integrated_fidelity/aeroelastic_aerodynamics.json`
- `examples/indycar_integrated_fidelity/ecu_hybrid_control.json`
- `examples/indycar_integrated_fidelity/radio_timing.json`
- `examples/indycar_integrated_fidelity/pit_lane_twin.json`
- `examples/indycar_integrated_fidelity/occupant_biomechanics.json`
- `examples/indycar_integrated_fidelity/uncertainty_validity.json`

## 6. Documentation

The following documentation was added or updated:

- `docs/INDYCAR_INTEGRATED_FIDELITY_PLATFORM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md` and generated PDF
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/DOCUMENTATION_INDEX.md`
- `README.md`
- `tests/user_manual_regression.py`

The detailed guide documents equations, request contracts, outputs, CLI usage,
evidence behavior, recommended workflows, and validation limits. Manual Chapter
57 integrates the module into the complete operator reference.

## 7. Compatibility statement

No existing feature was removed. Existing focused IndyCar libraries, headers,
classes, command families, examples, tests, and result schemas remain present.
The new module is additive and uses a separate namespace and domain family to
avoid collisions. The aggregate `aesim_advanced` target and advanced CLI expose
the new functionality transitively.

## 8. Engineering qualification boundary

The implementations are complete executable numerical models; they do not
claim vehicle-specific homologation or medical certification. Quantitative use
requires calibrated IndyCar geometry, inertias, suspension, Firestone tire,
aerodynamic, powertrain, controller, telemetry, communication, pit-lane, and
occupant data; mesh/time-step and parameter convergence studies; uncertainty
budgets; and independent validation throughout the intended operating envelope.

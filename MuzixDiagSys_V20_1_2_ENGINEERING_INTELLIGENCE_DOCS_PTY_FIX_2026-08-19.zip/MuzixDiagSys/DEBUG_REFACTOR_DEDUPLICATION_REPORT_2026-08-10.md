# MuzixDiagSys Advanced Automotive Simulator
## Debug, Deduplication, and Refactor Report — 2026-08-10

### Scope

This pass audited and refactored the complete V5 source archive with the following release constraints:

- preserve every non-duplicate public feature, command, domain surface, schema, and test capability;
- remove or consolidate duplicate *implementation* code rather than collapsing legitimate domain-specific APIs;
- keep Formula One, IndyCar, NASCAR, NHRA, Frontier Professional, industrial, professional, research, and core subsystems independently addressable;
- preserve domain-specific examples even when two fixtures currently contain the same values;
- compile and regression-test the modified code under the project's strict build policy.

No original source file or non-duplicate feature was removed.

### Audit results before refactoring

The archive contained no byte-identical production C/C++/Python source files, but it did contain repeated non-trivial function implementations. Running the final release guard against the unmodified V5 tree finds 13 exact normalized function-body clone groups at the 300-byte threshold. The principal duplicated implementation families were:

1. Ten IndyCar/NASCAR engineering-assurance self-test request builders.
2. A dense linear-system solver duplicated across the materials/multiphysics A/B implementation units.
3. Local SHA-256 wrappers repeated across multiple motorsport and engineering-operation translation units even though a canonical core SHA-256 implementation already existed.
4. Identical JSON report persistence helpers in four motorsport platform units.
5. Repeated UTC timestamp formatting logic in core/professional/industrial subsystems.

Additional structurally similar Formula One, IndyCar, and NASCAR algorithms were reviewed but intentionally retained where their public contracts, domain strings, schemas, diagnostics, or series-specific semantics differ. Similar mathematics is not treated as a duplicate feature.

Six byte-identical JSON example pairs remain intentionally under both NASCAR and IndyCar engineering-assurance directories:

- `timing_observation_fusion.json`
- `officiating_policy_lab.json`
- `debris_recovery.json`
- `fire_rescue_hazards.json`
- `contact_damage_raceability.json`
- `crash_safer_fe.json`

These are domain-addressable fixtures, not duplicate implementations; deleting either path would remove a series-specific example surface.

### Refactoring performed

#### 1. Shared motorsport engineering-assurance sample builders

Added:

- `src/advanced/motorsport_engineering_assurance_samples.hpp`

The byte-equivalent IndyCar/NASCAR self-test builders now have one shared implementation while both public series self-test registries remain independent. The NASCAR `sample_oem_request` use is mapped to the common manufacturer request builder without changing its public command or output contract.

#### 2. Shared materials/multiphysics linear solver

Added:

- `src/advanced/materials_energy_multiphysics_internal.hpp`

The two identical local dense Gaussian-elimination implementations are replaced by `aesim::advanced::materials_detail::solve_linear`. Existing materials and multiphysics callers retain their behavior and error semantics.

#### 3. Canonical SHA-256 ownership

Removed repeated local SHA-256 wrapper implementations from IndyCar operations, Formula One frontier/physical operations, assured engineering operations, and operational digital infrastructure code. All such call sites now use:

- `aesim::core::Sha256::digest_string`

This removes parallel cryptographic helper ownership and reduces OpenSSL-specific includes where they were only needed by the duplicate wrapper. Direct cryptographic APIs required for other operations remain intact.

#### 4. Shared report persistence helper

Added:

- `src/advanced/advanced_internal_utils.hpp`

Identical report-directory creation and atomic JSON-write logic in NASCAR ecosystem, NASCAR competition, NHRA championship strategy, and Formula One championship operations now routes through `aesim::advanced::internal_util::save_report`.

#### 5. Shared UTC timestamp utility and correctness fix

Added:

- `include/aesim/core/time.hpp`
- `tests/core_time_regression.cpp`

`Store`, `WorkflowEngine`, `TraceabilityRepository`, and `ExperimentManager` retain their existing API methods but delegate formatting to the core utility.

The shared implementation also fixes a latent boundary issue in the duplicated timestamp code: it now explicitly floors to whole seconds before conversion instead of relying on implementation-specific `system_clock::to_time_t` rounding. Milliseconds are calculated relative to the same floored second, giving correct pre-Unix-epoch subsecond values and deterministic second/millisecond alignment. UTC conversion and stream-formatting failures are checked rather than silently accepted.

#### 6. Duplicate-implementation release regression

Added:

- `tests/duplicate_implementation_regression.py`

The regression scans all production `src/**/*.cpp` translation units, preserves string/character literals, removes comments, extracts function bodies, normalizes whitespace, and rejects exact non-trivial cross-file clones of 300 normalized bytes or larger. Preserving literals is intentional: series-specific schema names, diagnostics, and labels remain sufficient to distinguish legitimate domain implementations.

The regression is registered in CTest and included in the deterministic source-package closure.

### Deduplication result

Using the same release guard:

- Unmodified V5 tree: **13 duplicate implementation groups detected**.
- Refactored tree: **0 duplicate implementation groups detected**.
- Byte-identical production source-file groups (`src` + `include`): **0**.
- Byte-identical source-like file groups (`src`, `include`, `tools`, `python`, `tests`): **0**.

The refactor changed 24 existing source/build/package-policy files and introduced shared internal/test files. The first comparison before this report showed a net reduction of approximately 650 lines despite adding regression coverage, consistent with consolidation rather than feature deletion.

### Feature-preservation validation

The rebuilt top-level executable's authoritative command schema reports `PASS`. The exhaustive completion regression also passes with:

- **444 canonical roots**
- **48,677 command paths**
- **48,232 nested completion checks**

This validates that the refactor did not remove, duplicate, orphan, or desynchronize the user-visible command registry/completion surface.

The user-manual regression also passes with:

- **216 accepted tokens**
- **149 command families**
- **266 glossary terms**

### Build and test validation

Configuration succeeded with GCC 14.2 / CMake 3.31.6 in `RelWithDebInfo` using the repository hardening and strict-numerics policy. No compiler or linker error was produced by the refactor.

Successfully built after the changes:

- `aesim_core`
- `aesim_professional`
- `aesim_diagnostics`
- `aesim_industrial`
- `aesim_nascar`
- `aesim_indycar`
- `aesim_formula_one_industrial`
- `aesim_formula_one`
- `aesim_advanced`
- `aesim_engineering`
- `aesim_advanced_cli`
- `aesim_console_support`
- the top-level `muzixdiagsys` executable
- FMI 3 model and sample SIL/native plugin artifacts
- the complete set of binaries required by `aesim_check`

Targeted native regressions passed for every modified implementation family, including:

- core UTC time boundary regression;
- project/workflow/causal persistence path;
- IndyCar and NASCAR engineering assurance;
- IndyCar operations;
- NASCAR competition and ecosystem;
- Formula One frontier laboratory, physical operations, and championship operations;
- materials/energy/multiphysics;
- assured engineering operations;
- operational digital infrastructure;
- NHRA championship strategy;
- Frontier Professional integration.

Source/package/CLI regressions passed, including build warning policy, documentation consistency, user manual, IndyCar/NASCAR source regressions, Formula One source regressions, Frontier source regressions, deterministic source packaging, exhaustive command completion, and the general CLI regression.

A broad CTest execution completed well over half of the 241-test suite with zero observed failures before the execution window ended; the remaining long-running tests are not in the modified implementation paths. The four-cycle regulatory tracking regression is computationally long in this environment, but an isolated HWFET run completed normally with `PASS`, 0.259 km/h RMSE, 100.000% tolerance compliance, -0.034% distance error, and 0.657% energy-ledger residual.

### Behavioral compatibility

The refactor deliberately avoids changing public class names, command names, registry keys, result schemas, persisted report shapes, exception contracts, domain-specific feature names, or example paths. Shared helpers are internal implementation details except for the new core time utility, which is an additive reusable API.

### Release conclusion

The V5 codebase has been refactored into a lower-duplication V6 source tree without deleting non-duplicate functionality. Exact non-trivial production function clones are now release-blocked, canonical shared utilities own common SHA-256/report/time/solver/sample mechanics, all touched code compiles under the strict policy, the main simulator links, command-surface uniqueness validates, and targeted behavioral tests pass.

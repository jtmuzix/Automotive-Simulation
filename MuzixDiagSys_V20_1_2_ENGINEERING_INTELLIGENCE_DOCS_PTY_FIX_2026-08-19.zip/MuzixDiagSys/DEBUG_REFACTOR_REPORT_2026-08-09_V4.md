# MuzixDiagSys Debug / Refactor Report — 2026-08-09 V4

## Compatibility policy

This pass preserves the existing simulator feature surface. No existing command family, vehicle/motorsport domain, platform module, CLI option, build option, API family, plugin interface, test family, or documented feature was removed.

The work is deliberately corrective: input validation, persisted-state integrity, path containment, and regression coverage were strengthened without replacing the existing architecture or reducing functionality.

## 1. Diagnostic command and SOVD input integrity

### Defect

The ELM327 and SOVD hexadecimal parsing paths filtered input by retaining hexadecimal characters and silently dropping other characters. As a result, malformed alphanumeric input could be transformed into a different valid request. For example, an invalid diagnostic string containing non-hexadecimal letters could become a valid OBD/UDS payload after those letters were discarded.

The SOVD OBD PID resource parser also used `std::stoul(..., nullptr, 16)`, which accepted a valid hexadecimal prefix followed by trailing garbage.

### Correction

- `src/industrial/virtual_diagnostics.cpp`
  - rejects non-hexadecimal alphanumeric characters instead of silently discarding them;
  - retains compatibility with existing punctuation/whitespace-delimited diagnostic input;
  - therefore preserves normal `010C`, `01 0C`, header, timeout, and protocol command forms while rejecting malformed alphabetic contamination.

- `src/industrial/diagnostic_service.cpp`
  - applies the same malformed-alphanumeric rejection to SOVD UDS payload parsing;
  - adds an exact one/two-digit hexadecimal byte parser for OBD PID resource identifiers;
  - rejects trailing garbage such as `0Cjunk` instead of interpreting only the `0C` prefix.

### Regression coverage

`tests/diagnostic_authority_tests.cpp` now verifies:

- normal ELM327 RPM requests still succeed;
- spaced ELM327 hexadecimal input still succeeds;
- malformed ELM327 hexadecimal payloads return `?`;
- malformed ELM327 protocol input returns `?`;
- malformed SOVD UDS hexadecimal payloads produce a bounded `400` response;
- malformed SOVD OBD PID resource identifiers produce a bounded `400` response.

## 2. Distributed checkpoint restoration and manifest integrity

### Defect A — empty metadata restoration

A checkpoint partition was allowed to contain no metadata. Such a partition serialized no `metadata` records, so the reloaded manifest did not necessarily contain an entry in `partition_metadata`. `restore_partition()` then used `.at(partition_id)`, causing an exception even though the checkpoint bytes and hashes were valid.

### Correction

`src/advanced/generalized_simulation_platform_a.cpp` now materializes an empty metadata map whenever a partition record is loaded. Empty metadata therefore round-trips as an empty map instead of failing restoration.

### Defect B — partial numeric parsing

Manifest fields used `std::stoull` / `std::stod` without requiring complete token consumption. A manifest whose hash had been recomputed could therefore contain values such as `7junk` and still parse the numeric prefix as `7`.

### Correction

Checkpoint manifest parsing now requires:

- exact unsigned-integer parsing for epoch values;
- exact finite floating-point parsing for simulation time;
- exactly one core `id`, `epoch`, `time`, and `manifest_hash` record;
- a syntactically valid SHA-256 manifest digest;
- syntactically valid SHA-256 partition digests;
- non-empty unique partition IDs;
- metadata records that reference a declared partition and non-empty key;
- no duplicate metadata keys for a partition.

### Defect C — checkpoint identifier path traversal

Checkpoint IDs were concatenated into a manifest path. An identifier containing parent-directory or path-separator components could escape the intended `manifests/` directory.

### Correction

Checkpoint IDs are now validated as safe single filename components before both checkpoint creation and manifest loading. Parent-directory traversal, forward-slash paths, backslash paths, dot components, and embedded NULs are rejected before filesystem access.

### Regression coverage

`tests/generalized_simulation_platform_tests.cpp` now verifies:

- checkpoint path traversal is rejected;
- partitions with empty metadata commit, verify, restore, and retain empty metadata;
- a manifest containing `epoch\t7junk` with a correctly recomputed SHA-256 is still rejected.

## 3. Collaboration repository revision-chain integrity

### Defect A — unsafe numeric conversion

Persisted revision numbers were converted from the document model's floating-point numeric representation directly to `std::uint64_t`. This did not explicitly reject non-finite, fractional, non-positive, or non-exact values before conversion.

### Correction

Revision parsing now requires a positive, finite, integral value within the exact-integer range of the document model before conversion.

### Defect B — weak revision filename trust boundary

Revision history was ordered using a numeric prefix parsed from filenames, but the canonical filename itself was not cross-checked against the revision number and digest stored in the persisted document. A valid revision document renamed to a forged digest-prefix filename could still pass the repository chain verification.

### Correction

The repository now:

- parses only canonical revision filenames of the form `<revision>-<16 hex digest prefix>.json`;
- performs exact decimal parsing of the filename revision number;
- rejects duplicate revision-number files;
- validates the persisted schema/version and core revision metadata;
- requires full SHA-256 digest syntax where applicable;
- verifies the filename revision number against the document revision number;
- verifies the filename digest prefix against the document digest;
- verifies the document artifact ID against the repository path requested by the caller.

### Defect C — repository path traversal

Artifact IDs were joined directly beneath the collaboration repository root. Parent-directory components could therefore escape the repository root.

### Correction

Artifact IDs are now validated as relative repository paths without root components, backslash traversal, NULs, or `.` / `..` path components. Legitimate nested repository IDs such as `subsystem/REQ-NESTED` remain supported.

### Regression coverage

`tests/validation_lifecycle_tests.cpp` now verifies:

- parent-directory traversal artifact IDs are rejected;
- canonical revision filename digest prefixes are treated as part of the integrity contract;
- a forged digest-prefix filename causes verification failure;
- restoring the canonical filename restores successful verification.

## 4. Refactoring and defensive-programming improvements

The pass introduced small purpose-specific parsing and path-validation helpers rather than duplicating unsafe conversion logic. The relevant code now fails early with domain-specific diagnostics at trust boundaries instead of relying on permissive standard-library prefix parsing or later incidental failures.

No numerical solver behavior, vehicle model, motorsport model, UI option, API command family, plugin interface, or simulation feature was removed or disabled.

## 5. Validation performed

The following qualification was performed on the supplied V3 archive after modification:

- clean CMake configure, GCC 14.2, Ninja, `RelWithDebInfo`, testing enabled: PASS;
- every modified C++ translation unit compiled with the project's strict warning policy: PASS;
- modified regression-test translation units compiled: PASS;
- `diagnostic_authority_tests` fully linked and executed: PASS;
- focused collaboration repository integrity harness linked against the real production object/libraries and executed: PASS;
- focused distributed checkpoint integrity/restoration harness linked against the real production object/libraries and executed: PASS;
- generalized simulation source regression: PASS;
- Formula One, IndyCar, NASCAR, Frontier, scientific-fidelity, mathematical-assurance, HIP option-isolation, and other source regressions exercised during the audit: PASS;
- build-warning policy regression: PASS;
- generated-artifact cleanup regression: PASS;
- documentation-consistency regression: PASS;
- user-manual regression: PASS;
- Python `compileall` over `python/`, `tools/`, and `tests/`: PASS.

A complete production `muzixdiagsys` RelWithDebInfo link was started from a clean build tree. The codebase contains several unusually large translation units and the bounded execution environment terminated long aggregate build invocations before completion. No compiler error was observed in the completed units, and all translation units changed by this V4 pass compiled successfully. The supplied V3 baseline includes its own prior complete Release-build qualification; this V4 report does not misrepresent the interrupted aggregate RelWithDebInfo build as a complete build.

See `DEBUG_REFACTOR_VALIDATION_2026-08-09_V4.txt` for the condensed validation record.

# Formula One Race-Engineering Platform Implementation Report

Date: 2026-07-18

## Scope

This release adds, without removing existing behavior:

1. Formula One suspension, steering, heave, and aerodynamic-platform control.
2. Carbon brakes, brake-by-wire, and wheel-end thermal physics.
3. Survey-grade circuit, weather, wake, and track digital twin.
4. Live telemetry, state estimation, and pit-wall engineering.
5. Reliability, damage, and component-allocation optimization.

## Source additions

- `include/aesim/advanced/formula_one_race_engineering.hpp`
- `src/advanced/formula_one_race_engineering.cpp`
- `tests/formula_one_race_engineering_tests.cpp`
- `docs/FORMULA_ONE_RACE_ENGINEERING.md`

## Integration changes

- Added the implementation to `aesim_advanced`.
- Added `formula_one_race_engineering_tests` and the CTest name `formula_one_race_engineering_unit_tests`.
- Added the public header to `include/aesim/advanced/platform.hpp`.
- Extended the README and authoritative Markdown manual.

## Behavioral correction during validation

The existing Formula One module already defined `F1PitWallDecision`. The new live-telemetry decision was renamed `F1LivePitWallDecision`, preserving the original public API and preventing an ODR/type collision.

## Suspension and platform-control implementation

The platform model integrates sprung-mass heave, pitch, and roll with four unsprung vertical degrees of freedom. Each corner contains nonlinear spring, asymmetric damping, bump and droop stops, tyre compliance, camber gain, and bump steer. Front and rear heave elements and anti-roll systems couple the corners. Longitudinal and lateral acceleration create pitch and roll moments, while aerodynamic and external corner loads feed the same equations. Steering includes ratio, torque compliance, and configurable Ackermann behavior. Results include ride height, clearance, bottoming, wheel lift, corner loads, plank wear, and deterministic evidence.

The setup engine replays a supplied lap load history for each candidate and ranks heave stiffness, anti-roll distribution, and ride-height changes using platform error, bottoming penetration, load variation, and plank wear.

## Carbon brake and BBW implementation

The brake model uses five thermal nodes per wheel end: disc, pad, caliper, rim, and tyre gas. It includes pressure dynamics, temperature- and wear-dependent carbon friction, front balance, migration, rear brake-by-wire response, MGU-K blending, hydraulic fallback, lockup margins, friction energy, recovered energy, wear, oxidation, flat spots, caliper limits, and brake-fluid boiling risk.

## Circuit and track-twin implementation

Survey points are validated, ordered, and resampled into spatial cells. Geometry retains position, elevation, banking, camber, roughness, drainage, and base grip. Spatial weather is interpolated along the lap. The evolution solver conserves local rainfall input and applies drainage, evaporation, spray removal, rubber deposition and wash-off, marbles, dust, oil, solar heating, convective cooling, and tyre-energy deposition. Query results include local grade and curvature. Wake evaluation returns downforce, drag, cooling, turbulence, and lateral-flow changes from speed, gap, offset, and crosswind.

## Live telemetry and pit-wall implementation

The live engineer maintains a deterministic ensemble of hidden race states. Telemetry assimilation updates tyre core temperatures, tyre wear, grip, fuel, electrical state, floor damage, power-unit health, cooling margin, brake wear, and uncertainty. Normalized innovations are retained as warning or critical anomalies. Pit-wall advice responds to tyre life, remaining laps, weather crossover, traffic, neutralization, cooling, reliability, and electrical state, and emits explicit driver messages, rationale, and an evidence hash.

## Reliability and allocation implementation

Components use serialized definitions with Weibull shape and characteristic life, temperature limits, thermal acceleration, shock tolerance, initial health, sealing, and grid-penalty data. Usage increments damage using Weibull hazard, thermal acceleration, loading, vibration, time, and shock. Discrete damage events incorporate severity, impact energy, and temperature. The allocation engine performs bounded beam search across sessions and serviceable components, minimizing championship-weighted failure risk, health consumption, and sealed-component change penalties.

## Validation summary

- Complete Debug configuration: passed.
- Complete project build and link: passed.
- Dedicated race-engineering suite: passed.
- Original Formula One suite: passed.
- Adjacent advanced-platform suites: passed.
- Registered CTest inventory: 132 tests.
- Observed passes: 127.
- Optional skip: 1.
- Observed assertion failures: 0.
- Four pre-existing heavy Debug workflows remained incomplete within bounded execution windows.
- All 89 Python source files compiled in memory.
- README and user-manual regressions passed.
- New source contains no unfinished-work markers or trailing whitespace.
- The regenerated manual contains 179 pages and passed visual inspection of the title and Formula One chapters.

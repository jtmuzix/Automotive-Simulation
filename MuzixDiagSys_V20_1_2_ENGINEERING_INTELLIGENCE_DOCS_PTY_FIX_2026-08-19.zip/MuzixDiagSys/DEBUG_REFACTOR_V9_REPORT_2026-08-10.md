# MuzixDiagSys V9 Debug / Refactor Report

Date: 2026-08-10  
Baseline: V8.1 Engineering UI Platform PTY corrective release  
Scope: repository-wide audit with focused terminal-input architecture refactor; no feature/option removal

## Executive summary

V9 preserves the complete V8.1 simulator, Engineering UI Platform, backend executables, interactive shell commands, aliases, dashboards, protocol tools, browser UI, and domain simulation features. The refactor concentrates on the terminal input subsystem because the immediately preceding failure exposed a class of parser/recovery and lock-order defects that warranted architectural hardening rather than a one-line timeout workaround.

The previously reported PTY self-deadlock remains fixed. V9 additionally removes quadratic Ctrl-C scanning from buffered input, prevents malformed UTF-8 from consuming the first byte of subsequent valid input, rejects impossible UTF-8 lead bytes without over-reading, extracts terminal decoding primitives from the monolithic console frontend, and adds independent lock-order/source regressions.

## Correctness defects fixed

### 1. Quadratic buffered-input interrupt scan

V8.1 searched the entire pending byte deque for Ctrl-C on every decoded byte. For a large paste/burst with no interrupt, consuming N bytes could perform O(N^2) comparisons. A 64 KiB collection window therefore had pathological worst-case input-processing cost.

V9 introduces `sim::console::terminal_input::InputQueue`. Ctrl-C position is indexed when bytes are appended. Ordinary byte consumption is O(1); the remaining queue is rescanned only after an actual interrupt is delivered. Existing semantics are preserved: stale bytes before Ctrl-C are discarded, the interrupt is delivered immediately, and bytes after the interrupt remain available.

### 2. Malformed UTF-8 consumed subsequent valid input

The old inline UTF-8 reader consumed the next byte before determining whether it was a valid continuation. If a malformed multibyte lead was followed by a printable character, that printable character was lost. For example, an invalid lead immediately before `quit` could turn the command into `uit`.

V9 replays a non-continuation byte to the normal input queue. The malformed codepoint is rejected, but the following valid command/control byte is preserved.

### 3. Invalid UTF-8 lead bytes over-read the stream

Lead bytes `C0`, `C1`, and `F5`-`FF` can never begin valid UTF-8. The previous reader classified them by bit shape and attempted to read continuation bytes before final validation.

V9 validates the lead range first (`C2`-`DF`, `E0`-`EF`, `F0`-`F4`) and rejects impossible leads immediately without consuming later input.

## Refactoring performed

New reusable production module:

- `include/aesim/app/terminal_input.hpp`
- `src/ui/terminal_input.cpp`

The module now owns:

- interrupt-aware terminal byte buffering;
- replay semantics;
- CSI/SS3 escape-sequence recovery;
- UTF-8 terminal-input assembly/recovery;
- function-key recognition;
- modified-key decoding.

`src/ui/console_frontend.cpp` now delegates these concerns to the module instead of embedding several large parser lambdas directly in the interactive loop. OS/PTTY polling remains in the frontend because it is platform/session orchestration, while deterministic parsing is independently testable.

## Regression hardening

### `terminal_input_unit_tests`

New native C++ coverage verifies:

- FIFO and replay ordering;
- single and repeated Ctrl-C preemption;
- preservation of post-interrupt suffix data;
- malformed CSI recovery;
- Ctrl-C recovery from CSI;
- valid four-byte UTF-8;
- non-continuation replay after malformed UTF-8;
- Ctrl-C replay from malformed UTF-8;
- immediate rejection of overlong/out-of-range UTF-8 leads;
- F-key recognition;
- modified-key recognition.

### `ui_lock_order_regression`

A new source regression scans the console frontend's lexical scopes and rejects calls to the outer `render()` lambda while `cout_mutex` is still held. This directly guards the self-deadlock pattern that caused the V8 PTY fuzz failure.

### Strengthened `ui_input_fuzz_pty`

The existing 12-second exit ceiling is unchanged. The test now additionally performs:

- a 48 KiB protected-paste burst to guard against quadratic byte-queue behavior;
- malformed UTF-8 immediately before `quit`, proving that the `q` byte is replayed rather than swallowed.

The original deterministic SGR mouse, beginner-menu, incomplete CSI, unterminated bracketed-paste, randomized fuzz, Ctrl-C recovery, and final shutdown coverage remains intact.

### Source-package closure

`source_package_regression.py` now explicitly requires the new terminal-input production files and both new regression surfaces so a future deterministic source archive cannot accidentally omit them.

## Feature preservation

No user-visible feature, command, backend executable, alias, dashboard, simulation model, UI workbench, protocol decoder, rendering mode, session feature, browser endpoint, or configuration option was removed.

The command/completion schema remains unchanged at 454 canonical roots, 51,227 literal paths, and 50,772 nested completion checks. All nine standalone backend/tool executables retain their interactive-shell parity routes.

## Validation summary

- Complete `aesim_test_artifacts` build: PASS.
- `terminal_input_unit_tests`: PASS.
- Terminal input module under ASan + UBSan: PASS.
- Terminal input module under GCC `-fanalyzer`: PASS.
- Strengthened `ui_input_fuzz_pty`: PASS repeatedly; CTest observed 6.92-7.60 s, below the unchanged 12 s process-exit requirement.
- UI lock-order regression: PASS across 62 `cout_mutex` scopes.
- Engineering UI source regression: PASS, all 20 feature families retained.
- All-command completion regression: PASS (454 roots / 51,227 paths / 50,772 nested checks).
- Backend executable CLI parity: PASS (9 executables / 9 direct roots).
- Duplicate implementation regression: PASS across 293 production translation units.
- Build-warning policy: PASS.
- Documentation consistency: PASS.
- Source-package regression: PASS.
- Python compile-all (`tests`, `tools`, `python`): PASS.
- Adjacent PTY regressions observed PASS: UI features, streamlined experience, modified keys, beginner menu/themes, NO_COLOR, preferences, professional workflow, completion detail scrolling, industrial-energy completion, all-command completion PTY, golden frames, lower-pane visibility, help focus, terminal resize/density, and terminal resize scroll anchoring.

A monolithic full CTest invocation was also exercised in execution-window-bounded chunks. No failure was observed among completed tests. The pre-existing regulatory-cycle tracking regression remains a long-running aggregate test with a 900-second CTest timeout and was not used as evidence for this UI/parser refactor.

## Changed production/test files

- `CMakeLists.txt`
- `include/aesim/app/terminal_input.hpp` (new)
- `src/ui/terminal_input.cpp` (new)
- `src/ui/console_frontend.cpp`
- `tests/terminal_input_tests.cpp` (new)
- `tests/ui_lock_order_regression.py` (new)
- `tests/ui_input_fuzz_pty.py`
- `tests/source_package_regression.py`


# NHRA Championship Strategy Platform Implementation Report

Date: 2026-07-29

## Scope

This additive implementation delivers seven complete NHRA domains:

1. National and divisional points.
2. Countdown simulation.
3. Mission #2Fast2Tasty Challenge.
4. Crew-chief optimization.
5. Causal run diagnosis.
6. Monte Carlo event strategy.
7. Historical and Heritage competition.

No existing source file, command, public API, test, dashboard, project format, or simulator feature was removed.

## Production source

- `include/aesim/advanced/nhra_championship_strategy_platform.hpp`
- `src/advanced/nhra_championship_strategy_platform.cpp`
- `tools/advanced_platform_cli.cpp`
- `include/aesim/advanced/platform.hpp`

The platform uses the established `doc::Value` request/report contract, atomic report writing, canonical JSON, and SHA-256 evidence generation. It adds no mandatory external dependency.

## Algorithms

### Points

Mission events combine elimination, participation, qualifying-position, and session-performance points. Lucas Oil events use class-specific claim windows, field-size tables, best-result selection, home/outside constraints, waiver handling, and explicit dropped-result reasons.

### Countdown

Regular-season rank is converted to the current reset spacing. Mission bonus points are carried into the reset. A seeded event model samples relative performance for each remaining event and reports championship probability and expected final points.

### Mission Challenge

Exactly four prior-event semifinalists are paired into rematches. Foul precedence and total package resolve each race. The final awards 3/2/1 points to winner, runner-up, and quickest losing semifinalist.

### Optimization

A deterministic seeded constrained search evaluates clutch rate, ignition, fuel, tire pressure, wheelie-bar height, and launch rpm. Infeasible candidates exceeding configured risk limits are discarded.

### Diagnosis

Synchronized telemetry is transformed into evidence scores for launch traction, shake, lane correction, fuel, lubrication, cylinder balance, driver lift, and shift timing. Scores allocate observed elapsed-time loss and generate a causal path and counterfactual.

### Event strategy

Each trial simulates all elimination rounds against stochastic opponent and weather conditions. Outcomes aggregate win advancement, failures, points, component cost, and user-weighted utility.

### Heritage

Data-driven period profiles validate year, mass, blower overdrive, electronics, and oil-down findings. Historical event generation selects starting-system and timing characteristics by year while retaining modern safety enforcement.

## CLI integration

The advanced-platform executable now supports:

```text
nhra capabilities
nhra self-test DIRECTORY
nhra DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The global advanced-platform capability inventory and complete self-test include the NHRA platform.

## Tests and documentation

Added:

- `tests/nhra_championship_strategy_platform_tests.cpp`
- `tests/nhra_championship_strategy_source_regression.py`
- `docs/NHRA_CHAMPIONSHIP_STRATEGY_PLATFORM.md`
- Chapter 62 of the user manual.
- Section 23 of the exact-command tutorial.
- Seven canonical JSON request examples.
- Documentation-index and README entries.

## Compatibility

The existing generic drag-racing branch remains unchanged. The NHRA layer is namespaced under `aesim::advanced::nhra` and linked additively into `aesim_advanced`.

## Qualification boundary

The platform is an engineering and strategy model. It is not an official rulebook, points ledger, event result, technical ruling, or certification service.

## Final qualification summary

- Complete RelWithDebInfo CMake/Ninja build graph: passed.
- NHRA production and source regressions: 2/2 passed.
- All seven example requests: passed through the production advanced-platform CLI.
- Documentation, user-manual, branding, README command audit, and source-package regressions: passed.
- Registered CTest tests: 205.
- Tests observed passing across complete and segmented runs: 203.
- Optional Python framework runtime test: skipped under its existing optional-dependency contract.
- Pre-existing `regulatory_cycle_tracking_regression`: did not complete within the execution environment's 300-second command ceiling; no failure was observed before termination. Its individual HWFET validation completed and passed.
- PDF manual: regenerated to 270 pages, preflighted, rendered, and visually inspected.
- New-source stub audit: no TODO, FIXME, placeholder, stub, or not-implemented markers.

# Formula One Championship Operations, Safety, Compliance, and Evidence Platform

## Scope

`FormulaOneChampionshipOperationsPlatform` adds ten executable Formula One operations and qualification domains to `aesim_advanced`. The implementation is additive and does not replace the existing Formula One vehicle, race-engineering, performance, team-competition, design-qualification, frontier, or physical-operations laboratories.

Public header:

```cpp
#include "aesim/advanced/formula_one_championship_operations.hpp"
```

Public CLI family:

```bash
muzixdiagsys_advanced_platform f1-operations ...
```

Every execution returns canonical JSON containing a schema identifier, calculated metrics, findings, a Boolean `passed` result, and a SHA-256 `evidence_digest`. When a working directory is supplied, the domain also writes a named evidence report atomically.

## Build and validate

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/full --parallel "$(nproc)"
ctest --test-dir build/full \
  -R formula_one_championship_operations_unit_tests \
  --output-on-failure
```

List the domain identifiers:

```bash
./build/full/muzixdiagsys_advanced_platform f1-operations capabilities
```

Run the integrated self-test:

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-operations self-test \
  build/full/f1-operations-self-test \
  build/full/f1-operations-self-test.json
```

Run one domain:

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-operations DOMAIN \
  REQUEST.json \
  OUTPUT.json \
  build/full/f1-operations-artifacts
```

The CLI exits with `0` when the report passes, `2` when the request executes but a qualification gate fails, `1` for invalid input or runtime errors, and `64` for invalid top-level command syntax.

## 1. Official timing, scoring, and classification

Domain: `timing-scoring`

The timing engine accepts circuit timing-loop definitions, entrants, raw primary or backup transponder hits, start-movement observations, and post-session penalties. It:

- sorts raw hits deterministically;
- merges duplicate primary/backup observations within a configurable tolerance;
- reconstructs laps from start/finish crossings;
- verifies intermediate timing-loop presence;
- rejects implausibly short or long laps;
- calculates completed laps, elapsed time, adjusted time, and fastest lap;
- detects start movement before lights out;
- accumulates multiple time and position penalties;
- applies disqualifications;
- applies classification-fraction eligibility; and
- certifies a winner only when a non-disqualified car completed a valid lap.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-operations timing-scoring \
  examples/formula_one_championship_operations/01_timing_scoring.json \
  build/full/timing.json \
  build/full/f1-operations-artifacts
```

Important output fields include `classification`, `winner_car_id`, `fastest_lap_car_id`, `duplicate_hit_count`, `missing_sector_sequences`, `start_findings`, and `classification_certified`.

## 2. Trackside safety, medical, recovery, and restart readiness

Domain: `trackside-safety`

The safety twin models a closed circuit as a loop and computes the shortest travel path from each available resource to an incident. Resources are typed as medical, fire, electrical, extrication, recovery, cleanup, barrier, or inspection units. The engine derives the required task graph from fire, high-voltage, trapped-driver, blockage, debris, spill, and barrier-damage inputs.

It calculates turnout, travel, task start, task duration, task completion, medical arrival, operational completion, and predicted red-flag duration. Restart readiness is denied when a required resource is missing, the medical-response target is exceeded, the evacuation chain is unavailable, or a required task cannot complete.

Example request: `examples/formula_one_championship_operations/02_trackside_safety.json`.

## 3. Cost-cap and financial-compliance forensics

Domain: `cost-cap-forensics`

The financial engine normalizes a ledger into a reporting currency, applies permitted exclusions, restores unsupported exclusions to relevant costs, adjusts related-party transactions to fair value, and calculates reported and adjusted relevant costs.

Forensic analysis includes:

- duplicate invoice candidates based on vendor, category, and amount;
- round-number concentration;
- vendor concentration;
- related-party under-valuation;
- unsupported exclusion value;
- period-completion forecast;
- cap headroom and forecast headroom;
- overspend; and
- a bounded anomaly score from zero to one hundred.

An execution fails when adjusted relevant costs exceed the cap or when an unsupported exclusion remains in the submitted ledger.

Example request: `examples/formula_one_championship_operations/03_cost_cap_forensics.json`.

## 4. Fuel and oil chemical certification

Domain: `fluid-certification`

The laboratory compares normalized reference and sample chromatographic peaks. Peaks are paired by compound identity or retention-time proximity. It calculates total-variation chromatographic similarity, unmatched or unknown compound fraction, and weighted cosine similarity for optional mass-spectral channels.

Additional gates cover fuel density, dielectric constant, renewable-carbon fraction, chain of custody, oil additive concentration, and wear-metal limits. The result reports fuel and oil certification separately and passes only when both are certified.

Example request: `examples/formula_one_championship_operations/04_fluid_certification.json`.

## 5. High-voltage ERS and MGU-K safety

Domain: `ers-safety`

The ERS solver models:

- series and parallel cell topology;
- state-dependent open-circuit voltage;
- pack resistance and current;
- Energy Store state of charge;
- cell and pack temperature;
- coolant heat rejection;
- pre-charge resistor and DC-link capacitor behavior;
- main-contactor state;
- insulation resistance;
- fuse I-squared-t accumulation;
- short-circuit current;
- inverter and MGU-K efficiency;
- MGU-K torque; and
- crash-triggered safe shutdown.

The engine opens the contactors and records fatal findings for insulation failure, fuse clearing, excessive cell temperature, or cell voltage outside the configured window.

Example request: `examples/formula_one_championship_operations/05_ers_safety.json`.

## 6. Driver cooling and Heat-Hazard qualification

Domain: `driver-cooling`

The driver-cooling model integrates core and skin thermal states, metabolic heat, core-to-skin conduction, cockpit convection, sweat evaporation, garment heat transfer, coolant temperature, pump power, and a finite thermal store. Pump failure, hose blockage, and coolant leakage reduce or remove cooling capacity.

Qualification requires the configured average heat-removal capacity, an acceptable core-temperature peak, and no detected cooling-system failure. The output also includes dehydration, electrical energy, minimum cooling rate, and thermal-store reserve.

Example request: `examples/formula_one_championship_operations/06_driver_cooling.json`.

## 7. Wet-weather spray and visibility

Domain: `wet-weather-visibility`

The spray model derives water pickup from tyre width, speed, surface-water depth, tyre evacuation efficiency, and rainfall deposition. Each leading car creates a spreading, decaying spray plume whose lateral position includes crosswind advection. Droplet mass concentration is converted to optical number density and Beer-Lambert extinction.

For every following car, the engine calculates meteorological visibility, camera transmission, lidar round-trip transmission, radar attenuation, apparent rain-light illuminance, adjusted aquaplaning speed, and aquaplaning ratio. It returns a recommended neutralization speed constrained by visibility and aquaplaning margin.

Example request: `examples/formula_one_championship_operations/07_wet_weather_visibility.json`.

## 8. Active-aero actuator and fail-safe qualification

Domain: `active-aero-actuation`

Each actuator has travel limits, velocity and acceleration limits, stiffness, damping, motor force constant, electrical resistance, thermal mass, cooling, backlash, and temperature limits. The time-domain solver integrates actuator position, velocity, current, heat, energy, tracking error, aerodynamic load, and left/right surface asymmetry.

Supported injected faults are `jam`, `runaway`, `sensor`, and `clear`. A detected fault commands the configured fail-safe position. Qualification verifies position tracking, thermal limits, surface asymmetry, and successful fail-safe positioning.

Example request: `examples/formula_one_championship_operations/08_active_aero_actuation.json`.

## 9. Physical scrutineering and anti-circumvention

Domain: `physical-scrutineering`

The scrutineering engine applies measurement uncertainty as a legal guard band. It evaluates minimum mass, regulated dimensions, plank thickness and wear, component seal identity, required fuel sample, and bodywork load-deflection behavior.

Load-deflection analysis calculates piecewise stiffness and detects large stiffness nonlinearity. Separate fast/slow and hot/cold measurements expose rate-sensitive or temperature-sensitive mechanisms. A test can therefore fail even when its nominal static deflection is below the legal limit.

Example request: `examples/formula_one_championship_operations/09_physical_scrutineering.json`.

## 10. Camera-generated sporting evidence

Domain: `camera-evidence`

The evidence engine accepts calibrated pinhole cameras with world poses and two-dimensional observations. Each image ray is transformed into world coordinates and intersected with the track plane. Multiple observations in the same time quantum are confidence-weighted into one reconstructed contact point.

The system:

- creates world-space evidence points;
- tests four tyre contact points against a legal-track polygon;
- detects pre-lights-out centroid movement;
- estimates centroid speed for pit-lane evidence;
- reports observation rejection; and
- gates evidence validity by average reconstruction confidence.

Example request: `examples/formula_one_championship_operations/10_camera_evidence.json`.

## Evidence and determinism

All reports are finalized by setting `evidence_digest` to an empty value, serializing the remaining report using canonical JSON, hashing that serialization with SHA-256, and then writing the resulting digest into the report. Identical requests and platform versions therefore generate identical evidence digests.

These models are engineering, pre-conformance, and qualification tools. They do not replace official FIA equipment, accredited chemical laboratories, financial auditors, stewards, medical authorities, or formal championship decisions.

## Motorsport CLI convenience aliases

The original `f1-operations` family remains authoritative. Additive suite routing is available through `f1 run operations DOMAIN ...`; shortcuts that target this family include `f1-scrutineering` -> `physical-scrutineering` and `f1-wet` -> `wet-weather-visibility`. See `MOTORSPORT_CLI_COMMANDS.md`.

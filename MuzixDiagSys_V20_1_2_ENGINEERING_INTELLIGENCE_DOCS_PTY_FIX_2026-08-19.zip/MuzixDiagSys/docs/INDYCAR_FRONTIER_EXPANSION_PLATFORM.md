# IndyCar Frontier Expansion Platform

**Revision:** 2026-07-22  
**Public header:** `aesim/advanced/indycar_frontier_expansion_platform.hpp`  
**Library:** `aesim_advanced`  
**Validation target:** `indycar_frontier_expansion_platform_tests`

## Purpose and compatibility

This module adds ten production implementations to the existing IndyCar IR-18, operations, and future-competition platforms. It is additive. No existing class, source file, target, command, or test was removed or renamed. Including `aesim/advanced/platform.hpp` exports the new API together with the prior advanced platform.

All public inputs enforce finite-value, identity, range, ordering, uniqueness, dimensional, and cross-reference invariants. Every successful analysis returns a deterministic SHA-256 evidence digest over its principal inputs and outputs. These digests provide reproducibility and content-integrity checking; they are not digital signatures or official homologation records.

## 1. 2028 2.4-liter power-unit co-design and homologation

`IndyCar2028PowerUnitLaboratory` evaluates a cylinder-resolved 2.4-liter twin-turbo V6 design over an arbitrary duty cycle.

The model resolves:

- declared and bore/stroke-derived displacement;
- four-stroke induction volume and pressure/temperature-corrected air mass flow;
- renewable-ethanol fuel flow and lower-heating-value energy;
- throttle, lambda, spark, volumetric-efficiency, and combustion-efficiency effects;
- speed-dependent friction mean effective pressure and pumping loss;
- positive or regenerative MGU shaft coupling;
- brake torque, brake power, brake thermal efficiency, and IMEP;
- compressor pressure ratio and speed;
- exhaust mass flow and turbine-inlet temperature;
- knock margin from compression, boost, intake temperature, lambda, and spark;
- deterministic per-cylinder peak-pressure variation and imbalance;
- rule-band evaluation for displacement, cylinders, speed, mass, power, temperature, compressor speed, cylinder balance, and knock margin.

Primary API:

```cpp
IndyCar2028PowerUnitResult IndyCar2028PowerUnitLaboratory::evaluate(
    const IndyCar2028PowerUnitDesign& design,
    const std::vector<IndyCar2028PowerUnitDutyPoint>& duty_cycle,
    const IndyCar2028PowerUnitHomologationRules& rules) const;
```

The result cannot be homologated when any design, duty-point, or derived limit is violated. Duplicate duty-point identifiers and inconsistent bore/stroke geometry are rejected before simulation.

## 2. MGU, inverter, and ultracapacitor electrothermal laboratory

`IndyCarHybridElectrothermalLaboratory` models the complete series-connected twenty-cell ultracapacitor ESS, MGU, inverter, bus, contactors, cooling, insulation monitoring, deployment, regeneration, and self-start behavior.

The solver includes:

- exactly twenty capacitor cells with capacitance and ESR variation;
- open-circuit pack voltage and series resistance;
- quadratic terminal-power/current solution including internal resistance;
- MGU torque-speed field weakening;
- inverter current limiting;
- MGU conversion, inverter conduction, switching, bus, contactor, and ESR losses;
- cell voltage integration and charge efficiency;
- cell, MGU, and inverter thermal states;
- coolant rejection and overtemperature protection;
- isolation-resistance and contactor interlocks;
- cell under/overvoltage protection;
- self-start energy and isolation qualification;
- equivalent-full-cycle throughput and temperature-accelerated remaining useful life.

The final state contains all twenty cell voltages and temperatures and can be passed directly into a subsequent mission.

## 3. Gearbox, bellhousing, clutch, and driveline durability twin

`IndyCarTransmissionDrivelineLaboratory` integrates the sequential gearbox and downstream driveline over a transient cycle.

Implemented physics and logic include:

- configurable gear and final-drive ratios;
- dog-ring speed matching and actuator-time qualification;
- completed and missed shifts;
- clutch capacity, slip speed, power, temperature, and wear;
- gearbox mesh loss and oil temperature;
- shaft torsional stiffness, damping, and twist response;
- differential preload, lock fraction, and left/right wheel-speed bias;
- gear and halfshaft Miner-style fatigue accumulation;
- inertial bellhousing load and margin;
- oil, clutch, fatigue, wear, and structural failure decisions.

Gear indices are one-based in the public cycle input. A shift does not complete unless both speed synchronization and actuation duration satisfy the configured limits.

## 4. Hydraulic brake-system and carbon-brake laboratory

`IndyCarBrakeSystemLaboratory` models the pedal box, master cylinder, hydraulic compliance, calipers, carbon discs, pads, brake ducts, fluid, wheel slip, and regenerative blending.

The implementation calculates:

- pedal-force-to-master-pressure conversion;
- knock-back volume and line-compliance pressure loss;
- front/rear pressure balance;
- temperature-dependent pad friction;
- front and rear friction torque;
- rear-axle regenerative torque blending;
- longitudinal deceleration;
- front/rear wheel-slip and lock-risk detection;
- carbon-disc heating and duct-dependent cooling;
- fluid-temperature response and boiling margin;
- pedal travel;
- pad and disc wear;
- disc-temperature fade margin and serviceability.

The brake result records every event, thermal peak, wear fraction, detected fault, and evidence digest.

## 5. Laser-scanned track, grip evolution, and weather digital twin

`IndyCarTrackEnvironmentTwin` evolves a longitudinal/lateral laser-scanned mesh under weather and vehicle traffic.

Each mesh point supports asphalt, concrete, sealer, paint, or patch material and carries elevation, roughness, macrotexture, drainage slope, base friction, and solar absorptivity.

The time-ordered solver models:

- solar heating, cloud attenuation, convection, and evaporation;
- rainfall input, slope/texture drainage, and water-film depth;
- rubber deposition, rain wash-off, marbles/contaminant coverage, and cleaning;
- tire-energy heating;
- vehicle and dedicated drying displacement of surface water;
- material, temperature, rubber, water, texture, and contamination friction factors;
- local slope/bump severity;
- hydroplaning-speed estimate;
- local crosswind;
- dry-line fraction and hazard classification.

Unknown mesh references, unsorted geometry, non-monotonic weather times, and events beyond the simulation interval are rejected.

## 6. Full-field agent-based racecraft and raceability engine

`IndyCarFullFieldCompetitionEngine` simulates two to thirty-five independent cars over a configured road/street, short-oval, or superspeedway event.

Each driver has skill, aggression, defensive tendency, tire management, fuel-saving skill, restart skill, reliability, team, manufacturer, qualifying pace, and pit interval.

The deterministic fixed-seed simulation includes:

- qualifying-order initialization;
- lap-by-lap tire degradation and fuel-saving cost;
- road-course wake loss and oval tow gain;
- attack/defense decisions;
- team and manufacturer cooperation effects;
- restart skill and field compression;
- pit-stop cycles and pit loss;
- reliability retirement probability;
- field-wide cautions;
- classification, lap records, overtakes, lead changes, pit stops, incidents, and field spread;
- normalized raceability index combining passing, lead changes, and field compression.

The same inputs and seed produce the same evidence digest and classification.

## 7. Synchronized video, telemetry, and incident reconstruction

`IndyCarIncidentReconstructionPlatform` fuses calibrated camera detections and vehicle telemetry into a synchronized evidence trajectory.

Implemented evidence processing includes:

- per-camera offset and clock-drift correction;
- invertibility checks for each 3 x 3 pixel-to-track homography;
- confidence-weighted pixel uncertainty propagation;
- conversion from image coordinates to track coordinates;
- weighted fusion of observations within a 25 ms window;
- telemetry position, speed, heading, brake, and steering fusion;
- finite-difference speed/heading recovery for video-only points;
- temporally aligned minimum-separation search;
- relative closing speed and reduced-mass contact energy;
- contact-visible evidence override;
- reconstruction uncertainty;
- primary/secondary avoidability scores;
- explicit contact, near-miss, uncertainty, and attribution findings.

At least two cars with temporally overlapping evidence are required.

## 8. Pit-lane computer-vision officiating

`IndyCarPitLaneVisionOfficiating` fuses frame-level visual detections with pit-loop speed observations and assigned pit-box geometry.

It detects and coalesces:

- pit-lane speeding;
- entry-line and exit-line violations;
- entry while the pits are closed;
- wrong-box service;
- service outside the assigned box;
- unsafe release into another car's conflict envelope;
- crew over the wall before the car is safely stopped;
- excess crew;
- uncontrolled wheels;
- movement while the fuel probe remains connected;
- release with wheel service incomplete or air jacks active;
- adjacent-box interference;
- pit-lane blockage.

Each finding contains type, car, interval, severity, confidence, and evidence references. Continuous detections of the same offense are merged rather than counted as independent penalties.

## 9. Appeals, protests, precedent, and officiating audit compiler

`IndyCarAppealsPrecedentPlatform` performs a procedural and precedent-based appeal review.

The platform validates:

- rule identity, jurisdiction, appealability, filing window, and penalty range;
- filing identity, timing, fee, conflict disclosure, facts, evidence, and tags;
- unique, validated precedent cases;
- sporting, technical, safety, and hybrid/powertrain jurisdiction.

Precedent similarity combines rule identity, jurisdiction, tag Jaccard similarity, facts severity, and evidence strength. Similar cases are squared-weighted to calculate a precedent-normalized penalty. The decision engine can dismiss, uphold, modify, accept, or remand a filing and can grant a stay when the procedural and evidence conditions are met.

Two evidence records are emitted:

- `public_decision_digest` binds the publishable decision and cited precedents;
- `complete_audit_digest` additionally binds procedural details and source-case digests.

## 10. Complete Indianapolis 500 Month-of-May operations twin

`Indy500CompleteMonthOfMayOperationsTwin` simulates the complete event programme rather than only a single qualifying or race calculation.

Supported session types are:

- Open Test;
- Rookie Orientation;
- Refresher;
- Practice;
- Fast Friday;
- Qualifying Day One;
- Top Twelve;
- Fast Six;
- Last Chance;
- Carb Day;
- Pit Stop Challenge;
- Race.

The programme resolves:

- non-overlapping session chronology;
- weather-interrupted track availability;
- per-session run capacity;
- engine-mileage, tire-set, programme-budget, and track-time constraints;
- rookie/refresher phase progress;
- practice learning and readiness;
- Fast Friday and qualifying boost effects;
- four-lap-average speed consistency;
- provisional order, Top Twelve, Fast Six, Last Chance, grid, and bumped entries;
- Carb Day readiness;
- Pit Stop Challenge times and winner;
- 200-lap race pace, caution allowance, pit-stop plan, reliability exposure, and expected duration;
- post-programme mileage, tires, budget, readiness, entry issues, and event readiness.

A fixed seed makes weather realization and performance variation reproducible.

## Build and validation

Configure a focused development build:

```bash
cmake -S . -B build/indy-frontier -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_ENABLE_NATIVE_OPTIMIZATION=OFF
```

Build the focused production module and test executable through `aesim_indycar`. The aggregate `aesim_advanced` target links this library publicly, so existing aggregate consumers remain source-compatible:

```bash
cmake --build build/indy-frontier --target \
  aesim_indycar \
  indycar_frontier_expansion_platform_tests --parallel "$(nproc)"
```

Run the new test:

```bash
ctest --test-dir build/indy-frontier --output-on-failure \
  -R '^indycar_frontier_expansion_platform_unit_tests$'
```

Run every IndyCar regression:

```bash
cmake --build build/indy-frontier --target \
  indycar_platform_tests \
  indycar_operations_platform_tests \
  indycar_future_competition_platform_tests \
  indycar_frontier_expansion_platform_tests \
  --parallel "$(nproc)"

ctest --test-dir build/indy-frontier --output-on-failure \
  -R '^indycar_.*_unit_tests$'
```

Direct include:

```cpp
#include "aesim/advanced/indycar_frontier_expansion_platform.hpp"
```

Umbrella include:

```cpp
#include "aesim/advanced/platform.hpp"
```

## Qualification boundaries

These models are engineering simulations. They do not replace supplier drawings, official rule interpretations, accredited dynamometer or metrology work, trackside officiating, medical review, or series homologation. Camera-derived findings require calibrated evidence and human review. Appeal recommendations are consistency analysis, not legal decisions. Vehicle, electrical, brake, and race-operation outputs must be correlated against controlled physical data before safety-critical use.

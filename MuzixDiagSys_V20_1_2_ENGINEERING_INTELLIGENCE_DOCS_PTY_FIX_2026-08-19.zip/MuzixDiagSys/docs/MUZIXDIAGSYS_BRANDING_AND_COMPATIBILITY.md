# MuzixDiagSys branding and compatibility

The program is named **MuzixDiagSys**. The primary executable is `muzixdiagsys`, and the primary manuals are `docs/MUZIXDIAGSYS_USER_MANUAL.md` and `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`.

To avoid removing functionality, the release retains these legacy technical interfaces:

- The build creates an `engine_sim` compatibility launcher beside `muzixdiagsys`.
- Existing `AESIM_*` CMake options and environment variables remain accepted.
- New `MUZIXDIAGSYS_*` aliases are accepted for project root, powertrain catalog, and UI preferences.
- Existing `aesim::` C++ namespaces, `aesim.*` schema identifiers, FMI identifiers, plugin ABI symbols, and serialized format identifiers remain stable.
- Existing `.engine_sim_history` and `.engine_sim_ui_preferences` files are read as migration fallbacks; new state is written under the MuzixDiagSys names.

These retained identifiers are compatibility contracts, not the displayed product name.

# Formula One Industrial and Ecosystem Platform

**Release:** 2026-07-25  
**Library:** `aesim_formula_one_industrial`  
**Formula One integration:** public dependency of `aesim_formula_one`  
**CLI family:** `muzixdiagsys_advanced_platform f1-industrial`

This module adds ten Formula One-only systems for power-unit financial governance, tyre-supplier production, advanced sustainable fuel, factory manufacture, vehicle assembly, causal race engineering, aerodynamic rule-package design, garage cybersecurity and RF resilience, driver medical performance, and the F2/F3/F1 Academy development ladder.

It does not replace or alter the existing Formula One engineering, race-engineering, performance, team-competition, design-qualification, frontier, physical-operations, championship-operations, or regulatory-competition APIs. It does not add source to `aesim_indycar` or `aesim_nascar`.

## Public API

```cpp
#include "aesim/advanced/formula_one_industrial_ecosystem_platform.hpp"
```

The public classes are:

- `F1PowerUnitFinancialCompliancePlatform`
- `F1TyreProductionMetrologyPlatform`
- `F1SustainableFuelProductionLaboratory`
- `F1FactoryManufacturingTwin`
- `F1VehicleAssemblyVariationTwin`
- `F1CausalRaceEngineeringOptimizer`
- `F1AerodynamicRaceabilityDesignLaboratory`
- `F1CyberPhysicalSecurityLaboratory`
- `F1DriverMedicalPerformanceLaboratory`
- `F1DriverDevelopmentLadderPlatform`
- `FormulaOneIndustrialEcosystemPlatform`

Each domain accepts a `doc::Value` request and returns a canonical JSON-compatible `doc::Value`. Every report contains `passed`, `findings`, and a 64-character `evidence_digest`. Supplying a working directory writes the report atomically.

## Build and validation

```bash
cmake -S . -B build/f1-industrial -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_MAX_PARALLEL_COMPILES=4
cmake --build build/f1-industrial --parallel --target \
  aesim_formula_one_industrial \
  formula_one_industrial_ecosystem_platform_tests
ctest --test-dir build/f1-industrial --output-on-failure \
  -R '^formula_one_industrial_ecosystem_platform_unit_tests$'
```

`AESIM_MAX_PARALLEL_COMPILES` defaults to `4` for Ninja generators. It caps
simultaneous C++ compiler processes while preserving the caller's requested
parallelism for linking and custom commands. This prevents memory exhaustion
when feature-dense translation units are built with an unrestricted
`cmake --build --parallel`. Set it to `0` to use Ninja's unbounded generator
default, or lower it on memory-constrained systems.

Sanitizer validation:

```bash
cmake -S . -B build/f1-industrial-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build/f1-industrial-sanitize --parallel --target \
  formula_one_industrial_ecosystem_platform_tests
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=print_stacktrace=1 \
ctest --test-dir build/f1-industrial-sanitize --output-on-failure \
  -R '^formula_one_industrial_ecosystem_platform_unit_tests$'
```

## CLI usage

```bash
./build/full/muzixdiagsys_advanced_platform \
  f1-industrial capabilities \
  build/f1-industrial-capabilities.json

./build/full/muzixdiagsys_advanced_platform \
  f1-industrial self-test \
  build/f1-industrial-evidence \
  build/f1-industrial-self-test.json

./build/full/muzixdiagsys_advanced_platform \
  f1-industrial DOMAIN \
  examples/formula_one_industrial_ecosystem/REQUEST.json \
  build/RESULT.json \
  build/f1-industrial-evidence
```

The ten domains are:

```text
pu-financial-compliance
tyre-supplier-production
sustainable-fuel-production
factory-manufacturing
vehicle-assembly-variation
causal-setup-intelligence
aero-raceability-design
cyber-rf-resilience
driver-medical-performance
driver-development-ladder
```

## 1. Power-unit manufacturer financial compliance

Use `F1PowerUnitFinancialCompliancePlatform` or `pu-financial-compliance`.

### Inputs

- Manufacturer and reporting-period identity.
- Cost cap and declared relevant cost.
- Ledger entries with original currency, exchange rate, Formula One PU allocation fraction, category, exclusion status, evidence status, related-party status, arm's-length support, and capital-expenditure classification.
- Reconciliation tolerance.

### Processing

The platform converts and allocates every ledger entry, separates permitted exclusions from relevant cost, identifies invalid exclusions, tests related-party support, reconciles the classified ledger to the declared submission, calculates headroom, and distinguishes compliant, minor-overspend, and material-overspend states.

### Outputs

- Classified ledger.
- Relevant and excluded cost.
- Related-party and capital-expenditure totals.
- Reconciliation discrepancy.
- Cost-cap headroom.
- Overspend classification and procedural findings.

The model is an audit and scenario-analysis system. It does not issue a Cost Cap Administration decision.

## 2. Pirelli production, batch, allocation, and metrology

Use `F1TyreProductionMetrologyPlatform` or `tyre-supplier-production`.

The platform verifies unique batch and tyre identities, compound/specification, produced quantity, dimensional error, radial- and lateral-force variation, mass variation, cure temperature, material traceability, X-ray status, shearography status, production capacity, and entrant allocation. Failed batches are quarantined and cannot contribute to available allocation inventory.

Release limits are validated before any batch is processed. Maximum dimensional, force-variation, and mass-error limits must be nonnegative; cure-temperature limits must form an ordered positive interval; and the minimum traceability fraction must lie in `[0, 1]`. Outputs include production utilization, release yield, quarantined quantity, weighted material traceability, allocation records, and specification-specific shortages.

## 3. Advanced sustainable fuel synthesis and lifecycle

Use `F1SustainableFuelProductionLaboratory` or `sustainable-fuel-production`.

Feedstock mass fractions must sum to one and each feedstock must be qualifying and traceable. Process steps define energy input, fuel-energy output, and energy-source carbon intensity. Blend components define volume fraction, density, research octane number, lower heating value, latent heat, and oxygen content.

The laboratory rejects duplicate feedstock, process-step, and blend-component
identifiers. It calculates each process-step efficiency and the aggregate
process efficiency as useful fuel energy divided by total supplied process
energy, together with lifecycle carbon intensity, final blend properties,
qualifying feedstock fraction, and release findings against declared density,
octane, energy-density, and carbon-intensity limits. Density and lower-heating-value
windows are validated as ordered positive intervals before evaluation, and all
aggregate energy and carbon calculations must remain finite.

## 4. Formula One factory and manufacturing digital twin

Use `F1FactoryManufacturingTwin` or `factory-manufacturing`.

The request contains inventory, work centers, task dependencies, capacity requirements, durations, required parts, variable cost, carbon, and release deadline. The scheduler validates a directed acyclic dependency graph, waits for dependencies, checks all parts before admission, consumes inventory only after successful task admission, and blocks downstream work after a failure. Independent tasks can execute concurrently when the work center has sufficient parallel lanes; each task reserves exactly its declared `resource_units` for its duration.

Reports contain task start/finish times, makespan, remaining inventory, cost, carbon, release margin, and explicit blocked/failed-task findings.

## 5. Vehicle assembly, datum, and dimensional variation

Use `F1VehicleAssemblyVariationTwin` or `vehicle-assembly-variation`.

Datums provide subsystem, nominal measurement, actual measurement, tolerance, and instrument uncertainty. Operations provide dependencies, duration, torque target, actual torque, tolerance, and mandatory status.

Instrument uncertainty must be strictly smaller than the datum tolerance, and
actual torque must be nonnegative. The twin reports uncertainty-adjusted
normalized datum error, root-sum-square dimensional stack, predicted
scrutineering margin, out-of-tolerance count, operation chronology, torque
compliance, and total assembly duration.

## 6. Causal race engineering and setup intelligence

Use `F1CausalRaceEngineeringOptimizer::optimize` or `causal-setup-intelligence`.

Observations contain setup identity, lap time, fuel mass, track temperature, traffic loss, tyre age, and driver-learning fraction. The optimizer performs ridge-regularized covariate adjustment, calculates setup-specific residual effects relative to a declared baseline, estimates standard error, applies engineering-constraint penalties, and ranks candidates with an uncertainty-aware decision score.

The output distinguishes causal effect estimates from raw lap-time differences and exposes the regression coefficients, residual noise, sample counts, uncertainty, penalties, and recommended setup. Normal-equation accumulation, elimination, prediction, residual, and decision-score arithmetic are finite-checked so extreme inputs cannot leak NaN or infinity into the evidence report.

## 7. Aerodynamic raceability and rule-package design

Use `F1AerodynamicRaceabilityDesignLaboratory` or `aero-raceability-design`.

Circuit profiles contain straight/corner fractions, baseline passing probability, and Overtake Mode energy sensitivity. Package profiles contain drag, downforce, following-car loss, Straight Mode drag reduction, wake recovery length, liftoff margin, manufacturer spread, and electrical overtake advantage.

The laboratory calculates circuit-level pass probability, field-convergence index, aerodynamic efficiency, safety/parity compliance, and a multi-objective design score. Weighted aggregation, efficiency, and score arithmetic are finite-checked. Selection is compliance-first: the highest-scoring compliant package is selected whenever one exists, regardless of the score of an unsafe or parity-violating alternative. A package cannot pass when every available option violates the declared liftoff, manufacturer-spread, or minimum-passing constraints.

## 8. Garage cybersecurity and RF resilience

Use `F1CyberPhysicalSecurityLaboratory` or `cyber-rf-resilience`.

Nodes define approved firmware and calibration identities, secure boot, authentication, and debug-interface state. Links define topology, medium, bitrate, frame loading, packet loss, encryption, redundancy, and RF link-budget parameters where applicable. Attack scenarios define target, likelihood, impact, detection probability, and containment probability.

Outputs include node trust, link utilization, RF SNR margin, link resilience, attack residual risk, and aggregate qualification score. Firmware/calibration tampering, missing trust controls, overloaded buses, excessive loss, unencrypted links, inadequate RF margin, or unacceptable residual attack risk causes failure.

## 9. Driver physiology, medical, and emergency egress

Use `F1DriverMedicalPerformanceLaboratory` or `driver-medical-performance`.

Stints define cockpit environment, duration, lateral load, brake and steering effort, hydration, and cooling. Emergency inputs define egress time, fire/smoke exposure, high-voltage state, and medical resources.

The laboratory estimates core temperature, hydration reserve, reaction-time degradation, cumulative neck/brake/lateral exposure, heat-strain index, injury-exposure index, egress compliance, high-voltage isolation, and fastest available medical response. When no medical resource is available, the report remains valid canonical JSON, sets `medical_response_available` to `false`, and emits `null` for `fastest_medical_response_time_s` instead of attempting to serialize infinity.

These outputs support virtual engineering and emergency planning. They are not diagnoses, medical clearance, or treatment recommendations.

## 10. F2, F3, F1 Academy, and driver development

Use `F1DriverDevelopmentLadderPlatform` or `driver-development-ladder`.

Drivers provide academy identity, age, Super-Licence points, budget, medical fitness, rookie status, simulator correlation, FP1 readiness, and results from F2, F3, F1 Academy, Formula Regional, or F4. Seats provide role, preferred academy, required budget, and Super-Licence requirement.

The platform normalizes performance by series level, combines pace, consistency, wet-weather skill, tyre management, simulator correlation, and FP1 readiness, and tests age, medical fitness, rookie status, budget, and Super-Licence eligibility. It then solves a global bipartite assignment problem that first maximizes the number of filled seats and then maximizes total assignment score. This removes request-order dependence while preserving deterministic output order. Medically unfit candidates are never assigned, an `fp1-rookie` seat can only be filled by a declared rookie, and each driver can fill at most one seat. Reports identify the strategy as `maximum-cardinality-maximum-score`.

## Evidence and determinism

Every output is finalized using canonical JSON and SHA-256. The digest is generated after the evidence field is cleared, making repeated identical requests produce identical evidence. Reports written to a working directory use atomic replacement.

## Validation and failure semantics

The compiled suite verifies all ten nominal requests plus:

- Invalid financial exclusions.
- Tyre allocation beyond released inventory.
- Invalid or inverted tyre metrology and cure-temperature limits.
- Untraceable sustainable feedstock.
- Duplicate sustainable-fuel identities, process-efficiency consistency, and inverted release windows.
- Manufacturing dependency cycles.
- Failed-task inventory conservation.
- Parallel work-center scheduling and duplicate part rejection.
- Out-of-tolerance assembly datums.
- Measurement uncertainty that consumes the full datum tolerance.
- Deterministic causal setup recommendation and non-finite regression rejection.
- Compliance-first aerodynamic selection, duplicate circuits, and non-finite score rejection.
- Firmware tampering.
- Unisolated high-voltage medical response.
- No-available-medical-resource canonical report generation.
- Race-seat assignment without Super-Licence eligibility.
- Medical-fitness and FP1-rookie seat eligibility.
- Global seat-allocation cardinality, score optimization, and seat-order independence.
- Unknown-domain rejection.

## Qualification boundary

The platform provides research, development, training, audit preparation, and virtual qualification evidence. It does not issue FIA financial findings, release physical tyres or fuel, certify a manufacturing process, approve a car, prescribe setup, approve technical regulations, authorize garage networks, grant medical clearance, or issue a Super Licence.

## Motorsport CLI convenience aliases

The original `f1-industrial` family remains authoritative. Additive suite routing is available through `f1 run industrial DOMAIN ...`; shortcuts include `f1-aero`, `f1-setup`, and `f1-driver`. See `MOTORSPORT_CLI_COMMANDS.md`.

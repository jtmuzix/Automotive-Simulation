# NASCAR Competition Platform

> **2026-07-28 additive assurance module:** The separate `nascar-assurance` command and `NascarEngineeringAssurancePlatform` add regulation digital-thread resolution, dynamic compliance, prospective-OEM management, timing observation fusion, officiating policy analysis, progressive contact damage, crash/SAFER elements, fire/rescue hazards, debris recovery, composite manufacturing, fleet reliability, and optimal test design. Existing contracts in this guide are unchanged. See `docs/NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 59 of the user manual.
**Revision:** 2026-07-22  
**Build architecture:** competition, ecosystem, and frontier implementations are compiled into `aesim_nascar`; `aesim_advanced` links that library publicly.

## Additive NASCAR integrated-fidelity module

The 2026-07-27 source tree also provides the separate `nascar-integrated` command and `NascarIntegratedFidelityPlatform`. Its twelve domains add deterministic multi-rate co-simulation, telemetry assimilation/calibration, unified uncertainty and model-validity supervision, a 28-DOF flexible vehicle, detailed asymmetric tire construction/contact, unsteady aeroelastic wakes and flaps, closed-loop ECU/driveline control, cranktrain/dry-sump/fuel/thermal systems, a multi-car pit-road twin, occupant heat/egress, scanned pavement mechanics, and spray/optical visibility. These domains are additive and do not change this guide's existing `nascar` command contracts. See `docs/NASCAR_INTEGRATED_FIDELITY_PLATFORM.md` and Chapter 58 of the user manual.

## 1. Scope

The NASCAR Competition Platform is an additive advanced-platform subsystem for
Cup Next Gen vehicle engineering, superspeedway pack behavior, race procedure,
championship scoring, official timing and SMT analytics, pit-crew operations,
Goodyear tyre behavior, evolving track surfaces, Optical Scanning Station
inspection, and Next Gen crash safety.

It is exposed through one command family:

```bash
muzixdiagsys_advanced_platform nascar ...
```

Every execution returns a structured JSON report containing a versioned
`schema`, domain-specific metrics, safety or compliance findings, a Boolean
`passed` gate, and a canonical SHA-256 `evidence_digest`. When a working
directory is supplied, the same report is retained under a stable domain file
name.

The models are engineering and pre-conformance tools. NASCAR's complete rule
book, event bulletins, manufacturer submissions, inspection procedures, and
sanctioning decisions remain authoritative. Numerical thresholds are therefore
request fields wherever practical rather than immutable assumptions.

## 2. Command syntax

List the ten domains:

```bash
./build/full/muzixdiagsys_advanced_platform nascar capabilities
```

Run all nominal regression workflows:

```bash
./build/full/muzixdiagsys_advanced_platform nascar self-test \
  build/full/nascar-self-test \
  build/full/nascar-self-test.json
```

Run one domain:

```bash
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN \
  REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

A valid execution that fails its qualification gates returns exit code `2`.
Malformed input or an execution exception returns `1`. Invalid top-level CLI
syntax returns `64`.

## 3. Domain registry

| Domain | Purpose | Stable artifact |
|---|---|---|
| `cup-next-gen-vehicle` | Next Gen dynamics, setup, suspension, transaxle and bottoming | `nascar_cup_next_gen_vehicle.json` |
| `superspeedway-pack` | Drafting, side drafting, bump contact, cooling and pack risk | `nascar_superspeedway_pack.json` |
| `race-control` | Stages, cautions, pit state, choose, free pass, wave-around, DVP and overtime | `nascar_race_control.json` |
| `chase-championship` | 2026 race/stage points, Chase seeding and title probability | `nascar_chase_championship.json` |
| `timing-smt` | Timing loops, caution freeze order, classification and SMT analytics | `nascar_timing_smt.json` |
| `single-lug-pit-crew` | Crew task graph, lug retention, fueling, fatigue and penalties | `nascar_single_lug_pit_crew.json` |
| `goodyear-tyre` | Left/right tyre heat, pressure, wear, stagger and wet behavior | `nascar_goodyear_tyre.json` |
| `track-surface` | Rubber, marbles, resin, rain wash, drainage and groove evolution | `nascar_track_surface.json` |
| `oss-inspection` | Optical alignment, guarded dimensions, seals and load tests | `nascar_oss_inspection.json` |
| `crash-safety` | SAFER barrier, crash pulse, flaps, liftoff and occupant injury | `nascar_next_gen_crash_safety.json` |

## 4. Cup Next Gen vehicle laboratory

The vehicle laboratory combines longitudinal power balance, aerodynamic drag
and downforce, braking, tyre-force saturation, suspension heave, roll, pitch,
ride-height limits, sequential-gear selection, differential settings, and setup
geometry.

Important request groups:

- `vehicle`: mass, wheelbase, tracks, CG, weight distribution, drag/lift,
  power, wheel radius, tyre/brake coefficients, gear ratios, final drive and
  minimum limits.
- `setup`: front/rear ride heights, wheel rates, anti-roll bars, motion ratios,
  differential preload/locking, camber, toe and pressures.
- `maneuvers`: time step, throttle, brake, steering, banking and optional
  externally imposed speed.

For each step, the engine calculates dynamic pressure, drag, downforce, normal
load, power-limited and friction-limited tractive force, brake force, rolling
resistance, acceleration, lateral utilization, roll moment, suspension
compression and current transaxle gear. It rejects nonphysical geometry and
reports bottoming, pressure and saturation findings.

```bash
./build/full/muzixdiagsys_advanced_platform nascar cup-next-gen-vehicle \
  examples/nascar_competition/cup_next_gen_vehicle.json \
  build/full/cup-next-gen-vehicle.json
```

## 5. Superspeedway pack-racing laboratory

The pack model integrates each car around a periodic oval. Same-lane forward
separation produces an exponentially decaying drag reduction and cooling loss.
Adjacent-lane overlap produces a side-draft yaw moment. Closing cars can enter
a bumper-contact calculation based on effective mass, relative velocity,
impulse and bounded common post-contact speed.

The output includes:

- Minimum same-lane gap and maximum bumper load for each car
- Coolant temperature and fuel consumption
- Maximum closing rate
- Maximum side-draft yaw moment
- Lane entropy and pack cohesion
- Contact and severe-contact counts
- A bounded multi-car incident or "Big One" risk score

A severe bump contact or coolant-limit violation fails the domain. The model is
suitable for lane-energy experiments, final-lap strategies, throttle lift for
cooling, and sensitivity sweeps over gap and lane count.

## 6. Race-control and procedure engine

The race-control engine processes an ordered event stream. Its state includes
caution, red flag, pit-road availability, current lap, official race distance,
overtime attempts, running order, lap deficits, garage status, DVP clock,
free-pass eligibility, penalties and stage points.

Supported event types are:

- `caution`
- `pit-road-open`
- `pit-road-close`
- `pit`
- `free-pass`
- `wave-around`
- `choose`
- `restart`
- `red-flag`
- `resume-from-red`
- `stage-end`
- `finish`

A caution near the scheduled finish extends the distance by two laps for each
configured overtime attempt. A restart outside the configured zone produces a
penalty and failed qualification. Stage ends award 10-to-1 points to the first
ten positions. DVP state distinguishes timed pit-box repair from unclocked
garage repair and permits a repaired vehicle to return with configured laps
lost.

## 7. 2026 Chase and stage championship engine

The default point schedule awards 55 points for a win, 35 for second, then a
one-point decrement through the field with a one-point floor. Each stage awards
10 through 1 points. An optional fastest-lap point is supported as a versioned
request field in race results.

The default Chase seed schedule is:

- Regular-season champion: 2,100
- Second seed: 2,075
- Third seed: 2,065
- Subsequent seeds: five-point decrements

Qualification is based on regular-season points rather than automatic
qualification by a victory. The engine also calculates manufacturer points
using the best finishing representative in each race and can run deterministic
Monte Carlo projections from driver performance ratings.

The simulation returns Chase qualification and championship probabilities for
every driver. Setting `simulations` to zero disables projection and reports the
current deterministic state.

## 8. Official timing, scoring and SMT

Timing-loop hits contain car, loop, timestamp and confidence. The engine:

1. Validates car and loop identities.
2. Sorts hits by time.
3. Collapses duplicates inside the configured tolerance, retaining the
   higher-confidence hit.
4. Reconstructs laps from start/finish crossings.
5. Rejects intervals outside the allowed lap-time range.
6. Applies time penalties and disqualifications.
7. Produces the official order by completed laps and adjusted elapsed time.

At each caution timestamp, the engine creates a frozen order from completed
start/finish crossings, the latest scoring-loop distance and the timestamp of
the latest valid hit.

SMT samples produce maximum speed, full-throttle fraction, brake fraction,
closest drafting partner, minimum draft gap and pit-road speed violations.

## 9. Single-lug pit-crew operations

The pit model is a dependency-scheduled discrete-event system. It constructs a
task graph for jack-up, wheel removal, tyre delivery, wheel installation,
fuelling, optional repairs and jack-down. Role skill, fatigue and pit-box error
modify task durations. Dependencies ensure the car cannot be lowered until all
required work is complete.

A deterministic Monte Carlo campaign calculates mean and 95th-percentile stop
time, adjacent-box interference probability and loose-wheel probability.
Qualification also checks:

- Front and rear single-lug torque windows
- Correct wheel indexing
- Equipment containment
- Pit-entry speed

## 10. Goodyear tyre and wet-weather laboratory

Four independent tyre states are integrated through each stint segment. The
model calculates dynamic load transfer, slip-energy heating, water cooling,
tread-to-carcass conduction, carcass-to-air heat rejection, gas-temperature
pressure growth, wear, damage accumulation and effective rolling radius.

Left and right constructions can use different pressure, camber, load, radius
and inner-liner settings. Final radius difference produces stagger. In wet
segments, a pressure- and tread-dependent hydroplaning margin is calculated.
The engine recommends dry slicks or wet-weather tyres from water depth and wet
exposure.

Cold-pressure, tread-temperature, remaining-tread, belt-damage and hydroplaning
limits are enforced independently for each corner.

## 11. Track-surface and rubber-evolution twin

The track is divided into cells representing racing lines or physical sections.
Each cell carries material, base friction, rubber, marbles, water, temperature,
resin, roughness, drainage and shade.

Supported surface events are:

- `running`: deposits rubber on the occupied line, creates off-line marbles,
  warms the surface and displaces water.
- `rain`: adds water, applies drainage, washes rubber and marbles, and cools the
  surface.
- `sun`: adds absorbed solar heat and evaporates water.
- `apply-resin`: increases the configured traction treatment.
- `repave`: replaces base friction and roughness and clears accumulated rubber
  and marbles.

Grip is calculated from base friction multiplied by temperature, water, rubber,
resin, marble and roughness factors. The report identifies the best current
line and rejects surfaces exceeding the raceable water-depth threshold.

## 12. OSS inspection and technical enforcement

The Optical Scanning Station model aligns measured datum points to a reference
using the mean translation, then calculates RMS and maximum residual alignment
error. Dimensional measurements use uncertainty guard bands:

- A lower limit passes only when `measured - uncertainty >= minimum`.
- An upper limit passes only when `measured + uncertainty <= maximum`.

The inspection also evaluates minimum mass, left-side weight fraction,
component serials, required seals, and load-deflection behavior. Load testing
calculates stiffness, nonlinearity, rate sensitivity and temperature
sensitivity to expose hidden or adaptive mechanisms.

Enforcement depends on inspection timing and attempt count. A critical post-race
failure produces `disqualification`. Pre-race failures escalate from failed
inspection through crew-member ejection, practice hold/pass-through, and
escalated last-row treatment.

## 13. Next Gen crash, roof-flap and SAFER-barrier safety

The crash model resolves impact velocity into normal and tangential components,
calculates normal kinetic energy, and partitions energy between barrier spring,
barrier damping and vehicle crush. It reports crush distance, peak deceleration,
delta-v and survival-cell intrusion.

The liftoff model uses speed, yaw, pitch, underbody area, baseline lift and roof
and A-post flap effectiveness. High-speed, high-yaw cases require timely flap
deployment. The engine calculates lift-to-weight ratio and rollover
probability.

Occupant assessment includes restraint and seat energy absorption, estimated
HIC15, chest acceleration and neck load. Fuel-cell integrity and fire risk are
also reported. A case fails if required flaps do not deploy, liftoff occurs, an
injury metric exceeds its configured limit, intrusion exceeds its limit, or the
fuel cell loses integrity.

## 14. Validation

Build and run the dedicated regression suite. The focused test links `aesim_nascar` rather than the full advanced aggregate; build the executable separately only when validating the JSON command surface:

```bash
cmake --build build/full --parallel --target \
  aesim_nascar \
  nascar_competition_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/full --output-on-failure \
  -R '^nascar_competition_platform_unit_tests$'
```

Run every public example:

```bash
for domain in \
  cup-next-gen-vehicle superspeedway-pack race-control chase-championship \
  timing-smt single-lug-pit-crew goodyear-tyre track-surface \
  oss-inspection crash-safety
do
  # Select the matching file under examples/nascar_competition/.
done
```

The dedicated tests include negative cases for an out-of-zone restart, an
under-torqued single lug, a post-race dimensional failure, and missing roof/A-
post flap deployment at high speed and yaw.

# NASCAR Ecosystem Expansion

The NASCAR command family now contains twenty independently executable domains. The original ten Cup competition domains remain unchanged; the following ten domains add the broader series, manufacturer, operational, commercial, officiating, communications, recovery, repair, and wet-weather ecosystem.

## General command form

```bash
muzixdiagsys_advanced_platform nascar DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The command parses the request, validates all required structures and bounded numerical inputs, executes the selected model, writes `OUTPUT.json`, and writes the domain-specific evidence file into `WORKING_DIRECTORY` when provided. Exit code `0` means the completed assessment returned `passed=true`; exit code `2` means execution completed but the assessment returned `passed=false`; exit code `1` means invalid input or an execution failure.

## `multi-series`

Provides versioned `cup-2026`, `oreilly-2026`, `truck-2026`, and `arca-2026` profiles. `operation=list` returns the installed profile catalogue. The default `simulate` operation combines vehicle mass, fuel, banking, corner radius, aerodynamic drag, downforce, tyre friction, and installed power to estimate corner speed, power-limited speed, average speed, lap time, fuel rate, and tyre energy.

## `manufacturer-homologation`

Evaluates multiple manufacturer bodies over a speed, yaw, front-ride-height, and rear-ride-height matrix. Each body carries base drag and lift coefficients, frontal area, cooling-opening area, yaw sensitivity, ride-height sensitivity, and wake recovery. The engine calculates drag, downforce, side force, yaw moment, and drafting efficiency at every test point, then compares normalized manufacturer spreads against explicit homologation windows.

## `v8-transaxle-durability`

Runs a duty cycle through a pushrod-V8 and sequential-transaxle durability model. It calculates piston speed, combustion and volumetric efficiency, torque, power, valvetrain surge ratio, cumulative valvetrain fatigue, gear-mesh load, bearing damage, dog engagement life, missed-shift damage, over-rev exposure, oil temperature, and coolant temperature. Thermal states include the effective metal, oil, coolant, and drivetrain thermal masses rather than treating fluid capacity as the complete system heat capacity.

## `special-event-formats`

Constructs official starting lineups for `daytona-500`, `all-star`, and `group-qualifying` profiles. Daytona processing locks the two fastest qualifiers into the front row, orders the remaining entries through Duel results, and applies open-exemption, charter, owner-points, and qualifying-speed provisionals when required. All-Star processing combines eligibility, pit-challenge performance, and fan-vote state.

## `charter-team-economics`

Models team and charter economics across a race schedule. Inputs include car and charter count, sponsor revenue, manufacturer support, payroll, shop costs, travel, parts, debt service, starting cash, race purses, open/charter shares, entry fees, performance, crash probability, and repair exposure. Outputs include revenue, cost, profit, ending cash, expected crash cost, discounted charter portfolio value, and financial-distress probability.

## `pit-road-vision`

Uses calibrated camera homographies to project image detections into pit-road ground coordinates. It tracks crew members, tyres, and equipment across frames; reconstructs movement speed; counts concurrent crew over the wall; checks pit-box containment; detects uncontrolled tyres; and verifies fueler protective-equipment evidence. Every violation includes the track identifier, measured value, and evidence subject.

## `radio-intelligence`

Analyzes driver, spotter, and crew-chief messages against traffic truth. It calculates RF signal-to-noise ratio, intelligibility, latency, acknowledgement state, urgency, ambiguous wording, and spotter-call correctness for `inside`, `outside`, and `clear` calls. The resulting communication score combines spotter accuracy, clarity, latency, and acknowledgement performance.

## `trackside-safety-drying`

Dispatches recovery, cleanup, barrier-repair, and drying resources around a closed circuit using shortest circular distance, travel speed, setup time, capacity, and required work. The drying model combines ambient evaporation, humidity, wind, and equipment removal rates. It reports each zone’s dispatch plan, predicted ready time, remaining water film, earliest overall restart, and daylight feasibility.

## `dvp-garage-repair`

Creates a dependency-resolved repair schedule from damage items, replacement-part requirements, parts inventory, mechanics, skill, task severity, and tool-independent task precedence. It consumes inventory, assigns the earliest available qualified mechanic, predicts repair duration and laps lost, reduces alignment error as repairs complete, calculates residual performance loss, and performs the minimum-speed return-to-race gate. Unavailable parts yield a completed negative report with a JSON `null` repair time rather than a non-finite value.

## `wet-weather-visibility`

Integrates rain deposition, wiper removal, aerodynamic clearing, cabin dew drive, defogger capacity, windshield fog, following-car spray, optical extinction, driver visibility, camera transmission, and rear-rain-light illuminance. It qualifies wipers, defogging, visibility, and rain-light operation and recommends `green`, `caution/pace-car`, or `red flag`.

## Integrated self-test

```bash
./build/full/muzixdiagsys_advanced_platform \
  nascar self-test \
  build/full/nascar-self-test \
  build/full/nascar-self-test.json
```

The integrated NASCAR self-test executes all 40 competition, ecosystem, frontier, and next-generation domains and writes their evidence files under the specified directory. Frontier behavior and 2026-07-22 correctness guarantees are specified in `docs/NASCAR_FRONTIER_OPERATIONS_GUIDE.md`; the fourth ten-domain expansion is specified in `docs/NASCAR_NEXT_GENERATION_PLATFORM.md`.

## Motorsport CLI convenience aliases

The original 40-domain `nascar` dispatcher remains authoritative. `nascar all-capabilities`, `nascar all-self-test`, and `nascar run competition|integrated|assurance ...` add complete-suite routing. Competition shortcuts include `nascar-pack`, `nascar-race-control`, `nascar-pit`, `nascar-tyres`, `nascar-setup`, and `nascar-racecraft`. See `MOTORSPORT_CLI_COMMANDS.md`.

# Physical Diagnostics and Intelligence Platform

## Scope

This additive V20.1.2 extension deepens eight engineering domains without replacing existing MuzixDiagSys implementations. Two requested capabilities intentionally extend existing authoritative subsystems: unified sensor ray tracing is implemented inside `PhysicallyBasedMultimodalRenderer`, and vulnerable-road-user (VRU) biomechanics is implemented alongside the existing occupant/crash lifecycle model. The remaining capabilities are new complementary analysis layers.

Public APIs are aggregated by `include/aesim/advanced/platform.hpp` through:

- `include/aesim/advanced/integrated_frontier_platform.hpp`
- `include/aesim/advanced/crash_lifecycle.hpp`
- `include/aesim/advanced/experimental_mechanics_platform.hpp`
- `include/aesim/advanced/experiment_intelligence_platform.hpp`

All production implementations are native C++17 and participate in the existing `aesim_advanced` build target.

## 1. Unified multimodal sensor ray tracing

The pre-existing `PhysicallyBasedMultimodalRenderer` remains the single sensor-rendering authority. It now accepts indexed triangle meshes in addition to its existing sphere, axis-aligned box, plane, and triangle primitives.

`SceneAcceleration` constructs a deterministic bounding-volume hierarchy (BVH) over finite geometry. Mesh triangles are flattened into the existing intersection representation, while infinite planes remain on a separate exact-intersection path. The BVH uses largest-extent median splitting, compact leaves, nearest-hit traversal, all-hit traversal, and swept bounds for translating geometry over the camera rolling-shutter interval.

The same accelerated scene is used by:

- visible-spectrum camera rendering;
- thermal rendering;
- multi-return lidar;
- FMCW radar visibility/target generation.

`RenderMaterial` additionally carries retroreflectivity, surface wetness, radar relative permittivity, and volumetric scattering terms. `RayTracingStatistics` reports primitive, mesh, triangle, bounded/infinite primitive, BVH node/leaf, and maximum-depth counts. Existing primitive-only scenarios remain valid.

This is deliberately an extension of the current renderer, not a second rendering engine or duplicated scene database.

## 2. Vulnerable-road-user crash biomechanics

`VruCrashBiomechanicsSimulator` extends the existing crash lifecycle with pedestrian, cyclist, and motorcyclist impact mechanics while leaving occupant-restraint simulation unchanged.

The model includes:

- active-safety impact-speed mitigation from initial speed, time-to-collision, brake delay, deceleration, and minimum speed;
- road-user-type-specific effective mass distribution;
- lower-body, pelvis, chest, and head lumped biomechanical segments;
- compliant vehicle contact using configurable stiffness and damping;
- bumper, hood, and windshield contact-height behavior;
- compliant secondary head/ground contact;
- helmet energy absorption;
- cyclist and motorcycle carried-mass effects;
- deterministic time histories for vehicle and body-segment motion, head acceleration/angular velocity, and contact force.

Reported injury observables include HIC15, a BrIC-style rotational measure, maximum head/chest acceleration, pelvis/femur loading, tibia acceleration, knee moment, and modeled injury probabilities. Every result carries a SHA-256 evidence digest over its canonical result representation.

## 3. NVH TPA / OMA workbench

`NvhExperimentalAnalysisWorkbench` provides a test-correlation layer over the existing acoustics/NVH capabilities.

### Frequency-response functions

The workbench performs detrended, Hann-windowed Welch spectral estimation and supports H1, H2, and Hv FRF estimators together with magnitude-squared coherence.

### Operational modal analysis

Two distinct identification paths are implemented:

- Frequency Domain Decomposition (FDD), using cross-spectral matrices, dominant singular-vector iteration, peak extraction, half-power damping estimation, and modal confidence;
- covariance-driven SSI, using block-Hankel covariance structure, observability extraction, reduced state-transition estimation, discrete-to-continuous poles, pole filtering, damping estimation, and FDD-backed mode-shape association. Numerically neutral synthetic cases retain a deterministic FDD frequency fallback rather than producing invalid poles.

### Modal correlation

The workbench computes MAC, COMAC, automatic mode pairing, and mean paired MAC for simulation/test or test/test comparison.

### Transfer-path analysis

`transfer_path_analysis` multiplies complex force spectra by path transfer functions, reconstructs the total response, and reports path RMS and normalized contribution together with deterministic evidence hashing.

## 4. Brake squeal / friction-induced instability

`BrakeSquealInstabilitySolver` constructs a coupled second-order modal brake system from structural modes, modal mass/damping, non-symmetric friction coupling, interface pressure, temperature-dependent friction coefficient, and pad-wear coupling.

The state matrix is evaluated with a scaled Faddeev-LeVerrier characteristic polynomial followed by complex simultaneous root solution. Scaling controls coefficient conditioning and allows conjugate oscillatory mode extraction without depending on an external eigensolver.

For each oscillatory mode the solver reports:

- complex eigenvalue;
- frequency;
- modal growth rate;
- effective damping ratio;
- stable/unstable classification;
- normalized rotor/pad modal participation.

Unstable modes drive a deterministic transient squeal acceleration waveform. The dominant squeal frequency, maximum growth rate, unstable-mode count, and evidence SHA-256 are retained.

## 5. Rolling-bearing fault physics and prognostics

`RollingBearingFaultPrognosticsLab` adds a diagnostics/prognostics layer rather than duplicating existing bearing mechanics.

It calculates shaft, FTF, BPFO, BPFI, and BSF characteristic frequencies from geometry, rolling-element count, contact angle, and shaft speed. Defect cases include inner/outer race spalls, rolling-element spalls, cage defects, lubrication starvation, brinelling, and misalignment.

The vibration model generates load-zone-modulated defect impacts, a damped bearing/structure resonance response, lubrication-quality-dependent stochastic excitation, and misalignment components. Diagnostic processing includes:

- RMS and peak amplitude;
- crest factor;
- kurtosis;
- analytic-signal envelope extraction;
- envelope amplitudes at BPFO/BPFI/BSF/FTF;
- banded spectral-kurtosis search.

The prognostic layer estimates severity, defect-growth rate, remaining cycles/hours, lognormal-style 95% remaining-life bounds, and a 100-hour failure probability. Random excitation is explicitly seeded for repeatability.

## 6. XFEM fracture and fatigue propagation

`XfemCrackPropagationSolver` complements the simulator's existing phase-field/peridynamic/cohesive fracture capabilities with a two-dimensional shifted-Heaviside XFEM path.

The implementation provides:

- structured rectangular triangular meshes;
- plane-stress constitutive behavior;
- three-point triangular integration;
- crack-side shifted-Heaviside enrichment;
- consistent boundary traction loading;
- constrained enriched/global linear solve;
- displacement and von-Mises recovery;
- Mode-I and Mode-II stress-intensity estimates;
- J-integral energy measure;
- mixed-mode crack-turning angle;
- fracture-toughness instability check;
- fatigue threshold and Paris-law growth;
- bounded growth increments and cycle accounting.

Results retain each propagation step, enriched-node count, final crack geometry, displacement field, consumed cycles, instability state, and evidence SHA-256.

## 7. Scientific data lineage

`ScientificDataLineageGraph` extends existing experiment/provenance services into a persistent, queryable experiment-and-artifact DAG.

Experiment records can retain parent experiments, source/model/scenario/configuration/calibration/build hashes, compiler/platform identity, random seed, timestamps, qualification state, and arbitrary tags. Artifact records retain experiment ownership, role, media type, producer, parent artifacts, metadata, file size, and SHA-256.

The graph supports:

- registration of existing `ExperimentStatus` / `ExperimentMetadata` runs;
- experiment and artifact filtering;
- experiment ancestry;
- artifact ancestry and descendants;
- unresolved-reference detection;
- DAG cycle detection;
- optional on-disk artifact hash verification;
- deterministic graph SHA-256;
- canonical JSON persistence and reload.

This is an evidence lineage layer over the existing provenance/runtime APIs, not a competing experiment manager.

## 8. Causal discovery and structural learning

`CausalDiscoveryEngine` adds data-driven structure learning alongside the simulator's existing causal replay/counterfactual facilities. The five method selections execute materially different algorithms:

- **PC**: partial-correlation/Fisher-Z conditional-independence skeleton discovery, separating sets, collider orientation, and Meek-style propagation;
- **FCI**: PC-family skeleton/conditioning with partially oriented graph endpoints for unresolved/latent-confounding-compatible relationships;
- **GES**: greedy BIC-scored directed edge addition/removal with acyclicity enforcement;
- **NOTEARS**: continuous weighted adjacency optimization using an augmented-Lagrangian acyclicity penalty based on the matrix exponential, followed by cycle-safe thresholding;
- **PCMCI**: lagged candidate screening followed by conditional residual testing over configurable lag depth.

Results contain directed/partially oriented edges, strengths, p-values where applicable, lag samples, topological order for directed DAGs, acyclicity state, optional comparison metrics against known simulator ground truth, and deterministic evidence hashing.

The ground-truth comparison reports structural Hamming distance, precision, recall, orientation accuracy, and intervention-oriented error measures where defined by the modeled graph representation.

## Determinism, qualification, and limits

These subsystems are deterministic when their documented random seeds and numerical inputs are held constant. They are engineering/research simulation implementations; they are not asserted to replace physical crash certification, accredited NVH/modal laboratories, component durability tests, regulatory homologation, or independently validated injury/fracture material models. Model parameters must be calibrated against appropriate experimental data for safety-critical or production decision use.

The V20 retention and source-package regressions protect the new implementation files, test wiring, documentation, and extension anchors from silent deletion. The dedicated source regression also rejects common implementation-erosion markers in the new production code.

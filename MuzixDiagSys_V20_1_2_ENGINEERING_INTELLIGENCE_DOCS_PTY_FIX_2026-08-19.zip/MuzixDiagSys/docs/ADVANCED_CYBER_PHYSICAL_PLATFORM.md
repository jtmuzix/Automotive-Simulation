# MuzixDiagSys Advanced Cyber-Physical Platform

## Purpose

This subsystem extends MuzixDiagSys with interoperable autonomous-vehicle interfaces, deterministic reinforcement-learning environments, multi-objective optimization, safety engineering, automotive cybersecurity, secure vehicle lifecycle models, digital homologation, columnar experiment storage, cluster scheduling, and deterministic heterogeneous execution.

The implementation is additive. Existing simulator, engineering, diagnostics, standards, lifecycle, HIL/XIL, FMI, OpenX, and vehicle-physics interfaces remain available.

## Build

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DAESIM_BUILD_TOOLS=ON -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

The primary command is:

```bash
build/muzixdiagsys_advanced_platform --help
```

The Python package is under `python/`:

```bash
python -m pip install -e 'python[rl,columnar]'
```

ROS 2, CARLA, Autoware, and Apollo Python runtimes are intentionally loaded only when their corresponding adapter is instantiated. This allows the base Python package to operate without all external ecosystems installed.

## 1. Native interoperability

### Canonical vehicle frame

`CanonicalVehicleFrame` is the neutral representation used by the C++ translators. It contains nanosecond time, map frame, 3D pose, body velocity, acceleration, steering, throttle, brake, and extensible numeric/text fields.

Translate to an external representation:

```bash
muzixdiagsys_advanced_platform interop translate carla to \
  examples/advanced_platform/canonical_vehicle_frame.json carla_frame.json
muzixdiagsys_advanced_platform interop translate autoware to \
  examples/advanced_platform/canonical_vehicle_frame.json autoware_frame.json
muzixdiagsys_advanced_platform interop translate apollo to \
  examples/advanced_platform/canonical_vehicle_frame.json apollo_frame.json
```

Translate back with `from` instead of `to`. The CARLA adapter performs handedness and angular-sign conversion. Autoware and Apollo adapters preserve their native message hierarchy while retaining the canonical time and control state.

### Runtime probe

```bash
muzixdiagsys_advanced_platform interop probe integration_status.json
```

The probe reports available executables and runtime details for ROS 2, CARLA, Autoware, Apollo, Slurm, Kubernetes, and heterogeneous compute support. Availability is reported rather than assumed.

### ROS 2 and rosbag2

`python/muzixdiag/interoperability.py` provides:

- `Ros2NativeBridge` using `rclpy` publishers/subscribers.
- `/clock`, odometry, IMU, and Ackermann control publication.
- `Rosbag2NativeWriter` using `rosbag2_py.SequentialWriter` and CDR serialization.
- `AutowareBridge` using native Autoware control and vehicle-status message packages.
- `ApolloBridge` using Apollo Cyber RT nodes, readers, and writers.
- `CarlaBridge` using synchronous CARLA world ticks and vehicle controls.

The C++ `Rosbag2Storage` creates the standard SQLite topic/message schema, indexes messages by timestamp/topic, supports bounded reads, and emits rosbag2 metadata YAML.

```bash
muzixdiagsys_advanced_platform rosbag2 create \
  run_0.db3 metadata.yaml /vehicle/pose geometry_msgs/msg/PoseStamped \
  examples/advanced_platform/rosbag_payload.json
```

## 2. Gymnasium and PettingZoo environments

The C++ `VectorVehicleEnvironment` executes a deterministic batched bicycle-style vehicle environment. It supports explicit configuration, seeded reset, vectorized actions, collision/lane/horizon termination, reward calculation, snapshots, and exact restore.

The Python wrappers are:

- `MuzixVehicleEnv`: Gymnasium single-agent environment.
- `MuzixVectorEnv`: one C++ batch call per vector step.
- `MuzixMultiAgentEnv`: PettingZoo `ParallelEnv` with active-agent semantics and a global `state()` vector.

```python
import numpy as np
from muzixdiag.rl import MuzixVectorEnv

env = MuzixVectorEnv(16)
observations, info = env.reset(seed=42)
actions = np.zeros((16, 3), dtype=np.float32)
observations, rewards, terminated, truncated, info = env.step(actions)
env.close()
```

The backend subprocess is deadline-bounded, validates output, and reports launch, timeout, protocol, and action-space errors explicitly.

Direct JSON protocol:

```bash
muzixdiagsys_advanced_platform rl \
  examples/advanced_platform/rl_reset.json rl_result.json
```

## 3. Multi-objective optimization

`MultiObjectiveOptimizer` implements two complete algorithms:

- NSGA-II with nondominated sorting, crowding distance, tournament selection, simulated-binary crossover, polynomial mutation, constraint dominance, deterministic seeding, and Pareto extraction.
- Multi-objective Bayesian optimization with Gaussian-process surrogates, normalized design coordinates, Cholesky-based inference, acquisition candidate search, exploration control, constraint handling, and deterministic seeding.

The document-defined problem supports bounded variables, quadratic objectives, vehicle-design objectives, linear constraints, minimization/maximization, and per-algorithm options.

```bash
muzixdiagsys_advanced_platform optimize nsga2 \
  examples/advanced_platform/optimization_vehicle.json nsga2_result.json
muzixdiagsys_advanced_platform optimize bayesian \
  examples/advanced_platform/optimization_vehicle.json bayesian_result.json
```

Results include evaluation count, complete population/history, constraint violations, ranks, crowding distance, and Pareto front.

## 4. HARA, FMEA/FMEDA, FTA, and STPA

`SafetyAnalysisGenerator` consumes one system model and produces linked analyses:

- HARA hazardous events with severity, exposure, controllability, and ASIL classification.
- FMEA rows with effects, mechanisms, S/O/D ratings, and risk-priority number.
- FMEDA aggregate safe, dangerous detected, dangerous undetected, latent, SPFM, and LFM measures.
- Fault-tree probabilities, gate evaluation, and minimal cut sets.
- STPA unsafe-control-action categories and generated safety constraints.

Fault-tree gate support includes basic events, OR, AND, voting, PAND, and sequence behavior as defined by the input model.

```bash
muzixdiagsys_advanced_platform safety \
  examples/advanced_platform/safety_model.json safety_result.json
```

## 5. Stateful cyber range and protocol fuzzing

The cyber range models persistent diagnostic state rather than treating frames independently. It executes and tracks:

- CAN frame validity and arbitration edge coverage.
- ISO-TP single, first, consecutive, and flow-control state.
- UDS sessions, security access, download state, transfer accounting, negative responses, and reset behavior.
- DoIP headers, payload lengths, routing activation, and diagnostic transport.
- SOME/IP header, service, method, message-type, and payload consistency.

`StatefulAutomotiveFuzzer` supplies protocol-specific seed corpora, mutation, sequence growth, timing mutation, coverage-edge retention, crash/timeout classification, finding deduplication, and reproducible message sequences.

```bash
for protocol in can isotp uds doip someip; do
  muzixdiagsys_advanced_platform fuzz "$protocol" 10000 "$protocol-fuzz.json"
done
```

The built-in virtual ECU is safe by construction for local research; the fuzzer target callback can be replaced with a controlled external ECU/HIL adapter.

## 6. Secure vehicle lifecycle

The security subsystem provides:

- Persistent Ed25519 signing keys.
- AES-256-GCM sealed objects with authenticated metadata.
- Monotonic rollback and attestation counters.
- Signed multi-stage secure-boot manifests and digest verification.
- SecOC authentication with freshness counters and replay rejection.
- Signed A/B OTA staging, exact anti-rollback progression, pending-state persistence, health confirmation, and rollback.
- PCR-style extend/reset operations.
- Signed remote-attestation quotes containing nonce, counter, selected PCRs, device identity, and key identity.

```bash
muzixdiagsys_advanced_platform security self-test secure-state security_result.json
```

Private key files and sealed state are written with restrictive permissions on POSIX platforms. Verification paths reject altered payloads, stale freshness values, wrong nonces, bad signatures, and rollback-counter violations.

## 7. Digital homologation packs

The homologation runner loads CSV telemetry, validates pack structure, computes metrics in selected time windows, applies comparison operators, hashes the source trace, and emits per-requirement and aggregate verdicts.

Included engineering packs:

- `data/homologation/wltp_energy_v1.json`
- `data/homologation/braking_performance_v1.json`
- `data/homologation/battery_safety_v1.json`
- `data/homologation/adas_aeb_v1.json`

```bash
muzixdiagsys_advanced_platform homologation \
  data/homologation/braking_performance_v1.json \
  examples/advanced_platform/braking_trace.csv braking_report.json
```

These are configurable engineering evidence packs, not claims of legal approval or regulatory certification.

## 8. Arrow IPC and Parquet storage

`muzixdiag.columnar.ExperimentStore` uses PyArrow directly and supports:

- Arrow IPC file writing/reading.
- Parquet writing with compression, dictionaries, statistics, and row groups.
- Partitioned datasets.
- Predicate filters and selective columns.
- Schema metadata and schema evolution checks.
- Append with schema validation.
- Streaming JSONL input.

```bash
muzixdiag-columnar write parquet telemetry.jsonl telemetry.parquet \
  --metadata-json '{"campaign":"braking-v3"}'
muzixdiag-columnar inspect telemetry.parquet
muzixdiag-columnar export-jsonl telemetry.parquet exported.jsonl \
  --columns run_id time_s speed_m_s
```

## 9. Slurm and Kubernetes execution

`DistributedJob` captures command arguments, working directory, environment, CPUs, GPUs, memory, wall time, queue, container image, and retry count.

Generate manifests:

```bash
muzixdiagsys_advanced_platform slurm manifest \
  examples/advanced_platform/distributed_job.json campaign.sbatch
muzixdiagsys_advanced_platform kubernetes manifest \
  examples/advanced_platform/distributed_job.json campaign-job.yaml research
```

The executors also implement submit/apply, query, cancel/delete, process timeouts, bounded output capture, job-ID parsing, state normalization, and error propagation. Arguments and environment values are shell/YAML escaped rather than concatenated unsafely.

## 10. Deterministic CPU/GPU execution graph

`DeterministicExecutionGraph` provides:

- Persistent named float buffers.
- Copy, fill, affine, and deterministic reduction nodes.
- Explicit dependencies and topological layer compilation.
- Cycle, missing-dependency, invalid-size, and multiple-writer rejection.
- Independent-node parallel CPU dispatch with deterministic result ordering.
- `auto`, CPU, and existing heterogeneous backend dispatch.
- Per-node elapsed time, selected device/backend, scalar result, and SHA-256 output digest.
- Graph-level digest and optional buffer materialization.

```bash
muzixdiagsys_advanced_platform graph \
  examples/advanced_platform/execution_graph.json graph_result.json include-buffers
```

The graph output can be executed repeatedly and compared by graph/buffer hashes to detect backend numerical drift.

## Validation

The implementation includes:

- `advanced_platform_tests`: C++ unit/integration qualification for all ten domains.
- `advanced_platform_cli_self_test`: executable end-to-end self-test.
- `advanced_platform_python_syntax`: Python compile qualification.
- `advanced_python_runtime_tests.py`: optional-dependency runtime qualification using Gymnasium's environment checker, PettingZoo's parallel API test, and actual Arrow/Parquet round trips.

Run only the advanced tests:

```bash
ctest --test-dir build --output-on-failure \
  -R 'advanced_(cyber_physical_platform_unit_tests|platform_cli_self_test|platform_python)'
```

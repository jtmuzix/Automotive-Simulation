# MuzixDiagSys
## Industrial HIL and Automotive Verification Platform Implementation Report

**Implementation date:** July 10, 2026  
**Language standard:** C++17  
**Baseline:** `advanced_engine_sim_professional_platform_2026-07-10`  
**Resulting platform:** `advanced_engine_sim_industrial_hil_platform_2026-07-10`

---

## 1. Executive summary

The simulator has been extended with an additive industrial testbench layer that preserves all pre-existing engine, vehicle, research-core, professional-platform, plugin, FMI, terminal, dashboard, API, file-format, calibration, uncertainty, checkpoint, replay, MIL, and SIL capabilities.

The implementation introduces a separately compiled `aesim_industrial` library containing production C++ modules for:

1. Linux hard-real-time execution controls and HIL-capable I/O abstractions.
2. SocketCAN, classical CAN, CAN FD, ISO-TP, UDS, and SAE J1939 communication.
3. An operational XCP command/DAQ server with generated A2L descriptions.
4. Binary MDF 4.10 measurement recording and structural validation.
5. An ASAM XIL-compatible testbench automation profile.
6. SSP 2.x package import/export and FMI 3 multi-component orchestration.
7. Requirements-to-test-to-evidence traceability with freshness checking.
8. Automated fault campaigns with diagnostic coverage, classification, safety, latency, and false-positive reporting.

No requested capability is represented by an empty implementation, no-op branch, placeholder return, or unimplemented command. The new source tree was scanned for `TODO`, `FIXME`, `placeholder`, `stub`, and `not implemented` markers; none were found in the industrial implementation, its examples, or its tests.

The platform is designed for professional engineering use, but two distinctions remain important:

- Hard-real-time facilities are implemented in software; meeting a physical deadline still depends on the deployed kernel, CPU isolation, firmware, drivers, privileges, and I/O hardware.
- The XIL, MDF, A2L/XCP, and SSP implementations are operational standards-oriented profiles. This report does not claim certification by ASAM, FMI, or an independent conformance laboratory.

---

## 2. Architectural changes

### 2.1 New library boundary

A new library target was added:

```text
libaesim_industrial.a
```

It links against the existing:

```text
libaesim_core.a
libaesim_professional.a
```

The terminal application remains the top-level compatibility and composition layer. The new industrial library is independently testable and contains no terminal-dashboard dependencies.

### 2.2 New public headers

```text
include/aesim/industrial/
├── archive.hpp
├── fault_campaign.hpp
├── hil_io.hpp
├── mdf.hpp
├── network.hpp
├── platform.hpp
├── realtime.hpp
├── signals.hpp
├── ssp.hpp
├── traceability.hpp
├── xcp.hpp
└── xil.hpp
```

### 2.3 New implementation units

```text
src/industrial/
├── archive.cpp
├── fault_campaign.cpp
├── hil_io.cpp
├── mdf.cpp
├── network.cpp
├── platform.cpp
├── realtime.cpp
├── signals.cpp
├── ssp.cpp
├── traceability.cpp
├── xcp.cpp
└── xil.cpp
```

The industrial layer comprises more than 5,000 lines of new headers, implementation code, and direct unit coverage.

### 2.4 Live plant coupling

Every accepted simulation step now publishes a typed `PlantSample` to the industrial platform. That update performs the following operations without replacing the legacy plant path:

- Updates the typed signal and XCP address space.
- Reads HIL input channels and applies optional throttle/brake overrides.
- Writes simulated frequency, analog, and digital outputs.
- Updates UDS data identifiers.
- Polls the automotive network transport.
- Publishes periodic CAN-FD plant telemetry.
- Publishes J1939 EEC1, address-claim, and DM1 traffic.
- Activates XCP DAQ event channel 0.
- Samples active MDF recording channels.
- Updates testbench-visible numerical-health counters.

Existing behavior remains the default unless the new industrial services are explicitly enabled or commanded.

---

## 3. Hard-real-time execution and HIL I/O

### 3.1 Runtime policy

`RealtimeRuntime` implements a validated runtime policy containing:

- Integer nanosecond base period.
- Warning threshold.
- SCHED_FIFO priority.
- CPU affinity set.
- Memory-locking policy.
- Stack-prefault policy.
- Strict versus best-effort setup.
- Overrun policy.

Supported overrun policies are:

```text
count_continue
skip_release
stop_run
```

`skip_release` now has operational behavior: a missed deadline arms an atomic skip flag, and the simulator consumes that flag on the next real-time release rather than merely incrementing a counter.

### 3.2 Linux thread preparation

On Linux, the simulation thread can perform:

- `mlockall(MCL_CURRENT | MCL_FUTURE)`.
- Stack-page prefaulting.
- `pthread_setaffinity_np` CPU pinning.
- `pthread_setschedparam(..., SCHED_FIFO, ...)` priority assignment.
- Absolute `clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, ...)` release waits.

Failures are accumulated. In strict mode, any failed requested facility rejects real-time activation and stops the loop. In non-strict mode, execution continues while exposing capability and measurement status.

### 3.3 Runtime statistics

The runtime records:

- Cycle count.
- Warning-threshold overruns.
- Deadline misses.
- Skipped releases.
- Last execution time.
- Mean execution time.
- Maximum execution time.
- Standard deviation.
- Minimum deadline slack.
- Stop request state.

Execution statistics use an online numerically stable variance calculation.

### 3.4 HIL I/O abstraction

`HilIo` defines a backend-independent interface for:

- Configuration.
- Open/close.
- Timed input acquisition.
- Bounded output writes.
- Safe-state entry.
- Backend description and state.

Supported channel classes include:

- Analog voltage.
- Analog current.
- Digital.
- PWM.
- Frequency.
- Encoder.
- Thermocouple.

Every channel defines:

- Numeric identifier.
- Name.
- Direction.
- Type.
- Unit.
- Minimum and maximum.
- Safe value.

Every value defines:

- Channel identifier.
- Physical value.
- Nanosecond timestamp.
- Quality flags.

### 3.5 Backends

Two complete backends are supplied:

#### Deterministic loopback

Suitable for tests, SIL integration, and development without hardware. It validates ranges and direction, queues input values, retains outputs, and applies configured safe values.

#### Bounded UDP HIL transport

The UDP backend implements a versioned binary protocol with:

- Magic and version fields.
- Bounded channel count.
- Channel/value/timestamp/quality records.
- Datagram size validation.
- Source and destination configuration.
- Poll-based bounded reads.
- Invalid-magic and truncated-packet rejection.
- Safe-state output transmission.

---

## 4. Automotive network stack

### 4.1 CAN transport abstraction

The `CanTransport` interface supports open, close, status, send, receive, and backend description operations.

### 4.2 Deterministic loopback CAN

The loopback backend provides a mutex-protected frame queue for deterministic network tests and fault-campaign use.

### 4.3 Linux SocketCAN and CAN FD

`SocketCanTransport` supports:

- Linux PF_CAN raw sockets.
- Interface-name resolution.
- Classical CAN and CAN FD.
- CAN-FD socket option enablement.
- Standard and extended identifiers.
- Bit-rate switch and error-state indicator flags.
- Optional accepted-ID filters.
- Poll-based receive timeout.
- Native frame conversion.
- Interface and socket error reporting.
- Resource-safe close behavior.

### 4.4 ISO-TP

`IsoTpEndpoint` provides:

- Single-frame encoding and decoding.
- First-frame encoding.
- Consecutive-frame sequencing.
- Flow-control frame recognition.
- Configurable link payload size for CAN and CAN FD.
- Sequence validation.
- Reassembly length validation.
- Maximum-payload controls.
- State reset after completion or errors.

The regression suite round-trips a 50-byte diagnostic payload through segmentation and reassembly.

### 4.5 UDS virtual ECU

`UdsServer` implements deterministic request processing for:

- `0x10` Diagnostic Session Control.
- `0x11` ECU Reset.
- `0x14` Clear Diagnostic Information.
- `0x19` Read DTC Information.
- `0x22` Read Data by Identifier.
- `0x27` Security Access.
- `0x28` Communication Control.
- `0x2E` Write Data by Identifier.
- `0x2F` Input/Output Control abstraction.
- `0x31` Routine Control.
- `0x34` Request Download abstraction.
- `0x36` Transfer Data abstraction.
- `0x37` Request Transfer Exit.
- `0x3E` Tester Present.

The server maintains:

- Session state.
- Security state.
- Read-only and writable DIDs.
- DTC status and occurrence counts.
- Deterministic negative response codes.
- Request statistics.

### 4.6 SAE J1939

`J1939Stack` implements:

- NAME encoding.
- Preferred source address.
- 29-bit identifier construction and parsing.
- Global and destination-specific PGNs.
- Address Claim.
- Single-packet messages.
- BAM connection-management messages.
- TP.DT packetization and reassembly.
- Sequence and payload validation.
- DM1 active diagnostic messages.
- DM2 previously active diagnostic messages.
- Stack statistics.

The live plant publishes EEC1 engine-speed data and diagnostic messages through this stack.

---

## 5. XCP server and A2L generation

### 5.1 Typed address space

`SignalRegistry` maintains a stable, bounded ECU-style address space containing measurements, commands, calibrations, and diagnostics. Each descriptor includes:

- Canonical name.
- Description.
- Unit.
- signal kind;
- scalar representation;
- range;
- address;
- byte size;
- write permission.

Memory reads and writes validate address range, scalar width, finite numeric values, permissions, and physical range.

### 5.2 XCP command handling

The XCP server implements command-transfer-object processing for:

- CONNECT and DISCONNECT.
- GET_STATUS.
- SYNCH.
- GET_ID.
- SET_MTA.
- UPLOAD and SHORT_UPLOAD.
- DOWNLOAD, DOWNLOAD_NEXT, and SHORT_DOWNLOAD.
- BUILD_CHECKSUM.
- SET_CAL_PAGE and GET_CAL_PAGE.
- DAQ, ODT, and ODT-entry allocation.
- SET_DAQ_PTR and WRITE_DAQ.
- SET/GET_DAQ_LIST_MODE.
- START_STOP_DAQ_LIST.
- START_STOP_SYNCH.
- DAQ processor and resolution information.

### 5.3 UDP transport

The UDP transport implements the four-byte XCP-on-Ethernet-style length/counter envelope, request validation, response transmission, connection tracking, and active peer retention.

DAQ DTOs generated by `sample_event` are both returned to local callers and asynchronously transmitted to the most recently active UDP peer. Transport-counter access is serialized to prevent command/DAQ races.

The unit suite opens a real UDP socket, sends a packetized CONNECT request, validates the response, activates an event, and receives an asynchronous DTO.

### 5.4 Automatic A2L

A2L is generated from live signal descriptors. Output includes:

- Project, header, and module.
- Mod common and byte order.
- XCP-on-CAN and XCP-on-Ethernet transport metadata.
- Units.
- Computation methods.
- Measurements.
- Characteristics.
- ECU addresses.
- Physical units and ranges.
- Record layouts.
- Measurement and calibration groups.

Names are canonicalized to valid A2L identifiers and text is escaped safely.

---

## 6. MDF measurement recording

### 6.1 Recorder behavior

`MdfRecorder` accepts:

- Output path.
- Ordered channel list.
- Sampling period.
- Maximum sample count.
- Experiment comment.

It validates channel existence and sampling configuration before recording. Samples are selected by deterministic simulation time rather than wall-clock time.

### 6.2 MDF 4.10 block graph

The binary writer emits an MDF 4.10-oriented hierarchy containing:

- Identification block.
- Header block.
- File-history block.
- Data group.
- Channel group.
- Channel blocks.
- Conversion blocks.
- Source-information blocks.
- Text and metadata blocks.
- Data block.
- Data-list block where applicable.

Channels include name, description, unit, type, range, byte offset, and sampling metadata. Data records contain a master time channel and deterministic signal ordering.

### 6.3 Validation

The validator verifies:

- MDF signature and version.
- Minimum file size.
- Block identifiers.
- Block header and payload bounds.
- Link-array bounds.
- Forward/referenced block offsets.
- Data block consistency.

The implementation writes a true binary file rather than a CSV file with an MDF extension.

---

## 7. ASAM XIL-compatible testbench automation

### 7.1 Port model

The implementation exposes four testbench port classes:

- `ModelAccessPort` for typed signal reads and writes.
- `NetworkPort` for CAN/CAN-FD and UDS access.
- `DiagnosticPort` for diagnostic requests and DTC state.
- `ElectricalErrorPort` for plant fault injection and clearing.

### 7.2 Test document

YAML and JSON documents can execute:

- Signal set.
- Time wait.
- Assertion.
- Existing terminal command.
- CAN/CAN-FD transmission.
- UDS request with exact expected response.
- Fault injection.
- Fault clearing.
- MDF start.
- MDF stop.
- Bounded wait-until.

Assertions support comparison operators, engineering units, and diagnostic detail.

### 7.3 Verdicts and timing

Each action records:

- Sequence index.
- Action type.
- Pass/fail state.
- Model time.
- Detail or response.

The result records PASS, FAIL, or ERROR and supports machine-readable JSON output. A model reset during a test is handled explicitly so the test interval cannot produce a negative duration.

The interface is described as XIL-compatible because it provides the expected model, network, diagnostic, and electrical-error port semantics, but no external ASAM conformance certification is claimed.

---

## 8. SSP 2.x and multi-FMU orchestration

### 8.1 Safe package handling

The industrial archive layer reads and writes bounded ZIP32 packages with:

- Stored entries.
- Deflate entries through zlib.
- CRC-32 verification.
- Entry-count limits.
- Uncompressed-size limits.
- Path traversal rejection.
- Absolute path rejection.
- Encrypted-entry rejection.
- Unsupported compression rejection.
- Truncation detection.

### 8.2 SSP representation

The system model contains:

- System identity and version.
- Components.
- Embedded FMU source paths.
- FMI execution interface.
- Connectors and kinds.
- Units.
- Parameters.
- Connections.
- Scale and offset transformations.

`SystemStructure.ssd` and embedded FMUs are packaged into a portable SSP archive.

### 8.3 Import

The importer parses the system description, validates component uniqueness, resolves embedded FMUs safely, validates connectors and connection endpoints, and reconstructs parameterization and signal flow.

### 8.4 Orchestration

The co-simulation master supports:

- FMI 3 Co-Simulation component loading.
- Parameter application before initialization.
- Jacobi coupling.
- Gauss-Seidel coupling.
- Iterative Gauss-Seidel coupling.
- Configurable iteration limit.
- Configurable convergence tolerance.
- FMU state capture and rollback.
- Connection scale and offset.
- Residual calculation.
- Convergence reporting.
- Component output collection.
- Deterministic component ordering.

The unit suite composes two real exported FMUs, connects source torque to sink load torque, initializes the system, performs iterative coupling, and validates generated outputs.

This is an operational SSP 2.x profile; independent SSP conformance certification is not claimed.

---

## 9. Requirements-to-test-to-evidence traceability

### 9.1 Requirement records

Requirements contain:

- Identifier.
- Title.
- Normative statement.
- Verification method.
- Safety classification.
- Owner.
- Source files.
- Linked tests.
- Attributes.
- Canonical content hash.

### 9.2 Test definitions

Tests contain:

- Identifier.
- Title.
- Executor.
- Expected artifact.
- Linked requirements.
- Attributes.
- Canonical content hash.

### 9.3 Evidence records

Evidence contains:

- Deterministic evidence identifier.
- Test and requirement identifiers.
- Verdict.
- UTC timestamp.
- Run identifier.
- Artifact path.
- Artifact SHA-256.
- Requirement hash at execution.
- Test hash at execution.
- Metrics.
- Message.

Evidence is rejected when it references an unknown requirement, unknown test, or a test that is not linked to the stated requirement.

### 9.4 Coverage and freshness

Reports calculate:

- Total requirements.
- Total tests.
- Evidence count.
- Covered requirements.
- Passing requirements.
- Failing requirements.
- Stale requirements.
- Uncovered requirements.
- Orphan tests.
- Coverage percentage.

Evidence becomes stale if either the requirement definition or test definition changes after the evidence was recorded. A Markdown traceability matrix can be generated for review and release evidence.

---

## 10. Automated fault campaigns

### 10.1 Campaign definitions

Campaign files support:

- Explicit fault cases.
- Cartesian fault matrices.
- Preconditioning duration.
- Observation duration.
- Integration step.
- Injection time.
- Fault duration.
- Expected DTC.
- Detection deadline.
- Safety expression.
- Maximum safe-state latency.

### 10.2 Case lifecycle

Each case performs:

1. Complete simulator reset.
2. Legacy and diagnostic fault clear.
3. Deterministic preconditioning.
4. Diagnostic clear and immediate baseline capture.
5. Fault injection.
6. Time-stepped observation.
7. Safety assertion evaluation.
8. DTC collection.
9. Detection and classification measurement.
10. Unexpected-DTC collection.
11. Safe-state timing.
12. Fault clear.

Clearing immediately before injection prevents a naturally occurring preconditioning DTC from being mistaken for campaign detection or suppressing the expected detection event.

### 10.3 Coverage metrics

The report includes:

- Cases and successful injections.
- Detected cases.
- Correctly classified DTC cases.
- Safely mitigated cases.
- Fully passing cases.
- Diagnostic coverage percentage.
- Correct classification percentage.
- Safe mitigation percentage.
- Mean detection latency.
- Maximum detection latency.
- Unexpected-DTC false positives.

A case fails if it produces an unexpected new DTC, even when the expected DTC is also present.

### 10.4 Artifacts

Each campaign can write:

```text
diagnostic_coverage.json
diagnostic_coverage.md
fault_cases.csv
```

---

## 11. New command surface

The industrial services are available through `industrial` and focused aliases.

```text
industrial status
industrial hil ...
industrial network ...
industrial xcp ...
industrial mdf ...
industrial xil ...
industrial ssp ...
industrial requirements ...
industrial campaign ...
```

Focused aliases include:

```text
hil
xcp
mdf
xil
ssp
requirements
traceability
faultlab
```

Legacy `realtime`, `can`, `uds`, `j1939`, `fmi`, `fmi3`, `scenario`, `fault`, and plugin commands remain available.

---

## 12. Example assets

The source archive includes executable examples:

```text
data/industrial_xil_test.yaml
data/industrial_requirements.yaml
data/industrial_tests.yaml
data/industrial_fault_campaign.yaml
```

They demonstrate XIL actions, MDF recording, UDS, CAN FD, traceability metadata, and diagnostic campaigns.

---

## 13. Correctness defects found and corrected during integration

### 13.1 Signal-registration move-order defect

The signal registry previously used a moved descriptor while evaluating a map key. C++ argument evaluation order could leave multiple entries with an empty key. The name is now captured before moving the descriptor.

### 13.2 XCP transport-counter race

UDP response packetization and DAQ packetization could both increment the transport counter. Counter access is now serialized.

### 13.3 Missing XCP DAQ network transmission

Local DAQ DTO construction existed, but DTOs were not sent to the active UDP peer. The server now retains the validated peer address and transmits event DTOs non-blockingly while still returning them to local callers.

### 13.4 Fault-campaign diagnostic baseline contamination

Preconditioning could produce an expected DTC before injection. Campaigns now clear/re-baseline immediately before fault injection.

### 13.5 Diagnostic false-positive accounting

The report field existed but was not populated. New non-baseline DTCs other than the expected classification are now collected, exported, counted, and included in case pass/fail.

### 13.6 XIL negative duration after reset

A test could begin at a nonzero model time and execute `reset`, producing an end time earlier than the original start. Action timestamps are now refreshed after execution, and a backward model-time transition rebases the executable test interval.

### 13.7 Real-time skip policy did not skip

The skip policy previously incremented a statistic without suppressing a release. It now arms an atomic one-shot flag that is consumed by the simulation loop.

### 13.8 Real-time release wait

The runtime used generic `std::this_thread::sleep_until`. Linux now uses an absolute `CLOCK_MONOTONIC` `clock_nanosleep` target with EINTR handling and a portable fallback.

### 13.9 Diagnostic clearing separation

Clearing a legacy injected fault did not necessarily clear the industrial UDS DTC store. The industrial callback now synchronizes an `all` clear across both domains.

### 13.10 Gas-path and prior professional fixes retained

All earlier professional-platform corrections remain present, including deterministic replay filtering, complete health-history serialization, diagnostic freeze-frame checkpointing, and conservation-residual correction.

---

## 14. Validation

### 14.1 Final Debug regression matrix

The final project registers 36 CTest cases. All 36 passed. Because the execution environment applies a per-command ceiling, the matrix was also executed in controlled groups; no failed test was omitted or waived.

Coverage includes:

- Core units and calibration.
- Industrial core.
- Professional core.
- Research core.
- Legacy CLI.
- Terminal/dashboard behavior.
- Drivetrain and transmission behavior.
- Plugin loading and execution.
- API server behavior.
- Non-finite input handling.
- Research workflows.
- Professional checkpoint/replay, schemas, scenarios, FMI, plugins, and MIL/SIL.
- Industrial HIL/network/XCP/MDF/XIL/SSP/traceability/fault workflows.

### 14.2 Industrial direct unit test

`industrial_core_tests` verifies:

- Typed signal memory access.
- Hard-real-time policy and skip behavior.
- HIL safe-state behavior.
- CAN-FD transport.
- ISO-TP segmentation/reassembly.
- UDS sessions, DIDs, DTCs, and security behavior.
- J1939 address claim and BAM reassembly.
- XCP calibration memory and DAQ configuration.
- Real UDP XCP CONNECT and asynchronous DTO delivery.
- Generated A2L.
- MDF write and validation.
- XIL actions and verdicts.
- FMI export and SSP two-FMU orchestration.
- Traceability coverage and stale-evidence detection.
- Fault campaign coverage and reports.
- Integrated platform state.

### 14.3 End-to-end terminal regression

`industrial_platform_regression.py` drives the real `muzixdiagsys` terminal and verifies generated files for:

- HIL configuration.
- CAN FD.
- UDS.
- J1939.
- XCP/A2L.
- MDF.
- XIL.
- FMI 3 and SSP.
- Traceability.
- Fault campaign outputs.

### 14.4 Optimized build

GCC RelWithDebInfo with hardening enabled builds successfully. The industrial unit and end-to-end terminal regression pass in the optimized configuration.

### 14.5 Sanitizers

GCC AddressSanitizer and UndefinedBehaviorSanitizer build and execute `industrial_core_tests` with leak detection and halt-on-error enabled. No sanitizer finding was reported.

### 14.6 Cross-compiler validation

Clang 17 builds both `muzixdiagsys` and `industrial_core_tests`. The industrial unit and terminal regressions pass with the Clang build.

### 14.7 Packaging validation

The final archive is extracted into a clean directory, configured independently, built, and tested. This checks that no development build directory, absolute local path, or omitted generated source is required.

---

## 15. Build and run instructions

### Fedora prerequisites

```bash
sudo dnf install gcc-c++ cmake ninja-build zlib-devel python3
```

For SocketCAN testing:

```bash
sudo dnf install can-utils
```

### Configure and build

```bash
cmake -G Ninja -S . -B build \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DAESIM_ENABLE_HARDENING=ON

cmake --build build -j"$(nproc)"
ctest --test-dir build --output-on-failure
```

### Run

```bash
./build/muzixdiagsys
```

### Example virtual CAN setup

```bash
sudo modprobe vcan
sudo ip link add dev vcan0 type vcan
sudo ip link set up vcan0
```

Then:

```text
industrial network socketcan vcan0
industrial network open
industrial network status
```

### Real-time privileges

A strict SCHED_FIFO/memory-lock deployment generally needs an appropriate systemd unit or limits configuration, for example `LimitRTPRIO`, `LimitMEMLOCK`, CPU affinity, and suitable privileges. The simulator reports exact setup failures rather than claiming that privileges were granted.

---

## 16. Compatibility statement

The implementation is additive. It does not intentionally remove or rename existing engine presets, vehicle presets, dashboard pages, commands, reports, plugins, ABI-v1 or ABI-v2 interfaces, checkpoints, scenarios, schemas, FMI workflows, MIL/SIL modes, research workflows, calibration functions, uncertainty functions, APIs, or existing tests.

The existing executable remains `muzixdiagsys`. Existing scripts continue to use the prior commands unless they elect to invoke the industrial services.

---

## 17. Recommended next steps

The next technically sound additions would be:

1. Physical DAQ vendor backends implemented behind `HilIo`.
2. PTP/IEEE 1588 clock-domain correlation and hardware timestamps.
3. XCP over CAN/CAN-FD in addition to UDP.
4. MDF interoperability testing against independent commercial/open readers.
5. External ASAM XIL/SSP conformance assessment.
6. Security hardening for remotely exposed XCP and HIL networks.
7. AUTOSAR ARXML bindings.
8. Distributed SSP orchestration.
9. Dedicated PREEMPT_RT qualification scripts and latency histograms.
10. Requirements approval workflows and signed evidence bundles.

These are expansion items, not missing code paths in the delivered scope.

## 2026-07-12 next-generation vehicle-depth integration

HIL and XIL users can publish the new `electrification.depth.*` signals and exercise deterministic terrain, electrical, brake, ECU, and replay faults through the existing command gateway.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


# MuzixDiagSys Project and Diagnostic Workbench

## Scope

This document defines the implemented `.muzixproj` workspace format, the stateful guided-diagnostic workflow engine, and the diagnostic causal-graph subsystem. These facilities are production code in `aesim_professional`, `aesim_diagnostics`, the simulator runtime, and the terminal frontend. They do not replace or disable existing checkpoint, scenario, plugin, OBD, UDS, DoIP, SOVD, DTC, fault, logging, or UI commands.

## 1. First-class `.muzixproj` workspace

A `.muzixproj` file is UTF-8 JSON with schema identifier `muzixdiagsys.project` and version `1.0.0`. The machine-readable schema is `schemas/muzixproj.schema.json`.

The format persists:

- Vehicle and engine preset keys.
- Every parameter override applied through `set`.
- Enabled manifest, ABI-v1, and ABI-v2 plugins, including ABI-v2 isolation mode, configuration, seed, and enabled state.
- ECU nodes, OBD/UDS identifiers, DoIP logical addresses, and CAN/DoIP topology links.
- Active fault injections and severity.
- Scenario name, portable scenario path, options, and deterministic random seed.
- Imported datasets with media type, size, SHA-256 digest, role, and required/optional status.
- Named watch lists and the selected watch list.
- Terminal UI layout, filters, selected page, status-bar composition, watch visibility, and history length.
- User checkpoints plus an automatically refreshed `active-state` full simulator checkpoint.
- Generated reports and graph artifacts with SHA-256 inventory records.
- The complete active diagnostic workflow state in project metadata.

### 1.1 Portability and integrity

Resource, plugin, and scenario paths are stored relative to the project file whenever possible. Loading resolves them against the project location. Imported datasets and generated artifacts are validated by file size and SHA-256. Enabled plugins and scenario files must exist. Topology links must include at least one declared ECU endpoint; the opposite endpoint may be an ECU, CAN segment, Ethernet segment, gateway, or diagnostic transport.

Project loading is transactional. Before loading, MuzixDiagSys captures a rollback checkpoint and the current plugin/project inventory. It validates resources, restores the embedded checkpoint when present, relocates portable ABI-v2 plugin paths, verifies checkpoint integrity, restores plugins, applies overrides and faults when no checkpoint exists, and restores the workflow state. A failure restores the prior simulator and plugin state.

### 1.2 Project commands

```text
project status
project inspect
project new <file.muzixproj> [name]
project save [file.muzixproj]
project load <file.muzixproj>
project validate <file.muzixproj>
project set name <text>
project set description <text>
project set seed <unsigned-integer>
project set scenario <scenario.yaml|scenario.json>
```

Resource inventory:

```text
project dataset list
project dataset add <file> [role]
project dataset remove <id|path>
project artifact list
project artifact add <file> [role]
project artifact remove <id|path>
```

Watch lists and layout:

```text
project watch list
project watch create <name>
project watch select <name>
project watch add <metric>
project watch remove <metric>
project layout show
project layout set <dotted-key> <JSON-value>
```

Examples:

```text
project watch create diagnostics
project watch select diagnostics
project watch add engine_rpm
project watch add fuel_rail_pressure_kpa
project layout set dashboard_page "diagnostics"
project layout set watch_panel_visible true
project layout set watch_history 64
```

Interactive terminal sessions synchronize the current terminal layout and active watch metrics into the project after `project new` and `project save`. `project load` applies the project layout and active watch list to the current terminal session. Batch mode uses explicit `project layout` and `project watch` commands.

Embedded checkpoints and faults:

```text
project checkpoint list
project checkpoint add <name> [description]
project checkpoint restore <name>
project checkpoint remove <name>
project topology
project fault list
project fault add <fault> <severity-0..1>
project fault clear
```

Every project save replaces the generated `active-state` checkpoint with an exact image of plant state, controllers, scheduler, RNG streams, DTC/freeze-frame state, sensor and CAN state, health/execution state, and serializable ABI-v2 plugin state. Named user checkpoints remain intact.

## 2. Stateful diagnostic workflows

The workflow engine is resumable and serializable. Each definition contains preconditions, diagnostic requests, quantitative checks, pass/fail branches, candidate-root-cause statements, confirming tests, a repair-verification step, and Markdown report generation.

Implemented workflows:

| ID | Diagnostic scope |
|---|---|
| `crank-no-start` | Supply/starter, crank speed, synchronization proxy, low-side and rail pressure, combustion/run transition. |
| `lean-operation` | Closed-loop enablement, persistent lean confirmation, fuel delivery, unmetered air, exhaust leaks, and sensor bias. |
| `rich-operation` | Excessive pressure/delivery, injector leakage, restricted air, purge faults, and feedback-sensor bias. |
| `misfire` | Enablement, crank/NVH signature, cylinder contribution, fuel/ignition/compression, and repeat verification. |
| `low-fuel-pressure` | Fuel quantity, electrical supply, low-side pressure, rail tracking, pump duty, restriction, regulator, and leak-off. |
| `boost-control-deviation` | Enablement, target/actual deviation, charge-air leakage, actuator control, turbo speed, sensor plausibility, and limp state. |
| `catalyst-efficiency` | Monitor enablement, conversion efficiency, oxygen-storage response, sensor correlation, exhaust leakage, and drive-cycle verification. |
| `ev-isolation` | HV safety gating, ohms-per-volt threshold, branch sectionalization, moisture/coolant/contamination, and loaded isolation verification. |
| `can-communication` | Supply/topology discovery, drop ratio, ECU online ratio, addressing/gateway routing, physical layer, utilization, and U-code recurrence. |

### 2.1 Workflow commands

```text
workflow list
workflow start <workflow-id> [case-id]
workflow status
workflow requests
workflow evidence list
workflow evidence add <metric> <value|missing> [unit] [fact|model-derived|heuristic|missing] [note]
workflow evidence remove <metric>
workflow evaluate
workflow run [maximum-steps]
workflow verify
workflow report <file.md>
workflow save <file.json>
workflow load <file.json>
workflow reset
```

`workflow evaluate` executes the current step only. `workflow run` advances until a terminal branch, missing evidence, or the maximum step count. Missing required measurements place the case in `waiting-for-evidence`; operator evidence can then be supplied and execution resumed. `workflow verify` jumps to and executes the definition's repair-verification step.

### 2.2 Evidence semantics

Every evidence record includes metric, observed value, unit, expected condition, source, simulation time, outcome, and provenance class:

- `fact`: directly observed sensor, DTC, freeze-frame, electrical, network, or physical-test evidence.
- `model-derived`: calculated from authoritative simulator state.
- `heuristic`: a diagnostic inference or synthesized indicator that requires confirmation.
- `missing`: required evidence has not been acquired.

Operator-supplied evidence takes precedence over the live diagnostic context for the same metric. Metric keys preserve underscores; workflow IDs accept underscores or hyphens and canonicalize to hyphenated IDs.

### 2.3 Example: EV isolation case

```text
project fault add ev_isolation 0.40
workflow start ev-isolation CASE-HV-001
workflow requests
workflow evaluate
workflow evidence add isolated_branch_ohm_per_v 620 ohm/V fact branch-sectionalization
workflow run
workflow report reports/CASE-HV-001.md
workflow verify
project save garage_case.muzixproj
```

The workflow is embedded in the project, so closing and reopening the project resumes the case with its evidence and branch history.

## 3. Diagnostic causal graph

The causal graph converts the selected workflow, live measurements, active DTCs, freeze frames, authoritative ECU topology, workflow decisions, and template knowledge into a typed directed graph.

Node types:

- Symptom.
- DTC.
- Freeze frame.
- Sensor.
- Actuator.
- Wiring or network path.
- Operating condition.
- Candidate root cause.
- Confirming test.

Relationship types:

- Observed with.
- Indicates.
- Affects.
- Travels through.
- Occurs under.
- Requires.
- Confirms.
- Contradicts.

Each node carries a provenance class, confidence, value, source, and explanation. Candidate causes are ranked using supporting and contradicting edges, active DTCs, abnormal measurements, and workflow-derived hypotheses. A candidate is never represented as a fact merely because it ranks first.

### 3.1 Causal commands

```text
causal report [workflow-id]
causal validate [workflow-id]
causal missing [workflow-id]
causal explain <node-id> [workflow-id]
causal json <file.json> [workflow-id]
causal dot <file.dot> [workflow-id]
```

`causal report` groups nodes under `fact`, `model-derived`, `heuristic`, and `missing`, then prints ranked root causes with supporting evidence, contradicting evidence, and confirming tests. `causal missing` is an acquisition queue. JSON is suitable for automation; DOT is suitable for Graphviz.

Example:

```text
workflow start misfire CASE-MF-004
workflow evaluate
causal report misfire
causal missing misfire
causal explain cause-1-ignition-coil-spark-plug-or-secondary-circuit-fault misfire
causal json reports/CASE-MF-004-graph.json misfire
causal dot reports/CASE-MF-004-graph.dot misfire
```

Graph validation rejects unknown edge endpoints and duplicate typed edges, and requires the essential symptom, sensor, actuator, path, operating-condition, candidate-cause, and confirming-test categories. DTC and freeze-frame categories are present when that evidence exists and are represented as missing template evidence when relevant to a cause.

## 4. Recommended operating sequence

1. Create or load a project.
2. Select vehicle/engine and apply parameter overrides.
3. Register datasets and scenario, set the seed, and load plugins.
4. Capture a known-good project checkpoint.
5. Inject or reproduce the fault.
6. Start the matching workflow.
7. Evaluate one step at a time and collect missing evidence.
8. Generate and inspect the causal graph before replacing components.
9. Perform corrective action and run `workflow verify`.
10. Export the workflow report and causal graph.
11. Save the project, which embeds exact state and inventories the generated artifacts.

## 5. Implementation and qualification

Primary source files:

```text
include/aesim/professional/project.hpp
src/professional/project.cpp
include/aesim/industrial/diagnostic_workflow.hpp
src/industrial/diagnostic_workflow.cpp
include/aesim/industrial/diagnostic_causal_graph.hpp
src/industrial/diagnostic_causal_graph.cpp
```

Qualification:

```text
project_workflow_causal_unit_tests
project_workflow_causal_cli_regression
all_commands_completion_pty
all_commands_completion_regression
```

The unit test verifies complete project round-trip and digest failure detection, all nine workflow definitions and phase requirements, workflow state serialization, evidence-key behavior, report generation, all causal node types, all provenance classes, cause ranking, JSON, and DOT output. The CLI test exercises the public executable and verifies save/validate/load, exact checkpoints, faults, scenario/seed, datasets, watch/UI state, workflow persistence, reports, artifact inventory, and graph exports.

# MuzixDiagSys
## Virtual Vehicle, Secure OTA, Deterministic Networking, and Distributed Validation Platform

**Implementation date:** 2026-07-10  
**Language standard:** C++17  
**Baseline:** `advanced_engine_sim_assurance_platform_2026-07-10`  
**Integration strategy:** Additive; existing engine, research, professional, industrial HIL, assurance, diagnostic, FMI/SSP, AUTOSAR, cybersecurity, safety, and evidence capabilities are retained.

---

# 1. Executive summary

This release adds an independently compiled virtual-vehicle subsystem to the existing simulator. The subsystem implements the eight requested feature groups:

1. OpenDRIVE import and deterministic OpenSCENARIO execution.
2. OSI-oriented vehicle-world exchange.
3. Vehicle dynamics, tire forces, brake/ABS/regeneration, and environment models.
4. Uptane-oriented secure OTA metadata verification and A/B update rollback.
5. PTP/gPTP clock synchronization and TSN schedule synthesis.
6. COVESA VSS signal normalization and VISS-style access/subscription.
7. Formal artifact qualification profiles.
8. Deterministic local and TCP-distributed studies.

The implementation is integrated through the established `IndustrialPlatform` and is available under the `industrial vehicle` command family. A reusable public C++ API and a standalone remote study-worker executable are included.

No prior command family or simulator subsystem was removed. The registered test count increased from 38 to 40.

---

# 2. Source architecture

## 2.1 Public interface

```text
include/aesim/vehicle/vehicle.hpp
```

The public interface defines the road, scenario, OSI, vehicle, OTA, gPTP, TSN, VSS/VISS, qualification, distributed-study, worker-server, and platform-facade types.

## 2.2 Implementation units

```text
src/vehicle/
├── internal.hpp
├── world.cpp
├── dynamics.cpp
├── connected.cpp
├── study.cpp
└── platform.cpp
```

Responsibilities:

| File | Responsibility |
|---|---|
| `internal.hpp` | Bounded XML parsing, checked conversion, sockets, framing, file helpers, deterministic hashing utilities |
| `world.cpp` | OpenDRIVE geometry, lane/elevation data, routes, OpenSCENARIO runtime, OSI world encoding |
| `dynamics.cpp` | Tire-force model, hydraulic/ABS/regenerative braking, planar vehicle integration, environment loads |
| `connected.cpp` | Uptane metadata/A-B slots, gPTP clocks, TSN scheduler, VSS/VISS, qualification profiles |
| `study.cpp` | Study expansion, local thread pool, TCP worker protocol, retries, deterministic result ordering |
| `platform.cpp` | Live simulator signal integration and terminal command dispatch |

## 2.3 Tools and tests

```text
tools/study_worker.cpp
tests/vehicle_platform_tests.cpp
tests/vehicle_platform_regression.py
docs/virtual_vehicle_platform.md
```

The added implementation and dedicated tests comprise approximately 1,300 lines in the new subsystem and validation files, excluding documentation and modifications to existing integration files.

---

# 3. OpenDRIVE implementation

The importer uses a bounded internal XML parser and rejects malformed or structurally invalid input. Imported road definitions include:

- Road ID, name, length, and junction association.
- Predecessor and successor road links.
- Plan-view line geometry.
- Constant-curvature arc geometry.
- Linear-curvature spiral geometry.
- Cubic elevation polynomials.
- Lane sections.
- Positive and negative lane identifiers.
- Lane types.
- Cubic lane-width records.

Operational services include:

- Sampling a road by longitudinal and lateral coordinates.
- Lane-centered positioning.
- Elevation and grade calculation.
- Heading and curvature calculation.
- Nearest-road search using deterministic sampling and refinement.
- Directed route construction from road links.
- Canonical JSON summary export.

Example:

```text
industrial vehicle map load data/vehicle_world.xodr
industrial vehicle map sample 1 50 -1.5
industrial vehicle map nearest 101 1
industrial vehicle map route 1 2
industrial vehicle map export reports/opendrive.json
```

---

# 4. OpenSCENARIO execution

The runtime imports and executes an operational OpenSCENARIO 1.x profile containing:

- Scenario objects.
- Vehicle classifications.
- Bounding boxes.
- World positions.
- Lane positions resolved through the loaded OpenDRIVE map.
- Initial speeds.
- Simulation-time trigger conditions.
- Absolute speed actions.
- Acceleration actions.
- Teleport actions.
- Deterministic fixed-step progression.
- Reset to the imported initial state.
- Host-vehicle state injection from the live vehicle model.

Events are ordered deterministically by trigger time and import order. The runtime produces a coherent vehicle-world snapshot after every accepted step.

Example:

```text
industrial vehicle scenario load data/vehicle_world.xosc
industrial vehicle scenario run 10 0.01
industrial vehicle scenario reset
```

---

# 5. OSI-oriented vehicle-world interface

The implementation exposes OSI-style `osi3.GroundTruth` semantics through:

- Interface major and minor versions.
- Monotonic sequence number.
- Simulation timestamp.
- Host-vehicle identity.
- Environment state.
- Classified world objects.
- Position, orientation, velocity, and dimensions.

The binary exchange envelope uses:

- `OSI3` signature.
- Explicit envelope version.
- Checked 32-bit payload length.
- Canonical serialized world document.
- Bounded read and decode behavior.
- Round-trip validation.

Example:

```text
industrial vehicle osi export reports/world.osi
industrial vehicle osi import reports/world.osi
industrial vehicle osi json reports/world.json
```

**Scope boundary:** the envelope provides operational OSI-oriented world semantics and deterministic interchange. It is not represented as official OSI protobuf wire compatibility.

---

# 6. Vehicle dynamics, tires, brakes, and environment

## 6.1 Vehicle state

The vehicle model integrates:

- World X and Y position.
- Yaw angle.
- Longitudinal and lateral velocity.
- Yaw rate.
- Longitudinal and lateral acceleration.
- Four wheel angular speeds.
- Four wheel slip ratios.
- Brake state.

## 6.2 Vehicle configuration

Configurable parameters include:

- Vehicle mass.
- Yaw inertia.
- Wheelbase.
- Track width.
- Front weight distribution.
- Wheel radius and inertia.
- Drag area.
- Rolling resistance.
- Maximum steering angle.
- Front and rear tire parameters.

## 6.3 Tire model

The tire model calculates:

- Longitudinal force from slip ratio.
- Lateral force from slip angle.
- Axle-dependent stiffness.
- Road-friction scaling.
- Friction-ellipse saturation.
- Force-utilization ratio.
- Relaxation behavior through wheel-state evolution.

## 6.4 Brake system

The brake model implements:

- Pedal-to-pressure command.
- First-order hydraulic pressure dynamics.
- Front/rear brake distribution.
- Per-wheel friction torque.
- Slip-based ABS activation.
- ABS release and reapply behavior.
- Regenerative torque allocation.
- Regeneration fade at low vehicle speed.

## 6.5 Environment

The environment model supplies:

- Ambient pressure and temperature.
- Air density.
- Longitudinal and lateral wind.
- Road grade.
- Road-friction coefficient.
- Rain intensity.

The vehicle force balance includes aerodynamic drag, wind-relative velocity, rolling resistance, grade force, tire force, braking, and yaw moments.

Example:

```text
industrial vehicle dynamics configure data/vehicle_dynamics.yaml
industrial vehicle dynamics environment grade 0.04
industrial vehicle dynamics environment friction 0.75
industrial vehicle dynamics step 0.01 1500 0 0
industrial vehicle dynamics step 0.01 0 1 0
```

---

# 7. Uptane-oriented secure OTA and A/B rollback

The OTA subsystem implements:

- Persistent ECU identity and update state.
- Provisioned signing keys.
- Root metadata.
- Timestamp metadata.
- Snapshot metadata.
- Targets metadata.
- Role-specific key authorization.
- Signature thresholds.
- Duplicate-signature rejection.
- Metadata expiration checks.
- Per-role monotonic version checks.
- Timestamp-to-snapshot version consistency.
- Snapshot-to-targets version consistency.
- ECU target compatibility checks.
- SHA-256 target verification.
- Target-length verification.
- Inactive-slot staging.
- Pending activation state.
- Boot-health acceptance.
- Failed-health rollback.
- Recovery to a known bootable slot.
- Durable state and verified-role persistence.

The included profile uses deterministic HMAC-SHA256 signatures with provisioned keys. This provides executable security and rollback behavior for simulation and testing but is not represented as direct compatibility with official asymmetric Uptane/TUF metadata or production PKI.

Example:

```text
industrial vehicle ota init reports/ota ECU-001
industrial vehicle ota key root-key test-secret-material
industrial vehicle ota create-bundle reports/update.json firmware.bin firmware.bin 1 2099-12-31T23:59:59Z root-key
industrial vehicle ota verify reports/update.json
industrial vehicle ota stage firmware.bin firmware.bin
industrial vehicle ota activate
industrial vehicle ota boot healthy
```

A failed health report returns activation to the previously accepted slot.

---

# 8. PTP/gPTP and TSN

## 8.1 gPTP clock domain

The model implements:

- Multiple clocks.
- Clock identity.
- Priority 1 and priority 2.
- Clock class.
- Initial phase offset.
- Frequency error in ppm.
- Pairwise path delays.
- Deterministic best-master selection.
- Local-clock advancement.
- Phase correction.
- Frequency correction.
- Offset and path-delay reporting.

## 8.2 TSN schedule synthesis

The scheduler implements:

- Link bitrate and guard-band configuration.
- Periodic traffic streams.
- Route paths across multiple links.
- Periods and deadlines in integer nanoseconds.
- Payload sizes.
- Stream priorities.
- Bounded least-common-multiple hyperperiod calculation.
- Deterministic priority/deadline ordering.
- Nonoverlapping first-fit gate windows.
- Store-and-forward multi-hop timing.
- Deadline checking.
- Link utilization.
- Oversubscription detection.
- Machine-readable schedule reports.

Example:

```text
industrial vehicle ptp clock gm 1 6 1 0 0
industrial vehicle ptp clock ecu 128 248 128 50000 20
industrial vehicle ptp link gm ecu 1000
industrial vehicle ptp advance 0.1
industrial vehicle ptp sync

industrial vehicle tsn load data/vehicle_tsn.yaml
industrial vehicle tsn synthesize
industrial vehicle tsn report reports/tsn.json
```

**Scope boundary:** this is a deterministic timing and schedule model, not physical Ethernet hardware certification.

---

# 9. COVESA VSS and VISS

## 9.1 VSS normalization

The registry supports:

- Flattened signal-list imports.
- Nested VSS-style tree imports.
- Sensor, actuator, and attribute classification.
- Data types.
- Engineering units.
- Minimum and maximum values.
- Descriptions.
- Mapping to the simulator signal registry.
- Duplicate-path rejection.
- Mapped and unmapped coverage reporting.

Default mappings include vehicle speed, engine speed, engine torque, transmission gear, steering command, and brake-pedal command.

## 9.2 VISS-style service

The service supports:

- `GET` for mapped values.
- Bounded `SET` for actuator paths.
- Subscription creation.
- Subscription removal.
- Per-subscription sampling intervals.
- Deadbands.
- Event polling.
- Structured JSON responses.

Example:

```text
industrial vehicle vss load data/vehicle_vss.yaml
industrial vehicle vss list
industrial vehicle viss get Vehicle.Speed
industrial vehicle viss set Vehicle.Chassis.SteeringWheel.Angle 0.2
industrial vehicle viss subscribe Vehicle.Speed 0.1 0.01
industrial vehicle viss poll 1.0
```

---

# 10. Formal conformance and supplier qualification

The qualification engine provides named profiles for:

- OpenDRIVE.
- OpenSCENARIO.
- OSI envelopes.
- VSS documents.
- Uptane bundles.
- FMI packages.
- SSP packages.

Profile checks include, as appropriate:

- File existence and bounded size.
- Parseability.
- Required root element or package entry.
- Version metadata.
- Required semantic content.
- Geometry or entity presence.
- Duplicate identifier checks.
- Range and finite-number checks.
- Hash and integrity checks.
- Safe path validation.
- Round-trip import/export checks.

Every report includes:

- Artifact path.
- Profile name.
- SHA-256 digest.
- Overall verdict.
- Rule identifiers.
- Severity.
- Finding text.

Example:

```text
industrial vehicle qualify opendrive supplier_map.xodr reports/map.json
industrial vehicle qualify openscenario supplier_test.xosc reports/scenario.json
industrial vehicle qualify fmi supplier_model.fmu reports/fmi.json
```

**Scope boundary:** these are formal internal qualification profiles, not external standards-body certification.

---

# 11. Distributed deterministic study execution

## 11.1 Study definition

A YAML or JSON definition supports:

- Study name.
- Base seed.
- Explicit cases.
- Cartesian parameter grids.
- Deterministic case IDs.
- Deterministically derived per-case seeds.

## 11.2 Local execution

The local backend provides:

- Bounded worker count.
- Atomic case assignment.
- Independent deterministic case evaluation.
- Error capture per case.
- Stable output ordering by case ID.

## 11.3 Remote execution

The remote backend provides:

- One or more TCP worker endpoints.
- Parallel dispatch across endpoints.
- Length-prefixed canonical JSON protocol.
- Bounded request and response payloads.
- Endpoint parsing and validation.
- Connection and receive timeouts.
- Retry behavior.
- Worker identity reporting.
- Stable result ordering independent of completion order.

The standalone worker is:

```text
./build/aesim_study_worker 0.0.0.0 47000
```

Coordinator examples:

```text
industrial vehicle study local data/vehicle_study.yaml reports/local.json 16
industrial vehicle study remote data/vehicle_study.yaml reports/remote.json worker1:47000 worker2:47000
```

The direct regression verifies exact equality of deterministic local and TCP-remote result metrics.

---

# 12. Existing-system integration

The new platform is integrated into `aesim::industrial::IndustrialPlatform`.

The live update path:

- Advances gPTP clocks when configured.
- Maintains a host-vehicle world object.
- Updates live world position from simulator speed.
- Publishes vehicle-model measurements into the typed industrial signal registry.
- Allows VISS access to existing and new signals.

Command aliases route these names to the same platform:

```text
vehicle
opendrive
openscenario
osi
ota
uptane
ptp
gptp
tsn
vss
viss
qualify
conformance
study
distributed
```

Existing industrial, assurance, FMI, SSP, HIL, diagnostic, XCP, MDF, AUTOSAR, safety, and research commands remain unchanged.

---

# 13. Added example assets

```text
data/
├── vehicle_world.xodr
├── vehicle_world.xosc
├── vehicle_dynamics.yaml
├── vehicle_tsn.yaml
├── vehicle_vss.yaml
├── vehicle_study.yaml
└── vehicle_firmware.bin
```

The assets are exercised by the terminal regression and can also be used as working templates.

---

# 14. Validation

## 14.1 Functional regression

The complete Debug CTest registration contains 40 tests: the 38 preserved tests plus:

- `vehicle_platform_unit_tests`
- `vehicle_platform_regression`

The full matrix covers existing engine, dashboard, drivetrain, controller, plugin, API, research, professional, industrial, assurance, and new virtual-vehicle behavior.

## 14.2 Dedicated tests

The direct C++ suite verifies:

- OpenDRIVE parsing, sampling, routing, and nearest lookup.
- OpenSCENARIO entity initialization and timed speed action.
- OSI encode/decode and file round trip.
- Vehicle acceleration and braking response.
- Uptane successful activation.
- Uptane failed-health rollback.
- gPTP grandmaster election and convergence.
- Feasible TSN schedule synthesis.
- VSS/VISS read, actuator write, and subscription.
- Qualification profiles.
- Study grid expansion.
- Local threaded execution.
- Real TCP worker execution.
- Exact local/remote deterministic metric equality.

The terminal regression drives the same capabilities through `muzixdiagsys` and verifies produced OSI, TSN, qualification, study, and OTA artifacts.

## 14.3 Build and instrumentation matrix

| Configuration | Result |
|---|---|
| GCC Debug | Complete 40-test functional matrix passed |
| GCC RelWithDebInfo with hardening | Vehicle platform library, worker, and direct suite built and passed |
| Clang 17 Debug | Vehicle platform direct suite built and passed |
| GCC AddressSanitizer + UndefinedBehaviorSanitizer + leak detection | Vehicle platform direct suite passed with no findings |
| Source incomplete-marker scan | No TODO, FIXME, placeholder, stub, or `not implemented` marker in added platform code |
| Clean archive extraction/rebuild | Performed as final package gate |

The dedicated test uses explicit runtime requirements rather than the C `assert` macro, ensuring Release/NDEBUG builds still execute all checks.

---

# 15. Build instructions

Fedora dependencies:

```bash
sudo dnf install gcc-c++ cmake ninja-build zlib-devel sqlite-devel python3
```

Build:

```bash
cmake -G Ninja -S . -B build \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DAESIM_ENABLE_HARDENING=ON

cmake --build build -j"$(nproc)"
ctest --test-dir build --output-on-failure
```

Run:

```bash
./build/muzixdiagsys
./build/aesim_study_worker 0.0.0.0 47000
```

---

# 16. Standards positioning and limitations

The implementation is operational and tested, but the following distinctions are essential:

- OpenDRIVE and OpenSCENARIO implement complete executable profiles for the included and tested workflows, not every optional construct in every standard revision.
- The OSI adapter uses OSI-oriented ground-truth semantics and a deterministic envelope; it does not claim official protobuf wire compatibility.
- The Uptane-oriented implementation provides role metadata, signature thresholds, expiration, version consistency, target verification, and A/B rollback using provisioned HMAC-SHA256 keys. It does not claim official asymmetric Uptane/TUF metadata or PKI compatibility.
- The gPTP and TSN implementations are deterministic simulation and schedule-analysis models, not physical-network compliance certification.
- VSS/VISS behavior is a useful vehicle-signal normalization and access profile, not independent COVESA certification.
- Qualification reports are internal supplier acceptance evidence and do not replace official conformance suites.
- Distributed studies are deterministic at the study-case/result level. Cross-platform bitwise equivalence still depends on compiler, floating-point environment, and processor behavior captured by the existing provenance system.

These boundaries do not represent missing code paths or placeholders. They define the intended engineering profile and avoid overstating independent standards certification.

## 2026-07-12 next-generation vehicle-depth integration

The virtual-vehicle platform has gained a coupled next-generation depth runtime while retaining the previously documented vehicle, world, traffic, and interface capabilities.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


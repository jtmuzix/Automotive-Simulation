- [Engineering Intelligence Platform](ENGINEERING_INTELLIGENCE_PLATFORM.md) — consequence propagation, zonal E/E synthesis, software service graphs, vehicle timebase analysis, conservation, identifiability/sloppiness, signal/calibration provenance, causal root-cause inspection, reproducibility capsules, and cross-layer requirement budgets.

- [Global Mathematical Assurance](GLOBAL_MATHEMATICAL_ASSURANCE.md) — automatic error budgets, adaptive precision, exact reductions, convergence/MMS, derivative/KKT certification, consensus, property testing, and sealed evidence.

- [CTest Runtime-Artifact Fixture](CTEST_ARTIFACT_FIXTURE.md) — direct CTest build dependency closure, compiled-test fixture semantics, and missing-executable cascade prevention.

- [Global UI Architecture](GLOBAL_UI_ARCHITECTURE.md) — modular providers, context graph, rich forms, graph workflows, jobs, linked dashboards, persistence, virtualization, rendering, and accessibility.

## V16 graphical engineering desktop

- `ENGINEERING_UI_PLATFORM.md` (V16 section) - direct-manipulation browser docking, WebGL 3D, out-of-core telemetry plotting, virtualized data grid, graphical calibration/topology/scenario/workflow/track analysis, Semantic CLI/Problems, security, and qualification.

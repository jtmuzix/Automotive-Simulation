# High-Fidelity Multiphysics Vehicle Extension

## Scope

This extension adds ten coupled, executable simulation domains to the existing MuzixDiagSys engine and vehicle platform without replacing the prior vehicle, electrification, federation, assurance, console, or plugin APIs. The implementation is available as independent C++ components and as a synchronized runtime facade under `industrial energy high-fidelity`.

The implementation contains no intentionally empty model methods, disabled feature branches, synthetic success returns, or incomplete interfaces. Optional operations reject invalid inputs with exceptions or explicit command errors.

## Source layout

| Domain | Public interface | Implementation |
|---|---|---|
| Conservative multi-rate execution | `include/aesim/high_fidelity/vehicle_systems.hpp` | `src/vehicle/high_fidelity_chassis.cpp` |
| Multibody suspension and compliance | same | `src/vehicle/high_fidelity_chassis.cpp` |
| Flexible-ring tire and road contact | same | `src/vehicle/high_fidelity_chassis.cpp` |
| Torsional driveline and backlash | same | `src/vehicle/high_fidelity_powertrain.cpp` |
| Distributed thermal network | same | `src/vehicle/high_fidelity_powertrain.cpp` |
| Sensor uncertainty and faults | same | `src/vehicle/high_fidelity_controls.cpp` |
| ECU scheduling and TSN network | same | `src/vehicle/high_fidelity_controls.cpp` |
| Crank-angle engine and 1-D ducts | same | `src/vehicle/high_fidelity_engine.cpp` |
| Cell-resolved battery | same | `src/electrification/cell_resolved_pack.cpp` |
| Calibration, validation, and UQ | same | `src/core/automated_assurance.cpp` |
| Integrated runtime facade | `include/aesim/high_fidelity/integrated_vehicle.hpp` | `src/vehicle/high_fidelity_integrated.cpp` |
| Runtime command/signal integration | `include/aesim/electrification/electrification.hpp` | `src/electrification/platform.cpp` |
| Regression coverage | — | `tests/high_fidelity_vehicle_tests.cpp`, `tests/electrification_platform_tests.cpp` |

## 1. Conservative multi-rate solver

`ConservativeMultiRateSolver` uses integer nanosecond scheduling to prevent cumulative floating-point phase drift. Tasks define:

- Name and conservation domain
- Period and phase
- Priority
- Enabled state
- Callback returning the post-step conserved state and boundary fluxes

Tasks due at the same instant execute by descending priority and then registration order, producing deterministic execution on repeated runs. A callback returns energy, mass, charge, momentum, and their corresponding rates. For a quantity `q`, the solver evaluates the trapezoidal balance

```text
r_q = (q[k] - q[k-1]) - dt/2 * (flux[k-1] + flux[k])
```

The solver stores absolute and normalized residuals, maximum residuals, root-mean-square residuals, execution count, missed periods, and tolerance violations. Runtime periods and enabled states can be changed without rebuilding the task graph.

The integrated vehicle uses these nominal cadences:

| Task | Period |
|---|---:|
| Torsional driveline | 0.25 ms |
| Crank-angle engine and gas paths | 0.50 ms |
| Flexible-ring tires | 1.00 ms |
| Multibody suspension | 1.00 ms |
| Sensor and fault channels | 1.00 ms |
| ECU and TSN simulation | 1.00 ms |
| Cell-resolved battery | 10.00 ms |
| Distributed thermal network | 50.00 ms |

## 2. Multibody suspension and compliance

`MultibodySuspensionSystem` represents body heave, roll, and pitch plus four unsprung vertical degrees of freedom. Every corner includes:

- Hardpoint longitudinal and lateral position
- Motion ratio
- Wheel rate
- Asymmetric bump and rebound damping
- Unsprung mass
- Tire vertical stiffness and damping
- Progressive bump and rebound stops
- Longitudinal and lateral bushing stiffness and damping
- Compliance steer and compliance camber
- Kinematic camber and toe gain

The solver computes spring, damper, stop, anti-roll, tire, active-actuator, bushing, and aerodynamic loads. It reports wheel normal load, suspension travel, hub offsets, toe, camber, stop contact, airborne state, body accelerations, and total mechanical energy.

## 3. Flexible-ring tire and detailed road contact

`FlexibleRingTire` discretizes the belt into configurable radial ring nodes. The road is supplied as ordered contact samples containing longitudinal offset, height, friction scale, water-film depth, and loose-material depth.

Implemented behavior includes:

- Road enveloping over the finite contact patch
- Ring radial stiffness, damping, and neighbor coupling
- Loaded and effective rolling radius
- Wheel rotational dynamics
- Longitudinal slip and slip angle
- Transient relaxation-length dynamics
- Bristle deformation and damping
- Combined-slip friction utilization
- Load sensitivity
- Camber thrust
- Pneumatic trail and aligning moment
- Overturning moment
- Pressure-dependent vertical behavior
- Rolling resistance
- Water-film hydroplaning reduction
- Loose-surface friction reduction
- Tread/carcass two-node thermal dynamics
- Energy-based tread wear

Road height is interpolated from physical samples; empty sample arrays fall back to a flat, dry road rather than failing silently.

## 4. Torsional driveline and backlash

`TorsionalDriveline` is a multi-inertia drivetrain containing engine, gearbox input, propshaft, differential, and left/right wheel states. Elastic interfaces include clutch, gear mesh, propshaft, and both halfshafts.

Backlash uses explicit contact states `-1`, `0`, and `+1`. Torque is zero while traversing lash and resumes only after the relative angle reaches a flank. The model also includes:

- Clutch engagement and torque capacity
- Gear-ratio reflection
- Mesh damping
- Propshaft and halfshaft damping
- Open-differential preload
- Torque-bias ratio
- Commanded differential locking
- Reversal and shuffle transients
- Stored torsional energy
- Rotational kinetic energy
- Dissipation and first-law residual

## 5. Distributed thermal network

`DistributedVehicleThermalNetwork` contains the following thermal nodes:

```text
engine metal, engine oil, engine coolant,
battery core, battery coolant,
front/rear machines, front/rear inverters,
power-electronics coolant,
cabin air, cabin mass
```

Conductive links preserve equal and opposite heat transfer. Boundary devices include the high-temperature radiator, low-temperature radiator, battery chiller, cabin HVAC/heat pump, ambient cabin exchange, coolant pumps, and fan.

The model publishes:

- Every node temperature
- Instantaneous boundary heat input and output
- Radiator and chiller rejection
- HVAC heat flow
- Auxiliary electrical power
- Cumulative heat input and rejection
- Stored thermal energy
- Thermal conservation residual
- Battery, engine, and power-electronics derating flags

The integrated conservation solver consumes instantaneous boundary rates, not cumulative averages.

## 6. Sensor uncertainty and comprehensive fault injection

`UncertainSensorChannel` combines deterministic seeded uncertainty with a scheduled fault timeline. The normal sensor model supports:

- Bias
- Multiplicative scale error
- Gaussian white noise
- Quantization
- Configurable sample period and sample-and-hold behavior
- Transport latency through a timestamped delay line
- Lower and upper saturation
- Configurable slew-rate limiting
- Deterministic linear drift
- Seeded random-walk drift
- Probabilistic dropout

Scheduled faults support:

- Bias
- Scale/gain shift
- Stuck-at
- Dropout
- Saturation-high
- Saturation-low
- Noise burst
- Drift
- Rate limiting
- Quantization change
- Polarity reversal
- Intermittent open circuit

Each fault has an identifier, start time, duration, magnitude, optional mode-specific secondary value, duty cycle, and intermittency period. For rate-limit faults, magnitude is the rising slew limit and a nonzero secondary value is the falling slew limit. Multiple active faults compose in deterministic order. Outputs include measured value, validity, held/saturated state, age, uncertainty sigma, active fault IDs, and source timestamp. `SensorFaultInjectionSuite` manages named channels and aggregate fault clearing.

## 7. Real-time ECU scheduling linked to network timing

`RealtimeEcuNetworkSimulator` models distributed ECUs, fixed-priority preemptive tasks, and a gated Ethernet/TSN link in the same microsecond timebase.

ECU tasks define:

- Owning ECU
- Period, phase, deadline, and priority
- Best, typical, and worst execution times
- Optional required input message and maximum input age
- Optional emitted output message, payload, destination, priority, and deadline

The scheduler models releases, blocking on unavailable or stale network data, background CPU load, preemption, completion, response time, and deadline misses. Task output frames are not available to downstream tasks until serialization, TSN gate eligibility, propagation, and destination delivery have completed.

Network behavior includes:

- Configurable bit rate
- Ethernet framing overhead
- Strict priority among eligible frames
- IEEE 802.1Qbv-style recurring gate windows
- Serialization delay
- Propagation delay
- Frame deadlines
- Delivery latency statistics
- Utilization
- Deadline misses

## 8. Crank-angle combustion and one-dimensional gas dynamics

`CrankAngleGasDynamicsEngine` couples the pre-existing cylinder-resolved combustion model to finite-volume intake and exhaust ducts. Each duct contains configurable cells and evolves compressible conserved variables using a bounded CFL substep.

Implemented gas-path behavior includes:

- Density, velocity, pressure, temperature, and total energy per cell
- Compressible numerical fluxes
- Choked boundary behavior
- Darcy friction
- Wall heat transfer
- Positivity preservation
- Inlet/outlet mass flow
- Stored gas mass and energy
- Mass and energy residuals

The engine integrates crank angle from RPM and evaluates cylinder volume, piston motion, valve effective area, cylinder pressure, combustion heat release, gas exchange, pumping, friction, indicated power, brake torque, fuel flow, exhaust temperature, and peak cylinder pressure. Cylinder phase offsets preserve firing order and individual-cylinder state.

## 9. Cell-resolved electrochemical battery and propagation

`CellResolvedElectrochemicalPack` explicitly stores every series/parallel cell. The default integrated vehicle contains 96 series groups and four parallel cells per group, for 384 independently evolving cell states.

Each cell contains:

- Bulk and surface state of charge
- Diffusion polarization
- Electrolyte overpotential
- Ohmic and charge-transfer resistance
- Terminal voltage and current
- Heat generation
- Temperature
- SEI thickness
- Lithium-plating fraction
- Capacity loss
- Resistance growth
- Internal-short resistance
- Thermal-runaway progress
- Vent state

Parallel-cell current sharing is solved from cell open-circuit voltage and effective resistance subject to the series-group current constraint. The pack model includes coolant heat transfer, cell-neighbor conduction, short-circuit heating, Arrhenius runaway progression, exothermic heat release, and thermal propagation through the adjacency graph.

Pack outputs include voltage, current, power, SOC range, temperature range, heat, capacity fade, resistance growth, voltage/temperature violations, runaway and vented cell counts, stored electrochemical and thermal energy, charge residual, and energy residual.

## 10. Automated calibration, validation, and uncertainty quantification

`AutomatedCalibrationValidationUQ` performs bounded nonlinear weighted least squares using a damped Gauss-Newton/Levenberg-Marquardt iteration with finite-difference Jacobians and bound projection.

It provides:

- Parameter bounds and finite-difference scales
- Observation-specific standard uncertainty
- Convergence and cost history outcome
- Parameter covariance from the information matrix
- Regularized fallback for singular information matrices
- Parameter standard errors and 95% intervals
- Normalized sensitivities
- K-fold cross-validation
- RMSE, MAE, maximum error, R², normalized RMSE, residual mean, and lag-one correlation
- Deterministic covariance sampling
- Predictive 95% intervals and empirical coverage
- Warnings for nonconvergence, correlation, poor coverage, and cross-validation degradation
- JSON export

The integrated facade records road-load observations and estimates vehicle mass, rolling resistance, and aerodynamic drag area. When insufficient runtime data exist, a deterministic reference experiment is used so the calibration path remains executable and testable.

## Runtime commands

```text
industrial energy high-fidelity status
industrial energy high-fidelity auto on|off
industrial energy high-fidelity reset [ambient_k]
industrial energy high-fidelity step [dt_s] [rpm torque_nm speed_m_s wheel_torque_nm brake]
industrial energy high-fidelity road <mu> <roughness_m> [water_m] [loose_m]
industrial energy high-fidelity steering <rad>
industrial energy high-fidelity sensor-fault <sensor> <mode> <id> <start_s> <duration_s> <magnitude> [secondary] [duty] [period_s]
industrial energy high-fidelity sensor-clear
industrial energy high-fidelity battery-short <series> <parallel> <resistance_ohm>
industrial energy high-fidelity calibrate [iterations] [folds] [uq_samples]
industrial energy high-fidelity assurance-export <output.json>
industrial energy high-fidelity solver|suspension|tires|driveline|thermal|sensors|ecu|engine|battery
```

Accepted sensor fault mode names are:

```text
bias scale drift stuck dropout saturation-high saturation-low noise-burst
rate-limit quantization-change polarity-reverse intermittent-open
```

## Published signals

The existing industrial signal registry exposes writable environment/command signals and synchronized measurements under `electrification.high_fidelity.*`. Important examples are:

```text
electrification.high_fidelity.command.steering_angle_rad
electrification.high_fidelity.environment.road_friction
electrification.high_fidelity.environment.road_roughness_m
electrification.high_fidelity.time_s
electrification.high_fidelity.conservation.severity
electrification.high_fidelity.conservation.violations
electrification.high_fidelity.suspension.heave_m
electrification.high_fidelity.suspension.roll_rad
electrification.high_fidelity.suspension.pitch_rad
electrification.high_fidelity.suspension.vertical_load_n
electrification.high_fidelity.tire.longitudinal_force_n
electrification.high_fidelity.tire.lateral_force_n
electrification.high_fidelity.driveline.propshaft_torque_nm
electrification.high_fidelity.battery.voltage_v
electrification.high_fidelity.battery.current_a
electrification.high_fidelity.battery.soc
electrification.high_fidelity.battery.maximum_temperature_k
electrification.high_fidelity.battery.runaway_cells
electrification.high_fidelity.engine.indicated_torque_nm
electrification.high_fidelity.engine.intake_pressure_pa
electrification.high_fidelity.engine.exhaust_pressure_pa
electrification.high_fidelity.thermal.engine_coolant_c
electrification.high_fidelity.thermal.battery_core_c
electrification.high_fidelity.network.mean_latency_us
electrification.high_fidelity.network.deadline_misses
electrification.high_fidelity.calibration.observations
electrification.high_fidelity.calibration.cv_rmse
```

## C++ integration example

```cpp
#include "aesim/high_fidelity/integrated_vehicle.hpp"

using namespace aesim::high_fidelity;

IntegratedHighFidelityVehicle vehicle;
IntegratedVehicleInput input;
input.engine_rpm = 1800.0;
input.engine_torque_nm = 140.0;
input.requested_wheel_torque_nm = 900.0;
input.vehicle_speed_m_s = 15.0;
input.vehicle_acceleration_m_s2 = 0.5;
input.steering_angle_rad = 0.02;
input.road_friction = 0.9;
input.road_roughness_m = 0.003;

vehicle.set_input(input);
for (int index = 0; index < 200; ++index) {
    const auto& state = vehicle.advance(0.005);
    (void)state;
}

const auto assurance = vehicle.calibrate_road_load();
vehicle.export_last_assurance("road_load_assurance.json");
```

## Validation coverage

`high_fidelity_vehicle_tests` exercises:

- Deterministic multi-rate ordering and conservation statistics
- Multibody corner/body dynamics and compliance
- Tire road enveloping, wet friction, force, temperature, and wear
- Backlash traversal and torque reversal
- Thermal graph conservation and HVAC/radiator behavior
- Sensor uncertainty and every fault mode family
- ECU release, preemption, network blocking, TSN transmission, and deadlines
- Crank-angle combustion and finite-volume gas paths
- Cell current sharing, electrochemical evolution, internal short, runaway, and propagation
- Calibration accuracy, covariance, cross-validation, predictive intervals, and JSON export
- End-to-end integrated task graph and runtime state coupling

`electrification_platform_tests` additionally exercises the public command facade, automatic runtime update, signal publication, sensor-fault commands, reports, calibration command, and assurance export.

These models are engineering simulation and virtual verification components. They do not, by themselves, constitute regulatory approval, safety certification, homologation, or proof of physical-system fitness.

## 2026-07-12 next-generation vehicle-depth integration

The established high-fidelity layer remains the base plant; the new depth runtime adds higher-bandwidth and spatial states through `IntegratedVehicleDepthRuntime`.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


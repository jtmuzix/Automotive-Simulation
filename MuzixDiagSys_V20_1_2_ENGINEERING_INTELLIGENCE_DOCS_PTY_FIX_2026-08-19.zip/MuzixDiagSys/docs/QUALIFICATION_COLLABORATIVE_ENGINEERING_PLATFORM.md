# Qualification and Collaborative Engineering Platform

## Scope

This additive C++17 platform connects compliance evidence, tool qualification, automotive measurement and calibration, deterministic debugging, regression intelligence, real-time timing, AUTOSAR engineering, autonomous-driving qualification, CAD/meshing, and governed engineering collaboration. The APIs are included by:

```cpp
#include "aesim/advanced/platform.hpp"
```

The implementation uses the same canonical document and SHA-256 provenance infrastructure as the existing MuzixDiagSys advanced platform. Every major assessment or generated artifact has deterministic machine-readable output.

## 1. Compliance and certification evidence

`ComplianceEvidenceEngine` stores framework clauses, applicability expressions, evidence requirements, accepted verification methods, independent-review requirements, physical-confirmation requirements, evidence-age limits, revocations, and trace links. Assessment produces satisfied, partial, unsatisfied, not-applicable, and stale verdicts plus a release-readiness decision and audit package.

Supported applicability operators are equality, inequality, conjunction, and disjunction over the configured release context. Evidence is rejected when its artifact hash, approval state, method, evidence type, reviewer independence, physical status, revocation state, or age does not satisfy the clause.

## 2. Tool qualification and trusted computation

`ToolQualificationEngine` validates source and binary identities and executes deterministic golden vectors. Document comparison is recursive and supports exact structural comparison plus numeric tolerance. `TrustedComputationChain` records compiler and platform identity, command lines, selected environment values, content-addressed inputs and outputs, and a previous-manifest link. Verification re-hashes artifacts and the canonical manifest.

## 3. ASAM-oriented measurement and calibration

`Mdf4File` provides deterministic measurement-file storage with MDF 4.20 identification and structured header, channel-group, and file-history records. The project profile stores typed channels, timestamps, physical values, conversion information, metadata, and an evidence digest. `A2lParser` imports and emits PROJECT, MODULE, MEASUREMENT, and CHARACTERISTIC objects. `XcpMemoryImage` implements connected page selection plus bounded upload and download operations. `ClockAligner` estimates offset, scale, drift, RMS residual, maximum residual, and inliers with iterative outlier rejection.

The implementation intentionally reports itself as the project’s deterministic MDF/A2L/XCP profile; it does not silently claim support for every compression method or vendor extension used by every external tool.

## 4. Deterministic time-travel debugging

`TimeTravelDebugger` records ordered state deltas with timestamps, categories, components, messages, causal predecessors, and event hashes. It reconstructs state at any sequence, reverse-steps, forks historical execution, computes causal slices, and locates the first divergence between two histories. Reports include initial state, events, snapshots, and deterministic identities.

## 5. Regression intelligence

`RegressionIntelligenceEngine` compares baseline and candidate artifact graphs, computes transitive impact, identifies invalidated evidence and required tests, evaluates numeric series against absolute and relative tolerances, and estimates test flakiness from historical outcomes. The final gate fails when changes are unqualified, evidence is invalidated without replacement, numeric drift exceeds tolerance, or tests are unstable beyond the implemented policy.

## 6. Hard real-time timing laboratory

`RealTimeTargetLaboratory` executes deterministic multicore periodic workloads under fixed-priority or earliest-deadline-first scheduling. It models release jitter, preemption, CPU affinity, WCET, deadlines, response time, scheduling latency, and deadline misses. `PtpClockDiscipline` estimates clock offset, path delay, drift, and residual error from timestamp exchanges.

This is a timing qualification laboratory and trace generator. Physical claims still require measurements from the actual target, operating system, compiler, clock source, and workload configuration.

## 7. AUTOSAR Classic and Adaptive toolchain

`AutosarToolchain` provides deterministic ARXML parsing and emission for the project semantic profile, including ports, runnables, timing properties, SOME/IP service identities, processes, and service dependencies. Validation detects incomplete timing, WCET/deadline errors, duplicate service identities, missing dependencies, excessive CPU utilization, and unmapped tasks. The toolchain generates standalone Classic-style RTE C interfaces and Adaptive-style process/service manifests.

The parser uses bounded token and attribute processing rather than regular expressions. XML entities and quoted attributes are validated. The semantic profile is round-trippable and does not discard represented fields; it is not advertised as an exhaustive implementation of every AUTOSAR schema revision and vendor extension.

## 8. End-to-end ADS qualification

`AdsQualificationLaboratory` evaluates timestamped closed-loop frames containing ego state, surrounding actors, lane geometry, speed limits, commands, localization validity, map validity, and minimum-risk operation. It computes collision count, minimum distance, time to collision, lane error, jerk, speeding, localization/map failures, minimum-risk activations, requirement verdicts, and an evidence digest.

## 9. CAD and meshing

`CadMeshingPipeline` imports OBJ, ASCII STL, and a faceted STEP AP242 subset, exports OBJ and STL, heals duplicated vertices and invalid topology, recursively refines triangles to a requested edge length, and calculates surface area, signed volume, minimum angle, maximum aspect ratio, boundary edges, non-manifold edges, degeneracy, and watertightness. A deterministic box primitive is included for qualification and examples.

The STEP reader is a complete faceted-profile implementation for the published API. NURBS construction, proprietary kernels, and every AP242 entity are outside that profile and are not reported as supported.

## 10. Collaborative visual engineering studio

`CollaborativeEngineeringStudio` provides users and roles, branches, immutable commits, artifact revisions, comments, resolution, reviews, three-way merging, conflict reporting, audit state, and deterministic commit/evidence hashes. Authorization is enforced for viewer, engineer, reviewer, approver, and administrator actions. `export_static_studio` creates a self-contained HTML/CSS/JavaScript project viewer from the exact backend state.

The browser client contains no engineering decision logic; authoritative validation, merge, evidence, and permission decisions remain in the C++ backend.

## Build and qualification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DAESIM_BUILD_TESTS=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build --target \
  qualification_studio_platform_tests \
  muzixdiagsys_advanced_platform -j
ctest --test-dir build \
  -R 'qualification_studio_platform|advanced_platform_cli_self_test' \
  --output-on-failure
```

Strict compilation is qualified with `-std=c++17 -Wall -Wextra -Wpedantic -Werror`. The cross-domain test is also executed with AddressSanitizer, UndefinedBehaviorSanitizer, and leak detection. The generated browser JavaScript is validated with `node --check`.

## External-system boundaries

Formal certification, physical real-time qualification, commercial ASAM interoperability, production AUTOSAR deployment, proprietary CAD-kernel behavior, and enterprise multi-user hosting require the corresponding external standards content, target hardware, vendor tools, trust services, and organizational approvals. The platform preserves this distinction in evidence and documentation rather than fabricating external availability.

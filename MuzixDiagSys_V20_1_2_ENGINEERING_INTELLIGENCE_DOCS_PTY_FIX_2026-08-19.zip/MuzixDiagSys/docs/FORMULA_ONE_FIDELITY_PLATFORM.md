# Formula One Predictive-Fidelity Platform

## Purpose

The Formula One predictive-fidelity platform supplies a deterministic, SI-unit,
C++17 implementation of five tightly integrated capabilities:

1. A fully coupled four-corner full-car dynamic simulation kernel.
2. An advanced transient tyre and wet-contact model.
3. Telemetry-driven state and parameter estimation.
4. Validation, uncertainty-quantification, and identifiability analysis.
5. Sensor, DAQ, latency, and clock-synchronization realism.

The production API is declared in:

```cpp
#include "aesim/advanced/formula_one_fidelity_platform.hpp"
```

It is compiled into `aesim_formula_one` and is also exported through
`aesim/advanced/formula_one_platform.hpp` and the aggregate
`aesim/advanced/platform.hpp` header. Existing Formula One APIs and libraries
remain unchanged.

All model inputs and outputs use SI units. Every public configuration validates
ranges and finite values before execution. Numerical paths reject NaN and
infinite values rather than writing invalid state into a later evidence product.

## Architecture

The fidelity platform is intentionally layered:

```text
physical environment and driver/control commands
                     |
                     v
      F1FullyCoupledCarDynamicsKernel
        |       |       |       |
        v       v       v       v
      FL tyre  FR tyre  RL tyre  RR tyre
        \       |       |       /
         F1AdvancedTransientTyreModel
                     |
                     v
             physical truth channels
                     |
                     v
             F1SensorDaqPipeline
                     |
                     v
        F1ClockSynchronizationEstimator
                     |
                     v
 F1TelemetryStateParameterEstimator
                     |
                     v
   validation / uncertainty / identifiability
```

The car kernel and tyre model produce physical truth. The sensor and DAQ layer
converts truth into instrumentation-like packets. Clock synchronization maps
sensor-local time into a common reference. The estimator consumes synchronized
measurements and returns state and parameter posterior estimates. Validation,
uncertainty, and identifiability then quantify predictive error, output
variation, and whether the calibration problem is observable.

## 1. Fully coupled full-car dynamic kernel

### Public types

- `F1CoupledCarConfiguration`
- `F1CoupledCarEnvironment`
- `F1CoupledCarControl`
- `F1CoupledCarState`
- `F1CoupledCarStepResult`
- `F1FullyCoupledCarDynamicsKernel`

### Dynamic states

The kernel advances:

- World position.
- Body-frame longitudinal, lateral, and vertical velocity.
- Roll, pitch, and yaw attitude.
- Roll, pitch, and yaw angular velocity.
- Body-frame acceleration.
- Four suspension compression and velocity states.
- Four complete transient tyre states.
- Fuel mass and cumulative energy accounting.

The coordinate system is right-handed:

- Positive `x`: forward.
- Positive `y`: vehicle left.
- Positive `z`: upward.
- Positive roll: left side rises.
- Positive pitch: nose moves downward under the right-hand convention.
- Positive yaw: left turn.

### Couplings

Each internal integration step performs the following sequence:

1. Transform world wind into the vehicle body frame.
2. Calculate air-relative speed, aerodynamic drag, and downforce.
3. Correct aerodynamic load for pitch, ride height, and active-aero command.
4. Distribute static and aerodynamic axle load.
5. Calculate four corner body heights and vertical velocities.
6. Calculate spring, damper, anti-roll, preload, and bump-stop forces.
7. Transform hub velocity into each steered wheel frame.
8. Advance each transient tyre model.
9. Integrate each wheel's rotational dynamics from drive, brake, engine-brake,
   and tyre reaction torque.
10. Transform tyre forces back into the body frame.
11. Accumulate body force and roll, pitch, and yaw moments.
12. Advance body translation and rotation.
13. Transform body velocity into world displacement.
14. Burn fuel from delivered drive energy.
15. Audit mechanical energy, external work, and dissipative losses.

The kernel automatically subdivides a caller step according to
`maximum_internal_step_s`. A 10 ms caller step with a 2 ms internal limit is
therefore executed as five deterministic coupled substeps.

### Force and moment model

Aerodynamic force uses:

```text
q = 0.5 * rho * V_air^2
D = q * A * Cd(active_aero)
L_down = q * A * (-Cl(active_aero)) * platform_factor
```

The platform factor is bounded and depends on pitch and average ride height.
Wheel forces are transformed through the road-wheel steering angle. Ground
forces generate force and moments at the physical corner coordinates, including
CG-height contributions. Suspension forces and aerodynamic center-of-pressure
moments use the same coordinate convention.

### Energy audit

`F1CoupledCarStepResult` reports:

- `mechanical_energy_j`
- `external_work_j`
- `energy_residual_j`
- cumulative fuel energy
- cumulative tyre dissipation
- cumulative aerodynamic dissipation

The residual is a numerical diagnostic, not an assertion that the reduced-order
vehicle model captures every energy storage mechanism. It should remain finite
and should decrease as the internal integration step is reduced.

### Example

```cpp
#include "aesim/advanced/formula_one_fidelity_platform.hpp"

using namespace aesim::advanced;

F1CoupledCarConfiguration car_configuration;
car_configuration.maximum_internal_step_s = 0.001;
F1FullyCoupledCarDynamicsKernel car(car_configuration);

F1CoupledCarEnvironment environment;
environment.track_temperature_k = 318.15;
environment.air_density_kg_m3 = 1.16;

F1CoupledCarControl control;
control.throttle = 0.65;
control.steering_wheel_angle_rad = 0.18;

F1CoupledCarState state = car.make_initial_state(55.0);
for (int step = 0; step < 1000; ++step) {
    const auto result = car.step(0.002, control, environment, state);
    state = result.state;
}
```

## 2. Advanced transient tyre and wet-contact model

### Public types

- `F1TransientTyreConfiguration`
- `F1TransientTyreInput`
- `F1TransientTyreState`
- `F1TransientTyreResult`
- `F1AdvancedTransientTyreModel`

### Transient slip

Instantaneous longitudinal slip ratio and lateral slip angle are passed through
speed-dependent relaxation dynamics:

```text
kappa_eff(k+1) = kappa_eff(k)
  + [1 - exp(-V * dt / L_kappa)] * [kappa_inst - kappa_eff(k)]

alpha_eff(k+1) = alpha_eff(k)
  + [1 - exp(-V * dt / L_alpha)] * [alpha_inst - alpha_eff(k)]
```

This prevents tyre force from changing instantaneously when steering, torque,
or contact velocity changes.

### Friction capacity

Dry friction includes:

- Vertical-load sensitivity.
- Inflation-pressure sensitivity.
- Surface-temperature operating window.
- Rubber coverage.
- Surface roughness.
- Wear and flat-spot degradation.

The unsaturated longitudinal and lateral demands are combined using a smooth
friction-circle saturation. Sliding demand transitions from peak friction toward
the configured sliding-friction ratio.

### Wet contact and aquaplaning

Wet-contact behavior includes:

- Water-film depth.
- Groove void fraction.
- Remaining tread depth.
- Time-dependent drainage.
- Tyre pressure.
- Vehicle speed.
- Water saturation retained in the contact region.

The aquaplaning threshold is pressure dependent. A bounded smooth transition
converts speed and residual water into `aquaplaning_fraction`. The resulting
wet-friction scale reduces the dry capacity without discontinuities.

The result reports:

- Drained water depth.
- Aquaplaning fraction.
- Wet-friction scale.
- Contact-patch area and length.
- Longitudinal and lateral force.
- Aligning moment.
- Rolling resistance.

### Thermal and wear states

The model contains three thermal nodes:

- Tread surface.
- Carcass.
- Internal gas.

Heat sources include longitudinal and lateral slip plus brake heat transfer.
Heat paths connect surface-to-carcass, surface-to-track, carcass-to-gas, and
carcass-to-ambient. Water increases surface heat transfer to the track.
Inflation pressure follows the gas-temperature ratio.

Wear accumulates from slip energy and increases when the surface operates above
or below the configured temperature window. Severe locked-wheel slip produces a
persistent flat-spot state.

### Standalone example

```cpp
F1AdvancedTransientTyreModel tyre;
F1TransientTyreState state;
F1TransientTyreInput input;
input.time_step_s = 0.001;
input.normal_load_n = 4200.0;
input.wheel_center_longitudinal_speed_m_s = 70.0;
input.wheel_center_lateral_speed_m_s = 1.2;
input.wheel_angular_speed_rad_s = 214.0;
input.water_film_depth_m = 0.004;

const F1TransientTyreResult result = tyre.step(input, state);
state = result.state;
```

## 3. Sensor, DAQ, latency, and synchronization realism

### Public types

- `F1SensorChannelConfiguration`
- `F1SensorChannelState`
- `F1DaqPacket`
- `F1SensorDaqPipeline`
- `F1ClockSynchronizationObservation`
- `F1ClockSynchronizationResult`
- `F1ClockSynchronizationEstimator`

### Channel effects

Each sensor channel can model:

- Sample rate.
- Scale-factor error.
- Static bias.
- White noise.
- Bias random walk.
- Temperature coefficient.
- Quantization.
- Minimum and maximum saturation.
- First-order low-pass response.
- Mean transport latency.
- Latency jitter.
- Packet dropout.
- Local clock offset.
- Clock frequency drift in parts per million.

The pseudo-random process is deterministic for a configured seed. Resetting the
pipeline returns all clocks, filter states, random walks, sequence counters, and
random generators to their initial state.

### Packet ordering

Packets are queued by arrival time rather than source timestamp. Latency jitter
can therefore produce delivery reordering. `receive_until()` returns only
packets whose simulated arrival time is no later than the requested reference
time.

### Clock synchronization

The synchronization estimator fits the weighted affine mapping:

```text
reference_time = scale * source_time + offset
```

It reports:

- Fitted scale.
- Fitted offset.
- RMS residual.
- Maximum residual.
- Observation count.

Use `F1ClockSynchronizationResult::correct()` to transform future source
timestamps into reference time.

### Example

```cpp
F1SensorChannelConfiguration speed;
speed.id = "vehicle_speed";
speed.sample_rate_hz = 500.0;
speed.white_noise_standard_deviation = 0.05;
speed.quantization_step = 0.01;
speed.latency_mean_s = 0.003;
speed.latency_jitter_standard_deviation_s = 0.0005;
speed.clock_offset_s = 0.12;
speed.clock_drift_ppm = 15.0;
speed.random_seed = 17;

F1SensorDaqPipeline daq({speed});
daq.reset(0.0);
daq.sample_until(0.100, {{"vehicle_speed", 72.4}}, 315.15);
const auto packets = daq.receive_until(0.110);
```

## 4. Telemetry-driven state and parameter estimation

### Public types

- `F1TelemetryMeasurementType`
- `F1TelemetryMeasurement`
- `F1EstimatorProcessInput`
- `F1EstimatedVehicleState`
- `F1EstimatorConfiguration`
- `F1EstimatorUpdateResult`
- `F1TelemetryStateParameterEstimator`

### Estimated quantities

The extended Kalman estimator maintains twelve states:

1. Longitudinal speed.
2. Lateral speed.
3. Yaw rate.
4. Roll angle.
5. Pitch angle.
6. Longitudinal accelerometer bias.
7. Lateral accelerometer bias.
8. Yaw-rate sensor bias.
9. Wheel-speed scale factor.
10. Tyre-friction scale.
11. Aerodynamic scale.
12. Vehicle-mass scale.

### Process model

The nonlinear process model uses:

- Front and rear axle geometry.
- Front and rear cornering stiffness.
- Tyre-friction scale.
- Aerodynamic drag and downforce.
- Drive and brake force.
- Vehicle mass scale.
- Saturated front and rear lateral force.
- Roll and pitch response time constants.

The transition Jacobian is calculated using deterministic finite differences.
Covariance propagation uses the full transition matrix and configured process
noise.

### Measurement model

Supported measurements are:

- Longitudinal speed.
- Wheel speed.
- Yaw rate.
- Lateral acceleration.
- Longitudinal acceleration.
- Roll angle.
- Pitch angle.
- Front ride height.
- Rear ride height.

Measurements are processed sequentially. Each scalar update uses a Joseph-form
covariance update for numerical stability. Measurements with a normalized
innovation magnitude above eight are rejected as outliers and reported in the
update result.

### Workflow

1. Initialize the state and one-standard-deviation uncertainty.
2. Call `predict()` at the estimator process rate.
3. Synchronize incoming DAQ packets.
4. Convert packets into `F1TelemetryMeasurement` values.
5. Call `update()` with all measurements valid at that time.
6. Read posterior state, parameter, and uncertainty using `current()`.

### Example

```cpp
F1TelemetryStateParameterEstimator estimator;
F1EstimatedVehicleState initial;
initial.longitudinal_speed_m_s = 60.0;

std::array<double, 12> sigma{{
    5.0, 2.0, 0.08, 0.03, 0.03, 0.5,
    0.5, 0.02, 0.03, 0.20, 0.20, 0.10}};
estimator.initialize(initial, sigma);

F1EstimatorProcessInput process;
process.steering_angle_rad = 0.015;
process.drive_force_n = 2500.0;
process.aerodynamic_drag_n = 1800.0;
process.aerodynamic_downforce_n = 9000.0;

estimator.predict(0.002, process);
const auto update = estimator.update({
    {F1TelemetryMeasurementType::LongitudinalSpeed, 61.2, 0.15, 1.002},
    {F1TelemetryMeasurementType::YawRate, 0.23, 0.003, 1.002},
    {F1TelemetryMeasurementType::LateralAcceleration, 13.8, 0.12, 1.002}
}, process);
```

## 5. Validation framework

### Public types

- `F1ValidationSeries`
- `F1ValidationMetrics`
- `F1ValidationFramework`

For each synchronized reference/prediction series, the framework calculates:

- Mean error.
- Mean absolute error.
- Root-mean-square error.
- Normalized RMSE.
- Maximum absolute error.
- Pearson correlation coefficient.
- Lag-one residual autocorrelation.
- Prediction-interval coverage.

Acceptance can enforce an RMSE maximum and correlation minimum. Prediction
intervals are optional, but when supplied both lower and upper arrays must match
the reference length and every lower bound must not exceed its upper bound.

## 6. Uncertainty quantification

### Public types

- `F1ProbabilityDistribution`
- `F1UncertainParameter`
- `F1UncertaintyConfiguration`
- `F1UncertaintyResult`
- `F1UncertaintyQuantificationFramework`

Supported parameter distributions are:

- Uniform.
- Normal.
- Triangular.

The framework supports deterministic Latin-hypercube sampling or independent
Monte Carlo sampling. It returns:

- Mean and sample standard deviation.
- Minimum and maximum.
- Lower, median, and upper confidence quantiles.
- Raw model outputs.
- Pearson input/output sensitivity.
- Multiple standardized regression coefficients.

The scalar model is a caller-supplied function. A non-finite model output stops
the run immediately.

### Example

```cpp
F1UncertaintyQuantificationFramework uq;
std::vector<F1UncertainParameter> parameters{
    {"tyre_mu", F1ProbabilityDistribution::Normal,
     0.0, 0.0, 1.0, 0.04, 0.0},
    {"aero_scale", F1ProbabilityDistribution::Uniform,
     0.95, 1.05, 1.0, 0.0, 1.0}
};

F1UncertaintyConfiguration options;
options.samples = 2048;
options.random_seed = 101;

const auto result = uq.propagate(parameters,
    [](const std::vector<double>& p) {
        return 90.0 - 1.8 * p[0] - 0.9 * p[1];
    }, options);
```

## 7. Parameter identifiability

### Public types

- `F1IdentifiabilityConfiguration`
- `F1IdentifiabilityResult`
- `F1IdentifiabilityFramework`

The framework calculates a centered finite-difference sensitivity matrix. Each
column is normalized by its parameter scale and each row by its observation
standard deviation. The Fisher information matrix is:

```text
F = J^T J
```

A symmetric Jacobi eigensolver produces singular values, numerical rank, and
condition number. The framework also calculates a regularized covariance and
parameter-correlation matrix. Parameters are reported as weak when their
sensitivity norm is very small or their posterior correlation with another
parameter is extreme.

A calibration problem is reported as identifiable only when:

- Numerical rank equals parameter count.
- The retained singular-value condition number does not exceed the configured
  maximum.

### Example

```cpp
F1IdentifiabilityFramework identifiability;
const auto result = identifiability.analyze(
    {"front_cornering_stiffness", "rear_cornering_stiffness"},
    {150000.0, 165000.0},
    {150000.0, 165000.0},
    {0.05, 0.10, 0.10},
    [](const std::vector<double>& p) {
        return std::vector<double>{
            1.0e-5 * p[0] + 0.4e-5 * p[1],
            0.2e-5 * p[0] + 1.1e-5 * p[1],
            0.8e-5 * p[0] - 0.6e-5 * p[1]
        };
    });
```

## 8. End-to-end correlation workflow

A recommended engineering sequence is:

1. Configure and run the coupled car as the prior physical model.
2. Configure sensor channels using calibration certificates and DAQ settings.
3. Generate or ingest packets with source-local timestamps.
4. Fit clock maps from synchronization events.
5. Resample or group corrected packets at estimator update times.
6. Run estimator prediction and measurement updates.
7. Compare posterior predictions with withheld telemetry using
   `F1ValidationFramework`.
8. Run identifiability before accepting calibrated parameters.
9. Run uncertainty propagation over the posterior parameter distribution.
10. Record configuration, random seed, source-data identity, estimator posterior,
    validation metrics, and uncertainty quantiles in the study evidence.

Do not calibrate and validate against the same unpartitioned telemetry. Use
separate development and validation laps, sessions, or maneuvers.

## 9. Build and validation

Focused build:

```bash
cmake -S . -B build/f1-fidelity -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2

cmake --build build/f1-fidelity --parallel 2 --target \
  formula_one_fidelity_platform_tests

ctest --test-dir build/f1-fidelity --output-on-failure \
  -R '^formula_one_fidelity_(platform_unit_tests|source_regression)$'
```

Standalone sanitizer check:

```bash
clang++ -std=c++17 -O1 -g \
  -Wall -Wextra -Wpedantic -Wshadow -Wformat=2 \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  -Iinclude \
  tests/formula_one_fidelity_platform_tests.cpp \
  src/advanced/formula_one_fidelity_platform.cpp \
  -o build/f1-fidelity-sanitized

ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=print_stacktrace=1 \
  build/f1-fidelity-sanitized
```

## 10. Qualification boundaries

The implementation is complete and executable; it does not contain deliberately incomplete
functions or fabricated default return values. It remains a reduced-order research
model. Accuracy depends on supplied configuration, sensor calibration, track
surface state, tyre parameterization, and available validation data.

It does not by itself provide:

- FIA homologation or legal compliance evidence.
- A substitute for confidential team tyre, aerodynamic, suspension, or
  power-unit characterization.
- A universal tyre model valid outside its calibrated load, pressure,
  temperature, speed, and water ranges.
- Automatic proof that identified parameters are physically unique.
- Certification of a sensor or DAQ chain.
- Medical, safety, or operational authorization for real vehicle testing.

The identifiability result must be reviewed before interpreting fitted
parameters. Good residual error with a rank-deficient Fisher matrix can indicate
parameter compensation rather than a physically correct calibration.


## Formula One multiphysics extension

For flexible-body dynamics, persistent wake transport, thermal-fluid networks,
mechanistic lifing, optimal experiment design, advanced Bayesian estimation,
adaptive fidelity, second-order automatic differentiation, compressible gas
paths, and ECU/HIL scheduling, see
[`FORMULA_ONE_MULTIPHYSICS_PLATFORM.md`](FORMULA_ONE_MULTIPHYSICS_PLATFORM.md) and
include `aesim/advanced/formula_one_multiphysics_platform.hpp`.

# MuzixDiagSys Electrification and Multi-Domain Platform

This subsystem adds battery-electric and hybrid powertrain simulation, charging communication and PKI, whole-vehicle thermal management, acausal equation execution, middleware and sensor-fusion interfaces, heterogeneous compute backends, and native ONNX inference with runtime assurance.

## Architecture

```text
include/aesim/electrification/electrification.hpp
src/electrification/
├── battery.cpp
├── hybrid.cpp
├── charging.cpp
├── thermal.cpp
├── modelica.cpp
├── middleware.cpp
├── acceleration.cpp
├── acceleration_sycl.cpp
├── acceleration_hip.hip
├── onnx.cpp
└── platform.cpp
```

The subsystem is linked into `aesim_industrial` and exposed through `industrial energy`. Existing simulation paths remain authoritative unless automatic hybrid or thermal coupling is explicitly enabled.

## Battery model

The battery model uses a two-polarization-branch equivalent circuit per series cell group, with:

- OCV interpolation versus state of charge;
- current, voltage, SOC, and thermal limits;
- core and surface thermal nodes;
- coolant heat transfer;
- reversible and irreversible heat generation;
- current derating at hot, cold, high-SOC, and low-SOC conditions;
- deterministic cell variation and balancing;
- Arrhenius temperature acceleration;
- square-root-time calendar aging;
- throughput-based cycle aging and resistance growth;
- low-temperature charging/plating exposure;
- power-limit calculation and energy-balance diagnostics;
- complete state serialization and restoration.

Commands:

```text
industrial energy battery configure data/electrification_battery.yaml
industrial energy battery reset 0.80 298.15
industrial energy battery step 100 298.15 0.01 balance
industrial energy battery power 50000 298.15 0.01
industrial energy battery save battery-state.json
industrial energy battery load battery-state.json
```

Positive current and power represent battery discharge. Negative current and power represent charging.

## Electric drive and hybrid topology

The electric drive models torque, current, voltage utilization, DC power, copper/iron/mechanical losses, inverter conduction and switching losses, and three thermal nodes. It enforces torque, speed, phase-current, DC-current, voltage, and thermal limits.

Hybrid topologies are graph-defined and validated. P0, P2, P4, and series presets are included. The supervisory controller supports electric, engine, blended, charge-sustain, regenerative, and fault states, with SOC targeting and equivalent-fuel accounting.

```text
industrial energy hybrid configure data/electrification_hybrid.yaml
industrial energy hybrid preset p2
industrial energy hybrid target-soc 0.62
industrial energy hybrid step 1800 40 220 0 298.15 298.15 0.01
industrial energy hybrid auto on
```

## ISO 15118, Plug & Charge, and OCPP

The charging subsystem implements an operational charging-session profile with:

- ECDSA P-256 root, contract, and EVSE certificates;
- certificate-chain verification;
- contract challenge signing and verification;
- ISO 15118 session setup, service discovery, payment selection, authorization, charge-parameter discovery, cable check, precharge, power delivery, current demand, and session stop;
- voltage/current/power constraints;
- OCPP JSON call handling for boot, heartbeat, authorization, transaction events, meter values, charging profiles, remote start/stop, status, firmware, and security notifications;
- charger efficiency, site limits, battery limits, and delivered-energy accounting.

```text
industrial energy charging pki init pki
industrial energy charging pki root MuzixDiagSys-Root
industrial energy charging pki contract DE-AES-001
industrial energy charging pki evse MUZIXDIAGSYS-EVSE-001
industrial energy charging iso message session-setup.json
industrial energy charging ocpp message boot-notification.json
industrial energy charging step 298.15 0.1
```

## Whole-vehicle thermal management

The coupled thermal network includes battery, motor, inverter, engine, coolant, cabin air, cabin interior, radiator, heat pump, pumps, and fans. It supports heating, cooling, battery conditioning, solar load, passenger load, vehicle-speed-dependent radiator flow, refrigerant pressure estimates, COP, comfort error, and conservation residuals.

```text
industrial energy thermal configure data/electrification_thermal.yaml
industrial energy thermal reset 285.15
industrial energy thermal step 273.15 500 250 2000 1500 500 8000 20 295.15 298.15 0.1
industrial energy thermal auto on
```

## Acausal Modelica execution

The embedded Modelica engine accepts a deterministic equation-based subset suitable for lumped multi-domain models. It supports:

- `Real` parameters, inputs, outputs, and local variables;
- start values and unit annotations;
- algebraic equations;
- `der(x)` state equations;
- `connect(a,b)` potential-equality expansion;
- arithmetic, powers, and common mathematical functions;
- structural balance checking;
- implicit backward-Euler integration;
- finite-difference Newton Jacobians with pivoted linear solves;
- convergence and non-finite residual checks.

```text
industrial energy modelica load data/electrification_rc.mo
industrial energy modelica initialize
industrial energy modelica set u 10
industrial energy modelica step 0.1
industrial energy modelica get v
industrial energy modelica save modelica-state.json
```

Unsupported source constructs are rejected with explicit diagnostics; they are never silently ignored.

## ROS 2/DDS-oriented transport and ISO 23150 fusion

The middleware layer includes:

- RTPS DATA envelopes over UDP multicast;
- local deterministic publish/subscribe delivery;
- bounded packet decoding;
- QoS metadata;
- ROS 2-compatible CDR payload encoding for Clock, Imu, and Odometry data structures;
- sensor mounting transforms;
- covariance-aware nearest-neighbor association;
- multi-sensor track updates;
- prediction, confidence, lifecycle, and contributor tracking;
- ISO 23150-oriented object export.

```text
industrial energy dds open 0 239.255.0.1
industrial energy dds publish /test aesim_msgs/msg/Test 01020304
industrial energy fusion sensor radar 1 vehicle 20 0 -2 0 0.9
industrial energy fusion fusion-json fusion.json
```

## Heterogeneous acceleration

Backends expose the same Copy, Fill, Affine, and ReduceSum request model where supported:

- deterministic scalar CPU;
- deterministic fixed-partition threaded CPU;
- Vulkan runtime command submission;
- native SYCL kernels when a compatible compiler/runtime is detected;
- native ROCm/HIP kernels when a HIP compiler/runtime is detected.

Unavailable devices or toolchains remain visible with a diagnostic and cannot be selected successfully. There is no implicit CPU substitution for a requested unavailable accelerator.

```text
industrial energy compute list
industrial energy compute run cpu-scalar affine 1000000 2.0 1.0
industrial energy compute run cpu-threaded reduce 1000000
industrial energy compute run best copy 1000000
```

Build controls:

```text
-DAESIM_ENABLE_SYCL=ON|OFF
-DAESIM_ENABLE_HIP=ON|OFF
```

## ONNX execution and AI assurance

The native ONNX protobuf reader and executor supports deterministic tensor execution for:

- Identity;
- Add, Sub, Mul, and Div;
- MatMul and Gemm;
- Relu and LeakyRelu;
- Sigmoid and Tanh;
- Clip;
- Flatten and Reshape;
- Softmax;
- ReduceMean.

The assurance runtime validates:

- allowed operator sets;
- tensor element counts;
- finite input and output values;
- input and output operating ranges;
- maximum output rates;
- inference deadlines;
- deterministic fallback outputs;
- model SHA-256 identity;
- violation and fallback counters.

```text
industrial energy onnx load data/electrification_controller.onnx
industrial energy onnx envelope data/electrification_ai_envelope.yaml
industrial energy onnx run 1.0 3,4 input
```

## Validation

The dedicated C++ and terminal suites cover numerical behavior, lifecycle transitions, serialization, failure handling, protocol state, and fallback behavior. They are registered with CTest as:

```text
electrification_platform_unit_tests
electrification_platform_regression
```

The included ONNX sample is generated deterministically by:

```bash
python3 tools/generate_sample_onnx.py data/electrification_controller.onnx
```

## Interoperability scope

The implementations are executable engineering profiles. They do not claim independent certification by ISO, ASAM, AUTOSAR, COVESA, Khronos, the Open Charge Alliance, the Modelica Association, the ROS 2 project, or the ONNX project. Production interoperability should be confirmed with the target toolchain and its official conformance tests.

## 2026-07-12 next-generation vehicle-depth integration

The electrification platform now owns a `depth` facade in addition to `advanced` and `high-fidelity`, and publishes synchronized `electrification.depth.*` measurements.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


## V17 accelerator execution-graph and persistent-memory optimization

The native HIP `HeterogeneousCompute` backend now owns grow-only device/pinned-host buffers through RAII and reuses bounded HIP graph executables for copy/fill/affine/reduction. Storage growth invalidates dependent graphs; other backends retain established behavior.

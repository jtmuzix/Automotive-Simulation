# Automotive Standards and Conformance Platform

## Purpose

The automotive standards and conformance platform adds executable engineering models for ten requested capability groups without changing or removing existing simulator behavior. It is part of `aesim_advanced`, is exposed through `include/aesim/advanced/platform.hpp`, and is available from `muzixdiagsys_advanced_platform standards`.

The implementation produces deterministic JSON evidence records with SHA-256 digests. It is intended for engineering analysis, pre-compliance, regression qualification, and evidence preparation. Final legal certification remains the responsibility of the applicable approval authority, accredited laboratory, standards licensee, and manufacturer.

## Build

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/full --parallel "$(nproc)"
```

## Unified command interface

```bash
./build/full/muzixdiagsys_advanced_platform \
  standards DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`DOMAIN` accepts:

```text
quality
cea
opentest
r171
cyber-lifecycle
semiconductor
charging
canxl
t1s
serdes
digital-key
```

Run every integrated domain test:

```bash
./build/full/muzixdiagsys_advanced_platform \
  standards self-test build/standards-self-test \
  build/standards-self-test.json
```

## 1. ASAM Quality Checker and QSQ

The engine evaluates explicit artifact rules and computes weighted quality-dimension scores and an aggregate QSQ score. Supported operators are:

```text
exists, not-empty, equal, not-equal, less-equal, greater-equal,
in-range, regex, unique-array, monotonic-array
```

Fatal rule failures always fail the gate. Other failures reduce the weighted score. The aggregate is:

```text
QSQ = 100 * sum(passed rule weights) / sum(all rule weights)
```

Command:

```bash
./build/full/muzixdiagsys_advanced_platform standards quality \
  examples/automotive_standards/quality.json build/quality-report.json
```

The report contains rule findings, per-dimension scores, the minimum gate, final verdict, and evidence digest.

## 2. ASAM CEA component runtime

The CEA runtime validates typed producer/consumer ports, dimensions, supported unit conversions, component IDs, connections, queue capacities, and graph cycles. Combinational cycles are rejected unless broken by a `delay` component.

Implemented deterministic operations:

```text
source, gain, sum, clamp, delay, integrator, sink
```

Command:

```bash
./build/full/muzixdiagsys_advanced_platform standards cea \
  examples/automotive_standards/cea.json build/cea-report.json
```

Set `operation` to `compile` for graph validation only, or `execute` for time-stepped execution.

## 3. ASAM OpenTestSpecification

The engine expands Cartesian parameter matrices with overflow and maximum-instance guards. It checks resource availability and executes:

```text
set, add, assert-equal, assert-range, wait, capture,
inject-fault, clear-fault
```

It produces per-step verdicts, per-instance evidence, requirement coverage, and aggregate pass/fail/error counts.

```bash
./build/full/muzixdiagsys_advanced_platform standards opentest \
  examples/automotive_standards/opentest.json build/opentest-report.json
```

## 4. UN R171 DCAS homologation

The DCAS evaluator checks:

- activation and deactivation evidence;
- driver-attention warning escalation;
- timely relinquishment after driver override;
- lateral-error and time-to-collision limits;
- lane-change safety gating;
- ODD-exit transition-demand or minimum-risk behavior.

```bash
./build/full/muzixdiagsys_advanced_platform standards r171 \
  examples/automotive_standards/r171.json build/r171-report.json
```

All sample timestamps must be finite and strictly increasing.

## 5. ISO/SAE 21434, UN R155, UN R156, and ISO 24089 lifecycle

The lifecycle engine performs asset/threat/control risk analysis, verifies CSMS and SUMS process evidence, and gates software update release. Residual risk is calculated by applying each verified control multiplicatively:

```text
residual risk = initial risk * product(1 - verified control effectiveness)
```

Update release requires a signed package, rollback protection, recovery, safety and cybersecurity impact assessments, compatibility declaration, user information, and an approved-or-later campaign state.

```bash
./build/full/muzixdiagsys_advanced_platform standards cyber-lifecycle \
  examples/automotive_standards/cyber_lifecycle.json \
  build/cyber-lifecycle-report.json
```

## 6. ISO 26262-11 semiconductor safety

The semiconductor laboratory computes:

- total failure rate in FIT;
- single-point fault metric (SPFM);
- latent fault metric (LFM);
- probabilistic metric for random hardware failures (PMHF);
- SEooC assumption and integration readiness;
- required mechanism coverage for high-ASIL designs.

For ASIL C/D targets, the current integration profile requires watchdog, BIST, ECC, and lockstep mechanisms. Thresholds are explicit in the implementation and results are evidence-digested.

```bash
./build/full/muzixdiagsys_advanced_platform standards semiconductor \
  examples/automotive_standards/semiconductor.json \
  build/semiconductor-report.json
```

## 7. SAE J3400/NACS and ISO 15118-20 charging

The charging laboratory checks:

- latch, proximity, pilot, insulation, insertion, and retention behavior;
- contact-loss power and connector temperature rise;
- ordered ISO 15118-20 session progression;
- TLS, Plug & Charge, certificate, revocation, and signature status;
- bidirectional metering and AC DER capability;
- mutual service support and delivered-energy integration.

```bash
./build/full/muzixdiagsys_advanced_platform standards charging \
  examples/automotive_standards/charging.json build/charging-report.json
```

## 8. CAN XL

The CAN XL engine provides a deterministic binary frame representation, validates priority and payload constraints, calculates CRC-32, rejects corrupt frames, and estimates arbitration/data timing and bus utilization.

```bash
./build/full/muzixdiagsys_advanced_platform standards canxl \
  examples/automotive_standards/canxl.json build/canxl-report.json
```

Payload length is validated from 1 through 2048 bytes.

## 9. 10BASE-T1S and PLCA

The multidrop model validates unique nodes and PLCA IDs, exactly one online coordinator, segment/node constraints, beacon availability, transmit opportunities, endpoint state, serialization time, packet deadlines, utilization, and maximum latency.

```bash
./build/full/muzixdiagsys_advanced_platform standards t1s \
  examples/automotive_standards/t1s.json build/t1s-report.json
```

## 10. Automotive SerDes

The SerDes laboratory supports MIPI A-PHY, ASA Motion Link, GMSL, and FPD-Link profile labels. It calculates channel loss, received power, SNR, eye margin, raw BER, FEC residual BER, packet error rate, payload capacity, serialization latency, synchronization compliance, and reverse-channel status.

```bash
./build/full/muzixdiagsys_advanced_platform standards serdes \
  examples/automotive_standards/serdes.json build/serdes-report.json
```

Fault injection covers burst errors, common-mode noise, link-training failure, and reverse-channel failure.

## 11. CCC Digital Key

Digital Key uses the existing persistent Hardware Security Module implementation. It creates Ed25519 issuer/device keys, signs credentials, enforces delegated permissions and validity intervals, propagates revocation to child keys, verifies challenge signatures, and evaluates NFC/BLE/UWB proximity.

UWB distance is derived from round-trip time:

```text
distance = round_trip_time_ns * 0.299792458 / 2
```

A mismatch between measured and claimed distance is treated as a possible relay attack.

```bash
./build/full/muzixdiagsys_advanced_platform standards digital-key \
  examples/automotive_standards/digital_key.json \
  build/digital-key-report.json build/digital-key-state
```

The working directory is mandatory because HSM keys and metadata are persistent artifacts.

## Regression testing

Run only the new unit suite:

```bash
ctest --test-dir build/full \
  -R '^automotive_standards_conformance_platform_unit_tests$' \
  --output-on-failure
```

The suite includes positive integrated qualification and negative cases for duplicate quality identifiers, CEA combinational cycles, unavailable test resources, delayed DCAS override, unsigned updates, insufficient semiconductor diagnostics, charging overtemperature, CAN XL corruption, missing PLCA coordination, and SerDes reverse-channel failure.

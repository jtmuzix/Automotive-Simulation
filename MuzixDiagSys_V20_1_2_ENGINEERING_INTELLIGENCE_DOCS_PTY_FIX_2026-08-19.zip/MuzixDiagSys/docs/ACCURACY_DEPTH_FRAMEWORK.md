# MuzixDiagSys Accuracy, Numerical Depth, and Diagnostic-Coverage Framework

## Purpose

This document describes the accuracy framework added to MuzixDiagSys. The implementation is designed for engineering validation, reproducible research, and coupled vehicle-system simulation. It does not replace the existing engine, transmission, chassis, electrification, industrial, professional, or terminal interfaces; it extends those interfaces with measurable conservation, traceable data handling, robust calibration, uncertainty propagation, deterministic replay, stiff-system integration, electromagnetic parasitics, environmental sensor behavior, diagnostic coverage, and electrohydraulic transmission dynamics.

The primary public C++ interface is:

```cpp
#include "aesim/core/accuracy.hpp"
```

The implementation is in `src/core/accuracy.cpp`. Runtime integration is primarily in `src/muzixdiagsys.cpp`, the high-fidelity vehicle sources, the industrial fault-campaign engine, and the professional checkpoint/provenance components.

## 1. Conservation auditing

`aesim::core::ConservationAuditor` maintains a signed ledger for:

- Energy, in joules.
- Mass, in kilograms.
- Electric charge, in coulombs.
- Linear momentum, in kilogram-metres per second.
- Angular momentum, in kilogram-metres squared per second.

Each domain declares storage at the beginning and end of an accepted step, signed external rates, and directed inter-domain transfer rates. A positive transfer removes a conserved quantity from the source and adds the same quantity to the destination, so internal transfers cancel from the global balance.

For each conserved quantity, the step residual is evaluated as:

```text
residual = ending storage - starting storage - integral(external rate) - integral(net transfer rate)
```

The auditor reports absolute and normalized residuals, domain-level pass/fail state, global residuals, violation counts, step identifiers, and timestamps. The runtime currently audits:

- `engine_thermofluid`: mass and energy flow against modeled storage.
- `vehicle_longitudinal`: kinetic-energy and linear-momentum changes against wheel, aerodynamic, rolling, grade, and brake forces.

Commands:

```text
health conservation
health conservation reset
health conservation export <path.csv>
```

Checkpoint, branch, and replay restoration re-anchor the ledger to the restored time and stored state. This prevents a valid backward time jump from appearing as a non-monotonic conservation step.

## 2. Test-data ingestion

`aesim::core::TestDataIngestor` supports delimited engineering test data with:

- CSV, TSV, semicolon, and pipe delimiters.
- Quoted fields and escaped quotation marks.
- Header-based semantic roles: `input`, `observed`, `sigma`, and `auxiliary`.
- Units declared in square brackets or parentheses.
- SI normalization.
- Missing and non-finite sample rejection.
- Timestamp sorting.
- Duplicate timestamp merging.
- Linear or held-value resampling.
- Synchronization of multiple data sources.
- SHA-256 source identity.
- Per-channel validity masks and warnings.

Examples of accepted headers:

```text
time[ms],input.throttle[%],observed.speed[km/h],sigma.speed[km/h]
time_s,observed.rpm[rpm],observed.temperature[C]
```

Role-qualified storage keys prevent an uncertainty channel such as `sigma.speed` from overwriting `observed.speed` while retaining the common metric name `speed` for analysis.

Runtime commands:

```text
telemetry import <path.csv>
telemetry compare
telemetry export-residuals <path.csv|path.json>
```

## 3. Automated calibration

`aesim::core::AutomatedCalibrationPipeline` wraps the existing bounded calibration optimizer with an engineering workflow that adds:

- Deterministic multi-start candidate searches.
- Bounded parameters and finite-value validation.
- Robust residual reweighting.
- K-fold cross-validation.
- Candidate ranking.
- Parameter-identifiability warnings.
- Training and validation error reporting.
- Preservation and restoration of the live baseline on failure.

The runtime telemetry-fit path uses this pipeline instead of a single unqualified optimization run. Calibration parameters remain constrained by their physical lower and upper limits.

## 4. Residual analysis

`aesim::core::ResidualAnalyzer` computes more than a single aggregate RMSE. Per observed channel it reports:

- Bias.
- Mean absolute error.
- Root-mean-square error.
- Normalized RMSE.
- Residual standard deviation.
- Maximum absolute error.
- Coefficient of determination, R².
- Durbin-Watson statistic.
- Lag-one residual autocorrelation.
- Ljung-Box Q statistic.
- Linear residual drift rate.
- Cross-correlation phase lag.
- Discrete-frequency spectral RMSE.
- Low-frequency residual-power fraction.
- Time-segmented residual statistics.

Results can be exported as CSV or JSON and are produced by `telemetry compare` after a synchronized test-data import.

## 5. Correlated uncertainty propagation

`aesim::core::CorrelatedUncertaintyPropagator` implements deterministic, bounded uncertainty propagation using:

- Latin hypercube sampling.
- Gaussian-copula correlation.
- Positive-semidefinite correlation handling.
- Normal, uniform, lognormal, triangular, and beta-style parameter distributions supported by the underlying uncertainty model.
- Output percentiles and confidence intervals.
- Output covariance.
- Parameter-to-output sensitivity correlations.
- Threshold exceedance and failure probabilities.
- Explicit random seed provenance.

Runtime command:

```text
uncertainty correlated <samples> <path.csv|path.json> [seed]
```

The simulator restores the exact nominal state and calibration parameters after every uncertainty run, including exceptional exits.

## 6. Configuration and result provenance

Two complementary provenance mechanisms are provided.

### 6.1 General provenance records

`aesim::core::ProvenanceRecorder` writes and verifies `aesim.provenance.v3` records containing:

- Run metadata.
- Environment metadata.
- User tags.
- Executable identity.
- Individual configuration files.
- Result files.
- Aggregate configuration-set digest.
- Canonical-record SHA-256.

The verifier checks each referenced artifact and the canonical record itself. Legacy v2 file-only records remain readable and are explicitly identified as legacy.

### 6.2 Runtime experiment packages

The existing `ExperimentManager` now emits `aesim.experiment.v3` packages. Each package contains:

```text
manifest.json
configuration.canonical.txt
telemetry.csv
events.csv
artifacts.sha256
```

The checksum file binds the manifest, canonical configuration, measurements, events, executable identity, and user artifacts. Editing metadata such as the experiment name causes verification to fail even when result files are untouched.

Commands:

```text
experiment begin <name> <directory> [seed]
experiment event <message>
experiment end
experiment verify <run-directory>
```

## 7. Deterministic replay

The replay format is upgraded to version 3 and records:

- Embedded initial full-state checkpoint.
- Ordered commands and sequence numbers.
- State hash before and after each command.
- Random-stream hash before and after each command.
- Command-output SHA-256.
- Per-event chain hash.
- Final chain identity.
- First mismatch sequence and mismatch reason.

The reader remains compatible with version 2 logs. Replay verification checks checkpoint authenticity, state, random streams, output text, command order, monotonic timestamps, and the hash chain.

Commands:

```text
replay start [path]
replay stop
replay save <path>
replay run <path>
replay verify <path>
replay hash
```

## 8. Automatic Jacobians

`aesim::core::DynamicDual` is a dynamic-size forward-mode automatic-differentiation scalar. It supports arithmetic and the nonlinear functions required by the DAE residual engine. `AutomaticJacobian::evaluate` seeds one derivative component per independent variable and returns both function values and the complete Jacobian.

The implicit solver uses automatic Jacobians when an automatic residual is supplied. A finite-difference fallback remains available for ordinary residual callbacks and for independent verification.

## 9. Implicit DAE integration

`aesim::core::ImplicitDaeSolver` supports:

- Backward Euler.
- Second-order backward differentiation, BDF2.
- Implicit midpoint.
- Algebraic constraints represented directly in the residual.
- Newton iteration with line search.
- Automatic or finite-difference Jacobians.
- Dense linear solution with pivoting.
- Absolute and relative convergence tolerances.
- Adaptive accepted-step control using full-step versus two-half-step error estimation.
- Minimum and maximum step bounds.
- Rejected-step accounting.
- Snapshot and restore.
- Event localization and event handlers.

A residual has the form:

```text
F(time, state, state_derivative) = 0
```

The solver never commits a failed Newton trial. An accepted state becomes visible only after convergence and error acceptance.

## 10. Event localization

A `DaeEvent` contains a named scalar event function, a direction filter, localization tolerance, and an optional handler. The solver detects sign changes over an accepted trial and localizes the root within the step before invoking the handler.

Supported direction filters are:

- Any crossing.
- Rising crossing.
- Falling crossing.

Statistics include detected and localized event counts. Event handlers may modify the localized state to model impacts, limiters, switching, valve transitions, lockup, or other discontinuities.

## 11. Solver rollback

Both the DAE solver and the multi-rate coordinator use explicit snapshots. Failed nonlinear solves, rejected error estimates, non-finite states, and unconverged coupling iterations restore the last accepted snapshot before reducing the step or reporting failure.

The main runtime additionally resets conservation history after full-state checkpoint, branch, and replay restoration because conservation history describes the execution path rather than only the instantaneous state.

## 12. Multi-rate integration and coupling diagnostics

`aesim::core::MultiRateCouplingCoordinator` executes independent domains at domain-specific periods within a macro step. Each domain supplies:

- Name and physical domain.
- Local integration period.
- Snapshot callback.
- Restore callback.
- Advance callback.
- Coupling-input getter and setter.
- Power-flow getter.

The coordinator supports:

- Iterative Gauss-Seidel-style waveform coupling.
- Configurable relaxation.
- Convergence tolerance.
- Maximum coupling iterations.
- Deterministic substep scheduling.
- Domain timing statistics.
- Snapshot rollback on non-convergence.
- Coupling residual history.
- Cross-domain power-balance mismatch.

The existing research-core integer-tick scheduler remains active and is synchronized with the public solver combustion, air-path, and thermal periods. The new coordinator is available for independently integrated DAE or external domains that require iterative macro-step convergence.

## 13. High-voltage parasitics and EMI/EMC

`HighVoltageParasiticsEmiModel` extends the distributed high-voltage network with:

- Source and cable resistance and inductance.
- DC-link capacitance, ESR, and ESL.
- Implicit backward-Euler modified-nodal integration.
- Switching-edge `dv/dt` and displacement current.
- Common-mode return current.
- Humidity- and contamination-dependent insulation leakage.
- Motor-bearing current estimation.
- Conducted-emission harmonics expressed in dBµV.
- Radiated-field estimation in dBµV/m.
- Shielding effectiveness.
- Conducted and radiated limit checks.
- Stored electrical energy and energy residual.

The model is integrated into the next-generation vehicle-depth runtime and contributes to status, fidelity diagnostics, deterministic replay inputs, and aggregate energy-residual reporting.

## 14. Fault injection and diagnostic coverage

The industrial fault-campaign engine now supports:

- Timed fault injection and duration-correct clearing.
- No-fault control runs.
- Expected and unexpected DTC classification.
- Detection latency.
- Safe-state and safety-preservation checks.
- True-positive, false-negative, true-negative, and false-positive counts.
- Severity, exposure, controllability, and occurrence weighting.
- Initial and residual risk scores.
- Diagnostic and safe-mitigation coverage.
- Risk-weighted coverage.
- Coverage grouped by target and fault class.
- CSV, JSON, Markdown, and generated-template output.

The established public report heading is retained for existing automation:

```text
Automated fault campaign and diagnostic coverage
```

The enhanced statistics follow that compatibility marker.

## 15. Sensor imperfection and environmental degradation

The high-fidelity uncertain-sensor channel now models:

- Static bias and scale error.
- Quantization and saturation.
- First-order lag and latency.
- Temperature-dependent bias and scale.
- Sensor-body thermal lag and self-heating.
- Humidity and pressure sensitivity.
- Vibration-dependent noise.
- Persistent contamination and recovery.
- Contamination-induced dropout.
- Radiation dose.
- Aging drift and scale degradation.
- Supply-voltage sensitivity and brownout dropout.
- EMI pickup.
- Cross-axis sensitivity.
- Hysteresis.
- Calibration and service reset state.

The environment-aware path is used by the integrated vehicle and vehicle-depth runtimes. The original nominal sample overload is retained for source compatibility.

## 16. Detailed transmission hydraulic-control model

The transmission ecosystem now contains a dynamic electrohydraulic plant rather than a command-to-pressure multiplier. The model includes:

- Speed-dependent hydraulic pump flow.
- Pump volumetric and mechanical efficiency.
- Line compressibility and fluid volume.
- Temperature-dependent fluid viscosity and density effects.
- Pressure regulator flow.
- Internal leakage.
- Solenoid resistance, inductance, and current dynamics.
- Solenoid force.
- Spool mass, damping, spring, travel, and pressure feedback.
- Orifice flow with pressure sign.
- Clutch-cavity dead volume and fill fraction.
- Accumulator compliance.
- Piston travel and clamp force.
- Wet-clutch torque capacity.
- Friction-temperature fade.
- Thermal accumulation and cooling.
- Wear accumulation.
- Lockup-clutch pressure.
- Fill, torque-transfer, inertia, completion, and fault phases.
- Hydraulic power, losses, and energy residual.
- Manual-transmission clutch interlock compatibility.

The existing public status marker remains:

```text
Full transmission, clutch, and planetary gearset
```

A second line identifies the detailed electrohydraulic implementation.

## 17. Public runtime examples

```text
telemetry import data/sample_telemetry.csv
telemetry compare
telemetry export-residuals residuals.json

quickstart
throttle 25
step 0.2
health conservation
health conservation export conservation.csv

uncertainty correlated 256 uncertainty.json 12345

experiment begin validation_run ./runs 12345
step 1.0
experiment event completed nominal segment
experiment end
experiment verify ./runs/<run-id>
```

## 18. Source-compatibility policy

The implementation preserves:

- Existing terminal layout and golden frames.
- Existing command names and completion behavior.
- Existing report markers used by automation.
- Existing checkpoint and replay readers.
- Existing nominal sensor calls.
- Existing vehicle, engine, and transmission functionality.
- Existing professional, industrial, electrification, federation, assurance, and plugin interfaces.

New functions are additive or are internal replacements behind the same public command/API surface.

## V17 sparse automatic-differentiation graph coloring

`AutomaticJacobian::evaluate_sparse_colored` validates a `SparseJacobianPattern`, deterministically colors interfering columns, compresses forward-AD seeds, and reconstructs declared nonzeros. `DaeSolverOptions::automatic_jacobian_pattern` enables it in the DAE solver; omission retains dense AD.

# MuzixDiagSys Virtual Vehicle and Distributed Validation Platform

This module extends the existing engine, assurance, and industrial HIL platform
with deterministic road, scenario, vehicle, update, network-timing, vehicle-data,
qualification, and distributed-study services. It is linked into
`aesim_industrial` and is exposed through `industrial vehicle` commands. Existing
commands and APIs remain available.

## Architecture

```text
include/aesim/vehicle/vehicle.hpp
src/vehicle/
├── internal.hpp       Bounded XML, networking, numeric, and file utilities
├── world.cpp          OpenDRIVE, OpenSCENARIO, and OSI world exchange
├── dynamics.cpp       Vehicle, tire, brake, and environment dynamics
├── connected.cpp      Uptane, gPTP, TSN, VSS/VISS, and qualification
├── study.cpp          Local/TCP deterministic studies and worker server
└── platform.cpp       Industrial-platform integration and command surface

tools/study_worker.cpp Standalone deterministic TCP study worker
```

## OpenDRIVE

The importer validates XML and constructs indexed road definitions containing
plan-view line, arc, and spiral geometry; elevation polynomials; lane sections;
lane-width polynomials; predecessor/successor relationships; and junction
references. It provides exact road sampling, lane-offset positioning, nearest-road
search, and graph route calculation.

```text
industrial vehicle map load data/vehicle_world.xodr
industrial vehicle map sample 1 50 -1.5
industrial vehicle map nearest 100 2
industrial vehicle map route 1 2
industrial vehicle map export reports/opendrive.json
```

## OpenSCENARIO and OSI

The OpenSCENARIO runtime imports entities, bounding boxes, initial world/lane
positions, initial speeds, simulation-time triggers, speed actions, acceleration
actions, and teleport actions. Execution uses deterministic fixed increments and
produces an OSI-style `osi3.GroundTruth` semantic world model.

The binary OSI envelope contains an `OSI3` signature, format version, bounded
payload length, and canonical world document. Its use provides a stable simulator
world interchange without claiming official protobuf wire compatibility.

```text
industrial vehicle scenario load data/vehicle_world.xosc
industrial vehicle scenario run 10 0.01
industrial vehicle osi export reports/world.osi
industrial vehicle osi import reports/world.osi
industrial vehicle osi json reports/world.json
```

## Vehicle, tire, brake, and environment models

The vehicle subsystem integrates planar longitudinal, lateral, and yaw dynamics
with four wheel states. The tire model combines longitudinal slip and slip-angle
force demands against a friction-circle limit. The brake model includes hydraulic
pressure dynamics, axle bias, wheel-specific ABS release/reapply behavior, and
regenerative torque allocation. Environment inputs include air density, wind,
road grade, road friction, rain, and rolling resistance.

```text
industrial vehicle dynamics configure data/vehicle_dynamics.yaml
industrial vehicle dynamics environment grade 0.05
industrial vehicle dynamics environment friction 0.8
industrial vehicle dynamics step 0.01 1500 0 0
industrial vehicle dynamics step 0.01 0 1 0
```

## Uptane-oriented secure A/B updates

The update manager implements signed root, timestamp, snapshot, and targets roles;
role thresholds; expiration and rollback checks; target ECU, length, and SHA-256
verification; persistent verified metadata; inactive-slot staging; atomic pending
activation; boot-health acceptance; failed-health rollback; and recovery.

The delivered profile uses provisioned HMAC-SHA256 keys for deterministic local
simulation. It does not claim direct compatibility with the official Uptane JSON
metadata format or asymmetric production PKI.

```text
industrial vehicle ota init reports/ota ECU-001
industrial vehicle ota key root-key replace-with-test-secret
industrial vehicle ota create-bundle reports/update.json firmware.bin firmware.bin 1 2099-12-31T23:59:59Z root-key
industrial vehicle ota verify reports/update.json
industrial vehicle ota stage firmware.bin firmware.bin
industrial vehicle ota activate
industrial vehicle ota boot healthy
```

## gPTP and TSN

The gPTP domain provides deterministic best-master selection using priority and
clock-quality fields, clock drift, path delays, phase correction, frequency
correction, grandmaster loss/reselection, and synchronization metrics.

The TSN scheduler accepts links and periodic streams, determines a bounded
hyperperiod, places deterministic gate windows by priority and deadline, computes
multi-hop completion latency and link utilization, and reports infeasibility and
deadline violations.

```text
industrial vehicle ptp clock gm 1 6 1 0 0
industrial vehicle ptp clock ecu 128 248 128 50000 20
industrial vehicle ptp link gm ecu 1000
industrial vehicle ptp advance 0.1
industrial vehicle ptp sync

industrial vehicle tsn load data/vehicle_tsn.yaml
industrial vehicle tsn synthesize
industrial vehicle tsn report reports/tsn.json
```

## COVESA VSS and VISS

The VSS registry imports either a flattened signal list or a nested VSS-style tree.
Each leaf retains path, role, data type, engineering unit, range, description, and
mapping to the simulator signal registry. The VISS service supports reads, bounded
actuator writes, subscriptions, deadbands, intervals, unsubscription, and event
polling.

```text
industrial vehicle vss load data/vehicle_vss.yaml
industrial vehicle vss list
industrial vehicle viss get Vehicle.Speed
industrial vehicle viss set Vehicle.Chassis.SteeringWheel.Angle 0.2
industrial vehicle viss subscribe Vehicle.Speed 0.1 0.01
industrial vehicle viss poll 1.0
```

## Conformance and supplier qualification

The qualifier executes profile-specific structural, semantic, integrity, range,
and round-trip checks for OpenDRIVE, OpenSCENARIO, OSI envelopes, VSS documents,
Uptane bundles, FMI packages, and SSP packages. Reports contain artifact hashes,
profile identity, verdict, and individual findings.

```text
industrial vehicle qualify opendrive supplier_map.xodr reports/map_qualification.json
industrial vehicle qualify openscenario supplier_test.xosc reports/scenario_qualification.json
industrial vehicle qualify fmi supplier_model.fmu reports/fmi_qualification.json
```

These checks are internal qualification profiles and are not substitutes for an
official standards-body conformance suite.

## Distributed deterministic studies

A study document defines a base seed and explicit cases or a Cartesian parameter
grid. Every expanded case receives a deterministic identifier and derived seed.
Local execution uses a bounded thread pool. Remote execution distributes cases in
parallel over one or more TCP workers using length-prefixed canonical JSON,
bounded payloads, retry handling, and deterministic result ordering by case ID.

```text
# Worker host
./build/aesim_study_worker 0.0.0.0 47000

# Coordinator
industrial vehicle study local data/vehicle_study.yaml reports/local.json 16
industrial vehicle study remote data/vehicle_study.yaml reports/remote.json host1:47000 host2:47000
```

Local and remote execution use the same case evaluator, allowing exact
cross-backend regression comparison for deterministic metrics.

## Build and test

```bash
cmake -G Ninja -S . -B build \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DAESIM_ENABLE_HARDENING=ON
cmake --build build -j"$(nproc)"
ctest --test-dir build --output-on-failure
```

Dedicated tests:

```bash
./build/vehicle_platform_tests
python3 tests/vehicle_platform_regression.py \
  ./build/muzixdiagsys "$PWD" ./build/aesim_study_worker
```

## Scope and standards positioning

The implementation provides complete, executable engineering profiles for the
listed functionality. OpenDRIVE and OpenSCENARIO support the constructs exercised
by the included model and scenario workflows, but do not claim every optional
construct in every historical standard revision. The OSI envelope preserves
OSI-style world semantics but is not official protobuf wire compatibility. The
Uptane profile uses deterministic provisioned HMAC keys rather than production
asymmetric PKI. gPTP/TSN behavior is a deterministic simulation and scheduling
model, not physical-network certification. Supplier qualification is an internal
formal profile, not external certification.

## 2026-07-12 next-generation vehicle-depth integration

The virtual vehicle now couples flexible chassis modes, three-dimensional terrain, structural tires, distributed HV, switching drive, aero-thermal flow, detailed brakes, and AUTOSAR execution.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


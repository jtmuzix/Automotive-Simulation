# Frontier Integration Platform

## Purpose

`frontier-integration` is an additive advanced-platform command family. It does not replace `frontier-runtime`, `frontier-expansion`, `frontier-systems`, the primary `muzixdiagsys` CLI, or any motorsports/engineering command family.

```bash
./build/full/muzixdiagsys_advanced_platform frontier-integration capabilities
./build/full/muzixdiagsys_advanced_platform frontier-integration self-test build/frontier-integration/self-test
./build/full/muzixdiagsys_advanced_platform frontier-integration DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Every result carries deterministic structured evidence and a SHA-256 evidence digest. Native external tools are used only when their executable is present and explicitly requested.

## 1. DDS-XRCE / Zenoh edge federation

Domain: `dds-xrce-zenoh-edge-federation-platform`.

The model implements bounded-memory DDS-XRCE-style client/session transport with stable per-topic object identifiers, Zenoh-style key mapping, MTU fragmentation, reliable or best-effort delivery, deterministic loss injection, retransmission timers, retry limits, latency/jitter, delivery accounting, and session-memory qualification. Reliable messages are complete only when every fragment is delivered.

## 2. Automotive MACsec link security

Domain: `automotive-macsec-link-security-laboratory`.

The link laboratory uses OpenSSL AES-256-GCM. A key epoch and secret derive a 256-bit key; the secure-channel identifier and packet number form the IV. Authenticated additional data protects link-header context. The receiver validates the GCM tag, packet-number replay window and duplicate state. Results include ciphertext/tag material, authentication/replay status, protected-frame overhead and link-rate latency cost. Authentication failures and replayed frames are rejected.

## 3. Automotive EMC compliance

Domain: `automotive-emc-compliance-laboratory`.

The EMC engine performs logarithmic frequency sweeps across user-defined limit masks. It models source level, shielding, measurement distance, cable half-wave resonance, resonance Q, field coupling and induced common-mode voltage. It reports the worst emission margin/frequency, complete bounded sweep evidence, immunity margin, induced voltage and independent emissions/immunity pass decisions.

## 4. Wiring harness SI/PI

Domain: `wiring-harness-signal-power-integrity-platform`.

The harness model solves the distributed RLGC transmission-line equations using complex propagation constant and characteristic impedance. It reports attenuation, source/load reflection, return loss, propagation delay, coupling/crosstalk, repeated-reflection TDR samples and a normalized eye-opening estimate. R/L/G/C, cable length, source/load impedances, coupling and signaling rate are configurable.

## 5. Continuous-frequency H-infinity / structured-real robustness

Domain: `continuous-frequency-hinf-mu-synthesis-laboratory`.

The laboratory synthesizes continuous-time LQR state feedback through iterative algebraic Riccati/Lyapunov equations. It then certifies the closed-loop disturbance-to-performance bound with a continuous-time bounded-real Riccati condition and bisection on gamma. Structured real affine uncertainty blocks are evaluated over every hypercube vertex and bisection returns a robust-stability radius plus reciprocal structured-real `mu` metric.

The reported `structured_real_mu` is for the explicitly supplied real affine block family. It is not labeled as an arbitrary complex/dynamic structured-singular-value theorem.

## 6. Advanced system identification

Domain: `advanced-system-identification-laboratory`.

Implemented identification modes are:

- `arx`: regularized least-squares ARX with configurable autoregressive order, input order and transport delay, with RMSE and fit percentage.
- `dmd` / `koopman`: ridge-regularized snapshot operator identification from `X` and `Y` matrices.
- `era`: Eigensystem Realization Algorithm from Markov parameters using Hankel matrices and reduced singular subspaces.

## 7. Formal proof-assistant bridge

Domain: `formal-proof-assistant-bridge`.

A deterministic local arithmetic kernel evaluates supported expression trees (`add`, `sub`, `mul`, `div`, integer `pow`, unary negation) and validates equality/inequality propositions. The bridge writes assistant-specific Lean, Coq or Isabelle theorem artifacts and hashes them. With `run_external=true`, it directly invokes a real installed `lean`, `coqc`, or `isabelle` executable without shell interpolation and fails qualification if that independent proof kernel rejects the artifact. Capability discovery reports the installed assistants.

## 8. OSLC / SACM lifecycle assurance

Domain: `oslc-sacm-lifecycle-assurance-platform`.

The local lifecycle repository persists typed resources with stable IDs, content-derived ETags, conditional updates (`if_match`), resource queries, transitive link traces and assurance resolution. SACM-style claim/evidence resolution verifies that requested claim IDs and evidence/artifact IDs exist and have compatible resource types. This creates an executable requirement -> model/test/evidence trace surface without requiring a third-party lifecycle server.

## 9. RTL / Verilator hardware co-simulation

Domain: `rtl-verilator-hardware-cosimulation-platform`.

The always-available reference engine executes synchronous register-transfer behavior cycle by cycle with bounded 1-64-bit register widths, modulo-width masking, simultaneous state updates, input vectors and arithmetic/logic/shift/compare/multiplexer operations. It emits a complete cycle trace.

When `backend=verilator` is requested and Verilator is installed, the platform generates a self-checking SystemVerilog testbench implementing the requested cycles, invokes `verilator --binary`, runs the generated executable, and treats any state mismatch or compile/runtime failure as a qualification failure. Verilator absence is reported as unavailable; it is never simulated as a successful native run.

## 10. Engineering data query fabric

Domain: `engineering-data-query-fabric`.

The query fabric is backed by the project's native SQLite dependency. JSON rows can be ingested into persistent typed tables with per-column unit metadata in `_aesim_units`. User SQL is prepared with SQLite and is accepted only when `sqlite3_stmt_readonly()` confirms it is read-only, preventing the query surface from being used for arbitrary mutations. Results preserve column names and numeric/text/null types. DuckDB CLI availability is reported separately for future/external interoperability but is not required by the implemented query engine.

## 11. Manufacturing process physics

Domain: `manufacturing-process-physics-platform`.

Implemented physical modes are:

- `adhesive-cure` and `paint-bake`: autocatalytic Arrhenius cure kinetics with degree of cure, peak rate, chemical shrinkage and cure-dependent modulus.
- `welding`: electrical/arc heat input per unit length, effective temperature rise, constrained thermal strain, yield-limited residual stress and distortion.
- `stamping`: elastic-plastic flow with linear hardening and springback estimate.
- `resin-infusion`: Darcy front propagation with porosity, viscosity, permeability, pressure drop, fill time and final front velocity.

## 12. Cross-domain error propagation

Domain: `cross-domain-error-propagation-engine`.

The engine constructs a forward analytic derivative graph across named physical inputs and expression nodes. It supports arithmetic plus `sin`, `cos`, `exp`, `log`, `sqrt`, `pow` and scaling. Input standard deviations and pairwise correlations form a covariance matrix. Each requested output reports its Jacobian sensitivities, `J P J^T` uncertainty, diagonal variance contributions and a conservative propagated numerical-error bound.

## 13. Automatic multifidelity model selection

Domain: `automatic-multifidelity-model-selection-platform`.

Each model carries computational cost, error model, difficulty validity range and optional difficulty-dependent cost/error slopes. Each trajectory state supplies difficulty and maximum error tolerance. The scheduler solves a dynamic-programming problem over the complete trajectory, including model-switch cost, and returns the globally minimum-cost feasible schedule rather than choosing greedily one state at a time.

## 14. Autonomous experiment campaign manager

Domain: `autonomous-experiment-campaign-manager`.

The campaign manager maintains a Gaussian parameter belief and scores candidate tests by expected information gain from their sensitivity vector, measurement noise, cost and failure probability. Selected experiments update posterior covariance with the Kalman information update. Optional synthetic truth produces deterministic seeded measurements and posterior-mean updates. Resource calendars, durations, repeat limits, information targets and minimum information gain are supported.

## Examples

One executable request is provided for every domain in `examples/frontier_integration/`:

- `dds_xrce_zenoh.json`
- `macsec.json`
- `emc.json`
- `harness_si_pi.json`
- `hinf_mu.json`
- `system_identification.json`
- `proof_bridge.json`
- `oslc_sacm.json`
- `rtl_cosim.json`
- `query_fabric.json`
- `manufacturing_physics.json`
- `error_propagation.json`
- `multifidelity.json`
- `campaign.json`

## Qualification boundary

The deterministic internal algorithms are part of the simulator and are tested on every supported host. External proof assistants and Verilator are real optional qualification backends and are invoked only when installed. A missing native executable is a capability limitation, not a successful emulation. The H-infinity certificate is continuous-time/continuous-frequency through the bounded-real condition; the `mu` result is explicitly limited to the supplied structured **real affine** uncertainty family.


## Compatibility with Frontier Next (2026-08-08)

Frontier Integration remains unchanged and callable through `frontier-integration`. The later additive `frontier-next` platform does not replace these fourteen domains. Its sixteen domains and dedicated aliases are documented in `FRONTIER_NEXT_PLATFORM.md`; both platform families may be used in the same build and workflow.

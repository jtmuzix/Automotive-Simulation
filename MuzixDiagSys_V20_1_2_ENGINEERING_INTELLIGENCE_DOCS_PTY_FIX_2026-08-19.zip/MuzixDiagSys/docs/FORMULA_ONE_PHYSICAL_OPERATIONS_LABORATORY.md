# Formula One Physical Operations Laboratory

This platform adds ten production-grade Formula One engineering systems to the existing simulator. The module is exposed through `aesim/advanced/formula_one_physical_operations_laboratory.hpp` and linked into `aesim_advanced`.

## Fuel, lubrication, scavenge, and mass migration

The fuel/oil twin integrates fuel consumption, baffled fuel-centroid motion, collector replenishment, pickup coverage, fuel-supply pressure, dry-sump aeration, pressure-stage and scavenge behavior, gallery pressure, oil heating/cooling, vehicle center-of-gravity migration, and yaw-inertia changes. It explicitly flags fuel and oil starvation.

## Tyre construction and contact patch

The tyre laboratory resolves layered tread, belt, carcass, sidewall, and liner behavior. It calculates radial stiffness, loaded radius, contact-patch dimensions and pressure, combined-slip forces, camber thrust, hysteresis, tread/carcass/rim thermal exchange, inflation-pressure evolution, aquaplaning margin, and structural damage.

## Hydraulic and pneumatic network

The network solver supports reservoirs, pumps, accumulators, manifolds, valves, leakage paths, check valves, and double-acting actuators. It integrates pressure, flow, actuator displacement, pump energy, leakage, cavitation, and demand completion while preserving cross-system pressure interactions.

## Laser-scanned track contact

A bilinear height-field model represents laser-scanned road, kerb, and local-friction data. Vehicle trajectories produce wheel impacts, wheel unloading, kerb strikes, plank strikes, floor damage, contact energy, wheel vertical acceleration, and plank-legality results.

## Parc-ferme provenance

The provenance engine maintains serialized and sealed configuration items across practice, qualifying, parc ferme, sprint, race, and post-race phases. It checks legal reasons, approval authorities, like-for-like equivalence, safety-critical hashes, sealed-component changes, and produces a chained SHA-256 audit record.

## Season component and logistics optimization

A deterministic beam-search optimizer allocates serialized component families over the championship calendar. It considers component life, failure growth, performance, free allocations, grid-penalty value, sprint importance, freight distance, mass, and logistics cost.

## Composite manufacture, NDT, and repair

The composite process twin integrates autocatalytic cure kinetics, exotherm, tool heat transfer, consolidation, void reduction, shrinkage stress, wrinkle penalties, stochastic defects, method-specific probability of detection, and scarf-patch repair qualification.

## Trackside weather nowcasting

The nowcaster assimilates quality-weighted observations, advects rain fields using measured wind, applies spatial and temporal kernels, integrates drainage and evaporation, and forecasts corner-level rain, water depth, grip, spray, and tyre crossover timing.

## Pit-wall human decision twin

The pit-wall system represents role competencies, authority, fatigue, stress, message complexity, radio loss, ambiguity, processing queues, deadlines, consultation, confidence, and retained strategic value. It produces workload and operational-resilience evidence.

## Wheel-corner structural laboratory

The wheel-corner twin calculates rim and upright deformation, bearing equivalent load and L10 life, bearing heat, fastener fatigue, kerb impulses, wheel-gun torque transfer, seating and alignment effects, clamp force, and unsafe-release probability.

## Validation

The dedicated test `formula_one_physical_operations_laboratory_unit_tests` exercises all ten systems, evidence generation, physical-state propagation, legality detection, optimization, and qualification outputs.

# Formula One Multiphysics, Optimization, and Real-Time Platform

**Revision:** 2026-07-26  
**Public include:** `aesim/advanced/formula_one_multiphysics_platform.hpp`  
**Library:** `aesim_formula_one`  
**Focused test:** `formula_one_multiphysics_platform_tests`

## 1. Purpose

This layer extends the Formula One predictive-fidelity platform with ten tightly
integrated engineering capabilities:

1. Flexible-body vehicle dynamics.
2. Persistent multi-car wake transport.
3. Integrated thermal-fluid networks.
4. Physics-of-failure component lifing.
5. Optimal experiment design.
6. Advanced Bayesian state estimation.
7. Adaptive multifidelity model selection.
8. Second-order differentiable simulation.
9. One-dimensional compressible power-unit gas dynamics.
10. Real-time ECU and hardware-in-the-loop scheduling.

The implementation is additive. Existing Formula One APIs, commands, libraries,
tests, and reduced-order models remain available. The new layer is intended for
studies that require stronger structural, fluid, reliability, calibration,
optimization, or control-system fidelity than the lower-cost models.

## 2. Flexible-body vehicle dynamics

`F1FlexibleBodyVehicleDynamics` advances modal structural coordinates using the
unconditionally stable average-acceleration Newmark method. Each
`F1StructuralModeConfiguration` contains modal mass, natural frequency, damping,
corner mode-shape coefficients, aerodynamic mode-shape coefficients, steering
compliance, stress recovery, and fatigue properties.

The modal equation is

\[
M_i \ddot q_i + C_i \dot q_i + K_i q_i = Q_i,
\]

where generalized force `Q_i` is assembled from four suspension loads, front and
rear aerodynamic load, and steering-rack force. The result recovers:

- Four corner displacements.
- Front and rear aerodynamic-surface displacement.
- Steering compliance.
- Modal kinetic and strain energy.
- Peak modal stress.
- Accumulated modal fatigue damage.
- A deformation-dependent aerodynamic-load scale.

A default constructor supplies chassis-torsion, floor-heave, front-wing-bending,
and steering-column modes. Production studies should replace these with modal
properties derived from finite-element, rig, or correlation data.

```cpp
F1FlexibleBodyVehicleDynamics structure;
auto structural_state = structure.make_initial_state();
F1FlexibleBodyInput structural_input;
structural_input.time_step_s = 0.001;
structural_input.suspension_force_n = {4200.0, 3800.0, 5100.0, 4700.0};
structural_input.front_aerodynamic_load_n = 7600.0;
structural_input.rear_aerodynamic_load_n = 10200.0;
const auto structural_result = structure.step(structural_input, structural_state);
```

The solver rejects a state with the wrong modal dimension and terminates a study
when a mode exceeds the configured displacement envelope. This prevents silent
continuation after structural-model divergence.

## 3. Persistent multi-car wake field

`F1PersistentMultiCarWakeField` represents the wake as convecting, diffusing,
decaying elements rather than an instantaneous distance multiplier. Every
`F1WakeElement` retains source-car identity, position, velocity deficit,
vorticity, turbulence, heat, moisture, radius, and age.

The field performs:

- Periodic wake emission from each moving car.
- Counter-rotating element generation.
- Ambient-wind advection.
- Deficit and vorticity decay.
- Turbulent radial diffusion.
- Moisture and temperature decay.
- Age and strength pruning.
- Deterministic memory bounding.
- Gaussian spatial sampling at every receiving car.

`F1WakeEffect` reports induced velocity, turbulence, moisture, axle-specific
downforce scaling, drag scaling, cooling scaling, and visibility scaling. The
axial deficit is projected onto the receiving car's direction of travel, so
crosswind and lateral wake motion do not incorrectly appear as pure towing loss.

```cpp
F1PersistentMultiCarWakeField wake;
F1WakeCarState lead{"car_1", {0.0, 0.0, 0.5}, {75.0, 0.0, 0.0},
                    0.0, 17000.0, 5200.0, 2.0, 1.0, 0.0};
F1WakeCarState chase = lead;
chase.id = "car_2";
chase.position_m.x = -8.0;
const auto wake_result = wake.step(0.02, {lead, chase}, {2.0, 1.0, 0.0});
```

Wake elements remain after the generating car leaves the input set until their
age or strength reaches the configured removal limit.

## 4. Integrated thermal-fluid network

`F1IntegratedThermalFluidNetwork` solves a graph of reservoirs, components,
junctions, radiators, pipes, pumps, valves, heat exchangers, and leaks. Node
states contain pressure, temperature, fluid mass, and vapor fraction. Edge
results contain signed mass flow, transferred heat, and cavitation status.

The hydraulic solve iterates pressure and nonlinear resistance:

\[
\dot m = \operatorname{sign}(\Delta p)
         \sqrt{\frac{|\Delta p|}{R_{\mathrm{effective}}}}.
\]

Valve opening modifies resistance quadratically. Pump edges add pressure head.
The thermal solve transports fluid enthalpy and applies component heat,
heat-exchanger rejection, and ambient conductance. The result reports mass and
energy conservation residuals.

Supported Formula One circuits include engine coolant, charge-air coolant,
energy-store coolant, inverter/MGU-K coolant, engine oil, gearbox oil,
hydraulics, brake fluid, and driver cooling. Each circuit can use a separate
network instance and fluid property set.

```cpp
F1ThermalFluidNetworkConfiguration cfg;
// Populate nodes and edges.
F1IntegratedThermalFluidNetwork network(cfg);
auto thermal_state = network.make_initial_state();
const auto thermal_result = network.step(
    0.002, thermal_state,
    {{"energy_store", 18000.0}, {"inverter", 6500.0}},
    {{"radiator_bypass", 0.25}});
```

## 5. Physics-of-failure lifing

`F1PhysicsOfFailureLifing` converts time histories into mechanistic damage. It
implements:

- Turning-point extraction.
- ASTM-style four-point rainflow counting.
- Goodman-type mean-stress correction.
- Stress-life fatigue damage.
- Palmgren-Miner accumulation.
- Paris-law crack propagation.
- Bearing load-life damage.
- Thermal-cycle damage.
- Temperature-accelerated creep damage.

The result identifies the dominant mechanism, combined damage, survival
probability, remaining-useful-life fraction, estimated remaining time, and
failure state. State can be carried from one session to the next.

```cpp
F1ComponentLifingConfiguration upright;
upright.id = "rear_left_upright";
F1PhysicsOfFailureLifing lifing(upright);
auto life_state = lifing.make_initial_state();
const auto life = lifing.evaluate(load_history, life_state);
```

Use stress and bearing load histories from correlated structural models. An
uncalibrated nominal stress history can support comparative studies but not a
qualified absolute life claim.

## 6. Optimal experiment design

`F1OptimalExperimentDesigner` chooses a cost-constrained subset of experiments
from normalized sensitivity matrices. Supported criteria are:

- D-optimality: maximize information determinant.
- A-optimality: minimize covariance trace.
- E-optimality: maximize the weakest information eigenvalue.

Selection is deterministic and greedy with an information-per-cost comparison.
The result includes selected experiment IDs and settings, Fisher information,
regularized parameter covariance, criterion value, total cost, numerical rank,
and full-rank status.

```cpp
F1ExperimentDesignConfiguration design_cfg;
design_cfg.criterion = F1ExperimentDesignCriterion::DOptimal;
design_cfg.maximum_experiments = 3;
design_cfg.maximum_total_cost = 6.0;
F1OptimalExperimentDesigner designer;
const auto design = designer.select(candidates, parameter_count, design_cfg);
```

Generate candidate sensitivities with the differentiable runtime or centered
perturbation studies. Reject a proposed calibration campaign when the selected
information matrix remains rank deficient.

## 7. Advanced Bayesian estimation

`F1AdvancedBayesianEstimator` offers two nonlinear estimators through one API:

- Scaled unscented Kalman filtering.
- Sequential Monte Carlo particle filtering.

The UKF uses sigma points, nonlinear transition and observation callbacks,
process covariance, measurement covariance, cross covariance, and likelihood
tracking. Covariance matrices are stabilized with diagonal jitter when required.

The particle filter supports multivariate Gaussian initialization, nonlinear
propagation, process-noise sampling, Gaussian measurement likelihoods,
effective-sample-size reporting, and deterministic systematic resampling.

```cpp
F1BayesianEstimatorConfiguration estimator_cfg;
estimator_cfg.mode = F1BayesianEstimatorMode::UnscentedKalman;
estimator_cfg.state_dimension = 4;
F1AdvancedBayesianEstimator estimator(estimator_cfg);
estimator.initialize(prior_mean, prior_covariance);
estimator.predict(transition_model, control, 0.01, process_covariance);
const auto posterior = estimator.update(observation_model, measurement,
                                        measurement_covariance);
```

Use the UKF for smooth unimodal posterior distributions. Use the particle filter
for multimodal, strongly nonlinear, discontinuous, or fault-hypothesis studies.

## 8. Adaptive multifidelity manager

`F1AdaptiveMultifidelityManager` registers low-, medium-, and high-fidelity
scalar models with nominal error, runtime, capabilities, and normalized domain.
It updates observed error and runtime using validation records.

At evaluation time, it:

1. Removes models with incompatible domain dimension.
2. Enforces gradient and uncertainty capabilities.
3. Calculates normalized extrapolation distance.
4. Inflates error outside the calibration center.
5. Selects the fastest model satisfying the request.
6. Selects the lowest-error capable model when no model meets all limits.

The returned `request_satisfied` field distinguishes a valid budgeted selection
from a best-available fallback.

```cpp
F1FidelityRequest request;
request.maximum_error = 0.005;
request.maximum_runtime_s = 0.2;
request.gradients_required = true;
const auto evaluation = manager.evaluate(input, request);
```

## 9. Differentiable Formula One runtime

`F1DifferentiableFormulaOneRuntime` implements second-order forward automatic
differentiation. `F1DifferentiableScalar` carries a value, full gradient, and
full Hessian through arithmetic and the following nonlinear functions:

- `exp`
- `log`
- `sqrt`
- `sin`
- `cos`
- `tanh`
- `pow`

Product, quotient, chain, and second-derivative rules are evaluated analytically.
The implementation therefore avoids finite-difference truncation and cancellation
for compatible smooth models.

```cpp
F1DifferentiableFormulaOneRuntime differentiable;
const auto derivatives = differentiable.evaluate(
    {spring_rate, ride_height},
    [](const std::vector<F1DifferentiableScalar>& x) {
        return x[0] * x[0] + 0.4 * x[0] * x[1] + exp(-x[1]);
    });
```

The result contains objective value, gradient, and Hessian. Hybrid events,
discrete branching, saturation, and external black-box solvers remain
nondifferentiable unless represented by a smooth compatible model.

## 10. Compressible power-unit gas dynamics

`F1CompressiblePowerUnitGasDynamics` supplies an executable one-dimensional gas
path for the intake and exhaust. Each duct is divided into finite-volume cells.
The solver advances mass, momentum, total energy, and fuel-species transport with
Rusanov interface fluxes and includes wall heat transfer and Darcy-type friction.

The integrated power-unit state includes:

- Intake and exhaust cell arrays.
- Intake-plenum pressure and temperature.
- Exhaust-manifold pressure and temperature.
- Turbocharger shaft speed.
- Cumulative fuel consumption.

The engine/turbo coupling includes:

- Four-stroke volumetric filling.
- Throttle and volumetric-efficiency effects.
- Stoichiometric fuel limitation.
- Lambda-dependent combustion efficiency.
- Fuel-energy-to-indicated-work conversion.
- Friction mean effective pressure.
- Compressor pressure and temperature ratio.
- Compressor flow capacity.
- Turbine expansion work.
- Wastegate bypass.
- Turbo inertia and speed limits.
- Plenum and manifold mass balance.

```cpp
F1CompressiblePowerUnitGasDynamics power_unit;
auto pu_state = power_unit.make_initial_state();
F1CompressiblePowerUnitInput pu_input;
pu_input.engine_speed_rad_s = 1100.0;
pu_input.throttle = 0.9;
pu_input.fuel_flow_command_kg_s = 0.020;
const auto pu_result = power_unit.step(pu_input, pu_state);
```

The internal step limit should satisfy the acoustic CFL requirement for the
selected cell length. Convergence must be checked by reducing both cell size and
internal time step.

## 11. Real-time ECU and HIL integration

`F1RealtimeEcuHilIntegration` is a portable deterministic ECU scheduler and HIL
transport model. It supports:

- Periodic tasks with phase, deadline, execution time, and priority.
- Fixed-priority execution and response-time reporting.
- Deadline-miss accounting.
- Shared typed signal values.
- CAN message release, arbitration, serialization, and transport latency.
- Up to 64-byte CAN FD payloads.
- Drop, delay, corruption, and stuck-value fault injection.
- Optional wall-clock pacing.
- Scheduler utilization and wall-clock lag reporting.

```cpp
F1RealtimeEcuHilIntegration hil;
F1EcuTaskConfiguration torque_task;
torque_task.id = "torque_control";
torque_task.period_s = 0.001;
torque_task.deadline_s = 0.0008;
torque_task.worst_case_execution_s = 0.0002;
torque_task.priority = F1EcuTaskPriority::Critical;
torque_task.callback = [](double time_s, std::map<std::string, double>& signals) {
    signals["torque_request_nm"] = control_law(time_s, signals);
};
hil.add_task(torque_task);
const auto hil_result = hil.run_until(1.0);
```

The runtime models scheduler and transport semantics in-process. Physical HIL
qualification still requires actual target processors, I/O interfaces, network
hardware, clocks, and external plant equipment.

## 12. Recommended integrated workflow

1. Correlate rigid and flexible vehicle parameters.
2. Calibrate wake emission and decay against CFD or track measurements.
3. Build each vehicle thermal circuit and validate pressure and temperature.
4. Propagate component load histories through lifing.
5. Generate candidate calibration experiments.
6. Select a full-rank experiment set.
7. Run UKF or particle-filter telemetry assimilation.
8. Record validation error in the multifidelity manager.
9. Use automatic derivatives for setup or design optimization.
10. Replace low-fidelity power-unit maps where gas-path transients matter.
11. Execute control software through the real-time scheduler and bus model.
12. Validate the integrated result on withheld laps and fault cases.

## 13. Build and test

```bash
cmake -S . -B build/f1-multiphysics -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2

cmake --build build/f1-multiphysics --parallel 2 --target \
  formula_one_multiphysics_platform_tests

ctest --test-dir build/f1-multiphysics --output-on-failure \
  -R '^formula_one_multiphysics_(platform_unit_tests|source_regression)$'
```

## 14. Qualification boundaries

The platform provides complete executable research models; it does not contain
confidential constructor data. Absolute predictive claims require calibrated
material properties, modal data, flow geometry, thermal-network measurements,
stress recovery, sensor characterization, and independent validation. The
multifidelity manager estimates model suitability from supplied error records;
it cannot manufacture missing validation evidence. The differentiable runtime
provides exact derivatives only for operations represented by its scalar type.

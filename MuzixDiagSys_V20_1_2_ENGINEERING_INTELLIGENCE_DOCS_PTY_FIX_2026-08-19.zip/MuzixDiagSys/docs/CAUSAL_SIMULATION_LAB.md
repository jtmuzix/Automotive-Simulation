# MuzixDiagSys Causal Simulation Laboratory

## Purpose

The causal simulation laboratory adds a coherent set of deterministic debugging,
causal analysis, observability, resilience, sensor, security, rare-event, and
differentiable-simulation services to MuzixDiagSys. The public API is exposed by:

```cpp
#include "aesim/research2/causal_simulation.hpp"
```

It is also included by the umbrella header:

```cpp
#include "aesim/research2/research2.hpp"
```

The implementation is part of `aesim_industrial`; it does not replace or remove
legacy simulation, diagnostics, vehicle, perception, research, or engineering
platform functionality.

## Build and verification

```bash
cmake -S . -B build -DAESIM_BUILD_TESTS=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build -j
ctest --test-dir build -R causal_simulation_unit_tests --output-on-failure
./build/muzixdiagsys_causal_lab status
```

## Command-line utility

```text
muzixdiagsys_causal_lab status
muzixdiagsys_causal_lab timeline-verify timeline.json
muzixdiagsys_causal_lab diff baseline.json candidate.json
muzixdiagsys_causal_lab mine vehicle_log.csv scenarios.json [clusters]
muzixdiagsys_causal_lab rare-gaussian threshold_sigma [samples]
```

`timeline-verify` loads and validates the persisted hash chain. `diff` compares
complete state/input histories. `mine` converts timestamped CSV data into
clustered operational scenarios. `rare-gaussian` is a directly executable
importance-sampling reference problem.

## 1. Deterministic time-travel debugger

`DeterministicTimeTravelDebugger` is an event-sourced simulation recorder. Every
record contains the complete state, input vector, simulation time, event name,
metadata, deterministic random-state token, parent hash, and SHA-256 state hash.
This makes replay integrity explicit rather than dependent on wall-clock state or
mutable process-global data.

Core operations:

- `begin()` establishes a branch with a deterministic initial state and seed.
- `record()` appends a fully validated timeline record.
- `at_sequence()` and `at_time()` provide random access to prior state.
- `rewind()` changes the active cursor without destroying later history.
- `create_branch()` creates a counterfactual branch from an existing record.
- `replay()` invokes a supplied deterministic step function and reports the exact
  sequence and signal of any numerical divergence.
- `save()` and `load()` persist JSON timelines and validate the complete hash chain.

Example:

```cpp
using namespace aesim::research2;

DeterministicTimeTravelDebugger debugger;
debugger.configure(32, 500000);
debugger.begin({{"speed_m_s", 0.0}}, 42);

debugger.record(0.1, {{"speed_m_s", 1.2}}, {{"throttle", 0.4}}, "integration_step");
debugger.create_branch("reduced_throttle", debugger.current().sequence);
debugger.save("timeline.json");
```

The recorder rejects non-finite state values and invalid/corrupt persisted
records. Record limits are enforced to bound memory use.

## 2. Causal run-difference analyzer

`CausalRunDifferenceAnalyzer` compares two deterministic timelines rather than
only their final values. For each input and state signal it calculates:

- first divergent sequence and simulation time;
- maximum absolute and relative differences;
- integrated absolute difference over time;
- graph-aware causal score;
- likely upstream causes and an ordered causal chain.

Dependencies are supplied as `CausalDependency` edges with source, target, lag,
gain, and confidence. Lagged input/state deviations are propagated through this
graph to distinguish an initiating perturbation from downstream symptoms.

```cpp
CausalRunDifferenceAnalyzer analyzer;
analyzer.set_dependencies({
    {"throttle", "engine_torque", 1, 1.0, 0.95},
    {"engine_torque", "vehicle_speed", 1, 0.8, 0.90}
});
auto report = analyzer.compare(baseline.history(), candidate.history());
std::cout << report.report();
```

## 3. Simulation observability and performance tracing

`SimulationObservability` supplies thread-safe structured instrumentation:

- nested spans with parent identifiers and arbitrary attributes;
- counters, gauges, and sampled histograms;
- minimum, maximum, mean, p50, p95, and p99 summaries;
- simulation-time events correlated with wall-clock timestamps;
- critical-path reconstruction from completed spans;
- JSON document output and Chrome Trace Event export.

Chrome traces can be opened in compatible trace viewers to inspect execution
latency, scheduling, solver stages, sensor pipelines, and diagnostics workloads.

```cpp
SimulationObservability trace;
auto step = trace.start_span("simulation.step");
auto solver = trace.start_span("solver.integrate", step);
trace.observe("solver.iterations", 4.0);
trace.end_span(solver);
trace.increment_counter("simulation.steps");
trace.end_span(step);
trace.export_chrome_trace("simulation_trace.json");
```

## 4. Causal diagnostic reasoning

`CausalDiagnosticReasoner` implements a directed Bayesian noisy-OR causal model.
Nodes have prior and leak probabilities; directed edges have activation
probabilities. Diagnostic evidence includes a reliability value so imperfect
measurements do not become unjustified hard facts.

The reasoner supports:

- DAG validation and topological ordering;
- exact inference for networks up to 22 nodes;
- likelihood-weighted Monte Carlo inference for larger graphs;
- Pearl-style `do()` interventions through the interventions map;
- posterior ranking of root-cause nodes;
- information-gain calculation;
- highest-confidence explanation paths to observed evidence;
- JSON model serialization/deserialization.

```cpp
CausalDiagnosticReasoner reasoner;
reasoner.add_node({"coolant_leak", "Coolant leak", 0.01, 0.0, true});
reasoner.add_node({"overtemperature", "Overtemperature", 0.02, 0.0, false});
reasoner.add_edge({"coolant_leak", "overtemperature", 0.92});

auto ranked = reasoner.diagnose({{"overtemperature", {true, 0.98}}});
double prevented = reasoner.infer(
    "overtemperature", {}, {{"coolant_leak", false}});
```

## 5. Scenario mining from real-world logs

`RealWorldScenarioMiner` imports monotonic timestamped CSV logs or accepts
`LogSample` records directly. It transforms sliding windows into features for
each signal: mean, standard deviation, range, and linear trend. Features are
globally normalized before deterministic k-means++ clustering.

The resulting `MinedScenario` records include support, duration, anomaly score,
centroid, feature ranges, exemplar time intervals, and generated trigger
conditions. Low-support clusters may be discarded, while high-z-score windows
are preserved as anomalous operational regimes.

Recommended workflow:

1. Synchronize and sanitize production or proving-ground logs.
2. Select a window duration long enough to contain the physical maneuver.
3. Select stride according to desired overlap and storage budget.
4. Mine several cluster counts and inspect support and exemplars.
5. Convert accepted trigger ranges into simulation scenario constraints.
6. Replay exemplars and counterfactual variants through the debugger.

CSV format:

```csv
time_s,vehicle_speed_m_s,yaw_rate_rad_s,steering_rad,brake_pressure_bar
0.0,12.1,0.01,0.02,0.0
0.1,12.2,0.02,0.03,0.0
```

## 6. Perception-grade sensor simulation

`PerceptionGradeSensorSimulator` supports camera, radar, lidar, and ultrasonic
modalities with one deterministic configuration and release queue per sensor.
It models:

- six-parameter sensor extrinsics and ego/object kinematics;
- horizontal/vertical field of view and minimum/maximum range;
- update cadence and explicit capture-to-delivery latency;
- range, angle, and radial-velocity noise and output variances;
- probabilistic dropouts and Poisson false positives;
- geometric occlusion by nearer objects;
- rain, fog, snow, road spray, illumination, and interference degradation;
- camera image projection, bounding-box size, and rolling-readout timing;
- lidar return density/channel effects;
- modality-specific reflectance, radar cross-section, and confidence.

`simulate()` captures a frame when the configured sensor cadence is due.
`release()` returns only frames whose modeled delivery time has arrived, or all
queued frames when flushing.

## 7. Cyber-physical attack laboratory

`CyberPhysicalAttackLaboratory` injects deterministic, auditable attacks into
signals and packets. Supported campaigns are:

- bias, scaling, drift, freeze, replay, delay, drop, and saturation;
- timestamp skew;
- packet injection.

Each campaign has an independent seed, activation interval, probability, target,
magnitude/rate, bounds, delay, and enabled state. Independent random streams
prevent one campaign from changing another campaign's stochastic sequence.

Signal attacks are accompanied by standardized residual and two-sided CUSUM
monitoring. Every activated campaign produces an `AttackAuditEvent` containing
the original value, attacked value, campaign, target, action, sequence, time,
and detection result.

Use this laboratory only on simulation signals, recorded traffic, or isolated
authorized test benches. The API does not establish network access or bypass
vehicle security controls.

## 8. Graceful-degradation analysis

`GracefulDegradationAnalyzer` models component reliability, dependency cascades,
and capability contributions. Capability requirements define nominal,
degraded, and minimum-risk thresholds. Assessments classify a failure set as:

- `Nominal`;
- `Degraded`;
- `MinimumRisk`;
- `Lost`.

The analyzer performs exact failure-state enumeration for up to 22 components;
larger systems use deterministic-seed Monte Carlo sampling. It reports the
probability mass for every degradation class and identifies inclusion-minimal
critical failure sets up to the configured order.

This supports architecture trades such as redundant sensor selection,
fail-operational controller allocation, minimum-risk maneuver coverage, and
quantitative verification of dependency cascades.

## 9. Rare-event acceleration

`RareEventAccelerator` treats failure as `limit_state(x) <= 0` and offers two
complementary algorithms:

### Cross-entropy adaptive importance sampling

The proposal distribution is iteratively shifted and scaled toward elite
low-limit-state samples. Final estimates use log-domain nominal/proposal
likelihood ratios to avoid numerical underflow. Reports include probability,
standard error, 95% confidence interval, coefficient of variation, effective
sample size, model evaluations, proposal parameters, and intermediate
thresholds.

### Subset simulation

Subset simulation decomposes a very small failure probability into conditional
levels. Elite seeds are advanced with component-wise Markov-chain proposals,
which is useful when the failure domain is disconnected or poorly represented
by a single Gaussian proposal.

For safety claims, confirm convergence across independent seeds, report the
limit-state definition, inspect effective sample size, and cross-check reduced
problems against brute-force Monte Carlo.

## 10. Differentiable simulation

`DifferentiableSimulator` integrates a user-defined continuous-time dynamic
system with fixed-step RK4. It provides:

- state trajectories;
- forward sensitivity ODE integration for every state/parameter pair;
- analytic state and parameter Jacobians when supplied;
- finite-difference Jacobian fallback when analytic functions are absent;
- reverse discrete-adjoint terminal-cost gradients;
- central finite-difference gradient checking;
- per-parameter relative gradient error reporting.

```cpp
DifferentiableSystem system;
system.state_names = {"x"};
system.parameter_names = {"gain"};
system.dynamics = [](double, const auto& x, const auto&, const auto& p) {
    return std::vector<double>{p[0] * x[0]};
};

DifferentiableSimulator simulator;
simulator.configure(system);
auto result = simulator.simulate(
    0.0, 1.0, 0.01, {1.0}, {0.5},
    [](double) { return std::vector<double>{}; },
    [](const auto& x, const auto&) { return 0.5 * x[0] * x[0]; },
    [](const auto& x, const auto&) { return std::vector<double>{x[0]}; },
    [](const auto&, const auto&) { return std::vector<double>{0.0}; },
    true);
```

A small gradient-check error is necessary but not sufficient evidence of a
correct derivative. Validate multiple step sizes, states, and parameter scales.

## Integrated analysis workflow

A high-value workflow combines the subsystems rather than operating them in
isolation:

1. Mine field logs into representative and anomalous scenarios.
2. Execute each scenario with deterministic seeds and record full timelines.
3. Export observability traces and establish runtime/resource baselines.
4. Create attack and component-failure campaigns.
5. Branch the timeline at the initiating event and replay counterfactuals.
6. Compare runs using the causal dependency graph.
7. Feed divergent symptoms into the Bayesian diagnostic reasoner.
8. Classify resulting capability loss and locate minimal critical sets.
9. Accelerate rare variants of the failure mechanism.
10. Use forward/adjoint derivatives to calibrate parameters or optimize margins.

## Determinism and numerical limits

- Reproducibility requires the same model code, compiler-sensitive floating-point
  behavior, input ordering, seeds, and external data.
- Hash-chain equality detects state mismatch but does not prove physical validity.
- Bayesian inference quality is bounded by graph structure and probability calibration.
- Sensor outputs are phenomenological engineering models, not replacements for
  electromagnetic/ray-tracing validation where certification evidence requires it.
- Monte Carlo confidence intervals describe sampling uncertainty, not model-form
  uncertainty.
- Differentiation through discontinuities requires smoothing, event-aware methods,
  or explicit hybrid-system treatment by the caller.

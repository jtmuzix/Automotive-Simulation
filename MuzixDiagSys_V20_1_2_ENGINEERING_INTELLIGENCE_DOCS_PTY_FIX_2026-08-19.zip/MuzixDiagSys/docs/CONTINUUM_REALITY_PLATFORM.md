# Continuum Reality, Multiphase, and Adaptive Resolution Platform

## Purpose

The continuum-reality layer provides ten shared numerical capabilities for every
MuzixDiagSys domain. It extends the existing generalized simulation and
scientific-fidelity services without replacing their APIs.

```cpp
#include "aesim/advanced/continuum_reality_platform.hpp"
```

All public quantities use SI units. The implementations reject non-finite,
inconsistent, and structurally invalid configurations.

## Public API inventory

- `MovingBoundaryMultiphaseCfdSolver`
- `TurbulenceHierarchySolver`
- `GeneralizedPorousElectrodeSolver`
- `TwoFluidPhaseChangeSolver`
- `ParticipatingMediaRadiationSolver`
- `ThreeDimensionalFieldAssimilationAndInversion`
- `PoromechanicsTerrainSolver`
- `AerosolPopulationBalanceSolver`
- `AutomaticManufacturedSolutionVerifier`
- `SimulationWideAdaptiveResolutionController`

## Moving-boundary and free-surface CFD

`MovingBoundaryMultiphaseCfdSolver` advances a two-dimensional cell-centered
incompressible mixture with a conservative liquid volume fraction. It includes:

- Donor-cell phase transport and interface compression.
- Liquid/gas mixture density, viscosity, and heat capacity.
- Explicit momentum advection and diffusion.
- Continuum-surface-force surface tension.
- Pressure-projection incompressibility.
- Thermal advection and diffusion.
- Moving circular immersed bodies with velocity penalization.
- Liquid-volume, divergence, kinetic-energy, and interface audits.

Use small CFL numbers and repeat the study with finer grids. A volume-fraction
interface is diffuse over approximately one cell; topology change is supported
through the transported phase field.

## Turbulence hierarchy

`TurbulenceHierarchySolver` exposes one interface for:

- Laminar flow.
- Spalart-Allmaras.
- k-omega SST.
- Transition SST with intermittency.
- Smagorinsky LES.
- WALE LES.
- Delayed DES.

The solver consumes velocity and wall-distance fields and advances model state,
including turbulent kinetic energy, specific dissipation, modified viscosity,
intermittency, DES length, strain rate, and eddy viscosity. Viscosity limiting
and finite-state validation prevent a closure failure from contaminating the
flow solution.

## Porous-electrode electrochemistry

`GeneralizedPorousElectrodeSolver` provides a one-dimensional porous-electrode
continuum model with user-defined negative electrode, separator, and positive
electrode regions. It advances:

- Electrolyte concentration diffusion and migration source terms.
- Solid average and surface concentration.
- Butler-Volmer reaction current and overpotential.
- Solid and electrolyte Ohmic potential losses.
- Region-specific porosity, conductivity, diffusivity, surface area, and OCV.
- Heat generation and lumped thermal rejection.
- Terminal voltage, state of charge, temperature, and lithium inventory.

The solver is suitable for calibration, control, pack-level embedding, and
multifidelity studies. Microstructure-resolved models should be used where pore
geometry itself is the target quantity.

## Two-fluid phase change

`TwoFluidPhaseChangeSolver` advances liquid and vapor states in a one-dimensional
channel. It includes:

- Pressure-dependent saturation temperature.
- Nucleate boiling closure.
- Condensation closure.
- Cavitation inception and vapor generation.
- Latent and sensible heat transport.
- Separate liquid and vapor velocities.
- Interphase drag and wall friction.
- Critical-heat-flux indication.
- Phase inventory, pressure-drop, mass, and energy audits.

Heat flux may vary with position and time through a callback.

## Participating-media radiation

`ParticipatingMediaRadiationSolver` implements a one-dimensional discrete-
ordinates source iteration for absorbing, emitting, and scattering media. It
supports:

- Configurable even ordinate count.
- Temperature-dependent blackbody emission.
- Absorption and isotropic-scattering source terms.
- Emissive and reflective boundaries.
- Directional sweeps in both directions.
- Scalar intensity, volumetric radiative source, boundary flux, and energy audit.

Use grid and ordinate convergence studies for optically thick, highly
scattering, or sharply varying media.

## Three-dimensional field assimilation and inversion

`ThreeDimensionalFieldAssimilationAndInversion` contains two workflows.

The ensemble workflow applies localized deterministic ensemble Kalman updates to
a structured 3-D field. It reports prior and posterior misfit, posterior mean,
posterior variance, and ensemble spread.

The inverse workflow performs regularized Gauss-Newton estimation with a
user-provided forward operator, finite-difference sensitivities, line search,
and approximate posterior covariance. It supports any model whose predicted
measurements can be represented as a vector.

## Poromechanics and terrain interaction

`PoromechanicsTerrainSolver` couples pore-pressure diffusion, Biot effective
stress, vertical settlement, infiltration, and surface loading on a structured
soil section. It reports pore pressure, settlement, strain energy, mass balance,
and bearing-capacity exceedance.

`evaluate_terrain_contact` adds Bekker-Wong pressure-sinkage and Janosi-Hanamoto
shear mobilization. It returns sinkage, pressure, gross traction, compaction
resistance, drawbar pull, and efficiency.

## Aerosol population balance

`AerosolPopulationBalanceSolver` uses a sectional particle-size distribution and
advances:

- Nucleation.
- Condensational growth.
- Binary coagulation.
- Fragmentation.
- Gravitational or wall deposition represented by deposition velocity.
- Suspended and deposited number and mass.

Transfers between sections preserve particle mass within numerical tolerance.
The report includes number- and mass-mean diameter and a complete mass audit.

## Automatic manufactured-solution verification

`AutomaticManufacturedSolutionVerifier` automatically derives a forcing field
from a user-supplied exact solution for a steady two-dimensional advection-
diffusion-reaction equation. It then:

1. Generates exact Dirichlet boundaries.
2. Solves every requested grid resolution.
3. Calculates L1, L2, and Linfinity errors.
4. Calculates the discrete residual.
5. Fits observed convergence orders.
6. Compares the result with the declared formal order.

This is a code-verification tool. It does not replace validation against physical
measurements.

## Simulation-wide adaptive resolution

`SimulationWideAdaptiveResolutionController` ranks regions using numerical
error, model-form uncertainty, output sensitivity, event probability, and
calibration distance. It can change:

- Mesh scale.
- Polynomial order.
- Time step.
- Physics-fidelity level.
- Particle count.
- Arithmetic precision.

The controller first restores the global cost budget, then selects refinements
by estimated error reduction per incremental cost. Every action includes a
rationale and before/after cost and error estimates.

## Integrated workflow

1. Establish geometry, properties, boundaries, and uncertainty.
2. Run automatic manufactured verification for each new PDE discretization.
3. Select the appropriate turbulence and phase-change hierarchy.
4. Couple multiphase flow, radiation, electrochemistry, and poromechanics through
   the strongly coupled scientific-fidelity runtime when feedback is strong.
5. Assimilate three-dimensional measurements and invert uncertain parameters.
6. Propagate aerosol and environmental fields.
7. Let the adaptive-resolution controller allocate the computational budget.
8. Repeat mesh, time-step, closure, and uncertainty studies.
9. Store results and provenance in the scientific data lake.
10. Validate against independent physical experiments.

## Focused build and test

```bash
cmake -S . -B build/continuum-reality -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2

cmake --build build/continuum-reality --parallel 2 --target \
  continuum_reality_platform_tests

ctest --test-dir build/continuum-reality --output-on-failure \
  -R '^continuum_reality_platform_(unit_tests|source_regression)$'

python3 tests/continuum_reality_platform_source_regression.py .
```

## Standalone strict and sanitizer checks

```bash
g++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  tests/continuum_reality_platform_tests.cpp \
  src/advanced/continuum_reality_platform_a.cpp \
  src/advanced/continuum_reality_platform_b.cpp \
  src/advanced/continuum_reality_platform_c.cpp \
  -o continuum_reality_platform_tests
./continuum_reality_platform_tests

clang++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror -fsanitize=address,undefined \
  -fno-omit-frame-pointer \
  tests/continuum_reality_platform_tests.cpp \
  src/advanced/continuum_reality_platform_a.cpp \
  src/advanced/continuum_reality_platform_b.cpp \
  src/advanced/continuum_reality_platform_c.cpp \
  -o continuum_reality_platform_tests_sanitize
ASAN_OPTIONS=detect_leaks=1 ./continuum_reality_platform_tests_sanitize
```

## Qualification boundary

The APIs are executable engineering implementations. Predictive use still
requires calibrated closure parameters, thermophysical properties, mesh and
time-step convergence, conservative coupling, field-identifiability evidence,
instrument uncertainty, and independent validation in the intended operating
domain. The compact solvers are designed to be embedded, compared, and replaced
through the existing multifidelity framework when a study requires a larger
three-dimensional or externally qualified solver.

# Formula One Integrated Operations, Safety, and Energy Platform

## 1. Scope

`formula_one_integrated_operations_platform.hpp` adds ten executable Formula One systems to the focused `aesim_formula_one` library. The layer is additive. It does not replace the existing regulatory, industrial, fidelity, multiphysics, race-engineering, performance, team-competition, physical-operations, championship-operations, or integrated-realism APIs.

All physical quantities use SI units unless a member name states otherwise. Stochastic models use explicit seeds and produce deterministic results for identical inputs.

## 2. Public modules

| Capability | Production class |
|---|---|
| Spatial pit crew and garage operations | `F1PitCrewGarageOperationsTwin` |
| Occupant, helmet, HANS, restraints, and egress | `F1OccupantHansEgressBiomechanics` |
| Team-radio semantics and comprehension | `F1TeamRadioSemanticComprehensionModel` |
| Dynamic trackside recovery | `F1DynamicTracksideRecoveryOperations` |
| Spray optics and wet visibility | `F1SprayOpticsVisibilityPhysics` |
| Carbon-brake tribology and thermomechanics | `F1CarbonBrakeTribologyThermomechanics` |
| Active-aero mechatronics and ground-effect stability | `F1ActiveAeroGroundEffectTwin` |
| Sustainable-fuel combustion and turbo rotordynamics | `F1SustainableFuelCombustionTurboTwin` |
| Switching-level ERS and EMC | `F1SwitchingLevelErsEmcTwin` |
| Bayesian CFD-tunnel-track aerodynamic fusion | `F1BayesianAeroFieldFusion` |

Include the complete Formula One API with:

```cpp
#include "aesim/advanced/formula_one_platform.hpp"
```

or include only this layer with:

```cpp
#include "aesim/advanced/formula_one_integrated_operations_platform.hpp"
```

## 3. Spatial pit-crew and garage-operations twin

`F1PitCrewGarageOperationsTwin` represents crew members as spatial agents with position, speed, acceleration, reach, role, fatigue, recovery, task-time dispersion, and error probability. Pit tasks have target coordinates, dependencies, role requirements, tool-cycle time, alignment tolerance, retry behavior, and release criticality.

The pit-stop solver performs:

1. Dependency-graph validation and stable topological ordering.
2. Car-stop position sampling from the configured deterministic seed.
3. Role-compatible crew assignment.
4. Acceleration-limited travel-time calculation.
5. Spatial interference and collision-delay evaluation.
6. Fatigue-dependent work-time evaluation.
7. Tool or human failure retries.
8. Release observation and traffic-gap risk calculation.

`simulate_garage_turnaround` adds resource-constrained workshop scheduling, personnel-role capacity, dependencies, rework, session deadlines, and parc ferme legality.

Important outputs include total stationary time, task-level start and finish times, travel and work time, attempts, crew fatigue, collision delay, unsafe-release probability, turnaround completion time, and deadline margin.

## 4. Occupant, helmet, HANS, and egress biomechanics

`F1OccupantHansEgressBiomechanics` integrates a reduced multibody occupant model through a measured or simulated crash pulse. The model includes head and helmet mass, torso, pelvis, neck stiffness and damping, HANS tether engagement, shoulder and lap belts, seat coupling, headrest contact, and cockpit clearance.

The simulation reports:

- HIC15.
- Maximum head linear and angular acceleration.
- Neck tension and compression.
- HANS tether load.
- Shoulder- and lap-belt load.
- Nij proxy.
- Consciousness probability.
- Self-egress probability.
- Estimated egress time.
- Survivability qualification.

Crash pulses must have strictly increasing timestamps. Use measured pulses for validation and repeat with refined time resolution.

## 5. Team-radio semantics and comprehension

`F1TeamRadioSemanticComprehensionModel` separates message composition, transmission, reception, comprehension, acknowledgement, and action execution.

The model accounts for:

- Channel serialization and occupancy.
- Message length and speech duration.
- Channel SNR.
- Clipping.
- Acoustic background level.
- Receiver hearing quality and language fluency.
- Workload, stress, urgency, and working memory.
- Action-word extraction.
- Token loss and misunderstanding.
- Acknowledgement probability.
- Action probability and delay.

This supports studies of missed pit calls, incorrect switch or mode selections, delayed safety responses, and radio-channel congestion.

## 6. Dynamic trackside recovery operations

`F1DynamicTracksideRecoveryOperations` uses a directed service-road and access network. Resources have type, initial node, maximum speed, setup time, and consumables. Tasks specify location, resource type, dependencies, work time, track-crossing requirements, and consumable demand.

The solver performs shortest-time route selection, capability and consumable filtering, dependency scheduling, resource reuse, track-crossing delay, and restart-readiness calculation.

Typical resources include medical vehicles, recovery cranes, flatbeds, intervention vehicles, sweepers, fire crews, and barrier-repair teams. Outputs include route distance, dispatch, arrival, completion, neutralization duration, restart-readiness time, and red-flag recommendation.

## 7. Spray optics and visibility physics

`F1SprayOpticsVisibilityPhysics` advances droplet populations by diameter, number concentration, velocity, and temperature. Sources are generated from tyre-displaced water and water-film depth.

The model includes:

- Diameter-squared evaporation.
- Humidity dependence.
- Coalescence.
- Deposition.
- Wake mixing.
- Wind transport.
- Mie/Rayleigh-regime extinction approximation.
- Beer-Lambert contrast transmission.
- Rain-light detection.
- Camera exposure blur.
- Closing-speed uncertainty.

Outputs include extinction coefficient, optical depth, meteorological visibility, contrast transmission, camera detection probability, rain-light detection probability, suspended-water mass, and deposition.

## 8. Carbon-brake tribology and thermomechanics

`F1CarbonBrakeTribologyThermomechanics` discretizes the disc radially and axially. Each cell stores temperature, wear depth, and transfer-layer state.

The implementation calculates:

- Hydraulic clamp force.
- Temperature-dependent friction.
- Transfer-layer formation and removal.
- Glazing and water penalties.
- Brake torque and heat generation.
- Radial and axial conduction.
- Forced convection and radiation.
- Water cooling.
- Wear-energy accumulation.
- Disc coning and runout.
- Pad knockback and fluid displacement.
- Oxidation damage.
- Judder amplitude.
- Thermomechanical crack risk.

Refine radial and axial segments until torque, peak temperature, coning, and crack risk are stable.

## 9. Active-aero mechatronics and nonlinear ground-effect stability

`F1ActiveAeroGroundEffectTwin` couples a physical actuator to a hysteretic ground-effect model.

The actuator includes:

- Position command and three-sensor voting.
- Motor torque and current.
- Linkage stiffness and damping.
- Hinge friction and aerodynamic hinge moment.
- Rate and travel limits.
- Motor heating and cooling.
- Jam, sensor, overtemperature, and runaway faults.
- Degraded and safe-state behavior.

The ground-effect model includes:

- Front and rear ride height.
- Pitch sensitivity.
- Floor flexible mode.
- Aerodynamic lag.
- Stall and recovery hysteresis.
- Minimum-height contact and bump-stop response.
- Oscillation-energy accumulation.
- Porpoising-risk evaluation.

The result provides transient angle, current, actuator power, downforce, drag change, stall fraction, floor motion, porpoising risk, and fault state.

## 10. Sustainable-fuel combustion and turbo rotordynamics

`F1SustainableFuelCombustionTurboTwin` combines reduced spray evaporation, pre-chamber ignition, cylinder heat release, knock and emissions indicators, compressor/turbine power, flexible shaft response, bearing dynamics, and rotor imbalance.

The combustion model includes:

- Liquid and vapor fuel inventories.
- Temperature- and airflow-dependent evaporation.
- Air-fuel lambda.
- Spark-timing sensitivity.
- Pre-chamber pressure and temperature.
- Pre-chamber jet energy.
- Cycle-window heat release.
- Cylinder pressure and temperature.
- Indicated and brake torque.
- Knock probability.
- Particulate and NOx indicators.

Turbo outputs include pressure ratio, shaft speed, twist, bearing temperature, radial load, vibration amplitude, critical-speed proximity, and failure risk.

## 11. Switching-level ERS and electromagnetic compatibility

`F1SwitchingLevelErsEmcTwin` resolves three inverter phase currents at switching time scales. It includes sinusoidal modulation, dead time, phase resistance and inductance, back EMF, rotor dynamics, current limiting, thermal derating, conduction loss, switching loss, DC-link ripple, common-mode voltage, common-mode current, bearing current, harness coupling, sensor interference, and telemetry-band interference.

The requested time step should resolve the switching period. Run convergence studies on phase current, torque ripple, DC-bus ripple, switching loss, and EMC outputs.

## 12. Bayesian CFD-tunnel-track aerodynamic fusion

`F1BayesianAeroFieldFusion` represents aerodynamic discrepancy as a spatially correlated basis field plus source-specific bias states for CFD, wind tunnel, and track evidence.

The Gaussian information-form update uses:

- Prior field mean and covariance.
- Spatial correlation length.
- Source-specific bias priors.
- Observation sensitivity vectors.
- Measurement uncertainty.
- Full posterior covariance.

Outputs include posterior field, source-bias estimates, predicted observations, normalized residuals, likelihood improvement, information gain, and the candidate test with the greatest expected information per cost.

The observation sensitivity vector must be generated from a physically defensible measurement operator. Assimilated evidence must not be reused as independent validation evidence.

## 13. Integrated workflow

1. Load pit crew, garage resources, and session constraints.
2. Configure occupant and restraint parameters from physical measurements.
3. Calibrate radio participants and channel-quality distributions.
4. Build the recovery service-road graph and resource inventory.
5. Generate spray source terms from the circuit-water and vehicle-wake models.
6. Couple the carbon brake to wheel-end, cooling, and driver-control states.
7. Couple active aero to flexible-body vehicle dynamics and floor contact.
8. Couple sustainable-fuel and turbo outputs to the existing gas path, thermal-fluid, and reliability models.
9. Couple ERS switching outputs to the ECU/HIL, electrical harness, RF, and sensor models.
10. Fuse CFD, tunnel, and track evidence and feed the posterior aero field into setup optimization.
11. Propagate total uncertainty and validate against independent data.

## 14. Focused build and validation

```bash
cmake -S . -B build/f1-integrated-operations -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/f1-integrated-operations --parallel 2 --target \
  formula_one_integrated_operations_platform_tests
ctest --test-dir build/f1-integrated-operations --output-on-failure \
  -R '^formula_one_integrated_operations_(platform_unit_tests|source_regression)$'
python3 tests/formula_one_integrated_operations_source_regression.py .
```

Strict standalone compilation:

```bash
g++ -std=c++17 -O0 -g -Iinclude \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  src/advanced/formula_one_integrated_operations_platform_a.cpp \
  src/advanced/formula_one_integrated_operations_platform_b.cpp \
  src/advanced/formula_one_integrated_operations_platform_c.cpp \
  tests/formula_one_integrated_operations_platform_tests.cpp \
  -o formula_one_integrated_operations_platform_tests
./formula_one_integrated_operations_platform_tests
```

## 15. Qualification boundary

The APIs are complete executable engineering implementations. Constructor-grade predictions still require measured crew trajectories, task and tool distributions, crash pulses, restraint parameters, radio recordings, service-road surveys, droplet and optical measurements, carbon-brake material data, actuator and aeroelastic measurements, fuel and turbo maps, switching hardware data, electromagnetic transfer functions, and independent CFD/tunnel/track evidence.

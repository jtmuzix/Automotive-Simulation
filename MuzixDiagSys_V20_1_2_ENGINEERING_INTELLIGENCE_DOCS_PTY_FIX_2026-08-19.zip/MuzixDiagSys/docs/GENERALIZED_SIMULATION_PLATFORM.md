# Generalized Scientific Simulation Platform

## Purpose

The generalized platform provides common execution, numerical, data, and
interoperability services for every MuzixDiagSys domain. It is exported through:

```cpp
#include "aesim/advanced/generalized_simulation_platform.hpp"
```

and transitively through:

```cpp
#include "aesim/advanced/platform.hpp"
```

The implementation is compiled into `aesim_advanced`. It does not replace any
existing vehicle, motorsport, electrification, autonomy, manufacturing,
infrastructure, safety, or diagnostic model. Existing subsystems can adopt the
services independently.

All APIs reject malformed identifiers, non-finite numerical values, invalid
configuration, incomplete checkpoint barriers, cyclic task graphs, and unsafe
write-oriented data-lake queries.

## Public subsystems

- `ElasticDeterministicDistributedRuntime`
- `DistributedCheckpointCoordinator`
- `UnifiedMeshFieldService`
- `HardwareAwareSolverAutotuner`
- `HighIndexDaeModelicaCompiler`
- `CrossSolverDifferentialVerifier`
- `VerificationBenchmarkRegistry`
- `QueryableScientificDataLake`
- `GeneralizedRemoteApiRouter`
- `GeneralizedHttpServer`
- `GeneralizedNotebookSdk`
- `CrossPlatformDeterministicEquivalenceLaboratory`

## Elastic deterministic distributed runtime

`ElasticDeterministicDistributedRuntime` executes a dependency-directed task
DAG over a capability-constrained worker pool. The runtime provides:

- Stable lexical topological ordering.
- Deterministic worker ranking derived from master seed, task ID, capacity, and
  declared relative speed.
- Capability filtering.
- Dependency failure propagation.
- Bounded retry attempts.
- Deterministic migration among eligible workers.
- Per-attempt deterministic random seeds.
- Ordered event journals.
- Output hashes and aggregate execution hashes.
- Retry and migration accounting.

Example:

```cpp
using namespace aesim::advanced;

ElasticDeterministicDistributedRuntime runtime;
runtime.configure(
    {
        {"cpu-a", {"cpu", "implicit"}, 4, 1.0, true},
        {"gpu-a", {"gpu", "implicit"}, 8, 5.0, true},
    },
    0x5eed,
    [](const GeneralizedDistributedTask& task,
       const GeneralizedDistributedWorker& worker,
       std::uint64_t seed) {
        GeneralizedTaskExecution execution;
        execution.success = true;
        execution.output = task.payload + ":" + worker.id + ":" +
                           std::to_string(seed);
        return execution;
    });

const auto report = runtime.execute({
    {"mesh", {}, "mesh", {"cpu"}, 2, 1.0},
    {"solve", {"mesh"}, "solve", {"implicit"}, 3, 10.0},
});
```

The current runtime executes deterministically within one process while
representing elastic worker placement and migration. Network transports can use
the same task, event, seed, and checkpoint contracts without changing model
code.

## Distributed coordinated checkpoint and restart

`DistributedCheckpointCoordinator` creates globally consistent checkpoints from
partition contributions. The coordinator implements:

- Explicit begin/contribute/commit barriers.
- Expected-partition enforcement.
- SHA-256 content addressing.
- Chunk deduplication across checkpoints.
- Atomic temporary-file replacement.
- Manifest hashes.
- Per-partition metadata.
- Integrity verification during restore.
- Checkpoint catalog enumeration.

```cpp
DistributedCheckpointCoordinator checkpoints("run/checkpoints");
checkpoints.begin("step-5000", 5000, 50.0, {"vehicle", "weather"});
checkpoints.contribute({"vehicle", vehicle_bytes, {{"solver", "BDF2"}}});
checkpoints.contribute({"weather", weather_bytes, {{"mesh", "regional"}}});
const auto manifest = checkpoints.commit();
```

A commit fails unless every expected partition has contributed. Restores verify
both the manifest and each chunk digest before returning state bytes.

## Unified mesh and field service

`UnifiedMeshFieldService` supplies a common representation for structured and
unstructured geometry. The current production service supports line, triangle,
quadrilateral, tetrahedral, and axis-aligned hexahedral measures; vertex and cell
fields; structured quadrilateral mesh generation; deterministic partitioning;
ghost-vertex identification; nearest-neighbor transfer; conservative scalar
cell transfer; and field integration.

```cpp
const auto coarse = UnifiedMeshFieldService::structured_quad_mesh(
    "coarse", 20, 10, 4.0, 2.0);
const auto fine = UnifiedMeshFieldService::structured_quad_mesh(
    "fine", 80, 40, 4.0, 2.0);

UnifiedField energy{
    {"energy_density", UnifiedFieldLocation::Cell, 1, "J/m2", true},
    coarse_values,
};
const auto mapped =
    UnifiedMeshFieldService::transfer_conservative_cell_scalar(
        coarse, energy, fine);
```

Conservative transfer rescales the destination field so its integrated quantity
matches the source integral to floating-point tolerance.

## Hardware-aware solver autotuning

`HardwareAwareSolverAutotuner` profiles architecture, logical cores, pointer
width, compile-time SIMD features, scalar throughput, and memory bandwidth. The
tuner executes caller-provided solver candidates and selects the fastest valid
candidate that satisfies error and memory limits. If no candidate satisfies all
limits, it returns the best valid fallback with
`requirement_satisfied == false`.

Candidate definitions can include algorithm, thread count, block size,
precision, and arbitrary numerical options. Benchmark callbacks report runtime,
error, memory, and validity.

Autotuning records are empirical evidence for the current executable and host.
They should be regenerated after compiler, driver, library, firmware, or
hardware changes.

## High-index DAE and Modelica equation compiler

`HighIndexDaeModelicaCompiler` implements an operational equation-language
compiler and implicit DAE runtime. The supported source language includes:

- `model Name ... end Name;`
- `parameter Real` declarations.
- `Real` variables with `start` values or direct initializers.
- `equation` sections.
- `der(variable) = expression` equations.
- Algebraic equations.
- Two-terminal `connect(a,b)` equations.
- Arithmetic operators and powers.
- `sin`, `cos`, `tan`, `exp`, `log`, `sqrt`, `abs`, and `tanh`.

The compiler performs:

- Declaration and reference validation.
- Differential/algebraic classification.
- Structural equation counting.
- Holonomic-constraint detection.
- Pantelides-style total-time differentiation.
- Numerical structural-rank analysis.
- High-index reporting.
- Implicit backward-Euler residual construction.
- Finite-difference Newton Jacobians.
- Regularized least-squares correction.
- Backtracking line search.
- Algebraic constraint reporting.

Example index-3 model:

```modelica
model ConstrainedPendulum
  parameter Real g = 9.81;
  Real x(start=1.0);
  Real y(start=0.0);
  Real vx(start=0.0);
  Real vy(start=0.0);
  Real lambda(start=0.0);
equation
  der(x) = vx;
  der(y) = vy;
  der(vx) = -lambda*x;
  der(vy) = -g-lambda*y;
  x*x + y*y = 1.0;
end ConstrainedPendulum;
```

The compiler is a complete implementation of the documented in-project
language. It is not presented as a complete implementation of every construct in
the external Modelica language standard. Unsupported declarations or functions
are rejected with explicit diagnostics rather than silently ignored.

## Cross-solver differential verification

`CrossSolverDifferentialVerifier` executes two or more solver variants and
compares their trajectories against the first variant. It reports:

- SHA-256 trajectory hashes.
- Per-channel maximum absolute error.
- Per-channel maximum relative error.
- Per-channel RMS error.
- First divergence time.
- Timestamp disagreement.
- Missing channels.
- Event-sequence mismatch.

Use independent algorithms or backends when possible. Two wrappers around the
same implementation do not provide independent verification evidence.

## Verification benchmark registry

`VerificationBenchmarkRegistry` provides executable reference problems. The
built-in registry currently includes:

- RK4 exponential decay.
- Symplectic harmonic-oscillator energy conservation.
- Manufactured one-dimensional Poisson solution.
- Periodic finite-volume advection conservation.

Each benchmark reports its measured value, reference value, absolute error,
allowed error, additional metrics, and pass state. New benchmarks can be
registered at runtime with independent executable callbacks.

## Queryable scientific data lake

`QueryableScientificDataLake` uses SQLite in WAL mode with full synchronous
commits. It provides:

- Typed dataset creation.
- Dataset metadata.
- Transactional batched appends.
- Read-only SQL queries.
- Aggregate and join queries.
- CSV import.
- RFC-style CSV escaping on export.
- Dataset catalog enumeration.
- BLOB integrity digests in textual query output.

```cpp
QueryableScientificDataLake lake("study.sqlite");
lake.create_dataset(
    "telemetry",
    {{"run_id", "TEXT"}, {"time_s", "REAL"}, {"temperature_k", "REAL"}},
    {{"units", "SI"}});

lake.append("telemetry", rows);
const auto result = lake.query(
    "SELECT run_id, MAX(temperature_k) FROM telemetry GROUP BY run_id;");
```

The query method only accepts statements SQLite classifies as read-only. Dataset
creation and append operations use separate validated APIs.

## Remote API and notebook SDK

`GeneralizedRemoteApiRouter` maps exact HTTP method/path pairs to typed C++
handlers. `GeneralizedHttpServer` is an actual HTTP/1.1 TCP server supporting:

- IPv4 bind addresses.
- Ephemeral or fixed ports.
- Request headers and body.
- Content-Length handling.
- JSON defaults.
- Error responses.
- Graceful stop.
- Linux/POSIX sockets and Windows Winsock.

`GeneralizedNotebookSdk` provides an in-process C++ client. The Python package
adds `muzixdiag.generalized.GeneralizedClient`, which provides:

- Standard-library HTTP/HTTPS requests.
- JSON GET and POST helpers.
- Health and OpenAPI helpers.
- SQL table-result handling.
- Study submission and polling.
- Newline-delimited or SSE-style event streaming.
- Notebook HTML rendering through `TableResult._repr_html_()`.

Python example:

```python
from muzixdiag.generalized import GeneralizedClient

client = GeneralizedClient("http://127.0.0.1:8080")
print(client.health())
result = client.query(
    "SELECT run_id, AVG(temperature_k) FROM telemetry GROUP BY run_id"
)
result
```

Authentication, authorization, TLS termination, rate limiting, and multi-tenant
policy should be supplied by the existing security platform or a deployment
proxy when the server is exposed beyond a trusted engineering host.

## Cross-platform deterministic-equivalence laboratory

`CrossPlatformDeterministicEquivalenceLaboratory` compares serialized state,
numeric outputs, and event sequences from multiple backends. It implements five
qualification levels:

| Level | Requirement |
|---|---|
| `Statistical` | Bounded distribution-level numerical disagreement |
| `EngineeringTolerance` | Numeric output within configured absolute or relative tolerance |
| `EventSequence` | Engineering tolerance plus identical ordered events |
| `SerializedState` | Event equivalence, numeric tolerance, and equal serialized-state size |
| `Bitwise` | Identical serialized bytes and ordered events |

Every backend record includes platform, compiler, architecture, executable
callbacks, numeric output, event output, and a SHA-256 serialized-state hash.
A model should publish the strongest level it can consistently satisfy.

## Recommended integrated workflow

1. Define semantic task IDs and deterministic master seeds.
2. Partition the model with `UnifiedMeshFieldService`.
3. Profile hardware and select a solver candidate.
4. Compile equation-based subsystems and verify structural rank.
5. Execute the dependency graph.
6. Commit coordinated checkpoints at validated synchronization points.
7. Persist telemetry and study outputs in the scientific data lake.
8. Run reference benchmarks and cross-solver differential comparisons.
9. Expose approved operations through the remote API.
10. Analyze results through the notebook SDK.
11. Run deterministic-equivalence qualification across target toolchains and
    hardware.

## Build and validation

```bash
cmake -S . -B build/generalized -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_MAX_PARALLEL_COMPILES=2

cmake --build build/generalized --parallel 2 --target \
  generalized_simulation_platform_tests

ctest --test-dir build/generalized --output-on-failure \
  -R '^generalized_simulation_platform_(unit_tests|source_regression)$'

python3 tests/generalized_simulation_platform_source_regression.py .
```

For sanitizer qualification:

```bash
cmake -S . -B build/generalized-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/generalized-sanitize --parallel 2 --target \
  generalized_simulation_platform_tests
ctest --test-dir build/generalized-sanitize --output-on-failure \
  -R '^generalized_simulation_platform_unit_tests$'
```

## Qualification boundaries

The services are executable engineering implementations, not automatic evidence
that every integrated domain model is correct. Users must still define:

- Model calibration and validation data.
- Mesh and time-step convergence criteria.
- Solver tolerances.
- Checkpoint synchronization boundaries.
- Reproducibility level.
- Hardware and compiler qualification matrix.
- Authentication and deployment controls.
- Data-retention and access policy.
- Modelica-language constructs required by a specific imported model.
- Independent reference solutions.

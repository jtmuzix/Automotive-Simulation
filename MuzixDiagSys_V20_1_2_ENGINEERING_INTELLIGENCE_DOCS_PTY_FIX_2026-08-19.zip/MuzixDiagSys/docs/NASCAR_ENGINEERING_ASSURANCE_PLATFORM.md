# NASCAR Engineering Assurance Platform

**Release:** 2026-07-28  
**Library:** `aesim_nascar`  
**Public API:** `aesim/advanced/nascar_engineering_assurance_platform.hpp`  
**CLI family:** `muzixdiagsys_advanced_platform nascar-assurance`

## Purpose

The NASCAR Engineering Assurance Platform adds twelve executable engineering,
regulatory, competition-observation, safety, manufacturing, reliability, and
experimental-design domains to the existing NASCAR platform. It is additive:
the original `nascar` and `nascar-integrated` commands, all 52 previously
implemented NASCAR domains, and every existing public header remain available.

Every domain:

- validates dimensions, ranges, identifiers, chronology, and finite arithmetic;
- returns a structured JSON report with `passed`, `findings`, and a deterministic
  SHA-256 `evidence_digest`;
- optionally writes its report atomically to a working directory;
- has a canonical request under `examples/nascar_engineering_assurance/`;
- participates in the focused C++ unit test, source-integrity regression, CLI
  workflow, sanitizer workflow, and documentation regression.

## Public C++ API

```cpp
#include "aesim/advanced/nascar_engineering_assurance_platform.hpp"

using aesim::advanced::nascarassure::NascarEngineeringAssurancePlatform;
using aesim::doc::Value;

NascarEngineeringAssurancePlatform platform;
Value capabilities = platform.capabilities();
Value result = platform.execute(
    "regulation-digital-thread",
    request,
    "evidence/nascar-assurance");
Value qualification = platform.self_test("evidence/nascar-assurance/self-test");
```

Individual domain classes are also public:

- `NascarRegulationDigitalThread`
- `NascarDynamicCompliance`
- `NascarProspectiveOemProgram`
- `NascarTimingObservationFusion`
- `NascarOfficiatingPolicyLab`
- `NascarContactDamageRaceability`
- `NascarCrashSaferFiniteElementTwin`
- `NascarFireRescueHazards`
- `NascarDebrisRecovery`
- `NascarCompositeManufacturing`
- `NascarFleetReliability`
- `NascarTestDesignCalibration`

## Build and qualification

```bash
cmake -S . -B build/nascar-assurance -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF

cmake --build build/nascar-assurance --parallel --target \
  aesim_nascar \
  nascar_engineering_assurance_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/nascar-assurance --output-on-failure \
  -R '^nascar_.*(platform_unit_tests|source_regression)$'
```

Sanitizer qualification:

```bash
cmake -S . -B build/nascar-assurance-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/nascar-assurance-sanitize --parallel --target \
  nascar_engineering_assurance_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ./build/nascar-assurance-sanitize/nascar_engineering_assurance_platform_tests
```

## CLI

```bash
./build/nascar-assurance/muzixdiagsys_advanced_platform \
  nascar-assurance capabilities capabilities.json

./build/nascar-assurance/muzixdiagsys_advanced_platform \
  nascar-assurance self-test evidence self-test.json

./build/nascar-assurance/muzixdiagsys_advanced_platform \
  nascar-assurance DOMAIN REQUEST.json OUTPUT.json evidence
```

Supported domains:

```text
regulation-digital-thread
dynamic-compliance
prospective-oem-program
timing-observation-fusion
officiating-policy-lab
contact-damage-raceability
crash-safer-fe
fire-rescue-hazards
debris-recovery
composite-manufacturing
fleet-reliability
test-design-calibration
```

## 1. Regulation digital thread

### Objective

Resolve effective-dated, series-specific, track-class-specific, and
session-specific rules into one authoritative numerical configuration. The
solver prevents multiple source documents from silently defining different
values for the same simulation parameter.

### Inputs

- `event.date`: ISO `YYYY-MM-DD` date.
- `event.series`, `event.track_class`, `event.session`.
- `rules[]`: unique rule ID, source, state, revision, precedence, effective and
  optional expiry dates, selectors, numerical parameters, and affected
  dependencies.
- Optional `baseline_configuration` and `saved_artifacts`.

### Resolution algorithm

Applicable rules are filtered by date and selectors. Parameter candidates are
ranked deterministically by:

1. explicit precedence;
2. selector specificity;
3. lifecycle state (`waivered`, `homologated`, `effective`, `published`,
   `announced`);
4. revision;
5. rule ID as a deterministic tie-break.

An equally ranked disagreement is an error. Lower-ranked disagreements are
recorded as resolved conflicts. The output includes parameter-level provenance,
a rule-to-software dependency trace, a baseline difference set, and saved-study
invalidation results.

## 2. Dynamic compliance

### Objective

Predict how a compliant pre-race car may drift toward or beyond post-race
measurement limits through fuel burn, spring settling, damper fade, tire-radius
loss, floor load, splitter wear, contact, repair offsets, fluid loss, and
measurement uncertainty.

### State and probability model

Each time-ordered race segment updates:

- front and rear ride height;
- splitter wear;
- body offset;
- left and right toe;
- total mass;
- spring settling, damper fade, floor deflection, tire-radius loss, and
  accumulated damage.

For measurement value `x`, lower limit `L`, upper limit `U`, and standard
uncertainty `sigma`, the two-sided failure probability is:

```text
P(fail) = Phi((L-x)/sigma) + 1 - Phi((U-x)/sigma)
```

The report identifies the first probable noncompliance time and physical
measurement, peak probability by measurement, combined failure probability,
and recommended statistical guard bands.

## 3. Prospective OEM program

### Objective

Model a complete prospective-manufacturer program rather than aerodynamic
parity alone.

### Implemented analysis

- dependency-checked milestone DAG and critical-path duration;
- remaining program cost;
- constrained test-day accounting;
- test information score from correlation and requirement coverage;
- weighted aerodynamic lift/drag parity error;
- engine torque-correlation error;
- capacity, quality, delivery, and criticality weighted supplier readiness;
- combined technical-readiness score;
- explicit budget, test-limit, parity, and approval gates.

Cycles and unknown predecessors are rejected. Every milestone, test, and
supplier has a traceable report entry.

## 4. Timing observation fusion

### Objective

Fuse timing loops, SMT, video, GNSS/IMU, and other observations without treating
any timestamp as exact.

### Algorithm

Every observation carries timestamp uncertainty, detection probability, source
quality, and latency. Latency is removed before fusion. Initial
inverse-variance estimates are iteratively refined with Huber robust weights.
The solver reports:

- fused crossing time and standard uncertainty;
- confidence interval;
- normalized residual by source;
- consistency score;
- most probable classification;
- pairwise order-reversal probability for adjacent cars;
- source-health residual RMS.

A statistically ambiguous order is retained as evidence rather than forced into
false certainty.

## 5. Officiating policy laboratory

### Objective

Compare alternative officiating policies while preserving the boundary between
simulation evidence and human authority.

Each incident includes severity, blockage, medical urgency, debris hazard,
evidence confidence, fault probability, field-compression cost, and positional
sensitivity. Each policy defines caution delay, investigation threshold,
penalty scale, and review time.

The lab calculates residual safety risk, competitive impact, due-process score,
and comparable-incident penalty dispersion. Policies are ranked by a configured
weighted cost. The report explicitly states that simulation quantifies
consistency and consequence; it does not replace official fact finding or
discretion.

## 6. Contact damage and raceability

### Objective

Carry repeated nonterminal contact forward as an evolving vehicle state.

The model updates bumper and fender crush, toe, camber, steering bias, tire
pressure, cooling blockage, splitter and diffuser damage, drag, downforce,
vibration, tire temperature, engine temperature, achievable speed, and
raceability. It estimates DVP repair time and recommends repairs based on the
actual final state.

This domain is distinct from severe crash analysis: the vehicle can remain in
competition while progressively losing performance or safety margin.

## 7. Crash and SAFER finite-element twin

### Objective

Provide a complete explicit nonlinear structural solver for detailed crash
studies while retaining the faster existing reduced-order crash domains.

### Numerical model

- user-defined one-dimensional structural nodes with mass, position, group, and
  optional fixed boundary;
- nonlinear spring-damper elements;
- elastic-plastic force limiting;
- accumulated permanent extension and plastic dissipation;
- ultimate-strain element deletion;
- penalty wall contact with damping;
- explicit time integration;
- node histories, peak intrusion, peak deceleration, barrier deflection,
  failed-element count, and energy audit;
- HIC15 screening from the selected occupant-reference node.

The term finite element refers to the implemented nodal/element discretization.
Engineering certification still requires geometrically and materially
calibrated three-dimensional models and physical correlation.

## 8. Fire and rescue hazards

### Objective

Couple released fuel/oil, ignition, combustion, smoke, carbon monoxide, oxygen,
thermal exposure, suppression, ventilation, fuel isolation, rescue routing, and
extraction.

The time-domain model calculates burn rates, heat release, cabin temperature,
radiant flux, smoke extinction, visibility, CO dose, thermal dose, agent
remaining, ignition and extinguishment times, route risk, rescue time, and a
screening survivability probability.

Actions are executed chronologically and affect subsequent state. Unknown
actions, invalid routes, and nonphysical masses or rates are rejected.

## 9. Debris recovery

### Objective

Predict where fragments travel, whether they are detected, how they threaten
following cars, and whether cleanup supports reopening.

The solver includes:

- three-dimensional ballistic motion;
- gravity, aerodynamic drag, wind, and wake transport;
- ground bounce, tangential energy retention, and settling;
- sensor-range, quality, and fragment-size-dependent detection probability;
- residual hazard and puncture probability;
- deterministic hazard-priority cleanup route;
- cleanup time and post-cleanup reopening confidence.

## 10. Composite manufacturing

### Objective

Connect cure process, laminate construction, dimensional variation, bondline
quality, repair history, structural properties, and aerodynamic consequences.

### Implemented physics and quality analysis

- Arrhenius cure kinetics with reaction order;
- exothermic heat release and tool/oven heat transfer;
- pressure-, viscosity-, and time-dependent void compaction;
- temperature- and cure-dependent viscosity;
- transformed ply extensional and shear stiffness;
- porosity and cure knockdown;
- anisotropic coefficient-of-thermal-expansion springback;
- bondline thickness/strength response;
- repair-area structural and aerodynamic penalties;
- scan error, mean, standard deviation, and process capability.

## 11. Fleet reliability

### Objective

Learn population and supplier-lot reliability from censored and failed part
histories, then determine next-event risk for serialized current parts.

The implementation uses a Bayesian-shrunk Weibull model by part type. It
combines prior effective failures and characteristic life with observed
exposure and failures. Supplier-lot hazard multipliers, overload damage,
thermal damage, and inspection health modify effective age.

Outputs include:

- Weibull shape and characteristic life by part type;
- part effective age;
- supplier-lot and damage multipliers;
- conditional next-event failure probability;
- remaining useful life;
- replacement plan;
- fleet failure probability and expected failure count.

## 12. Test design and calibration

### Objective

Select the most informative feasible test program across wind tunnel, dyno,
tire, seven-post, track, and other candidate tests.

The solver starts from the inverse prior covariance as the information matrix.
Each candidate contributes:

```text
Delta I = sensitivity * sensitivity^T / measurement_variance
```

A deterministic greedy D-optimal search maximizes log-determinant information
gain per cost while respecting budget, maximum test count, maximum repeats, and
required categories. The report includes the ordered design, cumulative cost,
information gain, posterior covariance, posterior parameter uncertainty,
uncertainty reduction, missing categories, and identifiability evidence.

## Canonical end-to-end workflow

```bash
set -euo pipefail
for item in \
  regulation-digital-thread:regulation_digital_thread \
  dynamic-compliance:dynamic_compliance \
  prospective-oem-program:prospective_oem_program \
  timing-observation-fusion:timing_observation_fusion \
  officiating-policy-lab:officiating_policy_lab \
  contact-damage-raceability:contact_damage_raceability \
  crash-safer-fe:crash_safer_fe \
  fire-rescue-hazards:fire_rescue_hazards \
  debris-recovery:debris_recovery \
  composite-manufacturing:composite_manufacturing \
  fleet-reliability:fleet_reliability \
  test-design-calibration:test_design_calibration
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/nascar-assurance/muzixdiagsys_advanced_platform \
    nascar-assurance "$domain" \
    "examples/nascar_engineering_assurance/${stem}.json" \
    "build/nascar-assurance/${stem}.result.json" \
    build/nascar-assurance/evidence
done
```

## Interpretation and qualification boundary

A report with `passed=true` means the request satisfied the encoded numerical,
logical, and threshold checks. It does not mean a real car, part, event,
facility, medical response, or officiating decision is certified. Quantitative
engineering use requires current rule inputs, calibrated geometry and material
data, validated measurement uncertainties, convergence studies, independent
correlation, controlled test evidence, and competent NASCAR, team, OEM,
medical, safety, manufacturing, or regulatory review as applicable.

## Motorsport CLI convenience aliases

The original `nascar-assurance` family remains authoritative. `nascar run assurance DOMAIN ...` provides suite routing; `nascar-officiating` directly targets `officiating-policy-lab`. See `MOTORSPORT_CLI_COMMANDS.md`.

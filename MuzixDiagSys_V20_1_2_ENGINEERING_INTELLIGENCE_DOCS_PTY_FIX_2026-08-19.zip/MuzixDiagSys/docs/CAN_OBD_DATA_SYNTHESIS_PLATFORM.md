# CAN, OBD-II, and Automotive Data-Synthesis Platform

**Documentation revision:** 2026-07-13 - authoritative diagnostics, multi-ECU virtual adapter, ISO-TP/CAN-FD, and measured-data validation

## Overview

The CAN/OBD platform adds guarded communication with Linux SocketCAN interfaces, a functional OBD-II client and virtual ECU, trace capture and analysis, and deterministic generation of labelled multi-ECU datasets. It is integrated into the existing virtual automotive laboratory and does not replace the earlier CAN, CAN-FD, ISO-TP, UDS, J1939, DBC, XCP, MDF, or simulated diagnostic features.

The implementation is designed around three operating principles:

1. **Receive-first safety.** A real interface opens in `listen-only` application mode. Diagnostic reads, diagnostic writes, and arbitrary raw transmission require separate explicit access levels.
2. **Protocol-correct data.** OBD values are encoded and decoded through SAE PID scaling, ISO-TP segmentation, ECU response identifiers, supported-PID bitmaps, and DTC/VIN services.
3. **Physically coherent synthesis.** Engine, chassis, body, battery, and diagnostic traffic is generated from one shared vehicle trajectory, so correlated channels do not contradict one another.

The command hierarchy is:

```text
industrial vehicle experience lab can ...
industrial vehicle experience lab obd ...
industrial vehicle experience lab synthesis ...
```

The existing aliases `automotive-lab` and `engineering-lab` remain valid.

## Authoritative diagnostic service

`aesim::industrial::DiagnosticService` is the sole semantic authority for ECU identity, PID, VIN, DTC, readiness, freeze-frame behavior, UDS services and DIDs, functional and physical routing, DoIP logical addresses, SOVD resources, and test-facing requests. The guarded gateway, SocketCAN responder, CLI, ELM327-compatible virtual adapter, DoIP facade, and SOVD facade delegate to it. `include/modules/can_uds.hpp` remains source-compatible but no longer carries an independent header-only protocol implementation.

Default virtual topology:

| ECU | Logical | Request | Response | OBD | UDS |
|---|---:|---:|---:|:---:|:---:|
| Powertrain | `0x10` | `0x7E0` | `0x7E8` | Yes | Yes |
| Transmission | `0x18` | `0x7E1` | `0x7E9` | Yes | Yes |
| Brakes | `0x28` | `0x760` | `0x768` | Yes | Yes |
| Battery | `0x30` | `0x7E4` | `0x7EC` | Yes | Yes |
| Body | `0x40` | `0x740` | `0x748` | No | Yes |

Direct console facades:

```text
diagnostics topology
diagnostics obd powertrain 010C
diagnostics uds powertrain 22F190
elm ATH1
elm 010C
doip 10 22F190
sovd GET /entities
```

## Build requirements

The portable loopback implementation builds on every supported platform. Live SocketCAN communication is available on Linux when the project is built with the existing SocketCAN transport.

A typical Debug build is:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j"$(nproc)"
```

No dedicated vehicle adapter is required to use the virtual ECU, trace-analysis, or synthetic-data functions.

## Safety model

The gateway uses four progressively stronger application access modes:

| Mode | Receive | OBD read | OBD clear/write | Raw CAN transmission |
|---|---:|---:|---:|---:|
| `listen-only` | Yes | No | No | No |
| `diagnostic-read` | Yes | Yes | No | No |
| `diagnostic-write` | Yes | Yes | Yes | No |
| `raw-allowlist` | Yes | Yes | Yes | Only explicitly allowed IDs |

The gateway also enforces a configurable maximum transmit-frame rate. Raw transmission requires both `raw-allowlist` mode and an exact identifier in the allowlist.

These controls reduce accidental transmission risk, but they do not make arbitrary commands safe for a real vehicle. Use an isolated bench, an appropriate gateway, a fused interface, and manufacturer documentation. Never perform control experiments on a public road or on a vehicle that can move unexpectedly.

## Loopback quick start

The loopback backend provides a self-contained virtual ECU and is the recommended first test:

```text
industrial vehicle experience lab can interface loopback
industrial vehicle experience lab can open
industrial vehicle experience lab can access diagnostic-read 50
industrial vehicle experience lab obd scan
industrial vehicle experience lab obd pid 0C
industrial vehicle experience lab obd pid 0D
industrial vehicle experience lab obd vin
industrial vehicle experience lab obd derived
industrial vehicle experience lab can status
```

The virtual ECU is continuously updated from the running simulator. It publishes engine speed, vehicle speed, calculated load, thermal state, manifold pressure, airflow, throttle, lambda, fuel rate, torque, module voltage, and odometer values.

A standalone virtual state can also be supplied:

```text
industrial vehicle experience lab obd virtual 2400 72 43 91 28 8.2 14.1 AESIMTESTVIN00001
```

## Linux SocketCAN quick start

Select a classical CAN or CAN-FD interface:

```text
industrial vehicle experience lab can interface socketcan can0 classic
industrial vehicle experience lab can open
industrial vehicle experience lab can access listen-only 20
industrial vehicle experience lab can receive 100 500
```

For CAN-FD:

```text
industrial vehicle experience lab can interface socketcan can0 fd
```

The operating system is responsible for configuring bitrate, CAN-FD data bitrate, termination, and link state. A development-only virtual interface can typically be configured on Linux with administrative privileges:

```bash
sudo modprobe vcan
sudo ip link add dev vcan0 type vcan
sudo ip link set up vcan0
```

Then use:

```text
industrial vehicle experience lab can interface socketcan vcan0 classic
industrial vehicle experience lab can open
```

## OBD-II services

### Mode 01 live PIDs

The virtual ECU implements and the client decodes the following Mode 01 PIDs:

| PID | Value |
|---:|---|
| `04` | Calculated engine load |
| `05` | Coolant temperature |
| `0B` | Intake manifold absolute pressure |
| `0C` | Engine speed |
| `0D` | Vehicle speed |
| `0F` | Intake-air temperature |
| `10` | Mass-air flow |
| `11` | Throttle position |
| `2F` | Fuel level |
| `33` | Barometric pressure |
| `3C` | Catalyst temperature |
| `42` | Control-module voltage |
| `44` | Commanded equivalence ratio |
| `46` | Ambient-air temperature |
| `49` | Accelerator-pedal position |
| `5E` | Engine fuel rate |
| `61` | Driver-demand torque percentage |
| `62` | Actual engine torque percentage |
| `63` | Engine reference torque |

Supported-PID discovery follows the normal `00`, `20`, `40`, and `60` continuation blocks.

Examples:

```text
industrial vehicle experience lab obd pid 05
industrial vehicle experience lab obd pid 0C 500
industrial vehicle experience lab obd pid 5E
industrial vehicle experience lab obd scan
```

### Generic OBD requests

The generic request command accepts a payload in hexadecimal and returns assembled ECU responses:

```text
industrial vehicle experience lab obd request 01 0C
industrial vehicle experience lab obd request 09 02
industrial vehicle experience lab obd request 06 00
```

This allows read-oriented experimentation beyond the convenience commands without exposing arbitrary raw CAN writes.

### Diagnostic trouble codes

```text
industrial vehicle experience lab obd dtc
industrial vehicle experience lab obd clear-dtc
```

DTC clearing requires `diagnostic-write` or `raw-allowlist` access:

```text
industrial vehicle experience lab can access diagnostic-write 20
industrial vehicle experience lab obd clear-dtc
```

The virtual ECU supports current, pending, and permanent DTC service families and uses standard P/C/B/U code encoding. A clean-to-confirmed-fault transition captures one immutable Mode 02 snapshot. Clearing the authoritative confirmed-DTC list resets the snapshot, allowing the next independent episode to capture fresh operating data. OBD Mode 04 and UDS service `14` clear the same authoritative store.

### Vehicle information and monitor data

```text
industrial vehicle experience lab obd vin
industrial vehicle experience lab obd request 09 04
industrial vehicle experience lab obd request 09 0A
industrial vehicle experience lab obd request 06 00
```

The virtual ECU supplies a VIN, calibration identifier, ECU name, and deterministic Mode 06 monitor data.

## Raw CAN access

Raw transmit is deliberately more restrictive than diagnostic traffic:

```text
industrial vehicle experience lab can access raw-allowlist 10
industrial vehicle experience lab can allow 7DF
industrial vehicle experience lab can send 7DF 02 01 0C 00 00 00 00 00
```

Clear the allowlist with:

```text
industrial vehicle experience lab can allow-clear
```

Identifiers accept common hexadecimal forms such as `7DF` and `0x7DF`.

## Capture, import, and export

Capture is maintained for transmitted and received frames. It can be cleared, imported from candump text, and exported in several forms:

```text
industrial vehicle experience lab can capture clear
industrial vehicle experience lab can capture import trace.log
industrial vehicle experience lab can capture export-candump output.log can0
industrial vehicle experience lab can capture export-csv output.csv
```

The candump parser supports standard timestamped records and preserves identifiers, extended-frame state, FD state, payloads, and timestamps where represented.

## Trace intelligence

The analyzer calculates per-identifier and whole-trace properties:

- Frame count and total duration.
- Mean period and estimated frequency.
- Timing jitter.
- Byte entropy.
- Bit-flip fraction.
- Candidate rolling-counter byte.
- Candidate SAE J1850 CRC byte.
- Estimated classical CAN bus load.
- Human-readable observations.

Commands:

```text
industrial vehicle experience lab can capture analyze
industrial vehicle experience lab can capture export-analysis trace_analysis.json
```

Counter and CRC findings are hypotheses derived from observed traffic; they are intended to focus reverse-engineering effort, not to claim a definitive proprietary signal definition.

## Derived OBD engineering features

After reading relevant PIDs, the gateway can synthesize higher-level values:

```text
industrial vehicle experience lab obd derived
```

Derived features include:

- Estimated fuel rate.
- Instantaneous fuel consumption in L/100 km when vehicle speed is valid.
- Estimated engine torque.
- Estimated engine power.
- Thermal-stress index.
- Catalyst light-off margin.
- Low-voltage health indicator.
- Commanded equivalence ratio.

The derivations retain their assumptions and should be calibrated against measured vehicle data before they are used for formal engineering conclusions.

## Synthetic multi-ECU datasets

Generate a coherent dataset with:

```text
industrial vehicle experience lab synthesis generate \
  60 10 12345 urban none 0.7 50 0.0
```

Arguments are:

```text
generate <duration_s> <step_ms> <seed> <cycle> [fault] [severity] [jitter_us] [dropout_probability]
```

Supported cycles:

- `urban`
- `highway`
- `aggressive`
- `cold_start`

Generated traffic contains correlated engine, chassis, body, battery, and diagnostic states. The same underlying trajectory drives all messages and the labelled signal table.

### Fault-labelled synthesis

Supported injected labels include:

- `wheel_speed_dropout`
- `coolant_bias`
- `injector_restriction`
- `weak_battery`
- `can_dropout`
- `counter_freeze`
- `bus_off_burst`
- `throttle_stuck`
- `crc_corruption`

Example:

```text
industrial vehicle experience lab synthesis generate \
  120 10 4512 aggressive injector_restriction 0.8 80 0.002
```

Fault intervals are explicitly represented in the ground-truth signal export, enabling supervised anomaly-detection and diagnostic-coverage experiments.

### Counterfactual augmentation

Captured traffic can be transformed without changing the source trace:

```text
industrial vehicle experience lab synthesis augment replay 0.6 9001
industrial vehicle experience lab synthesis augment bitflip 0.15 9002
industrial vehicle experience lab synthesis augment time_warp 0.4 9003
```

Available transformations:

- `jitter`
- `dropout`
- `replay`
- `bitflip`
- `counter_freeze`
- `id_spoof`
- `time_warp`

Every augmentation is deterministic for a given source trace, transformation, severity, and seed.

## Export formats

```text
industrial vehicle experience lab synthesis export csv signals.csv
industrial vehicle experience lab synthesis export candump traffic.log vcan0
industrial vehicle experience lab synthesis export jsonl dataset.jsonl
industrial vehicle experience lab synthesis export dbc generated.dbc
```

### CSV

Contains engineering ground truth such as speed, RPM, throttle, brake, coolant temperature, fuel rate, battery voltage/SOC, yaw rate, steering, gear, and fault label.

### candump

Suitable for replay, inspection, and interoperability with common SocketCAN tooling.

### JSONL

Stores one machine-readable frame per line with timestamp, identifier, frame flags, data, and associated labels.

### DBC

Provides signal definitions for the generated message set, including the optional CAN-FD high-voltage battery message.

## Shared ISO-TP and Linux kernel backend

The gateway and responder use the shared ISO-TP endpoint for classical CAN, CAN-FD escape-length single frames, 12-bit and 32-bit first frames, sequence rollover and rejection, block-size and STmin flow control, normal and extended addressing, padding, BRS, bounded reassembly, and timeouts. Linux builds also provide `KernelIsoTpTransport` over `PF_CAN`, `SOCK_DGRAM`, and `CAN_ISOTP`. Kernel API integration is compile-tested; a configured `vcan` or physical CAN interface is required for live transport qualification.

## Measured-data validation

```text
validation measured data/measured_validation_example.csv time_s measured_torque_nm simulated_torque_nm weight reports/measured_validation.json reports/measured_residuals.csv
```

The pipeline performs quoted CSV parsing, column selection, validation and sorting, optional weighting and outlier handling, agreement metrics, affine identification, robust nonlinear fitting through the C++ API, JSON reporting, and residual export. Preserve path and column-name case.

## C++ API

Primary public types are declared in:

```text
include/aesim/industrial/can_obd.hpp
```

Core classes:

```cpp
aesim::industrial::CanObdGateway gateway;
gateway.use_loopback();
gateway.open();
gateway.set_policy({
    aesim::industrial::CanAccessMode::DiagnosticRead,
    50.0,
    {}
});

auto rpm = gateway.query_pid(0x01, 0x0C);
auto vin = gateway.read_vin();
auto features = gateway.derived_obd_features();
```

Synthetic generation:

```cpp
aesim::industrial::CanDataSynthesizer synthesizer;
aesim::industrial::CanSynthesisOptions options;
options.duration_s = 60.0;
options.sample_period_s = 0.01;
options.seed = 42;
options.drive_cycle = "urban";
options.fault = "weak_battery";
options.fault_severity = 0.7;

const auto& dataset = synthesizer.generate(options);
synthesizer.export_signal_csv("signals.csv");
synthesizer.export_dbc("generated.dbc");
```

## Validation scope

The automated qualification covers:

- Virtual Mode 01 PID encoding and decoding.
- Supported-PID discovery through PID `63`.
- Generic OBD request transport.
- VIN, DTC, Mode 06, and clearing behavior.
- Default transmit rejection and raw allowlist enforcement.
- Derived engineering features.
- Multi-ECU classical CAN and CAN-FD generation.
- Labelled fault intervals.
- CSV, candump, JSONL, and DBC export.
- Candump round-trip import.
- Counter and CRC candidate discovery.
- Counterfactual augmentation.
- Live simulator-to-virtual-ECU binding.
- End-to-end command execution through the existing TUI.

Physical communication with a specific commercial adapter or vehicle is environment-dependent and must be validated on the target host, interface, bitrate, gateway, and vehicle. The source qualification verifies the SocketCAN integration path at compile time and verifies protocol behavior through the loopback transport; it does not claim road-vehicle hardware certification.

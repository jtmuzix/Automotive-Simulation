# NASCAR Integrated Fidelity Platform

> **2026-07-28 additive assurance module:** The separate `nascar-assurance` command and `NascarEngineeringAssurancePlatform` add regulation digital-thread resolution, dynamic compliance, prospective-OEM management, timing observation fusion, officiating policy analysis, progressive contact damage, crash/SAFER elements, fire/rescue hazards, debris recovery, composite manufacturing, fleet reliability, and optimal test design. Existing contracts in this guide are unchanged. See `docs/NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 59 of the user manual.
**Revision:** 2026-07-27  
**Library:** `aesim_nascar`  
**Public header:** `include/aesim/advanced/nascar_integrated_fidelity_platform.hpp`  
**CLI family:** `muzixdiagsys_advanced_platform nascar-integrated`

## 1. Purpose and compatibility

The NASCAR Integrated Fidelity Platform is an additive high-fidelity NASCAR module for MuzixDiagSys. It does not replace the existing 40-domain `nascar` command, the competition, ecosystem, frontier, or next-generation APIs, or any cross-series subsystem. The new implementation is compiled into `aesim_nascar`, exported by `aesim/advanced/platform.hpp`, and linked transitively by `aesim_advanced`.

The module provides twelve executable domains:

1. deterministic integrated NASCAR co-simulation;
2. telemetry assimilation and calibration;
3. unified uncertainty quantification and model-validity supervision;
4. a 28-degree-of-freedom flexible multibody Next Gen vehicle;
5. detailed asymmetric tire construction and transient contact mechanics;
6. unsteady aeroelastic body, underfloor, wake, cooling, and flap dynamics;
7. closed-loop ECU, sequential transaxle, and limited-slip driveline control;
8. cranktrain torsion, dry-sump lubrication, fuel delivery, and thermal systems;
9. a multi-car pit-road discrete-event twin;
10. occupant biomechanics, heat strain, carbon-monoxide exposure, and egress;
11. pavement mechanics and aligned scanned-track reconstruction; and
12. particle-informed spray-plume and optical-visibility physics.

Every request is validated before state is advanced. Invalid dimensions, duplicate identifiers, non-finite arithmetic, backward time, impossible topology, unsupported gear transitions, non-positive covariance, unstable scheduler ratios, and physically invalid material or geometry inputs are rejected. Successful executions return canonical JSON with a versioned `schema`, a Boolean `passed` gate, structured findings, and a 64-character SHA-256 `evidence_digest`. Supplying a working directory also writes the domain report atomically under a stable filename.

## 2. Public API

```cpp
#include "aesim/advanced/nascar_integrated_fidelity_platform.hpp"

using aesim::advanced::nascarint::NascarIntegratedFidelityPlatform;
using aesim::doc::Value;

NascarIntegratedFidelityPlatform platform;
Value registry = platform.capabilities();
Value result = platform.execute(
    "tire-construction-contact",
    request,
    "evidence/nascar-integrated");
Value qualification = platform.self_test("evidence/nascar-integrated/self-test");
```

| Runtime domain | Public class | Entry point |
|---|---|---|
| `integrated-cosimulation` | `NascarIntegratedCoSimulationRuntime` | `run()` |
| `telemetry-assimilation` | `NascarTelemetryAssimilationCalibration` | `assimilate()` |
| `uncertainty-validity` | `NascarUnifiedUncertaintyModelValidityFramework` | `evaluate()` |
| `flexible-multibody` | `NascarFlexibleMultibodyVehicle` | `simulate()` |
| `tire-construction-contact` | `NascarDetailedTireConstructionContactModel` | `evaluate()` |
| `aeroelastic-wake` | `NascarUnsteadyAeroelasticWakeModel` | `simulate()` |
| `ecu-driveline-control` | `NascarClosedLoopEcuDrivelineController` | `simulate()` |
| `cranktrain-lubrication-fuel-thermal` | `NascarCranktrainLubricationFuelThermalTwin` | `simulate()` |
| `pit-road-twin` | `NascarPitRoadDiscreteEventTwin` | `simulate()` |
| `occupant-heat-egress` | `NascarOccupantBiomechanicsHeatEgress` | `evaluate()` |
| `pavement-scanned-track` | `NascarPavementMechanicsScannedTrackTwin` | `evaluate()` |
| `spray-optical-visibility` | `NascarSprayPlumeOpticalVisibilityPhysics` | `simulate()` |

The aggregate API is:

```cpp
[[nodiscard]] aesim::doc::Value capabilities() const;
[[nodiscard]] aesim::doc::Value execute(
    const std::string& domain,
    const aesim::doc::Value& request,
    const std::string& working_directory = {}) const;
[[nodiscard]] aesim::doc::Value self_test(
    const std::string& working_directory = {}) const;
```

## 3. Focused build, tests, and sanitizers

Configure and build the focused NASCAR graph:

```bash
cmake -S . -B build/nascar-integrated -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF

cmake --build build/nascar-integrated --parallel --target \
  aesim_nascar \
  nascar_integrated_fidelity_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/nascar-integrated --output-on-failure \
  -R '^nascar_integrated_fidelity_(platform_unit_tests|source_regression)$'
```

Direct source regression:

```bash
python3 tests/nascar_integrated_fidelity_source_regression.py .
```

Clang/ASan/UBSan qualification:

```bash
cmake -S . -B build/nascar-integrated-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/nascar-integrated-sanitize --parallel --target \
  nascar_integrated_fidelity_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --test-dir build/nascar-integrated-sanitize --output-on-failure \
  -R '^nascar_integrated_fidelity_platform_unit_tests$'
```

## 4. Command-line operation

List the twelve domains:

```bash
./build/nascar-integrated/muzixdiagsys_advanced_platform \
  nascar-integrated capabilities \
  build/nascar-integrated/capabilities.json
```

Execute all twelve deterministic self-tests:

```bash
./build/nascar-integrated/muzixdiagsys_advanced_platform \
  nascar-integrated self-test \
  build/nascar-integrated/evidence \
  build/nascar-integrated/self-test.json
```

Execute one domain:

```bash
./build/nascar-integrated/muzixdiagsys_advanced_platform \
  nascar-integrated tire-construction-contact \
  examples/nascar_integrated_fidelity/tire_construction_contact.json \
  build/nascar-integrated/tire-result.json \
  build/nascar-integrated/evidence
```

A valid request that fails a physical, safety, or validity gate writes its complete evidence and returns CLI exit code `2`. Malformed input or an execution exception returns `1`. Invalid top-level CLI syntax returns `64`.

## 5. Integrated NASCAR co-simulation runtime

`NascarIntegratedCoSimulationRuntime` advances controller, driveline, flexible-vehicle, tire, aerodynamic, thermal, pavement/wetness, spray, and driver-heat states on one authoritative integer-tick clock.

### 5.1 Deterministic multi-rate scheduling

The configuration declares:

- `base_step_s`;
- `controller_step_s`;
- `vehicle_step_s`;
- `tire_step_s`;
- `aero_step_s`;
- `thermal_step_s`;
- `pavement_step_s`;
- `spray_step_s`;
- `output_step_s`; and
- `duration_s`.

Every subsystem interval must be an exact integer multiple of the base step. The runtime converts each rate to integer ticks, rejects non-integral ratios and excessive tick counts, and records exact scheduler invocation counts. This prevents long-race floating-point clock drift and makes replay deterministic.

### 5.2 Coupled state

The runtime couples:

- speed, position, heading, lateral velocity, yaw, roll, pitch, and flexible chassis states;
- engine torque, gear, driveline twist, wheel torque, fuel consumption, and limiter state;
- four tire temperatures, pressures, wear states, and friction capacity;
- unsteady drag, downforce, front balance, wake deficit, and structural body-mode response;
- coolant, oil, fuel, tire, and driver thermal states;
- pavement water depth and friction;
- spray attenuation and driver visibility; and
- driver heat strain and cognitive capacity.

Aerodynamic load changes the available tire normal load. Tire friction and wetness limit force delivery. Wake affects drag, downforce, cooling, and spray exposure. Driveline torsion determines delivered wheel torque. Thermal and fuel states feed controller protection and endurance evidence.

### 5.3 Numerical and evidence behavior

The runtime uses bounded force capacity, semi-implicit mechanical updates, exact first-order thermal relaxation where appropriate, rate-limited controls, and finite-state validation at every output checkpoint. The report includes scheduler counts, complete history, energy accounting, `normalized_energy_residual`, coupling residual, extrema, findings, and deterministic evidence.

A request can set limits for energy residual, coupling residual, temperature, tire utilization, and visibility. Exceeding a gate does not discard state; it produces a completed negative assessment with traceable findings.

## 6. Telemetry assimilation and calibration

`NascarTelemetryAssimilationCalibration` estimates hidden vehicle states and identifies uncertain parameters from asynchronous channels.

### 6.1 State estimator

The request defines unique state names, initial state, symmetric covariance, nonnegative process noise, optional continuous dynamics, and time-ordered scalar measurements. Each measurement carries a sensitivity vector, value, variance, optional bias, and optional normalized-innovation-squared gate.

The implementation performs deterministic linearized propagation and gated measurement updates. Posterior covariance uses the Joseph form to preserve symmetry and numerical robustness. Rejected outliers remain in the evidence log with innovation, innovation variance, and NIS; they are not silently removed.

### 6.2 Calibration

Weighted calibration samples supply feature vectors, targets, and positive weights. The solver forms the regularized normal equations, applies configurable ridge stabilization, solves with pivoted elimination, and reports coefficients, fitted values, residuals, weighted RMSE, conditioning evidence, and parameter covariance estimates.

This domain is suitable for calibrating drag, downforce, rolling resistance, tire stiffness, damping, road-load, and loss parameters after the user provides an identifiable model and qualified telemetry covariance.

## 7. Unified uncertainty and model validity

`NascarUnifiedUncertaintyModelValidityFramework` separates uncertain inputs from the question of whether the selected model remains valid.

### 7.1 Uncertainty propagation

The implementation supports bounded normal and uniform marginals. A user-supplied correlation matrix is checked for dimensions, symmetry, unit diagonal, valid coefficients, and positive definiteness. Cholesky transformation maps deterministic Halton low-discrepancy samples to correlated variables.

A quadratic response surface supplies intercept, linear coefficients, and a full quadratic coefficient matrix. The report includes mean, standard deviation, quantiles, exceedance probability, sample extrema, and ranked sensitivity contributions. Deterministic sampling ensures identical canonical input produces identical evidence.

### 7.2 Validity supervision

Validity metrics can cover calibration distance, residual bias/correlation, conservation drift, numerical error, model disagreement, sensor innovation, extrapolation, thermal margins, and other user-defined normalized criteria. Each metric declares an allowed absolute value. The framework reports `in_validity_domain`, failed criteria, confidence, and explicit mitigation actions.

A result outside the validity domain is not represented as unconditionally predictive. The caller must increase fidelity, refine the numerical resolution, acquire data, recalibrate, reject a surrogate, or restrict the operating envelope.

## 8. Flexible 28-DOF Next Gen multibody vehicle

`NascarFlexibleMultibodyVehicle` resolves a complete transient vehicle state rather than applying only static load-transfer equations.

The 28 generalized coordinates include:

- six chassis rigid-body coordinates;
- four unsprung vertical coordinates;
- four wheel-spin coordinates;
- suspension and steering-related transient states; and
- flexible chassis torsion, front-clip, and rear-clip modes with associated velocities.

The model includes mass and inertia, wheelbase and tracks, CG position, motion ratios, wheel rates, dampers, anti-roll coupling, bump stops, tire loads, banking, road-height excitation, distributed aero forces, steering, drive torque, brake effects, and structural mode coupling. Static preload is established before transient advancement so the car does not numerically fall through its equilibrium ride state.

Outputs include all generalized coordinates and rates, per-corner suspension deflection, wheel load, wheel speed, body attitude, flexible-mode response, kinetic/potential/dissipated energy, normalized mechanical-energy residual, bottoming events, wheel-load loss, and structural-envelope findings.

## 9. Detailed tire construction and transient contact

`NascarDetailedTireConstructionContactModel` distinguishes left-front, right-front, left-rear, and right-rear construction. This supports oval-specific asymmetric stiffness, pressure, loading, and durability behavior.

### 9.1 Contact mechanics

The model computes:

- load-sensitive longitudinal and lateral stiffness;
- transient slip-ratio and slip-angle relaxation;
- camber thrust;
- combined-slip force saturation;
- pneumatic trail and aligning moment;
- overturning moment and rolling resistance;
- contact-patch area and carcass deflection; and
- hydroplaning and water-depth derating.

### 9.2 Thermal, pressure, wear, and construction states

Four thermal states represent tread, shoulder, carcass, and contained gas. Slip work, hysteresis, rolling loss, conduction, and convection determine temperature evolution. Gas temperature drives inflation-pressure growth.

Construction evidence includes belt stress, sidewall strain, standing-wave index, accumulated slip energy, wear, flat-spot growth, minimum structural margin, and `belt_fatigue_damage`. The model emits findings for saturation, pressure, temperature, hydroplaning, fatigue, and structural-limit violations.

## 10. Unsteady aeroelastic body and wake model

`NascarUnsteadyAeroelasticWakeModel` combines a reduced unsteady flow model with flexible body modes and active safety-device dynamics.

It resolves:

- underfloor and diffuser load with separation/reattachment hysteresis;
- ride-height, pitch, roll, yaw, steering, and wall-proximity effects;
- multiple upstream wake sources with longitudinal and lateral offset;
- convecting velocity deficit and turbulence intensity;
- following-car cooling-flow reduction;
- flexible splitter, hood/body, deck/rear, and undertray modal response;
- two-way modal feedback into drag, downforce, and front balance; and
- roof-flap and A-post-flap deployment angle, rate, delay, damping, and aerodynamic moment.

The report provides coefficient and force histories, wake state, cooling factor, mode coordinates, flap states, underfloor separation, front-balance migration, peak deflection, and safety findings. The model rejects invalid modes, duplicate identifiers, nonpositive modal properties, negative geometry, and unordered samples.

## 11. Closed-loop ECU and driveline control

`NascarClosedLoopEcuDrivelineController` executes control laws against measured engine, wheel, and vehicle states.

The controller includes:

- driver torque-demand interpretation;
- PI torque tracking with bounded integral state;
- throttle actuator dynamics;
- engine-speed torque shaping;
- rev and pit-road speed limiting;
- legal adjacent-only sequential shifts;
- predicted over-rev rejection;
- shift torque interruption;
- five-speed ratio and final-drive kinematics;
- flexible shaft torsion and damping;
- limited-slip differential preload and speed-sensitive locking;
- axle torque split;
- front/rear brake-bias reporting; and
- fuel use from delivered engine power.

The implementation intentionally rejects a skipped sequential gear rather than converting it into a completed shift. History retains requested/delivered torque, throttle, gear, shift and limiter state, shaft twist/torque, wheel torque split, brake torque, and cumulative fuel.

## 12. Cranktrain, lubrication, fuel, and thermal twin

`NascarCranktrainLubricationFuelThermalTwin` advances tightly coupled V8 support systems.

### 12.1 Cranktrain torsion

A two-inertia crank/flywheel system includes shaft stiffness and torsional-damper damping. Indicated and load torque excite relative twist and speed. The report tracks peak crank twist, torque, speed difference, and fatigue-driving stress amplitude.

### 12.2 Dry-sump lubrication

The oil model includes viscosity-temperature behavior, pump flow, leakage, gallery pressure, aeration/de-aeration, scavenge effectiveness, bearing load, Sommerfeld behavior, minimum film thickness, combined roughness, and `bearing_film_ratio`. Findings distinguish low pressure, excess aeration, and inadequate hydrodynamic separation.

### 12.3 Fuel delivery

Fuel-cell mass, lateral and longitudinal acceleration, collector transfer, pickup exposure, pump pressure, demand, and delivered flow determine starvation and pressure margin. The mass balance never consumes fuel that was not delivered.

### 12.4 Thermal network and durability

Coolant, oil, cylinder-head, and fuel temperatures exchange heat with combustion, friction, airflow, and ambient conditions. The report includes heat flows, pressure margins, minimum film ratio, starvation duration, peak temperatures, torsional fatigue damage, and thermal-limit findings.

## 13. Multi-car pit-road discrete-event twin

`NascarPitRoadDiscreteEventTwin` schedules all supplied cars, boxes, tasks, resources, and releases on one event timeline.

The request defines pit boxes, car arrivals, teams, entry speeds, task dependency graphs, task resources and durations, pit-road speed limit, traffic observations, and unsafe-release probability thresholds. The engine validates unique identifiers, known boxes, known dependencies, acyclic task graphs, finite duration, and chronological arrivals.

Resource availability, box occupancy, predecessor completion, and team overlap determine task start times. The model captures queueing, double stacking, over-wall service, fuel and tire resource contention, lane occupancy, speeding, release time, approaching-car uncertainty, release margin, and unsafe-release probability.

Outputs include a deterministic event trace, per-car wait/service/total time, task schedule, resource utilization, queue metrics, speeding evidence, double-stack periods, and release findings.

## 14. Occupant biomechanics, heat strain, and egress

`NascarOccupantBiomechanicsHeatEgress` combines crash-pulse screening with cockpit environmental exposure and escape operations.

### 14.1 Crash response

The lumped occupant system resolves head/helmet, thorax, and pelvis motion against a time-ordered crash pulse. Harness, seat, head-and-neck restraint, and cockpit contacts use stiffness/damping force laws. Metrics include HIC15, normalized neck injury criterion, chest acceleration/compression, femur load, harness load, tether load, head excursion, and contact events.

### 14.2 Thermal and toxic exposure

Cabin air temperature, mean radiant temperature, humidity, air speed, clothing/metabolic terms, cooling power, and exposure duration determine body heat storage, sweat loss, dehydration, core-temperature rise, `heat_strain_index`, cognitive-capacity factor, and carbon-monoxide dose.

### 14.3 Egress

Egress time includes restraint release, window-net release, steering-wheel removal, driver strength, injury impairment, smoke, inversion, self-egress, and assisted extraction. The report separates biomechanical thresholds, heat/toxic exposure, and egress margin so a nominal crash result cannot mask an unacceptable thermal or escape condition.

These outputs are engineering screening evidence. Safety-critical interpretation requires validated occupant geometry, restraint properties, crash pulses, thermal measurements, and qualified medical/biomechanical review.

## 15. Pavement mechanics and scanned-track twin

`NascarPavementMechanicsScannedTrackTwin` converts ordered point observations into a mechanically useful local track profile.

The request can provide station, elevation, bank, cross slope, roughness, friction, material, joint severity, water depth, temperature, wheel load, and speed. Alignment pairs estimate scan-to-reference station offset and RMSE. The model derives grade, curvature, bank transition, roughness excitation, joint impulse, tire-envelope filtered elevation, wheel-load variation, water evolution, wet friction, rutting increment, and accumulated pavement fatigue.

The result reports aligned geometry, interpolation history, International Roughness Index-like evidence, maximum grade/curvature/bank rate, friction range, water range, wheel-load excitation, rut depth, fatigue damage, alignment quality, and findings for scan quality, roughness, standing water, friction, or structural deterioration.

## 16. Spray plume and optical visibility physics

`NascarSprayPlumeOpticalVisibilityPhysics` treats spray as a spatial field generated by every supplied car and observed from one or more driver/camera locations.

For each source car, the model calculates water displacement from tire width, speed, and water depth; droplet Weber and Reynolds behavior; representative droplet diameter; plume spread, advection, settling, and decay; and local liquid-water content. Contributions from multiple cars superpose at each observer.

Optical extinction is derived from droplet concentration and optical path length. The report includes meteorological visibility, target contrast, screen/visor contamination, light transmission, and `brake_light_detection_probability`. Crosswind, ambient humidity, spray-source geometry, observer height, target distance, and cleanup/evaporation rates are explicit inputs.

A completed report identifies observers below the configured raceable-visibility or brake-light-detection thresholds. Invalid geometry, negative water, nonpositive optics, duplicate identifiers, or backward samples are rejected.

## 17. Canonical examples

The directory `examples/nascar_integrated_fidelity/` contains one executable request per domain:

```text
integrated_cosimulation.json
telemetry_assimilation.json
uncertainty_validity.json
flexible_multibody.json
tire_construction_contact.json
aeroelastic_wake.json
ecu_driveline_control.json
cranktrain_lubrication_fuel_thermal.json
pit_road_twin.json
occupant_heat_egress.json
pavement_scanned_track.json
spray_optical_visibility.json
```

Run all examples:

```bash
set -euo pipefail
for item in \
  integrated-cosimulation:integrated_cosimulation \
  telemetry-assimilation:telemetry_assimilation \
  uncertainty-validity:uncertainty_validity \
  flexible-multibody:flexible_multibody \
  tire-construction-contact:tire_construction_contact \
  aeroelastic-wake:aeroelastic_wake \
  ecu-driveline-control:ecu_driveline_control \
  cranktrain-lubrication-fuel-thermal:cranktrain_lubrication_fuel_thermal \
  pit-road-twin:pit_road_twin \
  occupant-heat-egress:occupant_heat_egress \
  pavement-scanned-track:pavement_scanned_track \
  spray-optical-visibility:spray_optical_visibility
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/nascar-integrated/muzixdiagsys_advanced_platform \
    nascar-integrated "$domain" \
    "examples/nascar_integrated_fidelity/${stem}.json" \
    "build/nascar-integrated/${stem}.result.json" \
    build/nascar-integrated/evidence
done
```

## 18. Recommended engineering workflow

1. Establish the authoritative rates and verify scheduler counts, conservation, and deterministic replay with `integrated-cosimulation`.
2. Assimilate measured channels and inspect innovations, rejected observations, covariance, residuals, and parameter conditioning with `telemetry-assimilation`.
3. Define distributions and correlations, then use `uncertainty-validity` to establish the allowed operating envelope before reporting predictions.
4. Calibrate mass, inertia, suspension, structural modes, and road input in `flexible-multibody`.
5. Calibrate left/right tire construction, transient force, thermal, pressure, wear, and fatigue behavior with `tire-construction-contact`.
6. Fit wake, underfloor, flexible body, cooling, roof-flap, and A-post-flap behavior with `aeroelastic-wake`.
7. Run `ecu-driveline-control` against measured gear, engine, wheel-speed, and pit-road cases; audit every limiter, rejected shift, and saturation.
8. Correlate oil pressure/temperature, bearing film, fuel pressure, starvation, crank torsion, and heat rejection using `cranktrain-lubrication-fuel-thermal`.
9. Use `pavement-scanned-track` to create the local geometry and wet-friction input consumed by the vehicle and tire studies.
10. Use `spray-optical-visibility` for multi-car wet scenarios and preserve observer-specific visibility evidence.
11. Connect race traffic to `pit-road-twin`; validate queue, double-stack, speeding, and release uncertainty instead of relying on a fixed pit-loss scalar.
12. Use `occupant-heat-egress` only with validated pulse, restraint, thermal, and egress data; retain clear separation between engineering screening and medical conclusions.
13. Re-run unit, CLI, deterministic replay, sanitizer, strict-warning, documentation, and package-integrity regressions before release.

## 19. Qualification boundary

The twelve domains are complete executable implementations, not automatic homologation, medical certification, or proof of regulatory compliance. Quantitative use requires car-specific geometry, inertias, tire construction data, aerodynamic maps, controller calibrations, engine/oil/fuel measurements, pit-road geometry and traffic uncertainty, occupant/restraint data, scanned pavement, optical measurements, convergence studies, uncertainty budgets, and independent validation over the intended operating envelope.

Any result outside its declared model-validity envelope must be treated as exploratory. The evidence digest proves canonical report integrity within this software workflow; it does not prove the physical correctness of unvalidated input data or models.

## Motorsport CLI convenience aliases

The original `nascar-integrated` family remains authoritative. `nascar run integrated DOMAIN ...` provides suite routing; `nascar-telemetry` directly targets `telemetry-assimilation`. See `MOTORSPORT_CLI_COMMANDS.md`.

# MuzixDiagSys Engineering Platform

## Scope

The engineering platform extends the existing authenticated simulator without replacing its vehicle, diagnostics, project, network, checkpoint, FMI, OpenX, plugin, or terminal subsystems. The added C++ library is `aesim_engineering`; the authenticated command surface is `muzixdiagsys_engineering`; and the Python package in `python/muzixdiag` invokes the same executable and therefore uses the same authentication, role checks, and audit log.

All state-changing engineering commands require an authenticated account. Credential files contain the username on line 1 and password on line 2. On POSIX systems they must be regular files owned by the current user with no group or world permissions.

```bash
printf '%s\n%s\n' jtmuzix 'T1k1@420' > credentials.txt
chmod 600 credentials.txt

./muzixdiagsys_engineering \
  --credential-file credentials.txt \
  roles catalog
```

The bootstrap password should be changed after first deployment.

When `MUZIXDIAGSYS_USER_DB` or `--database` selects a custom path, MuzixDiagSys secures a newly created authentication directory but does not modify an existing parent directory's permissions. Administrators remain responsible for the ownership and ACLs of an existing shared or mounted parent. Database replacement uses the owner-private atomic-write path with exclusive staging files and flush-before-rename commit. Ordinary simulator exports retain process-default creation permissions, while generic replacement preserves existing POSIX file permissions.

## 1. Role-based access control

Authorization is expressed as named permissions. A role contributes exact permissions or namespace wildcards such as `workspace.*`. The administrator role contributes `*`. Role names are normalized to lowercase and underscores are accepted as hyphens.

Built-in roles:

| Role | Purpose | Principal permissions |
|---|---|---|
| `administrator` | Unrestricted platform administration | `*` |
| `user-manager` | Account and role administration | `users.read`, `users.create`, `users.modify`, `users.reset-password`, `roles.assign` |
| `simulation-engineer` | Configure and execute engineering work | workspace, scenario, campaign, simulation, fault, replay, standards, telemetry, reporting, diagnostics, units, drivers, sensors, and learning permissions |
| `operator` | Run approved simulations | read/run/stop permissions, telemetry/result access, safe driver/sensor/unit/learning tools |
| `analyst` | Analyze and report results | results, reports, diagnostic plans, telemetry, and unit conversion |
| `auditor` | Inspect security and provenance evidence | audit read/verify, manifest verification, and read-only workspace/result access |
| `learner` | Use training and safe demonstrations | learning, read-only workspace/scenario, simulation run, results, units, drivers, and sensors |

Examples:

```bash
./muzixdiagsys_engineering --credential-file credentials.txt roles catalog
./muzixdiagsys_engineering --credential-file credentials.txt \
  roles assign technician simulation-engineer analyst
```

The original `user create ... --can-create-users` command and `can_create_users` database field remain compatible. Existing databases are migrated to role-aware records. New users remain non-administrative by default.

## 2. Tamper-evident audit logging

Every engineering command records actor, session, action, target, outcome, detail, sequence, timestamp, previous hash, and entry hash. The entry hash is computed from canonical JSON and the preceding hash, creating an ordered SHA-256 chain.

The logger also maintains an owner-only head seal beside the log. Verification checks:

1. contiguous sequence numbers;
2. each entry's `previous_hash`;
3. recomputation of every entry hash;
4. agreement between the final entry and the head seal.

A filesystem lock serializes writers across processes. The lock directory is owner-only on POSIX systems. The logger refuses to append when verification fails, preventing a corrupted history from being silently extended.

```bash
./muzixdiagsys_engineering --credential-file credentials.txt audit verify
./muzixdiagsys_engineering --credential-file credentials.txt audit read 50
```

The audit path is derived from the authentication database. Legacy chained logs without a head seal are verified and sealed on the next successful append.

## 3. Workspaces and reproducibility manifests

A workspace is a persistent engineering boundary containing:

- identity, name, description, owner, and timestamps;
- member roles: `owner`, `editor`, `runner`, or `viewer`;
- copied resources with role and SHA-256 integrity metadata;
- settings;
- saved run-manifest references.

```bash
ROOT=$PWD/workspaces
ENGINEERING='./muzixdiagsys_engineering --credential-file credentials.txt'

$ENGINEERING workspace create "$ROOT" BrakeStudy 'Low-mu braking campaign'
$ENGINEERING workspace list "$ROOT"
$ENGINEERING workspace member "$ROOT" <workspace-id> analyst viewer
$ENGINEERING workspace add "$ROOT" <workspace-id> scenario.json scenario
$ENGINEERING workspace manifest "$ROOT" <workspace-id> 420 manifest.json
```

A reproducibility manifest records the run ID, workspace, actor, timestamp, executable path and digest, source revision, compiler, platform, compute backend, random seed, input digests, configuration, environment, and metrics. The manifest is sealed with a digest calculated from canonical content and can be verified independently.

## 4. Scenario composer

`ScenarioComposer` emits validated `aesim.scenario` 2.0 documents with SI-safe boundary conversion. It supports:

- duration, fixed step, and deterministic seed;
- environment and vehicle properties with explicit units;
- timed actions and optional conditions;
- `set`, `ramp`, command, checkpoint, branch, fault, and other actions consumed by the existing scenario runtime;
- temporal assertions with mode and severity.

A minimal specification accepted by `scenario build` is:

```json
{
  "name": "icy-braking",
  "duration_s": 30.0,
  "step_s": 0.01,
  "seed": 420,
  "environment": {
    "ambient_temperature": {"value": -15.0, "unit": "degC"},
    "road_friction": {"value": 0.28, "unit": "1"}
  },
  "vehicle": {
    "payload": {"value": 450.0, "unit": "kg"},
    "initial_speed": {"value": 80.0, "unit": "km/h"}
  },
  "events": [
    {
      "time_s": 2.0,
      "action": "set",
      "target": "driver.brake",
      "parameters": {"value": 1.0, "unit": "1"}
    },
    {
      "time_s": 10.0,
      "action": "checkpoint",
      "target": "post-brake",
      "parameters": {}
    }
  ],
  "assertions": [
    {
      "expression": "vehicle.speed_m_s >= 0",
      "message": "speed remains physically valid",
      "mode": "always",
      "severity": "abort"
    }
  ]
}
```

```bash
$ENGINEERING scenario build icy_braking_spec.json icy_braking.scenario.json
```

## 5. Batch campaign manager

Campaigns expand a Cartesian product of unit-aware parameters. Each run receives a deterministic derived seed and records SI parameters, metrics, success/failure, elapsed time, and worker provenance. The local scheduler uses bounded worker threads. The configured compute backend is resolved through the simulator's existing heterogeneous compute factory; preprocessing metrics expose the selected backend and processed parameter data.

```json
{
  "name": "thermal-friction-sweep",
  "seed": 420,
  "workers": 4,
  "compute_backend": "auto",
  "remote_fallback_local": true,
  "remote_timeout_ms": 30000,
  "scenario": {"schema": "aesim.scenario", "version": "2.0.0"},
  "parameters": [
    {"name": "mass_kg", "unit": "kg", "values": [1200, 1600, 2200]},
    {"name": "speed_m_s", "unit": "km/h", "values": [50, 80, 110]},
    {"name": "road_mu", "unit": "1", "values": [0.3, 0.7, 1.0]},
    {"name": "ambient_temperature_k", "unit": "degC", "values": [-20, 20, 45]}
  ]
}
```

```bash
$ENGINEERING campaign execute campaign.json campaign-result.json
```

Expansion is capped at one million runs by default to prevent accidental combinatorial exhaustion.

## 6. Distributed campaigns and acceleration

A campaign worker uses canonical newline-delimited JSON over TCP. Requests include run index, seed, and SI parameter values. Responses include metrics, elapsed time, success state, error text, and worker identity. Client and server sockets use bounded I/O timeouts.

Start workers on separate trusted hosts:

```bash
$ENGINEERING worker serve 46001 3600
$ENGINEERING worker serve 46002 3600
```

Add workers to a campaign:

```json
{
  "remote_workers": [
    {"host": "10.0.0.21", "port": 46001},
    {"host": "10.0.0.22", "port": 46002}
  ],
  "remote_fallback_local": true
}
```

Runs are assigned round-robin. A failed remote execution is recorded; when fallback is enabled, the same deterministic run is evaluated locally. Backends supported by the existing compute registry remain available, including CPU and accelerator implementations compiled for the host. The campaign layer never assumes a GPU exists and retains a CPU fallback.

The worker protocol is intended for isolated engineering networks. Authentication occurs when launching the worker process; deploy transport encryption or an authenticated tunnel when traffic crosses an untrusted network.

## 7. Deterministic replay and checkpoints

`ReplayCoordinator` wraps the existing full-state checkpoint/replay implementation. It captures simulation state, scheduler state, random streams, branch lineage, and state digests. Recorded commands preserve before/after state and random-stream hashes. Replay verification compares deterministic hashes after each operation.

```bash
$ENGINEERING replay demo replay-output
$ENGINEERING replay verify replay-output/<file>.json
```

A replay mismatch returns a nonzero status and identifies the first divergent operation. Host wall-clock timing is not used as trajectory state.

## 8. Unified fault injection

The fault engine composes multiple scheduled faults on the same signal. Each definition has an ID, target, kind, active interval, severity, probability, auxiliary parameter, deterministic seed, and enabled state.

Supported kinds:

- bias, drift, Gaussian noise, scale, stuck, dropout, saturation, delay;
- open circuit, short to ground, short to supply;
- network drop and network delay.

Example definitions:

```json
[
  {
    "id": "wss-bias",
    "target": "sensor.wheel_speed.front_left",
    "kind": "bias",
    "start_time_s": 5.0,
    "end_time_s": 20.0,
    "severity": 2.5,
    "probability": 1.0,
    "seed": 1001
  },
  {
    "id": "can-delay",
    "target": "network.powertrain",
    "kind": "network-delay",
    "start_time_s": 10.0,
    "severity": 0.080,
    "probability": 0.25,
    "seed": 1002
  }
]
```

Input samples are JSON objects containing `target`, `time_s`, and `value`. Output samples retain validity, drop state, added latency, and all applied fault IDs.

```bash
$ENGINEERING fault apply faults.json samples.json fault-results.json
```

## 9. Telemetry interface

`TelemetryBroker` assigns monotonically increasing sequence numbers, stores bounded history, supports topic-prefix subscribers, and seals each frame with SHA-256. `TelemetryServer` publishes canonical JSONL frames over TCP.

Telemetry input JSONL:

```json
{"simulation_time_s":0.00,"topic":"vehicle/state","payload":{"speed_m_s":0.0}}
{"simulation_time_s":0.01,"topic":"vehicle/state","payload":{"speed_m_s":0.2}}
```

```bash
$ENGINEERING telemetry serve 47000 telemetry-input.jsonl 10 500
```

Consumers must verify the frame schema and digest. The Python API includes a streaming frame iterator that performs those checks.

## 10. Python API

Install the local package in an isolated environment:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install ./python
```

Example:

```python
from pathlib import Path
from muzixdiag import Client

client = Client(
    Path("credentials.txt"),
    database=Path("users.json"),
    executable=Path("build/muzixdiagsys_engineering"),
)

workspace = client.create_workspace("workspaces", "BrakeStudy")
scenario = client.build_scenario(
    {
        "name": "cold-stop",
        "duration_s": 20.0,
        "step_s": 0.01,
        "seed": 420,
        "environment": {
            "ambient_temperature": {"value": -20, "unit": "degC"}
        },
        "events": []
    },
    "cold-stop.json",
)
result = client.execute_campaign(
    {
        "name": "mass-sweep",
        "seed": 420,
        "parameters": [
            {"name": "mass_kg", "unit": "kg", "values": [1200, 1600, 2000]}
        ]
    },
    "mass-sweep-results.json",
)
```

The Python API is a typed process client rather than an authorization bypass. It validates credential-file ownership/mode and invokes the audited C++ command surface.

## 11. Diagnostic test-plan generation

The diagnostic planner ranks tests by expected information gain while penalizing estimated time and cost. Tests include required permission, instructions, safety classification, and likelihood under each candidate cause. Cause priors are normalized before planning.

```bash
$ENGINEERING diagnostics plan plan.json crank_no_start \
  battery=0.35 starter=0.30 crank_sensor=0.20 fuel=0.15
```

The output includes ordered tests, rationale, information gain, cumulative time, and cumulative cost in both JSON and Markdown forms.

## 12. Run comparison and reporting

The comparator recursively traverses result trees. It records structural differences and numeric deltas, using configurable absolute and relative tolerances. Report generation writes:

- canonical JSON evidence;
- Markdown engineering summary;
- standalone HTML report;
- JUnit XML suitable for CI.

```bash
$ENGINEERING compare baseline.json candidate.json reports/brake-change 1e-8 1e-5
```

Exit code 0 indicates equivalence within tolerance; exit code 1 indicates significant or structural differences.

## 13. FMI, OpenSCENARIO, and OpenDRIVE integration

The gateway reuses the simulator's production standards implementations:

```bash
$ENGINEERING standards fmi model.fmu
$ENGINEERING standards opendrive proving-ground.xodr
$ENGINEERING standards openscenario emergency-stop.xosc proving-ground.xodr
```

FMI inspection uses the existing FMI 3 model-description and package validation path. OpenDRIVE import exposes road/lane geometry through the existing road-network parser. OpenSCENARIO import exposes scenario entities, actions, and references and can resolve the associated OpenDRIVE road network.

## 14. Interactive learning mode

The learning engine contains complete courses with explanation, challenge, choices, scoring, attempts, completion state, and persistent progress. Course material covers diagnostic reasoning, vehicle dynamics, and sensor/fault interpretation.

```bash
$ENGINEERING learning courses
$ENGINEERING learning lesson diagnostic-reasoning 0
$ENGINEERING learning answer diagnostic-reasoning 0 2
$ENGINEERING learning save diagnostic-reasoning progress.json
$ENGINEERING learning load progress.json
```

Incorrect answers return nonzero status but preserve structured feedback.

## 15. Unit-aware calculation system

Compile-time quantity types remain the primary internal representation. `UnitCalculator` provides a checked runtime boundary for compatible conversions and common physics calculations:

```bash
$ENGINEERING units convert 100 km/h m/s
$ENGINEERING units physics 1600 27.78 350 4000
```

Incompatible dimensions are rejected. Calculations include aerodynamic drag, kinetic energy, and mechanical power using typed mass, velocity, area, torque, angular speed, force, energy, and power values.

## 16. Driver behavior models

Profiles are `defensive`, `normal`, `aggressive`, `eco`, `distracted`, and `fatigued`. The model computes throttle, brake, steering, desired acceleration, reaction delay, and attention-lapse state from speed, target speed, lead-vehicle state, lane error, heading error, and road curvature. Random behavior is deterministic for a specified seed.

```bash
$ENGINEERING driver distracted 500 0.02 27.8 35 22
```

## 17. Sensor simulation suite

Supported sensor kinds are camera, radar, lidar, ultrasonic, GNSS, IMU, and wheel speed. Each sensor model includes independent update rate, latency, Gaussian noise, bias, drift, quantization, dropout, limits, and deterministic random stream. Weather and interference degrade applicable sensor classes. Measurements preserve source time, delivery time, validity, dropout, value, and evidence.

```bash
$ENGINEERING sensors 1000 0.01 25.0 0.7 0.2
```

The suite is multi-rate: sensors sample only on their configured schedule and deliver through latency queues.

## 18. Build and validation

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j3
ctest --test-dir build --output-on-failure
```

Focused targets:

```bash
cmake --build build --target \
  authentication_tests engineering_platform_tests muzixdiagsys_engineering
ctest --test-dir build -R \
  'authentication_unit_tests|engineering_platform_unit_tests|engineering_python_api_regression' \
  --output-on-failure
```

The engineering-platform native tests cover role matching, user migration, audit-chain and head-seal integrity, concurrent audit writers, workspace persistence, manifest verification, scenarios, local and distributed campaigns, acceleration metadata, replay, composable faults, telemetry, diagnostic planning, comparison/reporting, standards adapters, learning persistence, unit conversion, driver dynamics, and delayed/noisy sensor streams. The Python regression exercises the authenticated executable end to end.

## 19. Frontier Professional external laboratory integration

The engineering platform remains the authenticated campaign/workspace surface. The additive 2026-08-10 Frontier Professional layer supplies external laboratory and research interfaces that are intentionally kept in the focused `muzixdiagsys_frontier_professional` executable: OPC UA/AAS, physical DIL/OpenXR, vendor CAN transports, ns-3 federation, Jupyter workflows, Prometheus export, Sigstore provenance, HMC/NUTS/MLMC, acoustic beamforming/ANC, and privacy-aware federated learning. It links the same `aesim_advanced` production graph and does not replace engineering workspaces, audit chains, fault campaigns, or the original fleet FedAvg APIs.

```bash
cmake --build build --target muzixdiagsys_frontier_professional frontier_professional_integration_tests
./build/muzixdiagsys_frontier_professional capabilities
./build/muzixdiagsys_frontier_professional self-test build/frontier-selftest
```

For interface contracts and laboratory boundaries, use `docs/FRONTIER_PROFESSIONAL_INTEGRATION.md` and User Manual Chapter 73.

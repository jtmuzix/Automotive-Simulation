# NHRA Championship, Strategy, Diagnosis, and Heritage Platform

## Purpose

`NhraChampionshipStrategyPlatform` is an additive C++17 platform for NHRA national and divisional championship accounting, Countdown forecasting, Mission #2Fast2Tasty Challenge simulation, crew-chief setup optimization, causal run diagnosis, Monte Carlo event strategy, and historical/Heritage competition.

The public header is:

```cpp
#include "aesim/advanced/nhra_championship_strategy_platform.hpp"
```

The implementation is linked into `aesim_advanced` and is also exported through `aesim/advanced/platform.hpp`. Existing generic drag-racing, Formula One, IndyCar, NASCAR, diagnostics, electronics, and vehicle APIs are unchanged.

## CLI

```bash
muzixdiagsys_advanced_platform nhra capabilities [output.json]
muzixdiagsys_advanced_platform nhra self-test DIRECTORY [output.json]
muzixdiagsys_advanced_platform nhra DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Supported domains:

- `national_divisional_points`
- `countdown_simulation`
- `mission_challenge`
- `crew_chief_optimization`
- `causal_run_diagnosis`
- `monte_carlo_event_strategy`
- `heritage_competition`

## National and divisional points

The points engine supports the Mission Foods professional series and Lucas Oil national, regional, and divisional championships.

For Mission competition it calculates elimination points, qualifying-participation points, session performance points, qualifying-position points, and marquee-event multipliers. The request can mark an event waived or invalid without deleting it from the evidence trail.

For Lucas Oil competition it applies category-specific eligibility windows and best-finish selection:

- Top Alcohol national: first ten national and first five regional events; best seven national and best three regional results.
- Top Alcohol region: first six regional events; best four results with home/out-of-region constraints.
- Super Stock, Stock, Super Comp, and Super Gas national: first eight divisional and six national events; best five divisional and best three national results.
- Competition Eliminator, Top Dragster, and Top Sportsman national: first eight divisional and five national events; best five divisional and best three national results.
- Division-only profiles include Super Street and Sportsman Motorcycle.

The implementation includes field-size-sensitive round points from four-car through 129-plus fields, event waivers, home division/region declarations, out-of-division limits, minimum home-event checks, and explicit dropped-result reasons.

## Countdown simulation

The Countdown engine:

1. ranks regular-season competitors;
2. secures the top ten and competitors satisfying the supplied qualifying-compliance condition;
3. resets points to 2,100 for first, 2,080 for second, then ten-point increments;
4. adds accumulated Mission Challenge bonus points;
5. simulates remaining Countdown events with deterministic seeded Monte Carlo;
6. applies the configured final-event premium;
7. reports mean final points and championship probability.

The simulator does not scrape live standings. Current standings are supplied as request data, preserving reproducibility and auditability.

## Mission #2Fast2Tasty Challenge

The Mission engine requires exactly four semifinalists from the previous event. It constructs two rematches, advances each winner, resolves the final by foul precedence and total package, identifies the quickest losing semifinalist, and awards:

- three Countdown bonus points to the winner;
- two to the runner-up;
- one to the quickest losing semifinalist.

Semifinal and final runs remain qualifying passes and can therefore be analyzed separately by the existing timing and telemetry systems.

## Crew-chief optimization

The optimizer samples clutch application, ignition timing, fuel index, tire pressure, wheelie-bar height, and launch rpm. Each candidate is evaluated against:

- predicted elapsed time;
- tire-shake risk;
- component-failure risk;
- lane-excursion risk;
- component-life penalty;
- track grip;
- density altitude;
- lane bias.

Hard risk limits reject unsafe candidates. The result contains the recommended setup and the ten best feasible alternatives. A fixed seed provides deterministic repeatability.

## Causal run diagnosis

The diagnosis service consumes synchronized samples containing wheel slip, vertical acceleration, yaw rate, fuel pressure, oil pressure, EGT spread, throttle, and shift error. It detects and ranks:

- traction loss;
- tire shake;
- lane correction;
- fuel-delivery loss;
- lubrication loss;
- cylinder imbalance;
- driver lift;
- shift-timing error.

The report includes confidence, apportioned elapsed-time loss, an ordered causal path, and a counterfactual elapsed time with the primary cause removed.

## Monte Carlo event strategy

Each strategy defines pace strength, reaction-time distribution, failure probability, tire-shake probability, weather sensitivity, and expected component cost. The round-resolved simulator samples opponent strength and weather for every elimination round, then reports:

- event-win probability;
- final-round probability;
- semifinal probability;
- observed failure probability;
- expected championship points;
- expected component cost in US dollars;
- configurable decision utility.

This supports conservative, balanced, aggressive, qualifying-focused, parts-preservation, and championship-clinch strategies without hard-coding a preferred philosophy.

## Historical and Heritage competition

The Heritage system includes parameterized profiles for:

- front-engine Nostalgia Top Fuel;
- Nostalgia Funny Car;
- A/Fuel Dragster;
- Junior Fuel;
- 7.0 Pro;
- Nostalgia Eliminator;
- Hot Rod.

Entry validation checks period, race weight, blower overdrive, electronic-control compatibility, and oil-down findings. Historical-event generation selects period-appropriate starting-system behavior, timing precision, available classes, and the rear-engine-transition context while retaining modern event-safety enforcement.

## Evidence and validation

Every operation validates required fields, rejects invalid dimensions and unsupported categories, emits canonical JSON, and includes a SHA-256 evidence digest. When a working directory is supplied, a domain-specific result file is written atomically.

```bash
cmake --build build/nhra --parallel --target \
  nhra_championship_strategy_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/nhra --output-on-failure \
  -R 'nhra_championship_strategy|nhra_championship_strategy_source'
```

## Official rules basis

The 2026 implementation was checked against the following official NHRA materials on 2026-07-29:

- Mission Foods Drag Racing Series points: https://www.nhra.com/how-points-are-earned/nhra-mission-foods-drag-racing-series-points
- Countdown point reset: https://www.nhra.com/how-points-are-earned/mission-foods-countdown-championship-points
- Lucas Oil national championship points: https://www.nhra.com/how-points-are-earned/lucas-oil-national-championship-points
- Mission #2Fast2Tasty Challenge program: https://www.nhra.com/Mission-NHRA-Challenge
- Hot Rod Heritage Series: https://www.nhra.com/hotrodheritage
- 2026 Hot Rod Heritage Series policies: https://nhra.com/sites/default/files/2026-02/NHRA%20Hot%20Rod%20Heritage%20Racing%20Series%20Policies%20-%202026.pdf

The rules profile is versioned in generated evidence. Users must update request data and the encoded profile when NHRA publishes amendments or event-specific instructions.

## Qualification boundary

The platform implements an engineering model of published points structures and competition procedures. It does not create an official NHRA result, eligibility decision, protest ruling, technical approval, championship certification, or Heritage legality determination. Official use requires the current rulebook, amendments, event instructions, official timing data, and qualified NHRA personnel.

# Integrated Frontier Platform

## Scope

The integrated frontier platform adds five executable engineering systems to MuzixDiagSys:

1. Physically based multimodal sensor rendering.
2. Heterogeneous multicore automotive SoC simulation.
3. Chemistry-resolved battery and PEM fuel-cell physics.
4. Grid-aware charging and vehicle-to-grid infrastructure.
5. Factory and supply-chain discrete-event simulation.

The public API is declared in:

```text
include/aesim/advanced/integrated_frontier_platform.hpp
```

The implementation is in:

```text
src/advanced/integrated_frontier_platform.cpp
```

All models are deterministic for fixed inputs and random seeds. The implementation does not require proprietary solvers, external cloud services, accelerator drivers, or physical hardware.

## Physically based multimodal sensor rendering

`PhysicallyBasedMultimodalRenderer` maintains one material and geometry scene shared by camera, thermal, lidar, and radar rendering.

### Optical camera

The camera renderer provides:

- Eight-band spectral reflectance and emission.
- Cook–Torrance microfacet shading.
- GGX normal distribution.
- Smith geometric masking and shadowing.
- Schlick Fresnel response.
- Metallic and dielectric material behavior.
- Direct spectral point lighting.
- Environment radiance.
- Multiple stochastic reflection bounces.
- Russian-roulette path termination.
- Atmospheric Beer–Lambert attenuation.
- Rolling-shutter motion from primitive velocity.
- Subpixel sampling.
- Shot and read noise.
- Per-pixel linear RGB, depth, and object identity.

### Thermal camera

The thermal renderer calculates apparent temperature from:

- Surface temperature.
- Surface emissivity.
- Reflected atmospheric radiance.
- Path transmission.
- Atmospheric self-emission.

The emitted and reflected terms are combined in fourth-power radiance space before conversion to apparent temperature.

### Lidar

The lidar renderer provides:

- Arbitrary beam directions.
- Sphere, box, plane, and triangle intersections.
- Multiple returns through partially transparent surfaces.
- Incidence-angle response.
- Inverse-square geometric spreading.
- Two-way atmospheric attenuation.
- Receiver-aperture scaling.
- Range noise.
- Object identity and return ordering.

### FMCW radar

The radar renderer synthesizes a complete receive cube indexed by antenna, chirp, and fast-time sample. It includes:

- Carrier wavelength.
- Chirp slope and beat frequency.
- Doppler frequency.
- Radial target motion.
- Receive-array phase progression.
- Boresight gain.
- Range-fourth-power loss.
- Material radar cross section.
- Atmospheric attenuation.
- Ground-reflected multipath.
- Target truth records.

## Heterogeneous multicore automotive SoC

`HeterogeneousAutomotiveSoC` combines instruction-accurate RV32IM cores with deterministic accelerator engines.

### Scalar cores

RV32IM cores retain the complete instruction, trap, CSR, interrupt, memory-mapped UART, GPIO, and trace behavior provided by `InstructionAccurateRiscVSoC`.

The heterogeneous platform adds:

- Multiple independently loaded CPU cores.
- Shared coherent memory.
- Round-robin reference-clock execution.
- Configurable core clocks.
- Instruction-cache capacity and miss accounting.
- Shared-bus transaction accounting.
- Interconnect byte accounting.
- Safety-lockstep comparison.
- Per-core utilization, power, and thermal state.

### Accelerator cores

DSP, GPU, and NPU cores execute functional jobs rather than abstract timing markers. Supported operations are:

- Memory copy.
- FIR filtering.
- Dense neural-network layers with ReLU.
- Matrix multiplication.
- CRC-32.

Every completion record contains its core, start cycle, finish cycle, data movement, and CRC result where applicable.

## Chemistry-resolved battery physics

`PorousElectrodeCell` represents negative-electrode particles, electrolyte transport, and positive-electrode particles using spatial state vectors.

The model provides:

- Configurable NMC811, LFP, NCA, LTO, and sodium-ion open-circuit behavior.
- Implicit finite-volume diffusion.
- Solid-phase concentration profiles.
- Electrolyte concentration profiles.
- Butler–Volmer-derived kinetic overpotential.
- Concentration-dependent electrolyte resistance.
- SEI resistance.
- Contact resistance.
- Reversible and irreversible heat generation.
- Lumped thermal coupling to ambient and coolant.
- SEI growth.
- Cold-charge lithium plating.
- Lithium-inventory loss.
- Capacity loss.

Positive current discharges the cell; negative current charges it.

## PEM fuel-cell physics

`PemFuelCellStack` implements:

- Hydrogen and oxygen gas inventories.
- Feed and electrochemical consumption.
- Nernst potential.
- Activation polarization.
- Membrane ohmic polarization.
- Concentration polarization.
- Membrane hydration.
- Liquid-water accumulation and evaporation.
- Compressor thermodynamics and parasitic power.
- Gross and net stack power.
- Thermal dynamics.
- Catalyst degradation.
- Hydrogen-consumption accounting.

## Grid-aware charging and V2G

`GridAwareChargingSimulator` represents a radial, three-phase distribution feeder.

### Power flow

The solver uses iterative backward/forward sweep with:

- Per-phase complex bus loads.
- Per-phase complex line impedance.
- Root voltage phasors.
- Constant-power load currents.
- Branch-current accumulation.
- Voltage-drop propagation.
- Line loss calculation.
- Per-unit minimum voltage.
- Line thermal loading.
- Root import or export power.

### Charging scheduler

The scheduler provides:

- Departure deadlines.
- Battery energy targets.
- Charge and discharge limits.
- Charge and discharge efficiency.
- Minimum energy reserves.
- Renewable-aware charging.
- Price-aware V2G export.
- Iterative schedule reduction when feeder voltage or current limits are violated.
- Imported and exported energy.
- Energy cost.
- Carbon accounting.
- Departure-compliance reporting.

## Factory and supply-chain discrete-event simulation

`FactorySupplyChainSimulator` uses a deterministic chronological event queue.

Supported entities and behavior include:

- Parts and initial inventory.
- Suppliers and replenishment batches.
- Supplier lead time and reliability.
- Product bills of material.
- Ordered manufacturing routes.
- Machines and capabilities.
- Setup time.
- Processing time.
- MTBF and repair delay.
- Energy consumption.
- Scrap and bounded rework.
- Customer-order release and due dates.
- Shipping delay, cost, and carbon.
- Supplier delay and outage disruptions.
- Machine outages.
- Transport delays.
- Inventory value and embodied-carbon tracking.
- Machine utilization.
- Unit lead time.
- On-time service level.
- Revenue, manufacturing cost, energy, and carbon.
- Event provenance.

## Validation

The dedicated executable is:

```text
integrated_frontier_platform_tests
```

The registered CTest name is:

```text
integrated_frontier_platform_unit_tests
```

The test exercises every subsystem, including optical/thermal/lidar/radar consistency, coherent multicore memory, NPU execution, spatial battery states, lithium plating, fuel-cell power and water balance, feeder-constrained charging, V2G export, supplier-delay propagation, inventory replenishment, production, shipping, financial accounting, energy, carbon, and document export.

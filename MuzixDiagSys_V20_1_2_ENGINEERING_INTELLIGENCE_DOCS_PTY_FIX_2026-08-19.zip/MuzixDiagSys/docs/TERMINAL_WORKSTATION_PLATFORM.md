# Terminal Workstation Platform

## Purpose

The Terminal Workstation Platform turns the MuzixDiagSys console into a multi-pane engineering workstation suitable for local terminals, SSH, tmux, and constrained remote links.  It is an additive extension of the existing engineering UI.  Existing pane layouts, schema-driven forms, telemetry storage, run comparison, notebook, command dispatch, alerting, and evidence systems remain authoritative.

## Architecture and non-duplication rules

The implementation deliberately avoids parallel UI stacks:

- Arbitrary pane hosting extends `TuiPaneLayoutManager`.
- Scientific Plot/Scope 2.0 is exposed through the existing `ui scope` command and telemetry store.
- Schema-driven forms continue to use `globalui::RichForm` and `ui form`.
- Multi-run comparison extends `NWayRunComparisonWorkbench` and `ui run-compare`.
- Investigation notebook mode extends `EmbeddedEngineeringNotebook`.
- Workspace automation actions are re-injected into the canonical command queue rather than executed through a bypass path.
- Triggered investigations consume the same live engineering metrics used by the normal console.

## Capabilities

### Arbitrary workbench panes

The pane manager supports hierarchical parent relationships, horizontal and vertical splits, moving panes, swapping panes, focus, resizing, visibility, maximize/restore, responsive breakpoints, and layout persistence.

Representative commands:

```text
ui pane status
ui pane split dashboard horizontal scope2 scope 2.0 "ui scope show"
ui pane move scope2 command
ui pane swap scope2 diagnostics
ui pane maximize scope2
ui pane restore
ui pane save ./layout.json
```

### Virtualized structured grid

`VirtualGrid` provides a common tabular surface for large signal, trace, experiment, diagnostic, and artifact datasets.  It supports column metadata, sorting, filters, viewport slicing, selection, frozen columns, width-aware terminal rendering, and CSV export.  Only the visible viewport is rendered.

### Scientific Plot / Scope 2.0

The scientific plotting surface supports multiple engineering series, autoscaling, explicit viewports, pan, zoom, named cursors, sample snapping, nearest-value lookup, and A/B measurements including slope.  It is integrated under `ui scope` so telemetry storage and signal semantics remain centralized.

Representative commands:

```text
ui scope plot rpm vehicle.speed
ui scope cursor A 12.5 snap
ui scope cursor B 15.0 snap
ui scope measure
ui scope pan 1.0 0
ui scope zoom 2.0 14.0 4000
ui scope autoscale
```

### Adaptive SSH rendering

`AdaptiveRemoteRenderer` consumes frame time, bytes emitted, input latency, jitter, and dirty-screen ratio.  It derives a rendering policy containing dashboard/scope frame intervals, animation and graphics eligibility, synchronized-update policy, and byte budget.  The console uses the resulting frame interval in its live refresh path.

```text
ui remote-render status
ui remote-render observe 35 90000 180 75 0.90
```

### Schema-driven command forms

Forms remain generated from the existing command metadata and use `RichForm` validation.  Units, required values, range constraints, dependencies, conflicts, and canonical command generation all stay on the existing execution path.

```text
ui form open set
ui form set duration "2.5 s"
ui form show
ui form command
ui form run
```

### Triggered investigations

Threshold crossings can automatically create bounded investigation captures with pre/post time windows and evidence metadata.  Live console engineering metrics are evaluated each render cycle.

```text
ui investigation-trigger add coolant_hot engine.coolant_c '>' 115 10 30
ui investigation-trigger status
```

### Professional alarm lifecycle

The alarm console adds explicit lifecycle state including active, acknowledged, returned-to-normal, shelved, suppressed, and out-of-service representation.  Shelving is time bounded and automatically expires.

```text
ui alarm-console raise thermal CRIT Coolant high
ui alarm-console ack 1
ui alarm-console shelve 1 600000 known-test-condition
ui alarm-console status
```

### Presentation profiles

Presentation profiles convert canonical values to SI, metric-auto, US customary, or motorsport display units with dimension-specific precision and scientific-notation thresholds.  Calculations remain in canonical units.

```text
ui units use si
ui units use us
ui units use motorsport
ui units format 10 m/s speed
```

### TUI plugin workbench SDK

Plugins can register pane descriptors and object-kind context actions through the workstation registry.  The registry does not grant a plugin a second command or simulation execution path.

### Structured artifact inspector

The inspector identifies text, JSON, CSV, and unknown artifacts and returns bounded previews, file size, row/column information, and headings where applicable.

```text
ui artifact-inspector inspect ./results.csv
```

### Multi-run comparison cockpit

The existing run comparison workbench provides synchronized baseline/candidate values at the active time cursor, with absolute and percentage deltas.

```text
ui run-compare cockpit
ui run-compare cockpit 42.5
```

### Terminal qualification

The qualification wizard evaluates TTY/SSH state, terminal identity, geometry, UTF-8, mouse support, synchronized updates, and Sixel/Kitty capabilities, then recommends refresh, graphics, and density modes.

```text
ui terminal-qualify run
```

### Investigation notebook

Investigation sessions reuse the existing engineering notebook and can record notes and evidence references before being finalized.

### Semantic context actions

Actions are registered by selected-object kind and sorted by priority, allowing signals, DTCs, experiments, and plugin-provided objects to expose relevant canonical commands.

### Workspace automation

Rules compare named live engineering metrics with thresholds and emit canonical commands on an edge-triggered basis.  Commands are queued through the existing console command path.

```text
ui workspace-rules add slow_rtf realtime_factor '<' 0.80 ui profiler status
ui workspace-rules evaluate
```

## Determinism and remote operation

The workstation state machines are deterministic for identical inputs.  The adaptive renderer changes presentation cadence only; it does not alter simulation time steps or physical model state.  Expensive visualization is decoupled from authoritative telemetry collection so remote rendering cannot reduce simulation fidelity.

## Validation

The release contains:

- `tests/terminal_workstation_platform_tests.cpp` for the original 15 workstation capabilities plus the 18 engineering-IDE additions.
- `tests/terminal_workstation_source_regression.py` for retention, implementation-erosion, CMake-wiring, and non-duplication checks.
- Version 20 feature-retention coverage and deterministic source-package coverage.

## Engineering IDE Expansion — 2026-08-18

The workstation now adds an 18-capability engineering-navigation layer while preserving the existing authoritative graph, calibration, scenario, experiment, session, diff/merge, sensitivity, distributed tracing, field-visualization, HIL, and command-dispatch systems.

### Unified engineering graph and dataflow introspection

`ui engineering-graph` builds a terminal presentation graph from the existing `ContextGraph`.  It supports synchronization, inspection, bounded neighborhoods, weighted shortest paths, and terminal rendering. `ui dataflow` is an alias over the same presentation graph; it does not maintain a second producer/consumer database.

```text
ui engineering-graph sync
ui engineering-graph show
ui engineering-graph inspect <object-id>
ui engineering-graph path <source-id> <target-id>
ui engineering-graph neighbors <object-id> 2
```

### Interactive calibration surface editing

The existing Calibration Correlation workbench remains authoritative.  The TUI adds rectangular selection, additive and multiplicative region edits, and a compact terminal heatmap over the current `CalibrationMapStudio` map.

```text
ui calibration-correlation select 2 1 6 4
ui calibration-correlation add-selected 0.25
ui calibration-correlation multiply-selected 0.98
ui calibration-correlation heatmap
```

All modifications pass through the existing calibration map and its validation/review path.

### Scenario and experiment composer

`ui experiment-composer` defines deterministic sweep variables and constraints, calculates the Cartesian design size, and materializes accepted combinations into the existing `ExperimentMatrix`.  Reset also resets the existing scenario timeline name so scenario and experiment context remain aligned.

```text
ui experiment-composer reset cold-start
ui experiment-composer variable ambient_c -25,-15,-5,5
ui experiment-composer variable soc_pct 10:30:10
ui experiment-composer constraint soc_pct '>=' 10
ui experiment-composer materialize
```

### Deterministic TUI session recording and replay

`ui session-record` captures successful canonical commands and workstation context into a versioned `MZUX-TUI-SESSION|1` recording. Replays enqueue captured commands through the existing command queue and therefore retain authorization, semantic validation, staging, and normal logging.

```text
ui session-record start diagnosis-a
ui session-record save ./diagnosis-a.tuisession
ui session-record load ./diagnosis-a.tuisession
ui session-record replay
```

### HPC and distributed operations cockpit

`ui hpc-ops` aggregates the existing HPC placement and distributed trace workbenches with live node/PDES observations.  It reports utilization, event throughput, real-time factor, GVT, rollback rate, checkpoint/fossil collection counts, and partition skew without introducing a second distributed runtime.

### Fault injection and falsification console

`ui fault-console` provides terminal scheduling and visibility for fault campaigns and falsification progress.  Fault execution uses canonical commands re-entered through the existing command queue; it does not bypass the simulator's fault engines or command safety checks.

### Universal telemetry/evidence query workbench

`ui universal-query` queries bounded views assembled on demand from authoritative telemetry metrics, experiments, regression results, and context objects.  Result rows are ephemeral presentation data and can be rendered as a structured table without creating a duplicate evidence database.

### Model/dataflow introspection

`ui dataflow inspect`, `path`, and `neighbors` use the same synchronized `ContextGraph` presentation.  Producers, consumers, object relationships, and dependency paths remain owned by the existing context graph and model registries.

### Diff/merge, qualification, profiling, and sensitivity

Existing authorities are reused directly:

- configuration/calibration/scenario differences continue through `ui compare` and `ConfigurationDiffViewer`;
- `ui qualification-center` summarizes and histories the existing regression triage cases;
- `ui performance-trace` projects the existing distributed trace spans into a terminal flamegraph/critical-path view;
- `ui sensitivity` exposes the existing `DesignSpaceExplorer` and experiment matrix rather than adding a second sensitivity solver.

### Persistent remote sessions

`ui remote-session` is a terminal facade over `PersistentSessionRegistry`. Session creation, observer attachment, detach, release, rename, and status all use the existing session authority.

### Universal cross-domain timeline 2.0

`ui timeline2` aggregates the existing Sequence-of-Events and Flight Recorder streams into a common lane/time view and also accepts terminal-local presentation events.  It does not replace either authoritative event store.

### Build/compiler diagnostics

`ui build-diagnostics load <log>` parses Ninja progress lines and GCC/Clang-style diagnostics into a terminal report with target progress, warning/error locations, and translation-unit timing records.  The parser operates on build logs only and does not alter the build system.

### HIL/instrument operations console

`ui hil-console` maintains terminal presentation records for connected instruments and delegates actual hardware status/safe-state operations to the existing canonical `industrial hil` commands:

```text
ui hil-console backend-status
ui hil-console backend-safe
```

The industrial HIL backend remains the only hardware-I/O authority.

### Mesh/field slice inspector

The existing `MultiphysicsFieldVisualizationWorkbench` remains authoritative. `ui field-visualization slice-heatmap` renders bounded x/y/z slices as terminal heatmaps using its existing field samples.

### Semantic accessibility mode

The existing accessibility command family now supports semantic linearization:

```text
ui accessibility semantic-on
ui accessibility semantic-frame
ui accessibility semantic-metrics
ui accessibility semantic-off
```

Semantic mode strips terminal-control sequences and emits ordered textual regions/metrics while retaining the existing visual accessibility modes.

### Non-duplication contract

The expansion deliberately does not introduce replacement graph, calibration, scenario timeline, experiment, session registry, diff/merge, sensitivity, distributed trace, HIL, field-visualization, or command execution engines.  New workstation state is limited to terminal presentation/orchestration where no equivalent authoritative component existed.

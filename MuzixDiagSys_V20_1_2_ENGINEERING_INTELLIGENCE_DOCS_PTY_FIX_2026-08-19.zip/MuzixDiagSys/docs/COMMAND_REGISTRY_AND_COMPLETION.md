# Canonical Command Registry and Contextual Tab Completion

**Documentation revision:** 2026-07-14

## Purpose

MuzixDiagSys treats execution compatibility and command discovery as related but distinct release interfaces. The dispatcher accepts the complete historical command vocabulary, while interactive discovery presents one canonical spelling for each behavior. This removes redundant choices without breaking scripts, journals, projects, replay manifests, training material, or existing operator workflows.

The current registry contains:

- **165 canonical root commands** shown by discovery.
- **49 compatibility root aliases** accepted by execution but hidden from ordinary discovery.
- **214 total accepted root spellings**.
- Context-sensitive nested rules, runtime presets, parameters, metrics, and delegated industrial routes.

The exact live counts are reported by `command-schema status`; tests consume those reported values rather than duplicating them in a second registry.

## Discovery policy

### Canonical roots

An empty-line Tab request, the F2/Ctrl-Space command palette, schema path enumeration, and root prefix completion expose canonical roots only. For example, `metrics` is discoverable while the legacy spellings `dashboard` and `dash` remain executable but do not appear as duplicate rows.

Typing an exact compatibility alias and pressing Tab migrates the editor to the canonical command. This is an explicit compatibility upgrade, not deletion. The same rule applies to registered engine and vehicle preset aliases.

### Hierarchical parameters

Settable scalar names are intentionally excluded from the root list because they are arguments, not commands. They remain fully discoverable through:

```text
set <Tab>
set engine.<Tab>
set vehicle.<Tab>
```

This reduces root-list noise while preserving complete parameter access.

### Contextual descendants

Nested candidates are derived from the active command context. Exact grammar rules outrank wildcard rules, and delegated platform providers remain authoritative for their own subtrees. Representative paths include:

```text
road surface <Tab>
fuel <Tab>
scope add <Tab>
ui statusbar preset <Tab>
industrial vehicle <Tab>
industrial assurance diagnostics odx <Tab>
industrial energy advanced architecture <Tab>
xcp <Tab>
diagnostics obd <Tab>
validation measured <Tab>
```

Dynamic providers expose current engine presets, vehicle presets, settable parameters, scope channels, loaded platform routes, and other runtime-dependent domains.

### Fuzzy root recovery

When a root prefix has no exact or prefix candidates, Tab performs bounded subsequence scoring against canonical roots only. A typo such as `throtle<Tab>` can recover `throttle`. Compatibility aliases are deliberately excluded from fuzzy recovery so typo assistance cannot recreate the duplicate list that canonical discovery removes.

## Split contextual inspector

Pressing Tab with multiple candidates opens **Canonical Command Completion**, a two-pane inspector.

### Left pane: candidates

The left pane displays the canonical candidate list and an active pointer. It is a real viewport: the visible range follows the selection, and the footer reports candidate range and selected index.

Controls:

| Input | Result |
|---|---|
| Tab / Down | Select next candidate |
| Shift-Tab / Up | Select previous candidate |
| Home / End | Select first / last candidate |
| Enter | Insert the selected canonical token |
| Mouse wheel over left pane | Move the selected candidate |
| Esc / Ctrl-G | Close completion |

### Right pane: selected-command description

The right pane updates whenever the pointer changes. It reports, as applicable:

- Canonical command or full completion path.
- Command category.
- Match mode, including fuzzy recovery.
- Concise summary and extended operational detail.
- Accepted compatibility aliases.
- Valid next tokens for the selected path.
- Canonical insertion and discovery policy.

The description owns an independent scroll offset. PageUp/PageDown scroll it without moving the selected command. A mouse wheel event over the right pane scrolls the description; the same event over the left pane changes the pointer. Selecting another candidate resets the description to its first line.

For narrow terminal widths, the renderer stacks the candidate list and selected-command detail rather than allowing the right pane to collapse or overwrite text.

## Architecture

### Root command registry

`console_root_command_specs()` is the authoritative source for accepted root spellings and canonical targets. The dispatcher resolves a spelling through this registry before entering a handler. Domain dispatch branches compare canonical roots only; alias-specific conditionals are not duplicated throughout the runtime. Discovery derives a canonical projection from the same registry rather than maintaining a second command list.

Every canonical root also has authoritative metadata: category and command summary. Schema validation fails when metadata is missing.

### Nested grammar and delegated registries

`nested_completion_rules()` describes integrated console descendants with exact and wildcard contexts. `IndustrialPlatform` and its vehicle, assurance, electrification, frontier, research, and federation providers own delegated routes. Dynamic model state supplies presets, settable parameters, metric domains, and other runtime candidates.

### Completion proposal model

The terminal catalog converts raw candidates into contextual proposals containing the canonical path, category, aliases, detail text, next-token preview, and match mode. The renderer consumes those proposals directly, so the right pane cannot drift into an unrelated hand-maintained help table.

## Runtime audit commands

```text
command-schema status
command-schema validate
command-schema aliases
command-schema dump
command-schema paths
command-schema complete <command-prefix>
```

- `status` reports accepted spellings, canonical roots, hidden compatibility aliases, discoverable roots, nested rules, literal paths, and policy labels.
- `validate` checks registry uniqueness, canonical resolution, metadata completeness, duplicate choices, exact/wildcard reachability, delegated visibility, and production completion reachability.
- `aliases` prints the compatibility-to-canonical migration table.
- `dump` and `paths` expose the machine-auditable grammar.
- `complete` queries the production non-interactive candidate provider.

Automation interfaces remain:

```text
muzixdiagsys --command-schema
muzixdiagsys --completion-query "road surface "
muzixdiagsys --completion-batch
```

## Regression protection

The release suite verifies:

1. Canonical root discovery contains no compatibility aliases or scalar parameters.
2. Every compatibility alias still resolves and exact-alias Tab migration inserts the canonical spelling.
3. Preset aliases migrate to canonical preset keys.
4. Every declared literal path is reachable through the production completion API.
5. Every canonical root has a category and non-placeholder description.
6. The split PTY inspector shows contextual metadata, follows pointer movement, scrolls the right pane independently, and routes mouse-wheel events according to pane position.
7. Fuzzy typo recovery inserts a canonical root.
8. Completed leaf commands do not restart unrelated grammars.
9. Existing UI, industrial, diagnostics, case-sensitive-path, and manual regressions remain valid.

## Extension requirements

When adding or changing a command:

1. Register accepted root spellings and the canonical target in `console_root_command_specs()`.
2. Add category and summary metadata for every new canonical root.
3. Route execution through canonical resolution; do not create an independent dispatcher alias table.
4. Add nested literal or enum candidates to the owning grammar/provider.
5. Keep filenames, IDs, numbers, payloads, and other free-form arguments free-form and case preserving.
6. Put model parameters under `set`, not in the root namespace.
7. Add a PTY regression for novel interaction behavior.
8. Run `command-schema validate` and the complete CTest matrix.

Do not add independent root lists to the editor, command palette, help overlay, schema reporter, or dispatcher.


## Declarative UI action metadata

The canonical root registry is also ingested by `ux::ExperienceManager`. Registry metadata is merged with richer nested parameter schemas; an untyped live root record cannot erase an existing generated-form schema. Each UI action can define title, category, summary, mutation classification, discovery-profile promotion, aliases, search tags, and typed parameters.

This metadata drives all of the following from one source:

- Universal action indexing and type-prefixed fuzzy search.
- Presentation-only discovery profiles.
- Generated forms and validation.
- Context-sensitive help.
- Preview and dry-run mutation classification.
- Typed command transaction labels.

All accepted aliases remain parser contracts. The universal action palette may match an alias, but it displays and invokes the canonical action. See `docs/STREAMLINED_UI_EXPERIENCE.md`.

## Advanced API engineering registry

`muzixdiagsys_advanced_platform` additionally exposes a machine-readable registry for the 146 advanced API command adapters:

```bash
muzixdiagsys_advanced_platform commands [--category CATEGORY] [output]
muzixdiagsys_advanced_platform describe COMMAND [output]
muzixdiagsys_advanced_platform COMMAND capabilities|describe|schema|example [output]
muzixdiagsys_advanced_platform COMMAND self-test DIRECTORY [output] [GLOBAL_OPTIONS]
muzixdiagsys_advanced_platform COMMAND run REQUEST OUTPUT [WORKING_DIRECTORY] [GLOBAL_OPTIONS]
```

This registry is additive and is separate from the legacy interactive command registry. It is intended for scripting, CI, SSH workflows, and direct access to advanced engineering APIs. Use `commands --category CATEGORY` for discovery and `describe COMMAND` for machine-readable schema/example metadata. The complete command list and global option semantics are documented in `ADVANCED_API_CLI_COMMANDS.md`.

## V16 graphical command adapters

V16 preserves the same canonical command registry and adds only nested GUI-support operations. The graphical browser never invents a second command namespace: docking mutations, semantic analysis, scenario resizing, workflow graph/debug inspection, calibration inspection, and track/lap extraction are submitted through the standard dispatcher. New nested forms include `ui semantic json`, `ui desktop activate`, `ui desktop reorder`, `ui scenario-timeline resize`, `ui workflow-editor json`, `ui workflow-debugger json`, `ui calibration-correlation json`, and `ui run-compare track-json`. Existing aliases, completion behavior, canonical roots, and legacy command contracts remain valid. See `ENGINEERING_UI_PLATFORM.md`.

## V19 help-generation contract

The canonical command registry is also the root of the detailed-help system. Root metadata supplies category, summary, aliases, mutability, and typed parameters. Nested completion rules supply literal subcommand/value grammar. The V19 help renderer combines both so `help <path>` and the completion detail pane cannot independently invent command semantics.

Extension rule: register one canonical root, add aliases only for compatibility, provide a precise root summary/category, define typed parameter constraints where applicable, and add nested literal grammar. Common operation descriptions (`status`, `validate`, `create`, `run`, `export`, `json`, `lod`, and similar) are generated centrally; add operation-specific wording only when the common semantic would be inaccurate. New parser-visible behavior should be covered by completion reachability and a help regression, not by a duplicated standalone command table.

Operator discovery surfaces are intentionally distinct: Tab is context completion, F2 is universal action search, `help search <term>` is command/subcommand search, and `command-schema complete <prefix>` is the machine-readable completion interface.


## V20.1.2 universal palette and CLI/GUI equivalence

The universal palette is now a federated **discovery** surface but not a federated command executor. `Screen::universal_palette()` merges:

1. the existing Experience Manager action/command index; and
2. `StructuredGlobalSearch`, which contains workbench, signal, diagnostic, run-management, and engineering-object metadata.

Results are deduplicated by canonical invocation, ranked, and passed through `UiAccessPolicy`. Therefore a structured engineering result cannot bypass the same capability or safety restrictions that apply when the command is typed directly.

```text
ui palette battery temperature
ui palette time checkpoint
ui palette regression
```

`CliGuiEquivalenceRegistry` complements discovery by making GUI action mappings inspectable:

```text
ui equivalence list
ui equivalence search dashboard
ui equivalence show dashboard.save
```

A mapping never executes simulator logic itself. The terminal palette, browser workbenches, help/completion system, and direct CLI all converge on canonical commands. New UI actions must therefore register or reference an existing canonical command rather than embedding independent model mutations in the frontend.


## Research-grade engineering UI command families

The interactive completion registry includes the following canonical `ui` families: `formal-verification`, `field-visualization`, `jacobian-inspector`, `distributed-trace`, `hpc-placement`, `safety-analysis`, `temporal-bisection`, `contract-monitor`, `state-machine`, `numerical-trust`, `run-lineage`, `realtime-deadline`, `cosim-sync`, `coverage-explorer`, `cyber-attack`, `engineering-notebook`, `report-composer`, `crdt-collaboration`, `plugin-manager`, `migration-center`, `dependency-heatmap`, `performance-investigator`, `divergence-investigator`, `failure-clustering`, `twin-measurement`, `alert-rules`, `product-line`, and `control-room`.

Browser action metadata uses these exact shell forms. Commands requiring arguments are templates in the schema and are not executed until the operator supplies those arguments. Plugin and configuration migration remain top-level canonical commands (`plugin ...`, `config ...`) and are intentionally not reimplemented as nested UI commands.

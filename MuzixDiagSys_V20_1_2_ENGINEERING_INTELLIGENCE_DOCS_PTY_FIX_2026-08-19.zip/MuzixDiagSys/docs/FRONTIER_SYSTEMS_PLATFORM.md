# Frontier Systems Platform

**Release:** 2026-08-07  
**CLI family:** `muzixdiagsys_advanced_platform frontier-systems`  
**Public API:** `include/aesim/advanced/frontier_systems_platform.hpp`

The Frontier Systems Platform is an additive twelve-domain engineering layer for deterministic in-vehicle networking, native scientific data interchange, mesh/field exchange, external CAE federation, heterogeneous numerical kernels, PGAS/RMA communication, robust control, safety-critical MPC/estimation, automatic differentiation, event cameras, raw FMCW radar, and semantic physics contracts. It does not replace or hide any existing MuzixDiagSys command or platform.

## 1. Build and capability discovery

Configure the complete project in the normal manner, then build the advanced platform:

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON
cmake --build build/full --target muzixdiagsys_advanced_platform -j
```

Inspect runtime/native capabilities:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems capabilities
```

The deterministic implementations always build. Native HDF5, NetCDF, OpenMP, Kokkos, CUDA Runtime, MPI RMA, GPU-direct MPI/RMA, Clang, and Enzyme execution are reported only when actually detected. A missing optional dependency never produces a false-success capability.

General execution form:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-systems DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Complete integrated self-test:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-systems self-test build/frontier-systems-self-test \
  build/frontier-systems-self-test.json
```

## 2. Automotive TSN profile conformance laboratory

Domain: `automotive-tsn-profile-conformance-laboratory` or `tsn`.

The implementation models:

- deterministic BMCA-style grandmaster selection using priority1, clock class, clock accuracy, offset-scaled log variance, priority2, and clock identity;
- initial clock offset, ppm drift, wander, timestamp noise/quantization, synchronization interval, and maximum synchronization-error qualification;
- per-link serialization, propagation, bridge residence delay, guard bands, finite queue capacity, and explicit failed-link state;
- cyclic IEEE 802.1Qbv-style time-aware gate windows plus deterministic gate-window synthesis from stream demand and a configurable engineering margin;
- Qbu/802.3br-style preemption blocking with a configurable fragment size;
- Qci-style token-bucket policing, Qcr/ATS-style token shaping, and Qav-style idle-slope service limits;
- primary and redundant route qualification, earliest valid delivery, and 802.1CB/FRER-style disjoint-route single-link-failure evidence;
- phase-aware gate-delay bounds when deterministic release phase is preserved, with conservative maximum-closed-gate treatment when equal/higher-priority interference destroys phase knowledge;
- fixed-point same/higher-priority interference bounds, lower-priority blocking, per-link queue bounds, configured queue-capacity checks, certified end-to-end latency bounds, and deadline qualification;
- per-stream releases, deliveries, shaping/policing drops, nominal and certified latency, route availability, and a SHA-256 evidence seal.

The gate scheduler requires the complete frame, including Ethernet overhead, to fit inside an open gate interval. A stream with no finite policing or ATS rate is not accidentally constrained by a finite token bucket. Legacy result names such as `policer_drops`, `deadline_misses`, and `worst_latency_us` remain available alongside the more explicit v2 fields.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems tsn \
  examples/frontier_systems/automotive_tsn.json \
  build/results/automotive-tsn.json
```

The model is an engineering conformance laboratory; it does not claim third-party IEEE certification.

## 3. Native scientific data interchange

Domain: `native-scientific-data-interchange-platform` or `scientific-data`.

Supported operations are `write`, `read`, and `roundtrip`.

### 3.1 Zarr v2

Zarr v2 is always available. The writer emits `.zgroup`, `.zattrs`, per-array `.zarray` and `.zattrs`, and C-order little-endian IEEE-754 binary64 chunks. Array shape, unit, title, and data are reconstructed by the reader.

### 3.2 HDF5

When native HDF5 is detected, each scientific array is written as an HDF5 dataset below `/arrays`, using IEEE-754 binary64 storage. A canonical MuzixDiagSys manifest preserves complete array metadata and a reader independently reloads the HDF5 datasets before round-trip comparison.

### 3.3 NetCDF-4

When native NetCDF is detected, dimensions and binary64 variables are created through the NetCDF C API, unit attributes are attached to variables, and a canonical global manifest preserves complete metadata.

All native writers create missing parent directories automatically. `roundtrip` requires identical names, units, shapes, and value counts and enforces the configured numeric tolerance.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems scientific-data \
  examples/frontier_systems/scientific_data.json \
  build/results/scientific-data.json build/native-io
```

If HDF5 is not available, use `"format":"zarr"`.

## 4. Mesh, field interchange, and in-situ visualization

Domain: `mesh-field-interchange-and-insitu-visualization-platform` or `mesh`.

Implemented interchange paths:

- VTK legacy ASCII unstructured grids;
- Gmsh 2.2 ASCII meshes with NodeData/ElementData;
- VTKHDF unstructured-grid HDF5 containers when HDF5 is available, using `/VTKHDF` metadata plus native `Points`, `Connectivity`, `Offsets`, `Types`, point/cell/connectivity counts, and `/VTKHDF/PointData` and `/VTKHDF/CellData` datasets;
- point- and cell-associated multi-component fields with unit attributes;
- vertex, line, triangle, quad, tetrahedral, and hexahedral cells;
- deterministic round-trip verification;
- in-situ field reduction with bounds, minimum, maximum, mean, and L2 norm.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems mesh \
  examples/frontier_systems/mesh_visualization.json \
  build/results/mesh.json build/mesh-interchange
```

Use `{"operation":"insitu-reduce", ...}` when only field statistics and geometric bounds should leave a large simulation rather than full fields.

## 5. External CAE solver federation

Domain: `external-cae-solver-federation` or `cae`.

The federation generates directly executable case trees for:

- OpenFOAM `laplacianFoam` plus `blockMesh`;
- SU2 `SU2_CFD`;
- CalculiX `ccx`;
- Code_Aster `as_run`;
- Elmer `ElmerSolver`.

`operation=generate` writes the native input deck without requiring the solver. `operation=run` resolves the actual executable or accepts an explicit executable, invokes it with `fork`/`exec` rather than shell interpolation on POSIX systems, enforces a timeout, captures stdout/stderr, extracts reported residual evidence, recomputes the acceptance decision against the requested tolerance, and cryptographically seals the result. `operation=federate` runs and aggregates several solver requests.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems cae \
  examples/frontier_systems/cae_federation.json \
  build/results/cae.json build/cae
```

Native CAE executables are never reported as available unless found in the execution environment.

## 6. Portable heterogeneous kernel runtime

Domain: `portable-heterogeneous-kernel-runtime` or `kernels`.

Implemented kernels:

- AXPY;
- deterministic dot product;
- CSR sparse matrix-vector multiplication;
- three-dimensional seven-point stencil/Laplacian operator.

The serial backend always exists. OpenMP is compiled when detected. Kokkos is compiled when a valid `Kokkos::kokkos` CMake target is present. AXPY, dot product, CSR SpMV, and the 3-D stencil have genuine Kokkos execution paths; the runtime initializes Kokkos only when required and releases it only when it owns that initialization. The Kokkos dot product forms products on the selected execution space and performs the final accumulation in deterministic host index order. The OpenMP dot product likewise uses fixed per-thread partials and an ordered host reduction instead of an implementation-dependent reduction tree.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-systems kernels \
  examples/frontier_systems/portable_kernel.json \
  build/results/kernel.json
```

## 7. GPU-direct PGAS communication runtime

Domain: `gpu-direct-pgas-communication-runtime` or `pgas`.

The runtime provides a deterministic symmetric-memory exercise on every host. If MPI has been compiled and initialized, it creates an MPI RMA window and exercises one-sided transfer. If both MPI and an operational CUDA Runtime device exist, the runtime additionally attempts an actual device-memory MPI RMA operation and reports `gpu_direct_rma_verified` only after the transfer path completes and the device buffer can be read back successfully.

This makes capability state explicit on CPU-only developer machines while allowing the same command to qualify a GPU-aware MPI installation on a capable cluster.

## 8. Certified robust-control synthesis

Domain: `certified-robust-control-synthesis-laboratory` or `robust-control`.

The laboratory accepts a discrete state-space model and positive Q/R diagonal weights. It solves the discrete algebraic Riccati equation iteratively, derives the LQR feedback gain, and evaluates every supplied `A_vertices` uncertainty vertex against a common quadratic Lyapunov matrix. Positive-definiteness is tested using a Cholesky-based margin search.

It also samples the closed-loop disturbance-to-output transfer function on the unit circle and reports a conservative sampled Frobenius gain peak. The output explicitly labels this as a sampled frequency metric; it is not misrepresented as a continuous-frequency H-infinity theorem.

The certificate contains the feedback gain, Riccati matrix, common Lyapunov margin, closed-loop infinity-norm bound, sampled gain, acceptance limit, and evidence hash.

## 9. Safety-critical MPC and moving-horizon estimation

Domain: `safety-critical-mpc-estimation-platform` or `safety-mpc`.

Three operations are implemented:

- `mpc`: finite-horizon linear quadratic MPC with bounded inputs, adjoint gradients, forward rollout, optional discrete control-barrier constraints, disturbance-tube radius bound, barrier interventions, and recursive-feasibility evidence;
- `mhe`: finite-horizon observability/information least-squares estimation with measurement and prior variance weighting;
- `barrier-filter`: one-step control-barrier projection for an externally supplied control action.

Barrier constraints use `c*x <= upper_bound` and discrete decay parameter `alpha`. If a barrier cannot be influenced through `B`, the runtime reports an engineering error rather than silently declaring a safe control.

## 10. Compiler-native automatic differentiation

Domain: `compiler-native-automatic-differentiation-runtime` or `compiler-ad`.

The deterministic core uses a real reverse-mode computational tape. Supported expression operations are constants, indexed variables, add, subtract, multiply, divide, sine, cosine, exponential, logarithm, square root, hyperbolic tangent, and fixed-exponent power. The reverse gradient is independently checked against central finite differences.

When an Enzyme LLVM plugin is supplied through `enzyme_plugin` or `AESIM_ENZYME_PLUGIN`, `method=enzyme` emits a one-variable C translation unit, invokes Clang directly, loads Enzyme as a compiler plugin, compiles a shared derivative function, dynamically loads the resulting library, and compares the compiler-produced derivative with the deterministic reverse-mode derivative. The Enzyme path is reported unavailable when its actual compiler/plugin prerequisites are absent.

## 11. Event-camera neuromorphic vision

Domain: `event-camera-neuromorphic-vision-platform` or `event-camera`.

The event sensor converts positive input intensity frames to log intensity and emits asynchronous polarity events when pixel-specific positive/negative contrast thresholds are crossed. It includes:

- calibration mode that estimates positive/negative contrast thresholds from known log-intensity changes and event counts;
- Gaussian pixel threshold mismatch and log-domain shot-noise injection;
- refractory time, reference-level leak, and Poisson background activity;
- deterministic random seed, timestamp interpolation, and optional timestamp quantization;
- event bandwidth limit and dropped-event accounting;
- DAVIS-style statistics for the final APS frame;
- positive/negative event counts and event centroid;
- early/late event-centroid optical-flow estimation;
- optional focal-length/depth conversion to angular-rate and lateral ego-motion estimates.

Invalid dimensions, nonpositive intensity, nonmonotonic timestamps, and invalid sensor/noise parameters are rejected. `operation=calibrate`, `simulate`, `flow`, and `ego-motion` are executable paths rather than documentation-only modes.

## 12. Raw radar RF/ADC signal-chain laboratory

Domain: `raw-radar-rf-adc-signal-chain-laboratory` or `raw-radar`.

The radar laboratory synthesizes a complex FMCW ADC cube across chirps, receivers, and fast-time samples. The signal chain includes target range, radial velocity, azimuth, complex phase, chirp slope, Doppler, receive-array spacing, independent phase noise, PLL phase random walk, clock jitter, chirp nonlinearity, per-channel gain/phase/DC offsets, I/Q gain/phase mismatch, receiver-to-receiver coupling, complex Gaussian thermal noise, ADC clipping, and finite-bit quantization.

Targets can carry deterministic multipath components with excess path length, velocity/azimuth offsets, attenuation, and phase. Independent interferers can inject arbitrary beat/Doppler components. Hann-windowed range and Doppler DFT processing produces a full range-Doppler power cube, median-noise local-maximum detections, and coherent receive-array beam scanning for azimuth. The strongest detection reports estimated range, radial velocity, azimuth, peak power, range/velocity resolution, unambiguous range/velocity, saturation count, and detection metadata. Optional outputs expose the raw complex I/Q cube and bounded range-Doppler power data.

Range resolution is computed from the actually observed fast-time aperture, not blindly from the configured chirp duration. By default, targets outside the configured unambiguous range or velocity are rejected. Set `allow_aliasing=true` only when aliasing is intentionally part of the experiment.

## 13. Semantic physics contract system

Domain: `semantic-physics-contract-system` or `physics-contract`.

The contract layer validates data exchanged between physical subsystems before coupling. Contracts carry:

- physical quantity identity and dimensional unit;
- coordinate frame and time basis;
- producer/consumer causality and optional conservation group;
- admissible minimum/maximum range;
- one-sigma model/measurement uncertainty plus absolute/relative numerical error budgets;
- differentiability class (`continuous`, `piecewise-smooth`, `nondifferentiable`, or `unknown`);
- interpolation policy (`hold`, `nearest`, `linear`, `cubic`, or `none`) and extrapolation policy (`forbid`, `clamp`, or `allow`).

The built-in unit algebra covers dimensionless, mechanical, thermal, angular, pressure, energy/power, and electrical quantities, including current, voltage, resistance, capacitance, inductance, magnetic flux/flux density, conductance, common automotive pressure/speed units, and affine Celsius-to-Kelvin conversion. Source admissible range is checked before conversion and target range after conversion. Frame changes require an explicit orthonormal 3x3 **proper rotation** (determinant +1); optional position translation carries its own unit. Time-basis changes require synchronization uncertainty within a configured limit. Transfer uncertainty combines source/target uncertainty and numerical-error evidence, and a target can impose a maximum accepted uncertainty.

`operation=conservation-check` requires matching conservation-group identity, converts every signed term to a common unit, propagates uncertainty/error in root-sum-square form, and verifies the residual against absolute, relative, and sigma-weighted tolerance contributions.

## 14. Canonical examples

Every domain has an executable JSON request under:

```text
examples/frontier_systems/
```

The intended regression sweep is:

```bash
for f in examples/frontier_systems/*.json; do
  echo "$f"
done
```

Use the matching domain names listed in this document; the repository's CLI regression exercises capability discovery, semantic contract conversion, and the integrated twelve-domain self-test.

## 15. Qualification

Focused build and qualification:

```bash
cmake --build build/full --target \
  frontier_systems_platform_tests muzixdiagsys_advanced_platform -j

./build/full/frontier_systems_platform_tests
python3 tests/frontier_systems_source_regression.py .
python3 tests/frontier_systems_cli_regression.py \
  ./build/full/muzixdiagsys_advanced_platform .
```

Full compiled artifact closure:

```bash
cmake --build build/full --target aesim_test_artifacts -j
ctest --test-dir build/full --output-on-failure
```

## 16. Engineering boundaries

- Existing simulator features, motorsports platforms, APIs, and CLI commands remain available.
- Optional native runtimes are feature detected; capability JSON is authoritative for the current build/host.
- Generated CAE cases and numerical evidence do not replace external solver vendor qualification or physical validation.
- The robust-control sampled gain metric is not a substitute for continuous-frequency structured singular-value analysis.
- The raw radar laboratory is an engineering sensor model, not an RF compliance transmitter.
- Semantic physics contracts prevent many category/unit/frame errors but cannot prove the physical adequacy of the producer model itself.

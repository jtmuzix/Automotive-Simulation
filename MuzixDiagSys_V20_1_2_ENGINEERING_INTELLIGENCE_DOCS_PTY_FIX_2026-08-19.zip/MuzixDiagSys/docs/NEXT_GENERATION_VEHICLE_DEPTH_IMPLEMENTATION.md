# Next-Generation Vehicle Depth Implementation

Revision: 2026-07-12  
Scope: flexible structures, spatial terrain, advanced tires, distributed high voltage, switching electric drive, multidimensional aerodynamics, detailed brakes, AUTOSAR-oriented multicore execution, causal replay, and state-conserving multi-fidelity simulation.

## 1. Purpose

This extension adds a coupled vehicle-depth layer to the existing high-fidelity multiphysics vehicle. It does not replace the established combustion, gas-path, battery, thermal, chassis, network, assurance, federation, or electrification models. The new layer owns the additional high-bandwidth and spatial states and exchanges loads, temperatures, electrical demand, actuator requests, and timing information with the existing `IntegratedHighFidelityVehicle`.

The primary runtime class is:

```cpp
#include "aesim/high_fidelity/integrated_depth.hpp"

aesim::high_fidelity::IntegratedVehicleDepthRuntime runtime;
```

The complete public model declarations are in:

```text
include/aesim/high_fidelity/vehicle_depth.hpp
include/aesim/high_fidelity/integrated_depth.hpp
```

The implementations are in:

```text
src/vehicle/depth_structural_environment.cpp
src/vehicle/depth_electrical_aero_brake.cpp
src/vehicle/depth_autosar_replay_fidelity.cpp
src/vehicle/depth_integrated.cpp
```

## 2. Coupled execution architecture

`IntegratedVehicleDepthRuntime::advance()` performs one deterministic coupled advance. The execution order is designed to preserve causality:

1. Advance the established high-fidelity vehicle plant.
2. Advance terrain weather and determine world-space wheel locations.
3. Evaluate multidimensional aerodynamic forces and cooling mass flows.
4. Sample the three-dimensional terrain beneath each tire contact patch.
5. Advance detailed brake hydraulic and tribology states.
6. Advance structural tires with local terrain, normal load, drive torque, and brake torque.
7. Advance the switching-resolved electric drive.
8. Advance the distributed high-voltage network using electric-drive and auxiliary loads.
9. Advance flexible chassis modes using tire, mount, aerodynamic, steering, and hitch loads.
10. Advance the AUTOSAR-oriented multicore runtime and its communication services.
11. Apply automatic fidelity selection when enabled.
12. Publish aggregate state, conservation residuals, and replay metadata.

Each high-bandwidth domain has an independent accumulated update period. Fidelity changes alter these periods without discarding physical state.

## 3. Flexible-body chassis and component modal dynamics

### 3.1 Modal formulation

Each configured mode is represented by a generalized displacement `q`, velocity `q_dot`, and acceleration `q_ddot`:

```text
m*q_ddot + c*q_dot + k*q + k3*q^3 = Q
```

where:

- `m` is modal mass,
- `c = 2*zeta*omega*m`,
- `k = omega^2*m`,
- `k3` is derived from the configured nonlinear stiffness ratio,
- `Q` is the generalized force assembled from corner, mount, aerodynamic, steering, battery, and hitch loads.

The default mode set contains body torsion, body bending, front and rear subframe response, battery-enclosure response, and steering-column response. Every mode has explicit participation coefficients for corner displacement, IMU rotational error, steering-column twist, battery strain, and stress recovery.

### 3.2 Structural outputs

The model reports:

- modal displacement, velocity, and acceleration,
- modal kinetic and strain energy,
- dissipated modal energy,
- four-corner vertical and lateral hardpoint displacement,
- IMU orientation error caused by local structure motion,
- steering-column twist,
- battery-enclosure strain,
- recovered stress,
- fatigue damage,
- first-law mechanical-energy residual.

The corner deformations feed the tire and aerodynamic ride-height calculations. This closes the load-compliance-alignment loop instead of treating structural motion as a post-processing output.

## 4. Three-dimensional environmental terrain

### 4.1 Surface representation

`EnvironmentalTerrain3D` superimposes:

- deterministic procedural roughness,
- longitudinal grade and lateral crown,
- optional CSV height grids with bilinear interpolation,
- bounded material patches,
- accumulated rainwater and snow,
- local temperature,
- deformable-soil sinkage and compaction.

Supported surfaces are asphalt, concrete, cobblestone, gravel, sand, mud, snow, ice, water, and soil.

### 4.2 Terrain patches

A patch defines an axis-aligned world-space region and can independently set:

- surface material,
- height offset,
- friction multiplier,
- roughness RMS,
- water depth,
- snow depth,
- loose-material depth,
- soil cohesion,
- internal friction angle,
- temperature.

Overlapping patches are resolved deterministically in insertion order, with the most recently matching patch providing local material overrides.

### 4.3 Contact sampling

The terrain API provides point samples and finite contact strips. A sample includes the three-dimensional position, surface normal, material, friction, roughness, water, snow, loose material, sinkage, compaction, and temperature. Normals are calculated from neighboring height samples rather than assumed vertical.

## 5. Advanced structural tire, pressure, wear, and failure

### 5.1 Structural and contact states

Each tire contains:

- belt radial displacement and velocity,
- sidewall displacement and velocity,
- inflation-gas mass, temperature, volume, and pressure,
- transient longitudinal and lateral slip,
- combined-slip force saturation,
- camber thrust and aligning moment,
- effective loaded radius,
- tread and carcass temperatures,
- rolling resistance,
- tread depth and normalized wear,
- belt and sidewall damage,
- puncture mass flow,
- stored and dissipated energy.

### 5.2 Environmental behavior

The tire evaluates local water depth, friction, roughness, loose material, and terrain normal. Hydroplaning reduces available force when water depth and speed exceed the pressure-dependent threshold. Loose and deformable surfaces add rolling resistance and reduce effective shear capability.

### 5.3 Failure progression

The deterministic failure state machine includes:

```text
Healthy -> UnderInflated -> Punctured -> RunFlat
                                |          |
                                v          v
                         BeltSeparation -> Blowout
```

The exact transition depends on pressure, configured run-flat capability, accumulated belt/sidewall impact energy, and structural damage. Public operations allow puncture, repair, and impact-energy injection.

## 6. Distributed high-voltage network and protection transients

### 6.1 Network representation

The HV system is a graph of capacitive nodes and inductive-resistive branches. The default topology includes the traction source, main junction, two inverter branches, and an auxiliary branch. Each branch carries current, temperature, fuse `I^2t`, arc energy, and protection state.

The transient equations include:

```text
L*di/dt = V_from - V_to - R*i
C*dV/dt = sum(i_branch) + i_source - i_load - i_leakage
```

Constant-power loads are bounded by minimum voltage and maximum current. Source resistance, node leakage, local ground faults, and branch thermal losses are represented explicitly.

### 6.2 Protection behavior

Implemented protection states are closed, open, tripped, and welded. The network models:

- contactor opening and welded contacts,
- branch overcurrent,
- fuse `I^2t` accumulation and trip,
- pyrofuse crash delay and firing,
- current interruption arc energy,
- node-to-ground faults,
- isolation resistance,
- undervoltage and overcurrent flags,
- resistive and protection-energy accounting.

## 7. Switching-resolved inverter and electromagnetic machine

### 7.1 Control and switching

The electric drive uses a three-phase PMSM model with field-oriented current control. It includes:

- Clarke/Park-equivalent phase-to-`d-q` transforms,
- torque-to-`i_q` request conversion,
- field weakening through negative `i_d`,
- PI current controllers,
- voltage-vector saturation,
- triangular PWM carrier,
- six semiconductor gate states,
- configurable switching frequency,
- phase-current differential equations,
- back EMF and rotor electrical angle,
- imposed-speed and free-rotor modes.

### 7.2 Loss and thermal behavior

The model calculates:

- copper loss,
- semiconductor conduction loss,
- switching loss,
- inverter thermal response,
- magnetic and kinetic stored energy,
- DC-bus current,
- current total harmonic distortion,
- switching-event count,
- energy residual.

### 7.3 Electrical faults

Supported faults are phase-A open, phase-B open, phase-C open, phase short, and resolver bias. Open-phase behavior changes the electrical topology: the failed phase current is constrained to zero and the two active phases enforce current balance.

## 8. Multidimensional aerodynamics and aero-thermal cooling

The aerothermal model computes six-axis force and moment as functions of:

- three-dimensional relative wind,
- explicit yaw, pitch, and roll,
- four corner ride heights,
- rake,
- grille opening,
- spoiler position,
- trailer articulation,
- air density and temperature.

Outputs include drag, lift, side force, roll/pitch/yaw moments, aerodynamic power, underhood pressure, radiator airflow, battery cooling airflow, four brake-duct airflows, and corresponding heat-transfer coefficients. Structural corner deflection modifies ride height before the aerodynamic evaluation.

## 9. Detailed brake hydraulics, tribology, wear, and judder

The brake model includes:

- pedal force, pedal ratio, and booster gain,
- master-cylinder area,
- fluid bulk modulus,
- line volume and hose compliance,
- valve-flow dynamics,
- individual circuit leakage,
- ABS release modulation,
- caliper piston area and clamp force,
- temperature-dependent pad friction and fade,
- wet-friction recovery,
- transfer-layer formation,
- disc and pad thermal masses,
- cooling-air coupling,
- pad and rotor wear,
- runout-driven judder torque,
- fluid temperature, wet/dry boiling point, vapor fraction, and fallback state,
- hydraulic, friction, heat, and energy-residual ledgers.

## 10. Multicore ECU execution and AUTOSAR-oriented services

### 10.1 Scheduler

`AutosarMulticoreRuntime` provides deterministic fixed-priority preemptive execution on configurable cores. Runnable definitions contain activation type, period, deadline, worst-case cycles, priority, core affinity, service use, RTE input/output, and network frame.

The default controller contains acquisition, braking, inverter, vehicle-dynamics, network-receive, diagnostics, health-monitoring, and OTA runnables distributed across four cores.

### 10.2 Services

The runtime implements operational behavior for:

- RTE reads and writes,
- COM serialization and receive delivery,
- end-to-end sequence counter and CRC checking,
- DEM event storage,
- NvM key/value persistence,
- watchdog supervision,
- ECU state management,
- diagnostic-over-IP-oriented traffic,
- time-synchronization service use.

Network delivery includes base latency, deterministic seeded jitter, packet loss, sequence counters, and receive-queue timing. Execution overruns can be injected by runnable and duration.

## 11. Checkpointing, causal replay, and counterfactual branching

### 11.1 Recorded event stream

Every integrated advance records:

- exact step duration,
- physical and environmental inputs,
- operator-supplied world initialization,
- braking and crash inputs,
- a causal label.

Each checkpoint stores its branch, event index, simulation time, captured state blob, and state hash.

### 11.2 Deterministic reconstruction

The integrated runtime reconstructs state by resetting all models and replaying the recorded input sequence through the same coupled execution path. This includes the pre-existing high-fidelity model, all new depth modules, accumulated multi-rate clocks, and deterministic random streams.

### 11.3 Branching and counterfactuals

A branch forks at a named checkpoint. A recorded input can then be replaced at a selected event, after which the branch is replayed to expose the causal consequence of the changed input. Replay archives use a versioned binary representation with magic validation, explicit string and map lengths, and checkpoint state hashes.

## 12. State-conserving multi-fidelity runtime switching

### 12.1 Fidelity levels

Every registered domain supports:

- `Reduced`
- `Engineering`
- `Detailed`

The coordinator records each transition with before/after projections for energy, mass, charge, and momentum. A transition is accepted only when the domain projection succeeds. The difference is accumulated as an explicit conservation correction rather than silently lost.

### 12.2 Domain behavior

The current implementation preserves full state and changes update cadence and calculation depth. This avoids discontinuities in displacement, current, temperature, pressure, rotational speed, tire pressure, or stored energy. Automatic mode selects fidelity from numerical error, event severity, and the configured computational budget.

## 13. Console command reference

The runtime is exposed as `industrial energy depth`, with aliases `next-generation`, `nextgen`, `ng`, and `vehicle-depth`.

Representative executable commands:

```text
industrial energy depth status
industrial energy depth auto on
industrial energy depth reset 298.15
industrial energy depth step 0.02 2200 140 20 900 0.1
industrial energy depth patch add wet-gravel gravel 0 50 -3 3 0.01 0.72 0.012 0.002 0 0.03 6000 0.4
industrial energy depth tire-puncture 0 0.000001
industrial energy depth tire-impact 1 500000 0.75
industrial energy depth hv-ground 2 1.5
industrial energy depth hv-ground-clear 2
industrial energy depth machine-fault phase-a-open
industrial energy depth machine-fault resolver-bias 0.02
industrial energy depth brake-leak 2 0.00000000001
industrial energy depth ecu-overrun inverter_control 12 0.02
industrial energy depth checkpoint baseline
industrial energy depth branch lower-demand baseline
industrial energy depth branch-select lower-demand
industrial energy depth counterfactual 0 wheel_torque_nm 250 reduced-demand
industrial energy depth replay
industrial energy depth replay-save vehicle_depth_replay.bin
industrial energy depth fidelity tire reduced
industrial energy depth fidelity tire detailed
industrial energy depth fidelity-auto on 0.65
industrial energy depth structure
industrial energy depth terrain
industrial energy depth tires
industrial energy depth hv
industrial energy depth drive
industrial energy depth aero
industrial energy depth brakes
industrial energy depth autosar
industrial energy depth checkpoints
industrial energy depth fidelity-report
```

The generic help response documents all arguments and accepted subcommands.

## 14. Published signal namespace

The industrial signal registry exposes:

```text
electrification.depth.time_s
electrification.depth.position_x_m
electrification.depth.position_y_m
electrification.depth.structure.maximum_stress_pa
electrification.depth.tire.longitudinal_force_n
electrification.depth.tire.lateral_force_n
electrification.depth.tire.maximum_wear
electrification.depth.tire.maximum_damage
electrification.depth.hv.bus_voltage_v
electrification.depth.hv.source_current_a
electrification.depth.drive.torque_nm
electrification.depth.drive.current_thd
electrification.depth.drive.inverter_temperature_k
electrification.depth.aero.drag_n
electrification.depth.aero.radiator_airflow_kg_s
electrification.depth.brake.total_torque_nm
electrification.depth.brake.fluid_temperature_k
electrification.depth.ecu.deadline_misses
electrification.depth.replay.events
electrification.depth.energy_residual_j
```

## 15. Verification coverage

`tests/vehicle_depth_tests.cpp` covers all ten feature areas, including structural response, terrain grids and material patches, hydroplaning and tire failure, HV faults and pyrofuse operation, switching and phase faults, six-axis aerodynamic response, brake hydraulics and judder, AUTOSAR execution and deadlines, deterministic replay, persistent replay archives, and fidelity transitions.

`tests/electrification_platform_tests.cpp` covers the direct facade and signal registry. `tests/electrification_platform_regression.py` exercises the same command surface through the compiled console executable.

## 16. Calibration and physical correlation

The implementation is an executable engineering model, not a claim of physical-vehicle correlation. Vehicle-specific use requires replacing default parameters with measured or supplier-provided data, including:

- flexible-body modal frequencies, masses, participation factors, damping, and stress-recovery matrices,
- road survey or terrain-grid data,
- tire stiffness, leakage, thermal, force, wear, and failure data,
- cable, busbar, contactor, fuse, capacitor, and isolation properties,
- motor flux and inductance maps, inverter device losses, and switching data,
- wind-tunnel or CFD aerodynamic maps and cooling-flow data,
- master-cylinder, valve, hose, caliper, pad, rotor, fluid, and wear parameters,
- ECU worst-case execution times and measured communication timing.

The defaults are deterministic, dimensionally explicit, bounded, and suitable for software verification, architecture exploration, and sensitivity studies.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


# Advanced Electrified-Vehicle Architecture

## Scope

This implementation adds an executable, integrated electrified-vehicle stack to MuzixDiagSys. It is not a collection of interfaces or placeholders: each subsystem advances state, enforces limits, reports diagnostics, and is covered by deterministic regression tests. Existing combustion-engine, hybrid, charging, thermal, six-degree-of-freedom, perception, federation, and console functionality remains available.

Primary files:

- `include/aesim/electrification/advanced_vehicle.hpp`
- `src/electrification/advanced_vehicle.cpp`
- `src/electrification/platform.cpp`
- `tests/advanced_electrified_vehicle_tests.cpp`
- `tests/electrification_platform_tests.cpp`

The models are engineering simulation models. They support requirements development, controller development, fault-injection, calibration, and virtual verification. They do not by themselves constitute regulatory homologation, ISO certification, cybersecurity certification, or a standards-conformance claim.

## Build and test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build -R "advanced_electrified_vehicle|electrification_platform" --output-on-failure
```

The dedicated executable is `advanced_electrified_vehicle_tests`.

## Console integration

The advanced stack is integrated under the existing industrial/electrification command path:

```text
industrial energy advanced status
industrial energy advanced auto on
industrial energy advanced auto off
industrial energy advanced architecture bev
industrial energy advanced architecture series
industrial energy advanced architecture parallel
industrial energy advanced architecture phev
industrial energy advanced architecture fuel-cell
industrial energy advanced payload set <id> <kg> <x_m> <y_m> <z_m> <longitudinal_restraint_n> [lateral_restraint_n] [compliance_m_n]
industrial energy advanced sotif aeb [generations]
industrial energy advanced network
industrial energy advanced sovd
industrial energy advanced ota
```

When automatic update is enabled, `ElectrificationPlatform::update()` advances the complete stack and publishes measurements through the existing signal registry. Published measurements include architecture, battery state of charge and voltage, delivered torque, brake split, rear steering, trailer articulation, tailpipe NOx, Ethernet frame count, durability, and digital-twin uncertainty.

## Requirement implementation matrix

### 1. Full electrified-powertrain architecture

`ElectrifiedPowertrain` composes the traction battery, BMS, front and rear e-axles, fuel-cell source, and combustion-engine/generator source. It performs a state-preserving power-balance solve before committing model state. A bounded binary search scales electric torque if the requested DC power exceeds BMS charge or discharge limits.

The power balance is reported as:

```text
dc_bus_energy_residual = battery_power + source_power
                       - e_axle_dc_power - fuel_cell_startup_heater_power
```

The result exposes requested and delivered torque, source requests, fuel and hydrogen rates, DC-link voltage, derating, and propulsion availability.

### 2. Electric machines, inverters, and e-axles

`ElectricEAxle` contains independent left and right `ElectricDrive` machine/inverter models. The e-axle implements:

- final-drive ratio and gear efficiency;
- independent left/right wheel speeds;
- yaw-moment torque vectoring;
- per-wheel traction-torque limits;
- motoring and regeneration efficiency maps;
- speed/temperature torque-limit maps;
- DC current, DC power, mechanical power, and loss accounting;
- machine and inverter thermal state inherited from `ElectricDrive`.

The map axes are clamped to the calibrated envelope and bilinearly interpolated by `GridMap2D`. Example files are supplied in:

- `data/e_machine_motoring_efficiency.csv`
- `data/e_machine_regeneration_efficiency.csv`
- `data/e_machine_torque_limit.csv`

### 3. Hydraulic brake-by-wire and regenerative blending

`BrakeByWireSystem` converts pedal demand to deceleration and wheel torque, then allocates regenerative and hydraulic friction braking subject to:

- e-axle regenerative torque availability;
- battery charge-power acceptance;
- low-speed regeneration fade-out;
- axle brake bias;
- line-pressure and caliper torque capacity;
- road-friction and normal-load limits;
- wheel-slip ABS modulation;
- disc thermal energy, convective cooling, and temperature-dependent fade;
- recovered electrical power and unmet brake torque.

Regeneration is therefore blended from actual instantaneous battery and traction constraints rather than from a fixed percentage.

### 4. Active chassis systems

`ActiveChassisSystem` implements active suspension, yaw control, and rear-wheel steering. It includes:

- low-speed opposite-phase and high-speed same-phase rear steering;
- speed-dependent continuous blending;
- steering angle and slew-rate limits;
- bicycle-model desired yaw rate;
- yaw-moment feedback from yaw-rate and sideslip error;
- body roll and pitch moment control;
- four-corner damper and actuator-force commands;
- actuator saturation reporting.

### 5. Vehicle E/E architecture and automotive networking

`AutomotiveEthernetNetwork` implements a deterministic in-process E/E network with distributed ECU configuration, bounded receive queues, per-ECU processing latency, service registration, priority queues, serialization delay, deadline tracking, and utilization statistics.

### 6. Detailed exhaust aftertreatment chemistry

`ExhaustAftertreatmentSystem` advances a coupled DOC/TWC/DPF/SCR model. It includes:

- separate thermal masses and heat loss for each brick;
- flow-coupled heat transfer through the catalyst train;
- temperature-dependent DOC CO/HC oxidation;
- equivalence-ratio-sensitive three-way catalyst conversion;
- DPF particulate capture, soot loading, pressure drop, and Arrhenius oxidation;
- passive/forced regeneration state;
- SCR urea-to-ammonia storage;
- finite-rate NOx reduction constrained by stored ammonia;
- ammonia slip;
- tailpipe CO, HC, NO, NO2, NH3, PM, and CO2 mass-flow output.

### 7. Trailer, payload, and load-shift dynamics

`TrailerPayloadDynamics` models:

- empty trailer and arbitrary payload item masses;
- static and shifted payload centers of gravity;
- longitudinal/lateral restraint limits;
- bounded compliant load shift with a time constant;
- hitch longitudinal force and trailer braking;
- lateral tire force and articulation/yaw dynamics;
- tongue and axle reactions using total empty-plus-payload center of gravity;
- articulation limits and jackknife-risk index.

### 8. Full BEV, hybrid, and fuel-cell powertrains

`ElectrifiedArchitecture` supports:

- `Bev`;
- `SeriesHybrid`;
- `ParallelHybrid`;
- `PlugInHybrid`;
- `FuelCell`.

Series-hybrid operation converts engine power through generator efficiency. Parallel and plug-in hybrid modes mechanically combine engine and electric wheel torque. PHEV source sharing is state-of-charge dependent. Fuel-cell operation balances stack output, battery buffering, traction demand, and cold-start heating.

### 9. Electrochemical battery pack and BMS

The existing electrothermal `BatteryPack` is used as the physical pack plant, with vehicle-scale defaults of 108 series by 36 parallel cells. `BatteryManagementSystem` adds:

- open/precharge/closed contactor states;
- RC precharge dynamics and timeout;
- service-disconnect and crash handling;
- cell under/over-voltage, thermal, current, isolation, contactor, and imbalance faults;
- debounce and hazardous-fault latching;
- filtered current request;
- pack-derived charge/discharge power limits;
- torque and charge enable decisions;
- cell balancing enable logic.

### 10. E-machine, inverter, and regeneration maps

`GridMap2D` validates monotonic axes, validates matrix dimensions and finite values, reads CSV maps, clamps out-of-range requests, and performs bilinear interpolation. Separate motoring efficiency, regeneration efficiency, and thermal torque-limit maps are applied by each e-axle.

### 11. Active suspension and rear-wheel steering

Implemented by `ActiveChassisSystem`; see requirement 4. Four independently commanded corner forces combine heave damping with anti-roll and anti-pitch forces. Rear steering uses speed-dependent phase and actuator dynamics.

### 12. Automotive Ethernet, SOME/IP, TSN, and distributed ECUs

The network model includes:

- configurable 100/1000 Mb/s-style link rates;
- Ethernet serialization overhead;
- eight priority queues;
- IEEE 802.1Qbv-style cyclic gate windows;
- SOME/IP header encode/decode with length validation;
- SOME/IP service-to-provider resolution;
- distributed ECU queues and processing delays;
- deadline misses, drops, latency, and utilization metrics.

This is a deterministic simulation model of the relevant behaviors; it is not a packet-socket implementation or formal protocol certification suite.

### 13. SOVD diagnostics and OTA lifecycle

`SOVDServer` provides authenticated entity discovery, metadata, fault read/clear, environment data, and registered operations through method/path requests.

`OtaLifecycleManager` implements:

```text
Idle -> Downloading -> Validating -> Staged -> Installing
     -> Verifying -> Active
```

It verifies payload size, SHA-256 digest, and the supplied manifest-signature validity decision; enforces stationary-vehicle and minimum-SOC installation gates; performs post-install ECU health checking; records failure causes; and supports rollback to the previous version.

### 14. Automated SOTIF scenario falsification

`SOTIFFalsifier` uses a deterministic seeded cross-entropy search. It samples a bounded scenario vector, evaluates an objective, retains an elite population, and updates the sampling mean and variance over generations.

The built-in AEB objective searches combinations of:

- ego and lead speed;
- initial range;
- sensor latency;
- relative acceleration;
- road friction;
- perception confidence;
- road grade.

The minimized objective is remaining stopping margin; negative margin represents a falsifying collision case in the simplified AEB model.

### 15. Regulatory battery, brake, and tire durability

`RegulatoryDurabilityMonitor` accumulates:

- elapsed time and distance;
- battery equivalent full cycles from absolute current throughput;
- battery thermal/calendar stress and capacity-fade fraction;
- brake friction energy and normalized wear;
- front/rear tire dissipated energy and normalized wear;
- tire thermal aging;
- battery, brake, and tire threshold flags.

These are durability-screening metrics suitable for virtual test campaigns. Regulatory acceptance still requires the applicable prescribed procedures, calibrated hardware, traceability, and authority review.

### 16. Online digital-twin assimilation and model-form uncertainty

`OnlineDigitalTwinAssimilator` performs sequential bounded parameter estimation for:

- vehicle mass scale;
- aerodynamic drag scale;
- rolling-resistance scale;
- battery internal-resistance scale.

It uses acceleration and battery-voltage innovations with covariance propagation, measurement updates, state bounds, and adaptive innovation-variance estimation. Outputs include parameter standard deviations, residuals, normalized innovation squared, and separate acceleration/voltage model-form uncertainty estimates.

## Integrated stepping order

`AdvancedElectrifiedVehicle::step()` performs the following coupled sequence:

1. Advance the electrified powertrain and BMS.
2. Update brake blending with actual regenerative and battery charge limits.
3. Advance active suspension, yaw control, and rear steering.
4. Advance trailer and payload dynamics.
5. Advance aftertreatment chemistry.
6. Advance durability exposure.
7. Assimilate digital-twin measurements.
8. Publish powertrain/BMS information over the deterministic SOME/IP/TSN network.
9. Report diagnostic faults through SOVD when hazardous BMS faults are active.
10. Advance OTA lifecycle preconditions and state.

## Programmatic example

```cpp
#include "aesim/electrification/advanced_vehicle.hpp"

using namespace aesim::electrification;

AdvancedElectrifiedVehicle vehicle;
vehicle.set_architecture(ElectrifiedArchitecture::PlugInHybrid);
vehicle.set_payload({{
    "cargo", 250.0, 1.2, 0.0, 0.55,
    12000.0, 10000.0, 1.0e-5
}});

AdvancedElectrifiedVehicleInput input;
input.powertrain.key_on = true;
input.powertrain.requested_wheel_torque_nm = 1800.0;
input.powertrain.wheel_speed_rad_s.fill(55.0);
input.powertrain.engine_available_power_w = 90000.0;
input.braking.vehicle_speed_m_s = 18.15;
input.braking.wheel_speed_rad_s.fill(55.0);
input.braking.normal_load_n.fill(4200.0);
input.braking.road_mu.fill(0.9);
input.chassis.speed_m_s = 18.15;
input.trailer.tow_vehicle_speed_m_s = 18.15;

for (int sample = 0; sample < 1000; ++sample) {
    const auto output = vehicle.step(input, 0.01);
    // Consume output.powertrain, output.braking, output.chassis, etc.
}
```

## Calibration-map CSV format

The first row contains the x-axis. The first column of each subsequent row contains the y-axis. Remaining entries are row-major surface values:

```text
y_axis_name,x0,x1,x2
 y0,v00,v01,v02
 y1,v10,v11,v12
```

Axes must be strictly increasing. Values and axes must be finite. Queries outside the envelope are clamped rather than extrapolated.

## Verification coverage

`advanced_electrified_vehicle_tests.cpp` exercises:

- map interpolation and CSV parsing;
- contactor precharge and BMS isolation faults;
- e-axle motoring, regeneration, and torque vectoring;
- fuel-cell power, reactant use, and tank depletion;
- BEV, series-hybrid, and FCEV source behavior;
- DC-bus energy residual;
- regenerative/friction blending and ABS;
- rear steering and active suspension;
- payload restraint violation, load shift, tongue load, and axle load;
- DOC/TWC/DPF/SCR conversion;
- SOME/IP encoding, service routing, TSN delivery, and statistics;
- SOVD fault read/clear;
- OTA validation, activation, and rollback;
- SOTIF falsification search;
- battery/brake/tire durability accumulation;
- online digital-twin assimilation;
- complete integrated vehicle stepping.

`electrification_platform_tests.cpp` additionally verifies the console facade, architecture switching, automatic stepping, advanced measurements, payload command, SOTIF command, and network/SOVD/OTA status commands.

## 2026-07-12 next-generation vehicle-depth integration

The electrified architecture now exchanges DC demand, protection state, switching-machine torque, cooling flow, brake torque, and structural loads with the vehicle-depth runtime.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


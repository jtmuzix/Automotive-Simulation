# MuzixDiagSys Assurance Platform

This additive C++17 platform implements production-oriented AUTOSAR, diagnostics, cybersecurity, safety, eFMI, ODS/ATFX, MC/DC, and temporal verification capabilities while preserving all existing simulator features.

## Modules

- `include/aesim/assurance/assurance.hpp`
- `src/assurance/assurance.cpp`
- `tests/assurance_core_tests.cpp`
- `tests/assurance_platform_regression.py`

## Command root

All capabilities are available under `industrial assurance`.

Examples:

```text
industrial assurance autosar import data/assurance_swc.arxml
industrial assurance diagnostics odx import data/assurance_diagnostics.odx
industrial assurance diagnostics otx data/assurance_sequence.otx
industrial assurance adaptive offer 0x1234 1 1 1000
industrial assurance cyber run data/assurance_cyber_campaign.yaml
industrial assurance safety load data/assurance_safety.yaml
industrial assurance efmi generate data/assurance_efmi.yaml generated/efmi
industrial assurance ods open results/ods.db
industrial assurance verify mcdc data/assurance_mcdc.csv
industrial assurance verify temporal data/assurance_trace.csv data/assurance_temporal.yaml counterexample.json
```

The implementation is a standards-oriented operational profile. It does not claim independent AUTOSAR, ASAM, ISO, or eFMI conformance certification.

## 2026-07-12 next-generation vehicle-depth integration

Assurance workflows can now use replay branches, state hashes, conservation corrections, deadline statistics, protection events, tire damage, and structural stress as evidence channels.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


# NASCAR Next-Generation Engineering and Operations Platform

> **2026-07-28 additive assurance module:** The separate `nascar-assurance` command and `NascarEngineeringAssurancePlatform` add regulation digital-thread resolution, dynamic compliance, prospective-OEM management, timing observation fusion, officiating policy analysis, progressive contact damage, crash/SAFER elements, fire/rescue hazards, debris recovery, composite manufacturing, fleet reliability, and optimal test design. Existing contracts in this guide are unchanged. See `docs/NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 59 of the user manual.
**Revision:** 2026-07-23  
**Library:** `aesim_nascar`  
**Public header:** `aesim/advanced/nascar_next_generation_platform.hpp`  
**Aggregate command family:** `nascar`

This platform adds ten production NASCAR domains to the existing competition,
ecosystem, and frontier modules. The aggregate registry contains 40 domains.
Every request is validated before execution, every numerical report is finite
and deterministic for identical input, and every result contains a SHA-256
`evidence_digest` calculated from canonical JSON.

## Additive NASCAR integrated-fidelity module

The 2026-07-27 source tree also provides the separate `nascar-integrated` command and `NascarIntegratedFidelityPlatform`. Its twelve domains add deterministic multi-rate co-simulation, telemetry assimilation/calibration, unified uncertainty and model-validity supervision, a 28-DOF flexible vehicle, detailed asymmetric tire construction/contact, unsteady aeroelastic wakes and flaps, closed-loop ECU/driveline control, cranktrain/dry-sump/fuel/thermal systems, a multi-car pit-road twin, occupant heat/egress, scanned pavement mechanics, and spray/optical visibility. These domains are additive and do not change this guide's existing `nascar` command contracts. See `docs/NASCAR_INTEGRATED_FIDELITY_PLATFORM.md` and Chapter 58 of the user manual.

## Public API

```cpp
#include "aesim/advanced/nascar_next_generation_platform.hpp"

using aesim::advanced::nascar::NascarNextGenerationPlatform;
using aesim::doc::Value;

NascarNextGenerationPlatform platform;
Value registry = platform.capabilities();
Value report = platform.execute("electrified-stock-car", request, "evidence");
Value qualification = platform.self_test("evidence/self-test");
```

The same domains are routed through `NascarCompetitionPlatform` and the CLI:

```bash
muzixdiagsys_advanced_platform nascar DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Exit code `0` means the request executed and passed its gates. Exit code `2`
means the request was valid but failed one or more qualification gates. Exit
code `1` means malformed input or an execution error.

## 1. Electrified stock-car, hybrid, and EV architecture laboratory

**Domain:** `electrified-stock-car`  
**Evidence:** `nascar_electrified_stock_car.json`

Supported architectures are `battery-electric`, `series-hybrid`,
`parallel-hybrid`, and `power-split`. The request defines vehicle road load,
a series/parallel battery pack, one or more front/rear motors, optional engine
parameters, and a time-domain drive cycle.

The model computes:

- aerodynamic, rolling, grade, and inertial tractive force;
- axle-specific motor torque-speed envelopes and field-weakening power limits;
- motor and inverter conversion losses;
- battery open-circuit voltage, resistance, terminal voltage, pack current,
  current-limited power, energy-limited power, SOC, heat generation, and exact
  first-order cooling;
- regenerative-braking capture and residual friction-brake energy;
- hybrid engine contribution, shaft energy, and fuel consumption;
- unmet tractive energy, thermal margins, power parity, and deterministic
  component evidence.

Pack charge and discharge are bounded by both current and available stored
energy. Long regeneration segments cannot overcharge the battery, and long
discharge segments cannot consume negative energy. Reported motor wheel power
is reduced whenever current, voltage, SOC, or torque-speed limits prevent the
requested electrical power from being delivered.

## 2. Cylinder-resolved V8 combustion and sustainable-fuel laboratory

**Domain:** `v8-combustion-fuel`  
**Evidence:** `nascar_v8_combustion_fuel.json`

The laboratory requires an eight-cylinder pushrod-engine definition, fuel
properties, and one or more operating points. It resolves:

- displacement, mean piston speed, intake density, tapered-spacer velocity and
  pressure loss, manifold pressure, and volumetric airflow;
- fuel flow from stoichiometric ratio and equivalence ratio;
- latent-heat charge cooling and combustion efficiency;
- indicated power, friction MEP, brake power, torque, BMEP, and BSFC;
- normalized cylinder-to-cylinder flow variation, cylinder IMEP, peak pressure,
  fuel and air flow, and exhaust temperature;
- compression, spark, temperature, octane, and mixture contributions to knock;
- valvetrain inertia, spring force, contact stress, exhaust-temperature limits,
  homologation power bands, and lifecycle fuel carbon intensity.

Invalid cylinder count, geometry, fuel properties, flow factors, operating
points, or homologation limits are rejected before any evidence file is written.

## 3. Next Gen aerodynamic raceability and rules-package laboratory

**Domain:** `aero-raceability`  
**Evidence:** `nascar_aero_raceability.json`

Each candidate package contains body drag/lift, spoiler, diffuser, splitter,
wake, side-draft, yaw, and frontal-area parameters. Each scenario specifies
track class, speed, corner radius, following gap, overlap, yaw, wall distance,
power, and field density.

The solver evaluates leader drag/downforce, following-car wake loss, tow drag
reduction, wall and yaw corrections, side-draft penalty, lateral acceleration
margin, closing-power advantage, pass probability, multi-lane score, liftoff
speed/margin, manufacturer spread, and a weighted raceability score. It selects
the highest-scoring package that meets liftoff and parity constraints. If no
package qualifies, `recommended_package` is JSON `null`.

## 4. Full-field multi-agent racecraft and strategy engine

**Domain:** `full-field-racecraft`  
**Evidence:** `nascar_full_field_racecraft.json`

The engine supports fields from 2 to 60 drivers on short tracks, intermediates,
superspeedways, road courses, and street courses. Driver agents carry pace,
aggression, tire management, restart skill, fuel-saving skill, reliability,
pit interval, fuel window, and service-time parameters.

For every lap it executes:

- exact conversion of race-finish reliability into per-lap failure probability;
- traffic, draft, blocking, restart, random pace, tire falloff, and fuel-saving
  effects;
- green-flag and caution pit strategies with separate pit-lane losses;
- scheduled stages and stage points;
- deterministic incident generation, damage time, and retirement;
- end-of-lap classification and pairwise order-inversion analysis;
- exclusion of pit-cycle and retirement changes from green-flag overtake totals;
- caution field compression and complete lap/classification evidence.

A supplied random seed makes the entire race and evidence digest reproducible.

## 5. Remote race-control multimodal fusion center

**Domain:** `remote-race-control`  
**Evidence:** `nascar_remote_race_control.json`

Video, telemetry, radio, and timing observations use a common event identifier,
time, incident type, car set, confidence, source reliability, latency, and
unique evidence reference. The center performs latency-aware weighted fusion,
event-time synchronization, vehicle-pair attribution, incident prioritization,
rule selection, recommendation generation, and cryptographically chained audit
records.

Network channels model local/remote placement, availability, packet loss,
latency, and authentication. Independent channel availability is combined to
assess local/remote failover. Unauthenticated channels or insufficient combined
availability fail qualification. The platform recommends evidence and action;
it does not remove human officiating authority.

## 6. Temporary street-course and special-venue operations twin

**Domain:** `temporary-venue`  
**Evidence:** `nascar_temporary_venue.json`

The venue twin qualifies a temporary site against physical, operational, and
schedule constraints. It computes:

- installed barrier and debris-fence coverage and gaps;
- pit-box and paddock capacity;
- pedestrian evacuation throughput and maximum evacuation time;
- unblocked medical/recovery-route availability;
- peak and essential electrical loads, source capacity, and backup energy;
- communication coverage, capacity, independent backhaul count, and latency;
- dependency-resolved construction critical path and project cost;
- rainfall/drainage water balance and peak water depth;
- course grade and available construction-window compliance.

Construction tasks are topologically scheduled even when declared out of order.
Unknown dependencies, self-dependencies, and cycles are rejected.

## 7. Brake, steering, wheel-end, and single-lug durability laboratory

**Domain:** `wheel-end-durability`  
**Evidence:** `nascar_wheel_end_durability.json`

Exactly four wheel corners are modeled. The duty cycle integrates braking,
speed, deceleration, lateral acceleration, steering angle, road roughness,
vibration, and regenerative/friction brake split.

Per-corner outputs include disc, fluid, and bearing thermal states; convection;
pad wear; thermal/load fatigue damage; remaining life; single-lug clamp force
and margin after thermal/vibration relaxation; and steering-rack force. Exact
first-order cooling prevents numerical thermal undershoot or instability during
long segments.

## 8. NASCAR electrical/electronic architecture and cyber-physical twin

**Domain:** `electrical-cyberphysical`  
**Evidence:** `nascar_electrical_cyberphysical.json`

The model represents electrical nodes, criticality, power demand, voltage
requirements, signed firmware identity, harness resistance/current ratings,
communication buses, periodic messages, priorities, payloads, and injected
faults.

It calculates source sag, bus voltage, branch current/drop, overcurrent,
communication utilization and response time, critical-node availability,
firmware authenticity, and detected open/short/brownout, bus-flood, replay,
sensor-spoof, and firmware-tamper conditions. Critical-node unavailability,
firmware authentication failure, or overloaded buses fail qualification.

## 9. Race-engineering intelligence and causal setup optimizer

**Domain:** `race-engineering-intelligence`  
**Evidence:** `nascar_race_engineering_intelligence.json`

The optimizer accepts observed laps, selected setup features, traffic loss, fuel
mass, track temperature, and candidate setups. It normalizes lap time for
traffic, fuel, and track-temperature effects, standardizes setup variables, and
fits a ridge-regularized linear response model through pivoted Gaussian
elimination.

Outputs include model RMSE, standardized and physical-unit effects, candidate
lap-time predictions, uncertainty penalties, feature contributions, explicit
constraint violations, and the best feasible setup. A large configurable
constraint penalty prevents an infeasible candidate from being recommended over
an otherwise valid setup.

The model is an engineering decision aid. Correlation, data coverage, residuals,
and controlled intervention design remain part of the qualification evidence.

## 10. Broadcast, streaming, and digital fan-experience twin

**Domain:** `broadcast-streaming`  
**Evidence:** `nascar_broadcast_streaming.json`

The platform models camera type, zone coverage, reliability and latency;
battles/incidents; automated shot selection; replay packages; stream profiles;
users and bitrate; CDN regions; effective capacity; availability; latency;
independence; and delivery cost.

It calculates selected-camera scores, uncovered events, replay priority, total
stream demand, effective CDN capacity, load, buffering, end-to-end latency,
quality-of-experience score, profile allocation, regional redundancy, and
estimated hourly cloud cost. Missing event coverage, overload, excess latency,
low QoE, or insufficient independent regions fails qualification.

## Build and validation

```bash
cmake -S . -B build/nascar -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/nascar --parallel --target \
  aesim_nascar \
  nascar_competition_platform_tests \
  nascar_ecosystem_platform_tests \
  nascar_frontier_platform_tests \
  nascar_next_generation_platform_tests
ctest --test-dir build/nascar --output-on-failure \
  -R '^nascar_.*_platform_unit_tests$'
python3 tests/nascar_next_generation_source_regression.py .
python3 tests/documentation_consistency_regression.py .
```

Sanitizer configuration:

```bash
cmake -S . -B build/nascar-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF
cmake --build build/nascar-sanitize --parallel --target \
  nascar_next_generation_platform_tests
ctest --test-dir build/nascar-sanitize --output-on-failure \
  -R '^nascar_next_generation_platform_unit_tests$'
```

## Qualification boundaries

The platform is suitable for research, design comparison, virtual testing,
operator training, requirements analysis, and evidence generation. Results do
not by themselves approve a vehicle, rules package, venue, officiating action,
electrical system, broadcast service, or competition format. Physical testing,
calibrated measurement, official NASCAR procedures, current regulations,
supplier data, and competent engineering/officiating review remain required.

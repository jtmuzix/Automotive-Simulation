# Simulation Assurance, Resilience, and Reproducibility Framework

## Purpose

The Simulation Assurance, Resilience, and Reproducibility (SARR) framework is an additive cross-cutting runtime service for MuzixDiagSys. It does not replace the simulator, its command line, existing checkpoint formats, vehicle models, fault laboratories, or mathematical-assurance APIs. It connects them through a common operational contract for deterministic fault injection, transactional recovery, causal error evidence, conservation closure, numerical trust evidence, semantic result caching, and tamper-evident run manifests.

The command line remains the authoritative control surface. F7 beginner-menu actions invoke the same `industrial assurance ...` command dispatcher used by typed commands.

## Architecture

The public C++ entry point is:

```cpp
#include "aesim/assurance/resilience.hpp"

aesim::assurance::resilience::SimulationAssuranceFramework framework;
```

`AssurancePlatform` owns one framework instance. `IndustrialPlatform` binds the industrial signal registry into its hierarchical checkpoint tree and routes production industrial commands through the deterministic chaos guard. Therefore fault rules can act on real command execution, and recovery checkpoints can restore real industrial signal state.

The framework contains six cooperating services:

1. `DeterministicChaosEngine`
2. `HierarchicalCheckpointManager`
3. `ErrorProvenanceGraph`
4. `CrossSubsystemConservationLedger`
5. `NumericalEvidenceRegistry`
6. `SemanticResultCache`

A seventh orchestration surface, `SimulationAssuranceFramework`, produces integrated status, operation guards, manifests, and SHA-256-sealed certificates.

## Deterministic fault injection and chaos

Rules identify a subsystem and operation. Either field may be `*`. Supported effects are `fail`, `exception`, `delay`, `drop`, `corrupt`, and `resource-exhaustion`. Supported triggers are invocation count, simulation time, event, and seeded probability.

Probability decisions are derived deterministically from the configured 64-bit seed, rule identity, and decision sequence. Resetting a campaign and replaying the same call sequence therefore produces the same decisions.

Examples:

```text
industrial assurance chaos seed 424242
industrial assurance chaos add drop-write industrial.signal set drop invocation 3
industrial assurance chaos add sensor-bias industrial.signal set corrupt invocation 1 bias 0.05
industrial assurance chaos status
industrial assurance chaos reset
industrial assurance chaos clear
```

A production command that is dropped returns an explicit deterministic-chaos result and is not forwarded to the underlying subsystem. Numeric corruption is applied before normal signal validation, so a corrupted value must still satisfy the signal contract or the ordinary command fails.

`AssurancePlatform` commands themselves are deliberately outside the production-command guard. This preserves the operator's ability to inspect, disable, and recover from a fault campaign.

## Hierarchical checkpoint and transactional recovery

Checkpoint components register a hierarchical path, capture callback, restore callback, and restore order. A checkpoint captures all registered components and stores a SHA-256 digest for each component plus an aggregate digest.

The default framework registers:

```text
assurance.errors
assurance.chaos
assurance.conservation
assurance.numerics
assurance.cache
industrial.signals
```

The last component is registered by `AssurancePlatform` and restores the real industrial signal registry.

Create and inspect checkpoints with:

```text
industrial assurance checkpoint create pre-test
industrial assurance checkpoint list
industrial assurance checkpoint verify <checkpoint-id>
industrial assurance checkpoint save <checkpoint-id> checkpoint.json
industrial assurance checkpoint load checkpoint.json
industrial assurance checkpoint restore <checkpoint-id>
industrial assurance checkpoint restore <checkpoint-id> assurance.chaos
```

Restore is transactional. Before applying a checkpoint, the manager captures the current state of every affected component. If any restore callback fails after partially mutating its component, that component and every previously attempted component are restored in reverse order. The `RestoreReport` explicitly records whether rollback was attempted and whether it succeeded.

Scope is hierarchical. Restoring `assurance` applies all `assurance.*` components; restoring `assurance.chaos` applies only that component.

## Structured error taxonomy and provenance graph

Every error occurrence references a registered taxonomy code and records subsystem, operation, message, UTC timestamp, optional state SHA-256, structured context, and zero or more causal occurrence IDs.

Framework taxonomy includes:

```text
ERR-ASSURANCE-FAULT
ERR-ASSURANCE-CONSERVATION
ERR-ASSURANCE-NUMERICAL
ERR-ASSURANCE-RECOVERY
```

Commands:

```text
industrial assurance error catalog
industrial assurance error list
industrial assurance error record ERR-ASSURANCE-FAULT operator test manual-event
industrial assurance error trace <occurrence-id>
industrial assurance error clear
```

`trace` walks the causal graph while preventing cycles in traversal. Unknown error codes and nonexistent causal references are rejected when recording an occurrence.

## Cross-subsystem conservation ledger

The ledger is dynamic: quantities are not limited to a fixed vehicle-domain enumeration. Each conserved quantity has a unit plus absolute and relative closure tolerance. Default quantities are energy, mass, charge, linear momentum, and angular momentum.

A step uses stored-state change, external rates, and signed inter-domain transfer rates. Transfers are entered once and automatically appear with opposite sign in source and destination domains.

Example:

```text
industrial assurance conservation reset 0
industrial assurance conservation storage engine energy 100000
industrial assurance conservation storage battery energy 0
industrial assurance conservation transfer engine battery energy 1000
industrial assurance conservation storage engine energy 99000
industrial assurance conservation storage battery energy 1000
industrial assurance conservation close 1
```

Rates cannot be recorded for a domain/quantity until its storage state has been initialized. This prevents a missing storage term from silently disappearing from closure accounting.

## Numerical provenance and confidence-aware results

`NumericalEvidence` records result value/unit, uncertainty, confidence, algorithm, solver, precision, residual, tolerance, condition estimate, iteration count, convergence, validity-domain status, provenance links, and SHA-256 input/result identity.

The registry derives a trust score and classifies each result as `HIGH`, `MEDIUM`, `LOW`, or `REJECT`. Nonfinite, nonconverged, or out-of-validity results are rejected. Result IDs are deterministic when the caller omits an ID.

Example:

```text
industrial assurance numerics record brake-temp brake_temperature 800 degC 0.1 0.99 BDF 1e-10 1e-6 20 53
industrial assurance numerics get brake-temp
industrial assurance numerics status
industrial assurance numerics export numerical-evidence.json
```

Rejected evidence is also recorded in the structured error graph.

## Semantic result caching and incremental recalculation

Cache identity is derived from:

- namespace;
- canonical input-document SHA-256;
- canonical settings-document SHA-256;
- named semantic dependency hashes.

Changing a semantic dependency invalidates only entries that declared that dependency. Tags and namespaces provide explicit invalidation scopes. `get_or_compute` performs real incremental recalculation: it returns an existing valid result when possible and runs the supplied computation only after a miss or dependency invalidation.

Example:

```text
industrial assurance cache dependency vehicle.model model-v1
industrial assurance cache put lap-time inputs.json settings.json result.json vehicle.model baseline
industrial assurance cache status
industrial assurance cache save cache.json
industrial assurance cache load cache.json
industrial assurance cache invalidate dependency vehicle.model
```

Loaded cache files are integrity checked. Entry dependency hashes must agree with the cache dependency registry, and each stored semantic key is recomputed before acceptance.

## Reproducibility manifests and certificates

The framework manifest combines chaos state, error evidence, checkpoint index, conservation state, numerical evidence, and cache state under schema:

```text
aesim.simulation-assurance-resilience-reproducibility.v1
```

The canonical JSON content is sealed with SHA-256.

```text
industrial assurance framework certificate run-certificate.json qualification-run
industrial assurance framework verify run-certificate.json
```

Changing authenticated content without updating the digest is detected. Formatting-only whitespace does not invalidate a certificate because verification hashes canonical JSON semantics rather than raw bytes.

## Beginner menus and permanent CLI

F7/Alt-M beginner menus expose read-only assurance entry points under Analyze and Validate, including Numerical confidence, Conservation ledger, Assurance health, Recovery checkpoints, and Fault injection status. These items generate the same canonical CLI commands shown above. `Tab` inserts the generated command into the persistent command line for editing; `Enter` executes through the normal dispatcher.

No assurance capability requires the beginner menus, and no menu path bypasses the CLI command implementation.

## Qualification

Focused qualification targets are:

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --target assurance_resilience_tests muzixdiagsys -j
./build/assurance_resilience_tests
python3 tests/assurance_resilience_cli_regression.py ./build/muzixdiagsys .
```

The adversarial unit suite covers deterministic replay, numeric corruption, rollback after partial mutation, causal traces, balanced/unbalanced conservation, numerical trust rejection, dependency-driven cache invalidation and recalculation, real industrial-signal restoration, production command guards, certificate integrity, and tamper detection.

## V17 dependency-aware incremental simulation

`IncrementalSimulationGraph` orchestrates dependency ancestors through the existing `SemanticResultCache`. Canonical upstream values, settings, and semantic dependencies form each key, so unchanged branches are reused and source changes invalidate only affected descendants.

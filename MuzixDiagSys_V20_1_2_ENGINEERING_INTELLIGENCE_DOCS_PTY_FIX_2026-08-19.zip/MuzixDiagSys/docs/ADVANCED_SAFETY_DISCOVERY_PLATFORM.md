# MuzixDiagSys Advanced Safety Discovery Platform

## Purpose

The advanced safety discovery platform integrates automated hazard discovery, counterfactual remediation, formal analysis, runtime assurance, resilient control synthesis, deterministic distributed execution, digital-twin assimilation, uncertainty management, and evidence persistence into the existing MuzixDiagSys research and industrial simulation stack.

The implementation is exposed through:

- `include/aesim/research2/advanced_safety_platform.hpp`
- `src/research2/advanced_search_diagnostics.cpp`
- `src/research2/advanced_assurance_control.cpp`
- `src/research2/advanced_execution_twin.cpp`
- `tools/advanced_safety_cli.cpp`
- `tests/advanced_safety_platform_tests.cpp`

All components are linked into `aesim_industrial`. Existing libraries, executables, APIs, plugins, file formats, and command surfaces remain available.

## Build and run

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build -j
ctest --test-dir build -R 'advanced_safety|causal_simulation|research2_platform' --output-on-failure
```

List the installed capabilities:

```bash
./build/muzixdiagsys_advanced_safety capabilities
```

Run the deterministic integration smoke test:

```bash
./build/muzixdiagsys_advanced_safety self-test
```

Start an interactive reverse-debugging session over a generated reference timeline:

```bash
./build/muzixdiagsys_advanced_safety debugger
```

Load a persisted time-travel timeline:

```bash
./build/muzixdiagsys_advanced_safety debugger results/timeline.json
```

## 1. Search-guided scenario falsification

`SearchGuidedScenarioFalsifier` minimizes requirement robustness using a deterministic hybrid search:

1. Cross-entropy population sampling over bounded continuous or integer variables.
2. Constraint-violation penalties.
3. Elite-distribution adaptation with variance floors and smoothing.
4. Deterministic coordinate pattern-search refinement.
5. Counterexample de-duplication by trace hash or canonical parameter key.
6. Reproducible per-evaluation seeds independent of the evaluator's internal random use.

A negative robustness value denotes a falsified requirement. The result includes the best candidate, a bounded counterexample archive, objective history, evaluation count, metrics, and trace identifiers.

```cpp
SearchGuidedScenarioFalsifier falsifier;
FalsificationConfiguration cfg;
cfg.population = 64;
cfg.generations = 40;
cfg.seed = 42;

std::vector<FalsificationVariable> variables{
    {"road_friction", 0.1, 1.1, 0.8, 1.0, false},
    {"radar_latency_s", 0.0, 0.5, 0.04, 1.0, false}
};

falsifier.configure(variables, cfg,
    [](const std::vector<double>& x, std::uint64_t seed) {
        FalsificationEvaluation e;
        e.robustness = run_scenario_and_return_stl_robustness(x, seed);
        e.constraint_violations = validate_scenario_constraints(x);
        e.trace_hash = current_trace_hash();
        return e;
    });

auto result = falsifier.run();
```

## 2. Counterfactual intervention planner

`CounterfactualInterventionPlanner` enumerates feasible intervention sets up to a configured cardinality and evaluation budget. It enforces prerequisite and mutual-exclusion relationships, evaluates each set through a user-supplied counterfactual replay, and ranks plans by hazard probability, residual loss, performance degradation, cost, and response latency.

The planner returns:

- Ranked feasible plans.
- Pareto-optimal plans.
- Minimal intervention sets meeting the target hazard probability.
- Baseline outcome and evaluation count.

The evaluator can directly branch the deterministic time-travel debugger, apply interventions, replay the scenario, and return the resulting hazard probability and loss.

## 3. Cross-domain fault-propagation graph

`CrossDomainFaultPropagationGraph` represents faults across physical, electrical, thermal, software, network, sensor, actuator, cybersecurity, diagnostic, and safety domains.

The dynamic propagation engine supports:

- Node priors and recovery rates.
- Probabilistic, delayed, attenuated edges.
- Conditional propagation through another node.
- Noisy-OR aggregation of concurrent causes.
- Time-indexed probability histories.
- Dominant parent and causal-path extraction.
- Exact minimal cut-set enumeration up to a configured order.

The graph accepts cycles because propagation is performed over discrete time rather than through a static acyclic Bayesian network.

## 4. Statistical regression gate

`StatisticalRegressionGate` compares baseline and candidate sample distributions. It computes:

- Mean and sample standard deviation.
- 95th percentile.
- Relative shifts with absolute floors.
- Two-sample Kolmogorov-Smirnov distance.
- Asymptotic KS probability.
- Seeded bootstrap confidence interval for the mean difference.

Each metric can be treated as two-sided or as a lower-is-better performance measure. A gate fails when any configured threshold is violated.

This is intended for solver timing, energy use, stopping distance, perception error, tail risk, and other stochastic or repeated-run regression signals.

## 5. Interactive time-travel debugger

`InteractiveTimeTravelDebugger` adds an operator command session over `DeterministicTimeTravelDebugger`.

Supported commands:

```text
status | where
step | s
reverse-step | rs
continue | c
reverse-continue | rc
rewind SEQUENCE
history [COUNT]
print SIGNAL
watch SIGNAL
unwatch SIGNAL
break SIGNAL OP VALUE
breakpoints
delete BREAKPOINT_ID
branch NAME [SEQUENCE]
switch NAME
branches
quit
```

Breakpoints operate on state or input values and support `==`, `!=`, `>`, `>=`, `<`, and `<=`. Continue and reverse-continue traverse already-recorded history deterministically and stop at the first matching breakpoint.

## 6. Assumption and validity-domain registry

`AssumptionValidityRegistry` records explicit model validity rules:

- Model and signal identity.
- Unit.
- Minimum and maximum supported values.
- Approved operating modes.
- Severity.
- Rationale and evidence.
- Enabled state.

Runtime assessment reports unavailable signals, non-finite values, range violations, and invalid modes. Error and fatal violations invalidate the composed model result. Per-model credibility is computed from the proportion of satisfied enabled rules.

The registry persists as JSON through atomic document replacement.

## 7. Runtime assurance and safety shields

`RuntimeAssuranceSafetyShield` supervises a primary controller with an independent fallback controller and predictive plant model.

For every control decision it:

1. Predicts the primary action over the configured horizon.
2. Evaluates all safety margins at each prediction step.
3. Accepts the primary action when the required margin is preserved.
4. Otherwise evaluates the fallback action.
5. Uses deterministic bisection to find the least-restrictive safe blend between fallback and primary actions.
6. Optionally latches full fallback until explicitly reset.

The result records the primary and safe actions, blend factor, limiting constraint, minimum predicted margin, intervention status, and predicted state trace.

## 8. Formal reachability

`FormalReachabilityEngine` wraps the existing interval hybrid reachability analyzer and augments it with barrier-certificate checks.

The engine supports:

- Affine hybrid modes.
- Guarded transitions and reset maps.
- Invariants and unsafe sets.
- Interval initial states and bounded disturbances.
- Reachable-box histories and counterexamples.
- Barrier values and Lie-derivative margins over reachable-box vertices.
- SHA-256 proof digests over the resulting certificate summary.

For dimensions up to 12, every box vertex is checked. Higher-dimensional boxes use the center and every coordinate-axis extremum to keep the check bounded; the resulting certificate reports the exact method through the retained reachable boxes and margins.

## 9. Resilient-controller synthesis

`ResilientControllerSynthesizer` performs robust multi-scenario parameter synthesis using deterministic cross-entropy optimization.

The objective combines:

- Weighted average performance and control effort.
- Configurable worst-case emphasis.
- Safety-violation penalties.
- Instability penalties.

The final result includes controller parameters, robust objective history, worst safety violation, worst scenario, and a complete validation map for every configured scenario.

## 10. Event-sensitive differentiable simulation

`EventSensitiveDifferentiableSimulator` differentiates hybrid trajectories containing mode switches and reset events.

Implemented mechanics include:

- RK4 integration of state and forward parameter sensitivities.
- Analytic or central finite-difference state and parameter Jacobians.
- Directed guard-crossing detection.
- Sub-step event-time interpolation.
- Reset-state and reset-parameter Jacobians.
- Saltation matrices.
- Event-time contribution to post-event parameter sensitivity.
- Remaining-step integration in the destination mode.
- Terminal gradients.
- Central finite-difference gradient validation.

Grazing events with a nearly singular guard-flow denominator are rejected explicitly rather than returning unreliable derivatives.

## 11. Executable safety-case graph

`ExecutableSafetyCaseGraph` models claims, strategies, evidence, assumptions, context, and justifications.

Features include:

- Typed nodes and support relationships.
- Acceptance and confidence propagation.
- Unsupported-claim detection.
- Cycle detection.
- Artifact/hash linkage.
- Automatic stale-evidence propagation when an artifact changes.
- Atomic JSON persistence.

A top claim is accepted only when its complete support chain is accepted, current, acyclic, and non-empty.

## 12. Requirement-to-risk coverage

`RequirementRiskCoverageAnalyzer` combines requirements and evidence using risk weights derived from severity, exposure, and controllability.

Coverage contributions are combined as independent residual-uncovered probabilities:

```text
coverage = 1 - product(1 - operating_domain_weight * effectiveness)
```

The analyzer also checks explicit expected failure modes and reports uncovered modes. The system-level score is risk-weighted, preventing low-risk test volume from masking untested high-risk requirements.

## 13. Distributed deterministic runtime

`DistributedDeterministicRuntime` executes dependency graphs across configured worker capacities while preserving deterministic behavior.

Properties:

- Unique task and worker identities.
- Cycle-checked dependency graphs.
- Deterministic Kahn topological levels.
- Stable lexicographic task ordering.
- Stable worker-slot assignment.
- Seed derivation from master seed and task ID using SHA-256.
- Per-task retry limits.
- Dependency-failure propagation.
- Level-boundary checkpoint persistence.
- Result ordering independent of completion timing.
- Aggregate result hashes.

The executor callback can invoke an in-process worker, a local subprocess, an SSH job launcher, a cluster queue, or an existing federation adapter. Determinism is defined by task identity and payload rather than arrival order.

## 14. Deterministic GPU and heterogeneous execution

`DeterministicGpuExecutor` audits the existing `HeterogeneousCompute` backends, including CPU scalar, deterministic CPU-threaded, Vulkan, SYCL, and ROCm/HIP where available.

For each request it:

- Executes a CPU-scalar reference.
- Executes the requested or best available backend repeatedly.
- Hashes each backend result.
- Verifies repeatability.
- Compares results using bitwise, platform, tolerance, or statistical reproducibility policy.
- Records the backend, device, numerical environment, and environment hash.

Unsupported or unavailable GPU backends remain explicitly unavailable through the existing backend registry; the auditor does not silently claim GPU execution when only CPU execution occurred.

## 15. Online digital-twin assimilation

`OnlineDigitalTwinAssimilator` implements joint state and parameter estimation through an augmented-state extended Kalman filter.

Capabilities:

- State and parameter process models.
- Numerical transition and measurement Jacobians.
- Parameter random walks.
- Parameter bounds.
- Innovation and normalized innovation squared.
- Configurable outlier rejection.
- Consecutive-outlier rollback to a trusted state.
- Joseph-form covariance update.
- Exact covariance symmetrization after finite-precision operations.

`trust_current_state()` establishes a new rollback point after a validated operating interval.

## 16. Model-form uncertainty

`ModelFormUncertaintyModel` learns systematic simulation residuals using Gaussian-process regression with an RBF covariance kernel.

It reports:

- Predicted discrepancy mean.
- Discrepancy standard deviation.
- Distance to the nearest training point in length-scale units.
- Extrapolation status.
- Corrected physics prediction.
- Combined measurement, parameter, and model-form uncertainty.

The trained dataset and hyperparameters export to JSON. Physics predictions remain explicit; discrepancy is added as a separate, inspectable correction.

## 17. Multi-fidelity adaptive execution

`MultiFidelityAdaptiveExecutor` selects the least-cost approved model satisfying requested error, cost, and validity-domain limits.

The executor:

- Orders models by nominal cost.
- Uses declared and observed error bounds.
- Rejects unapproved extrapolation.
- Periodically audits selected models against the highest-fidelity model.
- Updates observed error using exponential smoothing.
- Falls back immediately when an audit exceeds the requested error.
- Returns the selected model, estimated cost/error, audit status, fallback status, and observed-error map.

## 18. Unified experiment database

`UnifiedExperimentDatabase` provides a WAL-enabled, foreign-key-enforced SQLite store for reproducible experiments.

Schema entities:

- Runs and canonical manifests.
- Time-indexed metrics.
- Artifacts with SHA-256 and size.
- Key/value tags.
- Requirement verdict and coverage links.

Operations include:

- Begin and complete runs.
- Append metrics.
- Register artifacts.
- Upsert tags and requirement links.
- Query by status and tag.
- Retrieve latest metric values.
- Export a complete run as JSON.

The database uses full-mutex SQLite mode and an internal C++ mutex so one database instance can be safely called from multiple threads.

## Determinism and evidence principles

The platform follows these rules:

1. Search and synthesis randomness is seeded explicitly.
2. Distributed task seeds depend on task IDs, not scheduling order.
3. Reductions use existing deterministic numerical utilities.
4. GPU claims are tied to the backend actually executed.
5. Counterexamples retain trace identifiers.
6. Formal certificates retain reachable sets and proof digests.
7. Safety evidence becomes stale when its backing artifact changes.
8. Digital-twin outliers are recorded and rejected rather than silently assimilated.
9. Model discrepancy remains separate from the governing physics model.
10. Experiment manifests and summaries are stored canonically.

## Test coverage

`advanced_safety_platform_tests` exercises all eighteen capabilities, including:

- Counterexample discovery.
- Minimal intervention planning.
- Cyber-to-sensor-to-safety propagation.
- Passing and failing statistical gates.
- Forward and reverse breakpoint execution.
- Validity-registry persistence.
- Least-restrictive safety shielding.
- Reachability and barrier certification.
- Robust controller optimization.
- Saltation-aware gradient validation.
- Stale safety-evidence rejection.
- Risk-weighted coverage.
- Dependency-ordered distributed execution and checkpointing.
- Deterministic heterogeneous execution.
- Joint state/parameter assimilation.
- Gaussian-process discrepancy prediction.
- Adaptive multi-fidelity auditing.
- SQLite experiment round-trip and export.

## V17 deterministic heterogeneous task scheduling

`DistributedDeterministicRuntime` now considers worker CPU/GPU class, capabilities, performance/NUMA/MPI/accelerator metadata and task capability/preference/cost metadata. Deterministic projected-load assignment keeps stable task seeds while measured timings refine later-frontier estimates.

# Connected Vehicle Integration Platform

## Scope

The connected-vehicle integration platform adds eight native C++17 research subsystems to MuzixDiagSys without replacing the existing NR-V2X, realtime/AUTOSAR, camera rendering, battery, networking, cybersecurity, or cycle-accurate compute implementations. The new layer provides deeper application/security, sensor-processing, embedded-timing, central-compute, wireless-pack, and telematics behavior and is linked into `aesim_advanced`.

Public API: `include/aesim/advanced/connected_vehicle_integration_platform.hpp`

Namespace: `aesim::advanced::connected`

## 1. J2735 application messages and IEEE 1609.2 security

`J2735Codec` supports deterministic binary round-trip encoding for modeled BSM, SPaT, MAP, PSM, and TIM fields. It performs range checking and engineering-unit quantization for latitude, longitude, elevation, speed, heading, acceleration, signal state/timing, geometry, and advisory text.

`WaveSecurityService` provides real OpenSSL P-256 key generation and ECDSA/SHA-256 signing, PSID authorization, pseudonym validity intervals, trust registration, revocation, freshness limits, sequence replay protection, tamper rejection, and per-signer sequence state.

The simulator intentionally distinguishes a modeled research interchange profile from third-party standards certification. SAE's licensed J2735 ASN.1 module set and IEEE conformance vectors remain the normative source for certified over-the-air bitstream qualification. This code contains no claim that its compact simulator interchange encoding is an official SAE ASN.1/UPER artifact.

## 2. DDS Security / SROS2 laboratory

`DdsSros2SecurityLab` models participant identities, domain/topic governance and permissions, authenticated publication, subscriber authorization, signed samples, AES-256-GCM confidentiality/integrity, nonce derivation, replay suppression, identity revocation, and SROS2-compatible governance/permissions XML export. Unauthorized publishers/subscribers, stale credentials, replay, signature modification, and ciphertext/tag modification are rejected.

## 3. Camera ISP

`CameraIspPipeline` accepts RAW Bayer frames and executes:

1. sensor black-level normalization;
2. optional short/long exposure HDR fusion;
3. radial lens-shading compensation;
4. local robust bad-pixel detection and correction;
5. same-color spatial denoising;
6. Bayer demosaicing;
7. gray-world automatic white balance or manual gains;
8. 3x3 color correction;
9. highlight-preserving tone mapping;
10. spatial unsharp-mask sharpening;
11. gamma/OETF encoding; and
12. mean-luma auto-exposure recommendation.

It reports saturation and corrected-pixel counts for downstream validation.

## 4. DMS/OMS sensor digital twin

`CabinSensorDigitalTwin` converts latent driver/occupant state into degraded RGB/NIR/radar-like measurements under illumination, NIR reflectivity, occlusion, vibration, sunglasses, radar interference, and spoof-artifact conditions. `DmsOmsFusion` performs temporal PERCLOS, gaze/head/phone distraction scoring, drowsiness scoring, driver availability, liveness/spoof detection, seat occupancy, child classification, respiration sensing, and belt-state fusion.

## 5. RTOS co-simulation

`RtosCoSimulator` is a deterministic discrete-time execution model with periodic releases, deadline tracking, fixed-priority preemption, multi-core dispatch, ISR precedence, mutex lock/unlock segments, blocking-time accounting, selectable priority inheritance, context-switch overhead, response-time metrics, and a complete execution trace. Kernel profiles include Generic, FreeRTOS, Zephyr, QNX, and VxWorks priority conventions.

## 6. Central compute PCIe/CXL fabric

`CentralComputeFabricSimulator` models PCIe and CXL.io/cache/mem links, transaction serialization, link utilization/contention, propagation/switch service time, DMA/MMIO/CXL transactions, coherent-transaction overhead, IOMMU page translation, TLB hits/misses, translation faults, SR-IOV VF bounds, failed-link/AER reporting, and route timing. Link timing state is persistent between transactions and can be reset deterministically.

## 7. Wireless BMS

`WirelessBmsDigitalTwin` closes cell electrothermal state and communications behavior in one step. It updates cell SOC, terminal voltage, ohmic heating/cooling, RF link budget, Gaussian fading, aggregate noise/interference/jamming, probabilistic packet delivery, retries/backoff, latency, measurement noise, estimator dead-reckoning after packet loss, balancing requests, compromised-node measurement behavior, packet-delivery health, and contactor-open safety decisions.

## 8. Telematics modem

`TelematicsModemDigitalTwin` models LTE, 5G NR, and NTN cells with eSIM home/roaming policy, boot/search/registration/connected/handover/sleep/thermal-limited states, radio-link failure, cell scoring and handover hysteresis, load/SINR/bandwidth-dependent throughput, latency, QoS-flow checks, payload delivery, inactivity sleep/wake, power draw, energy accumulation, and first-order modem thermal throttling/recovery.

## Qualification

Run the focused native unit test after configuring the project:

```bash
cmake --build <build-dir> --target connected_vehicle_integration_platform_tests
<build-dir>/connected_vehicle_integration_platform_tests
```

Run the source-retention regression directly:

```bash
python3 tests/connected_vehicle_integration_source_regression.py .
```

The platform also exposes `ConnectedVehicleIntegrationPlatform::capabilities()` and `ConnectedVehicleIntegrationPlatform::self_test()` for programmatic health checks.

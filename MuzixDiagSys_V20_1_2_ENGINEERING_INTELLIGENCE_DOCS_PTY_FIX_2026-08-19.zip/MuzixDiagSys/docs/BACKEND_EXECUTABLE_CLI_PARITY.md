# Backend Executable / Interactive-Shell Command Parity

**Release:** 2026-08-12  
**Scope:** every non-test backend/tool executable declared by the top-level CMake build

## Purpose

MuzixDiagSys exposes backend functionality in two equivalent forms:

1. the standalone executable, suitable for automation and process isolation; and
2. the authenticated `muzixdiagsys` interactive shell, suitable for an integrated operator workflow.

The parity implementation does **not** maintain a second copy of each command handler. The standalone executable and interactive shell call the same C++ runner/dispatcher. This prevents argument parsing, validation, output, side effects, permissions, and error behavior from drifting between surfaces.

## Complete executable mapping

| Standalone executable | Direct interactive root | Collision-safe interactive form | Functional surface |
|---|---|---|---|
| `muzixdiagsys_advanced_platform` | `advanced-platform ...` | `backend advanced-platform ...` | Full advanced/API registry, public façade commands, motorsport suites, schema/examples/self-tests/run operations |
| `muzixdiagsys_engineering` | `engineering-cli ...` | `backend engineering-cli ...` | Engineering workspaces, scenarios, campaigns, distributed workers, replay/fault/telemetry, diagnostics, standards, learning, uncertainty/calibration/fidelity, assurance, XIL, fleet/lifecycle, collaboration, graph operations |
| `muzixdiagsys_causal_lab` | `causal-lab ...` | `backend causal-lab ...` | Status, timeline verification, causal run differencing, scenario mining, Gaussian rare-event analysis |
| `muzixdiagsys_advanced_safety` | `advanced-safety-cli ...` | `backend advanced-safety-cli ...` | Capabilities, self-test, time-travel debugger/safety-discovery workflow |
| `muzixdiagsys_specification_discovery` | `specification-discovery ...` | `backend specification-discovery ...` | Capabilities, self-test, temporal specification/monitor synthesis |
| `muzixdiagsys_standards_deployment` | `standards-deployment ...` | `backend standards-deployment ...` | Capabilities, self-test, standards/scenario compilation |
| `muzixdiagsys_frontier_professional` | `frontier-professional ...` | `backend frontier-professional ...` | OPC UA/AAS, physical DIL/OpenXR, hardware I/O probe, ns-3 reference, Jupyter integration, Prometheus, Sigstore, Bayesian/MLMC, acoustics/ANC, federated/privacy-aware learning |
| `aesim_study_worker` | `study-worker [address] [port]` | `backend study-worker [address] [port]` | Exact long-running StudyWorkerServer endpoint |
| `research_reference_generator` | `research-reference-generator [csv] [metadata]` | `backend research-reference-generator [csv] [metadata]` | Deterministic research-reference CSV and metadata generation |

`backend list` prints the current mapping from inside the shell.

## Shared-dispatch architecture

The reusable runner contract is declared in:

```text
include/aesim/app/backend_cli.hpp
```

The inventory and shell dispatch bridge are implemented in:

```text
tools/backend_cli_registry.cpp
```

Standalone executables are thin `main()` wrappers. For example, `tools/engineering_main.cpp` calls the same `run_engineering_cli()` implementation that the backend registry uses. The primary shell routes its direct and `backend ...` forms through this same registry.

`muzixdiagsys_advanced_platform` is already built around the shared `aesim::advanced_cli` dispatcher; therefore `advanced-platform ...`, `backend advanced-platform ...`, and the standalone executable reach the same advanced-platform command implementation.

## Authentication equivalence

The engineering backend is authorization-sensitive. Its standalone executable retains the original independent authentication contract:

```bash
./build/muzixdiagsys_engineering \
  --database /path/users.json \
  --credential-file /secure/admin.cred \
  roles catalog
```

Inside `muzixdiagsys`, the operator has already authenticated. The interactive engineering bridge therefore inherits the shell's authenticated `UserIdentity` and authentication database instead of requesting or reading a second credential file:

```text
engineering-cli roles catalog
backend engineering-cli roles catalog
```

The inherited session does **not** bypass engineering authorization. Existing permission checks, audit-log preflight verification, and command audit appends execute unchanged through the same engineering dispatcher.

## Discovery and completion

The interactive completion schema exposes:

- `backend`, `advanced-platform`, and all eight other canonical direct backend roots;
- every registered operation for the six operation-oriented standalone CLIs plus engineering;
- the engineering backend's literal second-level API grammar, including `workspace create|list|member|add|manifest`, `collaboration create|revise|submit|comment|decide|latest|history|verify`, and `graph upsert|edge|search|impact|path|remove`;
- all advanced-platform roots under `advanced-platform ...` and `backend advanced-platform ...`; and
- the existing simulator/advanced/motorsport command surfaces without transferring ownership of colliding native roots.

Each standalone backend has one canonical command owner. Compatibility aliases and the executable spelling resolve to that same owner rather than creating duplicate handlers. For example, `engineering`, `engineering-platform`, and `muzixdiagsys_engineering` all canonicalize to `engineering-cli`. Native simulator roots retain priority; if a backend spelling collides with a native root, the native root remains unchanged and the backend remains reachable through `backend <name> ...`.

Useful discovery commands:

```text
backend list
backend help engineering-cli
advanced-platform commands --compact
engineering-cli --help
engineering workspace list ./workspaces
causal-lab status
frontier-professional capabilities
command-schema validate
```

## Equivalence examples

Standalone:

```bash
./build/muzixdiagsys_causal_lab status
./build/muzixdiagsys_frontier_professional capabilities
./build/research_reference_generator result.csv result.json
```

Interactive equivalents:

```text
causal-lab status
frontier-professional capabilities
research-reference-generator result.csv result.json
```

Namespaced equivalents:

```text
backend causal-lab status
backend frontier-professional capabilities
backend research-reference-generator result.csv result.json
```

The reference-generator parity regression verifies byte-identical CSV and metadata artifacts between standalone and interactive execution.

## Long-running worker behavior

`aesim_study_worker` is intentionally long-running, and its interactive equivalent is equally long-running:

```text
study-worker 127.0.0.1 50051
```

This occupies the current interactive command until the worker receives an interrupt/termination signal. Its embedded runner restores the shell process's previous `SIGINT`/`SIGTERM` handlers on exit, so invoking the backend does not permanently replace parent-shell signal handling. For routine operations, run a persistent worker in a dedicated terminal/process.

## Regression enforcement

`tests/backend_executable_cli_parity_regression.py` is the release gate for this contract. It:

1. inventories all nine non-test backend/tool executables;
2. requires a direct shell root for every executable;
3. requires a `backend ...` namespaced form for every executable;
4. validates operation-level completion, backend aliases/executable spellings, and engineering second-level API completion;
5. executes safe standalone and interactive probes, including direct alias execution and authenticated in-shell engineering help;
6. verifies interactive engineering commands work without the standalone engineering credential environment variable, proving authenticated-session inheritance;
7. compares reference-generator artifacts byte-for-byte;
8. exercises StudyWorkerServer argument validation through both dispatch paths without leaving a server running; and
9. requires the global command schema to validate.

Run it through CTest after building the backend targets, or invoke the registered regression as part of the normal release suite.

The all-command completion regression remains the broader guard against orphaned, multiply-owned, or unreachable interactive command paths.

## V13 UI backend parity

The V13 professional engineering workbenches add canonical shell roots `ui digital-twin-3d`, `ui runbook`, `ui release-planner`, `ui data-catalog`, `ui calibration-correlation`, and `ui collaboration`. These extend, and do not replace, the existing standalone backend executable and advanced API parity mechanisms.

# Integrated Engineering Studio

The `studio` command family is the modular engineering-workbench boundary for MuzixDiagSys. It is implemented in `aesim_engineering` and is intentionally separate from the legacy-compatible simulation command dispatcher and terminal renderer.

## Architecture

The implementation is divided into independently testable services:

- `ActionServiceRegistry`: typed action descriptors, validation, default resolution, invocation, and generated forms.
- `SignalExplorer`: descriptors, live values, quality, uncertainty, statistics, retained history, and causal dependencies.
- `SynchronizedTimeline`: state frames, categorized events, nearest-frame lookup, persistence, and run comparison.
- `TimeTravelDebugger`: exact state checkpoints, reverse restoration, forward stepping, conditional breakpoints, and bounded recording.
- `ModelContractEngine`: executable preconditions, postconditions, invariants, and transitions using a deterministic expression evaluator.
- `DifferentialValidationLab`: time alignment, interpolation, tolerance analysis, correlation, first divergence, and likely causal origins.
- `ScenarioMinimizer`: hierarchical delta debugging for arrays and numeric simplification under a reproducible failure predicate.
- `BugCapsuleStore`: deterministic ZIP capsules with a manifest, SHA-256 artifact hashes, aggregate digest, verification, extraction, and state replay.
- `CalibrationMapStudio`: 1D/2D interpolation, region edits, regularized smoothing, physical bounds, monotonic constraints, comparison, JSON, and CSV.
- `CoSimulationTopology`: typed ports, unit/sample-rate checks, adapter suggestions, algebraic-loop detection, ordering, persistence, and graph editing.
- `SolverPerformanceObservatory`: subsystem timing, step acceptance, deadline misses, real-time factor, and optimization recommendations.
- `ConfidenceDashboard`: nominal values, 95% intervals, aleatoric/epistemic uncertainty, calibration coverage, confidence labels, and rationale.
- `VirtualManufacturingSystem`: deterministic multi-station EOL campaigns, first-pass yield, cycle time, rework cost, and station Pareto data.
- `EngineeringStudioRuntime`: a thin application controller that supplies typed runtime bindings and routes the canonical command family.

No service depends on terminal escape sequences or direct access to the private simulation implementation. The terminal, future GUI, HTTP clients, Python clients, and automated campaigns can therefore share the same action and service contracts.

## Runtime bindings

The simulation supplies callbacks for:

- full checkpoint capture and verified restore;
- current signal capture;
- deterministic state hash;
- simulation time;
- deterministic advance;
- command/scenario execution.

The continuous loop records accepted steps. Commands that mutate state while the loop is paused trigger a post-command refresh, so the signal explorer and timeline do not lag direct `step`, scenario, calibration, checkpoint, or replay operations.

## Command reference

```text
studio status
studio action list
studio action describe <action-id>
studio action form <action-id> [name=value ...]
studio action run <action-id> [name=value ...]

studio signals list [pattern] [category]
studio signals show <path>
studio signals history <path> [maximum]
studio signals dependencies
studio signals export <path> [maximum-history]
studio signals clear

studio timeline status
studio timeline events [maximum]
studio timeline nearest <time-s>
studio timeline export <path> [maximum-frames]
studio timeline load <path>
studio timeline compare <path> [tolerance]
studio timeline clear

studio debug status
studio debug record on|off
studio debug configure <maximum-checkpoints> <automatic-interval-s>
studio debug checkpoint [label]
studio debug reverse [count]
studio debug forward [dt-s] [count]
studio debug goto <sequence>
studio debug break add <expression> [one-shot]
studio debug break list
studio debug break remove <id>
studio debug continue [dt-s] [maximum-steps]

studio contracts list
studio contracts load <path>
studio contracts save <path>
studio contracts evaluate
studio contracts add <contract-id> <component> <clause-id> <kind> <severity> <expression>
studio contracts remove <contract-id>

studio validation compare <baseline> <candidate> <output-prefix> [absolute] [relative] [period] [maximum-shift]
studio validation last
studio minimize <scenario> <failure-expression> <output> [maximum-evaluations]

studio capsule create <output> <title> <failure-signature> [scenario]
studio capsule verify <path>
studio capsule inspect <path>
studio capsule extract <path> <directory>
studio capsule replay <path>

studio calibration status
studio calibration load <path>
studio calibration save <path>
studio calibration csv <path>
studio calibration sample <x> [y]
studio calibration set <row> <column> <value>
studio calibration edit <xmin> <xmax> <ymin> <ymax> <offset> [scale]
studio calibration smooth [passes] [strength]
studio calibration validate
studio calibration compare <path> [absolute] [relative]

studio topology status
studio topology load <path>
studio topology save <path>
studio topology validate
studio topology order
studio topology node <id> <kind> [period-s] [implementation]
studio topology remove-node <id>
studio topology port <node> <name> <input|output> <type> <unit> [period-s] [required]
studio topology connect <from-node.port> <to-node.port> [delay-s] [scale] [offset]
studio topology disconnect <from-node.port> <to-node.port>
studio topology adapter <from-node.port> <to-node.port>

studio performance status
studio performance recommend
studio performance export <path>
studio performance reset

studio confidence status
studio confidence show <signal>
studio confidence export <path>

studio manufacturing stations
studio manufacturing run <input> <output-prefix>
studio manufacturing demo <count> <output-prefix> [seed]
studio manufacturing last
```

Quoted expressions are supported by the decomposed runtime tokenizer, for example:

```text
studio debug break add "engine.rpm > 6500 && engine.coolant_c > 110"
```

## Typed forms

Every registered action provides a generated form containing parameter type, unit, required/default state, range, enumeration choices, validation findings, reversibility, and the exact canonical invocation.

```text
studio action form calibration.smooth passes=3 strength=0.2
studio action run calibration.smooth passes=3 strength=0.2 preserve_boundaries=true
```

Invalid actions are rejected before their handler is called. Unknown parameters, missing required values, non-finite numbers, type mismatches, range violations, and invalid enumeration values are reported together.

## Contract expression language

Contracts and breakpoints support:

- arithmetic: `+ - * / ^`;
- comparison: `< <= > >= == !=`;
- logic: `! && ||`;
- constants: `true false pi e`;
- functions: `abs`, `sqrt`, `exp`, `log`, `sin`, `cos`, `tan`, `floor`, `ceil`, `round`, `min`, `max`, `pow`, `clamp`, and `within`.

Identifiers may contain dots and array-style qualifiers, which permits direct use of canonical signal paths.

## Artifact formats

- Timeline: `aesim.synchronized-timeline.v1`
- Contracts: `aesim.model-contracts.v1`
- Action forms: `aesim.action-form.v1`
- Bug capsules: `aesim.bug-capsule.v1`
- Performance reports: `aesim.performance-observatory.v1`
- Confidence reports: `aesim.confidence-dashboard.v1`
- Manufacturing reports: `aesim.virtual-manufacturing.v1`

All JSON/YAML writes use the platform atomic persistence path. Capsules reject unsafe archive entries, verify every artifact hash, verify the aggregate manifest digest, and constrain extraction to the requested destination.

## Testing

`engineering_studio_unit_tests` exercises all services and the application controller. The terminal command schema also validates `studio` as one canonical root with contextual nested completion.


## Terminal experience integration

The streamlined terminal experience reuses Engineering Studio's complete simulator-state serialization for UI undo, redo, and named state branches. The terminal backend calls `studio_capture_state()` before a metadata-classified state-changing command and `studio_restore_state()` during restoration. This avoids a partial UI-only state model and preserves existing checkpoint validation, deterministic replay, and compatibility behavior.

Guided terminal workflows can invoke Engineering Studio actions as ordinary canonical commands. Their completion state is presentation metadata; the underlying engineering action, evidence, and project journal remain authoritative. See `docs/STREAMLINED_UI_EXPERIENCE.md`.

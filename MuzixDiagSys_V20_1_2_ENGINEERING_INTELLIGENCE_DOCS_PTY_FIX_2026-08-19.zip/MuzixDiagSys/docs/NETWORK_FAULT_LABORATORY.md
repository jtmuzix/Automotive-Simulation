# MuzixDiagSys Network Fault Laboratory

## Purpose

The network fault laboratory is a deterministic, stateful failure-injection engine attached to the simulator's authoritative automotive network and diagnostic services. It perturbs live CAN/CAN-FD and ISO-TP traffic, DoIP routing activation, SOME/IP service discovery, and Ethernet/TSN delivery. The laboratory is inactive by default; existing network behavior remains unchanged until one or more modes are enabled.

The same laboratory instance is used by:

- `aesim::industrial::AutomotiveNetwork` for CAN, CAN-FD, ISO-TP, and UDS transport;
- `aesim::industrial::DiagnosticService` for DoIP routing activation;
- `aesim::assurance::AdaptiveRuntime` for SOME/IP-SD availability;
- the interactive `networklab` / `netfault` commands;
- `.muzixproj` project persistence and deterministic replay;
- the guided `can-communication` diagnostic workflow.

This avoids a disconnected fault demonstration: enabled modes alter the real transport path used by the simulator, CLI diagnostics, virtual ECUs, and assurance services.

## Determinism and state

Each laboratory has an unsigned 64-bit seed and a serialized pseudo-random generator state. A project save retains the configured modes, mode parameters, RNG state, pending delayed frames, held reordering frames, CAN controller states, recent evidence events, and cumulative statistics. Loading the project restores this state transactionally. The same seed, command sequence, and traffic sequence therefore produce the same fault decisions and ordering.

```text
project new cases/network_case.muzixproj Network_Case
project set seed 4242
networklab reset 4242
networklab set frame-drop 0.75 0.10 tx
project save
```

`severity` and `probability` are separate values in the inclusive range 0 through 1. Severity controls fault magnitude where a mode has a magnitude; probability controls whether an eligible event triggers. A probability of `1` is deterministic for every in-scope event. Scope is evaluated before probability.

## Commands

The canonical command is `networklab`; `netfault` is an exact alias.

```text
networklab status
networklab events 40
networklab seed 4242
networklab clear
networklab reset 4242
networklab set <mode> <severity> [probability] [scope] [key=value ...]
networklab remove <mode>
networklab node [name]
networklab error <node> <tx-points> <rx-points> [now-ns]
networklab recover <node> [now-ns]
networklab can-probe <tx|rx> <id> <hex bytes...>
networklab isotp-probe <tx|rx> <hex payload...>
networklab doip-probe <source> <target> [activation-type]
networklab someip-probe <service> <instance> [ttl-ms]
networklab ethernet-probe <bytes> <priority> <scheduled-ns> <now-ns>
networklab save <state.json>
networklab load <state.json>
```

The standalone JSON format has schema `muzixdiagsys.network-fault-lab` version `1.0.0`. A complete example is provided at `examples/reference_network_fault_lab.json`.

## Scope selectors

A mode may be scoped to all eligible traffic or to a narrower target:

| Scope | Meaning |
|---|---|
| `*` or `all` | All eligible operations for the mode |
| `tx` / `transmit` | Transmitted CAN or protocol traffic |
| `rx` / `receive` | Received CAN or protocol traffic |
| `fd` | CAN-FD frames only |
| `classic` | Classical CAN frames only |
| `0x123`, `123`, `id=0x123` | One CAN identifier |
| `doip` | DoIP activation operations |
| `someip` / `someip-sd` | SOME/IP service discovery |
| `ethernet` | Ethernet delivery |
| `tsn` | TSN schedule evaluation |

## Failure modes

### CAN loading and controller state

| Mode | Behavior | Important parameters |
|---|---|---|
| `can-congestion` | Adds deterministic arbitration/queueing delay and releases frames through the normal poll path. | `max_delay_ns`, `queue_penalty_ns` |
| `can-error-passive` | Raises the selected node's transmit or receive error counter to the error-passive threshold. | `node`, `error_points` |
| `can-bus-off` | Drives the selected node to transmit error counter 256, drops its frames, and schedules recovery. | `node`, `recovery_ms` |

CAN node states are represented explicitly as `error-active`, `error-passive`, and `bus-off`. `networklab error` can add exact transmit/receive error points, and `networklab recover` performs a forced recovery to error-active. Automatic recovery occurs when simulated time reaches the configured recovery deadline.

### Frame delivery and integrity

| Mode | Behavior | Important parameters |
|---|---|---|
| `frame-drop` | Removes an eligible frame from the output path. | scope/probability |
| `frame-delay` | Queues a frame until a deterministic time within the configured interval. | `min_delay_ns`, `max_delay_ns` |
| `frame-duplicate` | Emits an additional identical frame. | scope/probability |
| `frame-reorder` | Holds one frame and emits the next eligible frame before it; a timeout prevents indefinite retention. | `timeout_ns` |
| `rolling-counter` | Corrupts a selected payload counter field. | `byte`, `mask`, `action=jump|increment|freeze|invert`, `jump`, `freeze_value` |
| `checksum` | XOR-corrupts a selected checksum/CRC byte. | `byte`, `xor` |
| `gateway-route` | Changes the destination CAN identifier or blackholes the frame. | `action=misroute|blackhole`, `destination_id`, `id_offset` |
| `can-fd-mismatch` | Rejects a CAN-FD frame at a classical-CAN boundary or an injected incompatible peer. | scope/probability |

Delayed and held frames, including learned rolling-counter freeze baselines, are part of the persisted laboratory state, not transient local variables. They survive a project save/load and are released through `AutomotiveNetwork::poll()` when due.

### ISO-TP and diagnostics transport

| Mode | Behavior | Important parameters |
|---|---|---|
| `isotp-sequence` | Changes consecutive-frame sequence numbers in a multi-frame ISO-TP transfer. | `jump` |
| `isotp-flow-control` | Drops or changes an explicit Flow Control frame, or aborts/stalls a locally segmented multi-frame transfer when no explicit FC frame exists. | `action=drop|wait|overflow|invalid-stmin`, `retain_frames`, `gap_ns` |
| `doip-activation` | Rejects DoIP routing activation before UDS dispatch. | `action=reject|unknown-source|source-active|unsupported-type` |

DoIP action-to-response mapping is explicit: `unknown-source` yields response code `0x00`, `source-active` yields `0x02`, `unsupported-type` yields `0x06`, and the generic reject/deny path yields `0x04`.

### Automotive Ethernet, SOME/IP, and TSN

| Mode | Behavior | Important parameters |
|---|---|---|
| `someip-discovery` | Withdraws/flaps a service, retains a stale offer after TTL expiry, or delays an offer. | `action=flap|stale|delay`, `max_delay_ns` |
| `ethernet-jitter` | Adds deterministic signed timestamp jitter to an Ethernet packet. | `max_jitter_ns` |
| `tsn-violation` | Adds a gate/deadline violation and optionally drops the packet. | `violation_ns`, `drop=true|false` |

SOME/IP failures are evaluated by the assurance adaptive runtime before service method dispatch. DoIP failures are evaluated by the authoritative diagnostic service before the routing-activated UDS request. This keeps protocol behavior aligned across direct tests and runtime commands.

## Project integration

A `.muzixproj` save stores two complementary representations:

1. User-declared network fault injections appear in `fault_injections`, using canonical names such as `network.frame-drop`, with severity, probability, scope, source, and mode parameters.
2. The exact runtime laboratory state appears at `metadata.network_fault_laboratory`.

The metadata representation is necessary because the live state also includes RNG position, delayed/reordered traffic, CAN controller counters and transition state, statistics, and evidence events. For backward compatibility, a project that has network fault-injection records but no laboratory metadata reconstructs the active laboratory from those records.

```text
project fault add network.frame-drop 0.8 probability=0.05 scope=rx
project fault add network.gateway-route 1 probability=1 scope=0x7E0 action=blackhole
project save
```

## Guided CAN communication diagnosis

The `can-communication` guided workflow consumes laboratory evidence in addition to ordinary simulator measurements. Its context includes:

- CAN controller state and error counters;
- configured network-fault severity;
- measured dropped-frame ratio;
- protocol-failure and routing-error counts;
- TSN violation count;
- a physical/network error index derived from those observations.

The workflow output retains the existing evidence taxonomy: observed counters and states are facts; calculated ratios and model indices are model-derived conclusions; ranked candidate causes are heuristic hypotheses; tests that have not yet been performed remain missing evidence.

```text
workflow start can-communication CASE-CAN-017
networklab set can-bus-off 1 1 tx node=gateway recovery_ms=500
networklab can-probe tx 0x7E0 02 01 0C
workflow evaluate
workflow report reports/CASE-CAN-017.md
causal report can-communication
project save
```

## Event evidence and statistics

Every triggered mode emits a bounded, sequenced event containing simulated timestamp, mode, direction, action, optional CAN identifier, and detail. `networklab status` reports active modes, input/output frames, drop/delay/duplicate/reorder/corruption counts, routing errors, protocol failures, CAN state transitions, Ethernet packet count, TSN violations, and per-node TEC/REC/state. `networklab events` provides the recent event stream for diagnostic evidence and reports.

## Validation

The implementation is covered by:

- `network_fault_lab_unit_tests`: all 17 modes, deterministic transport behavior, persistence, controller transitions, direct protocol evaluators, authoritative diagnostic binding, and live loopback network integration;
- `network_fault_lab_cli_regression`: command routing, probes, all mode names, standalone state JSON, `.muzixproj` persistence, project reload, and CAN communication workflow evidence;
- the existing project/workflow/causal, diagnostic-authority, assurance, command-registry, completion, and source-package regressions.

# Continuous Engineering Platform

## Purpose

The continuous-engineering extension adds ten production C++17 subsystems to
MuzixDiagSys without replacing existing vehicle, assurance, cybersecurity,
optimization, lifecycle, or distributed-execution functionality. All public
interfaces are exported through:

```cpp
#include "aesim/advanced/platform.hpp"
```

The implementation emphasizes deterministic execution, bounded resource use,
machine-readable evidence, explicit failure diagnostics, and SHA-256 provenance.

## Public modules

| Module | Header | Primary responsibility |
|---|---|---|
| Scenario and localization | `aesim/advanced/scenario_localization.hpp` | Typed scenario compilation, execution, coverage closure, localization integrity, HD-map change assurance |
| AI and laboratory automation | `aesim/advanced/mlops_laboratory.hpp` | Dataset/model registry, continuous AI assurance, drift and rollout governance, robotic test-laboratory execution |
| Multiphysics and tire laboratory | `aesim/advanced/multiphysics_tire.hpp` | Finite-volume CFD, truss FEA, POD reduced-order modeling, tire/road/weather and particle emissions |
| Fleet cybersecurity and SoC synthesis | `aesim/advanced/fleet_soc.hpp` | Fleet incident correlation and containment, heterogeneous chiplet/SoC architecture synthesis |
| Passport and service engineering | `aesim/advanced/passport_service.hpp` | Signed product passports, selective disclosure, custody/revocation, Bayesian diagnostics and repair planning |

## 1. OpenSCENARIO 2.x-oriented compiler and coverage closure

`OpenScenario2Compiler` implements a deterministic typed scenario language for
executable vehicle regressions. The implemented grammar supports:

- `scenario` declarations;
- typed number, Boolean, and string parameters;
- numeric bounds and discrete choices;
- actor declarations and typed initial state;
- timestamped `set`, `add`, `multiply`, `assert`, and `emit` instructions;
- invariant assertions;
- weighted coverage goals;
- string metadata; and
- arithmetic, relational, and Boolean expressions over parameters and actor state.

Compilation produces `Osc2ScenarioProgram`, validation diagnostics, source and
IR hashes, and canonical machine-readable documents. Execution validates
bindings against types and domains, orders instructions deterministically,
updates actor state, evaluates assertions and coverage, records emitted events,
and hashes the complete trace.

Coverage closure enumerates bounded parameter-domain candidates and applies a
deterministic weighted greedy set-cover algorithm. The result contains selected
cases, covered and uncovered goals, weighted coverage, candidate count, and an
evidence hash. `emit_canonical_source` supports deterministic source round trips.

The supported language is a production executable subset designed for this
simulator. It does not claim that every possible construct from every ASAM
OpenSCENARIO 2.x revision is accepted.

## 2. Localization and HD-map assurance

`LocalizationAndMapAssurance` maintains an eight-state estimate:

```text
x, y, longitudinal velocity, lateral velocity, yaw,
gyroscope bias, acceleration bias, auxiliary state
```

The estimator provides:

- IMU prediction;
- GNSS position updates with innovation consistency gating;
- wheel-speed updates;
- map-lane lateral and heading updates;
- covariance propagation and correction;
- horizontal protection-level computation;
- integrity-risk estimation;
- GNSS fault detection; and
- alert-limit verdicts.

The HD-map assurance path compares observed and registered landmarks and reports
added, removed, moved, and semantic-change findings. It computes map confidence,
current/proposed map hashes, update requirements, and evidence provenance.

## 3. Vehicle-cloud MLOps and continuous AI assurance

`VehicleCloudMlopsPlatform` provides cryptographically identified dataset and
model registries. It rejects inconsistent hashes, preserves parent lineage, and
records schema, license, metric, parameter, and artifact metadata.

AI assurance evaluates samples by ODD slice and calculates:

- accuracy;
- root-mean-square error;
- calibration error;
- safety-violation rate;
- confidence; and
- coverage.

Requirements select a slice, metric, comparison operator, and threshold. The
result contains per-slice metrics, per-requirement verdicts, invalidated evidence
identifiers, aggregate pass/fail state, and a reproducible evidence hash.

Distribution drift is detected with population-stability index, standardized
mean shift, and empirical-CDF distance. Staged deployment supports shadow,
canary, cohort, fleet, and rolled-back states. Health gates enforce minimum
observations, accuracy, safety, and latency requirements before promotion;
unhealthy stages roll back deterministically.

## 4. Robotic test-laboratory orchestration

`RoboticTestLaboratoryOrchestrator` coordinates instruments, exclusive facility
resources, dependencies, safety interlocks, commands, measurements, expected
ranges, and evidence output.

The deterministic built-in instrument backend supports:

- `SET channel value`;
- `RAMP channel value rate`;
- `MEASURE channel`;
- `WAIT duration`; and
- `RESET`.

The network backend performs real bounded TCP SCPI request/response exchanges.
It applies connection and I/O deadlines, output-size limits, deterministic
socket cleanup, protocol validation, and explicit error propagation. Laboratory
plans are topologically validated, resource conflicts are prevented, interlocks
are evaluated before hazardous actions, and measurement tolerances determine the
final verdict.

Physical equipment remains subject to site-specific driver, calibration,
interlock, and safety qualification.

## 5. CFD, FEA, and reduced-order multiphysics

`MultiphysicsWorkbench` includes three numerical paths.

### Finite-volume CFD

A structured two-dimensional incompressible solver performs momentum prediction,
pressure projection, thermal advection/diffusion, boundary enforcement, and
stability checking. Reports include velocity, pressure, temperature, kinetic
energy, wall heat transfer, maximum divergence, and convergence diagnostics.

### Finite-element structural analysis

The truss solver assembles the global stiffness matrix, thermal strain loads,
external forces, and displacement constraints. Pivoted linear solution produces
nodal displacement, element axial force and stress, safety factor, and equilibrium
residual.

### Reduced-order modeling

Proper orthogonal decomposition is built from a snapshot ensemble. The
implementation calculates the mean state, covariance modes, retained energy,
projection, and reconstruction. Coupling utilities map CFD pressure and thermal
loads into structural inputs and reduce field histories for real-time execution.

## 6. Tire, road, weather, and non-exhaust emissions

`TireRoadWeatherLaboratory` integrates transient longitudinal slip and slip
angle, temperature, tread wear, road contamination, aquaplaning, force saturation,
aligning moment, rolling resistance, and radiated noise.

Environment inputs include dry friction, water depth, snow, ice, texture,
ambient temperature, and surface condition. Outputs include:

- longitudinal and lateral force histories;
- effective friction;
- aquaplaning state;
- contact-patch state;
- tire temperature and tread depth;
- tire-wear mass;
- brake-wear mass;
- particle-emission totals; and
- minimum friction and peak acoustic level.

## 7. Continuous fleet cybersecurity operations

`FleetCyberSecurityOperationsCenter` registers fleet assets, vulnerabilities,
service roles, behavioral baselines, and detection rules. It ingests vehicle,
network, charger, cloud, and backend security events.

Analysis provides:

- deterministic rule evaluation;
- behavioral anomaly detection;
- multi-event correlation by vehicle, asset, technique, and time;
- severity and confidence scoring;
- attack-path reconstruction;
- safety-impact propagation;
- containment actions;
- certificate and credential revocation plans;
- affected-fleet scope; and
- required simulation/regression campaigns.

The result is intended to connect operational incidents back into the existing
cyber range, OTA lifecycle, safety case, and fleet qualification workflows.

## 8. Chiplet and automotive SoC architecture synthesis

`ChipletSocArchitectureSynthesizer` performs bounded exact search over candidate
CPU, GPU, NPU, DSP, safety, memory, and I/O chiplets, inter-chiplet links,
workloads, replicas, and communication flows.

Constraints include:

- compute throughput;
- local memory;
- memory and link bandwidth;
- workload deadlines;
- ASIL capability;
- lockstep capability;
- replica count;
- vendor and chiplet diversity;
- communication latency;
- maximum power; and
- maximum junction temperature.

The weighted objective combines cost, power, area, and latency. Results include
selected chiplets and links, workload placements, utilization, thermal estimates,
system failure probability, diagnostics, search count, and a cryptographic
certificate.

## 9. Digital-product-passport data space

`DigitalProductPassportDataSpace` uses the existing hardware-security-module
implementation to issue signed product credentials. Product passports contain
identity, genealogy, material inventory, sustainability metrics, software
versions, parent-passport relationships, revisions, and evidence hashes.

Implemented data-space controls include:

- participant roles and permitted purposes;
- signed credentials;
- Merkle roots over canonical claims;
- selective disclosure with per-claim Merkle proofs;
- issuer-signature verification;
- custody-transfer hash chains;
- revision handling;
- revocation; and
- machine-readable status reporting.

Selective disclosure allows a recipient to verify only authorized claims while
retaining issuer authenticity and claim-integrity evidence.

## 10. Service and remanufacturing digital twin

`ServiceRemanufacturingDigitalTwin` performs Bayesian diagnostic inference over
fault hypotheses, observed symptoms, and completed tests. It ranks remaining
tests by expected information gain, cost, duration, and utility.

Repair counterfactuals evaluate:

- probability of resolving the fault;
- direct and downtime cost;
- residual safety risk;
- embodied carbon;
- recovered-material credit;
- remanufacturing yield; and
- remote-repair feasibility.

The planner recommends a diagnostic test and repair while preserving the full
posterior belief and evidence hash. `apply_repair` incorporates successful or
failed repair evidence into the posterior, enabling closed-loop post-repair
verification.

## Build and qualification

```bash
cmake -S . -B build -G Ninja \
  -DAESIM_BUILD_TESTS=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build --target \
  continuous_engineering_platform_tests \
  advanced_platform_cli
ctest --test-dir build \
  -R 'continuous_engineering_platform|advanced_platform_cli_self_test' \
  --output-on-failure
./build/advanced_platform_cli self-test ./continuous-engineering-self-test
```

The dedicated suite exercises nominal and non-nominal behavior across all ten
subsystems. It includes source round-trip and coverage closure, map-change
recognition, staged AI rollback, laboratory interlocks and measurements, CFD
conservation, FEA residuals, POD reconstruction, aquaplaning, particle emissions,
fleet incident containment, diverse safety placement, signed selective
disclosure, and repair counterfactuals.

## External-system boundaries

The source tree contains complete implementations of the published APIs.
Interactions with physical laboratory equipment, external vehicle clouds,
commercial map services, external OpenSCENARIO tools, and production passport
trust networks require their corresponding credentials, network endpoints,
devices, governance policies, and site safety controls. The simulator detects
and reports unavailable external dependencies rather than claiming successful
external execution.

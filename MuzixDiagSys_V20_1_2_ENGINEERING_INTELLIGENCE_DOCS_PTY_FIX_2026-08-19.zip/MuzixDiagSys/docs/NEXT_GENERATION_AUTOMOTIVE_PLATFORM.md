# Next-Generation Automotive Platform

MuzixDiagSys includes a production-oriented C++17 platform for simulation compilation, formal synthesis, AI assurance, software-defined vehicles, post-quantum security, connected-vehicle networking, synthetic data, reliability, compute timing, embedded deployment, manufacturing, and fleet digital twins. The implementation is additive: existing simulator models, commands, file formats, and public APIs remain available.

## Build requirements

The next-generation platform is part of `aesim_advanced` and requires OpenSSL 3.5 or newer for the standardized post-quantum algorithms.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --target aesim_advanced \
  next_generation_platform_tests muzixdiagsys_advanced_platform -j
ctest --test-dir build --output-on-failure \
  -R 'next_generation_platform|advanced_platform'
```

The umbrella public header is:

```cpp
#include "aesim/advanced/platform.hpp"
```

The implementation is divided into four cohesive API groups:

- `compiler_synthesis_ai.hpp`
- `sdv_security_network.hpp`
- `scene_reliability_compute.hpp`
- `codegen_manufacturing_fleet.hpp`

## 1. Simulation domain-specific IR and MLIR emission

`SimulationMlirCompiler` validates and optimizes a typed, unit-aware directed acyclic simulation graph. Supported operations are input, constant, copy, affine, add, subtract, multiply, divide, clamp, Euler integration, compensated reduction, range assertion, and output.

The compiler performs:

- unique-definition and dependency validation;
- cycle and use-before-definition detection;
- tensor-shape, literal-size, precision, and physical-unit checks;
- constant folding;
- common-subexpression elimination;
- affine-operation fusion;
- dead-operation elimination;
- stable deterministic execution ordering;
- estimated memory accounting;
- generic MLIR textual emission using `muzix.*` operations;
- deterministic output and evidence hashing.

Example:

```cpp
aesim::advanced::SimulationIrModule module;
module.name = "longitudinal_control";
module.operations = {
    {.id="speed", .opcode=aesim::advanced::SimulationIrOpcode::Input,
     .output="speed", .type={{1}, "m/s", "f64"}},
    {.id="gain", .opcode=aesim::advanced::SimulationIrOpcode::Affine,
     .inputs={"speed"}, .output="command", .type={{1}, "1", "f64"},
     .numeric_attributes={{"scale", -0.1}, {"bias", 1.0}}},
    {.id="limit", .opcode=aesim::advanced::SimulationIrOpcode::Clamp,
     .inputs={"command"}, .output="limited", .type={{1}, "1", "f64"},
     .numeric_attributes={{"minimum", 0.0}, {"maximum", 1.0}}},
    {.id="result", .opcode=aesim::advanced::SimulationIrOpcode::Output,
     .inputs={"limited"}, .output="result", .type={{1}, "1", "f64"}}
};
module.outputs = {"result"};

aesim::advanced::SimulationMlirCompiler compiler;
auto executable = compiler.compile(module);
auto result = executable.execute({{"speed", {4.0}}});
```

The generated MLIR uses generic operation syntax so the IR remains explicit and inspectable even when a custom dialect registration is not present. The built-in compiled interpreter is the authoritative deterministic execution path.

## 2. Formal controller and safety-architecture synthesis

`FormalControllerSynthesizer` solves finite nondeterministic safety games by greatest-fixed-point computation. It returns:

- realizability;
- the complete winning region;
- a deterministic memoryless strategy;
- losing initial states;
- an independently verifiable proof hash.

All successors for a selected control action must remain in the winning region, so nondeterministic environmental choices are treated adversarially.

`SafetyArchitectureSynthesizer` performs exact branch-and-bound selection of safety mechanisms. It supports hazard coverage, independent-channel groups, availability, cost, mass, and power. Diagnostic coverage is combined as independent failure-detection probability:

```text
combined coverage = 1 - product(1 - candidate coverage)
```

A feasible result includes selected mechanisms, achieved coverage per hazard, independent-channel counts, aggregate resource cost, and a certificate hash.

## 3. ONNX verification and deployment equivalence

`OnnxVerificationLaboratory` loads the simulator's actual parsed ONNX graph and performs interval-bound propagation. Supported graph operations include:

- Identity, Flatten, and Reshape;
- Add, Sub, Mul, and Div;
- MatMul and Gemm;
- Relu, Abs, Neg, Sigmoid, and Tanh;
- Clip, ReduceMean, and Softmax.

Unsupported operations cause an explicit inconclusive result rather than an unsafe success verdict. Output properties define indexed minimum and maximum limits. The report contains output intervals, violations, diagnostics, and the model SHA-256 digest.

Deployment-equivalence testing executes the same model under reference `float64`, deployed `float32`, or symmetric `int8` input/output quantization semantics. It reports maximum absolute error, maximum relative error, mismatch count, and per-sample diagnostics.

The existing ONNX runtime now exposes `OnnxModel::graph_document()` for graph-level verification, provenance inspection, and assurance tooling.

## 4. COVESA/Eclipse-style SDV workload runtime

`SdvWorkloadRuntime` provides a service-oriented vehicle runtime with:

- VSS-style signal definitions and value-range enforcement;
- reader/writer authorization based on service manifests;
- dependency-aware topological startup;
- CPU, memory, and GPU resource admission;
- periodic releases and deadline accounting;
- criticality-aware deterministic scheduling;
- process failure and dependent-service degradation;
- restart accounting;
- transactional rolling update with health-tick commit or rollback;
- machine-readable status and capacity reports.

Service manifests describe provided and consumed signals, dependencies, resource budgets, period, deadline, criticality, and restart policy. The runtime is independent of a specific SDV distribution, allowing adapters to map the model to COVESA, Eclipse S-CORE/Leda/OpenSOVD, AUTOSAR Adaptive, or container runtimes without changing execution semantics.

## 5. Post-quantum crypto agility and HSM attack simulation

`PostQuantumCryptoProvider` uses OpenSSL 3.5 EVP implementations directly. It supports runtime-discovered standardized and hybrid algorithms, including available variants of:

- ML-KEM-512, ML-KEM-768, and ML-KEM-1024;
- ML-DSA-44, ML-DSA-65, and ML-DSA-87;
- SLH-DSA implementations exposed by the provider;
- X25519+ML-KEM and P-256+ML-KEM hybrid KEMs when available.

The provider performs real key generation, DER public-key export, encapsulation, decapsulation, signing, verification, and key-size reporting. Operations are rejected when the key type and requested operation disagree.

`HsmAttackSimulator` executes deterministic seeded campaigns for voltage glitching, clock glitching, entropy degradation, timing leakage, power leakage, monotonic-counter rollback, debug extraction, and key-slot exhaustion. Security controls alter both success and detection probabilities, and every campaign produces a cryptographic evidence digest.

## 6. NR-V2X, NTN, and edge-compute co-simulation

`ConnectedVehicleNetworkSimulator` provides:

- NR-V2X link budget and thermal-noise calculation;
- shadowing and interference;
- resource-block allocation;
- modulation/coding-derived block error probability;
- HARQ retransmission behavior;
- delivery deadline evaluation;
- LEO NTN slant range, propagation delay, Doppler, and free-space path loss;
- priority/deadline-ordered edge workload execution;
- uplink, queue, compute, downlink, and total latency accounting.

All stochastic packet behavior is seeded and repeatable.

## 7. OpenUSD synthetic-data factory

`OpenUsdSyntheticDataFactory` composes valid ASCII USDA stages with materials, semantic objects, transforms, sensor metadata, physical dimensions, velocity, lidar reflectivity, and radar cross section. It also creates deterministic frame products:

- semantic and instance annotations;
- camera-space bounding boxes;
- lidar XYZI point sets;
- radar range, azimuth, radial velocity, and RCS detections;
- frame-level SHA-256 evidence.

`write_dataset()` creates a self-contained dataset directory containing the USDA stage, per-frame JSON annotations, lidar and radar CSV files, and a manifest containing hashes and generation settings.

The implementation does not depend on an installed OpenUSD SDK for writing standards-readable USDA. When `usdchecker` or a USD SDK is available, generated stages can be included in external validation pipelines.

## 8. Rare-event reliability analysis

`RareEventReliabilityAnalyzer` implements four complete methods:

- crude Monte Carlo;
- adaptive cross-entropy importance sampling;
- subset simulation with Markov-chain conditional sampling;
- Hasofer-Lind/Rackwitz-Fiessler FORM.

Inputs are normally distributed reliability variables mapped from standard-normal space. Results include probability of failure, standard error, confidence bounds, a finite continuity-corrected reliability index, evaluation count, most probable failure point, FORM importance factors, intermediate thresholds, and deterministic evidence hash.

The continuity correction prevents non-finite evidence when a finite campaign observes zero or all failures.

## 9. Cycle-accurate vehicle compute and NPU co-simulation

`CycleAccurateVehicleComputeSimulator` models:

- deterministic multicore priority/release scheduling;
- integer, floating-point, vector, branch, memory, DMA, and NPU-MAC instructions;
- direct-mapped L1 and L2 caches;
- cache and memory latency;
- branch prediction and misprediction penalties;
- NPU throughput in MACs per cycle;
- dynamic and leakage energy;
- first-order thermal response;
- thermal throttling;
- task deadlines and aggregate misses;
- trace hashing.

The model is intended for repeatable architecture exploration and ECU workload qualification rather than instruction-set emulation.

## 10. Embedded code generation and MIL/SIL/PIL/HIL equivalence

`EmbeddedControllerCodeGenerator` accepts discrete state-space controllers and emits standalone C11 source, header, and a machine-readable manifest. It supports:

- floating-point execution;
- signed fixed-point execution with configurable fractional bits;
- state initialization;
- output saturation;
- deterministic source hashing;
- atomic artifact writes.

The generated code is warning-clean under `-std=c11 -Wall -Wextra -Werror` in the qualification suite.

The equivalence laboratory executes MIL and generated-code semantics and compares arbitrary MIL, SIL, PIL, and HIL traces. It validates timestamps, dimensions, outputs, and states using absolute and relative tolerances and produces stage-specific mismatch counts plus an evidence hash. Physical PIL/HIL acquisition is supplied through `EquivalenceStageTrace`, allowing existing XIL, bench, or target adapters to provide measured samples without coupling the comparison engine to one vendor.

## 11. Manufacturing and end-of-line digital factory

`ManufacturingDigitalFactory` simulates complete production lots through ordered stations. It includes:

- process and measurement variation;
- station availability;
- cycle time and throughput;
- defect generation and escape probability;
- end-of-line limits;
- serial and supplier-lot genealogy;
- first-pass yield;
- escaped-defect counts;
- Cp and Cpk capability indices;
- defect Pareto analysis;
- deterministic genealogy hashing.

Every unit retains measured characteristics and defects, enabling direct linkage to warranty, supplier, calibration, and fleet studies.

## 12. Fleet prognostics and federated digital twins

`FleetDigitalTwinPlatform` stores versioned vehicle twins with cohort, software version, age, usage, health index, telemetry, and model parameters. Prognostics provide:

- remaining useful life;
- bootstrap confidence intervals;
- Weibull-style horizon failure probability;
- cohort-normalized anomaly score;
- anomaly verdict.

Federated aggregation supports:

- sample-weighted FedAvg;
- coordinate median;
- trimmed mean;
- client update norm clipping;
- robust median/MAD poisoning rejection;
- accepted/rejected client records;
- aggregate validation loss;
- deterministic model hash.

## Qualification

The dedicated test target covers nominal and failure paths across all twelve domains. Qualification includes:

```bash
./build/next_generation_platform_tests
./build/muzixdiagsys_advanced_platform self-test /tmp/muzix-self-test report.json
```

Sanitizer qualification:

```bash
cmake -S . -B build-san -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON -DAESIM_ENABLE_SANITIZERS=ON
cmake --build build-san --target next_generation_platform_tests -j
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1 \
  ./build-san/next_generation_platform_tests
```

The test suite exercises real ML-KEM and ML-DSA operations, optional hybrid and SLH-DSA algorithms when available, formal proof verification, ONNX interval propagation, generated-C compilation, all rare-event methods, NPU timing, deterministic USD output, manufacturing reproducibility, and robust rejection of a poisoned federated client.

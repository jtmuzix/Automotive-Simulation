# Global Mathematical Assurance Platform

## Purpose

The Global Mathematical Assurance Platform extends the shared numerical kernel from solver-level stability to result-level qualification. It preserves every existing numerical method and public API while adding eight cross-cutting services:

1. automatic error budgets;
2. adaptive precision escalation;
3. multiprecision and exact verified references;
4. reproducible exact reductions;
5. convergence and manufactured-solution testing;
6. derivative and optimization certification;
7. cross-solver consensus and deterministic property testing;
8. SHA-256-sealed mathematical evidence certificates.

The public header is:

```cpp
#include "aesim/core/mathematical_assurance.hpp"
```

It is also re-exported by `aesim/advanced/platform.hpp`. The namespace is:

```cpp
aesim::core::math_assurance
```

## Automatic error budgets

`ErrorBudgetBuilder` accepts individually classified contributions. The implementation distinguishes floating-point, linear-solver, nonlinear-solver, temporal-discretization, spatial-discretization, interpolation, quadrature, sampling, surrogate, parameter, measurement, and model-form sources.

Each contribution contains:

- an absolute bound;
- a standard uncertainty;
- a confidence level;
- an optional correlation group;
- a rationale and evidence-facing name.

Three combination rules are available:

- root-sum-square for independent standard uncertainties;
- worst-case addition for conservative bounded analysis;
- correlation-group combination, in which contributions in the same group combine linearly and independent groups combine quadratically.

The summary reports numerical, parameter, measurement, model-form, and total predictive uncertainty separately. This prevents model discrepancy or test-instrument uncertainty from being misrepresented as floating-point error.

Convenience adapters ingest existing `DenseSolveResult`, `QuadratureResult`, and `OdeResult` diagnostics.

## Adaptive precision escalation

`evaluate_adaptive_precision` evaluates a supplied calculation through available precision tiers:

```text
binary64 -> extended -> decimal50 -> decimal100
```

The controller evaluates absolute and relative change between tiers, estimates retained decimal digits, accounts for condition-number amplification, and stops only when the requested agreement and verified-digit thresholds are met. If the highest available tier does not meet the policy, the report remains explicitly unqualified.

`make_polynomial_precision_problem` supplies all four evaluators for cancellation-sensitive polynomial calculations. Other domains can provide their own callbacks while retaining the same escalation policy and evidence format.

## Multiprecision and exact verified references

A dependency-free C++17 arbitrary-precision backend provides exact signed-integer and dyadic arithmetic plus correctly rounded 50- and 100-digit decimal reference rendering. For finite IEEE-754 binary64 sums, dot products, and polynomial evaluations, the platform decomposes every input into an exact signed integer significand and power-of-two exponent, performs all accumulation with unbounded integers, and returns the exact dyadic rational. No Boost, GMP, MPFR, or other external multiprecision package is required for the default build.

The exact result includes:

- exact integer significand;
- binary exponent;
- exact rational numerator and denominator;
- a 100-digit decimal rendering;
- an explicitly nearest-even rounded binary64 result.

`compare_with_reference` reports absolute error, relative error, ULP distance, and verified decimal digits against that exact result.

## Reproducible exact reductions

`exact_sum` and `exact_dot` do not depend on input order, thread count, SIMD width, or reduction-tree shape. Products are formed exactly from decomposed significands before integer accumulation. The final binary64 conversion is performed by an explicit IEEE-754 nearest-even rounding procedure, including normal, subnormal, tie, underflow, and overflow handling.

The implementation therefore provides a deterministic oracle for conservation totals, residual norms assembled from sums, Monte Carlo aggregates, distributed reductions, and regression references. It complements rather than removes the faster compensated reduction APIs.

## Global convergence analysis

`analyze_convergence` accepts at least three refinement levels and reports:

- observed convergence order;
- Richardson-extrapolated value;
- fine- and coarse-grid convergence indices;
- asymptotic-range ratio;
- monotonic or oscillatory behavior;
- convergence and qualification diagnostics.

When exact errors are supplied, the order is estimated by log-log regression across all levels. Otherwise, the finest three solution values provide the estimate.

## Manufactured-solution tests

Two executable manufactured-solution services are included:

- `run_manufactured_ode_test` uses a fourth-order Runge-Kutta discretization against an analytic exact solution and derivative;
- `run_manufactured_poisson_1d_test` solves `-u'' = f` with second-order central differences and exact boundary data.

Both calculate `L1`, `L2`, and `L-infinity` errors over multiple refinement levels, call the global convergence analyzer, and enforce a configurable minimum observed order. They provide reusable templates for adding manufactured equations to every PDE and dynamics subsystem.

## Unified derivative certification

`certify_derivative` compares independent methods:

- supplied analytic derivative;
- complex-step derivative;
- five-point finite difference;
- Richardson-extrapolated five-point derivative;
- Taylor-remainder scaling.

A certificate passes only when the methods agree within combined absolute and relative tolerance and the Taylor remainder exhibits the expected second-order behavior. This detects incorrect analytic derivatives, automatic-differentiation plumbing defects, inappropriate finite-difference steps, and nonanalytic complex-step use.

## Optimization certification

`certify_optimization` evaluates a candidate solution using:

- equality and inequality primal feasibility;
- bound feasibility;
- nonnegative inequality multipliers;
- complementarity;
- Lagrangian stationarity;
- projected gradient at active bounds;
- aggregate KKT residual;
- minimum eigenvalue of a supplied symmetric Lagrangian Hessian.

The result distinguishes solver termination from mathematical optimality. A candidate is qualified only when the configured KKT tolerances and supplied curvature check pass.

## Cross-solver consensus

`cross_solver_consensus` accepts named scalar or vector results from independent methods. It builds a componentwise median reference, evaluates every solver pair, identifies outliers, checks the number of independent implementations, and reports maximum absolute and relative disagreement.

Typical uses include:

- direct versus iterative linear solution;
- explicit versus implicit integration;
- analytic versus automatic versus numerical derivatives;
- production versus multiprecision reference calculations;
- full-order versus reduced-order models.

## Deterministic property-based testing

`run_property_test` generates deterministic samples from declared finite ranges using a recorded 64-bit seed. The caller supplies a mathematical predicate and diagnostic. On failure, the implementation retains the first counterexample and performs coordinate-wise shrinking toward the nearest representable zero in the allowed range.

Suitable properties include conservation, symmetry, reciprocity, monotonicity, positivity, coordinate invariance, unit-system invariance, limiting behavior, and metamorphic relations.

## Mathematical evidence certificates

`MathematicalEvidenceCertificate` binds together:

- operation and method identity;
- precision and tolerances;
- iterations, residual, backward error, condition estimate, and verified digits;
- qualification and convergence state;
- complete error budget;
- optional convergence, derivative, optimization, and consensus reports;
- property-test summaries;
- arbitrary sorted metadata.

`seal()` generates a canonical JSON representation and SHA-256 digest. `verify_digest()` detects any subsequent change to the certified mathematical evidence.

Example:

```cpp
using namespace aesim::core::math_assurance;

ErrorBudgetBuilder builder;
builder.add({"mesh", ErrorCategory::SpatialDiscretization,
             0.4, 0.2, "mesh", 0.682689492137,
             "three-level grid convergence"});

MathematicalEvidenceCertificate certificate;
certificate.result_id = "brake-thermal-run-42";
certificate.operation = "brake_thermal_transient";
certificate.method = "implicit_finite_volume";
certificate.precision = "binary64+decimal100-reference";
certificate.error_budget = builder.summarize();
certificate.converged = true;
certificate.qualified = true;
certificate.seal();

if (!certificate.verify_digest()) {
    throw std::runtime_error("mathematical evidence digest mismatch");
}
```

## Validation

Focused build:

```bash
cmake -S . -B build/math-assurance -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_TESTING=ON
cmake --build build/math-assurance --target mathematical_assurance_tests -j
./build/math-assurance/mathematical_assurance_tests
```

The focused regression covers cancellation-sensitive exact sums and dot products, explicit nearest-even rounding, exact polynomial references, condition-aware precision escalation, Richardson/GCI analysis, fourth-order ODE and second-order Poisson manufactured solutions, analytic/complex-step/five-point derivative agreement, KKT and Hessian certification, independent solver consensus, deterministic property trials, and evidence digest verification.

## Qualification boundary

The platform certifies mathematical behavior that is represented by its inputs and checks. It cannot establish that a physical constitutive model, boundary condition, scenario distribution, measurement campaign, or regulatory interpretation is valid. Final engineering qualification still requires representative validation data, applicability evidence, and domain review.

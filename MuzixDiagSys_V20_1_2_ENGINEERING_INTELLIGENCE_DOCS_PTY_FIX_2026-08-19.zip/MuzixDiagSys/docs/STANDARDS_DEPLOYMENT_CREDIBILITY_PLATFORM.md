# MuzixDiagSys Standards, Deployment, and Credibility Platform

## 1. Purpose

The standards, deployment, and credibility platform adds an integrated C++17 engineering layer for scenario compilation, operational-design-domain governance, co-simulation scheduling, system-package exchange, formal analysis, perception differentiation, localization, radio propagation, sim-to-real adaptation, interactive-agent reasoning, and calibrated predictive uncertainty.

The public API is declared in:

```text
include/aesim/research2/standards_deployment_platform.hpp
```

The implementation is divided into:

```text
src/research2/standards_scenario_odd.cpp
src/research2/standards_formal_runtime.cpp
src/research2/standards_perception_intelligence.cpp
```

The operator utility is:

```text
muzixdiagsys_standards_deployment
```

All additions are linked through `aesim_industrial`; existing applications, libraries, plugins, FMI interfaces, command paths, and project formats remain available.

## 2. Standards baseline and conformance policy

The implementation is engineered against the following published standards families:

- ASAM OpenSCENARIO DSL 2.2.0 concepts for abstract, parameterized, constraint-driven scenarios.
- ASAM OpenODD concepts and ISO 34503-oriented hierarchical ODD taxonomy paths.
- FMI 3.0.2 Scheduled Execution concepts, including clocks and independently activated model partitions.
- SSP 2.0.1 package organization for system structures, parameter sets, mappings, dictionaries, and resources.
- The ASAM OpenX family as the semantic source domains for scenarios, ODDs, roads, labels, and simulation-interface entities.

MuzixDiagSys emits explicit profile metadata and validation reports. It does not claim third-party certification, official ASAM conformance approval, or equivalence to an external commercial solver. Unsupported or invalid constructs are diagnosed; they are not silently ignored.

## 3. Build and validation

Configure and build:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build -j
```

Run the dedicated suite:

```bash
ctest --test-dir build -R 'standards_deployment_(platform_unit_tests|cli_self_test)' --output-on-failure
```

Inspect the capability inventory:

```bash
./build/muzixdiagsys_standards_deployment capabilities
```

Run the integrated self-test:

```bash
./build/muzixdiagsys_standards_deployment self-test
```

## 4. OpenSCENARIO DSL compiler

### 4.1 Implemented language profile

`OpenScenarioDslCompiler` provides a deterministic lexer, parser, semantic validator, typed abstract syntax tree, scenario instantiator, canonical source emitter, and OpenSCENARIO XML exporter.

Implemented declarations and statements include:

- Scenario declarations and optional base-scenario metadata.
- Real, integer, Boolean, string, and enumeration parameters.
- Numeric ranges, defaults, deterministic distributions, and caller overrides.
- Actors with type, model, and properties.
- Metadata entries.
- Local variables and assignments.
- Actor actions with evaluated numeric arguments.
- Timed waits.
- Emitted events.
- Constraints and coverage goals.
- Conditional branches.
- Repeat blocks.
- Deterministically elaborated parallel blocks.
- Arithmetic, comparison, and Boolean expressions.
- Engineering-unit literals including seconds, milliseconds, microseconds, distance, velocity, acceleration, angle, and percentage.

Numeric tokenization distinguishes decimal points from range delimiters. The following are separate and valid:

```text
speed: real in [10..30]
wait 0.25s
set gain = 1.0e-3
```

### 4.2 Example

```text
scenario Merge(speed: real in [10..30], repetitions: int in [1..3] = 2) {
  meta purpose = "boundary coverage";
  actor ego: vehicle model "sedan";
  actor other: vehicle model "suv";

  constraint speed >= 10 && speed <= 30;
  let target = speed + 2;
  do ego.set_speed(speed);

  repeat repetitions {
    wait 100ms;
    do other.set_speed(target);
  }

  if (speed > 15) {
    emit high_speed();
  } else {
    emit low_speed();
  }

  cover target > speed;
}
```

Compile and elaborate:

```cpp
OpenScenarioDslCompiler compiler;
auto compiled = compiler.compile_file("merge.osc");
if (!compiled.valid) throw std::runtime_error(compiled.report());

auto instance = compiler.instantiate(compiled, 42, {{"speed", 20.0}});
auto xml = compiler.emit_open_scenario_xml(instance);
```

CLI conversion:

```bash
muzixdiagsys_standards_deployment compile-scenario merge.osc merge.json
muzixdiagsys_standards_deployment compile-scenario merge.osc merge.xosc
```

The generated instance records the source digest, deterministic seed, resolved parameters, actors, ordered events, coverage goals, and constraint violations.

## 5. OpenODD and ISO 34503-oriented engine

`OpenOddIso34503Engine` manages reusable ODD modules and hierarchical attribute domains.

### 5.1 Data model

An ODD module contains:

- A stable identifier, display name, description, and metadata.
- Included parent modules.
- Numeric, categorical, and Boolean attributes.
- ISO 34503-oriented taxonomy paths.
- Units, inclusive/exclusive boundaries, categories, and confidence.

### 5.2 Operations

The engine supports:

- JSON/YAML document import and deterministic export.
- Include resolution.
- Point-in-ODD assessment.
- Normalized boundary margins.
- ODD intersection.
- Subset checks with reasons.
- Deterministic boundary sampling.
- Multidimensional cell coverage.
- Risk-weighted coverage.
- Uncovered boundary-point reporting.

Example:

```cpp
OpenOddIso34503Engine odd;
odd.add_module({
    "highway", "Highway ODD", "Validated highway operating domain",
    {
        {"speed", "Speed", "scenery.dynamic.speed", OddAttributeKind::Numeric,
         "m/s", 0.0, 40.0, {}, true, true, 1.0},
        {"weather", "Weather", "environment.weather", OddAttributeKind::Categorical,
         "1", 0.0, 0.0, {"clear", "rain"}, true, true, 1.0}
    }, {}, {}
});

auto result = odd.assess("highway", {{"speed", 25.0}, {"weather", "clear"}});
```

## 6. FMI 3.0 Scheduled Execution master

`Fmi3ScheduledExecutionMaster` coordinates periodic, aperiodic, and externally triggered clocks and their model partitions.

### 6.1 Scheduling policies

- Time-triggered ordering.
- Fixed-priority ordering.
- Earliest-deadline-first ordering.

### 6.2 Runtime behavior

The master provides:

- Clock registration and trigger queues.
- Partition dependencies.
- WCET and deadline metadata.
- Jitter and deadline-miss accounting.
- Deterministic activation ordering.
- Timeline reports.
- Scheduler checkpoint and restoration.
- Binding to `aesim::fmi3::ImportedModel` instances.
- Direct partition activation through the FMI 3 Scheduled Execution entry point.

Example:

```cpp
Fmi3ScheduledExecutionMaster master;
master.set_policy(FmiSchedulePolicy::FixedPriority);
master.add_clock({"control", FmiClockKind::Periodic, 0.001, 0.0, 10});
master.add_partition({
    {"controller", "control", 100, 0.0002, 0.001, 10, {}},
    [](double time_s) { /* execute controller partition */ },
    {}, {}
});
master.initialize();
auto report = master.run_until(1.0);
```

The existing FMI importer gained `activate_partition()` and `current_time()` without removing its Model Exchange or Co-Simulation functionality.

## 7. SSP 2.x package support

`Ssp2Package` reads, validates, compares, and writes deterministic `.ssp` ZIP packages.

### 7.1 Preserved package surfaces

- `SystemStructure.ssd` components, connectors, and connections.
- Component implementation type and FMI interface kind.
- Connector type, unit, dimensions, and clock association.
- Linear connection transformations.
- SSV parameter values.
- SSM parameter mappings and transformations.
- SSB signal dictionary entries and descriptions.
- Referenced FMUs and arbitrary resources.
- Package and component annotations.
- MuzixDiagSys extension manifest.

### 7.2 Integrity

Validation checks include:

- Unique component and connector identities.
- Valid connector directions.
- Existing connection endpoints.
- Signal-type compatibility.
- Unit mismatch warnings when no transformation is defined.
- Parameter-mapping endpoint validity.
- Canonical SHA-256 identity.

The canonical digest includes topology, parameters, mappings, dictionaries, annotations, connector metadata, and content hashes for all package resources.

## 8. Unified OpenX semantic ontology

`UnifiedOpenXOntology` provides a typed semantic graph connecting:

- Scenarios.
- ODD modules.
- Roads and lanes.
- Actors and sensors.
- Signals and materials.
- Coordinate systems.
- Requirements and evidence.
- Models, parameters, and units.

The graph supports aliases, typed queries, property filters, directed path discovery, referential-integrity validation, deterministic persistence, and cross-format provenance.

Example:

```cpp
UnifiedOpenXOntology ontology;
ontology.add_entity({"scenario.merge", "Merge", OpenXEntityKind::Scenario, {}, {}, "OpenSCENARIO"});
ontology.add_entity({"odd.highway", "Highway ODD", OpenXEntityKind::OddModule, {}, {}, "OpenODD"});
ontology.add_relation({"r1", "constrainedBy", "scenario.merge", "odd.highway", {}});
```

## 9. Visual ODD and coverage studio

`VisualOddCoverageStudio` generates:

- SSH-friendly fixed-width terminal reports.
- Self-contained HTML dashboards requiring no external JavaScript or CSS.
- Coverage cells, pass/failure counts, robustness, and risk weighting.
- ODD attribute and taxonomy tables.
- Scenario-instance tables.
- Boundary-gap summaries.

Example:

```cpp
VisualOddCoverageStudio studio;
studio.write_html("odd-coverage.html", resolved_module, coverage, scenarios);
```

## 10. Validated numerics

`ValidatedInterval` uses outward rounding through adjacent representable floating-point values. It implements:

- Addition, subtraction, multiplication, and division.
- Square root and exponential enclosures.
- Sine and cosine enclosures with critical-point analysis.
- Hull and intersection.
- Width, midpoint, radius, and containment queries.

`ValidatedNumerics` provides interval dot products, strict diagonal-dominance checks, and validated explicit-Euler propagation with a caller-supplied local truncation-error enclosure.

```cpp
ValidatedInterval x(0.9, 1.1);
auto result = ValidatedNumerics::integrate_euler(
    [](double, const IntervalVector& state) {
        return IntervalVector{ValidatedInterval::point(-1.0) * state[0]};
    }, {x}, 0.0, 1.0, 0.01, 1e-5);
```

A result is marked verified only when its enclosure propagation remains valid and no empty interval is produced. This mechanism provides floating-point enclosures; a certificate is only as strong as the supplied dynamics and truncation bound.

## 11. SMT and delta-SAT backend

`DeltaSatSolver` combines:

- A deterministic DPLL Boolean CNF solver.
- Unit propagation.
- Boolean model extraction.
- Interval branch-and-prune for bounded nonlinear real constraints.
- Equality and inequality residual semantics.
- Configurable delta, box budget, and minimum width.
- SAT, delta-SAT, UNSAT, and UNKNOWN outcomes.
- Real-valued witness reconstruction and residual reporting.

Example:

```cpp
DeltaSatProblem problem;
problem.real_variables = {{"x", ValidatedInterval(1.0, 2.0)}};
problem.constraints = {{
    "sqrt2", "x*x-2=0",
    [](const IntervalVector& x) { return x[0] * x[0] - ValidatedInterval::point(2.0); },
    [](const StateVector& x) { return x[0] * x[0] - 2.0; },
    true
}};
auto result = DeltaSatSolver{}.solve(problem, 1e-6);
```

An UNKNOWN result is retained when subdivision or search budgets are exhausted. It is never converted into a proof of safety.

## 12. Probabilistic model checking

`ProbabilisticModelChecker` supports finite:

- Discrete-time Markov chains.
- Markov decision processes.
- Reachability and bounded reachability.
- Minimum and maximum adversarial reachability probabilities.
- Expected accumulated reward.
- Deterministic value iteration with convergence diagnostics.
- Optimal policy extraction for MDP states.

Transition probabilities are validated and normalized per state/action group only when their numerical sum is within the configured tolerance.

## 13. Certified model-order reduction

`CertifiedModelOrderReducer` performs snapshot-based proper orthogonal decomposition for discrete linear state-space systems.

The implementation provides:

- Deterministic excitation snapshots.
- Covariance construction.
- Symmetric Jacobi eigen decomposition.
- Projection and lifting matrices.
- Reduced A, B, C, and D matrices.
- Retained-energy accounting.
- State projection error bounds.
- Global output-error bounds for contractive systems.
- Explicit findings when a finite global certificate cannot be established.

A model is marked certified only when the contraction-based bound is mathematically finite under the implemented norm assumptions.

## 14. WCET and schedulability analysis

`WcetSchedulabilityAnalyzer` supports:

- Fixed-priority preemptive response-time analysis.
- Earliest-deadline-first utilization and deadline checks.
- Release jitter.
- Blocking time.
- Per-task priorities and core assignments.
- Total utilization and density.
- First-fit-decreasing multicore partitioning.
- Per-task response time and slack.

Timing inputs must be measured, statically bounded, or otherwise justified by the caller. The analyzer does not invent WCET values.

## 15. Security-protocol verification

`SecurityProtocolVerifier` implements a bounded symbolic Dolev-Yao-style protocol analysis.

Supported operations:

- Nonce generation.
- Send and receive.
- Symmetric symbolic encryption and decryption.
- Symbolic signing and verification.
- Acceptance with optional freshness requirements.
- Intruder knowledge closure.
- Optional replay and substitution attacks.
- Secrecy, authentication, and freshness claims.
- Attack traces and final intruder knowledge.

The model intentionally treats cryptographic primitives as perfect symbolic constructors. Computational cryptanalysis, side channels, weak random-number generators, and concrete cryptographic implementation defects require separate models.

## 16. Differentiable sensor rendering

`DifferentiableSensorRenderer` generates analytic observations and Jacobians for camera, radar, and lidar geometry.

### Camera

- Pinhole projection.
- Horizontal and vertical image coordinates.
- Depth and apparent extent.
- Jacobians with respect to target state.
- Visibility and near-singularity warnings.

### Radar

- Range.
- Radial velocity.
- Azimuth.
- Received-power proxy.
- Analytic geometric Jacobians.

### Lidar

- Range.
- Azimuth.
- Elevation.
- Reflectivity.
- Analytic geometric Jacobians.

The renderer reports nondifferentiable or poorly conditioned regions, such as targets at the sensor origin or behind the camera plane.

## 17. SLAM and localization laboratory

`EkfSlamLocalizer` implements two-dimensional EKF SLAM with:

- Pose initialization.
- Velocity/yaw-rate prediction.
- Process-noise propagation.
- Dynamic landmark-state augmentation.
- Range and bearing updates.
- Joseph-form covariance update.
- Normalized innovation squared.
- Chi-square-style integrity gating.
- Rejected-observation reporting.

The complete covariance includes cross-correlations between vehicle pose and all mapped landmarks.

## 18. RF, V2X, and GNSS propagation

`RfV2xGnssPropagationLab` provides deterministic physical-link and positioning studies.

### RF/V2X link

- Free-space reference loss.
- Configurable path-loss exponent.
- Antenna gain.
- Polarization mismatch.
- Obstacle attenuation.
- Log-normal shadowing with deterministic seed.
- Thermal noise and receiver noise figure.
- SNR.
- BPSK/QPSK-style BER approximation.
- Packet-error probability.
- Deterministic multipath-tap summaries.

### GNSS

- Satellite ECEF geometry.
- Receiver and satellite clock bias.
- Deterministic pseudorange generation.
- Weighted iterative least-squares positioning.
- Receiver clock-bias estimation.
- Covariance, residual RMS, and GDOP.
- Insufficient-geometry and singularity rejection.

## 19. Sim-to-real adaptation

`SimToRealAdapter` implements a governed statistical alignment pipeline:

- Source and target mean/covariance estimation.
- Covariance regularization.
- CORAL-style whitening and recoloring.
- Gaussian diagonal-density importance weights.
- Weight clipping and effective sample size.
- Optional regularized residual regression from labeled real data.
- Before/after discrepancy metrics.
- Explicit validity status and findings.

The adapter does not silently replace the original physics model. Its output is a versionable correction artifact whose domain and validation evidence should be recorded in the existing validity registry and experiment database.

## 20. Interactive game-theoretic traffic agents

`GameTheoreticTrafficEngine` performs iterative best-response reasoning over a discrete action space.

Agent state includes:

- Longitudinal position.
- Lane.
- Speed and desired speed.
- Aggressiveness.
- Reasoning level.

Actions contain acceleration and lane change. A caller may provide a custom utility function; otherwise the built-in utility balances speed tracking, acceleration effort, lane-change effort, and collision proximity. The solver reports convergence, utility, iteration count, and maximum regret.

The resulting action profile can be stepped forward deterministically and fed back into scenario falsification or ODD coverage campaigns.

## 21. Conformal uncertainty calibration

### 21.1 Split conformal regression

`SplitConformalRegressor` provides finite-sample residual calibration around an arbitrary deterministic point predictor:

- Absolute residual nonconformity scores.
- Finite-sample corrected empirical quantile.
- Prediction intervals.
- Nominal coverage metadata.
- Held-out coverage and mean-width evaluation.

### 21.2 Adaptive conformal regression

`AdaptiveConformalRegressor` maintains an online interval radius using observed misses and a bounded sliding coverage history. It reports the current quantile and empirical coverage.

Conformal guarantees depend on the applicable exchangeability or online-adaptation assumptions. The software reports empirical calibration; it does not claim those assumptions are automatically satisfied by every fleet or time-series dataset.

## 22. Determinism and provenance

The new layer follows these deterministic rules:

- Every stochastic operation accepts or stores an explicit seed.
- Stable maps and sorted traversal are used where output order affects artifacts.
- Scenario elaboration is independent of thread scheduling.
- SSP packages use deterministic archive generation.
- Canonical JSON and SHA-256 identify semantic package content.
- Formal backends preserve UNKNOWN when budgets are exhausted.
- Floating-point enclosure operations round outward.
- Runtime reports expose approximations, convergence, and validity findings.

## 23. Test coverage

`tests/standards_deployment_platform_tests.cpp` exercises every requested subsystem, including:

- DSL parsing, decimal/range/unit handling, deterministic elaboration, and XML emission.
- ODD include resolution, membership, boundary coverage, and HTML rendering.
- FMI partition scheduling, dependencies, deadlines, and checkpointing.
- Full SSP topology/parameter/mapping/dictionary/dimension/clock/annotation/resource round trip.
- Ontology aliases and path discovery.
- Validated integration and interval arithmetic.
- Nonlinear delta-SAT witness generation.
- DTMC reachability.
- Certified reduction.
- Fixed-priority and EDF schedulability.
- Protocol secrecy/authentication/freshness.
- Sensor Jacobians against finite differences.
- EKF SLAM integrity.
- RF and GNSS calculations.
- Sim-to-real discrepancy reduction.
- Traffic-game convergence.
- Split and adaptive conformal calibration.

The CLI self-test independently exercises scenario compilation, ODD assessment, probabilistic checking, and conformal prediction.

## 24. Operational boundaries

The implementation is complete for the APIs and profiles described in this document; there are no intentional stub or placeholder paths. The following are explicit scope boundaries rather than hidden omissions:

- The OpenSCENARIO compiler implements the documented MuzixDiagSys deterministic DSL profile and exports OpenSCENARIO XML 1.3-compatible instances; it is not an official ASAM certification harness.
- The OpenODD engine uses a machine-readable JSON/YAML profile with ISO 34503 taxonomy paths; it does not assert that every external vendor schema uses the same serialization.
- The delta-SAT backend is an in-process bounded interval solver, not a wrapper around Z3, dReal, or another external theorem prover.
- Probabilistic checking targets finite explicit-state models.
- Model-reduction certificates use the implemented POD and contraction assumptions.
- Sensor differentiation covers the implemented analytic sensor geometry, not a full photorealistic or electromagnetic renderer.
- RF propagation uses deterministic engineering channel models rather than full-wave electromagnetic simulation.
- Security-protocol verification is symbolic and bounded.

These boundaries are surfaced in documentation and result objects so engineering conclusions can be qualified correctly.

# IndyCar Engineering Assurance Platform

**Revision:** 2026-07-28  
**Library:** `aesim_indycar`  
**Public header:** `include/aesim/advanced/indycar_engineering_assurance_platform.hpp`  
**CLI family:** `muzixdiagsys_advanced_platform indycar-assurance`

## 1. Purpose and compatibility

The IndyCar Engineering Assurance Platform is an additive seventh IndyCar module. It adds fourteen executable domains that connect effective-dated regulation, evolving vehicle legality, 2028 certification, prospective manufacturer entry, probabilistic competition observations, officiating policy, progressive damage, crash/fire/debris safety, composite and tire manufacturing, fleet reliability, and information-optimal testing.

The module does not replace or remove the existing IR-18, operations, future-competition, frontier-expansion, development/operations, or integrated-fidelity platforms. All prior public headers, CLI families, examples, and tests remain available. The new implementation is compiled into `aesim_indycar`, exported by `aesim/advanced/platform.hpp`, and exposed through a separate `indycar-assurance` command family.

Every domain performs strict type, range, chronology, identifier, topology, and finite-arithmetic validation. Every successful or failed engineering report contains structured findings and a canonical SHA-256 `evidence_digest`. When a working directory is supplied, the report is written atomically for reproducibility and audit.

## 2. Domain inventory and public classes

| CLI domain | Public class | Entry point |
|---|---|---|
| `regulation-digital-thread` | `IndyCarRegulationDigitalThread` | `evaluate()` |
| `dynamic-compliance` | `IndyCarDynamicCompliance` | `simulate()` |
| `next-generation-certification` | `IndyCarNextGenerationCertification` | `evaluate()` |
| `prospective-manufacturer-program` | `IndyCarProspectiveManufacturerProgram` | `evaluate()` |
| `timing-observation-fusion` | `IndyCarTimingObservationFusion` | `fuse()` |
| `officiating-policy-lab` | `IndyCarOfficiatingPolicyLab` | `evaluate()` |
| `contact-damage-raceability` | `IndyCarContactDamageRaceability` | `simulate()` |
| `crash-safer-fe` | `IndyCarCrashSaferFiniteElementTwin` | `simulate()` |
| `fire-rescue-hazards` | `IndyCarFireRescueHazards` | `simulate()` |
| `debris-recovery` | `IndyCarDebrisRecovery` | `simulate()` |
| `composite-manufacturing` | `IndyCarCompositeManufacturing` | `evaluate()` |
| `fleet-reliability` | `IndyCarFleetReliability` | `evaluate()` |
| `test-design-calibration` | `IndyCarTestDesignCalibration` | `optimize()` |
| `tire-material-digital-thread` | `IndyCarTireMaterialDigitalThread` | `evaluate()` |

Aggregate API:

```cpp
#include "aesim/advanced/indycar_engineering_assurance_platform.hpp"

using aesim::advanced::indyassure::IndyCarEngineeringAssurancePlatform;

IndyCarEngineeringAssurancePlatform platform;
auto capabilities = platform.capabilities();
auto report = platform.execute(
    "next-generation-certification",
    request,
    "evidence/indycar-assurance");
auto self_test = platform.self_test("evidence/indycar-assurance/self-test");
```

## 3. Configure, build, and test

```bash
cmake -S . -B build/indycar-assurance -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF

cmake --build build/indycar-assurance --parallel --target \
  aesim_indycar \
  indycar_engineering_assurance_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/indycar-assurance --output-on-failure \
  -R '^indycar_.*(platform_unit_tests|source_regression)$'
```

Run the focused source-completeness regression directly:

```bash
python3 tests/indycar_engineering_assurance_source_regression.py .
```

## 4. CLI operation

```bash
./build/indycar-assurance/muzixdiagsys_advanced_platform \
  indycar-assurance capabilities \
  build/indycar-assurance/capabilities.json

./build/indycar-assurance/muzixdiagsys_advanced_platform \
  indycar-assurance self-test \
  build/indycar-assurance/evidence \
  build/indycar-assurance/self-test.json

./build/indycar-assurance/muzixdiagsys_advanced_platform \
  indycar-assurance DOMAIN \
  examples/indycar_engineering_assurance/REQUEST.json \
  build/indycar-assurance/result.json \
  build/indycar-assurance/evidence
```

The fourteen canonical request files under `examples/indycar_engineering_assurance/` are parsed and executed by the focused C++ test. They are also suitable for production CLI regression and deterministic replay.

## 5. Regulation digital thread

The regulation resolver converts effective-dated technical and sporting requirements into one authoritative numerical configuration. Each rule declares lifecycle state, revision, precedence, effective and optional expiry dates, series/track/session selectors, parameters, and affected software dependencies.

Resolution order is deterministic: precedence, selector specificity, lifecycle rank, revision, and rule ID. Equal-ranked disagreement produces an error rather than selecting an arbitrary value. The report includes selected-rule provenance, lower-ranked conflicts, baseline differences, dependency trace, and saved-study invalidations. The model supports event-specific waivers and historical replay without hard-coded current-rule assumptions.

## 6. Dynamic compliance and legality drift

The compliance model advances fuel mass, ride height, spring settling, damper fade, tire-radius loss, underfloor wear, aeroelastic floor deflection, body or aero-part offset, toe change, fluid loss, and contact damage over ordered race segments. Each regulated measurement includes lower and upper bounds plus measurement standard uncertainty.

For every time point the solver computes two-sided noncompliance probability. It records peak probability by measurement, first probable noncompliance time, final measurements, violation history, and statistically derived guard bands. This allows wear, damage, repair, assembly shift, and measurement uncertainty to be distinguished from a static pre-session setup error.

## 7. Next-generation certification

The 2028 certification engine is a requirement-to-evidence release model rather than a checklist. Requirements carry subsystem, lifecycle state, criticality, target maturity, verification method, and dependencies. Evidence carries design revision, date, method, maturity, result margin, calibration coverage, uncertainty, and independent-review status.

The engine:

- rejects unknown dependencies, duplicate IDs, invalid dates, and unsupported methods;
- invalidates evidence from a different design revision or after the review date;
- penalizes provisional requirements without presenting them as final rules;
- scores maturity, calibration coverage, physical margin, uncertainty, method strength, and independence;
- propagates prerequisite failures through the requirement graph;
- tracks design changes requiring reverification;
- evaluates supplier, manufacturing, software, trackside, and safety readiness;
- reports weighted program score, open high risks, provisional count, verification matrix, and invalidated evidence.

A passing report means the encoded release gates passed for the submitted evidence. It is not an official homologation or safety certificate.

## 8. Prospective manufacturer program

The manufacturer-entry model evaluates the complete program rather than only engine parity. A dependency-checked milestone graph produces remaining work, critical path, cost, and completion state. Test records contribute constrained test days, correlation quality, and requirement coverage. Engine and aerodynamic samples produce parity errors. Supplier capacity, quality, delivery, and criticality produce weighted readiness.

The output reports program cost, test allocation, critical path, technical readiness, parity errors, supplier readiness, approval blockers, and explicit budget or test-limit violations. It is suitable for scenario studies involving a new power-unit manufacturer, customer-team allocation, hybrid compatibility, production ramp, and trackside support readiness.

## 9. Timing observation fusion

The timing model fuses timing-loop, transponder, video, telemetry, GNSS, and other observations. Each observation carries source, latency, standard uncertainty, detection probability, source quality, car ID, lap, and timestamp.

The solver corrects latency, forms inverse-variance estimates, and iteratively applies Huber robust weights. It reports fused crossing time and confidence interval, source residuals, consistency score, source health, most probable order, and adjacent-car order-reversal probability. Alternative classifications remain visible when evidence is insufficient to establish a unique order.

## 10. Officiating policy laboratory

The policy laboratory evaluates alternative caution, pit-state, investigation, penalty, and review policies against incident severity, blockage, medical urgency, debris hazard, fault probability, evidence confidence, position sensitivity, comparable precedent, competitive impact, and due process.

It reports residual safety risk, field-compression and competitive costs, consistency, sanction proportionality, and ranked policy behavior. The model explicitly separates observed facts, reconstructed facts, rule interpretation, discretionary policy, sanction, and simulated competitive consequence. Human officials retain decision authority.

## 11. Progressive contact damage and raceability

The contact model covers nonterminal front, rear, side, and wheel-area contact. Successive impulses update structural crush, front-wing/floor/aero damage, toe and steering bias, tire leakage and puncture risk, cooling restriction, drag, downforce, vibration, tire temperature, power-unit temperature, achievable speed, and repair time.

The final report includes the complete event history, remaining raceability, minimum competitive-speed status, unsafe-continuation findings, and pit repair estimate. Damage states can be passed into the integrated multibody, tire, aeroelastic, thermal, racecraft, inspection, and pit-lane models.

## 12. Crash and SAFER finite-element twin

The crash domain implements an explicit nodal and structural-element solver for a reduced but executable finite-element topology. It includes:

- nodal mass, position, velocity, acceleration, and damping;
- nonlinear spring-damper elements;
- yielding, permanent extension, and ultimate-strain failure;
- wall and deformable-barrier penalty contact;
- vehicle and barrier energy accounting;
- intrusion and occupant-reference acceleration histories;
- barrier deflection, failed-element reporting, and HIC15 screening.

The solver rejects invalid topology, duplicate IDs, nonpositive masses or stiffnesses, unstable time steps, and unknown reference nodes. Detailed certification still requires calibrated 3-D meshes, composite material cards, contact definitions, convergence studies, and physical correlation.

## 13. Fire, smoke, toxic exposure, and rescue

Fuel and oil release, ignition, burn rate, heat-release rate, oxygen consumption, smoke, carbon monoxide, visibility, cockpit temperature, radiant heat, suppression agent, ventilation, fuel isolation, safety-worker routes, and extraction evolve in one deterministic simulation.

Actions occur at ordered times and affect subsequent source terms rather than only the final summary. The report provides ignition/extinguishment time, peak heat release, driver thermal dose, carbon-monoxide dose, final visibility, route risk, marshal arrival, extraction completion, reignition risk, and survivability screening.

## 14. Debris fragmentation and recovery confidence

Fragments carry mass, area, position, velocity, and puncture severity. The solver advances three-dimensional flight under gravity, drag, wind, wake, ground impact, bounce, and settling. Camera and marshal sensors use range, quality, fragment size, and location to produce detection probabilities.

The model calculates tire puncture risk, residual spatial hazard, a deterministic hazard-priority cleanup route, cleanup time, and track-reopening confidence. Reopening is therefore a quantified residual-risk decision rather than a binary flag.

## 15. Composite manufacturing digital thread

The composite model integrates Arrhenius cure kinetics, exothermic heat, oven/tool thermal exchange, pressure- and viscosity-dependent void compaction, transformed laminate stiffness, cure/porosity knockdown, anisotropic spring-back, bondline strength, repair effects, scanner deviation, aero effects, and process capability.

The request explicitly carries ply orientation, thickness, elastic constants, cure cycle, part-level dimensional data, bondline data, and repair area. Outputs include cure history, final degree of cure, void fraction, effective moduli, spring-back, part structural margins, dimensional statistics, aerodynamic deviation, and process-capability index.

## 16. Fleet reliability and serialized parts genealogy

Historical failed and right-censored records generate Bayesian-shrunk Weibull populations by part type. Supplier lot, overload exposure, thermal damage, inspection health, and accumulated equivalent hours modify each serialized part's effective age.

The report includes characteristic life, lot hazard modifier, conditional next-event failure probability, remaining useful life, replacement recommendation, expected failures, and aggregate fleet failure probability. This supports gearbox, hybrid, MGU, inverter, wheel-end, suspension, brake, cooling, and electrical populations without treating all failures as independent or identically distributed.

## 17. Test design and calibration

The test designer starts with the inverse prior covariance. Candidate tests provide category, sensitivity vector, measurement variance, cost, and repeat limit. Each selected test adds a Fisher-information outer product. A deterministic D-optimal search maximizes log-determinant information gain per cost while satisfying budget, count, repeat, and required-category constraints.

Outputs include ordered test program, cumulative cost, selected categories, information gain, posterior covariance, parameter standard deviations, uncertainty reduction, and identifiability findings. The engine is applicable to wind tunnel, straight-line aero, damper/K&C, tire force-and-moment, dyno, hybrid bench, simulator, and track-correlation programs.

## 18. Tire material digital thread

The tire-material domain connects raw-material genealogy, compound processing, physical properties, lot variability, and circularity. Material entries include role, mass fraction, renewable and recycled fractions, batch quality, dispersion, and molecular-weight index. The process cycle is integrated using Arrhenius cure and aging kinetics.

The solver calculates degree of cure, crosslink index, aging retention, viscoelastic index, thermal severity, predicted modulus and tensile strength, traction efficiency, heat-build index, structural margin, lot coefficient of variation, renewable/recycled content, sustainability score, and circularity index. It rejects mass fractions that do not sum to one and reports inadequate cure, excessive lot variation, insufficient strength, or insufficient sustainability performance.

## 19. Run all canonical requests

```bash
set -euo pipefail
for item in \
  regulation-digital-thread:regulation_digital_thread \
  dynamic-compliance:dynamic_compliance \
  next-generation-certification:next_generation_certification \
  prospective-manufacturer-program:prospective_manufacturer_program \
  timing-observation-fusion:timing_observation_fusion \
  officiating-policy-lab:officiating_policy_lab \
  contact-damage-raceability:contact_damage_raceability \
  crash-safer-fe:crash_safer_fe \
  fire-rescue-hazards:fire_rescue_hazards \
  debris-recovery:debris_recovery \
  composite-manufacturing:composite_manufacturing \
  fleet-reliability:fleet_reliability \
  test-design-calibration:test_design_calibration \
  tire-material-digital-thread:tire_material_digital_thread
do
  domain=${item%%:*}
  stem=${item##*:}
  ./build/indycar-assurance/muzixdiagsys_advanced_platform \
    indycar-assurance "$domain" \
    "examples/indycar_engineering_assurance/${stem}.json" \
    "build/indycar-assurance/${stem}.result.json" \
    build/indycar-assurance/evidence
done
```

## 20. Evidence and deterministic replay

Every report contains `evidence_digest`, calculated after canonical serialization of the report content. Identical executable, configuration, request, and numerical environment produce byte-identical result JSON. Evidence directories should be retained with source revision, compiler identity, rule package, calibration manifest, and physical-test provenance.

## 21. Engineering qualification boundary

A passing report establishes only that the encoded model, submitted data, arithmetic, thresholds, and deterministic evidence workflow completed as specified. It does not establish INDYCAR approval, homologation, technical legality, official timing or scoring, an officiating ruling, structural certification, medical survivability, fire-response adequacy, manufacturing acceptance, tire approval, or safe parts life.

Real application requires current governing documents, vehicle- and supplier-specific data, calibration, uncertainty budgets, convergence studies, physical tests, independent review, and qualified human authorization.

## Motorsport CLI convenience aliases

The original `indycar-assurance` family remains authoritative. `indycar run assurance DOMAIN ...` provides aggregate routing; `indycar-safety` and `indycar-timing` are direct shortcuts. See `MOTORSPORT_CLI_COMMANDS.md`.

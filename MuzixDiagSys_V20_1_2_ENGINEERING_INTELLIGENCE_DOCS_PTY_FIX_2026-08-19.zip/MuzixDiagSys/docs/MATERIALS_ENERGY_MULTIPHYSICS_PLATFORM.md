# Materials, Energy, and Multiphysics Platform

## Purpose

The materials, energy, and multiphysics platform extends MuzixDiagSys with ten deterministic engineering laboratories spanning particle mechanics, materials development, manufacturing, electrification, electrochemistry, environmental durability, hydrogen, design optimization, uncertainty quantification, and reacting flow. The implementation is exported by:

- `include/aesim/advanced/materials_energy_multiphysics_platform.hpp`
- `include/aesim/advanced/platform.hpp`

The production implementation is divided between:

- `src/advanced/materials_energy_multiphysics_platform_a.cpp`
- `src/advanced/materials_energy_multiphysics_platform_b.cpp`

All inputs enforce finite-value, range, allocation, and physical-consistency checks. Every principal result can be serialized into the shared document representation and sealed with a deterministic SHA-256 evidence digest.

## Build and test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --target materials_energy_multiphysics_platform_tests -j
ctest --test-dir build -R materials_energy_multiphysics_platform_unit_tests --output-on-failure
```

For memory and undefined-behavior qualification:

```bash
cmake -S . -B build-sanitized -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON -DAESIM_BUILD_TOOLS=OFF -DAESIM_ENABLE_SANITIZERS=ON
cmake --build build-sanitized --target materials_energy_multiphysics_platform_tests -j
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1 \
  ./build-sanitized/materials_energy_multiphysics_platform_tests
```

## 1. Mesh-Free SPH, MPM, and DEM Multiphysics

### Public entry points

- `MeshFreeMultiphysicsLaboratory::simulate_sph`
- `MeshFreeMultiphysicsLaboratory::simulate_mpm`
- `MeshFreeMultiphysicsLaboratory::simulate_dem`

### Smoothed Particle Hydrodynamics

The SPH solver uses a compact cubic smoothing kernel and evaluates density, pressure, viscous momentum transfer, thermal conduction, body force, and configurable surface-tension response. Density is reconstructed from neighboring particle mass. Pressure follows a weakly compressible equation of state. Pairwise forces are accumulated symmetrically so internal momentum exchange remains balanced to floating-point tolerance.

The solver supports bounded three-dimensional domains, restitution at walls, thermal evolution, configurable smoothing length, deterministic integration, and frame summaries containing mass, momentum, kinetic energy, thermal energy, center of mass, and contact counts.

### Material Point Method

The MPM implementation transfers particle mass, momentum, force, and thermal state to a structured background grid with trilinear interpolation. Grid momentum is advanced under internal stress, gravity, and boundary constraints, after which updated velocity and temperature are interpolated back to material points.

Material behavior includes elastic response, yield-limited plastic flow, hardening, scalar damage, and temperature evolution. Grid dimensions are validated before integer conversion and bounded by explicit safe-allocation limits.

### Discrete Element Method

The DEM solver performs broad all-pairs contact detection for the bounded reference workload, followed by normal spring-dashpot response, tangential friction, cohesion, rotational update, and boundary contact. Contact forces use equal-and-opposite accumulation. The output reports contact activity, penetration, energy, and particle trajectories.

### Qualification boundaries

These implementations are deterministic reference solvers intended for coupled engineering studies and regression-qualified moderate problem sizes. Extremely large industrial particle counts should use a specialized parallel backend behind the same validated data contracts.

## 2. Integrated Computational Materials Engineering

### Public entry point

- `IntegratedComputationalMaterialsEngineeringLab::simulate`

The ICME laboratory links composition and thermal history to evolving phase fractions, microstructure, and engineering properties.

Implemented mechanisms include:

- temperature-dependent phase Gibbs energies;
- equilibrium phase fractions obtained from normalized free-energy weighting;
- Arrhenius transformation kinetics;
- time-dependent phase-fraction relaxation;
- grain growth;
- precipitate nucleation, growth, and coarsening;
- dislocation accumulation and recovery;
- solid-solution, grain-boundary, precipitation, dislocation, and phase-strength contributions;
- homogenized modulus, density, conductivity, yield strength, hardness, and fatigue indicator;
- conservation checks for composition and phase fractions.

A thermal schedule is integrated segment by segment. Each state records temperature, phase fractions, grain size, precipitate radius and fraction, dislocation density, and homogenized properties. Input validation rejects invalid compositions, negative kinetic coefficients, impossible phase definitions, and non-monotonic schedules.

## 3. Manufacturing-Process Physics and As-Built Digital Twin

### Public entry point

- `ManufacturingProcessPhysicsLab::simulate`

The manufacturing laboratory evolves a spatial process mesh through thermal and mechanical process stages. Supported process families include additive deposition, casting, forging, heat treatment, machining, composite cure, welding, and surface treatment through a common process-step representation.

The thermal model includes:

- moving Gaussian heat input;
- conductive diffusion;
- convective and radiative boundary loss;
- phase-dependent heat effects;
- melt-pool tracking;
- cooling-rate history.

The as-built model includes:

- thermal strain and constrained residual stress;
- plastic relaxation;
- porosity growth and closure;
- lack-of-fusion and keyhole indicators;
- cure or phase-state evolution;
- machining stock removal;
- distortion accumulation;
- inspection assimilation and discrepancy scoring.

Outputs include node-resolved temperature, stress, strain, porosity, phase/cure state, distortion, and defect fields, plus global mass, dimensional, residual-stress, and quality metrics. This creates a deterministic process-to-as-built state that can be consumed by downstream structural, thermal, fatigue, and qualification analyses.

## 4. Switching-Level Power Electronics

### Public entry point

- `SwitchingLevelPowerElectronicsLab::simulate`

The switching solver models a three-phase bridge at carrier resolution. It includes:

- sinusoidal modulation and carrier comparison;
- dead-time insertion;
- phase current integration against resistance, inductance, and back electromotive force;
- device on-state and switching losses;
- diode/reverse-conduction losses;
- DC-link current and ripple;
- common-mode voltage;
- parasitic-inductance overshoot;
- junction-to-case and case-to-coolant thermal networks;
- cycle counting and accumulated semiconductor damage;
- current total-harmonic-distortion reporting.

Device definitions expose voltage/current limits, on-resistance, diode drop, switching energies, thermal impedances, and lifetime exponents. The solver reports waveforms, energy balance, peak electrical and thermal values, harmonic content, and a reliability damage index.

## 5. Battery Impedance and Manufacturing Laboratory

### Public entry points

- `BatteryImpedanceManufacturingLaboratory::manufacture_electrode`
- `BatteryImpedanceManufacturingLaboratory::simulate_impedance`
- `BatteryImpedanceManufacturingLaboratory::diagnose_pack`

### Electrode manufacturing

The manufacturing model propagates slurry solids fraction, coating thickness, drying temperature/time, calender pressure, particle size, active-material fraction, binder fraction, electrolyte wetting, and formation conditions into:

- final porosity;
- tortuosity;
- active surface area;
- ionic resistance;
- electronic resistance;
- wetting fraction;
- binder-migration index;
- crack-risk indicator;
- expected capacity and manufacturing variation.

### Electrochemical impedance spectroscopy

The EIS model evaluates complex impedance over a requested frequency grid. It includes ohmic resistance, charge-transfer response, double-layer capacitance, finite-length diffusion/Warburg response, inductive parasitics, and manufacturing-state corrections.

A regularized non-negative distribution-of-relaxation-times inversion is solved over a logarithmic time-constant grid. The output contains Nyquist/Bode quantities, DRT amplitudes, identified resistance contributions, characteristic frequencies, and residual error.

### Pack diagnostics

Cell or module spectra are compared against a robust pack reference. The diagnostic identifies anomalous ohmic resistance, charge-transfer resistance, diffusion response, and capacity-related deviations, then returns ranked fault evidence.

## 6. Environmental Corrosion and Water Ingress

### Public entry point

- `EnvironmentalCorrosionWaterIngressLab::simulate`

The environment laboratory models interconnected compartments, materials, seals, coatings, and ingress paths. Water transfer is driven by gauge pressure, hydrostatic loading, capillarity, path area, discharge coefficient, seal state, and one-way path constraints. Salt mass is advected with water and diluted or concentrated through compartment volume changes.

Environmental degradation includes:

- humidity condensation;
- coating permeability and damage;
- seal damage;
- galvanic potential differences with bounded Tafel amplification;
- Arrhenius temperature acceleration;
- salinity-dependent corrosion current;
- Faraday-law mass loss;
- corrosion-depth accumulation;
- stress-corrosion damage;
- electrical contact-resistance growth;
- high-voltage isolation degradation.

The solver produces time histories and terminal compartment states with water volume, salt concentration, corrosion depth, coating/seal damage, resistance, isolation, and detected ingress status.

## 7. Hydrogen and Cryogenic-Fuel Laboratory

### Public entry point

- `HydrogenCryogenicFuelLaboratory::simulate`

The hydrogen laboratory supports compressed gaseous and cryogenic storage. It includes:

- Peng-Robinson real-gas pressure evaluation;
- fill and withdrawal mass flow;
- choked and subcritical leak flow;
- pressure-relief-valve operation;
- wall-to-fluid heat transfer;
- expansion/compression thermal response;
- cryogenic saturation-pressure approximation;
- boil-off and latent heat;
- permeation;
- hoop and liner stress;
- hydrogen diffusion into material;
- embrittlement and fatigue-life reduction indicators.

The result records pressure, temperature, mass, liquid fraction, leak and relief flow, boil-off, stress, permeation, and material damage across time. Mass balance is audited against fill, withdrawal, leak, relief, and boil-off terms.

## 8. Adjoint and Topology Optimization

### Public entry points

- `AdjointTopologyOptimizationLab::solve_discrete_adjoint`
- `AdjointTopologyOptimizationLab::optimize_topology`

### Discrete adjoint

For a residual system `A(p)u=b(p)` and scalar objective `J(u,p)`, the laboratory solves:

1. the primal state;
2. the transpose adjoint system;
3. the total derivative using the direct term and adjoint-weighted residual derivative.

Primal and adjoint residual norms are returned, and the regression suite checks the analytic gradient against a central finite-difference reference.

### Topology optimization

The topology solver uses two-dimensional Q4 plane-stress finite elements, SIMP material interpolation, sensitivity filtering, and an optimality-criteria density update. It enforces fixed nodes, nodal loads, minimum density, move limits, volume fraction, and convergence criteria.

The dense qualification backend is guarded by element, node, and degree-of-freedom limits so invalid or unexpectedly expensive requests fail before allocation. Results include the final density field, compliance history, volume history, convergence state, and evidence digest.

## 9. Advanced Uncertainty and Rare-Event Computing

### Public entry points

- `AdvancedUncertaintyRareEventLab::fit_polynomial_chaos`
- `AdvancedUncertaintyRareEventLab::estimate_importance_sampling`
- `AdvancedUncertaintyRareEventLab::estimate_subset_simulation`
- `AdvancedUncertaintyRareEventLab::sobol_indices`

The laboratory supports normal, uniform, lognormal, and triangular random variables.

### Polynomial chaos

A total-order polynomial basis is generated over standardized variables. Coefficients are identified by regularized least squares. Mean, variance, and training residual are reported with the fitted model.

### Adaptive importance sampling

A cross-entropy-style adaptation phase moves the proposal distribution toward low-limit-state samples. The final probability estimate uses likelihood-ratio weighting, second-moment variance estimation, coefficient of variation, reliability index, and model-evaluation accounting.

### Subset simulation

Rare-event probability is decomposed into conditional levels. Each level selects an intermediate threshold and advances Markov chains from elite seeds. The result records thresholds, probability, coefficient of variation, reliability index, and evaluation count.

### Global sensitivity

Saltelli-style paired sampling produces first-order and total Sobol indices. All zero-observation edge cases remain finite in the public result and document representation.

## 10. High-Fidelity Reacting-Flow Combustion

### Public entry point

- `HighFidelityReactingFlowCombustionLab::simulate`

The combustion laboratory is a deterministic one-dimensional finite-volume reacting-flow solver. It advances conservative mass together with momentum, temperature, species mass fractions, spray state, and emissions precursors.

Implemented physics include:

- face mass flux and conservative continuity;
- pressure-gradient momentum;
- scalar advection and diffusion;
- finite-rate Arrhenius chemistry;
- turbulence-limited reaction rate;
- fuel and oxidizer consumption;
- product formation and species renormalization;
- spray droplet `d²` evaporation;
- vapor-source coupling;
- chemical heat release and thermal transport;
- simplified thermal-NO and soot source/oxidation models;
- CFL and diffusion stability limits;
- mass and energy residual reporting.

Boundary states, initial fields, reaction definitions, species thermodynamics, and injection schedules are validated before integration. Outputs include cell histories, integrated heat release, burn fraction, pressure/temperature extrema, emissions, mass residual, and energy residual.

## Shared evidence and determinism

The new laboratories follow the existing advanced-platform conventions:

- deterministic seeded stochastic methods;
- no mandatory external runtime or network dependency;
- finite, canonical structured documents;
- SHA-256 evidence sealing;
- explicit configuration validation;
- bounded reference workloads;
- strict floating-point compiler policy;
- AddressSanitizer, UndefinedBehaviorSanitizer, and leak-detection compatibility.

## Regression coverage

`tests/materials_energy_multiphysics_platform_tests.cpp` exercises all ten requested feature groups. It covers SPH/MPM/DEM state evolution, ICME phase/property progression, manufacturing defects and as-built state, switching waveforms and thermal response, EIS and DRT extraction, corrosion/ingress, hydrogen storage, adjoint finite-difference agreement, topology volume enforcement, polynomial chaos and rare-event estimation, Sobol sensitivity, and reacting-flow conservation.

# Specification, Discovery, and Verification Suite

## Scope

This subsystem extends MuzixDiagSys with executable temporal requirements, systematic counterexample reduction, broad behavior-space exploration, solver-backed verification, compositional contracts, synthesized safety supervisors, evidence-driven experiment selection, signal-level perception simulation, cyber-physical investigation, and fleet/regime intelligence.

Public API:

```cpp
#include "aesim/research2/specification_discovery_platform.hpp"
```

Operator tool:

```bash
muzixdiagsys_specification_discovery capabilities
muzixdiagsys_specification_discovery self-test
muzixdiagsys_specification_discovery synthesize-monitor \
  'response brake > 0.5 -> eventually[0,0.25] decel < -2.0'
```

## 1. Temporal logic and monitor synthesis

`TemporalLogicEngine` parses a bounded temporal DSL and evaluates complete traces or creates incremental monitors.

Supported forms:

```text
always[begin,end] signal <= threshold
 eventually[begin,end] signal > threshold
response trigger > threshold -> eventually[begin,end] response < threshold
until[begin,end] invariant >= threshold until release == threshold
```

The parser supports `<`, `<=`, `>`, `>=`, `==`, and `!=`. Quantitative robustness is positive for satisfaction and negative for violation. Results include earliest violation, earliest satisfaction, trigger counts, response completion counts, and vacuity status. The synthesis function emits a self-contained C++17 monitor with the selected predicate and temporal window embedded in generated code.

## 2. Causal scenario minimization

`CausalScenarioMinimizer` performs hierarchical delta debugging over scenario elements and then applies bounded binary value reduction toward each element's nominal value. Every accepted reduction is re-evaluated against the failure oracle. The final result records removed elements, reduced numeric values, evaluation count, preserved robustness, active causal support, and total complexity reduction.

## 3. Quality-diversity exploration

`QualityDiversityExplorer` implements deterministic MAP-Elites. Genome variables may be continuous or integer. Behavior descriptors are discretized into configurable multidimensional cells. The archive retains the highest-quality scenario in each occupied cell and reports coverage, quality-diversity score, occupied cells, total cells, and complete reproducible elites.

## 4. Property-based and metamorphic testing

`PropertyMetamorphicTestEngine` combines generated property cases with cross-execution metamorphic relations. Failed scalar/vector cases are reduced toward a smaller counterexample through deterministic shrinking. Typical relations include symmetry, scaling, monotonicity, conservation, zero-disturbance equivalence, and backend equivalence.

## 5. Numerical pathology detection

`NumericalPathologyDetector` identifies:

- Non-finite state values.
- Small-amplitude chattering.
- Geometrically contracting event intervals.
- Extreme adaptive-step ratios associated with stiffness.
- Constraint drift.
- Energy-ledger imbalance.
- Ill-conditioned linear systems.
- Hidden slope discontinuities.
- Exploding and vanishing gradients.
- Cross-solver final-state disagreement.

Every issue contains evidence, severity, simulation time, affected signal, and a corrective engineering recommendation.

## 6. Experiment and evidence query language

`ExperimentEvidenceQueryEngine` stores generic evidence records and can import `ExperimentRunRecord` metadata. The query language supports:

```text
FIND runs WHERE status = FAIL AND stopping_distance > 80
ORDER BY stopping_distance DESC LIMIT 20
```

`SELECT`, `FIND`, `WHERE`, `AND`, `ORDER BY`, `GROUP BY`, `LIMIT`, numeric comparisons, text equality, `contains`, and `tagged` are supported. Query execution reports the number of scanned and returned records and optional grouped counts.

## 7. Solver-backed formal verification

`SolverBackedFormalVerifier` includes a deterministic DPLL Boolean satisfiability solver with unit propagation and bounded finite-state reachability. Boolean clauses select enabled architecture or fault conditions. The verifier explores enabled transitions from every initial state, checks an executable invariant, and returns a shortest discovered counterexample state/transition sequence.

## 8. Compositional contracts

`CompositionalContractVerifier` evaluates assume/guarantee contracts against representative environments, detects multiple-driver interface conflicts, reports assumption and guarantee violations, and composes selected component contracts into a system contract. Composition removes internally supplied outputs from the external input set.

## 9. Automatic safety-shield synthesis

`AutomaticSafetyShieldSynthesizer` enumerates a configurable multidimensional action grid. For every training state it predicts the closed-loop trajectory over the safety horizon, evaluates all safety margins, and chooses the verified-safe action with minimum deviation from the nominal controller. The resulting nearest-state policy is deterministic and retains action bounds and training margins.

## 10. Bayesian experimental design

`BayesianExperimentalDesigner` normalizes hypothesis priors, evaluates outcome likelihoods, computes posterior distributions for every candidate outcome, and ranks experiments by expected entropy reduction minus optional cost. Outcome probabilities and expected posterior entropy remain available for audit.

## 11. Causal-path coverage

`CausalPathCoverageAnalyzer` enumerates simple root-to-target causal paths up to a configured length. Observed execution paths produce node, edge, full-path, and risk-weighted coverage. Uncovered edges are sorted by descending risk contribution for test generation.

## 12. Mutation testing

`MutationTestingEngine` executes the unchanged baseline first, applies each model mutation independently, and records which tests kill each mutant. Implemented mutations include coefficient sign/scale errors, bias shifts, saturation deletion or reversal, output delay, output loss, and state reset. The report includes killed/survived totals and mutation score.

## 13. Raw sensor rendering

`RawSensorRenderer` creates deterministic raw or near-raw signals:

- Camera Bayer RGGB ADC frames with perspective projection, exposure, full-well saturation, Poisson shot noise, and electronic read noise.
- FMCW radar complex I/Q samples with range beat frequency, Doppler, antenna phase, target RCS, thermal noise, and range-Doppler power accumulation.
- Scanning lidar point returns with vertical rings, azimuth scanning, object angular extent, range noise, reflectivity intensity, object attribution, and firing-time offset.
- Ultrasonic sampled waveforms with two-way time of flight, carrier oscillation, exponential ring-down, angular visibility, range attenuation, and additive noise.

## 14. Cooperative perception and Byzantine resilience

`ByzantineResilientCooperativePerception` computes per-dimension robust medians and median absolute deviations, rejects statistically inconsistent or low-trust contributors, updates persistent source trust, and fuses accepted tracks using trust, existence probability, and covariance-derived information weights.

## 15. Automated cyberattack synthesis

`AutomatedCyberattackSynthesizer` evolves variable-length attack programs over configurable targets and primitives. It optimizes physical impact and explicit safety violations while penalizing detectability and resource cost. Selection, mutation, insertion, deletion, deterministic seeding, Pareto filtering, and full attack-gene reporting are implemented.

## 16. Cyber-physical forensic reconstruction

`CyberPhysicalForensicReconstructor` validates evidence hash chains before timestamp correction, estimates affine clock drift/offset from synchronization anchors, aligns events, detects sequence and global-time gaps, ranks competing hypotheses with Bayesian posteriors, and produces a unified forensic timeline.

## 17. Fleet-scale hierarchical digital twins

`FleetHierarchicalDigitalTwin` performs precision-weighted Bayesian assimilation at fleet, platform, manufacturing-batch, and individual-vehicle levels. Predictions shrink sparse vehicle data toward batch/platform/fleet posteriors and expose level-specific means, variances, and observation counts. Vehicle outliers are identified relative to fleet uncertainty.

## 18. Change-point and regime detection

`ChangePointRegimeDetector` supports standardized two-sided CUSUM and Bayesian online change-point detection. The Bayesian mode maintains run-length probabilities and sufficient statistics; the CUSUM mode adapts baseline mean and variance. Both return per-sample change probability, detected change indices, and regime identifiers.

## Determinism

All stochastic algorithms use caller-provided seeds. Archive tie-breaking, formal exploration, mutation order, evidence alignment, and attack ranking are stable. Sensor noise, generated properties, MAP-Elites evaluation seeds, and cyberattack evaluation seeds are reproducible.

## Validation

The dedicated `specification_discovery_platform_unit_tests` target exercises all eighteen capabilities. `specification_discovery_cli_self_test` validates temporal parsing/evaluation, SAT-backed counterexample generation, and raw radar output through the installed operator surface.

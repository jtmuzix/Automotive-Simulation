# Control, Physical-System, Co-Simulation, and Qualification API Services

**Release:** 2026-08-08  
**Advanced API registry:** 214 commands  
**Expansion covered here:** 20 append-only production commands

These services are linked into both `muzixdiagsys_advanced_platform` and the authenticated interactive `muzixdiagsys` shell through the same in-process dispatcher. Every command supports the common `capabilities`, `describe`, `schema`, `example`, `self-test`, and request-file execution conventions. Safe command names are direct interactive roots; `advanced <command> ...` is always the collision-safe form.

## Common usage

From the primary shell:

```text
control-synthesis capabilities
safety-shield capabilities
nvh example
fmi-cosim schema
probabilistic-model-check self-test build/pmc build/pmc.json
```

Equivalent explicit namespace:

```text
advanced control-synthesis capabilities
advanced nvh example
advanced probabilistic-model-check self-test build/pmc build/pmc.json
```

From the standalone advanced executable:

```bash
./build/full/muzixdiagsys_advanced_platform control-synthesis self-test build/control build/control.json
```

## 1. `control-synthesis`

Production backend: `research2::ResilientControllerSynthesizer` with closed-loop plant evaluation.

Operations: `synthesize`, `evaluate`, `run`.

The controller is evaluated against nominal and disturbed scenarios rather than fitted only to one trajectory. Requests define initial state, position safety bound, actuator limits, simulation horizon, population/generation budget, and deterministic seed. The synthesis returns proportional/derivative parameters, robust objective history, per-scenario validation, stability state, control effort, performance cost, and worst safety violation.

```bash
./build/full/muzixdiagsys_advanced_platform control-synthesis synthesize \
  examples/advanced_api_cli/control-synthesis.json build/control-result.json
```

## 2. `safety-shield`

Production backends: `research2::RuntimeAssuranceSafetyShield` and `AutomaticSafetyShieldSynthesizer`.

Operations: `evaluate`, `synthesize`, `run`.

The runtime assurance layer predicts the state evolution under a primary control action, computes constraint margins, and replaces/blends the action with the fallback controller when required. The result records intervention state, limiting constraint, safe action, primary action, predicted trajectory, fallback latch state, blend factor, and minimum predicted margin. Infeasible safety requests are not silently qualified.

## 3. `prognostics`

Production backend: `high_fidelity::MechanismDurabilityPrognostics`.

Operations: `estimate`, `run`.

A request can contain multiple named components, mechanism types and load-history steps. Outputs include cumulative damage, crack/wear state, counted cycles, health index, failure probability, RUL mean/uncertainty, earliest fleet/component RUL and maximum failure probability. This API is intended for bearing, fatigue, wear and related degradation studies and can be chained with `api-workflow` and `api-baseline`.

## 4. `nvh`

Production backend: `high_fidelity::StructuralAcousticsNvhSystem`.

Operations: `simulate`, `run`.

The service accepts structural modes plus physical excitations and integrates the coupled structural/acoustic response. Results include modal displacement/velocity/acceleration, sound pressure, overall and A-weighted SPL, loudness, sharpness, roughness, tonality, seat-rail/steering-wheel vibration and ride-comfort index.

```bash
./build/full/muzixdiagsys_advanced_platform nvh simulate \
  examples/advanced_api_cli/nvh.json build/nvh-result.json
```

## 5. `aftertreatment`

Production backend: `electrification::ExhaustAftertreatmentSystem`.

Operations: `simulate`, `run`.

Transient steps carry exhaust temperature/mass flow, engine-out species and urea dosing. The service evolves DOC/TWC/SCR/DPF thermal and chemistry state and reports CO/HC/NOx/PM conversion, ammonia storage, soot mass, regeneration/overload state, pressure drop and tailpipe species rates. It is suitable for cold-start, thermal-management and emissions workflows.

## 6. `occupant-safety`

Production backends: `high_fidelity::NonlinearCrashOccupantSystem` and `advanced::PopulationResolvedOccupantLibrary`.

Operations: `simulate`, `population`, `run`.

The nonlinear path evaluates crash-pulse/restraint dynamics. The population path evaluates occupant-specific injury/egress characteristics. Outputs include HIC, neck injury criterion, chest deflection, severe-injury probability, submarining probability and egress time where applicable.

## 7. `fmi-cosim`

Production backends: `research2::Fmi3ScheduledExecutionMaster` and `high_fidelity::FmiOpenXInteroperability`.

Operations: `scheduled-execution`, `export-model-description`, `run`.

Scheduled Execution requests define clocks and clock-bound partitions with periods, deadlines and WCET. The master executes clock activations, records partition activation counts, deadline misses, jitter and final time, and serializes checkpoint state. Model-description export uses the existing FMI/OpenX interoperability backend. This is an in-process FMI 3 service rather than a subprocess wrapper.

## 8. `ssp-orchestrator`

Production backends: `industrial::SspPackage` and `industrial::SspOrchestrator`.

Operations: `validate`, `inspect`, `export`, `simulate`, `run`.

The validator checks named systems, component identity/source metadata and connection consistency. Package inspect/export uses the production SSP package representation; simulation is delegated to the production SSP orchestrator when referenced artifacts are available. Validation does not require an external FMU, which makes package construction testable before deployment.

## 9. `automotive-middleware`

Operations: `someip`, `dds`, `qos`, `run`.

This service models the service/middleware behavior above the lower-level `network-digital-twin`. SOME/IP analysis includes payload serialization, service-discovery overhead, one-way/RPC latency and deadline qualification. DDS/QoS analysis includes reliability/history/deadline behavior and deterministic delivery/latency qualification. It is intended to connect software-service assumptions to TSN/CAN/Ethernet timing studies.

## 10. `charging-session`

Production backends: `electrification::Iso15118Session` and `advanced::standards::J3400Iso15118ConformanceLaboratory`.

Operations: `simulate`, `conformance`, `run`.

Simulation executes the ISO 15118 session sequence through setup, discovery, selection, authorization, parameter discovery, cable check, pre-charge, power delivery, charge loop and stop. Limits include voltage, current and power. Results include protocol responses, negotiated request values, delivered energy and final state. `conformance` delegates standards checks to the J3400/ISO 15118 laboratory.

## 11. `depot-energy`

Production backend: `advanced::assured::MegawattDepotOperationsTwin`.

Operations: `optimize`, `run`.

Inputs define vehicles, arrival/departure windows, battery energy/SOC requirements, charger inventory and transformer limit. Outputs include dispatch intervals, delivered energy, grid power, peak load, final SOC, missed departures, energy/demand cost, carbon, degradation cost and transformer qualification.

## 12. `ota-campaign`

Production backend: `advanced::operational::WholeFleetOtaQualificationEngine`.

Operations: `qualify`, `run`.

The campaign service evaluates vehicle capabilities/storage/SOC, package dependencies, anti-rollback policy, dual-bank/rollback support, download/install order and fleet compatibility. It reports compatible/incompatible vehicles, per-vehicle reasons, rollback qualification and evidence digest. Contradictory anti-rollback/rollback requirements correctly fail qualification.

## 13. `digital-key`

Production backends: `advanced::HardwareSecurityModule` and `advanced::standards::CccDigitalKeyService`.

Operations: `authorize`, `simulate`, `run`.

The API creates persistent HSM-backed issuer/device keys in the working directory, enrolls a device, issues an owner credential, signs an authorization challenge and evaluates BLE/NFC/UWB proximity. Results explicitly distinguish credential validity, signature validity, proximity validity, relay-attack suspicion and authorization. Cryptographic authorization is therefore exercised rather than replaced with a boolean mock.

## 14. `accident-reconstruction`

Production backend: `advanced::ProbabilisticAccidentReconstructionLaboratory`.

Operations: `reconstruct`, `run`.

Requests contain telemetry/trajectory observations and multiple physical hypotheses. The backend returns state mean/covariance, impact speed, energy, likelihood, normalized hypothesis posterior weights and evidence digest, providing uncertainty-aware reconstruction rather than a single deterministic estimate.

## 15. `tire-digital-twin`

Production backend: `high_fidelity::FlexibleRingTire`.

Operations: `simulate`, `run`.

The service evolves a transient flexible-ring tire under hub speed, wheel angular speed and normal load. Outputs include longitudinal/lateral force, aligning moment, loaded/effective radius, contact-patch length, slip state, friction/utilization, tread/carcass temperature, tread depth, wear fraction, ring strain energy and dissipated energy.

## 16. `thermal-management`

Production backend: `high_fidelity::DistributedVehicleThermalNetwork`.

Operations: `simulate`, `run`.

The distributed thermal network couples powertrain/battery/power-electronics/cabin thermal loads, heat rejection and auxiliary/HVAC loads. It reports node temperatures, radiator/chiller/HVAC heat flows, derating/over-temperature state, stored thermal energy and conservation residual.

## 17. `driveline`

Production backend: `high_fidelity::TorsionalDriveline`.

Operations: `simulate`, `run`.

The model resolves clutch, gear mesh, propshaft, differential and left/right halfshaft/wheel torsional states. Inputs include engine/resisting torques, gear ratio and integration budget. Results include shaft/wheel speeds, clutch/mesh/shaft torques, differential lock fraction, kinetic/torsional/dissipated energy and energy residual.

## 18. `aero-map`

Production backend: `vehicle::AerodynamicCoefficientMap`.

Operations: `sample`, `sweep`, `export`, `run`.

The API samples or sweeps aerodynamic coefficients over speed, yaw, pitch and front/rear ride height. Outputs include drag, front/rear lift, side force, yaw/pitch moment and cooling-flow factor. CSV-backed maps can be loaded where supplied; generated/sampled points can be exported for vehicle/lap/controller workflows.

## 19. `ads-qualification`

Production backend: `advanced::ContinuousAdsQualificationEngine`.

Operations: `analyze`, `run`.

The service compares baseline and monitored fleet observations by software version and ODD features. It reports cohort exposure/event rates and confidence bounds, population-stability indices, shifted ODD dimensions, scenarios/regression campaigns, safety-case deltas and whether qualification review is required.

## 20. `probabilistic-model-check`

Production backend: `research2::ProbabilisticModelChecker`.

Operations: `reachability`, `expected-reward`, `run`.

Requests define states, actions/transitions, probabilities, initial/target states and optional rewards. The checker validates the stochastic model, solves reachability/reward objectives, reports convergence/iterations, state values, synthesized policy, probability/reward and findings.

## Regression policy

The registry remains append-only at **214 commands**. Release regressions include:

```bash
python3 tests/advanced_api_cli_commands_regression.py \
  build/full/muzixdiagsys_advanced_platform .

python3 tests/advanced_api_engineering_expansion_regression.py \
  build/full/muzixdiagsys_advanced_platform .

python3 tests/interactive_advanced_motorsport_cli_regression.py \
  build/full/muzixdiagsys .
```

The deep regression executes every new self-test plus representative real operations and rejects unfinished TODO/FIXME/placeholder/not-implemented markers from the implementation surface.

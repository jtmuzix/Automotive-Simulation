# Frontier Professional Integration

**Revision:** 2026-08-10  
**Status:** Production additive subsystem  
**Primary public API:** `include/aesim/advanced/frontier_professional_integration.hpp`  
**Hardware plugin ABI:** `include/aesim/advanced/frontier_hardware_plugin.h`  
**CLI:** `muzixdiagsys_frontier_professional`  
**Regression:** `frontier_professional_integration_tests`

## 1. Purpose

The Frontier Professional Integration closes ten interoperability and research gaps without replacing or removing any existing MuzixDiagSys subsystem. The implementation was deliberately added in the requested order:

1. OPC UA / Asset Administration Shell (AAS)
2. physical Driver-in-the-Loop (DIL) and OpenXR
3. real automotive hardware I/O backends
4. ns-3 packet-level network federation
5. Jupyter research environment
6. Prometheus/OpenMetrics-style observability
7. Sigstore/in-toto provenance
8. advanced Bayesian HMC/NUTS and adaptive multilevel Monte Carlo (MLMC)
9. acoustic beamforming and active-noise control (ANC)
10. privacy-aware and adversarially robust extensions to the existing fleet federated-learning platform

The tenth area **extends** the pre-existing `FleetDigitalTwinPlatform::federated_aggregate()` FedAvg/robust aggregation functionality. It does not introduce a duplicate FedAvg implementation.

## 2. Build integration and optional native dependencies

The source files are compiled into `aesim_advanced`. The deterministic/in-process portions require only the normal MuzixDiagSys dependencies. Native interoperability is activated only when the corresponding development package is discoverable at configure time.

| Capability | Baseline implementation | Optional native dependency | Capability reporting |
|---|---|---|---|
| OPC UA/AAS | in-process UA address space, subscriptions, AAS Environment, AASX | open62541 | `native_opcua_available()` |
| Physical DIL | Linux evdev, force feedback, injected qualification state | Linux input/evdev kernel API | `PhysicalDilDevice::status()` |
| OpenXR | deterministic pose state and runtime discovery | OpenXR loader + headers | `native_openxr_available()` |
| CAN hardware | SocketCAN, PCAN-Basic, Kvaser CANlib, vendor plugin ABI | vendor runtime libraries where applicable | `HardwareCanChannel::probe()` |
| ns-3 | deterministic packet/reference model | external ns-3 bridge supplied under `integrations/ns3/` | explicit `Ns3Mode` |
| Jupyter | Python research client + four notebooks | JupyterLab for interactive UI | notebook validation/execution |
| Prometheus | native metric registry + HTTP exporter | none beyond sockets | exporter lifecycle |
| Sigstore | in-toto statement generation and bundle validation | `cosign` executable for signing/verifying | `cosign_available()` |
| HMC/NUTS/MLMC | native C++ algorithms | none | result diagnostics |
| Beamforming/ANC | native C++ delay-and-sum, MVDR, FxLMS | none | result/state diagnostics |
| Federated privacy | FedProx step, Krum, async, Gaussian DP, secure aggregation | OpenSSL 3.5 already required | result/privacy evidence |

CMake discovers open62541 and OpenXR with:

```text
AESIM_OPEN62541_INCLUDE_DIR
AESIM_OPEN62541_LIBRARY
AESIM_OPENXR_INCLUDE_DIR
AESIM_OPENXR_LIBRARY
```

When these variables are not resolved, native capability flags remain false. The build does not silently pretend that an unavailable SDK is active.

### 2.1 Focused build

```bash
cmake -S . -B build/frontier-professional -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON

cmake --build build/frontier-professional \
  --target muzixdiagsys_frontier_professional \
           frontier_professional_integration_tests \
  --parallel
```

Run the direct regression and capability self-test:

```bash
./build/frontier-professional/frontier_professional_integration_tests
./build/frontier-professional/muzixdiagsys_frontier_professional capabilities
./build/frontier-professional/muzixdiagsys_frontier_professional self-test build/frontier-selftest
```

## 3. Command-line surface

```text
muzixdiagsys_frontier_professional capabilities
muzixdiagsys_frontier_professional self-test [scratch-dir]
muzixdiagsys_frontier_professional opcua-aas [output.aasx]
muzixdiagsys_frontier_professional dil-openxr
muzixdiagsys_frontier_professional hardware-probe
muzixdiagsys_frontier_professional ns3-reference
muzixdiagsys_frontier_professional jupyter
muzixdiagsys_frontier_professional prometheus
muzixdiagsys_frontier_professional sigstore [artifact]
muzixdiagsys_frontier_professional bayes
muzixdiagsys_frontier_professional mlmc
muzixdiagsys_frontier_professional acoustics
muzixdiagsys_frontier_professional federated
```

Every data command emits one JSON document. Errors are emitted as JSON on stderr and return non-zero status.

---

# 4. OPC UA and Asset Administration Shell

## 4.1 In-process UA address space

`OpcUaAasGateway` provides a typed, thread-safe address space that is available independently of a network stack. It supports:

- namespace registration;
- object and variable nodes;
- stable namespace/string `UaNodeId` values;
- parent/child browse relationships;
- variable read/write authority;
- finite numeric-value validation;
- absolute-deadband subscriptions;
- monotonically increasing notification sequence numbers;
- wall-clock notification timestamps;
- structured address-space export.

Example:

```cpp
using namespace aesim::advanced::frontier;

OpcUaAasGateway gateway;
auto ns = gateway.register_namespace("urn:vehicle:powertrain");
auto engine = gateway.add_object(ns, "engine", "Engine");
auto rpm = gateway.add_variable(
    ns, "engine.speed", "EngineSpeed", "Double", 850.0, true, engine);

auto subscription = gateway.subscribe(rpm, 5.0,
    [](const UaNotification& update) {
        // Consume a validated engineering state change.
    });

gateway.write(rpm, 3250.0);
gateway.unsubscribe(subscription);
```

Callbacks execute after the gateway releases its address-space mutex, preventing user callbacks from running under the internal lock.

## 4.2 AAS mapping

An `AasShell` contains one or more `AasSubmodel` records, each with `AasProperty` elements. `map_variable()` projects a live UA variable into a submodel property. The mapped value is obtained from current address-space state whenever `aas_environment()` is generated.

The generated environment contains:

- `AssetAdministrationShell`;
- `assetInformation` and global asset ID;
- `ModelReference` entries to submodels;
- `Submodel` objects;
- `Property` submodel elements;
- `semanticId` external references when supplied;
- unit qualifiers when supplied;
- XML-schema-compatible lexical value types.

AASX persistence uses Open Packaging Convention ZIP relationships and contains:

```text
[Content_Types].xml
_rels/.rels
aasx/aasx-origin
aasx/_rels/aasx-origin.rels
aasx/aas.json
aasx/address-space.json
```

`read_aasx()` validates the JSON structure and reconstructs shell, submodel, property, semantic-reference, unit, Boolean, numeric, and string data. Import does not execute package content.

## 4.3 Native OPC UA endpoint

When open62541 headers and the library are present at build time, `start_native_server(port, error)` creates an OPC UA server endpoint and mirrors the registered namespace/object/variable topology. The gateway uses the open62541 minimal server configuration and reports the native state in `status()`.

```cpp
std::string error;
if (gateway.native_opcua_available()) {
    if (!gateway.start_native_server(4840, error)) {
        throw std::runtime_error(error);
    }
}
```

The in-process API remains authoritative for MuzixDiagSys state and is available whether or not a native OPC UA SDK is installed.

## 4.4 Standards boundary

The implementation is standards-oriented and uses AAS 3-style environment/model shapes and AASX packaging relationships, but a generated package or endpoint must still be run through the target organization's official schema/profile/conformance tooling before a claim of profile conformance is made. MuzixDiagSys capability reporting intentionally distinguishes implementation from third-party certification.

---

# 5. Physical DIL and OpenXR

## 5.1 Linux evdev device acquisition

`PhysicalDilDevice` opens a real `/dev/input/event*` device on Linux and consumes `EV_ABS` and `EV_KEY` events. Axis codes are mapped explicitly to roles:

- `steering` -> normalized `[-1, 1]`;
- `throttle` -> normalized `[0, 1]`;
- `brake` -> normalized `[0, 1]`;
- `clutch` -> normalized `[0, 1]`;
- `gear` -> integer gear state.

`DilAxisCalibration` provides minimum, center, maximum, dead zone, and inversion. The implementation validates calibration ordering and finite dead-zone behavior before accepting it.

```cpp
PhysicalDilDevice wheel;
std::string error;
if (!wheel.open_evdev("/dev/input/event12", error)) {
    throw std::runtime_error(error);
}
wheel.configure_axis(ABS_X, {-32768, 0, 32767, 0.02, false}, "steering");
wheel.configure_axis(ABS_RZ, {0, 0, 255, 0.01, true}, "throttle");
auto state = wheel.poll(std::chrono::milliseconds(5));
```

Permission to access an evdev node is an operating-system policy decision; do not run the simulator as root merely to bypass an incorrect udev/group configuration.

## 5.2 Force feedback

`set_constant_force()` uses Linux `EV_FF`/`FF_CONSTANT` effects and validates the normalized requested force. It uploads and plays a force-feedback effect on devices that advertise the required capability. Errors remain explicit when a device or kernel driver lacks force feedback.

Emergency stops, torque limits, wheel-base firmware limits, physical travel limits, and safe operator procedures remain external laboratory responsibilities. Software force feedback is not a safety-rated torque limiter.

## 5.3 OpenXR

`OpenXrDilRuntime` exposes runtime discovery, system/session state, event polling, and head/hand pose state. When the OpenXR loader is not compiled in, deterministic pose injection remains available for CI, recorded-session playback, and non-headset workflows.

```cpp
OpenXrDilRuntime xr;
std::string error;
if (!xr.initialize("MuzixDiagSys DIL", error)) {
    throw std::runtime_error(error);
}
auto state = xr.poll();
```

`native_openxr_available()` reports build capability separately from `system_available`, because having an OpenXR loader installed does not imply that an HMD/system is currently present.

---

# 6. Real automotive hardware I/O

## 6.1 Unified CAN frame model

`HardwareCanFrame` supports:

- standard and extended CAN identifiers;
- Classical CAN and CAN FD payload sizes;
- bitrate-switch and error flags;
- nanosecond timestamps;
- payload validation.

`HardwareChannelConfig` specifies backend, channel, arbitration/data bitrate, CAN FD mode, receive-own-message policy, and optional driver/plugin library paths.

## 6.2 Built-in backends

### SocketCAN

The Linux backend uses `PF_CAN`, `CAN_RAW`, interface indexes, optional `CAN_RAW_FD_FRAMES`, and `CAN_RAW_RECV_OWN_MSGS`. It supports real Classical CAN and CAN FD through kernel-supported interfaces.

### PEAK PCAN-Basic

The backend dynamically resolves the PCAN-Basic classic-CAN API, initializes the selected PCAN channel, transmits/receives frames, and uninitializes it during close. A PCAN-FD timing profile should be supplied through the vendor plugin ABI because the redistributable direct path intentionally avoids hard-coding SDK-version-specific FD parameter strings.

### Kvaser CANlib

The backend dynamically resolves CANlib, opens the selected numeric channel, applies supported arbitration bitrate profiles, controls bus-on/bus-off, and performs timed reads. CAN-FD-specific SDK profiles use the plugin ABI for the same version-isolation reason.

### Vector XL and NI-XNET

These commercial SDKs are intentionally integrated through the stable C ABI in `frontier_hardware_plugin.h`. MuzixDiagSys detects the vendor runtime but does not falsely mark the backend available until a bridge built against the licensed SDK is supplied.

## 6.3 Stable hardware plugin ABI

A bridge library exports:

```c
uint32_t muzix_hw_plugin_abi_version(void);
void* muzix_hw_open_v1(...);
int muzix_hw_send_v1(...);
int muzix_hw_receive_v1(...);
void muzix_hw_close_v1(...);
const char* muzix_hw_status_v1(...);
```

`MUZIX_HW_PLUGIN_ABI_VERSION` is currently `1`. ABI mismatch, missing symbols, failed opens, and vendor diagnostics are rejected before the channel is marked open.

The plugin path is designed for vendor SDKs whose licenses, redistributability, or installation models make direct linkage inappropriate. It is not a placeholder transport: the bridge's send/receive calls carry the production CAN frame data.

## 6.4 Threading and lifecycle

Channel open/send/receive/close operations are serialized around backend state. A failed open unwinds resources without recursively locking the channel mutex. Socket handles, vendor channel handles, dynamic libraries, and plugin handles are released by `close()` and by the destructor.

---

# 7. ns-3 packet-level federation

## 7.1 Two explicit modes

`Ns3Federation` never conflates the reference model with ns-3:

- `Ns3Mode::ExternalUdpBridge` sends versioned packet requests to a real external ns-3 process;
- `Ns3Mode::DeterministicReference` provides seeded serialization/propagation/loss behavior for CI and builds where ns-3 is not installed.

The result includes packet identity, delivery, congestion, receive timestamp, latency, configured/model-reported loss probability, and a diagnostic string.

## 7.2 Versioned bridge protocol

The `MNS3` bridge protocol uses network byte order and includes:

- protocol magic and version;
- request/response discriminator;
- 64-bit packet ID;
- 64-bit MuzixDiagSys transmit time;
- source/destination node IDs;
- protocol and traffic-class metadata;
- bounded packet payload;
- response delivery/congestion flags;
- receive time and latency;
- loss probability and diagnostic.

The UDP bridge enforces the IPv4 UDP datagram payload bound instead of advertising an impossible 64 MiB datagram.

## 7.3 Supplied ns-3 bridge

`integrations/ns3/muzix_ns3_bridge.cc` is a companion ns-3 scratch application. It:

- creates an ns-3 `NodeContainer`;
- installs the Internet stack;
- builds a shared CSMA channel;
- installs per-node UDP sockets;
- accepts MuzixDiagSys control requests on loopback UDP/47003;
- injects the corresponding packet into ns-3;
- measures delivery/latency on the ns-3 simulation clock;
- reports configured receive-loss behavior;
- expires packets that are dropped or fail to arrive.

Example:

```bash
cp integrations/ns3/muzix_ns3_bridge.cc /path/to/ns-3/scratch/
cd /path/to/ns-3
./ns3 build
./ns3 run 'scratch/muzix_ns3_bridge --nodes=8 --dataRate=100Mbps --delay=200us --loss=0'
```

The supplied bridge binds only to `127.0.0.1`. Do not expose the unauthenticated control protocol directly on an untrusted network; use an authenticated tunnel if federation must cross hosts.

---

# 8. Jupyter research environment

The Python package version is incremented to `2.1.0` and adds `muzixdiag.research_lab` plus the `research` optional dependency set.

```bash
python -m pip install -e './python[research]'
export MUZIXDIAGSYS_FRONTIER_PROFESSIONAL="$PWD/build/frontier-professional/muzixdiagsys_frontier_professional"
jupyter lab notebooks/
```

The four source notebooks are:

1. `01_opcua_aas_dil_lab.ipynb`
2. `02_bayesian_mlmc_lab.ipynb`
3. `03_acoustic_anc_lab.ipynb`
4. `04_federated_privacy_lab.ipynb`

They invoke the production C++ JSON command surface through `FrontierProfessionalClient`; they do not reimplement the simulator algorithms in notebook cells.

## 8.1 Python helpers

`research_lab.py` provides:

- `FrontierProfessionalClient`;
- `FrontierCommandResult`;
- `read_aasx()`;
- `parse_prometheus_text()`;
- `notebook_paths()`;
- `validate_notebooks()`.

The executable path can be set per client or through `MUZIXDIAGSYS_FRONTIER_PROFESSIONAL`.

```python
from muzixdiag.research_lab import FrontierProfessionalClient

client = FrontierProfessionalClient()
print(client.capabilities())
posterior = client.bayesian_demo()
```

All four notebooks are part of the regression/qualification workflow and can be executed non-interactively with `jupyter nbconvert --execute`.

---

# 9. Prometheus observability

## 9.1 Metric registry

`PrometheusRegistry` supports:

- counter families;
- gauge families;
- histogram families;
- arbitrary validated label sets;
- HELP and TYPE metadata;
- cumulative histogram buckets;
- `_sum` and `_count` rows;
- deterministic text rendering;
- JSON snapshots.

Metric names and label names are validated. Counter increments must be finite and non-negative. Gauge/histogram values must be finite.

```cpp
PrometheusRegistry registry;
registry.define_counter("muzix_runs_total", "Completed runs");
registry.define_gauge("muzix_realtime_factor", "Real-time factor");
registry.define_histogram("muzix_step_seconds", "Solver step duration", {0.001,0.005,0.01});

registry.increment("muzix_runs_total", 1, {{"scenario","durability"}});
registry.set("muzix_realtime_factor", 0.99);
registry.observe("muzix_step_seconds", 0.0032);
```

## 9.2 HTTP exporter

`PrometheusHttpExporter` provides:

- `GET /metrics` -> text exposition;
- `GET /healthz` -> health response;
- 404 for other paths;
- ephemeral port selection with port `0`;
- IPv4/IPv6 endpoint formatting;
- clean worker-thread shutdown.

Bind to loopback unless an authenticated/segmented monitoring network is intentionally configured.

---

# 10. Sigstore and in-toto provenance

## 10.1 In-toto statements

`SigstoreProvenance::in_toto_statement()` hashes the artifact with SHA-256 and emits an in-toto Statement containing:

- artifact subject name and digest;
- caller-selected predicate type;
- caller-supplied structured predicate;
- optional material URIs and SHA-256 digests.

`write_statement()` persists the evidence atomically.

## 10.2 Cosign integration

When `cosign` is installed, the subsystem invokes it with an argument vector rather than constructing a shell command. This prevents artifact/key/identity text from becoming shell syntax.

Signing uses a Sigstore bundle:

```text
cosign sign-blob --yes --bundle <bundle> [--key <key>] <artifact>
```

Verification supports either a key or certificate-identity/OIDC-issuer policy using the bundle. Exit status and diagnostic output are retained in `SigstoreResult`.

`validate_bundle_json()` performs structural validation independent of whether `cosign` is installed. Cryptographic trust still requires successful Cosign verification under the intended identity/key policy; structural JSON validation alone is not a signature verification.

---

# 11. Bayesian HMC/NUTS and MLMC

## 11.1 Hamiltonian Monte Carlo

`HamiltonianMonteCarlo::sample()` supports:

- caller-provided log density;
- optional analytic gradient;
- central finite-difference gradient fallback;
- leapfrog Hamiltonian integration;
- Metropolis correction;
- warmup;
- dual-averaging step-size adaptation;
- seeded trajectory-length jitter to avoid fixed-trajectory resonance;
- divergence detection;
- deterministic seeded runs.

`HmcOptions::trajectory_jitter` defaults to `0.2`, representing a seeded fractional randomization of the configured leapfrog count. Set it to `0` when an exactly fixed integration length is explicitly required.

## 11.2 No-U-Turn Sampler

`NoUTurnSampler::sample()` implements recursive binary-tree expansion with:

- random forward/backward expansion;
- slice-variable candidate selection;
- no-U-turn stopping criterion;
- dual-averaging step-size adaptation;
- maximum tree-depth control;
- divergence accounting.

## 11.3 Diagnostics

Both samplers return:

- retained samples;
- final step size;
- acceptance-rate statistic;
- mean acceptance probability;
- minimum dimension-wise effective sample size (ESS);
- maximum split-R-hat diagnostic;
- divergent transition count.

A single-chain split-R-hat is a useful stationarity signal but does not replace a multi-chain convergence study for safety-critical inference. Run multiple independently seeded chains for formal posterior qualification.

## 11.4 Multilevel Monte Carlo

`MultilevelMonteCarlo::estimate()` performs:

1. independent seeded pilot sampling per level;
2. correction mean/variance estimation;
3. measured cost estimation;
4. variance/cost-optimal sample allocation under the target variance budget;
5. bounded adaptive additional sampling;
6. final telescoping estimate and standard error.

The caller supplies a coupled fine/coarse sampler, which is essential: MLMC efficiency depends on variance reduction in the level correction, not merely on evaluating two independent models.

---

# 12. Acoustic beamforming and ANC

## 12.1 Delay-and-sum

`AcousticBeamformer::delay_and_sum()` accepts arbitrary 3-D microphone locations, validates equal channel lengths and finite samples, computes plane-wave geometric delay, and uses fractional interpolation while aligning channels.

## 12.2 Azimuth scanning

`scan_azimuth()` evaluates beam power over a caller-defined angular grid. It is useful for broadband/localization prototyping where a full frequency-domain covariance solution is not required.

## 12.3 MVDR/Capon narrowband beamforming

`mvdr_narrowband_scan()` performs:

- Hann-windowed narrowband complex extraction;
- microphone cross-spectral covariance construction;
- diagonal loading;
- complex matrix inversion;
- steering-vector evaluation;
- Capon/MVDR output-power calculation over the requested angular grid.

Diagonal loading must be selected relative to measurement noise, calibration uncertainty, sample count, and array conditioning in a physical experiment.

## 12.4 FxLMS active-noise control

`FxLmsController` implements single-reference/single-control filtered-x LMS with:

- configurable adaptive FIR length;
- secondary-path FIR model;
- adaptation rate;
- leakage;
- output saturation;
- reference, filtered-reference, and control histories;
- online coefficient update;
- reset/status access.

The production controller returns each step's raw control, secondary-path anti-noise estimate, and residual error. A real ANC deployment still requires measured secondary-path identification and stability/saturation qualification for the actual transducer/amplifier/acoustic path.

---

# 13. Federated and privacy-aware fleet learning

## 13.1 Relationship to the existing platform

MuzixDiagSys already had `FleetDigitalTwinPlatform::federated_aggregate()`. The new `FederatedPrivacyEngine` adds mechanisms that were absent rather than renaming FedAvg.

## 13.2 FedProx local update

`fedprox_local_step()` performs a gradient step with a proximal penalty relative to the current global model:

```text
theta_next = theta_local - learning_rate *
             (gradient + mu * (theta_local - theta_global))
```

This is useful for statistically/systematically heterogeneous fleet clients.

## 13.3 Krum

`krum_aggregate()` computes pairwise squared distances and selects the update with the smallest sum to its `n-f-2` nearest peers. It enforces the Krum cardinality requirement `n >= 2f + 3` and explicitly records accepted/rejected clients.

Krum is a robustness mechanism, not proof that a client is benign. Threat-model validation remains necessary.

## 13.4 Asynchronous aggregation

`asynchronous_aggregate()` weights updates by both sample count and staleness:

```text
weight_i proportional to sample_count_i / (1 + staleness_i)^exponent
```

The server learning rate is applied to the weighted displacement from the current global model. This enables a production fleet to incorporate delayed clients without pretending every update belongs to the same synchronous round.

## 13.5 Differentially private aggregation

`differentially_private_fedavg()`:

- validates finite client parameters;
- clips each client vector to an L2 norm;
- computes sample-count weighting;
- calibrates Gaussian noise from clipping sensitivity and `noise_multiplier`;
- uses a deterministic qualification seed when supplied;
- returns a zero-concentrated-DP (zCDP) accountant converted to `(epsilon, delta)`.

Privacy budget composition across many training rounds is a deployment-level responsibility. Do not quote one-round epsilon as the fleet program's total privacy guarantee.

## 13.6 X25519 secure aggregation

`secure_fedavg()` generates ephemeral X25519 key pairs, derives each pairwise shared secret independently from both sides, verifies secret agreement, derives per-parameter masks through HMAC-SHA-256, adds/subtracts pair masks according to deterministic client ordering, and verifies mask cancellation through the aggregate result.

The result includes a SHA-256 transcript over the round nonce, client IDs, and ephemeral public keys. Raw pairwise private keys/shared secrets are not exported through the result object.

The current primitive protects the aggregation path for a complete participating set. Production dropout-resilient secure aggregation requires a protocol for mask recovery/secret sharing when a participant disappears after key exchange; do not silently treat a complete-set round as dropout tolerant.

---

# 14. Validation

The subsystem has three qualification layers.

## 14.1 Standalone focused harness

The focused harness links the new sources with the minimum existing core/document/archive/fleet objects. It catches accidental dependence on unrelated advanced-platform state and exercises all ten feature groups.

## 14.2 Full project-linked regression

`frontier_professional_integration_tests` links against `aesim_advanced`, therefore its successful link validates compatibility with the complete advanced dependency graph and the existing motorsport/industrial/professional libraries.

Coverage includes:

- UA subscription deadbands and AASX round trip;
- DIL/OpenXR deterministic state;
- CAN transport round trip and capability probing;
- ns-3 reference serialization/propagation timing;
- Jupyter asset discovery;
- Prometheus metric exposition and HTTP-exporter lifecycle;
- in-toto statement and Sigstore-bundle structure;
- Gaussian HMC/NUTS posterior qualification;
- MLMC adaptive allocation and standard-error contract;
- MVDR source localization;
- FxLMS error reduction;
- FedProx, Krum, asynchronous aggregation;
- deterministic DP qualification and privacy accounting;
- X25519 secure-mask cancellation and transcript evidence;
- exact ten-feature capability registry.

## 14.3 Notebook execution

All four notebooks are parsed as nbformat 4 and executed non-interactively against the built `muzixdiagsys_frontier_professional` executable. This prevents examples from drifting away from the production JSON command surface.

---

# 15. Security and laboratory-safety boundaries

- Do not expose the ns-3 bridge or Prometheus endpoint publicly without network-layer authentication/segmentation appropriate to the laboratory.
- Do not use the hardware CAN backends on an operating vehicle or safety-critical bus without explicit authorization, galvanic/voltage compatibility, bus-load analysis, and an isolation plan.
- Treat force feedback as non-safety-rated software output; retain physical emergency-stop and torque-limiting mechanisms.
- Treat Sigstore bundle structural validation as syntax validation only; trust requires cryptographic verification under an explicit key or workload-identity policy.
- Treat DP accounting as part of a complete multi-round privacy budget, not as an isolated scalar.
- Treat Krum/robust aggregation as one adversarial defense layer, not a Byzantine-security proof under arbitrary assumptions.
- Native capability flags are authoritative for whether optional runtimes were compiled in; do not infer availability from documentation examples.

# 16. Primary source map

```text
include/aesim/advanced/frontier_professional_integration.hpp
include/aesim/advanced/frontier_hardware_plugin.h
src/advanced/frontier_professional_opcua_aas.cpp
src/advanced/frontier_professional_dil_openxr.cpp
src/advanced/frontier_professional_hardware_io.cpp
src/advanced/frontier_professional_ns3.cpp
src/advanced/frontier_professional_prometheus.cpp
src/advanced/frontier_professional_sigstore.cpp
src/advanced/frontier_professional_statistics.cpp
src/advanced/frontier_professional_acoustics.cpp
src/advanced/frontier_professional_federated_privacy.cpp
tools/frontier_professional_cli.cpp
tests/frontier_professional_integration_tests.cpp
python/muzixdiag/research_lab.py
notebooks/
integrations/ns3/
```

# 17. External standards/project references

Use the current official specifications/tool documentation when deploying native integrations:

- OPC UA specifications: OPC Foundation reference specifications, `https://reference.opcfoundation.org/`
- Asset Administration Shell: Industrial Digital Twin Association specifications, `https://industrialdigitaltwin.org/`
- OpenXR registry/specification: Khronos Group, `https://registry.khronos.org/OpenXR/`
- ns-3: `https://www.nsnam.org/`
- Prometheus exposition/monitoring documentation: `https://prometheus.io/docs/`
- Sigstore/Cosign: `https://docs.sigstore.dev/`
- in-toto: `https://in-toto.io/`

These references are deployment inputs; MuzixDiagSys does not freeze an external project's future release cadence into the simulator's internal capability claims.

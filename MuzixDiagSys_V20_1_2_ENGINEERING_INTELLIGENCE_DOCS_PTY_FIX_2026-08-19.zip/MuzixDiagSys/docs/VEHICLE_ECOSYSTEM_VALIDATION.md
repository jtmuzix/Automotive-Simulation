# Vehicle Ecosystem Validation Specification

**Revision:** 2026-07-12

## Validation objective

This document defines the verification performed for the integrated vehicle–occupant–environment ecosystem. It supplements, rather than replaces, all pre-existing validation documents.

## Dedicated executable

The dedicated test target is:

```text
ecosystem_tests
```

The associated CTest name is:

```text
ecosystem_unit_tests
```

## Covered behavior

The suite verifies:

1. Conservative one-dimensional thermo-fluid flow, pressure/temperature evolution, heat exchange, transported species, and finite mass/energy residuals.
2. Crankshaft torsion, gas torque, cam/valve lift, valve dynamics, EHL minimum film, peak film pressure, bearing loss, and energy residuals.
3. Rail pressure, needle motion, multi-bin spray, evaporation, heat release, cylinder pressure, indicated torque, emissions state, and fuel/chemical-energy residuals.
4. Torque-converter and planetary transmission operation, clutch slip energy, ratio behavior, gear-mesh force, oil temperature, and driveline energy residuals.
5. Particle-level electrode shells, conservative solid-lithium transfer, SOC evolution, pack voltage, OCV-integral stored energy, internal-short heating, gas generation, thermal coupling, and charge/energy residuals.
6. FMCW I/Q generation, range-Doppler processing, Bayer image formation, saturation behavior, lidar waveform generation, and extracted returns.
7. Human steering/pedal response, attention/fatigue evolution, takeover escalation, acknowledgement, and minimum-risk behavior.
8. Closed-loop agents, traffic signals, V2X delivery/loss, ODD violation, boundary margin, and minimum-risk request.
9. Cycle damage, wear, crack growth, health index, failure probability, and finite RUL uncertainty.
10. Offline/SIL/PIL/HIL task execution, deadlines, network/analog I/O, FMI model description, OpenDRIVE, OpenSCENARIO, ODD, OSI, and OpenLABEL exports.
11. End-to-end coupled advancement and aggregate conservation observability.

## Platform regression

`electrification_platform_tests` verifies the actual production facade:

- `industrial energy ecosystem` status and stepping.
- Signal registration and publication.
- Driver and execution-mode commands.
- Traffic and signal creation.
- Environmental input handling.
- Battery internal-short injection and clearing.
- Every subsystem report.
- The actual `muzixdiagsys --no-color` console path for ecosystem configuration, stepping, faults, reports, and export.
- FMI/OpenX bundle export and all six required output files.

## Acceptance criteria

- No NaN or infinity in public physical states.
- All dimensions and indices validated before execution.
- Positive time steps and bounded substeps.
- Conservation residuals finite and exposed.
- Zero-current particle-battery charge residual below 1e-6 C and energy residual below 1e-3 J.
- Loaded particle-battery charge residual below 1e-5 C and first-law residual below 500 J in the dedicated duty case.
- Transmission per-step energy residual below 100 J and compliant-shaft twist below 0.1 rad in the dedicated steady operating case.
- Deterministic random seeds.
- Faults affect the intended state and can be cleared.
- Exported files are nonempty and parseable by their supported subset.
- Existing regression tests remain unchanged in behavior.
- AddressSanitizer and UndefinedBehaviorSanitizer report no fault in the dedicated and platform suites.

## Physical correlation requirements

Software verification demonstrates deterministic implementation and internal consistency. Predictive validation requires comparison against physical data. Recommended datasets include:

- Instrumented fluid-loop pressure, flow, and temperature transients.
- Cylinder pressure and valve-motion measurements.
- Injector-rate and spray visualization data.
- Transmission dynamometer and clutch-energy tests.
- Cell pulse, EIS, aging, venting, and abuse calorimetry.
- Radar chamber, camera calibration, and lidar target-return data.
- Driver-in-the-loop and human factors studies.
- Naturalistic traffic and V2X channel measurements.
- Proving-ground loads and field durability records.
- ECU WCET, bus traces, and HIL timing measurements.

Any correlation claim must identify vehicle configuration, calibration revision, dataset hash, solver settings, random seed, residual tolerances, and acceptance metrics.

## Final verification evidence

The final source state was rebuilt after the conservation and console-regression corrections. Results:

```text
Complete Release build graph:                 PASSED
Main muzixdiagsys executable:                   PASSED
Libraries, plugins, tools, and FMU component: PASSED
Focused ecosystem unit suite:                 PASSED
Production electrification platform suite:    PASSED
Actual muzixdiagsys ecosystem CLI regression:   PASSED
User-manual provenance regression:            PASSED
Complete CTest matrix:                        79 / 79 PASSED
Complete CTest elapsed time:                  407.78 seconds
README command-surface audit:                 PASSED
Regulatory-cycle tracking regression:         PASSED
OSI protobuf wire conformance:                PASSED
GCC AddressSanitizer:                         PASSED
GCC UndefinedBehaviorSanitizer:               PASSED
Leak detection:                               PASSED
PDF render and visual preflight:              PASSED
Original-file preservation:                   439 / 439
Incomplete implementation marker audit:       PASSED
```

Representative coupled step after final corrections:

```text
time_s=0.040000
vehicle_speed_m_s=15.000000
automation_mode=automated
inside_odd=true
particle_pack_voltage_v=96.090356
fluid_mass_residual_kg=0.000000
fluid_energy_residual_j=0.000000
transmission_gear=5
transmission_ratio=4.128000
transmission_shaft_twist_rad=0.008750
transmission_energy_residual_j=-71.006159
particle_charge_residual_c=0.00000000
particle_energy_residual_j=-0.00000002
```

The sanitizer executions used `-fsanitize=address,undefined`, frame pointers, leak detection, halt-on-error behavior, and the focused ecosystem and production-platform test executables. No runtime sanitizer or leak finding was reported.

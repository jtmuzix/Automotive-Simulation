# Formula One Engineering Platform

## Purpose

The Formula One extension adds five executable engineering laboratories to the
existing MuzixDiagSys advanced library:

1. Versioned FIA technical-regulation compliance.
2. A 2026 hybrid power-unit and lap energy-management laboratory.
3. Active-aerodynamics, ground-effect, and aeroelastic simulation.
4. Formula One tyre, pressure, wear, and track-evolution physics.
5. Race-weekend optimization, Monte Carlo analysis, and pit-wall decisions.

The public API is available through either:

```cpp
#include "aesim/advanced/formula_one_platform.hpp"
```

or the umbrella header:

```cpp
#include "aesim/advanced/platform.hpp"
```

All functionality is additive. The extension does not alter the established
vehicle, powertrain, tire, CFD, FEA, HIL, diagnostics, evidence, or standards
interfaces.

## Regulatory source baseline

The built-in current profile is:

- season: 2026;
- section: C, Technical;
- issue: 19;
- publication date: 2026-06-25.

A prior Issue 18 profile is retained so rule deltas can be calculated and
regression campaigns can be pinned to the regulation issue under which a design
was assessed.

The built-in rules are an executable engineering subset covering publicly
identified dimensional, mass, wheel, power-unit, energy-recovery, sustainable
fuel, active-aero safety, high-voltage safety, and low-power-start requirements.
The profile is not represented as a substitute for scrutineering or an FIA legal
interpretation. The engine can load additional numeric and Boolean rules from a
`doc::Value` profile without changing its evaluation code.

## 1. Versioned FIA technical-regulation compliance

### Primary types

- `F1RegulationRule`
- `F1RegulationIssue`
- `F1RegulationRepository`
- `F1CarTechnicalSubmission`
- `F1TechnicalComplianceEngine`
- `F1ComplianceReport`

### Rule forms

The evaluator supports:

- minimum values;
- maximum values;
- closed ranges;
- exact values with tolerance;
- required-true conditions;
- required-false conditions.

Each rule carries a stable identifier, article reference, technical domain,
unit, severity, description, and numerical limits. Missing required fields fail
the rule rather than silently accepting the design.

### Geometry-envelope check

A submission may include body reference points and a legal bounding volume.
Every point outside that volume is returned by index in the compliance report.
This permits a CAD adapter to map the violation back to the originating face,
edge, actuator, or bodywork element.

### Version comparison

```cpp
F1RegulationRepository repository;
const auto& old_issue = repository.get(2026, "C", 18);
const auto& new_issue = repository.get(2026, "C", 19);
const auto delta = repository.compare(old_issue, new_issue);
```

`F1RegulationDifference` reports added, removed, and changed rule identifiers.

### Compliance example

```cpp
F1CarTechnicalSubmission submission;
submission.design_id = "race-car-a";
submission.numeric_fields["overall_width_m"] = 1.899;
submission.numeric_fields["wheelbase_m"] = 3.395;
submission.numeric_fields["minimum_mass_kg"] = 768.2;
submission.numeric_fields["wheel_rim_diameter_in"] = 18.0;
submission.numeric_fields["mguk_peak_power_kw"] = 349.8;
submission.numeric_fields["mguk_non_acceleration_power_kw"] = 249.7;
submission.numeric_fields["recoverable_energy_mj_per_lap"] = 8.49;
submission.boolean_fields["mgu_h_present"] = false;
submission.boolean_fields["fully_sustainable_fuel"] = true;
submission.boolean_fields["active_aero_fail_safe_present"] = true;
submission.boolean_fields["hv_isolation_monitor_present"] = true;
submission.boolean_fields["low_power_start_detection_present"] = true;
submission.boolean_fields["low_power_warning_lights_present"] = true;

F1TechnicalComplianceEngine engine;
auto report = engine.evaluate(
    repository.get(2026, "C", 19), submission);
```

The report includes pass/fail counts, safety-critical failures, margins,
diagnostics, geometry-envelope violations, and a SHA-256 evidence identity.

## 2. 2026 power-unit and energy-management laboratory

### Physical state

`F1PowerUnitState` retains:

- energy-store state of charge;
- energy-store temperature;
- turbo speed fraction;
- cumulative fuel use;
- cumulative deployed energy;
- cumulative recovered energy;
- cumulative electrical losses.

### Step model

`F1PowerUnit2026Laboratory::step` models:

- turbo spool response;
- throttle and engine-speed-dependent ICE availability;
- load-dependent indicated efficiency;
- zone-dependent MGU-K deployment limits;
- overtaking override;
- regenerative braking;
- lap recovery limits;
- battery state-of-charge limits;
- inverter and MGU-K efficiency;
- battery current and resistive heat;
- energy-store thermal derating;
- fuel flow and cumulative fuel consumption.

Positive `mguk_power_kw` is deployment. Negative power is recovery.

### Lap optimizer

`optimize_lap_energy` uses dynamic programming over discretized state of charge.
For every segment it evaluates a set of electrical deployment levels, computes
available recovery, ICE power, unmet wheel power, fuel consumption, and state
transition, then selects the least-cost trajectory satisfying the requested
minimum final state of charge.

The optimizer enforces:

- energy-store minimum and maximum state of charge;
- 350 kW acceleration/overtaking-zone deployment limit;
- 250 kW non-acceleration-zone deployment limit in the Issue 19 engineering
  profile;
- 8.5 MJ per-lap recoverable-energy limit;
- ICE power limit;
- terminal state-of-charge requirement.

## 3. Active aero, ground effect, and aeroelasticity

### Modes

- `Corner`
- `Straight`
- `Transition`
- `FailSafe`

### Implemented behavior

`F1ActiveAeroGroundEffectLaboratory` includes:

- independently commanded front and rear flap angles;
- actuator slew-rate limits;
- straight-mode drag reduction;
- corner-mode downforce restoration;
- ride-height-dependent ground-effect response;
- floor stall below minimum effective clearance;
- yaw and pitch sensitivity;
- crosswind and lateral force;
- front/rear aerodynamic balance;
- front-wing, rear-wing, and floor elastic deflection;
- fixed-point aeroelastic load correction;
- a damped porpoising oscillator;
- actuator and asymmetric-fault behavior;
- a legal fail-safe state;
- deterministic evidence output.

Aeroelastic floor deflection is subtracted from geometric ride height when
checking floor clearance. This ensures load-induced deformation can trigger a
stall or floor-contact risk rather than artificially increasing clearance.

## 4. Formula One tyre and track evolution

### Compounds

- soft;
- medium;
- hard;
- intermediate;
- wet.

### Tyre state

The model retains:

- surface, core, carcass, and rim temperatures;
- gas pressure;
- tread wear;
- graining;
- blistering;
- pickup;
- flat spotting;
- puncture state.

### Track state

Every track cell maintains:

- surface temperature;
- racing-line rubber;
- off-line marbles;
- water-film depth;
- dust;
- base friction;
- drainage and solar properties.

### Coupled physics

The step model calculates:

- combined longitudinal and lateral tire forces;
- aligning moment;
- temperature-dependent grip;
- pressure-dependent grip;
- compound-to-surface suitability;
- aquaplaning onset and severity;
- tread slip energy;
- brake-to-rim and rim-to-carcass heat transfer;
- air and track convection;
- graining and blistering growth/recovery;
- wear and pickup;
- rubber deposition and marble formation;
- rain wash-off, drainage, evaporation, and rain cooling.

### Blanket conditioning

`blanket_condition` uses separate surface, core, carcass, and rim time constants
and recalculates hot pressure from the gas temperature.

## 5. Race weekend and pit-wall strategy

### Race optimization

`F1RaceWeekendStrategySimulator::optimize_race_strategy` performs dynamic
programming over:

- current compound;
- tire age;
- dry-compound usage mask;
- pit or stay-out decisions;
- expected track water;
- traffic loss;
- safety-car and virtual-safety-car probabilities.

The objective includes:

- base lap time;
- compound performance;
- age-dependent degradation;
- wet/dry mismatch;
- traffic;
- expected pit-lane loss.

For a predicted dry race, the optimizer can enforce use of at least two distinct
dry compounds.

### Monte Carlo race simulation

`simulate_monte_carlo` samples:

- pit-stop time variation;
- lap-time variation;
- safety-car and virtual-safety-car pit-loss reductions;
- forecast rain occurrence;
- water-dependent compound mismatch.

It reports mean, standard deviation, 10th/50th/90th percentiles, sporting
compliance probability, and an evidence hash.

### Pit-wall decision

`decide` evaluates:

- current tire age and wear;
- current and near-term water forecast;
- safety-car, VSC, red-flag, or green conditions;
- pit loss;
- traffic gaps;
- expected new-tire advantage.

The result contains pit/stay-out selection, recommended compound, both expected
costs, decision margin, and a human-readable rationale.

## Build and validation

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target formula_one_platform_tests -j
ctest --test-dir build -R formula_one_platform_unit_tests --output-on-failure
```

The dedicated suite verifies:

- Issue 18 to Issue 19 regulation differences;
- regulation document round-trip;
- compliant and illegal car submissions;
- safety-critical compliance failures;
- zone-dependent MGU-K deployment;
- regenerative charging;
- terminal-energy-constrained lap optimization;
- corner/straight active-aero behavior;
- floor stall and aeroelastic deformation;
- fail-safe aero behavior;
- blanket heating and hot pressure;
- wear, rubbering, wet-compound advantage, and aquaplaning;
- dry-race two-compound strategy;
- Monte Carlo race-time statistics;
- wet-crossover safety-car pit-wall decisions.

## Qualification interpretation

The regulation engine produces deterministic engineering evidence. It does not
replace official FIA scrutineering, sporting adjudication, homologation, or a
team's controlled interpretation of the complete regulation text. The power
unit, aero, tire, track, and strategy models are open reference models intended
for simulation, teaching, research, regression, and architecture development.
Qualification use requires calibration against controlled measurements,
regulation-controlled data, track telemetry, and representative hardware.


## Formula One multiphysics extension

For flexible-body dynamics, persistent wake transport, thermal-fluid networks,
mechanistic lifing, optimal experiment design, advanced Bayesian estimation,
adaptive fidelity, second-order automatic differentiation, compressible gas
paths, and ECU/HIL scheduling, see
[`FORMULA_ONE_MULTIPHYSICS_PLATFORM.md`](FORMULA_ONE_MULTIPHYSICS_PLATFORM.md) and
include `aesim/advanced/formula_one_multiphysics_platform.hpp`.

## Integrated realism extension

`formula_one_realism_platform.hpp` adds production hardpoint K&C, flexible-ring tyre contact, circuit environment, damage-aware performance, driver human dynamics, wheel-end/driveline mechanics, RF/EMC telemetry, tyre pedigree, counterfactual strategy, and wind-tunnel facility simulation. See `FORMULA_ONE_REALISM_PLATFORM.md` for APIs and qualification requirements.

## Integrated operations, safety, and energy extension

`formula_one_integrated_operations_platform.hpp` adds spatial pit and garage
execution, occupant/HANS/egress biomechanics, semantic team radio, dynamic
trackside recovery, spray optics, carbon-brake thermomechanics, active-aero and
ground-effect stability, sustainable-fuel combustion and turbo rotordynamics,
switching-level ERS/EMC, and Bayesian CFD-tunnel-track aerodynamic fusion. See
[`FORMULA_ONE_INTEGRATED_OPERATIONS_PLATFORM.md`](FORMULA_ONE_INTEGRATED_OPERATIONS_PLATFORM.md)
for complete APIs, workflows, tests, and qualification boundaries.

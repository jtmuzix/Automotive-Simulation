# MuzixDiagSys Digital Thread and Frontier Assurance Platform

## Overview

The frontier platform extends MuzixDiagSys with eight additive capability domains:

1. SysML v2-oriented textual model ingestion, ReqIF exchange, typed digital-thread relations, and change-impact analysis.
2. ISO/PAS 8800-oriented AI lifecycle records, artifact hashing, release assessment, and assurance-case generation.
3. SAE/ETSI-oriented V2X message exchange, roadside infrastructure, certificate-backed signatures, replay protection, channel loss, and plausibility checks.
4. OpenMATERIAL, OpenLABEL, and OpenODD asset ingestion, export, and qualification.
5. ODD bin and pairwise coverage measurement plus deterministic gap-driven scenario synthesis.
6. Cell-level battery abuse, exothermic reaction, venting, thermal-runaway, and neighbor-propagation simulation.
7. Mixed-criticality virtual ECU execution with deterministic fixed-priority scheduling, bytecode execution, state persistence, static and measured WCET, and response-time analysis.
8. Forward-mode automatic differentiation, state sensitivities, output Jacobians, and differentiable transient integration.

All frontier functionality is opt-in. Loading or configuring a frontier domain does not remove or replace the established engine, research, HIL, industrial, assurance, virtual-vehicle, or electrification paths.

## Architecture

```text
include/aesim/frontier/
└── frontier.hpp

src/frontier/
├── internal.hpp
├── digital_thread.cpp
├── v2x.cpp
├── openx.cpp
├── runaway.cpp
├── vecu.cpp
├── differentiable.cpp
└── platform.cpp
```

The modules are linked into `aesim_industrial` and exposed by `aesim::frontier::FrontierPlatform`. The live simulator owns one frontier platform and routes commands through `industrial frontier` and the direct aliases documented below.

## Command namespace

```text
industrial frontier status
```

Direct aliases are also accepted:

```text
industrial sysml ...
industrial reqif ...
industrial digital-thread ...
industrial ai-safety ...
industrial iso8800 ...
industrial v2x ...
industrial openx ...
industrial openmaterial ...
industrial openlabel ...
industrial openodd ...
industrial odd ...
industrial runaway ...
industrial battery-abuse ...
industrial vecu ...
industrial wcet ...
industrial autodiff ...
industrial differentiable ...
```

## SysML v2-oriented digital thread

The textual model reader accepts a deterministic systems-modeling profile with packages, part definitions, requirements, verification cases, named identifiers, containment, and explicit relations. Imported elements are stored as typed records with stable IDs, names, qualified names, source paths, properties, and content hashes.

### Commands

```text
industrial frontier sysml import data/frontier_system.sysml
industrial frontier sysml export reports/system.sysml
industrial frontier reqif import data/frontier_requirements.reqif
industrial frontier reqif export reports/requirements.reqif
industrial frontier digital-thread import-links links.json
industrial frontier digital-thread impact MODEL-TORQUE reports/impact.json
industrial frontier digital-thread save reports/thread.json
industrial frontier digital-thread load reports/thread.json
industrial frontier digital-thread clear
industrial frontier digital-thread status
```

### ReqIF exchange

The ReqIF exchange preserves:

- specification-object identifiers;
- long names;
- string values;
- XHTML requirement text;
- specification hierarchy;
- typed requirement records;
- stable source identities;
- inter-element relations represented in the MuzixDiagSys thread repository.

Exports are XML documents with deterministic ordering so revisions can be compared meaningfully.

### Impact analysis

Impact traversal follows typed incoming and outgoing relations from a changed root. The report includes:

- the changed element;
- all transitively affected elements;
- paths from the root to each affected element;
- affected requirements and verification cases;
- evidence records that became stale because their bound content hashes no longer match.

## AI safety lifecycle

The AI lifecycle reader accepts YAML or JSON records containing datasets, models, requirements, runtime monitors, metrics, operating domains, fallback outputs, evidence, and metadata.

### Commands

```text
industrial frontier ai-safety load data/frontier_ai_safety.yaml
industrial frontier ai-safety evidence AI-EVID-003 AI-REQ-001 PASS report.json "campaign passed"
industrial frontier ai-safety safety-case reports/ai_safety_case.json
industrial frontier ai-safety evaluate
industrial frontier ai-safety status
```

### Release assessment

A model is releasable only when:

- at least one model and dataset are registered;
- referenced files exist and their SHA-256 digests are recorded;
- model-to-dataset references resolve;
- model and dataset approvals are acceptable;
- every safety requirement has passing evidence;
- evidence artifacts exist and are hashed;
- required runtime monitors and fallback definitions are present.

The assurance-case artifact includes lifecycle metadata, model and dataset provenance, requirements, evidence, individual verdicts, missing evidence, and the aggregate release decision.

## V2X and roadside infrastructure

### Message profile

The V2X envelope supports typed messages for:

- Basic Safety Message;
- Signal Phase and Timing;
- intersection MAP;
- Traveler Information Message;
- Cooperative Awareness Message;
- Decentralized Environmental Notification Message;
- Collective Perception Message.

Each message contains a station identity, monotonic sequence, timestamp, position, elevation, speed, heading, acceleration, typed numeric fields, typed text fields, certificate identity, and signature.

### Cryptographic authority

The authority uses OpenSSL P-256 keys and X.509 certificates. It provides:

- root authority creation;
- pseudonym certificate issuance;
- validity windows;
- certificate indexing and persistence;
- message signing;
- chain and signature verification;
- certificate revocation;
- revoked-certificate rejection.

### Commands

```text
industrial frontier v2x pki init reports/v2x-pki MuzixDiagSys-V2X-Authority
industrial frontier v2x pki issue VEH-001 0 4102444800000
industrial frontier v2x pki revoke <certificate-id>
industrial frontier v2x rsu load data/frontier_rsu.yaml
industrial frontier v2x rsu phase north_south green 12
industrial frontier v2x send data/frontier_v2x_message.json 5 [certificate-id]
industrial frontier v2x reset-replay
industrial frontier v2x status
```

### Network model

The channel computes free-space reference loss, configurable path-loss exponent, receive margin, logistic packet-error probability, and deterministic seeded delivery. Delivered messages pass through:

1. envelope decode and structural validation;
2. certificate and signature verification when secured;
3. per-station monotonic sequence replay checks;
4. geographic and kinematic plausibility checks;
5. delivery accounting.

### Roadside unit

The RSU stores intersection polygons and movement phases and can generate MAP, SPAT, and TIM data from its configured state.

## OpenMATERIAL, OpenLABEL, and OpenODD

### OpenMATERIAL profile

Material records support:

- stable material IDs and names;
- optical roughness;
- refractive index;
- radar relative permittivity;
- lidar reflectivity;
- emissivity;
- wavelength-indexed spectral reflectance.

### OpenLABEL profile

Frame and object records support:

- timestamps;
- frame IDs;
- object IDs and classifications;
- cuboid center, dimensions, and orientation;
- coordinate-system identity;
- confidence;
- attributes;
- track continuity across frames.

### OpenODD profile

ODD records support:

- a stable domain identity;
- categorical dimensions and allowed values;
- continuous dimensions and intervals;
- units;
- metadata and descriptions.

### Commands

```text
industrial frontier openx material import data/frontier_material.json
industrial frontier openx material export reports/material.json
industrial frontier openx label import data/frontier_openlabel.json
industrial frontier openx label export reports/labels.json
industrial frontier openx odd import data/frontier_openodd.yaml
industrial frontier openx odd export reports/odd.json
industrial frontier openx qualify
industrial frontier openx status
```

### Qualification

The qualifier checks required IDs, finite physical values, spectral tables, object dimensions, confidence ranges, coordinate systems, track continuity, and ODD dimension completeness. Findings are explicit and never silently discarded.

## ODD coverage and synthesis

The coverage engine discretizes continuous dimensions into configured bins and preserves categorical values as discrete cells. It measures:

- single-dimension bin coverage;
- pairwise cross-dimension coverage;
- uncovered bins;
- uncovered pairs;
- sample count and percentages.

### Commands

```text
industrial frontier odd configure data/frontier_openodd.yaml 5
industrial frontier odd samples data/frontier_odd_samples.yaml
industrial frontier odd analyze
industrial frontier odd report reports/odd_coverage.json
industrial frontier odd synthesize reports/generated_scenarios.json 100 42
```

Scenario synthesis is deterministic for a given seed. It prioritizes uncovered single bins, then uncovered pairwise cells, then fills any remaining request with seeded, in-domain combinations. Every generated scenario records its source ODD and the coverage gap it was selected to address.

## Battery abuse and thermal runaway

The cell network models:

- core and surface temperatures;
- core-to-surface conduction;
- neighbor conduction;
- radiative neighbor transfer;
- coolant and ambient heat rejection;
- internal short, external short, overcharge, heater, crush, and penetration abuse;
- Arrhenius exothermic reaction;
- reaction-progress depletion;
- gas generation;
- vent opening and gas release;
- runaway and cell-failure states;
- pack energy residual;
- propagation to neighboring cells.

### Commands

```text
industrial frontier runaway configure data/frontier_runaway.yaml
industrial frontier runaway reset 298.15
industrial frontier runaway inject 0 0 heater 4000
industrial frontier runaway step 0.01 298.15 298.15
industrial frontier runaway clear 0 0
industrial frontier runaway save reports/runaway.json
industrial frontier runaway load reports/runaway.json
industrial frontier runaway status
```

The state document preserves temperatures, reaction progress, gas mass, vented mass, abuse mode, abuse intensity, vent state, runaway state, failure state, and simulation time.

## Mixed-criticality virtual ECU and WCET

The virtual ECU loads a YAML task set. Each task defines:

- stable task ID;
- criticality level;
- period and deadline in integer nanoseconds;
- fixed priority;
- low- and high-criticality budgets;
- instruction bound;
- deterministic bytecode program.

The bytecode VM supports signal load/store, constants, arithmetic, comparisons, branches, clamping, and termination. It has bounded registers, bounded instruction execution, explicit invalid-signal errors, and non-finite-value rejection.

### Scheduler

The scheduler implements:

- deterministic integer time;
- fixed-priority release ordering;
- periodic tasks;
- deadline accounting;
- low- and high-criticality budgets;
- high-criticality mode transition on critical overrun;
- low-criticality task suppression in high-criticality mode;
- invocation and execution-time accounting;
- exact state serialization and restoration.

### WCET analysis

The analyzer combines:

- static instruction-path cost;
- repeated measured execution time;
- maximum and percentile observations;
- declared task budgets;
- fixed-priority response-time recurrence;
- low-criticality schedulability;
- high-criticality schedulability;
- aggregate system verdict.

Measurement is performed against a temporary runtime snapshot so analysis does not modify the live ECU task state.

### Commands

```text
industrial frontier vecu load data/frontier_vecu.yaml
industrial frontier vecu reset 0
industrial frontier vecu step 10000000
industrial frontier vecu analyze 100 reports/wcet.json
industrial frontier vecu save reports/vecu.json
industrial frontier vecu restore reports/vecu.json
industrial frontier vecu status
```

## Differentiable simulation

The differentiable engine parses arithmetic expressions into an abstract syntax tree and evaluates them with dual values carrying derivatives with respect to selected parameters.

Supported expression operations include:

- addition, subtraction, multiplication, and division;
- power;
- unary negation;
- `sin`, `cos`, `tan`, `exp`, `log`, `sqrt`, `abs`, `min`, and `max`;
- parameters, inputs, state variables, and time.

### Transient sensitivities

State values and parameter sensitivities are integrated together with fourth-order Runge-Kutta. The solver therefore produces derivatives of outputs and states with respect to model parameters, not only static expression gradients.

### Commands

```text
industrial frontier diff load data/frontier_differentiable.yaml
industrial frontier diff reset
industrial frontier diff input force 3000
industrial frontier diff parameter mass 1500
industrial frontier diff evaluate acceleration
industrial frontier diff step 0.1
industrial frontier diff jacobian reports/jacobian.json
industrial frontier diff status
```

## Validation assets

```text
data/
├── frontier_system.sysml
├── frontier_requirements.reqif
├── frontier_ai_safety.yaml
├── frontier_ai_dataset.csv
├── frontier_ai_model.bin
├── frontier_ai_evidence.txt
├── frontier_v2x_message.json
├── frontier_rsu.yaml
├── frontier_material.json
├── frontier_openlabel.json
├── frontier_openodd.yaml
├── frontier_odd_samples.yaml
├── frontier_runaway.yaml
├── frontier_vecu.yaml
└── frontier_differentiable.yaml
```

Permanent regression coverage is provided by:

```text
tests/frontier_platform_tests.cpp
tests/frontier_platform_regression.py
```

## Interoperability scope

The implementations are executable engineering profiles with strict parsing, validation, persistence, and negative-path behavior. They do not claim standards-body certification. Inputs outside an implemented profile are rejected with explicit diagnostics rather than accepted and ignored.

## 2026-07-12 next-generation vehicle-depth integration

Digital-thread records may now include replay state hashes, structural stress, tire failure state, protection state, ECU deadline statistics, and fidelity-transition conservation corrections.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


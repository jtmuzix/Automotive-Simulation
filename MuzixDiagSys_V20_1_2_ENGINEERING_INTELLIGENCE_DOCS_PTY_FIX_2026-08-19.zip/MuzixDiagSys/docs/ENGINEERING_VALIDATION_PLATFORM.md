# Engineering Validation Platform

This release extends the existing MuzixDiagSys V20.1.2 simulation stack with eight tightly integrated engineering-validation capabilities. The implementation is additive: existing authoritative solvers are reused and extended rather than copied into parallel subsystems.

## 1. Commercial tire identification

`CommercialTireIdentificationLab` builds on `F1VirtualTireTestLaboratory`. It adds commercial parameter-deck import/export, deterministic train/validation splitting, robust nonlinear identification, covariance-derived parameter uncertainty, and independent validation statistics. The existing tire force/transient implementation remains authoritative.

Supported fit evidence includes per-axis RMSE, normalized RMSE, coefficient of determination, optimizer covariance, fitted-parameter standard deviation, convergence state, and a SHA-256 evidence digest. The `.tir` reader accepts the Muzix commercial deck keys plus common aliases for unloaded radius, nominal load, friction, stiffness, relaxation, pressure, and temperature parameters; unrecognized numeric vendor fields are preserved.

## 2. Real-world test correlation and road-load reconstruction

`RealWorldTestCorrelationLab` aligns measured and simulated channels by bounded cross-correlation, performs interpolation onto a common time base, and computes RMSE, normalized RMSE, R-squared, peak error, mean bias, Pearson correlation, and Welch spectral coherence. The aggregate report ranks correlation quality and emits diagnostics for weak time- or frequency-domain agreement.

The same laboratory includes stabilized double integration for base-displacement reconstruction from measured vertical acceleration. Leakage/high-pass stabilization limits the low-frequency drift that makes naive double integration unusable on proving-ground data.

## 3. Synthetic-data / sim-to-real qualification

`SyntheticSimToRealPipeline` is an orchestration and qualification layer over the existing `research2::SimToRealAdapter`. It does not introduce a second adaptation model. The pipeline adds deterministic Latin-hypercube domain-randomization designs and independent discrepancy measures before and after adaptation.

Reported discrepancy metrics include standardized feature-mean gap and RBF-kernel maximum mean discrepancy (MMD). The result records whether the existing governed adapter reduced both discrepancy measures and hashes the qualification evidence.

## 4. Grid-aware charging optimization

`GridAwareChargingSimulator::optimize_schedule` extends the existing radial three-phase distribution solver. Charging schedules are allocated using marginal energy, carbon, degradation, and demand costs; every candidate schedule is checked using the existing `solve_power_flow` implementation.

The optimizer enforces departure windows, vehicle charge/discharge limits, minimum bus voltage, line thermal loading, charge/discharge efficiency, V2G eligibility, and battery reserve constraints. Network-violating slots are iteratively curtailed and the resulting energy is repaired into feasible pre-departure slots where possible. The final report includes energy and carbon costs, demand charge, degradation cost, peak demand, shortfall penalty, grid feasibility, and SHA-256 evidence.

## 5. Distributed parallel discrete-event simulation

`DistributedSharedWorldExecutor::execute_pdes` extends the pre-existing shared-world conservative/optimistic execution model. Conservative execution remains timestamp ordered. Optimistic execution now maintains explicit partition checkpoints, recognizes stragglers, rolls back to the newest valid checkpoint, replays causally ordered events, counts anti-message-equivalent invalidations, bounds rollback depth, computes global virtual time, and performs checkpoint fossil collection.

The result records rollback, straggler, checkpoint, fossil-collection, and maximum rollback-depth statistics in addition to the existing deterministic shared-world state digest.

## 6. Model validation and credibility

`SolverCredibilityAndDigitalTwinLaboratory::assess_validation_domain` extends the existing solver-credibility subsystem with operating-domain governance. Each model can declare validated ranges for named operating variables. Requested operating points are measured against those ranges and assigned normalized extrapolation distance.

The assessment combines fit error, R-squared, validation coverage, extrapolation distance, and measurement uncertainty into a bounded credibility score. It emits specific warnings for out-of-domain variables, large normalized residuals, and weak predictive agreement.

## 7. Cross-model conservation governor

`ConservationGovernor::audit_interfaces` extends the existing aggregate conservation audit with interface-level attribution. Each interface sample records inflow, outflow, storage change, modeled generation, modeled dissipation, tolerances, and time.

The governor computes residual and normalized residual by interface, contribution fraction to total imbalance, dominant interface, dominant time, aggregate action (`Accept`, `RefineStep`, `Rollback`, or `Abort`), and a cryptographic evidence digest. This makes global mass/energy/charge imbalance traceable to the coupling boundary that created it.

## 8. Generalized lubrication hydraulic network

`LubricationHydraulicNetwork` complements the existing `UnifiedTribologyWearSystem` by modeling the fluid-supply system feeding tribological contacts. It supports reservoirs, junctions, bearing feeds, piston jets, turbo feeds, VVT actuators, coolers, filters, accumulators and returns, connected by pipes, pumps, restrictors, relief valves, check valves, orifices, and scavenge pumps.

The nonlinear network solves pressure-dependent flow, temperature-dependent viscosity, Reynolds number, pump delivery, cavitation, pickup starvation under acceleration, demand shortfall, oil heating, pump power, entrained-air effects, and mass-balance residual. The resulting node supply flow and pressure can be passed directly into the existing tribology loads.

## Non-duplication architecture

The release intentionally retains the following authority boundaries:

- Tire force/transient physics: `F1VirtualTireTestLaboratory`.
- Sim-to-real statistical adaptation: `research2::SimToRealAdapter`.
- Distribution power flow: `GridAwareChargingSimulator::solve_power_flow`.
- Shared-world event semantics: `DistributedSharedWorldExecutor`.
- Solver credibility: `SolverCredibilityAndDigitalTwinLaboratory`.
- Conservation policy: `assured::ConservationGovernor`.
- Contact lubrication/wear: `UnifiedTribologyWearSystem`.

The new code adds identification, orchestration, optimization, diagnostics, and hydraulic supply physics around those existing implementations.

## Validation

The `engineering_validation_platform_tests` native C++ suite covers all eight areas, including tire parameter-deck round-trip, robust tire fitting, temporal/spectral test correlation, domain-randomization and sim-to-real discrepancy reduction, grid-feasible optimized charging, optimistic PDES rollback, validation-domain extrapolation, interface conservation attribution, and bearing-feed oil delivery.

`engineering_validation_source_regression.py` protects implementation tokens, build wiring, public-header aggregation, no-placeholder policy, and explicit reuse of the existing tire, grid, and sim-to-real authorities.

# Frontier Expansion Platform

**Release:** 2026-08-07  
**CLI family:** `muzixdiagsys_advanced_platform frontier-expansion ...`  
**Public API:** `aesim/advanced/frontier_expansion_platform.hpp`  
**Library:** `aesim_advanced`

The Frontier Expansion Platform is an additive engineering and research layer. It does not replace or disable any existing simulator command, command-line workflow, motorsports platform, numerical solver, diagnostic service, interoperability interface, or advanced-platform domain. The implementation provides deterministic host execution for every domain. Native MPI and HIP paths are selected only when their toolchains are detected at configure time.

The platform contains fourteen independently invokable domains:

1. `safe-reinforcement-learning-laboratory`
2. `asam-cmp-capture-platform`
3. `asam-traffic-participants-platform`
4. `sysml-v2-repository-integration`
5. `scientific-streaming-io-platform`
6. `modern-mpi-transport-runtime`
7. `qualified-external-solver-backends`
8. `automotive-sensor-bus-physical-layer`
9. `materialx-gltf-asset-pipeline`
10. `gpu-particle-multiphysics-runtime`
11. `lubricant-chemistry-condition-monitoring`
12. `tire-acoustic-and-uniformity-laboratory`
13. `hazop-bowtie-barrier-assurance`
14. `software-supply-chain-evidence-platform`

## 1. Build and capability discovery

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON \
  -DAESIM_ENABLE_HIP=ON \
  -DAESIM_ENABLE_SYCL=ON

cmake --build build/full --parallel "$(nproc)" --target \
  muzixdiagsys_advanced_platform \
  frontier_expansion_platform_tests
```

Discover runtime capabilities:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-expansion capabilities
```

Run the domain-level self-test:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion self-test build/frontier-expansion-self-test \
  build/frontier-expansion-self-test.json
```

General invocation:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The `WORKING_DIRECTORY` argument is used by domains that persist capture files, repositories, scientific streams, material assets, solver request/response files, or evidence bundles.

## 2. Safe reinforcement-learning laboratory

`SafeReinforcementLearningLaboratory` trains and evaluates bounded vehicle-control policies against the existing deterministic vehicle learning environment. The implementation uses constrained stochastic policy search with an elite distribution update and an invariant action shield.

The policy maps six normalized observations to three bounded actions:

- normalized longitudinal speed error;
- lateral error;
- heading error;
- yaw rate;
- nearest-vehicle headway;
- normalized vehicle speed;
- throttle;
- brake;
- steering.

Safety handling is not implemented as an after-the-fact label. The action shield is applied before environment execution and enforces emergency braking/acceleration suppression when headway becomes critically small and steering recovery when lateral deviation approaches the lane envelope.

Training supports:

- deterministic seed control;
- configurable population and elite count;
- configurable generations and evaluation episodes;
- exploration-standard-deviation annealing;
- safety-cost constraints;
- explicit safety-violation penalties;
- independent final policy evaluation;
- lane-departure and collision rates;
- SHA-256 evidence sealing of the resulting training/evaluation document.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion safe-reinforcement-learning-laboratory \
  examples/frontier_expansion/safe_rl.json \
  build/results/safe-rl.json
```

To evaluate an existing policy, use `operation: "evaluate"` and provide the serialized `policy`, `episodes`, and `seed` fields.

## 3. ASAM CMP capture platform

`AsamCmpCapturePlatform` implements a deterministic capture-record transport used to model capture modules, data sinks, source interfaces, sequence integrity, timestamped payload movement, and persistent replay. The record profile uses the ASAM CMP EtherType (`0x99FE`) as its protocol discriminator and records CMP-oriented module/sink/interface metadata.

Each encoded simulator capture record contains:

- EtherType and protocol version;
- capture-module identifier;
- data-sink identifier;
- source-interface identifier;
- message type;
- 32-bit sequence number;
- nanosecond timestamp;
- payload length and payload;
- CRC32 over the complete record body.

The capture engine detects and records:

- duplicate sequence numbers;
- reordered records;
- missing sequence ranges;
- CRC failures;
- first/last capture timestamps;
- accepted record count.

Persistent `.aescmp` captures contain individually length-delimited and CRC-validated records. Truncated lengths, impossible record sizes, malformed versions, invalid payload lengths, and corrupt CRC values are rejected rather than silently accepted.

This is a production MuzixDiagSys capture/emulation profile for CMP-oriented testing. The project does not claim third-party ASAM conformance certification or claim that `.aescmp` is an official ASAM exchange-file format.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion asam-cmp-capture-platform \
  examples/frontier_expansion/asam_cmp.json \
  build/results/cmp.json build/results/cmp-work
```

Supported operations are `encode`, `decode`, and `capture`.

## 4. ASAM Traffic Participants platform

`AsamTrafficParticipantsPlatform` provides one normalized participant definition for road actors that otherwise appear independently in scenario, sensor, traffic, and autonomy models.

Supported participant classes include:

- passenger car;
- truck;
- bus;
- motorcycle;
- bicycle;
- pedestrian;
- trailer;
- emergency vehicle;
- other/custom participant.

The canonical model includes dimensions, mass, maximum speed, acceleration/deceleration limits, lateral-acceleration limit, classifications, and articulated-child relationships.

Validation rejects:

- missing participant identifiers;
- non-positive physical dimensions or mass;
- negative dynamic limits;
- empty/duplicate articulated child identifiers;
- self-articulation.

The platform can generate normalized OpenSCENARIO-style catalog objects and OSI-style object representations from the same validated participant. `canonicalize` validates complete catalogs and reports each invalid/duplicate participant without discarding valid entries.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion asam-traffic-participants-platform \
  examples/frontier_expansion/traffic_participants.json \
  build/results/traffic-participants.json
```

Supported operations are `canonicalize`, `validate`, `openscenario`, and `osi`.

## 5. SysML v2 repository integration

`SysmlV2Repository` provides a content-addressed, versioned system-model repository suitable for deterministic simulation/MBSE workflows. It is intentionally file-backed so the complete repository is available in offline, CI, HPC, and air-gapped environments without a mandatory external service.

Repository semantics include:

- initialization;
- named branches;
- upsert and erase changes;
- immutable commit objects;
- parent-commit linkage;
- content-addressed tree SHA-256;
- content-addressed commit SHA-256;
- atomic branch-reference updates;
- type-filtered queries;
- full-text JSON queries;
- added/removed/modified element diffs;
- preserved `@id` identity.

The same repository API can be used as a deterministic local mirror/staging area for external SysML v2 services. No external server is required to use the feature.

Example commit:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion sysml-v2-repository-integration \
  examples/frontier_expansion/sysml_repository.json \
  build/results/sysml-commit.json build/results/sysml-work
```

Supported operations are `head`, `query`, `diff`, and `commit`.

## 6. Scientific streaming I/O platform

The scientific stream is a deterministic append-only binary record container optimized for simulation state, field reductions, telemetry vectors, and checkpoints. It is designed to remain usable even when optional HPC I/O libraries are not installed.

Each record contains:

- simulation step;
- simulation time;
- named variables;
- engineering units;
- one or more binary64 values per variable.

On disk, every canonical-JSON record is independently:

1. serialized deterministically;
2. compressed with zlib;
3. length-delimited;
4. protected with CRC32;
5. appended to the stream.

Readers verify the file magic, record sizes, decompression length, CRC, JSON syntax, variable names, and finite numerical values. Variable-selective reading allows a consumer to subscribe to one variable without changing the stored stream.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion scientific-streaming-io-platform \
  examples/frontier_expansion/scientific_stream.json \
  build/results/scientific-stream.json build/results/stream-work
```

Supported operations are `write`, `read`, and `inspect`.

## 7. Modern MPI transport runtime

`ModernMpiTransportRuntime` augments the existing distributed/ULFM infrastructure with MPI-4-aware transport capabilities while retaining a deterministic single-process implementation when MPI is unavailable.

Runtime capability discovery reports:

- whether MPI was compiled in;
- MPI major/minor version;
- world size and rank when initialized;
- MPI Sessions availability;
- partitioned-communication availability;
- persistent-collective availability;
- native ULFM compile capability.

The API provides:

- balanced deterministic work partitioning;
- pairwise deterministic reduction for local numerical reproducibility;
- persistent all-reduce using `MPI_Allreduce_init` when MPI 4 is available and initialized;
- standard `MPI_Allreduce` fallback on older native MPI implementations;
- a session-based `mpi://WORLD` size query under MPI 4;
- serial fallback with identical public API when MPI is absent.

This capability design means enabling MPI acceleration never makes the host simulator mandatory-dependent on MPI.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion modern-mpi-transport-runtime \
  examples/frontier_expansion/modern_mpi.json \
  build/results/mpi.json
```

Supported operations are `capabilities`, `partition`, `deterministic-sum`, `persistent-allreduce`, and `session-world-size`.

## 8. Qualified external solver backends

`QualifiedSolverBackends` provides independent linear-solver families and an external-process qualification protocol. Native simulator calculations can therefore be cross-checked instead of trusting a single algorithmic path.

Built-in solver families:

- dense Gaussian/LU elimination with partial pivoting;
- conjugate gradient for symmetric positive-definite systems;
- BiCGSTAB for nonsymmetric systems.

Every solver result reports:

- backend identity;
- solution vector;
- iteration count;
- independently recomputed L2 residual;
- convergence status;
- diagnostic detail.

`consensus` runs independent solver families and verifies both the maximum residual and maximum pairwise solution disagreement. The resulting evidence document is SHA-256 sealed.

### 8.1 External-process protocol

`external` writes a deterministic JSON request file, launches the configured executable without shell interpolation on POSIX systems, enforces a timeout, requires an output file, validates output dimensions and finiteness, and independently recomputes the residual before reporting the result.

The external command receives two final arguments:

```text
COMMAND ... INPUT.json OUTPUT.json
```

Input schema:

```json
{
  "schema": "muzixdiagsys.external-linear-solver-request.v1",
  "matrix": [[4.0, 1.0], [1.0, 3.0]],
  "rhs": [1.0, 2.0]
}
```

Required output field:

```json
{"solution": [0.0909090909, 0.6363636364], "iterations": 1}
```

Adapters for PETSc, SUNDIALS-driven linearizations, Trilinos, Hypre, MUMPS, SuiteSparse, AMGX, or site-specific solvers can use this process boundary without linking those libraries into the simulator executable. Qualification still occurs inside MuzixDiagSys via the independently recomputed residual.

Example consensus:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion qualified-external-solver-backends \
  examples/frontier_expansion/qualified_solvers.json \
  build/results/solver-consensus.json
```

## 9. Automotive sensor-bus physical layer

`AutomotiveSensorBusPhysicalLayer` adds low-level sensor communication models for:

- SENT;
- PSI5;
- DSI3;
- CXPI.

The feature does not stop at decoded messages. It creates and consumes edge-time/logic-level waveforms with protocol-specific symbol rules.

Implemented behaviors include:

- SENT synchronization/status/data/CRC-nibble pulse widths;
- PSI5 Manchester coding;
- DSI3 pulse-width coding;
- CXPI start/data/parity/stop framing;
- CRC/checksum verification;
- configurable timing jitter;
- stochastic edge loss with deterministic seeding;
- decoder timing and framing validation;
- measured timing/bitrate reporting.

Corrupted framing, parity, invalid pulse widths, impossible nibble counts, incomplete bytes, invalid CRCs, and malformed edge arrays are detected explicitly.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion automotive-sensor-bus-physical-layer \
  examples/frontier_expansion/sensor_bus.json \
  build/results/sensor-bus.json
```

## 10. MaterialX/glTF asset pipeline

`MaterialAssetPipeline` implements glTF 2.0 and MaterialX 1.38 material import/export plus deterministic round-trip qualification.

The common material model carries:

- base color and alpha;
- metallic factor;
- roughness;
- emissive color;
- index of refraction;
- transmission;
- LiDAR reflectivity;
- radar real permittivity;
- radar loss tangent.

The glTF path uses standard PBR metallic-roughness fields and `KHR_materials_ior` / `KHR_materials_transmission`; simulator-specific sensor parameters are preserved in `extras`. The MaterialX path emits/reads `standard_surface` inputs and preserves the same sensor-property extensions.

`roundtrip` writes both formats, reads them back, computes the maximum numeric error over every supported property, and fails if the error exceeds the strict round-trip threshold.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion materialx-gltf-asset-pipeline \
  examples/frontier_expansion/material_assets.json \
  build/results/material-assets.json build/results/material-assets-work
```

## 11. GPU particle multiphysics runtime

`GpuParticleMultiphysicsRuntime` provides production host implementations plus an optional HIP backend.

### 11.1 Host SPH

The SPH path implements:

- three-dimensional cell-linked spatial hashing;
- deterministic neighbor-list construction;
- Poly6 density evaluation;
- pressure from a configurable equation-of-state stiffness;
- Spiky pressure gradients;
- viscosity Laplacian;
- body-force integration;
- finite-state verification;
- kinetic-energy reporting.

### 11.2 Host DEM

The DEM path implements:

- cell-linked contact candidate discovery;
- sphere overlap/contact detection;
- normal penalty stiffness;
- velocity-dependent damping;
- equal/opposite pair forces;
- gravity;
- explicit time integration;
- finite-state verification.

### 11.3 HIP backend

When CMake detects a HIP compiler, `frontier_expansion_particle_hip.hip` is compiled into `aesim_advanced`. Native kernels perform GPU-resident SPH density/integration and DEM integration. When HIP is unavailable, the host cell-linked implementations remain fully operational and `native_gpu_available` reports false rather than pretending acceleration is active.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion gpu-particle-multiphysics-runtime \
  examples/frontier_expansion/particle_multiphysics.json \
  build/results/particles.json
```

Supported operations are `capabilities`, `sph`, and `dem`.

## 12. Lubricant chemistry and condition monitoring

`LubricantChemistryConditionMonitoring` integrates an operating-history-dependent lubricant state with bounded time steps.

State variables include:

- oxidation;
- nitration;
- additive reserve;
- soot loading;
- water contamination;
- fuel dilution;
- TAN;
- TBN;
- 100 °C kinematic viscosity;
- wear metals;
- varnish index.

The aging rates depend on temperature, load, oxygen fraction, blow-by, water ingress, fuel ingress, and soot ingress. Temperature acceleration follows a Q10-style relationship, while fuel and water include temperature-dependent removal terms. Oxidation/nitration and contamination feed viscosity, TAN/TBN, wear, and varnish rather than evolving as isolated counters.

`condition_report` computes service alerts and a 0–100 health score with `normal`, `monitor`, `service-soon`, and `service-now` conditions.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion lubricant-chemistry-condition-monitoring \
  examples/frontier_expansion/lubricant_condition.json \
  build/results/lubricant.json
```

## 13. Tire acoustic and uniformity laboratory

`TireAcousticUniformityLaboratory` joins tire-generated tonal content with manufacturing/uniformity defects.

It computes:

- wheel rotation frequency and harmonics;
- tire-cavity acoustic mode and harmonics;
- tread-pass frequency and harmonics;
- speed-dependent relative levels;
- radial-force-variation influence;
- lateral-force variation;
- conicity plus ply-steer steering pull;
- rotating imbalance force;
- flat-spot excitation;
- aggregate uniformity score.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion tire-acoustic-and-uniformity-laboratory \
  examples/frontier_expansion/tire_acoustic.json \
  build/results/tire-acoustic.json
```

## 14. HAZOP, bow-tie, and barrier assurance

`HazopBowTieBarrierAssurance` complements the existing FMEA/FMEDA/FTA/STPA safety stack.

### 14.1 HAZOP

For every declared process parameter the HAZOP generator applies:

- No;
- More;
- Less;
- Reverse;
- Early;
- Late.

Every deviation contains the parameter, guideword, generated deviation statement, screening severity, and a required simulation/coverage action.

### 14.2 Bow-tie and barrier reliability

The bow-tie model contains:

- hazard;
- initiating frequency;
- causes;
- consequences;
- prevention barriers;
- mitigation barriers;
- probability of failure on demand;
- availability;
- common-cause beta factor.

The solver evaluates prevention failure, top-event frequency, mitigation failure, and unmitigated consequence frequency. For at most sixteen barriers it also enumerates the complete independent dynamic event-state space and reports states with non-negligible probability.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion hazop-bowtie-barrier-assurance \
  examples/frontier_expansion/hazop_bowtie.json \
  build/results/bowtie.json
```

## 15. Software supply-chain evidence platform

`SoftwareSupplyChainEvidencePlatform` creates machine-readable build evidence and evaluates release policy.

Implemented evidence includes:

- SPDX 2.3-style package/document data;
- source and artifact SHA-256 values when paths are supplied;
- vulnerability findings;
- VEX disposition handling;
- SARIF-oriented static-analysis finding ingestion;
- maximum-unresolved-CVSS policy;
- denied-license policy;
- reproducible-build comparison by SHA-256;
- persisted evidence bundle;
- evidence SHA-256.

A vulnerability with VEX state `not_affected`, `fixed`, or `resolved` does not count as unresolved for the CVSS gate. A SARIF finding with level `error` becomes a release-policy violation. Denied licenses always become policy violations.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-expansion software-supply-chain-evidence-platform \
  examples/frontier_expansion/supply_chain.json \
  build/results/supply-chain.json build/results/supply-chain-work
```

## 16. Qualification

Focused build and test:

```bash
cmake --build build/full --parallel "$(nproc)" --target \
  frontier_expansion_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/full --output-on-failure \
  -R 'frontier_expansion_(platform_unit_tests|source_regression|cli_regression)'
```

The unit test exercises direct C++ APIs and the platform-level self-test. The CLI regression validates command dispatch, capability enumeration, solver qualification, physical-layer encoding, and the all-domain self-test. The source regression verifies that public headers, implementation sources, CMake registration, CLI registration, documentation, and all fourteen executable JSON examples remain in the source package and contain no unfinished implementation markers.

## 17. Examples

All fourteen domains have executable requests under `examples/frontier_expansion/`:

```text
safe_rl.json
asam_cmp.json
traffic_participants.json
sysml_repository.json
scientific_stream.json
modern_mpi.json
qualified_solvers.json
sensor_bus.json
material_assets.json
particle_multiphysics.json
lubricant_condition.json
tire_acoustic.json
hazop_bowtie.json
supply_chain.json
```

The example set is parsed by the source regression. Each request can be passed directly to the `frontier-expansion` dispatcher.

## 18. Capability-dependent native backends

Two implementations have compile-time native acceleration paths:

- MPI transport: enabled when `MPI_CXX_FOUND` is true; MPI-4-specific APIs are compiled only for MPI 4 or newer.
- HIP particle execution: enabled only when the CMake HIP capability probe succeeds.

Their host implementations are not mock objects and are not disabled when the optional toolchains are absent. Capability results always disclose which native backend is active.

## 19. Evidence and deterministic behavior

The implementation follows the same general evidence discipline used by the rest of MuzixDiagSys:

- explicit input validation;
- rejection of non-finite numerical inputs where applicable;
- deterministic seeded stochastic behavior;
- deterministic JSON serialization for hashes;
- CRC or SHA-256 integrity on persistent artifacts;
- explicit capability reporting instead of hidden fallback claims;
- independent residual verification for externally supplied numerical results;
- additive CLI/API integration with no removal of prior features.

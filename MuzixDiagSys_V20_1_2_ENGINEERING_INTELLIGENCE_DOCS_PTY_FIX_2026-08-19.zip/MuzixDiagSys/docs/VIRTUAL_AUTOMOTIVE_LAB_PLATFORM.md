# MuzixDiagSys Virtual Automotive Laboratory

## Scope

The automotive laboratory is a software-only engineering layer reachable through:

```text
industrial vehicle experience lab ...
```

It does not replace the existing vehicle, lifecycle, accuracy, workshop, replay, or industrial systems. It composes them into a repeatable development workflow.

## Vehicle builder

Load the central component catalog, create a build, install one component per category, validate the interfaces and export the resulting build:

```text
industrial vehicle experience lab builder catalog data/lab/component_catalog.yaml
industrial vehicle experience lab builder new track_car
industrial vehicle experience lab builder install chassis_compact_rwd
industrial vehicle experience lab builder install engine_i4_20t
industrial vehicle experience lab builder install transmission_manual6_small
industrial vehicle experience lab builder install final_drive_lsd_373
industrial vehicle experience lab builder install brakes_sport_4p
industrial vehicle experience lab builder install tires_sport_245
industrial vehicle experience lab builder install radiator_95kw
industrial vehicle experience lab builder validate
industrial vehicle experience lab builder export track_car.yaml
```

Validation checks required categories, explicit conflicts, torque capacity, mechanical interfaces, high-voltage compatibility, cooling margin, and essential vehicle systems. Derived mass, cost, power, and wheel torque are recalculated after every change.

## Tuning workshop

```text
industrial vehicle experience lab tuning set boost_multiplier 1.20
industrial vehicle experience lab tuning set line_pressure 1.08
industrial vehicle experience lab tuning export track_calibration.yaml
```

Tuning values are constrained to validated ranges. Each modification records reliability and emissions multipliers so performance changes cannot silently ignore durability or environmental consequences.

## Test laboratories

```text
industrial vehicle experience lab dyno engine 1000 7000 250
industrial vehicle experience lab dyno chassis 20 200 10
industrial vehicle experience lab dyno transmission 380 200
industrial vehicle experience lab dyno battery 150 900
industrial vehicle experience lab dyno export result.csv
```

The engine bench generates torque, power, efficiency, temperature and energy-rate curves. The chassis dynamometer includes mass, road load and driveline efficiency. The transmission bench resolves repeated shift fill/slip/thermal behavior. The battery bench integrates current, heat and state of charge.

## AI test engineer and mechanic

```text
industrial vehicle experience lab engineer investigate cold 3-4 shift flare
industrial vehicle experience lab mechanic investigate intermittent power loss
```

Recommendations are deterministic and evidence-based. They identify a test matrix, rationale, required channels and configuration blockers.

## Telemetry and replay studio

```text
industrial vehicle experience lab telemetry import data/lab/telemetry_reference.csv
industrial vehicle experience lab telemetry seek 3.0
industrial vehicle experience lab telemetry frame
industrial vehicle experience lab telemetry plot engine_rpm.svg engine_rpm
industrial vehicle experience lab telemetry cinematic replay.yaml
```

The studio validates sorted timestamps, supports deterministic seek/step operations, exports engineering SVG traces and produces a complete cinematic camera/overlay script.

## Crash reconstruction

```text
industrial vehicle experience lab forensics solve 1600 1400 22 0.72 18 0.48 500 4 0.05 77
industrial vehicle experience lab forensics export reconstruction.md
```

The solver combines braking distance, road friction, crush energy, mass ratio and impact geometry. Monte Carlo propagation produces a 95% delta-v interval instead of a falsely exact answer.

## World and mission generation

```text
industrial vehicle experience lab world generate mountain 20 15 42
industrial vehicle experience lab world mission economy 99
industrial vehicle experience lab world export-world mountain_world.yaml
industrial vehicle experience lab world export-mission economy_mission.yaml
```

Generated worlds contain connected road nodes and edges. Missions contain routes, objectives, deterministic seeds and measurable safety/energy constraints.

## Manufacturing variation

```text
industrial vehicle experience lab manufacturing build unit_0001 1234 0.025 0.10
industrial vehicle experience lab manufacturing export unit_0001.json
```

Each manufactured vehicle receives correlated physical variation across compression, injector flow, bearing clearance, turbo efficiency, backlash, friction, tire stiffness, battery capacity and sensor scale. Assembly defects and a quality score are generated from the same deterministic seed.

## Teardown analysis

```text
industrial vehicle experience lab teardown inspect clutch 0.62 0.41 P0730
industrial vehicle experience lab teardown export teardown.md
```

Findings connect wear and damage levels to visible observations, probable causes, severity and confidence.

## Plugin/modding SDK

See `docs/sdk/MUZIXDIAGSYS_MODDING_SDK.md`. The SDK command validates manifests, registers plugins, exports the registry and creates a complete compilable ABI-v2 project.

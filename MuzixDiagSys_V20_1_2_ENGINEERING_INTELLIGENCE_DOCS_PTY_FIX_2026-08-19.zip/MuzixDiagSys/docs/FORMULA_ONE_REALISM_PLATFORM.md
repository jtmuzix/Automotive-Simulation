# Formula One Integrated Realism Platform

## Purpose

The Formula One integrated realism platform adds ten production simulation services that connect geometry, tyre construction, circuit environment, vehicle damage, human response, wheel-end mechanics, telemetry physics, tyre pedigree, strategy, and wind-tunnel correlation. All public quantities use SI units and stochastic paths are deterministic for identical seeds and inputs.

## Public include

```cpp
#include "aesim/advanced/formula_one_realism_platform.hpp"
```

The header is also exported through `aesim/advanced/formula_one_platform.hpp`.

## Implemented APIs

- `F1SuspensionGeometryTwin`: hardpoint-based double-wishbone K&C, steering, compliance, roll-center, trail, scrub, caster, KPI, jacking, motion-ratio, Ackermann, and travel sweeps.
- `F1FlexibleRingTyreModel`: flexible belt ring, distributed tread bristles, Prony/WLF viscoelasticity, thermal state, wear, distributed pressure and shear, aquaplaning, and water-film contact.
- `F1CircuitMicroclimatePlatform`: spatial wind, air and surface temperature, humidity, shallow water, drainage, rubber, marbles, sharp debris, oil, spray, grip, visibility, and puncture risk.
- `F1DamageAwareVehicleTwin`: component damage accumulation, aero/cooling/alignment/reliability consequences, safe-to-continue assessment, and repair optimization.
- `F1DriverHumanDynamics`: gaze, visual uncertainty, vestibular dynamics, motion-cue conflict, neuromuscular activation, fatigue, workload, dehydration, steering, brake, and throttle response.
- `F1WheelEndDrivelineModel`: bearings, hub and rim compliance, bead slip and leakage, torsional shafts, backlash, gear mesh, dog engagement, hydraulic shift actuation, damage, and delivered wheel torque.
- `F1TracksideRfTelemetryTwin`: free-space and reflected propagation, antenna gains, rain loss, polarization, Doppler, interference, receiver noise, packet errors, handover, latency, and EMC-induced sensor error.
- `F1TyrePedigreeDigitalThread`: serialized production and lifecycle records, tyre-specific parameter distributions and covariance, failure probability, and balanced set allocation.
- `F1CounterfactualRaceEngineer`: scenario-weighted Monte Carlo counterfactuals, expected points, CVaR, regret, failure probability, value of information, and recommendation confidence.
- `F1WindTunnelFacilityTwin`: blockage, wall interference, rolling-road mismatch, belt boundary layer, support drag, flow angularity, model deformation, balance cross-talk/noise, uncertainty covariance, and yaw sweeps.

## Integrated workflow

1. Solve hardpoint K&C for the requested ride, steering, and wheel loads.
2. Feed corner geometry and compliance into the flexible-ring tyre model.
3. Query spatial grip, water, debris, wind, and visibility from the circuit twin.
4. Propagate component incidents through the damage-aware vehicle state.
5. Apply visibility, motion cues, heat, workload, and feedback torque to the driver model.
6. Propagate driver torque and shift commands through wheel-end/driveline dynamics.
7. Transmit simulated telemetry through the physical RF/EMC channel.
8. Use serialized tyre pedigree distributions for calibration and set selection.
9. Evaluate strategic actions over the current probabilistic belief state.
10. Correlate aero predictions against facility-corrected virtual tunnel measurements.

## Qualification requirements

- Survey and validate suspension hardpoints and coordinate conventions.
- Calibrate tyre ring, bristle, thermal, viscoelastic, and water-contact parameters against rig data.
- Perform spatial and time-step convergence for circuit water, spray, and contaminant fields.
- Validate damage-to-performance maps with structural and aerodynamic evidence.
- Calibrate human parameters against driver-in-the-loop or measured response data.
- Correlate gearbox, wheel-end, bearing, and bead models against component rigs.
- Survey receiver sites, antenna patterns, interference, and propagation conditions.
- Trace tyre production data to measured set performance before operational use.
- Validate race outcome priors and utility choices on withheld events.
- Validate wind-tunnel facility corrections with reference models and independent instrumentation.

## Focused build and test

```bash
cmake -S . -B build/f1-realism -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF -DAESIM_MAX_PARALLEL_COMPILES=2
cmake --build build/f1-realism --parallel 2 --target formula_one_realism_platform_tests
ctest --test-dir build/f1-realism --output-on-failure \
  -R '^formula_one_realism_(platform_unit_tests|source_regression)$'
python3 tests/formula_one_realism_source_regression.py .
```

## Downstream integrated operations extension

The additive `formula_one_integrated_operations_platform.hpp` layer extends the
realism platform into spatial pit and garage execution, occupant safety,
communication semantics, trackside recovery, optical spray visibility,
three-dimensional carbon-brake behavior, active-aero mechatronics,
sustainable-fuel and turbo dynamics, switching ERS/EMC, and Bayesian
CFD-tunnel-track fusion. See `FORMULA_ONE_INTEGRATED_OPERATIONS_PLATFORM.md`.

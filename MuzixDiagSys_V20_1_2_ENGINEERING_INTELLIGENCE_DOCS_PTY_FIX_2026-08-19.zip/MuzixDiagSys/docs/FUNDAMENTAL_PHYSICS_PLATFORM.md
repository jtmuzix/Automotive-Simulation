# Fundamental Physics and Runtime Credibility Platform

## Scope

This subsystem provides ten reusable numerical and credibility capabilities:

1. entropy-consistent thermodynamic coupling;
2. geometrically nonlinear beam, shell, cable, and membrane networks;
3. reactive surface chemistry with bounded site occupancy;
4. rarefied-gas transport with slip and temperature-jump reporting;
5. conserved and nonconserved phase-field evolution;
6. coupled fluid-structure-acoustic wave propagation;
7. proper-orthogonal-decomposition reduced-order modeling;
8. continuous model-validity supervision;
9. cost-constrained D-optimal sensor placement; and
10. causal discrepancy localization over validated acyclic graphs.

All public quantities use SI units. Include:

```cpp
#include "aesim/advanced/fundamental_physics_platform.hpp"
```

## Build architecture

The implementation is compiled into the focused `aesim_fundamental_physics`
static library. `aesim_advanced` links that library publicly, so existing users
of the complete advanced platform retain the same feature surface. The focused
library prevents this module's tests from compiling and linking every unrelated
advanced subsystem.

```bash
cmake -S . -B build/fundamental \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON
cmake --build build/fundamental \
  --target fundamental_physics_platform_tests -j
ctest --test-dir build/fundamental --output-on-failure \
  -R '^fundamental_physics_platform_(unit_tests|source_regression)$'
```

Memory and undefined-behavior qualification:

```bash
CC=clang CXX=clang++ cmake -S . -B build/fundamental-sanitize \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON
cmake --build build/fundamental-sanitize \
  --target fundamental_physics_platform_tests -j
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=print_stacktrace=1 \
  ctest --test-dir build/fundamental-sanitize --output-on-failure \
  -R '^fundamental_physics_platform_(unit_tests|source_regression)$'
```

## Numerical contracts

Every configuration and runtime entry point rejects non-finite values and
physically invalid dimensions before numerical work begins. Dimension mismatch,
invalid graph topology, nonpositive material properties, impossible grids, and
unstable explicit time steps produce deterministic exceptions rather than
undefined behavior or silent non-finite output.

Explicit transport, phase-field, and coupled-wave integrations automatically
subcycle to a conservative stability limit. A hard upper bound prevents a
single request from expanding into an unbounded amount of work.

## Thermodynamic coupling

`EntropyConsistentCoupling` audits mass, energy, entropy, and exergy using
long-double accumulation and checked conversion back to the public `double`
interface. Port temperatures must be positive. Species mass fractions, when
provided, must be finite, bounded, and normalized. Chemical-potential vectors
must match the species dimension.

The sign convention is positive flow into the audited control volume. The
first-law result requires both mass and energy residuals to satisfy their
specified tolerances. The second-law result uses a scale-aware tolerance for
floating-point roundoff.

## Nonlinear structural mechanics

`GeometricallyExactStructureSolver` validates every element index and rejects
zero-length or repeated-node elements before solving. Shell and membrane
polygons are represented by their perimeter segments; beams and cables use the
first-to-last segment. Cable compression is suppressed.

The solver precomputes segment reference geometry and diagonal tangent
stiffness once per solve. This removes repeated element searches and temporary
edge construction from every nonlinear iteration. Reports include convergence,
iteration count, residual norm, strain energy, and a conservative minimum
diagonal tangent measure.

## Reactive surface chemistry

`ReactiveSurfaceChemistry` evaluates Arrhenius rates in logarithmic form to
avoid overflow and underflow. Stoichiometric coefficients, site density,
activities, temperature, and time step are validated. Coverage updates are
limited by available reactant coverage, and occupied sites are normalized when
floating-point accumulation would otherwise exceed unity.

The report exposes total forward rate, heat release, species coverage, and site
balance error. Vacant sites are permitted; therefore total coverage may be less
than one.

## Rarefied-gas transport

`RarefiedGasTransportSolver` computes mean free path, Knudsen number, slip
velocity, temperature jump, density, velocity, temperature, unit-area mass flow,
and conductive heat flux. Spatial updates use separate previous and next
buffers, removing the order dependence of in-place finite-difference updates.
Automatic subcycling enforces the explicit diffusion stability limit.

The `particles` and `seed` fields remain part of the public configuration for
compatibility with kinetic extensions. The current deterministic continuum-
kinetic bridge does not inject sampling noise.

## Phase-field evolution

`GeneralizedPhaseFieldSolver` supports Allen-Cahn and Cahn-Hilliard forms. The
solver derives a stability bound from mobility, grid spacing, double-well
curvature, and gradient energy, then subcycles as required. Conserved evolution
applies a global roundoff correction after each substep so total order-parameter
mass remains invariant to numerical precision.

Periodic boundaries are used in both directions. Reports contain free energy,
mass, interface measure, and the complete order-parameter field.

## Fluid-structure-acoustic coupling

`FluidStructureAcousticWaveSolver` uses a coupled explicit wave update with a
Courant limit based on both acoustic and structural wave speeds. The interface
pressure boundary retains the incoming acoustic characteristic and subtracts
the structure-velocity impedance term. This prevents the former behavior in
which the boundary was overwritten before the pressure wave could load the
structure.

State time is continuous across repeated `advance` calls. Reports include the
pressure and displacement fields, interface power, maximum amplitudes, and
nonnegative acoustic and structural energy measures.

## Certified reduced-order modeling

`CertifiedReducedOrderModel` now builds a POD basis using the method of
snapshots and a symmetric Jacobi eigensolver. Snapshot matrices must be finite,
rectangular, and dynamically nondegenerate. The full operator must be square and
match the trained state dimension.

The reduced operator includes the affine drift caused by the snapshot mean.
State advancement uses fourth-order Runge-Kutta integration. The runtime report
contains reconstructed state, projected full-order residual, residual-based
error bound, retained snapshot-energy fraction, and certification status.

## Runtime validity supervision

`ModelValiditySupervisor` requires strictly positive thresholds and evaluates
absolute normalized magnitudes for every signal, including calibration
distance. Non-finite input is rejected. Credibility and inadequacy probability
are derived from the worst normalized excursion, and invalid assessments return
explicit mitigation actions.

## D-optimal sensor placement

`OptimalSensorPlacement` validates unique identifiers, dimensions, variance,
cost, and budget. Selection uses the matrix-determinant lemma with a Cholesky
solve to compute the actual incremental log-determinant gain. The greedy utility
is gain per unit cost, with deterministic tie breaking. The final condition
number is computed from the symmetric information-matrix eigenvalues rather
than diagonal ratios.

## Causal discrepancy localization

`CausalDiscrepancyLocalizer` validates unique nodes, known parents, positive
uncertainty, and acyclic topology during graph installation. Localization finds
the first significant node in declared execution order, propagates attenuated
influence upstream, ranks causes deterministically, and constructs a root-to-
divergence path using the strongest upstream evidence.

## Qualification boundary

These APIs are executable numerical implementations, not substitutes for model
qualification. Quantitative deployment still requires calibrated constitutive,
chemical, molecular, acoustic, sensor, and uncertainty data; mesh and time-step
convergence evidence; uncertainty accounting; and independent verification and
validation over the intended operating envelope.

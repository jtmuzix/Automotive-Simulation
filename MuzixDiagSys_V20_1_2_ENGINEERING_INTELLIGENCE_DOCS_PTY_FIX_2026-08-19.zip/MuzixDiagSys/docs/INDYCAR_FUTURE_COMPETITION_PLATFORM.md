# IndyCar Future Competition and Development Platform

## Purpose

`aesim/advanced/indycar_future_competition_platform.hpp` adds ten production-grade IndyCar engineering systems to the existing IR-18 and entrant-operations platforms. The module is additive: it does not replace the current-car rules, oval physics, hybrid, Firestone strategy, refueling, power-unit, inspection, telemetry, crash-recovery, pit-crew, or street-circuit laboratories.

Every public input validates finite values and physical ranges. Deterministic workflows emit SHA-256 evidence identifiers that bind the principal configuration and result state. These hashes provide content integrity, not digital signatures.

## 1. 2028 next-generation design, homologation, and transition

`IndyCarNextGenerationLaboratory` compares a current vehicle generation with a candidate design. It calculates mass, road-course and speedway performance trends, wake recovery, crash/load margins, supplier-rate-constrained production, team training, conversion cost, programme budget, and a month-by-month transition schedule.

Homologation cases jointly evaluate absorbed energy, peak force, survival-cell intrusion, deceleration, and electrical isolation. A candidate cannot qualify without an integrated aeroscreen and non-regressing roll-hoop capacity.

## 2. Championship, charter, Leaders Circle, and entrant economics

`IndyCarChampionshipEconomicsPlatform` evaluates driver, entrant, and manufacturer points together with event prize value, sponsorship value, development spending, crash exposure, charter acquisition/amortization, and Leaders Circle eligibility. It chooses a bounded risk setting for every event and ranks eligible chartered entries for the configured Leaders Circle cutoff.

## 3. Official timing, scoring, photo finish, and stewarding

`IndyCarOfficialTimingStewardingEngine` reconstructs official classification from synchronized loop hits. It rejects weak and duplicate readings, counts completed laps, applies time/position/drive-through/stop-and-hold/disqualification decisions, and invokes calibrated photo-finish observations when the timing gap is below the configured threshold.

Steward incidents include avoidable contact, blocking, restart, pit-lane, local-yellow, qualifying-interference, and unsafe-release cases. Decision severity reflects responsibility and mitigating circumstances.

## 4. Firestone structural tyre and oval failure mechanisms

`IndyCarStructuralTyreLaboratory` resolves layered tread, belt, carcass, liner, sidewall, or bead definitions. It calculates radial stiffness, contact area, pressure growth, tread/carcass/shoulder temperatures, belt-edge stress, viscoelastic heating, seam-impact loading, Miner-style fatigue damage, belt-separation probability, minimum cold pressure, and safe stint duration.

## 5. Fuel-cell slosh, collector, pickup, and mass migration

`IndyCarFuelCellSloshLaboratory` models the flexible-cell main volume, baffle response, collector volume, lift pump, high-pressure pump, pickup coverage, fuel-temperature vapour penalty, supply pressure, starvation, fuel centroid, vehicle CG migration, and yaw-inertia changes. It reports minimum safe reserve and unusable residual fuel.

## 6. Trackside safety, rescue, medical, repair, and restart readiness

`IndyCarTracksideSafetyTwin` schedules the fastest available safety, fire, ambulance, extrication, recovery, barrier, and helicopter resources. It calculates fire/electrical isolation, extraction, medical stabilization, vehicle recovery, debris removal, barrier/surface repair, red-flag need, residual risk, and earliest safe restart.

## 7. IRIS rulebook, bulletin, and regulation-change compiler

`IndyCarIRISRuleCompiler` converts deterministic rule statements into typed executable rules. Supported directives are:

```text
RULE <id> SCOPE <scope> PARAM <parameter> <MIN|MAX|EQ|PROHIBITED|REQUIRED> <value> <unit> SEVERITY <ADVISORY|SPORTING|TECHNICAL>
OVERRIDE <id> SCOPE <scope> PARAM <parameter> <operator> <value> <unit> SEVERITY <severity>
REPEAL <id>
```

Documents are applied by priority, effective date, and identity. The compiler reports diagnostics, added/modified/removed rules, affected simulator modules, a generated profile identity, and a deterministic evidence digest. Activation remains subject to engineering approval; the compiler does not claim to replace official interpretation.

## 8. Suspension K&C, dampers, steering, and seven-post correlation

`IndyCarSuspensionRigLaboratory` combines suspension geometry, camber/toe/bump-steer gains, motion ratios, steering ratio, nonlinear compression/rebound damper curves, gas force, seal friction, road-post inputs, aero posts, and steering-rack motion. It integrates heave and pitch, calculates damper forces and steering torque, compares measured heave/pitch, and reports RMSE and identified compliance.

## 9. Multi-car team strategy and racecraft

`IndyCarMultiCarStrategyEngine` performs an exact enumeration of candidate strategies for up to four team cars. Deterministic Monte Carlo scenarios account for cautions, traffic/tow benefit, fuel saving, aggression, hybrid reserve, push-to-pass reserve, pit loss, shared pit-box conflicts, crash exposure, championship weighting, expected team points, cost, and win probability.

## 10. Aero-kit development and regulated test facilities

`IndyCarAeroDevelopmentLaboratory` selects wind-tunnel and straight-line activities under test-day, wind-on, cost, maximum-test, approval, and blackout constraints. It applies Reynolds and blockage corrections, Bayesian variance reduction, corrected lift/drag/balance estimates, information gain, and a recommended variant.

## Build and validation

```bash
cmake --build build/relwithdebinfo --target \
  indycar_future_competition_platform_tests --parallel "$(nproc)"

ctest --test-dir build/relwithdebinfo --output-on-failure \
  -R '^indycar_future_competition_platform_unit_tests$'
```

Run every IndyCar test:

```bash
ctest --test-dir build/relwithdebinfo --output-on-failure \
  -R '^indycar_.*_unit_tests$'
```

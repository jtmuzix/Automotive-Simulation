# MuzixDiagSys Research Integration Platform

The `aesim::research2` subsystem provides the second-generation research and
external-physics integration layer. It is additive: none of the existing engine,
vehicle, HIL, AUTOSAR, FMI/SSP, assurance, electrification, or frontier services
are disabled when the subsystem is unused.

## Build

The standard build has no mandatory preCICE, Protocol Buffers, libbpf, or
OpenTelemetry SDK dependency. The core implementations remain available in a
normal C++17 build:

```bash
cmake -G Ninja -S . -B build \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

A real preCICE installation is consumed dynamically through its stable C API.
Pass the path of `libprecice.so` to `PreCiceParticipant`, or leave the path empty
when it is available through the dynamic loader search path.

## Partitioned multiphysics coupling

`PartitionedCoupler` composes arbitrary implementations of
`CouplingParticipant`. Included participant implementations are:

- `LinearPhysicsParticipant`, used for deterministic reference and regression
  models.
- `PreCiceParticipant`, a runtime adapter for the preCICE C API.

Supported coupling schemes are explicit Jacobi, explicit Gauss-Seidel, implicit rollback iteration with bounded Aitken relaxation, waveform Jacobi, and waveform Gauss-Seidel. Implicit iterations
save each participant state, restore it before every trial, advance each solver,
calculate interface residuals, and continue until the declared convergence
criterion is satisfied.

The preCICE adapter performs participant creation, mesh vertex registration,
initial-data exchange, data writes, time advancement, and data reads. It checks
mesh and data dimensions and enforces the maximum time step reported by the
runtime.

Terminal demonstration:

```text
industrial research2 coupling demo 0.01
```

Programmatic integration permits CFD, FEA, thermal, electromagnetic, battery,
and acoustic solvers to provide their own `CouplingParticipant` implementation
or use the preCICE runtime adapter.

## Native OSI protobuf profile

`OsiProtobufCodec` emits and consumes native Protocol Buffers wire data for the
represented OSI 3.x `GroundTruth` fields. No JSON envelope is inserted into the
binary record. The supported wire-compatible profile includes:

- `InterfaceVersion`
- `Timestamp`
- `Identifier`
- `GroundTruth.host_vehicle_id`
- repeated `MovingObject`
- `BaseMoving` dimension, position, orientation, velocity, and acceleration
- country code, projection string, and map reference

The profile schema is provided at:

```text
schemas/osi3/aesim_osi_groundtruth_profile.proto
```

Length-prefixed `.osi` traces can contain multiple GroundTruth records:

```text
industrial research2 osi generate ground_truth.osi
industrial research2 osi validate ground_truth.osi
```

Conformance checks reject duplicate and reserved IDs, invalid timestamps,
unknown object types, negative dimensions, non-finite state, and host IDs that
do not reference a moving object.

## Online digital-twin estimation

Three independent estimators share typed process and measurement functions:

- Extended Kalman filter with numerical process and measurement Jacobians.
- Seeded particle filter with Gaussian process noise, normalized likelihoods,
  effective sample size, and systematic resampling.
- Moving-horizon estimator with an arrival prior, bounded measurement window,
  weighted batch residuals, Gauss-Newton updates, and horizon-sliding prior
  propagation.

```text
industrial research2 estimate demo
```

The C++ API accepts arbitrary state, input, and measurement vectors and can be
fed by XCP, MDF, ODS, ROS/DDS, VISS, HIL, or replayed experiment data.

## Multi-fidelity Bayesian calibration

`MultiFidelityBayesianCalibrator` implements bounded random-walk MCMC over model
parameters and optional structural-discrepancy hyperparameters. The likelihood
uses measurement variance plus a squared-exponential discrepancy covariance.
Cross-fidelity covariance is attenuated when observations come from different
fidelity levels.

Outputs include posterior samples, means, standard deviations, 2.5/50/97.5
percentiles, acceptance rate, discrepancy amplitude, and discrepancy length.

```text
industrial research2 bayes demo posterior.json
```

## Hybrid-system reachability

`HybridReachabilityAnalyzer` propagates interval boxes through affine continuous
modes, guards, resets, invariants, disturbances, and discrete mode transitions.
The result contains all retained reachable boxes and, when an unsafe set is
intersected, a deterministic counterexample with time, mode, mode path, and a
representative state.

```text
industrial research2 reach demo counterexample.json
```

The counterexample is directly usable as an input to scenario/checkpoint/replay
workflows or as digital-thread evidence.

## Governed surrogates and reduced-order models

The platform implements:

- Degree 1–3 multivariate polynomial regression with ridge stabilization.
- Validation metrics: RMSE, MAE, maximum error, and R².
- Proper orthogonal decomposition through covariance eigenvectors.
- Reduced-state encode/decode and reconstruction-error evaluation.
- Approval states and validation thresholds.
- Hashes for source model, training data, and validation data.
- Approved operating domains and explicit extrapolation policy.
- Persistent registry serialization.

```text
industrial research2 surrogate demo surrogate-registry
```

A model in `experimental` or `withdrawn` state cannot execute. Inputs outside an
approved domain are rejected unless the approval record explicitly permits
extrapolation.

## Deterministic numerical profiles

The deterministic profile controls rounding, x86 flush-to-zero and
denormals-are-zero flags, reduction order, random seed, and environment
recording. Stable reductions use magnitude-ordered Neumaier compensation.

Comparison levels are statistical, tolerance-based, platform, and bitwise.

```text
industrial research2 numerics status
industrial research2 numerics strict 1234
industrial research2 numerics compare reference.txt candidate.txt
```

## OpenTelemetry and eBPF

`OpenTelemetryTracer` records trace IDs, span IDs, parent relationships,
nanosecond timestamps, attributes, and status, then exports the OTLP JSON
structure with resource and instrumentation-scope metadata.

```text
industrial research2 observe span simulation.step
industrial research2 observe export traces.otlp.json
```

On Linux, `EbpfSchedulerProfiler` loads an actual raw-tracepoint eBPF program for
`sched_switch`, stores a 64-bit event counter in a BPF array map, attaches it,
and reads the counter through the `bpf()` system call. Systems without the
required kernel permissions return an explicit diagnostic rather than a false
success.

```text
industrial research2 observe ebpf-start
industrial research2 observe ebpf-read
industrial research2 observe ebpf-stop
```

## SBOM and signed provenance

`SupplyChainAttestor` creates:

- CycloneDX 1.6 JSON component inventories.
- An in-toto/SLSA-style provenance statement.
- Ed25519 private/public key pairs.
- Detached signatures and signature verification.

```text
industrial research2 attest generate attestation-directory ./build/muzixdiagsys
industrial research2 attest verify \
  attestation-directory/sbom.cdx.json \
  attestation-directory/attestation-public.pem \
  attestation-directory/sbom.cdx.json.sig
```

The private key is generated only for the local demonstration. Production use
should supply a protected organizational signing key or HSM-backed signer.

## Tests

The dedicated test suite verifies:

- Dynamic preCICE C-API linkage and data exchange through a separately built
  shared library.
- Nontrivial implicit coupling convergence.
- Independent OSI wire encode/decode and trace persistence.
- EKF, particle-filter, and moving-horizon convergence.
- Multi-fidelity Bayesian posterior recovery.
- Unsafe-set discovery and counterexample persistence.
- Surrogate validation, approval, domain rejection, persistence, and POD.
- Stable numerical reductions and reproducibility comparisons.
- OTLP structure, eBPF success-or-explicit-diagnostic behavior, CycloneDX,
  provenance, Ed25519 verification, and tamper rejection.

## 2026-07-12 next-generation vehicle-depth integration

The research integration layer can use deterministic depth checkpoints, branch-specific counterfactuals, and state-conserving fidelity selection for DOE and uncertainty studies.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


## V17 waveform relaxation and power-conservative bonds

`WaveformJacobi`/`WaveformGaussSeidel` iterate complete substep waveforms with snapshot rollback and bounded relaxation. `PowerBondConnection` uses `e_B=n*e_A`, `f_A=-n*f_B` and reports interface power residuals; existing coupling schemes remain available.

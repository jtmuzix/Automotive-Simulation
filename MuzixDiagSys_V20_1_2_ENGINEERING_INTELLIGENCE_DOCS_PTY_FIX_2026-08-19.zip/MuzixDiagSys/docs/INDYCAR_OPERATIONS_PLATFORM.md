# IndyCar Operations, Compliance, and Human Performance Platform

## Scope

`aesim/advanced/indycar_operations_platform.hpp` extends the existing IR-18,
oval dynamics, pack-aerodynamics, hybrid, tyre, qualification, race-control,
and power-pool platform with ten production-oriented entrant systems. All
models reject malformed and non-finite inputs, preserve deterministic output
for fixed inputs and seeds, and emit SHA-256 evidence identifiers.

## 1. Fuel allotment and pit-stop safety

The fuel twin calculates the event allotment from scheduled distance and the
applicable mileage equivalency, then limits the stop by onboard capacity, pit
tank inventory, and remaining event allocation. Gravity flow is calculated
from hydrostatic head, density, hose area, dry-break area, vent area,
discharge coefficient, temperature-dependent density, line viscosity, tank
head, and receiver backpressure. It explicitly models probe/vent engagement,
leakage, spills, grounding, fire equipment, emergency shutoff, tyre-service
interference, and release-before-disconnect.

Conservation is enforced between pit-tank withdrawal, onboard retention, and
spill volume. The result reports a time history, delivered quantity, stop time,
fire probability, procedural violations, and safe-release status.

## 2. Renewable-ethanol twin-turbo V6

The V6 laboratory resolves air flow, pressure ratio, lambda, renewable-ethanol
fuel flow, indicated efficiency, friction, crank torque and power, turbo spool,
exhaust temperature, coolant temperature, and oil temperature. Twin turbo
shaft states use distinct inertias and first-order exhaust-energy response.
Cooling depends on vehicle speed, pack airflow, radiator conductance, and oil
cooler conductance.

Damage accumulates from knock, turbo overspeed, coolant/oil temperature, and
exhaust temperature. The output includes delivered energy, fuel consumption,
peak states, remaining-life fraction, histories, and qualification violations.

## 3. Aeroscreen, visibility, and impact

The aeroscreen model combines polycarbonate optics, haze, water film,
contamination, tear-off removal, fogging, anti-fog heating, inlet and exit flow,
helmet airflow, cockpit heat load, solar load, and driver heat strain. Debris
impacts resolve normal kinetic energy, contact stress, frame load sharing,
polycarbonate energy absorption, and titanium-frame stress.

Qualification gates cover minimum visibility, cockpit thermal state, driver
heat strain, frame yield, and penetration margin.

## 4. Spotter and oval situational awareness

Traffic observations are translated into inside, outside, still-there,
three-wide, clear, check-up, wreck-ahead, pit, and blend calls. Deterministic
Monte Carlo sampling models perception failure, fatigue, experience, visual
conditions, radio interference, loss, latency, workload, and false-clear risk.
Results include delivered/lost calls, missed-hazard probability, false-clear
probability, avoided-contact probability, and operational qualification.

## 5. Technical inspection and aero metrology

The inspection laboratory registers calibrated instruments and applies
coverage-factor guard bands to dimensional measurements. It supports minimum,
maximum, range, and nominal-tolerance comparisons. Aero load tests include
elastic deflection, permanent set, and temperature correction. Approved parts
are checked by serial, approved/fitted part number, seal requirement, seal ID,
and seal integrity.

Every finding reports corrected value, expanded uncertainty, compliance margin,
and explanation. The complete inspection is content-bound by SHA-256.

## 6. Telemetry and locked calibration

The telemetry verifier validates software, calibration, and logger manifests;
locked parameter values; required channel identities; rates; continuity;
sequence numbers; duplicates; session bounds; and data completeness. Required
channels may be continuous and safety critical. Canonically sorted samples form
a dataset digest, which is bound into a separate compliance evidence digest.

## 7. Testing, ROP, refresher, and development allocation

The test optimizer supports team, open, manufacturer, Firestone, straight-line,
wind-tunnel, rookie, evaluation, and refresher activities. It enforces approval,
blackouts, eligible drivers, restricted-day equivalents, cost, tyres, fuel,
component mileage, and maximum selected tests. An exact bounded search maximizes
weather-weighted lap-time, reliability, and driver-learning value.

ROP speed phases and selected rookie/refresher tests determine driver completion
status. Invalid or unavailable activities are never selected.

## 8. Primary/backup car crash recovery

Damage is resolved by zone, severity, safety relevance, trackside repairability,
repair hours, and cost. The manager chooses primary repair, corner replacement,
floor replacement, engine/hybrid change, backup substitution, or retirement.
It enforces available time, labor, cost, impound approval, backup readiness,
post-qualifying consequences, reinspection, and late-race repaired-car return
restrictions.

## 9. Seven-person pit crew and wheel-gun mechanics

The pit model requires four tyre changers, an air-jack operator, fueler, and
aeroscreen attendant. Each crew member has reaction, skill, fatigue, and error
properties. Wheel service resolves socket alignment, cross-thread probability,
impact-gun torque, thread efficiency, clamp force, seating confidence, and
completion time. Fuel and aeroscreen tasks execute concurrently with wheel
service after the car is raised.

The result reports stop time, delivered fuel, wheel-specific results,
equipment-failure probability, crew-injury probability, unsafe-release
probability, incidents, and safe-release qualification.

## 10. Street-circuit bump, wall, steering, and brakes

Street segments include curvature, camber, friction, bumps, concrete, paint,
water, walls, and braking duty. The wheel/suspension state uses an implicit
integration step suitable for stiff unsprung dynamics. Outputs include steering
torque without power assistance, rack load, wheel vertical acceleration, floor
clearance, disc temperature, fade, wall contact energy, and complete state
history.

Qualification gates cover steering effort, brake temperature, floor clearance,
wall contact, and structural wheel acceleration.

## Numerical and evidence behavior

- Every public input type validates finite values and physical ranges.
- Time-ordered data is explicitly checked where required.
- Stochastic models accept explicit seeds and are reproducible.
- Fuel transfer accounts for retained and spilled volume.
- Stiff street-circuit suspension dynamics use implicit integration.
- SHA-256 evidence identifies the principal input/output state of each run.
- Hashes are integrity identifiers, not signatures or remote attestation.

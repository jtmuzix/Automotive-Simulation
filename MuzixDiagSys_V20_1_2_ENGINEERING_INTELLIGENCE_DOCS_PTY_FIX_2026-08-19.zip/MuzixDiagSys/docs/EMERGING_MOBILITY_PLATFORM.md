# Emerging Mobility Platform

The advanced CLI now exposes ten deterministic laboratories:

```bash
muzixdiagsys_advanced_platform emerging capabilities [OUTPUT.json]
muzixdiagsys_advanced_platform emerging self-test DIRECTORY [OUTPUT.json]
muzixdiagsys_advanced_platform emerging DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The domains are `neural-world`, `cockpit`, `ar-hud`, `cabin-sensing`, `hydrogen-fueling`, `multigig-ethernet`, `v2x-r18`, `soafee-wasm`, `fpga-hil`, and `r157-r160-dssad`. Every request is range-validated, produces a deterministic JSON report, sets an engineering `passed` verdict, computes a canonical SHA-256 `evidence_digest`, and optionally persists a domain report in `WORKING_DIRECTORY`. A completed failing verdict exits 2; exceptions exit 1; usage errors exit 64.

## Implemented numerical and state models

- **Neural world:** confidence-weighted voxel seeding, Gaussian means, anisotropic covariance scales, RGB radiance, opacity, semantic voting, iterative residual refinement, RMSE, and PSNR.
- **Cockpit/AAOS twin:** boot/shutdown, application lifecycle, VHAL signals, CPU/memory admission, distraction blocking, stale-signal detection, crash/restart, and safety-display continuity.
- **AR-HUD:** field of view, eyebox coverage, wedge/thickness ghosting, ambient contrast, latency/yaw/parallax registration error, and threshold findings.
- **Cabin sensing:** bounded Bayesian/log-odds fusion for child/adult/pet/empty, breathing evidence, driver attention, locked-vehicle warning, and timed emergency escalation.
- **SAE J2601 fueling:** time-stepped hydrogen mass, pressure, temperature, compression heat, ambient transfer, pre-cooled inlet, pressure-ramp limiting, non-communication derating, and emergency shutdown.
- **Multi-gig Ethernet:** 2.5/5/10/25GBASE-T1 and 10G optical channel budgets, receive margin, SNR, raw/post-FEC BER, serialization/propagation, priority scheduling, and deadlines.
- **Release 18 V2X:** certificate validity/revocation, deterministic signature verification, message age, replay/sequence, acceleration/position plausibility, quarantine, and adjudication evidence.
- **SOAFEE/WASM:** signature, measured-boot, quota, capability, canary, and promotion gates plus a real bounded WebAssembly binary parser/interpreter for a validated `() -> i32` integer subset. Imports and unsupported opcodes fail explicitly.
- **FPGA-HIL:** signed Q-format quantization, saturation/overflow, PI control and plant execution, deterministic transport latency/dropout, floating reference equivalence, RMS/max error, and sample-rate metrics.
- **UN R157/R160/DSSAD:** ALKS lateral/TTC/transition/MRM checks, pre/post-event EDR retention and lock, and control-authority timeline evidence.

Run all ten:

```bash
./build/full/muzixdiagsys_advanced_platform emerging self-test \
  build/emerging-self-test build/emerging-self-test.json
ctest --test-dir build/full --output-on-failure \
  -R '^emerging_mobility_platform_unit_tests$'
```

Executable requests are in `examples/emerging_mobility/`. These are engineering and pre-conformance models, not substitutes for licensed normative standards, calibrated accredited testing, or regulatory approval.

# Next-Generation Vehicle Depth Validation

Revision: 2026-07-12

## Scope

This document records the completed verification evidence for the additive vehicle-depth extension. It covers compilation, subsystem behavior, runtime integration, deterministic replay, conservation observability, compatibility, sanitizers, documentation, and archive preparation.

## Verified test targets

- `vehicle_depth_unit_tests`: all ten added model domains and their coupled runtime.
- `electrification_platform_unit_tests`: direct industrial-platform facade, signal publication, terrain/fault commands, replay, fidelity changes, and AUTOSAR reporting.
- `electrification_platform_regression`: production-console execution through the final `muzixdiagsys` binary.
- `user_manual_regression`: manual/help/token/command-family/glossary consistency.
- Existing high-fidelity, vehicle, electrification, industrial, assurance, federation, frontier, research, plugin, FMU, PTY, terminal, regulatory-cycle, and OSI-wire tests: non-regression evidence.

## Acceptance criteria and results

| Criterion | Result |
|---|---|
| All new sources compile under the project warning policy | Passed |
| Complete release build, including console, libraries, plugins, FMU component, tools, and every test target | Passed |
| Complete CTest matrix on exact final binaries | **78/78 passed** |
| CTest elapsed time | 313.09 seconds |
| Structural, electrical, hydraulic, thermal, mechanical, and tire residuals remain finite | Passed |
| Open-phase fault leaves the failed conductor at zero current | Passed |
| Ground fault lowers isolation resistance and clears deterministically | Passed |
| Tire puncture lowers pressure and impact injection increases structural damage | Passed |
| Tire reset establishes a consistent thermodynamic energy datum | Passed |
| HV reset starts from completed precharge at actual pack voltage | Passed |
| HV nodes remain within the configured physical voltage envelope | Passed |
| AUTOSAR execution overrun generates deadline misses | Passed |
| Checkpoint restore reconstructs recorded time and state | Passed |
| Counterfactual branch replaces a recorded input and replays through the normal coupled path | Passed |
| Replay archive survives binary save/load validation | Passed |
| Fidelity transitions preserve projected state and expose conservation corrections | Passed |
| Production console commands execute without error responses | Passed |
| Existing command, plugin, FMU, federation, vehicle, and electrification behavior remains available | Passed |
| GCC AddressSanitizer and UndefinedBehaviorSanitizer, with leak detection, on both new suites | Passed |
| User-manual structural regression | Passed: 193 accepted tokens, 144 command families, 215 glossary terms |
| Updated user-manual PDF preflight | Passed: 167 pages, openable, unencrypted, searchable text |
| Original-file preservation | Passed: 430/430 original files retained |
| Final source-tree file count | 439 files, including 9 additive implementation/test/documentation files |
| Added-source unfinished-marker audit | Passed: no TODO, FIXME, stub, placeholder, or not-implemented markers |

## Representative coupled runtime check

The production console was advanced through:

```text
industrial energy depth step 0.01 2200 125 18 900 0
```

The resulting integrated state included:

```text
hv_bus_v=365.13076
inverter_torque_nm=304.53331
aggregate_energy_residual=175.46476
```

This check confirms that the runtime uses vehicle-scale pack voltage, switching-resolved torque production, and a bounded conservation residual rather than the initialization artifacts detected and corrected during validation.

## Sanitizer configuration

The dedicated sanitizer build used:

```text
CMAKE_BUILD_TYPE=Debug
AESIM_ENABLE_SANITIZERS=ON
AESIM_ENABLE_SYCL=OFF
AESIM_ENABLE_HIP=OFF
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1:strict_string_checks=1
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
```

Both `vehicle_depth_tests` and `electrification_platform_tests` completed without an AddressSanitizer, UndefinedBehaviorSanitizer, or leak report.

## Documentation verification

All 22 artifacts in `docs/` were updated for the 2026-07-12 vehicle-depth extension. The authoritative model design is in `NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`. Current command coverage and operator guidance are maintained in `MUZIXDIAGSYS_USER_MANUAL.md`, `MUZIXDIAGSYS_USER_MANUAL.pdf`, and `advanced_help_flag_reference_2026-07-11.txt`.

## Reproducibility commands

```bash
cmake --build /path/to/build -j2
ctest --test-dir /path/to/build --output-on-failure -j2
/path/to/build/vehicle_depth_tests
/path/to/build/electrification_platform_tests
python3 tests/electrification_platform_regression.py /path/to/build/muzixdiagsys /path/to/source
python3 tests/user_manual_regression.py /path/to/source
```

## Engineering-use statement

These tests establish source-level completeness, deterministic execution, bounded numerical behavior, interface compatibility, and regression stability for the supplied engineering models. Vehicle-specific predictive validity still requires measured geometry, material, electrical, aerodynamic, tire, brake, structural-modal, ECU-timing, and environmental calibration data and correlation against the intended physical vehicle.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


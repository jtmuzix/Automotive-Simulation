# Operational Digital Infrastructure Platform

The operational digital infrastructure platform adds ten production-grade engineering laboratories under `aesim::advanced::operational`.

## Live digital-twin streaming and semantic telemetry

`LiveDigitalTwinTelemetryFabric` provides a semantic signal registry, duplicate and sequence-gap detection, event-time watermarks, bounded reordering, deterministic replay, quality-aware linear measurement assimilation, divergence monitoring, and SHA-256 evidence digests. Signal contracts preserve physical dimension, unit, coordinate frame, bounds, safety classification, privacy classification, period, and schema version.

## Formal refinement and equivalence

`FormalRefinementEquivalencePlatform` executes a checked integer intermediate representation and exhaustively verifies source-to-binary and binary-to-RTL equivalence over bounded input domains. It detects arithmetic overflow, output-range violations, and concrete counterexamples. The generated certificate binds all three programs, explored domains, proof outcomes, and counterexamples.

## Electromagnetic machine finite elements

`ElectromagneticMachineFiniteElementLaboratory` solves the two-dimensional magnetic vector-potential finite-element equation on triangular meshes. It supports nonlinear saturation, impressed current density, permanent-magnet coercivity, Dirichlet boundaries, under-relaxed nonlinear iteration, field reconstruction, magnetic energy, flux linkage, inductance, torque co-energy proxy, copper loss, and frequency-dependent core loss.

## Whole-fleet OTA qualification

`WholeFleetOtaQualificationEngine` validates package dependency DAGs, capability requirements, conflicts, storage constraints, state-of-charge limits, safety-package rollback requirements, installation order, reverse rollback order, and download duration for each vehicle in a fleet.

## Cloud-edge mixed-criticality service mesh

`MixedCriticalityServiceMeshRuntime` places replicated services across vehicle, edge, and cloud compute nodes according to CPU, memory, accelerator, capability, deadline, and criticality constraints. It calculates utilization and response time, preserves replica diversity, evaluates freedom from interference, and re-solves placement after node failures.

## Space-weather and radiation reliability

`SpaceWeatherRadiationReliabilityTwin` integrates mission-segment neutron, proton, heavy-ion, and total-ionizing-dose exposure with device cross sections and dose tolerances. ECC, lockstep, watchdog, and latch-up coverage reduce residual event rates. The twin reports per-effect event counts, device failure probabilities, correlated geomagnetic fleet risk, GNSS error inflation, and safety-target compliance.

## Neuromusculoskeletal digital human

`NeuromusculoskeletalHumanLaboratory` implements activation dynamics, Hill-type force-length and force-velocity behavior, tendon moment arms, fatigue and recovery, joint inertia, damping, stiffness, external torque, joint limits, PD neural control, metabolic energy, posture discomfort, and takeover timing.

## Hydrogen materials and cryogenic transfer

`HydrogenMaterialsCryogenicSafetyTwin` models pressure-dependent hydrogen solubility, diffusion, toughness degradation, thin-wall hoop stress, stress-intensity factors, Paris-law crack growth, fatigue life, liquid-hydrogen heat leak, boil-off, vapor pressure, pressure-controlled venting, and release hazard radius.

## 6G integrated sensing and communications

`IntegratedSensingCommunicationsLaboratory` models path loss, atmospheric and blockage loss, MIMO gain, quantized RIS phase efficiency, thermal noise, Shannon throughput, waveform latency, coherent radar integration, range and velocity resolution, detection probability, and positioning error. It searches the communications/sensing resource split against explicit requirements.

## Cascading infrastructure resilience

`CascadingInfrastructureDisasterTwin` couples power, communications, roads, water, hospitals, charging, fuel, and logistics assets through functional dependencies and capacity connections. It samples disaster impacts deterministically from a supplied seed, propagates cascading service loss, prioritizes repair by criticality and restoration rate, assigns capable crews, integrates weighted unserved demand, and reports critical-service restoration.

## Build and test

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target operational_digital_infrastructure_platform_tests
ctest --test-dir build -R operational_digital_infrastructure_platform_unit_tests --output-on-failure
```

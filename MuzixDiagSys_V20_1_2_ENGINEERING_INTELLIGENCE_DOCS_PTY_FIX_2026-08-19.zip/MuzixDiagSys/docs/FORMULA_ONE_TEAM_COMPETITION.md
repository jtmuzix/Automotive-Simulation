# Formula One Team and Competition Digital Twin

## Scope

This module adds five executable Formula One systems without replacing any existing model:

1. Multi-car race dynamics and racecraft.
2. Pit-stop, garage, and trackside operations.
3. Sporting regulation, race control, and stewarding decision support.
4. Trackside sensor metrology and model-correlation campaigns.
5. Competitor intelligence, game theory, and championship optimization.

The public API is declared in `aesim/advanced/formula_one_team_competition.hpp` and is re-exported through `aesim/advanced/platform.hpp`.

## Multi-car racecraft laboratory

`F1MultiCarRacecraftLaboratory` advances multiple cars around a periodic circuit. Each car retains lap position, lateral position, speed, acceleration, tyre grip, electrical state of charge, aerodynamic damage, reliability health, and driver parameters. Commands provide throttle, braking, lateral target, energy deployment, attack, and defensive intent.

The solver applies power-limited acceleration, braking, quadratic drag, curvature-limited speed, bounded lateral motion, electrical energy use, and periodic lap progression. Pairwise interactions calculate longitudinal and lateral overlap, wake-induced downforce/drag/cooling changes, side-by-side state, collision probability, physical contact, speed loss, and aerodynamic damage. Position ordering uses unwrapped race distance.

`choose_racecraft_command` evaluates gap, circuit overtaking quality, speed advantage, tyre advantage, and energy advantage to select an attack line or defensive state.

## Pit-stop and garage operations

`F1TracksideOperationsTwin` executes a dependency graph of pit tasks. Tasks reserve qualified crew and required equipment, respect predecessor completion, account for skill, fatigue, reaction time, equipment cycle time, seeded duration variation, equipment reliability, recovery time, double stacking, and release traffic gaps. Cyclic or incomplete task graphs are rejected.

Garage scheduling executes precedence-constrained work orders against technician capacity and serialized inventory. It records start/finish times, parts availability, and deadline compliance. Required parts are consumed only when available.

## Sporting and stewarding engine

`F1SportingProfile::fia_2026_issue_07` identifies the built-in FIA 2026 Section B Issue 07 profile. Rules are represented as data and can be replaced with later profiles without rewriting adjudication logic.

`F1SportingRaceControlEngine` stores the active race-control phase, reference speed, required delta, sector, and message. It evaluates VSC/race-control delta compliance and adjudicates evidence for track limits, pit speeding, unsafe release, yellow-flag overtaking, collision responsibility, impeding, jump starts, and VSC delta violations.

Decisions include rule identity, infringement status, penalty, uncertainty-aware confidence, severity, reasoning, and a canonical SHA-256 evidence seal. This is engineering decision support and does not represent an official steward decision.

## Trackside metrology and correlation

`F1TracksideMetrologyCampaign` validates sensor sampling against the Nyquist criterion, applies scale, bias, drift, time-offset, and uncertainty corrections, and retains calibrated samples.

Correlation observations are grouped by channel and fitted using the shared qualification-grade column-pivoted QR least-squares solver. The report contains scale, bias, RMSE, uncertainty-normalized RMS, stable correlation, observation count, three-sigma outlier records, synchronization error, an overall likelihood-like score, and evidence.

## Competitor intelligence and championship strategy

`F1CompetitorGameTheoryOptimizer` maintains Bayesian beliefs for competitor pace, pit loss, tyre degradation, reliability, aggression, and wet-weather skill. Lap and pit observations update means and variances with scalar Bayesian measurement updates; retirement observations update reliability belief.

The strategy optimizer evaluates attack, defend, pit, extend, conserve, undercut, and overcut actions using reproducible Monte Carlo race continuations. It includes tyre-age cost, energy benefit, pit loss, safety-car pit advantage, rain response, action-specific costs, and stochastic reliability. Outputs include expected finishing position, win/podium probabilities, expected points, championship value, per-action values, rationale, and evidence.

## Validation

```bash
cmake --build build --target formula_one_team_competition_tests -j
ctest --test-dir build -R formula_one_team_competition_unit_tests --output-on-failure
```

The dedicated tests cover physical multi-car interaction, attack selection, pit dependency execution, equipment and inventory behavior, Issue-07 sporting adjudication, calibrated time/value correction, weighted model correlation, Bayesian opponent updates, and complete strategy-action evaluation.

# CTest runtime-artifact fixture

## Purpose

MuzixDiagSys has many CLI, PTY, Python API, plugin, and integration tests that
execute compiled programs. A direct `ctest` invocation after an interrupted or
partial build previously started those tests even when `muzixdiagsys`,
`muzixdiagsys_engineering`, plugins, or test executables did not exist. The
result was a large secondary failure cascade that obscured the actual build
state.

The build now registers the `aesim_prepare_test_artifacts` CTest setup fixture.
Before any normal test starts, the fixture builds the `aesim_test_artifacts`
target, whose dependency closure contains every compiled target registered in
the directory. Tests that execute compiled targets require the `aesim_test_artifacts_ready`
fixture. Pure source and documentation regressions remain immediately runnable.

Consequences:

- `ctest --test-dir build/full` is safe after a partial build.
- `ctest --test-dir build/full -R cli_regression` also builds missing runtime
  artifacts before running the selected regression.
- A compiler or linker failure appears once in the setup fixture.
- Tests that require the failed build are reported as not run instead of
  producing dozens of misleading `FileNotFoundError` messages.
- `aesim_check` remains the preferred transactional full build/test target and
  reuses the same artifact dependency closure.

## Commands

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON

# Preferred complete transaction.
cmake --build build/full --target aesim_check --parallel

# Also safe: the CTest fixture builds missing artifacts first.
ctest --test-dir build/full --output-on-failure

# Focused direct CTest is safe as well.
ctest --test-dir build/full --output-on-failure -R '^cli_regression$'
```

## Optics and diagnostics

When a selected test executes a compiled artifact, the fixture intentionally
builds the complete compiled target closure. This makes test selection reliable and prevents selected tests from depending on an
accidental prior build state. The first invocation can therefore perform a
substantial build; subsequent invocations are incremental and normally no-op.

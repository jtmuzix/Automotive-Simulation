# MuzixDiagSys Federation and Production Runtime Platform

## Scope

This subsystem adds executable profiles for distributed federation, real-time DCP exchange, FMI layered bus traffic, QEMU-managed virtual ECUs, nonlinear/economic MPC, redundant lockstep controllers, mutation qualification, and persistent distributed-study governance.

All capabilities are opt-in and preserve the inherited simulator behavior.

## Command root

```text
industrial federation status
```

Direct aliases are available for `hla`, `dcp`, `fmi-ls-bus`, `qemu2`, `mpc`, `lockstep`, `mutation`, and `cloud2`.

## HLA federation

```text
industrial federation hla fom-validate data/federation_vehicle_fom.xml
industrial federation hla demo
industrial federation hla save reports/federation.json
industrial federation hla restore reports/federation.json
```

The runtime implements FOM parsing, publication/subscription, object registration, timestamped attribute updates, interactions, conservative logical-time advancement, synchronization points, deterministic event queues, and federation persistence.

## DCP

The DCP layer includes a checked state machine and operational UDP, TCP client/server, Linux SocketCAN, and POSIX process-shared-memory transports. The CAN profile fragments complete DCP PDUs into ordered bounded eight-byte segments and rejects missing, duplicated, reordered, oversized, or truncated sequences.

```text
industrial federation dcp demo
```

## FMI-LS-BUS

```text
industrial federation bus demo
industrial federation bus save reports/bus-state.json
industrial federation bus load reports/bus-state.json
```

The virtual bus supports CAN, CAN FD, LIN, and Ethernet frame records, deterministic arbitration, transmission timing, inboxes, rollback-capable state persistence, and layered-standard metadata.

## QEMU vECU

```text
industrial federation qemu start data/federation_qemu_aarch64.json
industrial federation qemu pause
industrial federation qemu snapshot-save baseline
industrial federation qemu snapshot-load baseline
industrial federation qemu resume
industrial federation qemu stop
```

The process manager selects architecture-specific QEMU executables for Arm, AArch64, RISC-V 32, and RISC-V 64, negotiates QMP capabilities, propagates QMP errors, manages pause/resume, saves and loads snapshots, queries execution status, and guarantees child-process cleanup.

## Nonlinear and economic MPC

```text
industrial federation mpc demo
```

The solver uses bounded single shooting, numerical gradients, projected controls, line search, warm starts, trajectory validation, and a hard deadline. Deadline or non-finite failures return a declared safe fallback command.

## Lockstep redundancy

```text
industrial federation lockstep demo
```

The runtime supports exact, tolerance, median, and weighted-median voting, per-replica deadlines, injected failure/bias, health accounting, degraded quorum, and explicit exclusion reporting.

## Mutation qualification

```text
industrial federation mutation run source.cpp "./test-mutant {mutant}" reports/mutations 100
```

The original source must pass first. Each mutant is then materialized, executed in a timeout-contained child process, classified as killed or survived, and included in a machine-readable report.

## Distributed study control plane

```text
industrial federation cloud demo reports/cloud
```

The SQLite-backed control plane provides capability-labeled workers, persistent studies and tasks, deterministic task ordering, leases, heartbeats, retries, ownership checks, result persistence, content-addressed artifacts, digest verification, review states, and audit-ready metadata. A bounded length-prefixed JSON/TCP service exposes worker registration, study submission, task claim, heartbeat, completion, failure, study status, and artifact-record operations to remote workers without sharing the database file.

## External dependencies

QEMU and physical CAN interfaces are not bundled. When requested, the runtime invokes the installed QEMU executable or binds the configured SocketCAN interface and reports concrete operating-system errors if the dependency is unavailable.

## 2026-07-12 next-generation vehicle-depth integration

Federated runs can expose the new depth signals through the existing industrial signal registry without changing federation ownership or time-management semantics.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


# MuzixDiagSys real-world preset data sources

**Revision:** 2026-07-11  
**Scope:** Public-data anchors used by the built-in engine and vehicle presets added in this revision.

MuzixDiagSys presets are simulation calibrations, not manufacturer-supplied digital twins. Public specifications anchor displacement, architecture, rated output, transmission type, and selected mass/gearing values. Parameters that are not published consistently—such as complete torque surfaces, inertias, converter maps, tire effective radius, aerodynamic area, shift schedules, thermal constants, and loss maps—are bounded engineering approximations selected for stable, plausible simulation behavior. Users should replace these values with controlled measurements for validation or calibration work.

| MuzixDiagSys engine key | Human-readable preset | Public anchor | Official source |
|---|---|---|---|
| `toyota_gr_corolla_g16e_gts` | Toyota GR Corolla G16E-GTS 1.6 turbo | 1.6 L turbo three-cylinder, 300 hp, 295 lb-ft | Toyota GR Corolla: https://www.toyota.com/grcorolla/ ; Toyota press release: https://pressroom.toyota.com/conquer-every-corner-in-the-2026-toyota-gr-corolla/ |
| `honda_civic_type_r_k20c1` | Honda Civic Type R FL5 K20C1 2.0 turbo | 315 hp at 6,500 rpm, 310 lb-ft at 2,600–4,000 rpm, 3,188 lb curb weight | Honda 2026 specifications: https://hondanews.com/en-US/honda-automobiles/releases/release-80046da63cbf9f2582c8895ecb00c4b6-2026-honda-civic-type-r-specifications-features |
| `bmw_m3_competition_s58` | BMW M3 Competition xDrive S58 3.0 twin-turbo | 2,993 cc inline-six, 523 hp, 479 lb-ft, 8-speed automatic | BMW M3 model page: https://www.bmwusa.com/vehicles/m-series/m3-series/bmw-m3-sedan.html ; technical data: https://www.bmwusa.com/vehicles/m-series/m3-series/bmw-m3-sedan-technical-highlights.html |
| `mazda_mx5_skyactiv_g_2.0` | Mazda MX-5 Miata SKYACTIV-G 2.0 | 1,998 cc, 181 hp at 7,000 rpm, 151 lb-ft at 4,000 rpm, 7,500 rpm redline | Mazda model page: https://www.mazdausa.com/vehicles/mx-5-miata ; 2026 release: https://news.mazdausa.com/2026-01-27-2026-Mazda-MX-5-Miata-Pricing-and-Packaging |
| `ram_hurricane_ho_3.0` | Ram 1500 Hurricane High-Output 3.0 twin-turbo | 3.0 L high-output Hurricane, 540 hp, 521 lb-ft, 8-speed automatic class | Ram capability: https://www.ramtrucks.com/ram-1500/capability.html ; RHO: https://www.ramtrucks.com/rho.html |
| `gm_duramax_lz0_3.0` | Chevrolet Duramax LZ0 3.0 turbo-diesel | 3.0 L turbo-diesel, 305 hp, 495 lb-ft, 10-speed automatic | Chevrolet Duramax: https://www.chevrolet.com/duramax-diesel-vehicles ; Silverado: https://www.chevrolet.com/trucks/silverado/1500 |
| `porsche_911_carrera_3.0_boxer` | Porsche 911 Carrera 3.0 twin-turbo boxer | 3.0 L twin-turbo boxer six, 388 hp, 331 lb-ft, 8-speed PDK | Porsche 911 Carrera: https://www.porsche.com/usa/models/911/carrera-models/911-carrera/ ; Porsche newsroom: https://newsroom.porsche.com/en_US/2024/products/porsche-new-911-world-premiere-hybrid-36337.html |
| `subaru_wrx_fa24_dit` | Subaru WRX FA24F 2.4 DIT boxer | 2.4 L direct-injection turbo boxer, 271 hp, 258 lb-ft, 6-speed manual option | Subaru 2026 WRX: https://www.subaru.com/vehicles/wrx/2026/features.html ; specifications: https://www.subaru.com/vehicles/wrx/2026/specs-trim.html |

## Exact selection commands

```text
engine toyota_gr_corolla_g16e_gts
engine honda_civic_type_r_k20c1
engine bmw_m3_competition_s58
engine mazda_mx5_skyactiv_g_2.0
engine ram_hurricane_ho_3.0
engine gm_duramax_lz0_3.0
engine porsche_911_carrera_3.0_boxer
engine subaru_wrx_fa24_dit

vehicle toyota_gr_corolla_6mt
vehicle honda_civic_type_r_fl5_6mt
vehicle bmw_m3_competition_xdrive_8at
vehicle mazda_mx5_nd_6mt
vehicle ram_1500_rho_hurricane_8at
vehicle chevrolet_silverado_1500_duramax_10at
vehicle porsche_911_carrera_pdk
vehicle subaru_wrx_6mt
```

## Longitudinal-dynamics calibration basis

The realism update extends each vehicle preset with a governed-speed envelope, a 50%-pedal road-load equilibrium target, rotating-mass allowance, accessory-power estimate, wheelbase, center-of-gravity height, and drive layout. Published specifications are used where available. Values that manufacturers do not normally publish as a complete set are explicitly engineering calibrations rather than claimed OEM data.

The road-load implementation uses signed aerodynamic drag, a speed-dependent rolling-resistance correction inspired by SAE J2452 tire-test practice, grade force, accessory power, ratio/load-dependent driveline efficiency, and gear-dependent reflected inertia. The accelerator command is treated as driver torque demand rather than direct percentage of rated power. A transient reserve supplies realistic acceleration below the pedal-specific target and decays to zero at equilibrium; the steady-state result is therefore governed by road-load power rather than indefinite partial-throttle peak-power delivery.

Recommended validation is to pair each engine with its intended vehicle, run constant-pedal equilibrium tests on level ground and controlled ambient conditions, then compare acceleration, terminal speed, engine speed, selected gear, wheel power, road-load power, and limiter state. The built-in `partial_throttle_realism_regression` covers representative passenger-car, performance-car, gasoline-truck, and diesel-truck combinations.

## Use and limitations

1. Run `engine list` or `vehicle list` and copy the **Select with** line exactly.
2. Verify the active display name, preset key, and command with `engine status`, `vehicle status`, or `status`.
3. Use `checkpoint save` before changing calibration maps or parameters.
4. Treat the public values as calibration anchors, not complete validation evidence.
5. For measured-data studies, use `validate <csv>`, `identify fit`, `calibrate research fit`, uncertainty analysis, and documented test conditions.

## 2026-07-12 next-generation vehicle-depth integration

Existing presets remain unchanged. Vehicle-specific depth calibration additionally requires modal, terrain, tire, HV, machine, aerodynamic, brake, and ECU timing data.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


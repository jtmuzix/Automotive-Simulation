# Software-Only Simulation Experience Platform

## Purpose

The software-only simulation experience platform adds persistent ownership, interactive scenario control, causal diagnostics, synthesized audio, detailed road/contact physics, environmental traffic, workshop exercises, visualization, adaptive fidelity, uncertainty reporting, and a human driver to the existing MuzixDiagSys vehicle and powertrain simulator. It requires no steering wheel, pedal set, motion platform, or virtual-reality equipment. The existing terminal interface, automation APIs, plugins, vehicle presets, physics models, and command behavior remain available.

The feature is exposed through either command prefix:

```text
industrial experience ...
industrial vehicle experience ...
```

All commands participate in Tab completion and the command-schema audit.

## Runtime architecture

`aesim::experience::SimulationExperiencePlatform` owns the experience services and is embedded in `aesim::vehicle::VehiclePlatform`. The vehicle platform couples the services to the live signal registry, advanced vehicle state, OSI world, environmental state, and industrial command arbitration.

The update path is:

```text
Powertrain and transmission state
        |
        v
IndustrialPlatform::update(PlantSample)
        |
        v
VehiclePlatform::update(...)
        |
        +--> persistent lifecycle accumulation
        +--> timeline event evaluation
        +--> dynamic weather and road evolution
        +--> distributed tire contact and suspension compliance
        +--> heterogeneous traffic and OSI world publication
        +--> human driver perception, pedals, clutch, and shifts
        +--> procedural audio capture
        +--> visualization and ghost history
        +--> adaptive-fidelity decision
        +--> causal event recording
```

When the software human driver is enabled, its throttle and brake outputs become authoritative after the legacy speed controller. For manual transmissions, clutch-pedal depression and gear requests are passed into the real transmission state through the same fully-depressed-clutch interlock used by interactive shift commands. Automatic transmissions ignore user-clutch requests.

## 1. Persistent vehicles, wear, damage, and maintenance

Persistent vehicles are stored as versioned JSON records in a configurable garage directory. The state includes odometer, engine and idle hours, launches, shifts, cold/hot starts, energy histories, active faults, maintenance records, and component-level wear, damage, contamination, thermal age, equivalent cycles, condition, and remaining useful life.

Create and operate a vehicle:

```text
industrial experience garage directory ./garage
industrial experience garage create commuter_01 compact_sedan turbo_i4
industrial experience garage status
industrial experience garage damage transmission 0.08 P0730
industrial experience garage service fluid_change transmission 0.95 320 Correct_ULV_ATF
industrial experience garage save
industrial experience garage load commuter_01
industrial experience garage list
```

Supported maintenance actions are `replace`, `rebuild`, `fluid_change`, `clean`, `flush`, `calibrate`, `align`, and `inspect`. Replacement/rebuild can reverse both wear and damage according to service quality. Fluid and cleaning operations primarily remove contamination. Inspection records cost and elapsed service history without falsely repairing a component.

Lifecycle accumulation is driven by actual operating quantities such as load, RPM, thermal exposure, clutch-slip power, brake power, roughness, impact energy, rain, salt, and electrical power. Persistent degradation therefore changes according to use rather than elapsed wall-clock time alone.

## 2. Interactive scenario timeline and branching

A timeline contains deterministic, prioritized actuator or environment events. It supports live insertion, YAML loading, pause/resume, event stepping, arbitrary seeking, branch creation, branch selection, comparison, and CSV trace export.

```text
industrial experience timeline load data/experience/urban_wet_timeline.yaml
industrial experience timeline resume
industrial experience timeline next
industrial experience timeline pause
industrial experience timeline seek 5.0
industrial experience timeline branch lower_friction
industrial experience timeline select lower_friction
industrial experience timeline add emergency_brake 8.5 brake set 80 Emergency_braking
industrial experience timeline compare main lower_friction
industrial experience timeline export ./timeline_trace.csv
```

Supported event operations are `set`, `add`, `multiply`, `minimum`, `maximum`, and `toggle`. Targets may be writable registered signals or supported environment aliases. Brake event values may be supplied as normalized fractions or percentages.

Branches store timeline time, next-event position, and target values. Seeking rebuilds state deterministically by replaying all events up to the requested time.

## 3. Causal explanations

The causal engine records directed event chains with timestamps, subsystem labels, measured evidence, parent-event identifiers, and recommended actions. Live integration records significant shifts, high brake-energy events, hydroplaning, timeline errors, and audio capture limits.

```text
industrial experience explain status
industrial experience explain latest
industrial experience explain <event-id>
industrial experience explain export ./causal_events.json
industrial experience explain clear
```

An explanation traverses parent identifiers and prints the complete causal chain rather than returning a generic description.

## 4. Procedurally synthesized audio

The audio synthesizer creates stereo PCM WAV output from live physics variables. Sources include engine firing order, load-dependent combustion harmonics, gear-mesh orders, tire/road roughness, wind, braking, clutch slip, and deterministic stochastic texture. Phase is continuous across blocks so output does not click at update boundaries.

```text
industrial experience audio configure 48000 2 12345
industrial experience audio reset
industrial experience audio start 120
quickstart
step 10
industrial experience audio stop
industrial experience audio write ./vehicle_run.wav
industrial experience audio status
```

The capture limit prevents unbounded memory use. Standard speakers or headphones are sufficient; audio generation can also be used off-line for diagnostic comparison.

## 5. OpenCRG and generated road surfaces

`RoadSurfaceField` supports a rectilinear OpenCRG surface and deterministic procedural roads. Samples provide height, surface normal, local friction, roughness, water depth, snow depth, temperature, and material.

```text
industrial experience road load data/experience/example_surface.crg
industrial experience road sample 8.0 0.5
industrial experience road generate worn_city 42 5000 10 0.008 7 0.012 0.90 asphalt
industrial experience road weather 0.004 0.0 286.15
industrial experience road export ./road_grid.csv 2.0 0.5
```

Procedural generation combines seeded broadband roughness, long-wave undulation, wheel-path rutting, and spatially distributed potholes. Identical configuration and seed produce identical surfaces.

The generated/OpenCRG road feeds actual per-wheel road elevation and friction when the pre-existing vehicle OpenCRG surface is not active. The legacy surface retains precedence, preserving established workflows.

## 6. Distributed tire contact and suspension compliance

The contact patch is discretized longitudinally and laterally. Every cell calculates local elevation, normal pressure, longitudinal and lateral slip contribution, friction utilization, thermal input, wear, and water support. Aggregate output includes longitudinal/lateral force, aligning moment, effective friction, contact area, mean temperature, and hydroplaning fraction.

```text
industrial experience tire evaluate 12 0 4300 0.08 0.03 16 8
industrial experience tire suspension-step 4300 0.012 0.002
industrial experience tire status
```

The suspension model resolves each corner independently with nonlinear bump and droop stops, spring/damper force, road excitation, bushing compliance, load-dependent camber and toe, compliance steer, and dissipated energy. Its compliance-steer output is added to the advanced vehicle wheel steering state.

Adaptive fidelity selects contact-cell resolution according to event severity, uncertainty, and compute budget.

## 7. Dynamic weather, road state, and heterogeneous traffic

Weather is represented by moving spatial cells with rain, snow, fog visibility, temperature, and wind. The road evolves through precipitation accumulation, drainage, traffic spray, snow compaction, freezing, melting, ice formation, and friction reduction.

```text
industrial experience weather reset 289.15
industrial experience weather add storm 0 0 1200 4 0 35 0 300 12 3 286
industrial experience weather step 100 0 0.2 250 1.0
industrial experience weather status
```

Traffic contains passenger cars, heavy trucks, buses, motorcycles, bicycles, pedestrians, emergency vehicles, construction vehicles, and disabled vehicles. Each agent has individual speed preference, reaction time, desired gap, aggression, courtesy, rule compliance, distraction, and lane-change behavior.

```text
industrial experience traffic populate 80 5000 91422
industrial experience traffic step 100 0 22 0.70 800 0.1
industrial experience traffic status
industrial experience traffic clear
```

Traffic is mirrored into the shared OSI-oriented world model. Dynamic weather is mirrored into the shared world environment so perception, autonomy, and visualization consume the same conditions.

## 8. Workshop diagnostics and fault-solving scenarios

Workshop mode hides the true fault while exposing only tests appropriate to the case. Included cases cover restricted injectors, weak batteries, transmission pressure leakage, wheel-speed dropout, cooling-system air pockets, turbo underboost, and clutch slip.

```text
industrial experience workshop load data/experience/diagnostic_underboost.yaml
industrial experience workshop status
industrial experience workshop test scan
industrial experience workshop test smoke_test
industrial experience workshop test wastegate_test
industrial experience workshop test compressor_speed
industrial experience workshop diagnose turbo_underboost
industrial experience workshop export ./workshop_report.md
```

Every advertised test maps to concrete case-specific evidence. A missing evidence mapping raises an internal consistency error; there is no generic placeholder response. Diagnostic scoring accounts for correctness, evidence gathered, elapsed diagnostic time, and test cost.

## 9. Two-dimensional, three-dimensional, and ghost comparison

The terminal renderer provides a top-down ASCII view. Two-dimensional and perspective three-dimensional views export as self-contained SVG files, requiring only a normal browser or image viewer.

```text
industrial experience visual ascii 100 30 2
industrial experience visual export-2d ./scene_2d.svg 120 60
industrial experience visual export-3d ./scene_3d.svg 120 60
```

Measured/reference trajectories can be imported from CSV:

```text
industrial experience visual load-ghost data/experience/reference_ghost.csv
industrial experience visual compare ./ghost_residuals.csv
industrial experience visual status
```

Ghost comparison aligns simulation and reference samples by time and exports position, speed, engine-speed, and gear differences.

## 10. Adaptive fidelity, reports, and uncertainty visualization

Fidelity levels are:

```text
fast
interactive
engineering
validation
full_research
```

```text
industrial experience fidelity set engineering
industrial experience fidelity auto on 0.85
industrial experience fidelity update 15.0 0.90 0.70 0.55
industrial experience fidelity status
```

The manager raises fidelity near severe, uncertain events and lowers it under compute pressure. Decisions include tire cell count, suspension substep, weather substep, traffic substep, and audio sample rate. Every transition is retained in decision history.

Automatic reports include metadata, physics-derived metrics, standard uncertainty, model-form uncertainty, combined standard uncertainty, and 95% intervals:

```text
industrial experience report automatic markdown ./experience_report.md
industrial experience report automatic json ./experience_report.json
industrial experience report metric clutch_energy 18.2 0.5 0.04 kJ
industrial experience report warning Synthetic_measurement_input
industrial experience report write json ./custom_report.json
```

## 11. Human driver skill model

The software human driver includes clutch skill, shift skill, rev-matching skill, throttle/brake smoothness, steering skill, reaction time, fatigue, distraction, aggression, and economy tendency.

```text
industrial experience driver configure 0.70 0.75 0.65 0.80 0.80 0.75 0.35 0.55 0.45 1234
industrial experience driver transmission manual 6
industrial experience driver target 25
industrial experience driver on
quickstart
step 30
industrial experience driver status
industrial experience driver off
```

The driver calculates car-following acceleration, braking, lane correction, attention, fatigue, shift points, clutch timing, rev matching, missed shifts, stalls, and harsh events. It owns the real throttle, brake, and steering channels when enabled. Manual clutch/gear requests act on the actual transmission only when the clutch is fully depressed.

## Reproducible software-only workflow

```text
industrial experience garage directory ./garage
industrial experience garage create test_car compact_sedan turbo_i4
industrial experience road generate urban_worn 42 2000 10 0.007 6 0.010 0.91 asphalt
industrial experience weather add rain 500 0 900 -2 0 30 0 400 8 2 288
industrial experience traffic populate 40 2000 99
industrial experience timeline load data/experience/urban_wet_timeline.yaml
industrial experience visual load-ghost data/experience/reference_ghost.csv
industrial experience driver configure 0.70 0.75 0.65 0.80 0.80 0.75 0.35 0.55 0.45 1234
industrial experience driver transmission manual 6
industrial experience driver target 22
industrial experience driver on
industrial experience audio reset
industrial experience audio start 60
industrial experience timeline resume
quickstart
step 12
industrial experience audio stop
industrial experience audio write ./run.wav
industrial experience visual export-2d ./run_2d.svg 120 60
industrial experience visual export-3d ./run_3d.svg 120 60
industrial experience visual compare ./ghost_compare.csv
industrial experience report automatic markdown ./run_report.md
industrial experience garage save
```

## Validation

The implementation is exercised by:

- `simulation_experience_tests`: persistence, maintenance, branching, causal chains, WAV generation, procedural/OpenCRG roads, distributed contact, suspension compliance, weather, traffic, human driver, workshop evidence, visualization, ghost comparison, adaptive fidelity, uncertainty reporting, integrated actuator requests, and completion.
- `simulation_experience_cli_regression.py`: complete terminal workflow and artifact validation.
- Existing core, vehicle, accuracy, industrial, completion, and golden-frame regressions.


# Qualification Science Platform

## Scope

The qualification science platform is an additive C++17 module exported through
`include/aesim/advanced/qualification_science_platform.hpp` and the aggregate
`include/aesim/advanced/platform.hpp`. It provides ten production implementations
for simulation credibility, standards-oriented validation, executable regulation,
multiphysics engineering, adaptive computation, causal diagnosis, and autonomous
physical testing.

The module contains no placeholder methods, no constant demonstration returns,
and no deferred external-service dependency. Every public operation validates its
inputs, executes a deterministic numerical algorithm, returns structured results,
and produces a SHA-256 evidence identifier over a canonical machine-readable
result document.

## 1. Simulation Quality Qualification Engine

`SimulationQualityQualificationEngine` evaluates a model-use request against:

- explicit validity-envelope limits and normalized extrapolation distance;
- validation, calibration, numerics, provenance, and uncertainty evidence;
- evidence weights, standard uncertainties, and independent review state;
- runtime residual and conservation-error tolerances;
- one-sided confidence deductions; and
- certification-use restrictions.

The engine uses a weighted geometric quality aggregate so one critically weak
dimension cannot be hidden by strong unrelated dimensions. It returns one of six
enforceable states: qualified, conditionally qualified, extrapolated, exploratory,
numerically suspect, or invalid. `permits_certification()` is deliberately stricter
than a generic successful evaluation.

## 2. Standards-Based Vehicle-Dynamics Validation

`StandardsVehicleDynamicsValidationLab` supports steady-state circle, on-centre
weave, slowly increasing steer, sine-with-dwell, step steer, pulse steer, fishhook,
brake-in-turn, split-mu braking, and frequency-sweep workflows.

The implementation performs:

1. strict signal/time validation;
2. common-grid interpolation;
3. optional zero-phase first-order low-pass filtering;
4. bounded cross-correlation time alignment;
5. optional bias removal;
6. RMSE, normalized RMSE, maximum error, R-squared, gain error, phase error, and
   squared-correlation coherence calculations;
7. residual lag-one whiteness assessment; and
8. per-signal and campaign-level acceptance decisions.

The standard identifier is data, not hard-coded policy. This allows projects to
bind organization-specific limits or licensed standard procedures without changing
the solver.

## 3. Regulation-as-Code and Semantic Rule Diff

`RegulationAsCodeEngine` contains a real lexer, recursive-descent parser, canonical
abstract syntax tree, evaluator, and semantic differ. The expression language
supports:

- arithmetic: `+`, `-`, `*`, `/`, and exponentiation;
- comparison: `<`, `<=`, `>`, `>=`, `==`, and `!=`;
- Boolean composition: `&&`, `||`, and `!`;
- parentheses;
- variables with dotted paths; and
- `abs`, `sqrt`, `min`, `max`, and `clamp` functions.

Compilation records referenced variables and a semantic hash. Evaluation reports a
signed compliance margin for top-level comparisons. Semantic comparison separates
added, removed, threshold, logic, and metadata changes and then traverses an
artifact dependency graph to calculate the complete evidence and analysis impact.

## 4. Composite Laminate and Progressive-Damage Solver

`CompositeLaminateProgressiveDamageSolver` implements classical laminate theory
for arbitrary orthotropic stacking sequences:

- reduced lamina stiffness and transformed off-axis stiffness;
- full `A`, `B`, and `D` assembly;
- membrane/bending coupling;
- thermal expansion resultants;
- six-degree generalized strain solution;
- ply-midplane local strain and stress recovery;
- maximum-stress, Tsai-Hill, Tsai-Wu, and Hashin-style failure indices;
- mode-specific fiber, matrix, and shear stiffness degradation;
- iterative load redistribution; and
- reserve factor, mass-per-area, terminal failure, and convergence reporting.

Positive-definiteness and engineering-constant guards reject nonphysical lamina
inputs before matrix assembly.

## 5. Monolithic Aeroelasticity

`MonolithicAeroelasticSolver` solves coupled modal structural and aerodynamic
motion in one nonlinear implicit system. It supports:

- multiple coupled flexible modes;
- full aerodynamic stiffness and damping matrices;
- airspeed-dependent dynamic pressure;
- nonlinear cubic modal stiffness;
- external generalized loads;
- average-acceleration Newmark integration;
- Newton iterations with an assembled coupled tangent;
- structural-energy and aerodynamic-work histories;
- energy-growth instability classification; and
- bounded divergence and flutter onset searches.

A zero instability-speed result means no crossing was found inside the requested
search interval; it is not serialized as infinity.

## 6. Physics-Based Tire Compound Laboratory

`PhysicsBasedTireCompoundLaboratory` links compound material physics to tire
friction, heat, wear, and aging:

- Williams-Landel-Ferry time-temperature shifting;
- generalized Maxwell/Prony storage and loss moduli;
- loss tangent;
- Mooney-Rivlin hyperelastic stress;
- temperature-, pressure-, speed-, wear-, and aging-sensitive adhesion;
- hysteretic friction from viscoelastic loss;
- frictional heat generation;
- tread thermal-state integration;
- abrasion-rate integration; and
- deterministic temperature sweeps.

## 7. Thermo-Elastohydrodynamic Tribology

`ThermoElastohydrodynamicTribologyLab` provides a point-contact engineering model
for bearings, gears, followers, and related contacts:

- Hamrock-Dowson film-thickness correlation;
- lambda film parameter;
- boundary, mixed, EHL, and hydrodynamic regime classification;
- Stribeck-like blended friction;
- Hertzian contact radius and peak pressure;
- friction power and flash-temperature rise;
- Archard-style boundary wear;
- debris-state accumulation; and
- combined thermal/film scuffing risk.

## 8. Certified Surrogate and Adaptive-Fidelity Controller

`CertifiedSurrogateAdaptiveFidelityController` trains a regularized complete
quadratic response surface, calculates residual scales and finite-sample conformal
coverage, estimates conditioning, and certifies the resulting model only when the
requested empirical coverage and numerical condition limits are satisfied.

Prediction returns mean values, conformal intervals, normalized domain
extrapolation, and an acceptance decision. The adaptive controller executes the
high-fidelity callback whenever certification, domain, or error-policy conditions
are not met. Optional online residual correction updates the intercept and residual
scale after a high-fidelity observation.

## 9. Causal Telemetry and Counterfactual Replay

`CausalTelemetryCounterfactualEngine` fits structural linear equations to a
user-supplied causal graph with regularized least squares. It supports zero-lag
acyclic effects and delayed feedback/self-dynamics. Each equation reports fitted
coefficients, residual standard deviation, and R-squared.

Counterfactual replay applies fixed-value or additive interventions over bounded
time intervals and then recomputes downstream signals in instantaneous topological
order while respecting delayed parents. Endpoint deltas and structural path-gain
root-cause contributions are returned for selected outcomes.

## 10. Autonomous Physical-Test Planner

`AutonomousPhysicalTestPlanner` performs constrained sequential Bayesian
experimental design. Candidate tests define parameter sensitivities, measurement
noise, cost, duration, risk, rig load, resources, and control setpoints.

At every selection step, the planner:

1. rejects unavailable or unsafe tests;
2. computes the scalar innovation covariance;
3. applies the exact linear-Gaussian covariance update;
4. calculates D-optimal information gain from covariance determinants;
5. normalizes gain by cost, duration, and risk;
6. selects the highest-utility admissible test; and
7. updates the posterior before selecting the next test.

The same Kalman update is exposed for assimilating an actual measurement innovation
into parameter means and covariance.

## Build and Test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DAESIM_BUILD_TESTS=ON
cmake --build build --target qualification_science_platform_tests -j
ctest --test-dir build -R qualification_science_platform_unit_tests --output-on-failure
```

Sanitizer validation:

```bash
cmake -S . -B build-sanitize -DCMAKE_BUILD_TYPE=Debug \
  -DAESIM_BUILD_TESTS=ON -DAESIM_ENABLE_SANITIZERS=ON
cmake --build build-sanitize --target qualification_science_platform_tests -j
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
  ./build-sanitize/qualification_science_platform_tests
```

## Qualification Boundary

These implementations provide engineering algorithms and traceable evidence. A
project claiming conformance to a particular external standard must still load the
correct licensed test procedure, issue-specific limits, instrumentation rules,
measurement uncertainty, and organizational acceptance policy. The software does
not misrepresent a generic maneuver implementation as third-party certification.

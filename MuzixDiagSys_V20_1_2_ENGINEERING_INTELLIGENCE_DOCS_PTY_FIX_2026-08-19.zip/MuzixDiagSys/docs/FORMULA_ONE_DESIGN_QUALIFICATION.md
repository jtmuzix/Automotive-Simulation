# Formula One Design, Test, Scrutineering, Tire, and Control Qualification

## Scope

This module adds five executable engineering laboratories without deleting or replacing existing functionality:

1. Full-car multidisciplinary design optimization.
2. Formula One physical test-rig and hardware-in-the-loop execution.
3. Digital scrutineering with measurement uncertainty and guard bands.
4. Virtual tire testing and inverse parameter identification.
5. Control-software qualification and safety analysis.

The public API is declared in `include/aesim/advanced/formula_one_design_qualification.hpp` and re-exported by `include/aesim/advanced/platform.hpp`.

## Full-car multidisciplinary design optimization

`F1FullCarMdoOptimizer` accepts continuous and discrete `F1MdoVariable` definitions, weighted `F1MdoScenario` operating conditions, hard constraints, objective weights, and an executable `F1MdoEvaluator`.

The optimizer performs deterministic stratified population initialization, bounded crossover and mutation, feasibility-first selection, multi-objective dominance filtering, and a final trust-region coordinate search. Every candidate is evaluated across every scenario. The robust metrics retain worst-case lap time, peak temperature, reliability, compliance margin, and correlation confidence, while mass, drag, cost, and resource use are weight-averaged.

Constraints cover mass, temperature, reliability, regulation margin, correlation confidence, cost, and development resources. Infeasible candidates remain visible with a normalized maximum violation; they cannot displace feasible candidates solely through objective weighting. `F1MdoResult` contains the best scalarized candidate, a nondominated Pareto front, evaluation totals, feasibility totals, and canonical evidence.

The evaluator is deliberately supplied by the caller so the optimizer can couple the existing aero, tire, suspension, cooling, power-unit, reliability, compliance, and lap-time systems without duplicating their equations.

## Physical rigs and HIL

`F1PhysicalRigHilLaboratory` executes damped second-order rig axes with fourth-order Runge-Kutta integration, actuator force and slew limits, travel limits, sensor uncertainty, deterministic seeded noise, and time-bounded faults.

Supported rig profiles include seven-post, four-post, kinematics/compliance, brake dynamometer, gearbox dynamometer, power-unit dynamometer, active-aero, and tire-machine configurations. A rig can contain any number of named axes with independent mass, stiffness, damping, travel, force, rate, and sensor-noise parameters.

Command histories are linearly interpolated. Faults include bias, added noise, dropout, stuck sensors, delayed measurements, and actuator loss. The report contains the complete time history, RMS force-tracking error, actuator energy, travel utilization, limit status, and frequency responses around each axis natural frequency. Frequency-response records include gain, phase, and a bounded coherence indicator.

`run_hil` drives the same physical rig from an executable `F1HilController`. Each controller step declares its execution time, returns actuator commands, and can request a safe state. The report records deadline misses, worst execution time, safety transition, events, the complete rig result, and evidence.

The declared execution time is the deterministic timing input for repeatable qualification. Physical target qualification should additionally record hardware-clock timestamps from the existing industrial HIL interfaces.

## Digital scrutineering

`F1DigitalScrutineeringEngine` first aligns measured geometry to the regulatory datum system. It uses weighted least-squares rigid registration based on Horn's unit-quaternion solution, with a symmetric eigenproblem, residual RMS, datum uncertainty, and alignment uncertainty.

Rule types include minimum, maximum, bounded range, required Boolean condition, maximum deflection, three-dimensional legal envelope, and approved software hash. Scalar checks combine instrument uncertainty and alignment uncertainty. Pass/fail is based on a configurable guard band rather than the nominal measurement alone.

Each check reports nominal margin, guard-banded margin, standard uncertainty, probability of conformance, and engineering reasoning. Envelope checks transform every scan point into the regulatory frame and evaluate its nearest face margin. Software checks compare cryptographic identities exactly.

This laboratory creates uncertainty-qualified engineering evidence. It does not represent an official FIA measurement, interpretation, or homologation decision.

## Virtual tire testing and identification

`F1VirtualTireTestLaboratory` implements a combined-slip brush-style tire with load sensitivity, longitudinal stiffness, cornering stiffness, camber stiffness, a friction ellipse, pneumatic trail, temperature response, pressure response, wear response, and speed-dependent rolling resistance.

`steady_state` evaluates one operating point. `transient_test` adds first-order longitudinal and lateral relaxation using physical relaxation lengths and wheel speed.

`identify` fits selected tire parameters to force and moment observations with uncertainty normalization, Huber robustification, bound-aware high-order finite-difference Jacobians, Levenberg-Marquardt damping, the qualification-grade linear solver, covariance estimation, condition diagnostics, and an identifiability score.

The caller can fit any supported subset of:

- Friction coefficient.
- Load sensitivity.
- Longitudinal stiffness.
- Cornering stiffness.
- Camber stiffness.
- Longitudinal and lateral relaxation length.
- Optimum temperature and thermal width.
- Optimum pressure and pressure sensitivity.
- Wear sensitivity.
- Rolling resistance.

A low identifiability score indicates that the supplied test matrix does not independently excite the requested parameters. More optimization iterations do not correct an uninformative experiment.

## Control-software qualification

`F1ControlSoftwareQualificationLaboratory` binds a controller name, domain, binary SHA-256, calibration SHA-256, period, and deadline to a qualification campaign.

The executable campaign compares model-in-the-loop and software-in-the-loop functions while advancing a caller-supplied plant. Supported fault campaigns include sensor bias, dropout, stuck input, stuck actuator, communication loss, controller reset, corrupted calibration, and timing overrun.

Requirements include:

- Output ranges and physical invariants.
- Output slew-rate limits.
- Execution deadlines.
- Temporal response deadlines.
- Safe-state entry.
- MIL/SIL equivalence.

The result retains the full trace, requirement-level observed value and margin, deadline misses, worst execution time, maximum MIL/SIL error, safe-state result, events, overall status, and evidence.

`verify_state_machine` performs graph validation independently of simulation. It verifies distinguished states, transition references, initial-state reachability, safe-state reachability, unreachable states, and non-safe deadlocks.

The module does not claim that simulation alone qualifies production software. Processor-in-the-loop, hardware-in-the-loop, compiler qualification, WCET measurement, code coverage, and physical fail-safe testing remain necessary for deployment evidence.

## Validation

```bash
cmake --build build --target formula_one_design_qualification_tests -j
ctest --test-dir build -R formula_one_design_qualification_unit_tests --output-on-failure
```

The dedicated suite exercises robust mixed-variable MDO, dynamic rig response, HIL deadlines and safety, rigid datum alignment, uncertainty-aware scalar and envelope inspection, cryptographic identity checks, synthetic tire inverse identification, MIL/SIL equivalence, fault-triggered safe state, temporal requirements, and state-machine reachability.

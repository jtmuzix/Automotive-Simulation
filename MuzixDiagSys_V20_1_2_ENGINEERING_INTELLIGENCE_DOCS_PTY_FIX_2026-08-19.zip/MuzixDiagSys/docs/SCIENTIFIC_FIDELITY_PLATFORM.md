# MuzixDiagSys Scientific Fidelity and Predictive Accuracy Platform

**Revision:** 2026-07-26

## 1. Purpose

The scientific-fidelity platform adds a common numerical and experimental layer
for simulation domains that require stronger physical coupling, higher-order
continuum discretization, nonsmooth contact, spatially correlated uncertainty,
field-scale calibration, real-fluid phase equilibrium, explicit structural-model
uncertainty, total predictive-error accounting, virtual laboratory measurements,
and progressive fracture.

The implementation is additive. Existing vehicle, motorsport, autonomy,
materials, manufacturing, infrastructure, diagnostic, generalized-runtime, and
interoperability services remain available without API removal or semantic
replacement.

Public API:

```cpp
#include "aesim/advanced/scientific_fidelity_platform.hpp"
```

The aggregate advanced header also exports this API:

```cpp
#include "aesim/advanced/platform.hpp"
```

## 2. Production source layout

```text
include/aesim/advanced/
└── scientific_fidelity_platform.hpp

src/advanced/
├── scientific_fidelity_platform_a.cpp
├── scientific_fidelity_platform_b.cpp
├── scientific_fidelity_platform_c.cpp
└── scientific_fidelity_internal.hpp

tests/
├── scientific_fidelity_platform_tests.cpp
└── scientific_fidelity_platform_source_regression.py
```

The three production translation units are compiled into `aesim_advanced`.
The internal header contains shared dense-linear-algebra, eigensystem,
probability, covariance, and numerical-validation utilities and is not part of
the public API.

## 3. Strongly coupled multiphysics solver

`StronglyCoupledMultiphysicsSolver` solves an arbitrary block residual system:

```text
R(X) = 0
```

where `X` may contain fluid, structural, thermal, electrical, chemical,
controller, or reduced-order states. A caller supplies block descriptors and a
residual callback. An analytical Jacobian may be supplied; otherwise the solver
constructs a scaled finite-difference Jacobian.

Implemented numerical behavior:

- Monolithic Newton iterations.
- Pivoted dense linear solution.
- Regularized normal-equation fallback for singular or rectangularly sensitive
  local Jacobians.
- Block residual scaling.
- Block update scaling.
- Armijo-style backtracking line search.
- Absolute and relative residual convergence.
- State-update convergence.
- Complete nonlinear-iteration history.
- Optional conservation-accounting callbacks.
- Strict finite-value and dimension validation.

Example:

```cpp
StronglyCoupledMultiphysicsSolver solver;
solver.configure(
    {{"fluid", 2, 1.0e5, 1.0}, {"structure", 3, 1.0e-3, 1.0}},
    [](const ScientificVector& x) {
        return assemble_coupled_residual(x);
    },
    StronglyCoupledMultiphysicsSolver::JacobianFunction{
        [](const ScientificVector& x) {
            return assemble_coupled_jacobian(x);
        }});

const auto report = solver.solve(initial_state);
if (!report.converged) {
    throw std::runtime_error(report.termination_reason);
}
```

Use physically meaningful block scales. A pressure residual measured in pascals
and a displacement residual measured in meters should not enter the nonlinear
norm with identical unscaled magnitudes.

## 4. High-order hp-adaptive PDE framework

`HpAdaptiveDiscontinuousGalerkinSolver` implements a one-dimensional modal
Legendre discontinuous-Galerkin solver for advection, diffusion, linear
reaction, and nonlinear source callbacks.

Implemented features:

- Modal Legendre polynomial basis.
- User-selected polynomial order per cell.
- Exact diagonal modal mass matrix.
- Gaussian quadrature generated at runtime.
- Upwind advection flux.
- Interior-penalty diffusion flux.
- SSP-RK3 time integration.
- CFL-limited adaptive time step.
- Periodic or zero-gradient exterior boundaries.
- Modal-energy smoothness indicator.
- Automatic p refinement.
- Automatic h bisection.
- Automatic p coarsening.
- Conservative modal projection during h refinement.
- Integral, point-evaluation, and L2-error calculations.
- Mass, extrema, cell, and degree-of-freedom reporting.

Example:

```cpp
HpPdeConfiguration configuration;
configuration.advection_speed = 12.0;
configuration.diffusivity = 1.0e-4;
configuration.minimum_order = 2;
configuration.maximum_order = 7;
configuration.refine_indicator = 1.0e-3;
configuration.coarsen_indicator = 1.0e-7;

HpAdaptiveDiscontinuousGalerkinSolver solver;
solver.configure(
    0.0,
    1.0,
    32,
    configuration,
    [](double x) { return std::exp(-200.0 * (x - 0.3) * (x - 0.3)); });

const auto step = solver.advance(0.05);
```

The current implementation is a complete scalar one-dimensional DG engine. Use
it directly for transport benchmarks, reduced-order field models, line networks,
and method development. Multidimensional production PDE work should couple it
with the unified mesh service or extend the same modal and flux contracts to the
existing multidimensional finite-volume and finite-element layers.

## 5. Nonsmooth complementarity contact mechanics

`NonsmoothComplementarityContactSolver` resolves unilateral contact and Coulomb
friction using projected Gauss-Seidel impulse iterations.

Each constraint contains:

- Dynamic body A.
- Optional dynamic body B; absence represents an immovable environment.
- Unit normal and independent tangent.
- Signed gap.
- Friction coefficient.
- Restitution.
- Optional normal compliance.

The solver enforces:

```text
gap >= 0
normal impulse >= 0
normal impulse * admissible normal velocity = 0
|tangential impulse| <= friction * normal impulse
```

Implemented behavior:

- Dynamic and fixed bodies.
- Normal impulse projection.
- Coulomb friction-cone projection.
- Stick/slip classification.
- Restitution.
- Penetration stabilization.
- Compliance regularization.
- Relaxed projected iterations.
- Complementarity residual reporting.
- Kinetic-energy before/after accounting.
- Position advancement after impulse solution.

This approach avoids the very small stable time steps required by excessively
stiff penalty springs. It is appropriate for rigid-body impact, backlash,
mechanical stops, wheel/rail contact, gear engagement, robotics, debris contact,
and manufacturing operations.

## 6. Spatial stochastic fields and uncertain geometry

`SpatialStochasticFieldModel` represents correlated uncertainty over arbitrary
point coordinates.

Supported covariance models:

- Exponential.
- Squared exponential.
- Matern 3/2.
- Matern 5/2.

The model assembles the full covariance matrix and computes a symmetric Jacobi
eigendecomposition. Retained Karhunen-Loeve modes generate deterministic seeded
samples:

```text
a(x, omega) = mean + sum(sqrt(lambda_i) * phi_i(x) * xi_i)
```

Implemented capabilities:

- User-selected mean and standard deviation.
- User-selected correlation length.
- Deterministic sample indexing.
- Captured-variance reporting.
- Conditional Gaussian sampling from noisy point observations.
- Full posterior conditional covariance.
- Cholesky-correlated conditional draws.
- Geometry perturbation along user-provided direction fields.

Applications include road friction, material porosity, composite thickness,
corrosion depth, surface roughness, wind, rainfall, manufacturing variation,
thermal conductivity, electrode loading, and uncertain geometry.

Example:

```cpp
SpatialStochasticFieldModel roughness;
roughness.configure(surface_points,
                    {0.0, 20.0e-6, 0.08,
                     StochasticCovarianceModel::Matern52,
                     30, 1234});

const auto sample = roughness.conditional_sample(
    {{inspection_point, measured_height, measurement_sigma}}, 17);
const auto geometry = roughness.perturb_geometry(
    nominal_vertices, surface_normals, sample);
```

## 7. Field-scale data assimilation

`EnsembleFieldAssimilator` implements a stochastic ensemble Kalman update for
high-dimensional fields.

Implemented behavior:

- Arbitrary ensemble state dimension.
- Nonlinear propagation callback.
- Sequential scalar observations.
- Sample covariance calculation.
- Multiplicative covariance inflation.
- Stochastic observation perturbations.
- Optional coordinate-based covariance localization.
- Compactly supported Gaspari-Cohn localization.
- Prior and posterior weighted misfit.
- Posterior mean and covariance.

The direct observation model addresses a field element by index. More complex
measurement operators can be represented by augmenting the state with synthetic
observation channels in the propagation callback or by mapping physical
instrument outputs into the indexed observation space.

## 8. PDE-constrained inverse modeling

`PdeConstrainedInverseSolver` estimates parameters or discretized fields from a
forward-model callback and measured observations.

The objective combines measurement mismatch and prior regularization:

```text
J(theta) = 0.5 * (F(theta)-y)^T R^-1 (F(theta)-y)
         + 0.5 * lambda * (theta-theta_prior)^T P^-1
                         (theta-theta_prior)
```

Implemented behavior:

- Full measurement covariance.
- Full prior covariance.
- Analytical Jacobian callback or finite-difference Jacobian.
- Gauss-Newton approximate Hessian.
- Pivoted linear solution.
- Descent-direction fallback.
- Armijo backtracking.
- Gradient convergence.
- Iteration history.
- Approximate posterior parameter covariance.

Use this layer to estimate boundary conditions, source strengths, spatial
properties, constitutive parameters, unknown loads, heat fluxes, reaction rates,
and reduced field coefficients.

## 9. Real-fluid thermodynamics and phase equilibrium

`PengRobinsonThermodynamics` implements multicomponent Peng-Robinson cubic-EOS
properties and isothermal-isobaric flash calculations.

Each component defines:

- Critical temperature.
- Critical pressure.
- Acentric factor.
- Molar mass.
- Ideal molar heat capacity.

A symmetric binary-interaction matrix may be supplied.

State evaluation provides:

- Physical liquid or vapor compressibility root.
- Molar density.
- Mass density.
- Ideal plus residual molar enthalpy.
- Component fugacity coefficients.

`flash_pt` provides:

- Wilson initial equilibrium ratios.
- Rachford-Rice vapor fraction.
- Liquid and vapor compositions.
- Fugacity-ratio updates.
- Damped equilibrium-ratio iteration.
- Single-liquid and single-vapor recognition.
- Material-balance residual.
- Iteration and convergence reporting.

Example:

```cpp
PengRobinsonThermodynamics fluid;
fluid.configure(components, binary_interaction);
const auto flash = fluid.flash_pt(temperature_k, pressure_pa, composition);
```

The EOS does not substitute for a dedicated high-accuracy reference equation of
state for water, steam, refrigerants, or cryogenic fluids. Use the implemented
model where cubic-EOS accuracy is appropriate and validate against reference
property data over the intended operating envelope.

## 10. Bayesian multimodel inference and averaging

`BayesianMultimodelInference` maintains uncertainty over competing physical
models instead of selecting one model as certainly correct.

Implemented features:

- Log prior model probabilities.
- Log marginal likelihoods.
- Stable log-sum-exp normalization.
- Posterior model probabilities.
- Log Bayes factors relative to the best-supported model.
- Bayesian predictive mean.
- Within-model plus between-model predictive variance.
- Effective model count.
- Sequential evidence updates.
- Predictive stacking-weight optimization on the probability simplex.

Example competing models may include alternative tyre laws, turbulence models,
battery-aging laws, heat-transfer correlations, fracture models, driver agents,
or chemical mechanisms.

## 11. Quantitative total error-budget propagation

`QuantitativeSimulationErrorBudget` combines all important predictive-error
sources in one correlated covariance calculation.

Supported source categories:

- Measurement.
- Parameter.
- Numerical.
- Model form.
- Sampling.
- Implementation.
- Boundary condition.
- Initial condition.
- Surrogate.

Each source defines a standard uncertainty, local sensitivity coefficient, and
optional degrees of freedom. A full correlation matrix captures dependent error
sources.

The report includes:

- Combined standard uncertainty.
- Effective degrees of freedom using Welch-Satterthwaite aggregation.
- Confidence-dependent normal coverage factor.
- Expanded uncertainty.
- Lower and upper interval.
- Probability of satisfying an upper requirement limit.
- Per-source variance contribution.
- Dominant-source ordering.

Do not add source variances independently when the sources are correlated. The
correlation matrix is validated for symmetry, bounds, unit diagonal, and
positive definiteness.

## 12. Experimental metrology and virtual instrumentation

`VirtualInstrument` simulates the complete time-domain measurement chain between
physical truth and reported data.

Per-instrument effects include:

- Sampling rate.
- Aperture or exposure averaging.
- Scale error.
- Bias.
- Quadratic nonlinearity.
- First-order dynamic response.
- Transport delay.
- White noise.
- Bias random walk.
- Calibration polynomial.
- ADC quantization.
- Saturation.
- Per-sample uncertainty.
- Deterministic random seed.

`VirtualInstrumentationLaboratory` manages multiple independent instruments,
checks that every channel has a truth callback, acquires synchronized truth-time
intervals, and reports channel samples plus earliest and latest delivery time.

This allows validation to compare measured-to-simulated measurement, rather than
measured-to-ideal truth. The distinction is critical whenever sensors have
filtering, exposure integration, latency, nonlinearity, calibration residuals,
or limited resolution.

## 13. Advanced fracture and progressive failure

### 13.1 Progressive material point

`ProgressiveFailureMaterialPoint` represents a regularized local constitutive
damage state.

Implemented mechanisms:

- Tension and compression strength checks.
- Fibre-direction and matrix-direction mode classification.
- Shear failure.
- Energy-regularized exponential softening.
- Characteristic-length regularization.
- Monotonic damage.
- Residual stiffness.
- Fatigue damage accumulation.
- Paris-law crack growth.
- Critical crack-length failure.
- Dissipated-energy accounting.
- Tangent modulus and degraded stress.

The material point accepts a vector containing up to three normal strains and
additional engineering shear components. It returns the degraded stress vector,
equivalent stress, damage increment, tangent modulus, and failure state.

### 13.2 Mixed-mode cohesive zone

`MixedModeCohesiveZone` implements:

- Independent normal and shear penalty stiffness.
- Normal and shear strengths.
- Quadratic mixed-mode initiation.
- Bilinear softening.
- Mode-I and mode-II fracture energies.
- Benzeggagh-Kenane mixed-mode energy interpolation.
- Irreversible damage.
- Compression contact response.
- Dissipated interface energy.
- Complete separation detection.

Use cohesive interfaces for adhesives, composite delamination, bonded joints,
battery interfaces, laminated glass, and material boundaries where crack path is
known or represented explicitly.

## 14. Integrated scientific workflow

1. Define physical states and residual blocks.
2. Select appropriate residual and update scales.
3. Solve tightly coupled equilibrium with the monolithic solver.
4. Use the hp-DG engine for high-order line or reduced field transport.
5. Resolve nonsmooth impact and friction with complementarity impulses.
6. Generate spatial random fields and condition them on measurements.
7. Propagate and assimilate field ensembles.
8. Invert uncertain parameters or fields with the PDE-constrained solver.
9. Evaluate real-fluid states and phase splits where cubic-EOS accuracy is
   appropriate.
10. Maintain posterior probabilities over competing models.
11. Propagate all uncertainty and error contributors into final decisions.
12. Simulate the laboratory acquisition chain before validation comparisons.
13. Accumulate progressive material and cohesive-interface damage.
14. Store results in the queryable scientific data lake.
15. Verify solver independence and deterministic equivalence through the
   generalized platform services.

## 15. Focused build and test commands

```bash
cmake -S . -B build/scientific-fidelity -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=OFF \
  -DAESIM_MAX_PARALLEL_COMPILES=2

cmake --build build/scientific-fidelity --parallel 2 --target \
  scientific_fidelity_platform_tests

ctest --test-dir build/scientific-fidelity --output-on-failure \
  -R '^scientific_fidelity_platform_(unit_tests|source_regression)$'

python3 tests/scientific_fidelity_platform_source_regression.py .
```

Strict standalone compilation:

```bash
g++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  tests/scientific_fidelity_platform_tests.cpp \
  src/advanced/scientific_fidelity_platform_a.cpp \
  src/advanced/scientific_fidelity_platform_b.cpp \
  src/advanced/scientific_fidelity_platform_c.cpp \
  -o scientific_fidelity_platform_tests

./scientific_fidelity_platform_tests
```

Sanitizer qualification:

```bash
clang++ -std=c++17 -Iinclude -Isrc/advanced \
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wsign-conversion \
  -Wformat=2 -Werror \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  tests/scientific_fidelity_platform_tests.cpp \
  src/advanced/scientific_fidelity_platform_a.cpp \
  src/advanced/scientific_fidelity_platform_b.cpp \
  src/advanced/scientific_fidelity_platform_c.cpp \
  -o scientific_fidelity_platform_tests_sanitize

ASAN_OPTIONS=detect_leaks=1 ./scientific_fidelity_platform_tests_sanitize
```

## 16. Qualification boundaries

The new solvers are executable engineering implementations. Predictive accuracy
still depends on:

- Governing-equation suitability.
- Constitutive-model calibration.
- Mesh and polynomial-order convergence.
- Time-step convergence.
- Nonlinear and linear tolerances.
- Contact-resolution convergence.
- Covariance and correlation evidence.
- Identifiability.
- Property-data validity.
- Laboratory calibration records.
- Independent validation data.
- Declared model-form uncertainty.

The high-order PDE implementation is currently a scalar one-dimensional modal
DG engine. The real-fluid service is a Peng-Robinson mixture implementation, not
a universal reference-property library. The progressive material point is a
regularized local constitutive model, not an automatic replacement for a
fully calibrated three-dimensional anisotropic fracture model. These boundaries
are explicit so that the platform does not overstate scientific qualification.

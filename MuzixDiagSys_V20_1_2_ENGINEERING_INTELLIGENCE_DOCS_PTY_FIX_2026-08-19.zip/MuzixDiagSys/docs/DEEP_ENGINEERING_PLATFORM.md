# Deep Engineering Platform

## Scope

The deep engineering platform adds five executable C++ subsystems to `aesim_advanced`:

1. a unified sparse linear, nonlinear, implicit-time, and adaptive-mesh runtime;
2. rational NURBS and boundary-representation CAD with production surface/volume meshing;
3. transient unstructured CFD, conjugate heat transfer, and partitioned fluid-structure interaction;
4. a full-system heterogeneous virtual ECU with firmware execution, hypervisor budgets, real-time scheduling, cache/memory telemetry, peripherals, secure boot, faults, power, and temperature;
5. solution verification, mesh-convergence assessment, uncertainty propagation, Bayesian calibration, and ensemble digital-twin assimilation.

The public API is in `include/aesim/advanced/deep_engineering_platform.hpp` and is re-exported by `include/aesim/advanced/platform.hpp`.

## Sparse nonlinear and adaptive-mesh runtime

`SparseMatrixCsr` validates and stores matrices in compressed sparse row form. Duplicate assembly triplets are accumulated, rows are sorted, small coefficients may be dropped, and matrix-vector products use deterministic row order.

`UnifiedSparseNonlinearRuntime` provides:

- preconditioned Conjugate Gradient for symmetric positive-definite systems;
- restarted left-preconditioned GMRES for nonsymmetric systems;
- preconditioned BiCGStab;
- no preconditioner, Jacobi, zero-fill incomplete LU, contiguous block Jacobi, overlapping additive Schwarz, and native aggregation algebraic multigrid (AMG);
- residual history, absolute and relative stopping criteria, and evidence hashes;
- Newton iteration with either an analytic sparse Jacobian or a central finite-difference Jacobian;
- selectable Jacobian-Free Newton-Krylov (JFNK) using matrix-free residual directional products and restarted GMRES;
- explicit `SparseSolveWorkspace`/`NonlinearSolveWorkspace` objects that retain safe symbolic/numeric preconditioner state and permit Jacobian reuse inside a nonlinear solve;
- error-controlled FP32 BiCGStab correction with FP64 residual evaluation, iterative refinement, and automatic promotion to the established binary64 solver when acceptance criteria are not met;
- residual-decreasing backtracking line search;
- backward Euler and BDF2 integration of nonlinear ODE systems;
- centroid subdivision of marked tetrahedra, parent tracking, nodal field transfer, boundary reconstruction, volume/quality recomputation, and error-estimate reduction.

Centroid subdivision preserves each original exterior face, so a refined tetrahedron remains face-conforming with an adjacent unrefined tetrahedron.

## Industrial B-rep and NURBS CAD

The CAD kernel implements rational B-spline curves and tensor-product surfaces with validated knot vectors, positive weights, Cox-de Boor basis evaluation, derivatives, and surface normals.

The boundary representation contains explicit vertices, edges, oriented coedges, loops, NURBS faces, material identity, and shell topology. Validation detects disconnected loops, degenerate geometry, open edges, nonmanifold edges, and inconsistent orientation. Healing merges tolerance-equivalent vertices, removes collapsed edges, deduplicates edges, and rebuilds loop references.

The production mesher provides:

- adaptive-density NURBS surface tessellation;
- shared-node deduplication;
- source-face provenance;
- triangle normals and quality;
- closed-shell point classification;
- Cartesian background volume sampling;
- six-tetrahedron cell decomposition;
- unused-node compaction;
- oriented tetrahedra, boundary extraction, volume, and quality metrics.

STEP exchange supports the ISO-10303-21 envelope and an AP242-oriented polyhedral B-rep profile using `CARTESIAN_POINT`, `POLY_LOOP`, `FACE_OUTER_BOUND`, `FACE`, `CLOSED_SHELL`, and `MANIFOLD_SOLID_BREP`. Import accepts compatible point/poly-loop geometry and reconstructs shared B-rep topology.

## Unstructured CFD, CHT, and FSI

`FullUnstructuredCfdChtFsiSolver` constructs owner-neighbour topology directly from tetrahedra. Face area, centroid, outward orientation, cell centroid, volume, and boundary-patch identity are derived once and reused.

The transient solver includes:

- cell-centred velocity, pressure, and temperature;
- viscous momentum diffusion;
- upwind convective transport;
- velocity inlet, pressure outlet, no-slip, slip, fixed-temperature, and heat-flux patches;
- sparse pressure projection with ILU-preconditioned BiCGStab;
- velocity correction from the pressure gradient;
- conductive heat exchange across fluid-fluid, fluid-solid, and solid-solid faces;
- conservative temperature-difference advection;
- one shared thermal field across fluid and solid regions;
- boundary mass and energy audits;
- pressure traction transfer to a solid-only tetrahedral structural model;
- thermal strain and partitioned under-relaxed FSI coupling.

The pressure equation uses the negative integrated Laplacian convention consistently with its divergence source and outlet Dirichlet terms.

## Full-system virtual ECU 3.0

`FullSystemVirtualEcu3` composes the instruction-accurate RV32IM virtual ECU with a deterministic full-system scheduler and SoC services.

Implemented behavior includes:

- RV32 instruction and safety-lockstep cores;
- real-time, DSP, GPU, and NPU task cores;
- hypervisor partitions with cycle budgets and replenishment periods;
- fixed-priority preemptive scheduling with criticality-aware tie breaking;
- periodic releases, deadlines, response times, and overrun detection;
- secure firmware measurements and trusted-hash comparison;
- rollback-policy enforcement;
- CAN-FD, LIN, FlexRay, Ethernet-TSN, SPI, I2C, ADC, PWM, watchdog, and timer queue models;
- L1/L2/DDR traffic accounting and coherence telemetry;
- correctable and uncorrectable ECC, watchdog, lockstep, peripheral-drop, and thermal fault injection;
- per-core dynamic/leakage power and RC thermal integration;
- automatic safe-state entry for safety-critical deadline, boot, ECC, lockstep, watchdog, and thermal failures.

## Credibility, uncertainty, and assimilation

`SolverCredibilityAndDigitalTwinLaboratory` implements:

- ordered three-grid convergence analysis;
- observed spatial order;
- Richardson extrapolation;
- fine-grid Grid Convergence Index;
- asymptotic-range checking;
- weighted L1, L2, Linf, and conservation residuals;
- Latin-hypercube sampling;
- vector-output statistics and percentiles;
- Saltelli pick-freeze first-order Sobol indices;
- random-walk Metropolis Bayesian calibration;
- posterior mean, standard deviation, MAP, and acceptance rate;
- stochastic ensemble Kalman analysis with covariance-derived Kalman gain;
- observation perturbation, covariance inflation, innovation norm, and normalized innovation squared;
- aggregate credibility records with numerical, input, validation, and documented-limitation penalties.

## Build and test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target deep_engineering_platform_tests -j
ctest --test-dir build -R deep_engineering_platform_unit_tests --output-on-failure
```

The dedicated suite exercises every subsystem, including nonlinear sparse solution, BDF2 integration, adaptive tetrahedral refinement, rational quarter-circle NURBS evaluation, closed-shell STEP round trip, volume meshing, transient CFD/CHT/FSI, secure lockstep SoC execution, real-time scheduling, ECC injection, mesh convergence, Sobol analysis, Bayesian calibration, and ensemble data assimilation.

## V17 scalable implicit-solver extensions

V17 adds selectable matrix-free JFNK, reusable sparse/nonlinear workspaces, block-Jacobi, overlapping Schwarz, deterministic aggregation AMG, and FP32 iterative refinement with FP64 residual qualification/automatic promotion. Existing CG/GMRES/BiCGStab/Newton/BDF and None/Jacobi/ILU0 paths remain available; Chapter 79 documents the controls and evidence fields.

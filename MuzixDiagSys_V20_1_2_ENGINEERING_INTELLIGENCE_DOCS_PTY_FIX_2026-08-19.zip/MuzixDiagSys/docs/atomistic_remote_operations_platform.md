# Atomistic, Device, Infrastructure, and Remote-Operations Platform

This module adds ten deterministic engineering laboratories to `aesim_advanced` while preserving the existing public API and target graph.

## Numerical contracts

All public inputs validate finite values, physical ranges, dimensional consistency, resource limits, and index validity. Each result exposes a canonical JSON-compatible document and SHA-256 evidence identifier. Algorithms avoid external services and optional accelerator runtimes, so identical inputs produce deterministic reference results.

## Laboratories

### Atomistic, molecular, and quantum materials

The atomistic engine uses velocity-Verlet integration, periodic minimum-image interactions, mixed Lennard-Jones and electrostatic forces, Berendsen temperature control, virial properties, radial-distribution analysis, mean-square-displacement diffusion, and a distance-dependent tight-binding Hamiltonian. A symmetric Jacobi eigensolver produces electronic eigenvalues, density of states, and half-filling band-gap estimates.

### Semiconductor TCAD and reliability

The TCAD laboratory solves a one-dimensional electrostatic drift-diffusion model through damped Gummel iteration. It produces potential, carrier concentration, electric field, terminal current, convergence residuals, and bias sweeps. Reliability calculations cover bias-temperature instability, hot-carrier stress, time-dependent dielectric breakdown, radiation exposure, mobility degradation, and remaining-life estimates.

### High-order adaptive PDE and mesh platform

The transport engine uses conservative second-order MUSCL reconstruction with limited slopes, upwind advection, explicit diffusion and reaction, CFL enforcement, h-refinement, conservative coarsening, modal coefficients, and conservation audits. The mesh utility performs conforming midpoint refinement of triangular seed meshes.

### Explicit crash and human-body FE

The explicit solver advances lumped nodal dynamics with tetrahedral edge-based constitutive response, yielding, isotropic hardening, progressive failure, general rigid-plane contact, damping, friction, energy accounting, and anatomical-region acceleration tracking. Injury outputs include HIC proxy, brain rotational criterion, Nij, chest deflection, and femur load.

### Fire, smoke, explosion, and suppression

A two-dimensional finite-volume reaction/transport model evolves fuel, oxygen, temperature, smoke, toxic products, diffusion, wind advection, radiative loss, enclosure pressure, ventilation relief, and spatial suppression sources. Suppression supports cooling and oxygen displacement.

### Vibroacoustics and computational aeroacoustics

The frequency-domain laboratory couples structural and cavity dynamic stiffness matrices, computes generalized natural frequencies, solves complex frequency responses, projects microphone pressure, and adds compact far-field dipole sources. Results include SPL, peak frequency, loudness, and sharpness estimates.

### Road, pavement, bridge, and infrastructure twin

The infrastructure twin evaluates multilayer pavement strains, fatigue, viscoelastic rutting, surface temperature, drainage, water-film depth, salt-modified icing, friction, and moving-load bridge response using modal integration. Serviceability is qualified against deflection, fatigue, and rutting limits.

### Non-destructive evaluation and metrology

The NDE engine creates noisy parallel-beam X-ray projections, filtered back-projection reconstructions, pulse-echo ultrasonic B-scans, multimodal defect indications, reconstruction error, dimensional bias, probability of detection, and false-call probability.

### RTL-to-binary co-verification

The verification engine evaluates bounded-width RTL logic graphs, executes a deterministic binary instruction model, exhaustively compares all configured input combinations, performs bounded sequential checks, audits register and branch safety, reports counterexamples, estimates worst-case steps, and runs deterministic fault-detection campaigns.

### Remote assistance and teleoperation

The control-center model includes uplink/downlink latency, jitter, bandwidth delay, loss, outages, handovers, operator queues, workload-dependent reaction time, service duration, command envelopes, time-to-collision checks, minimal-risk maneuvers, service-level metrics, and utilization.

## Integration

Include the module directly:

```cpp
#include "aesim/advanced/atomistic_remote_operations_platform.hpp"
```

It is also exported from:

```cpp
#include "aesim/advanced/platform.hpp"
```

The regression target is `atomistic_remote_operations_platform_tests` and the CTest name is `atomistic_remote_operations_platform_unit_tests`.

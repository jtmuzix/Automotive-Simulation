# PIC/PIE Build-System Correction — 2026-07-10

## Symptom

Clang with `lld` could fail while linking `muzixdiagsys` with diagnostics such as:

```text
relocation R_X86_64_32 cannot be used against symbol ...; recompile with -fPIC
```

The affected relocations could originate from `muzixdiagsys.cpp.o` or members of
`libaesim_core.a`, `libaesim_professional.a`, and `libaesim_industrial.a`.

## Root cause

The final executable could be linked as a position-independent executable by a
distribution or packaging toolchain, while the project did not establish a
project-wide position-independent-code policy. Static library objects were
therefore allowed to compile without `-fPIC`, and `muzixdiagsys.cpp` was allowed
to compile without `-fPIE`.

GNU `ld` may accept some relocation combinations that `lld` rejects. The
rejection is correct: all objects contributing to a PIE must use compatible
position-independent relocations.

## Correction

The CMake build now:

- enables `AESIM_ENABLE_POSITION_INDEPENDENT_CODE` by default;
- sets `CMAKE_POSITION_INDEPENDENT_CODE=ON` before creating targets;
- applies `POSITION_INDEPENDENT_CODE=TRUE` to every configured target;
- enables CMake policy `CMP0083` for executable PIE link handling;
- verifies Linux compiler/linker PIE support with `CheckPIESupported`;
- compiles static archive members with `-fPIC`;
- compiles executables with `-fPIE` and links them with `-pie`;
- includes a permanent regression that checks the exact affected objects and
  validates the final ELF type;
- registers the distributed-worker regression only when `aesim_study_worker`
  is actually built, allowing `BUILD_TESTING=ON` with `AESIM_BUILD_TOOLS=OFF`.

## Required clean rebuild

Delete the existing build directory. CMake cannot change relocations already
stored in old object files or static archives.

```bash
rm -rf build/clang-lld

CC=clang CXX=clang++ cmake -G "Unix Makefiles" -S . -B build/clang-lld \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_POSITION_INDEPENDENT_CODE=ON \
  -DCMAKE_EXE_LINKER_FLAGS=-fuse-ld=lld \
  -DCMAKE_SHARED_LINKER_FLAGS=-fuse-ld=lld

cmake --build build/clang-lld --parallel
ctest --test-dir build/clang-lld --output-on-failure
```

Ninja is also supported by replacing `-G "Unix Makefiles"` with `-G Ninja`.

## Validation

The correction was validated with:

- Clang 17 and `lld` 17 using Unix Makefiles;
- Clang 17 and `lld` 17 using Ninja;
- GCC 14.2 using Ninja;
- all 45 registered tests;
- direct inspection of `compile_commands.json`;
- direct ELF verification that `muzixdiagsys` is `ET_DYN`.

## 2026-07-12 next-generation vehicle-depth integration

The build fix remains valid. The newly added vehicle-depth sources are registered in `aesim_industrial` and follow the same position-independent-code and shared-component linkage policy.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


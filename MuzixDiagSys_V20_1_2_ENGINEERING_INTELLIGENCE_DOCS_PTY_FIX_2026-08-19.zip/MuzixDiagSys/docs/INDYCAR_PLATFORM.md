# IndyCar IR-18 Engineering and Competition Platform

This additive C++17 platform implements ten IndyCar-specific systems using versioned rule profiles and event parameters so technical bulletins can change limits without modifying solver code.

## Implemented laboratories

1. **IR-18 vehicle and rules:** circuit-specific minimum mass, driver-equivalency ballast, fuel capacity, wheelbase, height, engine displacement and speed, boost, approved wheels and parts, seals, power-steering prohibition, keel ballast, violations, margins, and SHA-256 evidence.
2. **Oval dynamics:** banking, asymmetric load transfer, crossweight, stagger, tyre utilization, right-side loads and temperatures, manual steering torque, aero heave, bumps, bottoming, stability, and lap histories.
3. **Pack aerodynamics:** longitudinally decaying and laterally spreading wakes, tow gain, dirty-air downforce and balance loss, drag reduction, side draft, wall effects, turbulence, crosswind, and cooling restriction.
4. **Driver setup controls:** rate-limited weight-jacker travel, spring-perch load transfer, anti-roll-bar settings, balance shift, mechanical stops, and explicit rejection of automatic or external commands.
5. **Hybrid and push-to-pass:** event energy and power limits, torque-limited regeneration, state-of-charge bounds, activation and total-time limits, timing-and-scoring interlocks, start and command-blue lockouts, boost state, and road/street self-start safety logic.
6. **Firestone tyre strategy:** entrant and corner serial identity, compound authorization, no-warmers and no-treatment rules, cold first-lap grip, heat cycles, tread, structural health, mandatory-new-set constraints, primary/alternate use, and bounded exhaustive allocation.
7. **Indianapolis 500:** rookie-orientation stages, no-tow speed, wind and temperature sensitivity, aero-trim search, four-lap qualifying average, completion and advancement probability, fuel windows, cautions, pit stops, and expected race time.
8. **Qualification:** road/street group advancement, interference penalties, technical eligibility, finals and elimination; oval multi-lap averages, time withdrawal, technical failure, field-size bumping, and classified order.
9. **Race control:** chronological caution, pit-lane, wave-around, one-to-go, restart, red/green, penalty, retirement, and lap events; official order, closed-pit penalties, timeline snapshots, and evidence.
10. **Engine and hybrid pools:** sealed serialized assets, manufacturer pairing, accumulated mileage, life limits, Indianapolis severity, event importance, failure probability, free allocations, unauthorized-change penalties, assignments, and final mileage.

## Build

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target indycar_platform_tests -j
ctest --test-dir build -R indycar_platform_unit_tests --output-on-failure
```

The reduced-order oval and pack-aero solvers are intended for rapid setup, strategy, and uncertainty studies. Their state histories can be passed to the repository's existing multibody, tyre, CFD, thermal, reliability, and evidence laboratories for higher-fidelity campaigns.

# Must-Have High-Fidelity Platform

The `aesim::advanced` library exposes six additive engineering laboratories through:

```cpp
#include "aesim/advanced/must_have_platform.hpp"
```

The implementation is self-contained, deterministic by default, and preserves every pre-existing MuzixDiagSys interface.

## Full-wave electromagnetic, antenna, and EMC laboratory

`FullWaveElectromagneticLaboratory` implements a three-dimensional finite-difference time-domain Maxwell solver. The solver advances all six electric and magnetic field components, supports spatially varying relative permittivity, permeability, and conductivity, enforces the three-dimensional Courant limit, applies graded lossy absorbing boundary layers, injects pulsed or continuous-wave electric sources, records time-domain field probes, calculates discrete-frequency phasors, and reports stored and dissipated electromagnetic energy.

The same laboratory contains a thin-wire electric-field integral-equation solver. It assembles and solves a complex method-of-moments impedance matrix, includes conductor surface resistance, calculates feed impedance, accepted and radiated power, conductor loss, radiation resistance, efficiency, and an axisymmetric far-field power pattern.

The EMC cable-coupling model calculates open-circuit field pickup, shield current, transfer-impedance coupling, terminated load voltage, and coupled power. It is intended for deterministic engineering studies and does not claim accredited regulatory certification.

## Native CPU, CUDA, multi-GPU, and HPC execution

`NativeHpcExecutor` always provides a native multithreaded CPU backend. On Linux systems with a CUDA driver, it dynamically loads `libcuda.so.1`, enumerates physical CUDA devices, creates device contexts, loads an embedded PTX double-precision AXPY kernel, allocates device memory, transfers operands, launches the kernel, synchronizes, and copies results back. When multiple CUDA devices are available, the input is partitioned across all selected devices and executed concurrently.

The CPU backend provides deterministic partitioning, a compensated fixed-block reduction, exception-safe parallel loops, and numerical comparison against scalar reference results. CUDA is an optional runtime capability rather than a build dependency; systems without a CUDA driver execute the complete CPU implementation.

## Exact analytic CAD, CSG, volume meshing, and unstructured multiphysics

`ExactCadCsgModel` stores analytic boxes, spheres, and cylinders and evaluates union, intersection, and difference through exact signed-distance Boolean composition. Point membership and solid bounds remain analytic.

The volume mesher samples the exact solid on a controlled Cartesian lattice, retains cells whose centroids are inside the analytic CSG solid, decomposes each retained cell into conforming tetrahedra, compacts unused nodes, extracts boundary faces by topological incidence counting, and reports physical volume and tetrahedral quality.

`UnstructuredMultiphysicsSolver` implements:

- steady scalar heat conduction on linear tetrahedra;
- spatial material assignment;
- volumetric and nodal heat sources;
- Dirichlet temperature constraints;
- three-dimensional small-strain isotropic elasticity;
- thermal strain;
- nodal loads and directional supports;
- tetrahedral stress recovery;
- von Mises stress, safety factor, displacement, and residual auditing.

Dense pivoted linear algebra is used as a deterministic reference path suitable for small and medium qualification models.

## Production virtual ECU 2.0

`ProductionVirtualEcu2` composes the instruction-accurate RV32IM core with a production-oriented multicore environment:

- multiple executable cores;
- coherent shared physical memory;
- virtual-to-physical mappings with read/write/execute permissions;
- direct-mapped data-cache accounting;
- ELF32 little-endian RISC-V program loading using `PT_LOAD` segments;
- deterministic round-robin scheduling;
- safety-lockstep register and program-counter comparison;
- physical DMA transfers;
- CAN/CAN-FD frame arbitration and delivery;
- Ethernet frame delivery;
- instruction, cache, DMA, network, MMU-fault, and lockstep telemetry.

The ELF loader validates the file class, endianness, machine type, program-header table, segment bounds, memory sizes, and entry point before reconstructing the target core.

## Advanced tire, terrain, and adverse-weather laboratory

`AdvancedTireTerrainLaboratory` models a flexible circumferential ring with per-node radial displacement and velocity, radial stiffness, belt bending, damping, pressure-dependent stiffness, road-profile forcing, transient slip relaxation, combined longitudinal and lateral saturation, pneumatic trail, rolling resistance, tread heating, and wear.

Environment models include asphalt, concrete, gravel, sand, mud, snow, and ice. Deformable terrain uses Bekker pressure-sinkage and Janosi-Hanamoto shear behavior. Water-film and pressure-dependent hydroplaning reduce available friction; snow, ice, road temperature, tread temperature, tread depth, puncture, and inflation loss further modify forces and contact behavior.

## Learned-component robustness and neural safety verification

`NeuralSafetyVerifier` supports validated dense feed-forward neural networks with linear, ReLU, and tanh activations. It provides:

- exact forward evaluation;
- analytic input gradients;
- interval bound propagation;
- branch-and-bound classification robustness verification;
- concrete counterexample search;
- projected-gradient adversarial attacks under an L-infinity budget;
- split-conformal regression intervals;
- interval closed-loop reachability for neural controllers and linear plants;
- exact affine closed-loop contraction when the controller is a single linear layer.

Robustness evidence includes explored and pending boxes, certified margins, counterexamples, and a canonical SHA-256 evidence seal.

## Build and validation

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target must_have_platform_tests -j
ctest --test-dir build -R must_have_platform_unit_tests --output-on-failure
```

The dedicated test executes all six domains, including a full FDTD run, dipole MoM solve, deterministic HPC kernels, CSG subtraction and tetrahedral FEA, RV32 firmware and ELF execution, coherent MMU/DMA/network transactions, flexible tire dynamics on dry/wet/deformable terrain, neural robustness proof, adversarial search, conformal calibration, and closed-loop reachability.

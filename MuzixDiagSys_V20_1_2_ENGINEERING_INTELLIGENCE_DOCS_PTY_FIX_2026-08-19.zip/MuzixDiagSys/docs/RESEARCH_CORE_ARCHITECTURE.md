# MuzixDiagSys Modular Research Core Architecture

## Scope

This document describes the production implementation of the modular simulation core introduced in the 2026-07-09 research-grade expansion. The implementation is additive: the established terminal simulator, all command families, native plugins, configuration formats, diagnostics, CAN/DBC support, scenario execution, and legacy physical models remain available.

The new `aesim_core` static library provides six independently testable capabilities:

1. deterministic multi-rate scheduling;
2. cylinder-resolved combustion;
3. dynamic intake/exhaust/turbocharger gas-path simulation;
4. formal statistical validation and uncertainty quantification;
5. bounded hybrid parameter estimation;
6. reproducible experiment capture with cryptographic artifact verification.

## Source layout

```text
include/aesim/core/
├── multirate_kernel.hpp
├── cylinder_combustion.hpp
├── gas_path.hpp
├── validation.hpp
├── uncertainty.hpp
├── calibration.hpp
├── provenance.hpp
├── research_core.hpp
└── research_workflows.hpp

src/core/
├── multirate_kernel.cpp
├── cylinder_combustion.cpp
├── gas_path.cpp
├── validation.cpp
├── uncertainty.cpp
├── calibration.cpp
├── provenance.cpp
├── research_core.cpp
└── research_workflows.cpp
```

`muzixdiagsys` links against `aesim_core`; the original executable remains the compatibility and orchestration layer. The library has no dependency on the terminal UI.

## Deterministic multi-rate kernel

`DeterministicMultirateKernel` stores time as signed 64-bit integer nanoseconds. This removes cumulative floating-point deadline drift and gives every task a stable dispatch key:

1. next deadline;
2. explicit priority;
3. immutable registration order.

A task may change period or enabled state at runtime. The kernel records invocation count, deadline misses, execution time, and last/next release. A single `advance_to()` operation dispatches every release up to the requested timestamp in deterministic order.

Default research-core task rates are configurable:

- gas path: 1 ms;
- combustion: 5 ms, automatically bounded by engine-cycle duration;
- diagnostics/conservation audit: 10 ms.

The core supports deterministic reset and direct configuration through `core period` commands.

## Cylinder-resolved combustion

`CylinderResolvedCombustionModel` solves each cylinder independently over a complete four-stroke cycle. The implementation includes:

- slider-crank volume and derivative;
- first-law pressure integration;
- single/double-Wiebe-style mass-fraction-burned progression;
- configurable spark timing and burn duration;
- residual gas and EGR dilution;
- wall heat transfer;
- blow-by mass loss;
- deterministic cylinder-to-cylinder variation;
- indicated work, IMEP, torque, and efficiency;
- CA10, CA50, and CA90;
- peak pressure and maximum pressure-rise rate;
- exhaust-gas temperature estimate;
- coefficient of variation of IMEP;
- knock integration and ringing indicator;
- per-crank-angle CSV trace export.

The model is coupled to the legacy plant by a configurable blend coefficient. `core coupling 0` leaves the existing plant fully authoritative; `core coupling 1` applies the modular core output at full weight.

## Dynamic gas path

`LumpedGasPathModel` represents intake and exhaust manifolds as finite control volumes and advances their mass and internal energy. It includes:

- compressible throttle flow;
- compressor corrected-flow and efficiency map approximations;
- intercooler pressure loss and effectiveness;
- engine pumping/volumetric-efficiency demand;
- EGR recirculation;
- exhaust manifold dynamics;
- turbine flow and efficiency;
- wastegate flow;
- turbocharger shaft inertia and friction;
- compressor/turbine power balance;
- surge/choke margin indicators;
- mass- and energy-balance residuals.

Operating points outside supported numerical or physical limits are clamped and surfaced through diagnostics rather than allowed to create non-finite state.

## Validation framework

`ValidationFramework` consumes CSV datasets containing independent input columns, `observed.<metric>` columns, and optional `sigma.<metric>` columns. A predictor callback is evaluated for every record. Per-metric results include:

- sample count;
- bias;
- MAE;
- RMSE and normalized RMSE;
- maximum absolute error;
- residual standard deviation;
- coefficient of determination (`R²`);
- 95% confidence interval for mean residual;
- lag-one residual autocorrelation;
- reduced chi-square when measurement uncertainty is supplied;
- requirement-level pass/fail evaluation.

Results can be rendered as terminal text or exported as Markdown and JSON.

The bundled `data/research_validation_reference.csv` is generated deterministically by `research_reference_generator`. It is a regression and integration reference, not evidence of independent physical validation. Physical validation requires measured dyno, cylinder-pressure, turbo-map, emissions, or vehicle data from a traceable source.

## Uncertainty quantification

`UncertaintyAnalyzer` supports uniform, normal, and log-normal uncertain parameters. It implements:

- deterministic Latin-hypercube sampling;
- seeded reproducibility;
- mean, variance, standard deviation, min/max, and quantiles;
- 95% confidence intervals;
- Pearson sensitivity coefficients;
- standardized-regression sensitivity coefficients;
- Saltelli sampling;
- first-order and total-order Sobol indices;
- CSV and JSON exports.

The integrated research workflow varies combustion, heat-transfer, burn-duration, compressor, turbine, intercooler, and mechanical-efficiency parameters.

## Calibration and parameter estimation

`CalibrationOptimizer` uses a bounded hybrid algorithm:

1. Differential Evolution explores the global parameter domain.
2. Levenberg-Marquardt performs local least-squares refinement.
3. Huber robust loss limits the effect of outliers.
4. A finite-difference Jacobian supplies local sensitivity.
5. The final normal matrix provides covariance, parameter standard errors, correlation estimates, and a condition indicator.

The integrated calibration fits seven physical and coupling parameters against all compatible observations in a validation dataset and applies the fitted values directly to the live modular core.

## Reproducible experiments and provenance

`ExperimentManager` creates a self-contained run directory with:

- run identifier and UTC timestamps;
- model and source revision labels;
- compiler, platform, and executable identity;
- canonical configuration SHA-256;
- deterministic seed;
- tags for engine, vehicle, fuel, and fidelity;
- timestamped telemetry CSV;
- event log CSV;
- user-registered artifacts copied into a content-addressed `artifacts/` directory;
- a packaged copy of the executing binary when its path is available;
- run-relative artifact paths for portability;
- SHA-256 and size for every artifact;
- final summary metrics;
- canonical JSON manifest.

`experiment verify <run_directory>` resolves only run-relative v2 artifact paths, rejects traversal outside the package, recomputes hashes and sizes, and reports any missing or modified content. A finalized run directory can be moved to another location and still verifies without the original external artifact files.

## Command surface

```text
core status
core on|off
core reset
core coupling <0..1>
core period gas_path|combustion|diagnostics <seconds>
core export <state.json>
core trace <cylinder_trace.csv>

validation research run [dataset.csv] [report.md|report.json]
validation research status

uncertainty research run [samples] [seed] [output.csv|output.json]
uncertainty research sobol [base_samples] [seed] [output.json]
uncertainty research status

calibrate research fit [dataset.csv] [global_generations] [output.json]
calibrate research status

experiment begin <name> [root_directory] [seed]
experiment event <category> <message>
experiment artifact <path> [role]
experiment end
experiment abort [reason]
experiment verify <run_directory>
experiment status
```

## Dataset schema

A validation/calibration CSV may contain arbitrary scalar inputs recognized by the workflow and one or more observations:

```csv
rpm,load,throttle,ambient_pressure_kpa,ambient_temp_c,observed.torque_nm,sigma.torque_nm,observed.map_kpa
2500,0.55,0.60,101.325,25.0,245.8,3.0,151.2
```

Recognized observations currently include torque, power, MAP, MAF, peak cylinder pressure, CA50, exhaust temperature, turbo speed, intake temperature, and conservation scores.

## Build and test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

Sanitizer build:

```bash
cmake -S . -B build-sanitize \
  -DCMAKE_BUILD_TYPE=Debug \
  -DAESIM_ENABLE_SANITIZERS=ON
cmake --build build-sanitize --parallel
ctest --test-dir build-sanitize --output-on-failure
```

## Scientific interpretation

Passing the bundled regression reference demonstrates deterministic software behavior, interface integrity, and parameter-recovery capability. It does not establish predictive accuracy for a production engine. Independent physical validation must use traceable measurements, declared instrumentation uncertainty, held-out operating points, and acceptance requirements selected before evaluating results.

## 2026-07-12 next-generation vehicle-depth integration

Research workflows can directly access all depth subsystems through the public C++ API and use checkpoint branching and fidelity transitions in repeatable experiments.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


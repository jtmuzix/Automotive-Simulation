# MuzixDiagSys transmission, preset, output, and manual revision

**Revision date:** 2026-07-11

## Implemented behavior

- Automatic-transmission anti-hunting control with projected lower/higher gear RPM checks, shift-request dwell, post-shift temporal inhibit, spatial speed/throttle hysteresis, redline override, and distinct high-load/coastdown schedules.
- TCM diagnostics expose shift reason, pending gear, pending dwell, and remaining anti-hunt inhibit.
- Eight additional real-world-based engine presets and eight matching vehicle presets.
- Engine/vehicle lists show full names, canonical keys, copyable exact commands, public-data basis, and major calibration data.
- Application and status reports repeat the full display name, key, and exact command.
- Human-readable status includes speed in m/s, mph, and km/h while retaining established parser token order.
- Established machine-readable vehicle calibration markers remain available for automation compatibility.
- `--advanced-help` includes generated exact-command sections for every engine and vehicle preset.
- The comprehensive manual includes the supplied advanced-help transcript verbatim, expanded preset and transmission workflows, official data-source notes, updated command reference, QA coverage, references, and glossary terms.

## New canonical engine commands

```text
engine toyota_gr_corolla_g16e_gts
engine honda_civic_type_r_k20c1
engine bmw_m3_competition_s58
engine mazda_mx5_skyactiv_g_2.0
engine ram_hurricane_ho_3.0
engine gm_duramax_lz0_3.0
engine porsche_911_carrera_3.0_boxer
engine subaru_wrx_fa24_dit
```

## New canonical vehicle commands

```text
vehicle toyota_gr_corolla_6mt
vehicle honda_civic_type_r_fl5_6mt
vehicle bmw_m3_competition_xdrive_8at
vehicle mazda_mx5_nd_6mt
vehicle ram_1500_rho_hurricane_8at
vehicle chevrolet_silverado_1500_duramax_10at
vehicle porsche_911_carrera_pdk
vehicle subaru_wrx_6mt
```

## Validation

- Complete Release build graph succeeded.
- 65 registered CTest targets passed on the final source state.
- New `automatic_throttle_sweep_anti_hunt_regression` covers constant-throttle operation across 6-, 8-, and 10-speed configurations.
- New `preset_readability_regression` verifies display names, canonical keys, exact commands, labels, source basis, units, and diesel-fuel disclosure.
- Existing WOT, high-load hysteresis, coastdown, drivetrain acceleration, GTI data-marker, PTY, golden-frame, fuzz, plugin, API, federation, platform, command-surface, and manual regressions pass.
- All Python regression scripts compile successfully.

## 2026-07-12 next-generation vehicle-depth integration

The transmission preset revision remains intact; the new runtime consumes the existing requested wheel torque and gear ratio without altering preset keys.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


# MuzixDiagSys SocketCAN OBD-II Responder

The same operator material is integrated into Section 17 of `MUZIXDIAGSYS_USER_MANUAL.md` and the regenerated `MUZIXDIAGSYS_USER_MANUAL.pdf`. This guide reflects the 2026-07-13 authoritative-diagnostics revision.

## Purpose

MuzixDiagSys can operate as the vehicle side of an ISO 15765-4 diagnostic connection. A real OBD-II scan tool can send functional or physical requests over an isolated CAN bench bus, and MuzixDiagSys responds as an engine ECU using live simulation state.

The responder is separate from the existing OBD-II tester/client. The client queries real ECUs; the responder emulates an ECU.

The responder does not own a private PID, DTC, or VIN implementation. It delegates diagnostic semantics to `aesim::industrial::DiagnosticService`, the same authority used by the CLI, guarded gateway, ELM327-compatible adapter, DoIP, SOVD, and tests. The responder retains transport and session state locally but refreshes its diagnostic snapshot through one synchronization path.

## Safety boundary

The SocketCAN responder is deliberately disarmed whenever a real interface is selected or its CAN identifiers are changed. It can be armed only with:

```text
industrial experience lab obd-server arm isolated-bench
```

Use responder mode only on an isolated bench network. Do not connect the emulator to a road vehicle, because a real ECU and MuzixDiagSys could answer the same functional request and create ambiguous or disruptive traffic.

The normal high-speed CAN OBD connector pins are:

| Pin | Function |
|---:|---|
| 4 | Chassis ground |
| 5 | Signal ground |
| 6 | CAN High |
| 14 | CAN Low |
| 16 | Fused bench supply for the scan tool |

Use a suitable CAN transceiver, correct termination, and an independently fused bench supply. MuzixDiagSys does not configure physical termination or supply power to the reader.

## Default addressing

```text
Functional request: 0x7DF
Physical request:   0x7E0
Engine response:    0x7E8
```

All three identifiers are configurable, including 29-bit identifiers:

```text
industrial experience lab obd-server ids 7DF 7E0 7E8
```

## Starting a physical responder

Configure the Linux CAN interface outside MuzixDiagSys. A typical classical-CAN setup is:

```bash
sudo ip link set can0 down
sudo ip link set can0 type can bitrate 500000 restart-ms 100
sudo ip link set can0 up
ip -details link show can0
```

Then start MuzixDiagSys:

```text
industrial experience lab obd-server interface socketcan can0 classic
industrial experience lab obd-server arm isolated-bench
industrial experience lab obd-server start
industrial experience lab obd-server status
```

Stop and disarm it with:

```text
industrial experience lab obd-server stop
industrial experience lab obd-server disarm
```

### Lifecycle and restart guarantees

Responder lifecycle transitions are serialized. Concurrent calls to `start()`
are idempotent and produce one worker; concurrent calls to `stop()` safely join
that worker once. A worker that exits after a transport or protocol exception is
collected before a later restart, so restart never assigns over a still-joinable
`std::thread`. Transport replacement and configuration changes are also
serialized against start/stop. As before, configuration changes while the
responder is actively running are rejected with `std::logic_error`.

The responder never detaches its worker during an error path. This preserves the
object-lifetime guarantee that no background thread may continue referencing a
destroyed responder.

## Testing without hardware

Responder protocol behavior can be exercised through the same state machine without transmitting on a physical bus:

```text
industrial experience lab obd-server interface loopback
industrial experience lab obd-server identity MUZIXDIAGSYS00001 MUZIXDIAGSYS-SERVER-CAL MUZIXDIAGSYS SERVER ECU
industrial experience lab obd-server simulate-request functional 01 0C
industrial experience lab obd-server simulate-request physical 09 02
```

`simulate-request` automatically sends a tester Flow Control frame when the response is multi-frame, so VIN and long DTC responses are fully displayed.

## Live data binding

The responder snapshot is updated from the active MuzixDiagSys plant. It exposes:

- Engine speed
- Vehicle speed
- Calculated load
- Coolant and intake temperatures
- Manifold and barometric pressure
- Mass-air flow
- Throttle and accelerator position
- Lambda
- Catalyst temperature
- Module voltage
- Fuel rate and fuel level
- Commanded, actual, and reference torque
- Odometer

Diagnostic identity, readiness, DTC, and freeze-frame state are retained while those dynamic values change.

## DTC management

Three independent DTC stores are implemented:

```text
industrial experience lab obd-server dtc add stored P0301
industrial experience lab obd-server dtc add pending P0299
industrial experience lab obd-server dtc add permanent U0100
```

Remove or clear codes with:

```text
industrial experience lab obd-server dtc remove pending P0299
industrial experience lab obd-server dtc clear stored
industrial experience lab obd-server dtc clear all
```

The first clean-to-confirmed-fault transition captures a pre-fault freeze-frame snapshot. Live updates do not rewrite it while confirmed faults remain. When the confirmed list becomes empty, the snapshot resets; the next independent episode captures new data. Mode 04 clears confirmed and pending DTCs but deliberately retains permanent DTCs, and UDS service `14` acts on the same authoritative fault store.

Mode 04 can be disabled:

```text
industrial experience lab obd-server mode04 deny
```

A denied clear request returns negative response `7F 04 22`.

## Readiness and MIL

Configure non-continuous monitor support and completion masks:

```text
industrial experience lab obd-server readiness E1 C1 spark
```

Arguments are:

1. Supported-monitor byte in hexadecimal.
2. Complete-monitor byte in hexadecimal.
3. `spark` or `compression` ignition.

Mode 01 PID 01 reports the MIL, confirmed-DTC count, ignition type, supported monitors, and incomplete monitors.

## Identity

```text
industrial experience lab obd-server identity \
  MUZIXDIAGSYS00001 \
  MUZIXDIAGSYS-SERVER-CAL \
  MUZIXDIAGSYS SERVER ECU
```

Mode 09 provides:

- PID 00: supported vehicle-information items
- PID 02: VIN
- PID 04: calibration identifier
- PID 06: deterministic calibration verification number
- PID 0A: ECU name

## ISO-TP behavior

The responder implements:

- Single Frames
- First Frames
- Consecutive Frames
- Flow Control: Continue To Send, Wait, and Overflow handling
- Configurable block size
- Configurable STmin
- Sequence validation
- Bounded request reassembly
- Flow-control timeout
- Functional and physical requests
- Classical CAN and CAN-FD escape-length single frames
- 12-bit and 32-bit first-frame lengths
- Normal and extended addressing
- Shared endpoint behavior with the guarded gateway
- Optional Linux kernel ISO-TP transport for supported SocketCAN environments

Timing is configured with:

```text
industrial experience lab obd-server timing \
  <p2_ms> <flow_timeout_ms> <stmin_byte> <block_size> [maximum_responses_per_second]
```

Example:

```text
industrial experience lab obd-server timing 8 750 0 0 100
```

## Supported OBD services

| Mode | Function |
|---:|---|
| 01 | Current powertrain data and readiness |
| 02 | Freeze-frame PID data |
| 03 | Confirmed DTCs |
| 04 | Clear confirmed and pending DTCs |
| 06 | Onboard monitor result |
| 07 | Pending DTCs |
| 09 | Vehicle information |
| 0A | Permanent DTCs |

Unsupported services and PIDs return standards-style negative responses.

## Access and padding controls

Limit accepted request classes:

```text
industrial experience lab obd-server accept functional
industrial experience lab obd-server accept physical
industrial experience lab obd-server accept both
```

Configure frame padding:

```text
industrial experience lab obd-server padding 00
```

## Audit and statistics

```text
industrial experience lab obd-server stats
industrial experience lab obd-server log 50
industrial experience lab obd-server export-log responder.jsonl
industrial experience lab obd-server log-clear
```

The JSON Lines audit schema is `aesim.obd-responder-log.v1` and records timestamp, direction, CAN identifier, payload, and event.

## Direct can-utils check

On a virtual or isolated CAN interface, send a Mode 01 RPM request:

```bash
cansend can0 7DF#02010C0000000000
candump can0
```

MuzixDiagSys should answer from `0x7E8`. A VIN request begins with:

```bash
cansend can0 7E0#0209020000000000
```

The first response is an ISO-TP First Frame. The tester must then send Flow Control on `0x7E0`; ordinary commercial readers and ISO-TP-capable tools do this automatically.

## Hardware qualification note

The responder uses the native Linux SocketCAN transport and shared ISO-TP and diagnostic services and has compile-time and protocol-level qualification. The delivery environment did not permit creation of a `vcan` interface and had no physical CAN adapter, so adapter-specific behavior, bus termination, bitrate, reader protocol detection, and electrical integration must be verified on the target bench.

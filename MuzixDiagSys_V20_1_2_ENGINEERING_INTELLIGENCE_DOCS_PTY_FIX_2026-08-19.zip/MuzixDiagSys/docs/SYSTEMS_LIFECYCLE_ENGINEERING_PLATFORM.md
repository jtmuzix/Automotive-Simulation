# Systems and Lifecycle Engineering Platform

## Scope

This additive C++17 platform extends MuzixDiagSys with ten integrated engineering
capabilities:

1. SysML v2 and digital-thread integration.
2. Automated calibration and system identification.
3. SPICE, EMC, and wiring-harness co-simulation.
4. Cell-resolved battery abuse and thermal-runaway propagation.
5. E/E architecture synthesis.
6. Distributed shared-world execution.
7. Spectral synthetic-data generation.
8. City-scale infrastructure simulation.
9. Crash and occupant biomechanics.
10. Lifecycle and circular-economy analysis.

All APIs are available from:

```cpp
#include "aesim/advanced/platform.hpp"
```

The implementation is contained in four cohesive modules:

```text
include/aesim/advanced/digital_thread_calibration.hpp
include/aesim/advanced/electrical_battery_architecture.hpp
include/aesim/advanced/world_spectral_city.hpp
include/aesim/advanced/crash_lifecycle.hpp
src/advanced/digital_thread_calibration.cpp
src/advanced/electrical_battery_architecture.cpp
src/advanced/world_spectral_city.cpp
src/advanced/crash_lifecycle.cpp
```

## 1. SysML v2 and digital thread

`SysmlV2DigitalThread` stores typed elements and relationships using stable IDs,
qualified names, semantic versions, attributes, and optional artifact SHA-256
identities. Supported element classes include packages, parts, requirements,
interfaces, ports, actions, states, constraints, test cases, hazards, evidence,
and artifacts. Supported relationship classes include containment, satisfy,
verify, refine, trace, allocate, interface, derive, and mitigate.

The implementation provides:

- Transactional JSON import: an invalid model never partially replaces the
  currently loaded model.
- Canonical JSON export with SysML v2-oriented `@id` and `@type` fields.
- SysML v2-style textual export.
- Endpoint validation and duplicate identity rejection.
- Qualified-name uniqueness checks.
- Containment-cycle detection.
- Artifact hash validation.
- Requirement satisfaction and verification coverage.
- Hazard-mitigation coverage.
- Directional transitive tracing.
- Bidirectional change-impact analysis.
- Immutable baselines with canonical SHA-256 identities.
- Baseline delta calculation for elements and relationships.

A baseline includes the complete canonical model, label, UTC creation time, and
content hash. Delta analysis classifies added, removed, and modified elements,
then expands the result through the relationship graph to identify impacted
requirements, tests, designs, hazards, evidence, and allocated functions.

## 2. Automated calibration and system identification

`AutomatedCalibrationEngine` implements two complementary workflows.

### ARX identification

The ARX identifier supports:

- Multiple input channels.
- Multiple output channels.
- Configurable autoregressive order.
- Configurable input order.
- Configurable input delay.
- Ridge regularization.
- Pivoted dense linear solution.
- Per-output RMSE and coefficient of determination.
- Residual variance and covariance-diagonal estimation.
- Deterministic evidence hashing.

The coefficient order is explicit: intercept, output lags, then input-channel
lags. `IdentifiedArxModel::predict` performs recursive free-run prediction using
the identified output dynamics.

### Bounded nonlinear calibration

The nonlinear calibration engine uses a bounded Levenberg-Marquardt method with:

- Central finite-difference Jacobians.
- Parameter-specific scales.
- Hard lower and upper bounds.
- Adaptive damping.
- Gradient and step convergence criteria.
- Singular-normal-equation recovery.
- Residual-size and finite-value validation.
- Objective, RMSE, gradient norm, and iteration evidence.
- Approximate covariance and standard errors when the information matrix is
  identifiable.

The residual callback is a normal C++ function object and can therefore call the
full simulator, a surrogate, a HIL interface, or an external data adapter.

## 3. SPICE, EMC, and wiring-harness co-simulation

`SpiceEmcHarnessSimulator` implements transient modified nodal analysis and
complex-frequency AC analysis.

Supported primitive elements are:

- Resistors.
- Capacitors.
- Inductors.
- Independent voltage sources.
- Independent current sources.

Transient integration uses backward Euler companion models for capacitors and
inductors. Inductors and voltage sources introduce explicit branch-current
unknowns. The solver performs pivoted dense elimination and reports the maximum
post-solve KCL residual.

A `WiringHarnessSection` expands into distributed R-L series segments and
shunt-capacitance sections. Harness coupling supports capacitive and inductive
paths between aggressor and victim nodes. This provides a deterministic,
vehicle-level model for voltage drop, ringing, filtering, crosstalk, grounding,
and transient propagation.

The AC sweep uses complex nodal admittances and produces:

- Per-node magnitude.
- Per-node phase.
- Common-mode source current.
- Estimated conducted-emission level in dBµV.
- Peak frequency and peak emission.

## 4. Cell-resolved battery abuse simulation

`CellResolvedBatteryAbuseSimulator` integrates every cell independently while
coupling cells through explicit thermal conductances.

Each cell includes:

- Capacity and state of charge.
- Open-circuit-voltage behavior.
- Temperature-dependent internal resistance.
- Joule heating.
- Convective cooling.
- Heat capacity and mass.
- Vent temperature.
- Runaway onset temperature.
- Exothermic runaway energy.
- Gas-generation inventory.

Supported abuse events are:

- Internal short circuit.
- External heating.
- Overcharge.
- Crush-induced damage and heat.
- Cooling loss.

The simulation models runaway progress, heat release, gas generation, venting,
cell-to-cell propagation, enclosure pressure, pressure-relief activation, pack
voltage collapse, and deterministic event evidence. Numerical integration is
bounded and rejects invalid or unstable states instead of silently producing
non-finite results.

## 5. E/E architecture synthesis

`EeArchitectureSynthesizer` performs exact branch-and-bound allocation of
software functions and redundant replicas to candidate compute nodes.

Constraints include:

- CPU capacity.
- Memory capacity.
- ASIL capability.
- Replica count.
- Diverse-replica placement.
- Compute-node diversity groups.
- Communication bandwidth.
- End-to-end flow latency.
- Network reachability.

Communication routes are calculated over candidate network links using shortest
latency paths. The final architecture includes selected compute nodes, selected
links, function allocations, CPU utilization, memory utilization, link
utilization, total weighted objective, search count, diagnostics, and a
cryptographic feasibility certificate.

The objective can combine node and link cost, mass, power, and cross-zone
latency. The maximum search-node count provides a deterministic bound on exact
search effort.

## 6. Distributed shared-world execution

`DistributedSharedWorldExecutor` supports two synchronization modes.

### Conservative mode

Events are processed in stable timestamp and event-ID order. Partition logical
times advance monotonically and the final world state is deterministic.

### Optimistic mode

Events are delivered using an independent delivery sequence. A straggler whose
timestamp precedes the partition logical time triggers rollback and deterministic
chronological replay of that partition's event history. The engine reports:

- Processed events.
- Rollback count.
- Anti-message-equivalent invalidations.
- Per-partition logical time.
- Global virtual time.
- Canonically hashed final state.

Supported event semantics include spawn, pose update, velocity update, migration,
and despawn.

## 7. Spectral synthetic-data generation

`SpectralSyntheticDataGenerator` provides a physically based, deterministic
spectral renderer for axis-aligned scene geometry.

The renderer includes:

- Arbitrary strictly increasing wavelength bands.
- Piecewise-linear spectral curves.
- Material reflectance spectra.
- Spectral irradiance.
- Atmospheric extinction.
- Lambertian surface response.
- Pinhole camera projection.
- Camera yaw and pitch.
- Ray-box intersection and depth.
- Per-band radiance.
- Camera red, green, and blue response curves.
- Exposure, quantum efficiency, shot noise, and read noise.
- Tone mapping and gamma conversion.
- Semantic and instance labels.

The dataset writer produces raw typed files for the spectral cube, RGB image,
depth map, semantic labels, and instance labels, plus a deterministic manifest
with per-frame hashes.

## 8. City-scale infrastructure simulation

`CityScaleInfrastructureSimulator` models directed road networks, traffic
signals, charging stations, and vehicle trips.

The simulation includes:

- Deterministic shortest-route assignment.
- Time-stepped vehicle movement.
- Link occupancy.
- BPR-style congestion speed reduction.
- Link-capacity tokens.
- Signal-controlled discharge.
- Link queue measurement.
- Electric-energy consumption.
- Reserve-energy enforcement.
- Charging-station capacity.
- Per-charger and grid power limits.
- Charging energy and peak site power.
- Trip completion, travel time, and stranding.

Outputs include trip-level routes and energy use, network queue and speed
statistics, charging demand, grid peak power, completion fraction, mean travel
time, total traction energy, and evidence identity.

## 9. Crash and occupant biomechanics

`CrashOccupantBiomechanicsSimulator` uses a coupled pelvis, chest, and head
multibody representation driven by an arbitrary vehicle acceleration pulse.

The model includes:

- Pelvis-chest stiffness and damping.
- Neck stiffness and damping.
- Belt slack.
- Pretensioner timing and retraction.
- Belt stiffness, damping, and load limiting.
- Airbag contact, stiffness, damping, and venting.
- Fourth-order Runge-Kutta integration.
- Numerical stability monitoring.

Calculated injury and restraint metrics include:

- HIC15.
- HIC36.
- Nij.
- Maximum chest deflection.
- Maximum chest acceleration.
- Maximum femur-force proxy.
- Maximum belt force.
- AIS3+ head and chest injury probability estimates.

The full time history records pelvis, chest, and head displacement and
acceleration, belt force, and neck force.

## 10. Lifecycle and circular-economy analysis

`LifecycleCircularEconomyAnalyzer` performs mass-balanced cradle-to-grave
accounting over components and materials.

Material inputs include:

- Mass.
- Recycled content.
- Virgin and recycled carbon intensity.
- Embodied energy.
- Water consumption.
- Cost.
- Criticality.
- Recyclability.
- Reusability.
- Remanufacturability.

Component inputs add manufacturing energy, manufacturing scrap, expected life,
replacement count, supplier identity, and battery-passport applicability.

The use phase includes lifetime distance, electricity, fuel, carbon intensity,
primary energy, maintenance carbon, and maintenance cost. End-of-life allocation
is mass-balanced and prioritizes reuse, then remanufacturing, then recycling.

Outputs include:

- Vehicle mass.
- Production, use-phase, end-of-life, and total carbon.
- Primary energy.
- Water.
- Cost.
- Recovered and landfill mass.
- Material circularity indicator.
- Critical-material risk.
- Material inventory.
- Battery passport with content hash.
- Scenario-delta comparison.

## Build and qualification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --target digital_thread_lifecycle_tests \
  advanced_platform_tests next_generation_platform_tests \
  muzixdiagsys_advanced_platform -j
ctest --test-dir build -R \
  'digital_thread_lifecycle_unit_tests|advanced_cyber_physical_platform_unit_tests|next_generation_platform_unit_tests' \
  --output-on-failure
./build/muzixdiagsys_advanced_platform self-test \
  build/systems-lifecycle-self-test build/systems-lifecycle-self-test.json
```

The focused test executable contains deterministic nominal and failure-oriented
checks for all ten domains. The advanced platform CLI self-test publishes one
machine-readable Boolean verdict per domain and includes those verdicts in the
overall platform result.

## Engineering boundaries

The implementations provide complete, deterministic engineering models for the
published APIs. They do not claim that a virtual result is a statutory approval,
a physical crash-test replacement, or a laboratory EMC certification. External
certification and physical correlation remain governed by the applicable test
laboratory, regulatory authority, measurement uncertainty, and model-validity
evidence.

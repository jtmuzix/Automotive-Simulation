# Global Numerical Rigor and Mathematical Qualification

## Purpose

MuzixDiagSys applies one numerical-quality policy across every configured C++ target. The policy prevents unsafe compiler reassociation and contraction, supplies qualification-grade numerical primitives, and replaces duplicated low-order or poorly conditioned local mathematics in high-impact simulation, calibration, optimization, reliability, and uncertainty workflows.

This upgrade does not change existing public model APIs or remove any subsystem. Physical model fidelity still depends on constitutive laws, geometry, boundary conditions, calibration data, and measurement quality; numerical rigor reduces avoidable discretization, conditioning, cancellation, and convergence error within those models.

## Global floating-point policy

`AESIM_ENABLE_STRICT_NUMERICS` defaults to `ON`.

- GCC and Clang targets compile with `-fno-fast-math` and `-ffp-contract=off`.
- Microsoft Visual C++ targets compile with `/fp:strict`.
- `AESIM_STRICT_NUMERICS=1` is propagated to all configured targets.
- Every concrete library, executable, plugin, and C++ test in the top-level build is passed through `aesim_configure_target`.

The policy prevents silent algebraic reassociation, reciprocal approximation, and fused contraction from changing qualified numerical behavior. It does not force bitwise identity across different standard libraries or processor architectures.

## Public API

Include:

```cpp
#include "aesim/core/numerical_rigor.hpp"
```

The API is also re-exported by `aesim/advanced/platform.hpp`.

The namespace is `aesim::core::numerics`.

## Tolerance and rigor policies

`TolerancePolicy` provides absolute, relative, pivot, and rank tolerances, iterative-refinement limits, and equilibration control. Three profiles are available:

- `RigorLevel::Fast`
- `RigorLevel::Engineering`
- `RigorLevel::Qualification`

Comparisons use magnitude-scaled tolerances rather than a single dimensionless epsilon.

## Stable accumulation and statistics

The module implements:

- compensated scalar summation;
- compensated dot products;
- overflow/underflow-resistant Euclidean norms;
- stable RMS calculation;
- online mean, variance, skewness, and kurtosis;
- mergeable moment accumulators;
- online covariance and correlation.

These algorithms avoid the loss of low-order terms that occurs in ordinary left-to-right summation and avoid catastrophic variance cancellation for signals with large offsets and small fluctuations.

## Dense linear algebra

`solve_linear` implements:

1. row and column equilibration;
2. scaled partial pivot selection;
3. long-double elimination workspace;
4. rank and singularity detection;
5. iterative refinement against the original system;
6. residual and componentwise backward-error calculation;
7. reciprocal condition estimation;
8. pivot-growth reporting.

The complex solver applies the same approach to antenna, impedance, and AC-network systems. Its residual certification uses scaled extended-precision complex norms so finite systems with very large magnitudes are not misclassified because an intermediate squared magnitude overflowed.

`inverse` factors the matrix once, reuses that factorization for every identity column, and applies iterative refinement against the original matrix to each column. This preserves the same qualified solve semantics while avoiding the former repeated factorization/condition-estimation cost. Singular inversion requests fail deterministically even when non-throwing solve options are used, because an inverse matrix has no partial-result status channel.

## Least squares and calibration

`least_squares_qr` uses column-pivoted Householder QR. It supports observation weights, ridge regularization, scale-relative numerical rank detection, residual norms, weighted RMS, coefficient permutation recovery, condition diagnostics, and covariance estimation. Covariance is recovered from the triangular QR factor and pivot permutation rather than explicitly forming and inverting normal equations, avoiding the condition-number squaring inherent in `X^T X`.

Calibration workflows use QR-based damped steps or robust equilibrated solves rather than unqualified inversion of normal equations. Jacobian and objective accumulation use compensated arithmetic. The validation, calibration, and automated-assurance objective paths use stable online moments or compensated sums for residual statistics and squared-error objectives.

## Numerical differentiation

`finite_difference_jacobian` uses five-point central differences in the interior and fourth-order one-sided formulas near parameter bounds. Step sizes scale with parameter magnitude and machine precision. The result reports function-evaluation counts and per-column derivative error estimates.

This replaces fixed forward differences in calibration, Modelica equation solution, reliability analysis, and selected optimization workflows.

## Roots, quadrature, and time integration

- `brent_root` combines bracketing, bisection, secant, and inverse-quadratic interpolation while preserving a valid root bracket. Sign tests do not multiply endpoint residuals, so tiny same-sign values cannot evade bracket validation through underflow.
- `adaptive_gauss_kronrod15` performs local error estimation with a maximum-error priority queue, overflow-safe midpoint arithmetic, and explicit detection of intervals that can no longer be subdivided at binary64 resolution.
- `integrate_dormand_prince45` provides embedded fourth/fifth-order error estimates, rejected-step accounting, adaptive step control, scaled extended-precision error accumulation, preallocated stage workspaces, and Dormand-Prince FSAL derivative reuse. After the first derivative, each attempted step therefore requires six new derivative evaluations rather than seven.

Rigid-body attitude integration uses a quaternion exponential-map update and normalization instead of first-order componentwise Euler integration.

## Sparse and multiphysics mathematics

The existing CSR runtime retains CG, restarted GMRES, BiCGStab, Jacobi, ILU(0), Newton line search, implicit BDF2, and conforming adaptive refinement. It now uses compensated inner products and stable norms for convergence, Krylov orthogonalization, residual reporting, and covariance operations. Dense interface and assimilation systems route through the equilibrated/refined solver.

## Migrated systems

The global kernel is used by the following implementation families:

- core accuracy, calibration, uncertainty, and automated assurance;
- measured validation and metrology;
- electrical and battery network solution;
- Modelica equation execution;
- sparse CFD, CHT, FSI, and digital-twin assimilation;
- electromagnetic, antenna, thermal, and structural finite elements;
- flexible-ring tire finite elements;
- camera/radar/lidar calibration and Gauge R&R;
- Gaussian-process and Bayesian optimization;
- surrogate analytics and multi-fidelity prediction;
- reliability FORM analysis;
- controller code generation and state-space norms;
- Formula One aerodynamic correlation;
- Formula One performance, calibration, and uncertainty workflows.


## Deterministic scheduler and research-runtime hardening

The integer-nanosecond multi-rate scheduler now performs checked deadline addition for registration, reset, period changes, and recurring dispatch. It rejects signed nanosecond overflow instead of wrapping a future task into the past. Earliest-deadline selection and due-task collection are combined into one pass, and the due-task buffer is reused across dispatches. Ordering remains deterministic because priority and unique registration order fully define the sort key.

The research2 estimation and deployment stack now routes dense solves and inversion through the same qualified core solver. Its internal Jacobian rejects changing output dimensions and non-finite stencil values. GNSS positioning uses column-pivoted QR for iterative pseudorange updates instead of normal-equation inversion; the covariance inverse is formed only after the final update. Sim-to-real residual regression likewise uses QR with ridge regularization, covariance accumulation is performed in-place with extended-precision accumulators, and invariant matrix transforms are hoisted out of per-sample loops.

Bayesian calibration evaluates the covariance log-determinant and Mahalanobis term from one scaled Cholesky factorization rather than computing a full inverse and then factoring the matrix again. Extended Kalman covariance updates use Joseph form. Particle-filter normalization, means, covariance, and effective-sample-size accumulation use extended or compensated arithmetic and avoid per-particle temporary covariance matrices.

## Diagnostics and evidence

Dense solves report convergence, rank, refinement count, residual norm, relative residual, componentwise backward error, reciprocal condition estimate, pivot growth, and a diagnostic message. ODE and quadrature results expose evaluation and error histories. `audit_invariants` compares conservation, energy, probability, geometry, and other invariants against combined absolute and relative tolerances.

Qualification workflows should retain these diagnostics with the existing provenance and evidence hashes.

## Validation

Build and run the dedicated numerical suite:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON
cmake --build build --target numerical_rigor_tests -j
ctest --test-dir build -R global_numerical_rigor_unit_tests --output-on-failure
```

The test suite covers cancellation-sensitive sums, scaled norms, ill-conditioned real and complex systems, rank-revealing least squares, bounded high-order Jacobians, Brent roots, adaptive Gauss-Kronrod integration, Dormand-Prince integration, stable high-offset statistics, covariance, and invariant audits.


## Result-level mathematical assurance

The companion [`GLOBAL_MATHEMATICAL_ASSURANCE.md`](GLOBAL_MATHEMATICAL_ASSURANCE.md) extends this solver-level kernel with classified error budgets, condition-aware precision escalation, exact dyadic reference arithmetic, reproducible nearest-even reductions, convergence/GCI and manufactured-solution services, derivative and KKT certification, cross-solver consensus, deterministic property tests, and SHA-256-sealed per-result evidence. Include `aesim/core/mathematical_assurance.hpp` and use `aesim::core::math_assurance`.

The original `numerical_rigor.hpp` APIs remain unchanged. Faster compensated calculations continue to serve production paths; exact and multiprecision services provide qualification references and difficult-case escalation.

## Scope boundaries

The original numerical-rigor API uses IEEE binary64 values with long-double work and accumulation where beneficial. The mathematical-assurance companion adds decimal multiprecision and exact dyadic references without changing those production solver contracts. A poor physical model, unobserved parameter, invalid mesh, or unrepresentative boundary condition can still produce a precise but inaccurate answer. Qualification therefore requires numerical convergence studies, experimental correlation, uncertainty propagation, and applicability assessment in addition to solver convergence.

# Full Lifecycle Virtual Vehicle Implementation

## Scope

The lifecycle layer is an additive, deterministic extension of the existing vehicle ecosystem. It preserves the ecosystem, vehicle-depth, high-fidelity, electrification, industrial, plugin, FMI, federation, and command-completion interfaces while coupling ten additional production models through `aesim::high_fidelity::IntegratedVehicleLifecycleRuntime`.

Public declarations are in `include/aesim/high_fidelity/lifecycle.hpp`. Implementations are split across:

- `src/vehicle/lifecycle_physics.cpp`
- `src/vehicle/lifecycle_systems.cpp`
- `src/vehicle/lifecycle_integrated.cpp`

## Causal execution order

Each lifecycle step executes the following deterministic sequence:

1. Reconstruct autonomous-object measurements from the closed-loop traffic world.
2. Fuse, predict, plan, and generate steering/acceleration commands.
3. Evaluate the finite-horizon predictive energy, thermal, and chassis controller.
4. Advance the existing complete vehicle ecosystem.
5. Advance nonlinear crash structure and occupant restraints.
6. Advance cell reaction, vent-gas, fire, enclosure pressure, and propagation.
7. Advance reduced-order three-dimensional airflow and conjugate heat transfer.
8. Advance the unified lubrication/tribology/wear network.
9. Advance structural-acoustic modes and psychoacoustic metrics.
10. Accumulate semiconductor and passive-component degradation.
11. Advance water, salt, dust, corrosion, insulation, and icing states.
12. Advance steering-column, rack, EPS, road-wheel, and road-feel dynamics.
13. Publish synchronized lifecycle state and conservation residuals.

## Nonlinear crash and occupant restraints

The crash model contains direction-specific crush zones with nonlinear elastic/plastic hardening, viscous dissipation, overlap scaling, available stroke, bottoming, and post-crush intrusion. Vehicle deceleration is calculated from the reduced collision mass.

The occupant model resolves pelvis, torso, and head motion. It includes belt slack, pretensioner retraction, belt stiffness and damping, load limiting, airbag trigger delay, airbag stiffness, and vent damping. Outputs include belt and airbag forces, head/chest acceleration, HIC15, chest 3-ms acceleration, neck injury index, crush energy, and a collision energy residual.

## Battery vent gas and fire

Each cell tracks temperature, remaining reactive mass, reaction progress, cumulative gas generation, released-gas inventory, retained-gas pressure, vent state, thermal-runaway state, and burning state. Reaction rate is Arrhenius-based and includes electrical short heating, external heat, cooling, and nearest-neighbor thermal coupling. Vent flow uses a pressure-dependent release time constant so accumulated gas is transferred from the cell rather than counted only at the generation instant.

The enclosure tracks mixed-gas mass and temperature, ideal-gas pressure, vent flow, rupture state, cumulative heat release, hydrogen, carbon monoxide, and toxic-gas approximations. Vent discharge removes gas species and enthalpy proportionally, rupture is evaluated from pre-vent pressure, and reported pressure is recomputed after discharge. Cell, enclosure, cooling, reaction, and vent enthalpy are closed through cumulative input/output energy integrals. Vent area and rupture pressure are configurable. Fire propagation feeds the CFD heat source and can be initiated by crash intrusion or an explicit ignition source.

## Reduced-order 3D CFD/CHT

The solver uses user-configurable cell volumes and reduced spatial modes. Each mode contains three velocity shapes and a temperature shape. Modal amplitudes evolve as stable first-order states driven by freestream, fan command, and heat input. Reconstructed cell fields include three-axis velocity, fluid and solid temperature, pressure, and wall heat flux.

Conjugate heat transfer couples fluid and solid capacities. The model reports captured flow, pressure drop, outlet temperature, convective heat transfer, stored energy, and a first-law residual.

## Unified tribology and wear

Supported contact types are journal bearings, rolling bearings, gear meshes, piston rings, cam/follower contacts, clutches, seals, and CV joints. The model calculates temperature-dependent oil viscosity, entrainment, film thickness, lambda ratio, Stribeck-regime friction, friction power, flash temperature, Archard wear, debris generation, scuffing risk, pitting damage, and lubricant degradation.

## Structural acoustics and psychoacoustics

Structural modes use stable implicit integration of modal mass, stiffness, and damping. Arbitrary excitation sources supply frequency, RMS force, phase, and per-mode participation. Outputs include modal displacement/velocity/acceleration, radiated pressure, overall and A-weighted SPL, loudness, sharpness, roughness, tonality, steering-wheel vibration, seat-rail vibration, and ride-comfort index.

## Power-electronics lifetime

Each semiconductor or capacitor tracks junction/case temperature, bond-wire damage, solder damage, gate-oxide damage, on-resistance growth, failure probability, remaining life, and open/short failure state. Damage combines thermal swing, current loading, Arrhenius acceleration, Coffin-Manson-style cycle severity, and mission-profile time.

## Environmental ingress, contamination, corrosion, and icing

Each component tracks liquid water, ice, salt, dust, corrosion depth, insulation resistance, connector resistance, blockage, ingress fault, and frozen state. Inputs include rain, splash pressure, ambient temperature, humidity, road salt, dust, acceleration, and de-icing heat. The model includes seal leakage, drainage, freezing/melting, ice shedding, electrolyte-enhanced corrosion, insulation loss, and connector resistance growth.

## Steering mechanics and road feel

The steering model resolves wheel and column inertia, column compliance, backlash, friction, rack mass/stiffness/damping, tie-rod conversion, EPS assist/current/temperature, aligning-moment feedback, kickback, steering effort, on-center gradient, and an energy residual.

## Predictive control

The predictive controller evaluates a finite grid of acceleration, cooling, and chassis candidates over a configurable horizon. Route preview includes grade, curvature, speed limits, traffic speed, and ambient temperature. The objective combines energy, speed tracking, battery damage, thermal stress, ride comfort, SOC reserve, and lateral-load penalties. Outputs include wheel torque, regeneration, pump/fan commands, active-suspension gain, and ride height.

## Autonomous driving stack

The stack implements:

- deterministic measurement fusion and covariance reduction;
- track aging and confidence decay;
- constant-acceleration trajectory prediction;
- lane and acceleration candidate generation;
- collision-clearance and time-to-collision evaluation;
- speed, comfort, lane-change, friction, and ODD costs;
- emergency braking and degraded-mode constraints;
- trajectory tracking steering, throttle, and brake commands.

## Console commands

```text
industrial energy lifecycle status
industrial energy lifecycle auto on|off
industrial energy lifecycle reset [ambient_k]
industrial energy lifecycle step [dt rpm torque speed wheel_torque brake target_speed]
industrial energy lifecycle autonomy-mode disabled|standby|active|degraded|emergency-stop
industrial energy lifecycle crash front|rear|left|right|rollover <relative_speed_m_s> [overlap]
industrial energy lifecycle crash-clear
industrial energy lifecycle battery-fire <cell> <heat_w>
industrial energy lifecycle battery-fire-clear <cell>
industrial energy lifecycle weather <rain_mm_h> <ambient_k> <salt_kg_m3> <dust_kg_m3> [humidity]
industrial energy lifecycle steering-input <driver_torque_nm> <supply_v>
industrial energy lifecycle mpc on|off
industrial energy lifecycle autonomy on|off
industrial energy lifecycle cfd
industrial energy lifecycle tribology
industrial energy lifecycle nvh
industrial energy lifecycle power-electronics
industrial energy lifecycle exposure
industrial energy lifecycle steering
industrial energy lifecycle crash-report
industrial energy lifecycle fire-report
```

Aliases are `full-lifecycle`, `safety-autonomy`, and `virtual-vehicle`. All fixed command tokens and enum values are supplied by the authoritative completion registry.

## Signals

Signals are published under `electrification.lifecycle.*`, including time, crash severity, fire pressure and heat-release rate, CFD outlet temperature, tribology loss, cabin SPL, semiconductor life, corrosion, steering effort, MPC objective, autonomy mode/clearance, and aggregate energy residual.

## Calibration requirements

Vehicle correlation requires crash pulse and crush data, restraint component data, cell accelerating-rate calorimetry and vent-gas data, CFD mode bases, component oil-film and wear tests, modal/acoustic transfer functions, semiconductor mission-profile data, environmental chamber exposure, steering rig measurements, route/thermal plant calibration, and perception/planning validation datasets.

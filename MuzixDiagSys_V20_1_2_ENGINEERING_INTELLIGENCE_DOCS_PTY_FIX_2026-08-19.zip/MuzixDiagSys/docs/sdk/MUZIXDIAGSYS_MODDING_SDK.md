# MuzixDiagSys Modding SDK

> The public product is MuzixDiagSys. Existing `aesim_*` ABI entry points and `AESIM_PLUGIN_*` constants are retained as stable legacy interfaces for binary compatibility.


## ABI

The supported native interface is `aesim_plugin_abi_v2.h`, ABI version 2.0. Plugins use a C ABI so modules built with different C++ standard-library implementations can interoperate safely.

Required exported functions:

```text
aesim_plugin_v2_query
aesim_plugin_v2_create
aesim_plugin_v2_step
aesim_plugin_v2_serialize
aesim_plugin_v2_deserialize
aesim_plugin_v2_destroy
```

A deterministic, serializable plugin must preserve all mutable state through the serialize/deserialize pair. It must not use wall-clock time or an unseeded random generator.

## Manifest

```yaml
schema: aesim.plugin-manifest.v1
id: thermal_margin_analyzer
name: Thermal Margin Analyzer
version: 1.0.0
abi_major: 2
abi_minor: 0
library: libthermal_margin_analyzer.so
capabilities:
  - analysis
  - deterministic
  - serializable
```

Validate and register it with:

```text
industrial vehicle experience lab sdk validate plugin.yaml
industrial vehicle experience lab sdk register plugin.yaml
industrial vehicle experience lab sdk export plugin_registry.json
```

## Generate a complete plugin project

```text
industrial vehicle experience lab sdk scaffold plugins/sample sample_analysis "Sample Analysis Plugin"
```

The generated project contains:

- `plugin.yaml`
- `plugin.cpp`
- `CMakeLists.txt`

The source implements all ABI-v2 lifecycle functions, deterministic step behavior, state serialization and cleanup. It is directly buildable when `AESIM_SDK_INCLUDE_DIR` points to the simulator's `include` directory:

```bash
cmake -S plugins/sample -B plugins/sample/build \
  -DAESIM_SDK_INCLUDE_DIR=/path/to/MuzixDiagSys/include
cmake --build plugins/sample/build
```

## Safety and compatibility rules

- Reject ABI-major mismatches.
- Validate manifest fields before loading a shared library.
- Declare at least one capability.
- Use bounded output buffers.
- Return defined ABI error codes.
- Keep simulation-state mutations deterministic.
- Serialize every state variable needed for replay and rollback.
- Never throw C++ exceptions across the C ABI boundary.
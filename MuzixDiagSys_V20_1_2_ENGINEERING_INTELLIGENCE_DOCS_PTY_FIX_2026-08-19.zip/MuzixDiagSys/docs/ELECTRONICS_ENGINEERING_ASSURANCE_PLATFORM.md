# Electronics Engineering and Assurance Platform

## Scope

The electronics expansion is part of `aesim_advanced` and is exported through three additive public headers:

```cpp
#include "aesim/advanced/electronics_power_distribution_platform.hpp"
#include "aesim/advanced/electronics_circuit_conversion_platform.hpp"
#include "aesim/advanced/embedded_electronics_assurance_platform.hpp"
```

Link applications to `aesim_advanced`. Existing simulator commands, libraries, public APIs, project formats, dashboards, diagnostics, and motorsport platforms are unchanged.

## Vehicle electrical power and energy distribution

### Low-voltage power network

`LowVoltagePowerNetwork` solves a nonlinear nodal network containing voltage sources with internal resistance, resistive loads, constant-current loads, constant-power loads, distributed harness resistance and inductance, branch thermal states, brownout thresholds, priority-based load shedding, and source-current limits. Constant-power loads are solved iteratively with voltage relaxation. Smart fuses use instantaneous-trip and accumulated I²t criteria and retain thermal and trip-count state between calls.

The report contains node voltages, branch currents and temperatures, fuse state, shed loads, brownout nodes, source power, delivered power, and resistive loss.

### Sleep and wake behavior

`SleepWakePowerManager` models vehicle modes, ECU startup and shutdown delays, run/standby/sleep current, supply-voltage dropout, accepted wake sources, wake dependencies, wake causal chains, unexpected awake modules, settled quiescent current, and battery time to no-start state of charge.

### PMIC and system-basis chips

`PmicSystemBasisChip` models dependent output rails, startup timing, capacitive voltage evolution, efficiency, current limiting, power-good generation, undervoltage lockout, watchdog reset, dissipated power, junction temperature, and thermal shutdown.

### High-voltage precharge and disconnect

`HvPrechargeDisconnectUnit` implements negative-contactor closure, RC precharge, completion and timeout checks, positive-contactor closure, discharge, service disconnects, isolation faults, welded contactors, contactor loss, interruption arc energy, pyrofuse operation, crash isolation, and safe-to-service determination.

## Electronic circuit and PCB engineering

### Analog and mixed-signal electronics

`AnalogMixedSignalLaboratory` evaluates gain, input offset, bias-current error, common-mode rejection, power-supply rejection, Johnson noise, amplifier noise, bandwidth, slew rate, settling, and clipping.

### ADC and DAC

`DataConverterLaboratory` implements finite resolution, reference ranges, offset and gain error, INL, DNL, aperture jitter, deterministic input noise, quantization, SNDR, ENOB, DAC glitch energy, finite settling time, and slew limiting.

### PCB signal and power integrity

`PcbSignalPowerIntegrityPlatform` evaluates cascaded transmission-line insertion and return loss, crosstalk, impedance discontinuity, eye height, eye width, deterministic and random jitter, BER estimate, and TDR impedance range. The PDN solver performs logarithmic frequency sweeps of parallel RLC elements, finds anti-resonant impedance peaks, checks target impedance, and predicts load-step droop.

### ECAD import

`EcadImporter` parses SPICE connectivity, a deterministic CSV connectivity interchange, and a useful KiCad S-expression subset. It returns components, nets, warnings, and a canonical SHA-256 digest suitable for digital-thread comparison.

### Grounding and shielding

`GroundingShieldingOptimizer` solves a frequency-dependent ground/bond network, reports node potential and path current, calculates maximum ground offset, common-mode emission, shield effectiveness, and identifies the bond with the largest corrective value.

## Power semiconductor and conversion laboratory

### Si, SiC, GaN, and IGBT devices

`PowerSemiconductorModel` calculates temperature-dependent conduction loss, switching loss, reverse-recovery loss, gate-drive loss, stray-inductance voltage overshoot, capacitive current overshoot, junction temperature, and safe-operating-area margin for silicon MOSFETs, silicon-carbide MOSFETs, gallium-nitride HEMTs, and IGBTs.

### Gate drivers and double-pulse qualification

`GateDriverLaboratory` models source/sink paths, propagation delay, UVLO, CMTI, Miller clamping, false turn-on, desaturation, soft shutdown, and dead-time requirements. `DoublePulseQualificationLaboratory` computes peak current and voltage, switching energies, reverse-recovery energy, avalanche energy, temperature rise, and pass/fail against device ratings.

### Onboard chargers, isolated DC/DC, and wireless charging

- `OnboardChargerLaboratory` supports interleaved boost PFC/LLC, totem-pole PFC/CLLC, and Vienna/DAB profiles with efficiency, PF, THD, leakage current, semiconductor and magnetic loss, thermal derating, and bidirectional operation.
- `IsolatedDcDcLaboratory` evaluates phase-shift power transfer, leakage inductance, synchronous conduction, magnetics loss, efficiency, temperature, and derating.
- `WirelessChargingLaboratory` calculates misalignment-dependent coupling, mutual inductance, reflected impedance, coil current, delivered power, efficiency, stray field, foreign-object risk, and field-limit compliance.

## Automotive communication physical layers

`AutomotiveCommunicationPhysicalLayer` connects analog channel behavior to link status:

- CAN: cable/termination mismatch, propagation delay, stubs, reflections, ground offset, noise, eye opening, BER, and link margin.
- LIN: pull-up RC rise time, battery dependence, ground offset, noise, eye opening, and link status.
- Automotive Ethernet T1: insertion loss, return loss, mode conversion, PAM symbol rate, SNR, impulse noise, BER, eye opening, and link margin.

## Embedded hardware verification and safety

### Bootloader and flashing

`BootloaderFlashingLaboratory` manages non-overlapping flash partitions, programming voltage limits, transport time, erase/program/verify behavior, SHA-256 image verification, device-wide anti-rollback counters, interrupted-program recovery state, executable partition activation, and partition readback.

### AUTOSAR BSW and MCAL

`AutosarBswMcalRuntime` provides executable behavior for EcuM, BswM, ComM, CAN/LIN/Ethernet state managers, watchdog management, DEM, NvM, flash, ADC, PWM, SPI, DIO, GPT, and ICU profiles. It evaluates dependencies, startup, sleep, network wake, scheduling, utilization, deadlines, watchdogs, undervoltage, degraded operation, and diagnostic events.

### RTL and SystemC-style co-simulation

`RtlSystemCCosimulator` is a dependency-free, deterministic cycle engine with typed-width signals, combinational and registered operations, saturating arithmetic, transaction input, assertions, cycle counts, and traceable final signal state. It permits software/RTL behavior verification in the default build without requiring a proprietary HDL simulator.

### LBIST, MBIST, NVM, and semiconductor aging

- `BuiltInSelfTestLaboratory` implements March C- memory testing and LFSR/MISR-style logic BIST with fault injection and diagnostic coverage.
- `NvmReliabilityLaboratory` models EEPROM, NOR, NAND, FRAM, and MRAM configurations, page/block geometry, wear, journaled power-loss recovery, retention acceleration, ECC correction, uncorrectable pages, and remaining life.
- `SemiconductorAgingLaboratory` accumulates BTI, HCI, TDDB, electromigration, power-cycling, thermal-cycling, and cosmic-ray damage from mission profiles and reports parameter drift, failure probability, dominant mechanism, and remaining useful life.

## Electronics manufacturing, security, and compliance

### PCBA production and inspection

`PcbaProductionDigitalTwin` evaluates paste transfer, placement error, reflow profile, moisture exposure, ionic cleanliness, bridges, opens, voids, tombstones, warpage, first-pass yield, and process recommendations.

`ElectronicsInspectionLaboratory` composes AOI, AXI, ICT, flying-probe, boundary-scan, and functional-test stages using defect-specific detection probabilities, false-call rates, cycle time, escaped-defect probability, and aggregate diagnostic coverage.

### Secure provisioning and physical attacks

`SecureProvisioningLifecycle` enrolls device identities and enforces authorized transitions through manufacturing, development, field, service, return, and decommissioned states. It creates deterministic identity, certificate, authorization, anti-rollback, debug-lock, and audit digests.

`HardwarePhysicalSecurityLaboratory` models power and EM analysis, clock and voltage glitches, and EM fault injection. Masking, constant-time execution, random delay, monitors, redundant computation, and shielding modify leakage, fault success, and detection probability.

### EMC chamber instrumentation and mitigation

`EmcChamberInstrumentationTwin` composes receiver, preamplifier, probe, cable, and chamber corrections; propagates expanded uncertainty; detects overload and noise-floor limitations; checks site VSWR and field uniformity; and determines whether the chamber/measurement is qualified.

`AutomatedEmcMitigationOptimizer` performs an exhaustive constrained search across compatible mitigation candidates. It selects the lowest-scoring combination that meets emission and immunity margins while honoring efficiency, thermal, and mass constraints.

## Build and qualification

```bash
cmake -S . -B build/electronics -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_HARDENING=ON \
  -DAESIM_ENABLE_STRICT_NUMERICS=ON

cmake --build build/electronics --parallel --target \
  electronics_power_distribution_platform_tests \
  electronics_circuit_conversion_platform_tests \
  embedded_electronics_assurance_platform_tests

ctest --test-dir build/electronics --output-on-failure \
  -R '^(electronics_power_distribution|electronics_circuit_conversion|embedded_electronics_assurance)_platform_unit_tests$'
```

For memory-safety qualification, create a Debug build with `-DAESIM_ENABLE_SANITIZERS=ON` and execute the same three test binaries with ASan and UBSan configured to halt on first error.

## Qualification boundary

These models perform deterministic engineering calculations and expose assumptions, margins, state, and evidence. They do not by themselves establish production electrical safety, regulatory EMC approval, ISO 26262 compliance, AUTOSAR conformance, silicon qualification, hardware security certification, manufacturing acceptance, or field reliability. Production use requires supplier models, measured parasitics, calibrated material and thermal properties, verified test fixtures, controlled uncertainty, applicable standards, and qualified engineering review.

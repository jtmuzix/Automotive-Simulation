# Assured Engineering Operations Platform

## Purpose

`aesim::advanced::assured` adds ten production-oriented engineering systems to
the advanced simulator library. The implementation is additive: no pre-existing
public type, source file, executable, test, or command is removed. All public
entry points validate dimensions, finite values, ranges, graph references, and
physical configuration before executing.

Public header:

```cpp
#include "aesim/advanced/assured_engineering_operations_platform.hpp"
```

The umbrella header `aesim/advanced/platform.hpp` also exports this platform.

## 1. Contract-driven co-simulation compiler

`ContractDrivenCoSimulationCompiler` consumes typed `ComponentContract` and
`ContractConnection` objects. Each port declares direction, causality, unit
dimension and affine SI conversion, coordinate frame, conserved quantity,
range, sample period, and direct-feedthrough behavior.

Compilation performs:

1. unique component and port identifier validation;
2. connection endpoint and direction resolution;
3. physical-dimension, coordinate-frame, and conservation-quantity checks;
4. unit conversion synthesis, including offset units such as Celsius;
5. sampled/continuous/event rate-transition detection;
6. Tarjan strongly connected component analysis of direct-feedthrough edges;
7. algebraic-loop qualification against implicit-iteration or rollback support;
8. condensation-graph scheduling into deterministic execution stages; and
9. SHA-256 binding of the complete semantic contract.

`convert_value` applies the compiled affine conversion and enforces the
receiving port range.

`ConservationGovernor` evaluates storage, integrated flow, generation, and
dissipation balances. Residuals are normalized by absolute and relative
budgets. The governor returns `Accept`, `RefineStep`, `Rollback`, or `Abort`
based on the observed residual and runtime rollback capability.

## 2. Certified probabilistic programming and Bayesian digital twins

`CertifiedBayesianDigitalTwinRuntime::infer_linear` implements a complete
linear-Gaussian state estimator:

- prediction with control input;
- innovation covariance and Gaussian log evidence;
- Kalman gain and covariance update;
- covariance symmetrization;
- Rauch--Tung--Striebel backward smoothing; and
- Gershgorin lower-bound checks for covariance numerical validity.

`sample_posterior` executes multiple independent random-walk Metropolis chains.
It reports posterior means and covariance, 95% credible intervals, acceptance
rate, autocorrelation-based effective sample size, multi-chain R-hat, a
convergence decision, retained samples, and a deterministic evidence digest.
The caller supplies actual prior and likelihood functions through
`ProbabilisticProgram`; the runtime does not substitute placeholder densities.

## 3. Distributionally robust stochastic control

`DistributionallyRobustControlOptimizer` operates on discrete linear plants
with explicit disturbance channels and weighted disturbance scenarios. It
simulates every scenario and minimizes an objective containing:

- expected quadratic state and control cost;
- worst-case scenario cost;
- conditional value at risk (CVaR);
- a Wasserstein-radius robustness term; and
- a quadratic chance-constraint violation penalty.

Controls are projected into declared bounds. Central finite-difference
gradients and bounded backtracking line search provide a deterministic solver
that works without external optimization libraries. Results include the full
control sequence, expected/worst/CVaR costs, robust objective, empirical
violation probability, gradient norm, iteration count, feasibility,
convergence, and evidence digest.

## 4. Verified software synthesis and proof-carrying code

`VerifiedAutomotiveSoftwareSynthesizer` generates deterministic C for bounded
affine controllers. The generated package contains:

- a standalone C header;
- implementation with null guarding and output saturation;
- a compilable C unit-test source;
- requirement-to-proof traceability;
- fixed-point range/overflow analysis;
- saturation validity proof;
- estimated execution cycles and WCET budget proof;
- stack-use estimate;
- finite-coefficient proof;
- SHA-256 source binding; and
- an Ed25519 signature produced by the existing signed-attestation service.

`verify` regenerates the deterministic artifact, compares all text, estimates,
proof obligations, proof margins, and requirement traces, recomputes the hash,
and verifies the Ed25519 signature. Removed, reordered, modified, or fabricated
proof obligations are rejected.

## 5. Manufacturing-to-structure twin

`ManufacturingStructureTwin` contains four independent numerical workflows.

### Crystal plasticity

The crystal integrator resolves traction onto each declared slip system,
applies a rate-sensitive power-law flow rule with isotropic hardening and a
temperature factor, accumulates absolute slip, updates the symmetric plastic
strain tensor through the Schmid tensor, and integrates plastic work.

### Phase-field fracture

The one-dimensional irreversible phase-field solver combines degraded elastic
energy, fracture surface energy, and the damage-gradient regularizer. Damage is
monotonic, bounded to `[0,1]`, and iterated to a declared tolerance. Outputs
include damage, degraded stress, elastic energy, fracture energy, crack length,
iteration count, and convergence.

### Joining

Spot weld, laser weld, adhesive, rivet, and hybrid joints use process-specific
strength and fatigue factors. Penetration, porosity, residual stress, adhesive
thickness, sheet thickness, base strength, and cyclic load determine tensile
capacity, shear capacity, energy absorption, S-N fatigue life, and
qualification.

### Gigacasting

The casting solver evolves cell temperature and liquid fraction under die and
neighbor heat transfer, including latent heat in the effective heat capacity.
It accumulates feeding-sensitive shrinkage porosity, oxide entrainment, and a
solidification-driven residual-stress estimate until fully solid or the step
budget is exhausted.

## 6. Autonomous robotic proving-ground and test-cell orchestration

`AutonomousTestCellOrchestrator` validates a dependency DAG, resources,
capabilities, calibration, safety interlocks, power limits, and robot paths.
Line segments are checked against three-dimensional axis-aligned exclusion
zones using a slab intersection calculation.

The scheduler performs deterministic earliest-resource assignment after all
predecessors complete. Execution uses a seeded measurement-quality model and
per-operation retry policy. Reports include resource assignments, times,
attempts, measured quality, energy, makespan, safety events, overall completion,
safety status, and audit digest.

## 7. Post-crash rescue and emergency response

`PostCrashEmergencyResponseTwin` combines:

- undirected road-network shortest-path routing;
- responder mobilization and protected extraction capacity;
- saturating fire growth and suppression effectiveness;
- species-specific toxic generation, ventilation, and decay;
- compartment concentration histories;
- responder integrated dose after arrival;
- injury, delay, and toxic-hazard survival estimation; and
- heat-release-based hazard-radius estimation.

The engine provides peak concentration per species, responder dose, arrival and
extraction times, survival probability, recommended actions, extraction
success, and signed-content-compatible evidence digest.

## 8. Megawatt charging, swapping, and depot operations

`MegawattDepotOperationsTwin` performs a time-stepped fleet dispatch. It first
uses qualified swap packs for vehicles that cannot physically meet their target
through charging. Remaining demand is ordered by required energy per remaining
hour.

Dispatch enforces:

- vehicle and charger power limits;
- charger efficiency;
- cable/connector thermal derating;
- transformer power limit;
- onsite-storage power and energy limits;
- vehicle availability windows;
- departure state-of-charge requirements; and
- complete tariff coverage.

The result reports every charging or swapping action, final vehicle and pack
state of charge, energy and demand cost, carbon, peak grid power, a degradation
index, missed departures, transformer qualification, and evidence digest.

## 9. Privacy-preserving engineering data space

`aggregate` applies dataset, purpose, and column policies before reading any
record. It spends an explicit differential-privacy budget and adds Laplace
noise calibrated from declared sensitivity and epsilon. Budget is mutated only
for authorized, successful releases.

`prove_secret_knowledge` implements a genuine non-interactive Schnorr proof on
NIST P-256:

1. a secret scalar is derived from secret material;
2. a deterministic nonce scalar is derived from the secret, statement, and
   caller seed;
3. the prover publishes `P=xG` and `R=kG`;
4. the Fiat--Shamir challenge binds the statement digest, public key, and
   commitment; and
5. the response is `s=k+ex mod n`.

Verification checks the challenge and the equation `sG = R + eP`. The secret is
not included in the evidence. Modified statements, points, challenges, or
responses fail verification.

This proof demonstrates possession/knowledge of secret material. It is not a
range proof and does not by itself prove an undisclosed numeric threshold.

## 10. Fleet causal root cause and reliability growth

`FleetCausalReliabilityGrowthEngine` fits a regularized logistic propensity
model from supplied covariates, clips extreme propensities, and evaluates common
support. Inverse-probability weights produce treated and control rates and an
average treatment effect. An influence-function estimate supplies standard
error.

Failure-event times feed a Crow--AMSAA non-homogeneous Poisson process model.
The result includes beta, lambda, projected failure intensity, and whether the
observed reliability trend is improving. Candidate causes are ranked by
standardized outcome association, approximate odds ratio, and confidence.

The `causally_identifiable` flag requires adequate propensity overlap and finite
uncertainty. It is an engineering diagnostic, not a substitute for an explicit
causal identification argument when unmeasured confounding is plausible.

## Determinism and evidence

All workflows that use randomness require an explicit seed. Evidence digests
use canonical, maximum-precision serialization of the relevant result fields.
Cryptographic signatures use OpenSSL's Ed25519 implementation; Schnorr evidence
uses OpenSSL P-256 arithmetic.

## Validation

Dedicated native target:

```bash
cmake --build build --target assured_engineering_operations_platform_tests -j
ctest --test-dir build \
  -R assured_engineering_operations_platform_unit_tests \
  --output-on-failure
```

The test performs successful and tampered-path validation across all ten
systems, including unit conversion, conservation, smoothing, MCMC, robust
control, signed generated code, material/process physics, dependency scheduling,
rescue routing, depot completion, privacy-budget spending, Schnorr verification,
and fleet causal/reliability output.

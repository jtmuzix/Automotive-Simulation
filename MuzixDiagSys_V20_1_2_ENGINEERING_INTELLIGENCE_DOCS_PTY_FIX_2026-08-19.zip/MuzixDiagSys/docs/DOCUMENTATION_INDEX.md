# MuzixDiagSys Documentation Index

**Revision:** 2026-08-19 (V20.1.2 Engineering Intelligence Platform and PTY synchronization hardening)

This index separates current operator guidance from subsystem references, examples, implementation records, and historical validation artifacts.

## Authoritative user documentation

| Document | Role |
|---|---|
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Authoritative editable operator and engineering manual. |
| [`MUZIXDIAGSYS_USER_MANUAL.pdf`](MUZIXDIAGSYS_USER_MANUAL.pdf) | Typeset release rendering of the authoritative manual. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Practical beginner-to-advanced workflows and exact command guide. |
| [`REAL_WORLD_TUI_USAGE_GUIDE.md`](REAL_WORLD_TUI_USAGE_GUIDE.md) | Short real-world TUI workflows with explanations, terminal selection/copy/paste guidance, and practical engineering examples. |
| [`MuzixDiagSys_Formula_One_Industrial_Ecosystem_Tutorial_2026-07-24.docx`](MuzixDiagSys_Formula_One_Industrial_Ecosystem_Tutorial_2026-07-24.docx) | Dated editable Word rendering retained for the 2026-07-24 Formula One industrial/ecosystem release; use the current Markdown tutorial and User Manual for later additions. |
| [`MuzixDiagSys_Beginner_to_Advanced_Tutorial_and_Exact_Command_Guide_2026-07-23.docx`](MuzixDiagSys_Beginner_to_Advanced_Tutorial_and_Exact_Command_Guide_2026-07-23.docx) | Prior dated Word rendering retained for historical comparison. |
| [`COMMAND_REGISTRY_AND_COMPLETION.md`](COMMAND_REGISTRY_AND_COMPLETION.md) | Command discovery, aliases, completion, and schema behavior. |
| [`ADVANCED_API_CLI_COMMANDS.md`](ADVANCED_API_CLI_COMMANDS.md) | Complete 214-command advanced API CLI registry, common grammar, global execution options, categories, and high-value engineering workflows. |
| [`ENGINEERING_INTELLIGENCE_PLATFORM.md`](ENGINEERING_INTELLIGENCE_PLATFORM.md) | Ten-domain cross-vehicle engineering intelligence reference: consequence propagation, zonal E/E synthesis, service graphs, timebase, conservation, identifiability, provenance, causality, reproducibility capsules, and requirement propagation. |
| [`API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md`](API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md) | Detailed lifecycle/versioning, baseline/diff/replay/lineage/artifact, metrics/tracing, gRPC/WebSocket, XIL, formal reachability, WCET/scheduling, SLAM, network, diagnostics, road-surface, SOTIF, and RSS API guide. |
| [`CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md`](CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md) | Control synthesis, safety shields, prognostics, NVH, emissions/occupant safety, FMI/SSP, middleware, charging/depot/OTA/Digital Key, reconstruction, tire/thermal/driveline/aero, ADS qualification, and probabilistic model checking. |
| [`MUZIXDIAGSYS_MODDING_SDK.md`](sdk/MUZIXDIAGSYS_MODDING_SDK.md) | Plugin/modding SDK and extension interfaces. |



## Professional Engineering Operations Workbenches

| Document | Coverage |
|---|---|
| [`ENGINEERING_UI_PLATFORM.md`](ENGINEERING_UI_PLATFORM.md) | Mission Control, N-way run comparison, requirements-verification-evidence traceability, design-space exploration, Flight Recorder, browser/terminal command parity, and the complete engineering UI architecture. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 75 operator workflows and exact commands for all five professional workbenches. |
| [`../PROFESSIONAL_UI_WORKBENCHES_IMPLEMENTATION_REPORT_2026-08-10.md`](../PROFESSIONAL_UI_WORKBENCHES_IMPLEMENTATION_REPORT_2026-08-10.md) | V11 implementation architecture, algorithms, integration boundaries, and compatibility record. |
| [`../PROFESSIONAL_UI_WORKBENCHES_VALIDATION_2026-08-10.txt`](../PROFESSIONAL_UI_WORKBENCHES_VALIDATION_2026-08-10.txt) | V11 build, sanitizer, CLI, regression, documentation, and package qualification record. |


## Frontier Professional Integration references

| Document or directory | Coverage |
|---|---|
| [`FRONTIER_PROFESSIONAL_INTEGRATION.md`](FRONTIER_PROFESSIONAL_INTEGRATION.md) | OPC UA/AAS, physical DIL/OpenXR, real CAN hardware backends, ns-3 federation, Jupyter labs, Prometheus, Sigstore, HMC/NUTS/MLMC, beamforming/FxLMS ANC, and privacy-aware federated fleet learning. |
| [`../notebooks/`](../notebooks/) | Four executable Jupyter research labs backed by the production Frontier Professional CLI. |
| [`../integrations/ns3/`](../integrations/ns3/) | Real ns-3 packet-federation companion bridge and operating guide. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 73 integrated operator/developer reference. |
| [`../FRONTIER_PROFESSIONAL_INTEGRATION_IMPLEMENTATION_REPORT_2026-08-10.md`](../FRONTIER_PROFESSIONAL_INTEGRATION_IMPLEMENTATION_REPORT_2026-08-10.md) | Implementation map, architecture decisions, compatibility, and subsystem coverage. |
| [`../FRONTIER_PROFESSIONAL_INTEGRATION_VALIDATION_2026-08-10.txt`](../FRONTIER_PROFESSIONAL_INTEGRATION_VALIDATION_2026-08-10.txt) | Build, regression, notebook, PDF, capability, and environmental validation record. |


## Engineering Intelligence Platform references

| Document or directory | Coverage |
|---|---|
| [`ENGINEERING_INTELLIGENCE_PLATFORM.md`](ENGINEERING_INTELLIGENCE_PLATFORM.md) | Authoritative request fields, domain semantics, CLI examples, C++ integration, evidence behavior, non-duplication boundaries, and validation commands for all ten engineering-intelligence domains. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 91 integrated operator/developer workflow. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Exact command workflow for discovery, self-test, per-domain execution, causal/consequence analysis, and reproducibility sealing. |
| [`../ENGINEERING_INTELLIGENCE_PLATFORM_IMPLEMENTATION_REPORT_2026-08-19.md`](../ENGINEERING_INTELLIGENCE_PLATFORM_IMPLEMENTATION_REPORT_2026-08-19.md) | Source architecture, reuse decisions, algorithms, regression coverage, and preservation record. |

## Advanced API CLI references

| Document or directory | Coverage |
|---|---|
| [`ADVANCED_API_CLI_COMMANDS.md`](ADVANCED_API_CLI_COMMANDS.md) | Machine-readable discovery plus 214 direct engineering commands over existing production APIs, global output/validation controls, and qualification semantics. |
| [`../examples/advanced_api_cli/`](../examples/advanced_api_cli/) | Minimal common request plus scripting/discovery examples. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 70 integrated operator/developer reference. |

## Frontier Next platform references

| Document or directory | Coverage |
|---|---|
| [`FRONTIER_NEXT_PLATFORM.md`](FRONTIER_NEXT_PLATFORM.md) | `frontier-next` aggregate CLI plus 16 aliases: wireless PHY/coexistence, secure ranging, complex structured robustness, stochastic identification, protocol/static verification, native scientific solvers, distributed GPU communication, ADIOS2, CGNS/XDMF/Exodus, IBIS/AMI/S-parameters, refrigerant/heat pumps, NDE, maturity/validity, scenario coverage, and model-form uncertainty. |
| [`../examples/frontier_next/`](../examples/frontier_next/) | Sixteen canonical JSON requests plus alias-oriented execution guidance. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 68 integrated operator/developer reference and qualification boundaries. |

## Frontier systems platform references

| Document or directory | Coverage |
|---|---|
| [`FRONTIER_SYSTEMS_PLATFORM.md`](FRONTIER_SYSTEMS_PLATFORM.md) | TSN BMCA/Qbv/preemption/shaping/redundancy/latency qualification, native scientific I/O, native-topology VTKHDF mesh/field interchange, CAE federation, heterogeneous kernels, GPU-direct/PGAS, robust control, safety MPC/MHE, compiler-native AD, calibrated event cameras/flow, multipath/interference raw radar processing, and uncertainty-aware semantic physics contracts. |
| [`../examples/frontier_systems/`](../examples/frontier_systems/) | Canonical executable JSON requests for all twelve `frontier-systems` domains. |

## Frontier expansion platform references

| Document or directory | Coverage |
|---|---|
| [`FRONTIER_EXPANSION_PLATFORM.md`](FRONTIER_EXPANSION_PLATFORM.md) | Safe RL, CMP/traffic-participant interoperability, SysML v2 repository, scientific streaming, modern MPI transport, solver qualification, sensor buses, material assets, particle multiphysics, lubricant/tire laboratories, HAZOP/bow-tie assurance, and software-supply-chain evidence. |
| [`../examples/frontier_expansion/`](../examples/frontier_expansion/) | Canonical executable JSON requests for all fourteen `frontier-expansion` domains. |

## Frontier runtime, positioning, and sensing references

| Document or directory | Coverage |
|---|---|
| [`FRONTIER_RUNTIME_SENSING_PLATFORM.md`](FRONTIER_RUNTIME_SENSING_PLATFORM.md) | ULFM recovery, error-bounded checkpoint compression, out-of-core execution, hardware placement, floating-point certificates, geometric/stiff integration, carrier-phase GNSS, SPAD/FMCW LiDAR, and radar signatures. |
| [`../examples/frontier_runtime/`](../examples/frontier_runtime/) | Canonical tested JSON requests for every `frontier-runtime` domain, both checkpoint profiles, and every stiff solver family. |
| [`../FRONTIER_RUNTIME_SENSING_IMPLEMENTATION_REPORT_2026-08-07.md`](../FRONTIER_RUNTIME_SENSING_IMPLEMENTATION_REPORT_2026-08-07.md) | Source architecture, algorithms, compatibility boundaries, and implementation record. |
| [`../FRONTIER_RUNTIME_SENSING_VALIDATION_2026-08-07.txt`](../FRONTIER_RUNTIME_SENSING_VALIDATION_2026-08-07.txt) | Build, regression, sanitizer, documentation, PDF, and deterministic packaging evidence. |

## Numerical rigor and mathematical assurance

| Document | Coverage |
|---|---|
| [`GLOBAL_NUMERICAL_RIGOR.md`](GLOBAL_NUMERICAL_RIGOR.md) | Strict floating-point policy, stable primitives, conditioned solves, quadrature, roots, integration, and invariant audits. |
| [`GLOBAL_MATHEMATICAL_ASSURANCE.md`](GLOBAL_MATHEMATICAL_ASSURANCE.md) | Automatic error budgets, adaptive precision escalation, exact reductions and references, convergence and manufactured solutions, derivative/KKT certification, solver consensus, property testing, and mathematical evidence certificates. |
| [`../examples/mathematical_assurance_example.cpp`](../examples/mathematical_assurance_example.cpp) | Minimal executable example covering exact reduction, precision escalation, and manufactured-solution convergence. |

## Current NASCAR references

| Document or directory | Coverage |
|---|---|
| [`NASCAR_COMPETITION_PLATFORM.md`](NASCAR_COMPETITION_PLATFORM.md) | Ten competition domains plus ten ecosystem domains, command semantics, evidence, and validation. |
| [`NASCAR_INTEGRATED_FIDELITY_PLATFORM.md`](NASCAR_INTEGRATED_FIDELITY_PLATFORM.md) | Twelve-domain integrated NASCAR runtime covering co-simulation, assimilation, UQ/validity, flexible vehicle, detailed tires, aeroelastic wakes/flaps, ECU/driveline, V8 support systems, pit road, occupant heat/egress, scanned pavement, and spray optics. |
| [`NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md`](NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md) | Twelve additive assurance domains covering effective-dated rules, compliance drift, OEM programs, timing fusion, officiating policy, contact damage, crash/SAFER elements, fire/rescue, debris, composites, fleet reliability, and optimal testing. |
| [`NASCAR_NEXT_GENERATION_PLATFORM.md`](NASCAR_NEXT_GENERATION_PLATFORM.md) | Ten next-generation domains covering electrification, V8 combustion, aero raceability, full-field competition, race control, venues, wheel ends, E/E cybersecurity, race engineering, and broadcast delivery. |
| [`NASCAR_FRONTIER_OPERATIONS_GUIDE.md`](NASCAR_FRONTIER_OPERATIONS_GUIDE.md) | Ten frontier domains and corrected live-bracket, rulebook, fuel, and logistics semantics. |
| [`../examples/nascar_competition/`](../examples/nascar_competition/) | Complete competition request examples. |
| [`../examples/nascar_ecosystem/`](../examples/nascar_ecosystem/) | Complete ecosystem request examples. |
| [`../examples/nascar_frontier/`](../examples/nascar_frontier/) | Complete frontier request examples and correctness checks. |
| [`../examples/nascar_integrated_fidelity/`](../examples/nascar_integrated_fidelity/) | Twelve canonical integrated-fidelity requests and execution notes. |
| [`../examples/nascar_engineering_assurance/`](../examples/nascar_engineering_assurance/) | Twelve canonical engineering-assurance requests and execution notes. |
| [`../NASCAR_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md`](../NASCAR_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md) | Source architecture, algorithms, compatibility, and documentation record for the assurance module. |
| [`../NASCAR_ENGINEERING_ASSURANCE_VALIDATION_2026-07-28.txt`](../NASCAR_ENGINEERING_ASSURANCE_VALIDATION_2026-07-28.txt) | Compiler, unit, CLI, sanitizer, documentation, PDF, and package validation record. |
| [`../NASCAR_INTEGRATED_FIDELITY_IMPLEMENTATION_REPORT_2026-07-27.md`](../NASCAR_INTEGRATED_FIDELITY_IMPLEMENTATION_REPORT_2026-07-27.md) | Source architecture, algorithms, compatibility, and documentation record for the additive integrated module. |
| [`../NASCAR_INTEGRATED_FIDELITY_VALIDATION_2026-07-27.txt`](../NASCAR_INTEGRATED_FIDELITY_VALIDATION_2026-07-27.txt) | Focused build, CLI, deterministic replay, sanitizer, LTO, documentation, PDF, and package validation record. |
| [`../examples/nascar_next_generation/`](../examples/nascar_next_generation/) | Next-generation request templates and end-to-end study sequence. |
| [`../NASCAR_NEXT_GENERATION_IMPLEMENTATION_REPORT_2026-07-23.md`](../NASCAR_NEXT_GENERATION_IMPLEMENTATION_REPORT_2026-07-23.md) | Source integration, algorithms, compatibility, and documentation record. |
| [`../NASCAR_NEXT_GENERATION_VALIDATION_2026-07-23.txt`](../NASCAR_NEXT_GENERATION_VALIDATION_2026-07-23.txt) | Build, CTest, sanitizer, documentation, and package validation record. |
| [`../DEBUG_REFACTOR_REPORT_2026-07-22.md`](../DEBUG_REFACTOR_REPORT_2026-07-22.md) | Defect analysis and source/build refactor record. |
| [`../DEBUG_REFACTOR_VALIDATION_2026-07-22.txt`](../DEBUG_REFACTOR_VALIDATION_2026-07-22.txt) | Toolchain, build, sanitizer, and 157-test accounting. |

## Motorsport platform references

### Current Formula One references

| Document or directory | Coverage |
|---|---|
| [`FORMULA_ONE_REGULATORY_COMPETITION_PLATFORM.md`](FORMULA_ONE_REGULATORY_COMPETITION_PLATFORM.md) | 2026 ERS hardware and metering, 22-car competition, championship governance, power-unit governance, ATR/CFD/testing compliance, remote race control, pit/parc ferme vision, case law, accident reconstruction, and Grade 1 circuit qualification. |
| [`FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_PLATFORM.md`](FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_PLATFORM.md) | PU manufacturer financial compliance, Pirelli production/metrology, sustainable-fuel synthesis, factory manufacture, vehicle assembly, causal setup intelligence, aero raceability, cyber/RF resilience, driver medical performance, and the F2/F3/F1 Academy ladder. |
| [`FORMULA_ONE_FIDELITY_PLATFORM.md`](FORMULA_ONE_FIDELITY_PLATFORM.md) | Coupled full-car dynamics, transient dry/wet tyres, telemetry estimation, sensor/DAQ realism, validation, uncertainty, and identifiability. |
| [`FORMULA_ONE_MULTIPHYSICS_PLATFORM.md`](FORMULA_ONE_MULTIPHYSICS_PLATFORM.md) | Flexible-body dynamics, persistent wake transport, thermal-fluid networks, physics-of-failure, optimal experiments, Bayesian estimation, adaptive fidelity, automatic differentiation, compressible gas paths, and ECU/HIL integration. |
| [`../examples/formula_one_regulatory_competition/`](../examples/formula_one_regulatory_competition/) | Canonical request documents for all ten regulatory and competition domains. |
| [`../FORMULA_ONE_REGULATORY_COMPETITION_IMPLEMENTATION_REPORT_2026-07-23.md`](../FORMULA_ONE_REGULATORY_COMPETITION_IMPLEMENTATION_REPORT_2026-07-23.md) | Formula One-only source integration, algorithms, compatibility, and documentation record. |
| [`../FORMULA_ONE_REGULATORY_COMPETITION_VALIDATION_2026-07-23.txt`](../FORMULA_ONE_REGULATORY_COMPETITION_VALIDATION_2026-07-23.txt) | Build, CTest, sanitizer, documentation, scope-audit, and package validation record. |
| [`../examples/formula_one_industrial_ecosystem/`](../examples/formula_one_industrial_ecosystem/) | Canonical request documents for all ten industrial and ecosystem domains. |
| [`../FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_IMPLEMENTATION_REPORT_2026-07-24.md`](../FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_IMPLEMENTATION_REPORT_2026-07-24.md) | Formula One-only implementation, focused-library architecture, algorithms, and scope record. |
| [`../FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_VALIDATION_2026-07-24.txt`](../FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_VALIDATION_2026-07-24.txt) | Build, test, sanitizer, documentation, scope-audit, and package validation record. |
| [`../FORMULA_ONE_FIDELITY_IMPLEMENTATION_REPORT_2026-07-25.md`](../FORMULA_ONE_FIDELITY_IMPLEMENTATION_REPORT_2026-07-25.md) | Fidelity-platform implementation, numerical architecture, integration, and compatibility record. |
| [`../FORMULA_ONE_FIDELITY_VALIDATION_2026-07-25.txt`](../FORMULA_ONE_FIDELITY_VALIDATION_2026-07-25.txt) | GCC, Clang, sanitizer, CTest, source-integrity, documentation, PDF, and packaging validation record. |
| [`../FORMULA_ONE_MULTIPHYSICS_IMPLEMENTATION_REPORT_2026-07-26.md`](../FORMULA_ONE_MULTIPHYSICS_IMPLEMENTATION_REPORT_2026-07-26.md) | Multiphysics algorithms, integration, compatibility, and implementation record. |
| [`../FORMULA_ONE_MULTIPHYSICS_VALIDATION_2026-07-26.txt`](../FORMULA_ONE_MULTIPHYSICS_VALIDATION_2026-07-26.txt) | Compiler, CMake, CTest, sanitizer, documentation, PDF, and package validation record. |
| [`../DEBUG_REFACTOR_REPORT_2026-07-25.md`](../DEBUG_REFACTOR_REPORT_2026-07-25.md) | Driver-seat global optimization, threshold validation, and finite-arithmetic defect analysis. |
| [`../DEBUG_REFACTOR_VALIDATION_2026-07-25.txt`](../DEBUG_REFACTOR_VALIDATION_2026-07-25.txt) | GCC, Clang, sanitizer, focused CTest, source-regression, and packaging record. |

The other current Formula One references use the `FORMULA_ONE_*.md` naming convention in this directory. Current IndyCar documentation consists of seven production modules:

| Document or directory | Coverage |
|---|---|
| [`INDYCAR_PLATFORM.md`](INDYCAR_PLATFORM.md) | IR-18 rules, oval dynamics, pack aero, driver controls, hybrid strategy, tires, Indianapolis 500 preparation, qualifying, race control, and power-unit pools. |
| [`INDYCAR_OPERATIONS_PLATFORM.md`](INDYCAR_OPERATIONS_PLATFORM.md) | Fuel, V6, aeroscreen, spotter, inspection, telemetry, testing, crash recovery, pit crew, and street-circuit operations. |
| [`INDYCAR_FUTURE_COMPETITION_PLATFORM.md`](INDYCAR_FUTURE_COMPETITION_PLATFORM.md) | 2028 vehicle transition, economics, official timing/stewarding, structural tires, fuel-cell slosh, safety, rules, suspension rigs, multi-car strategy, and aero development. |
| [`INDYCAR_FRONTIER_EXPANSION_PLATFORM.md`](INDYCAR_FRONTIER_EXPANSION_PLATFORM.md) | 2028 2.4-liter power unit, hybrid hardware, driveline, carbon brakes, evolving track/weather, full-field racecraft, incident reconstruction, pit vision, appeals, and complete Month-of-May operations. |
| [`INDYCAR_DEVELOPMENT_OPERATIONS_PLATFORM.md`](INDYCAR_DEVELOPMENT_OPERATIONS_PLATFORM.md) | INDY NXT development, Firestone production, OEM supply parity, renewable fuel, E/E cybersecurity, race engineering, simulator qualification, factory logistics, circuit safety, and medical operations. |
| [`INDYCAR_INTEGRATED_FIDELITY_PLATFORM.md`](INDYCAR_INTEGRATED_FIDELITY_PLATFORM.md) | Multi-rate co-simulation, telemetry assimilation/calibration, 22-DOF multibody dynamics, detailed tires, aeroelastic aerodynamics, ECU/hybrid control, radio/timing uncertainty, pit-lane events, occupant biomechanics, and unified UQ/model validity. |
| [`INDYCAR_ENGINEERING_ASSURANCE_PLATFORM.md`](INDYCAR_ENGINEERING_ASSURANCE_PLATFORM.md) | Fourteen assurance domains covering rule provenance, legality drift, 2028 certification, manufacturer entry, observation fusion, officiating policy, contact/crash/fire/debris safety, composite and tire materials, fleet reliability, and optimal testing. |
| [`../examples/indycar_frontier_expansion/`](../examples/indycar_frontier_expansion/) | Compiled, canonical end-to-end inputs and validation workflow for the ten frontier systems. |
| [`../examples/indycar_development_operations/`](../examples/indycar_development_operations/) | Canonical requests for all ten development and operations domains. |
| [`../examples/indycar_integrated_fidelity/`](../examples/indycar_integrated_fidelity/) | Canonical executable requests for all ten integrated-fidelity domains. |
| [`../examples/indycar_engineering_assurance/`](../examples/indycar_engineering_assurance/) | Canonical executable requests for all fourteen engineering-assurance domains. |
| [`../INDYCAR_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md`](../INDYCAR_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md) | Source architecture, algorithms, compatibility, evidence, and documentation record. |
| [`../INDYCAR_ENGINEERING_ASSURANCE_VALIDATION_2026-07-28.txt`](../INDYCAR_ENGINEERING_ASSURANCE_VALIDATION_2026-07-28.txt) | Compiler, test, CLI, sanitizer, documentation, PDF, and package validation record. |
| [`../INDYCAR_INTEGRATED_FIDELITY_IMPLEMENTATION_REPORT_2026-07-27.md`](../INDYCAR_INTEGRATED_FIDELITY_IMPLEMENTATION_REPORT_2026-07-27.md) | Algorithms, source integration, compatibility, evidence, and implementation scope. |
| [`../INDYCAR_INTEGRATED_FIDELITY_VALIDATION_2026-07-27.txt`](../INDYCAR_INTEGRATED_FIDELITY_VALIDATION_2026-07-27.txt) | Compiler, unit, CLI, sanitizer, documentation, PDF, and package validation record. |
| [`../INDYCAR_DEVELOPMENT_OPERATIONS_IMPLEMENTATION_REPORT_2026-07-23.md`](../INDYCAR_DEVELOPMENT_OPERATIONS_IMPLEMENTATION_REPORT_2026-07-23.md) | Implementation, integration, scope, and validation architecture. |
| [`../INDYCAR_DEVELOPMENT_OPERATIONS_VALIDATION_2026-07-23.txt`](../INDYCAR_DEVELOPMENT_OPERATIONS_VALIDATION_2026-07-23.txt) | Build, test, sanitizer, documentation, scope-audit, and package validation record. |
| [`../INDYCAR_FRONTIER_EXPANSION_IMPLEMENTATION_REPORT_2026-07-22.md`](../INDYCAR_FRONTIER_EXPANSION_IMPLEMENTATION_REPORT_2026-07-22.md) | Source integration, compatibility, and documentation record. |
| [`../INDYCAR_FRONTIER_EXPANSION_VALIDATION_2026-07-22.txt`](../INDYCAR_FRONTIER_EXPANSION_VALIDATION_2026-07-22.txt) | Focused build, CTest, sanitizer, and documentation validation record. |
| [`../DEBUG_REFACTOR_REPORT_2026-07-23.md`](../DEBUG_REFACTOR_REPORT_2026-07-23.md) | IndyCar semantic defect analysis, focused-library architecture refactor, and PTY regression hardening. |
| [`../DEBUG_REFACTOR_VALIDATION_2026-07-23.txt`](../DEBUG_REFACTOR_VALIDATION_2026-07-23.txt) | Complete build, sanitizer, motorsport, package, and 160-test accounting. |

The comprehensive manual Chapters 29-50, Chapter 57, and Chapter 60 provide the integrated motorsport operator view and exact validation targets.



## Generalized platform-wide simulation services

| Document | Coverage |
|---|---|
| [`GENERALIZED_SIMULATION_PLATFORM.md`](GENERALIZED_SIMULATION_PLATFORM.md) | Elastic deterministic execution, coordinated checkpoints, unified mesh/field operations, hardware autotuning, high-index DAE compilation, differential verification, benchmark registry, SQL data lake, HTTP/notebook APIs, and deterministic-equivalence qualification. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 51 integrated operator workflow, exact build/test commands, security notes, and qualification boundaries. |
| [`../GENERALIZED_SIMULATION_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md`](../GENERALIZED_SIMULATION_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md) | Implementation architecture, algorithms, compatibility, and source integration. |
| [`../GENERALIZED_SIMULATION_PLATFORM_VALIDATION_2026-07-26.txt`](../GENERALIZED_SIMULATION_PLATFORM_VALIDATION_2026-07-26.txt) | Compiler, unit, source, sanitizer, documentation, PDF, and package validation record. |

## Scientific fidelity and predictive accuracy

| Document | Coverage |
|---|---|
| [`SCIENTIFIC_FIDELITY_PLATFORM.md`](SCIENTIFIC_FIDELITY_PLATFORM.md) | Strong coupling, hp-adaptive DG, nonsmooth contact, stochastic fields, field assimilation and inversion, real-fluid phase equilibrium, multimodel inference, total error budgets, virtual metrology, and progressive fracture. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 52 integrated scientific-fidelity workflow, API examples, exact commands, and qualification boundaries. |
| [`../SCIENTIFIC_FIDELITY_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md`](../SCIENTIFIC_FIDELITY_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md) | Numerical algorithms, source integration, compatibility, and documentation record. |
| [`../SCIENTIFIC_FIDELITY_PLATFORM_VALIDATION_2026-07-26.txt`](../SCIENTIFIC_FIDELITY_PLATFORM_VALIDATION_2026-07-26.txt) | Compiler, CMake, CTest, sanitizer, documentation, PDF, and package validation record. |


## Engineering and interoperability references

Use the platform-specific Markdown files in this directory for model equations, APIs, qualification boundaries, evidence formats, and examples. The comprehensive manual remains authoritative for installation, command behavior, workflows, troubleshooting, test policy, and release procedures.

## Historical reports and validation records

Root-level `*_IMPLEMENTATION_REPORT_*.md`, `*_VALIDATION_*.txt`, and `DEBUG_REFACTOR_REPORT_*.md` files are immutable development records for their stated dates. They explain what was implemented or validated at that point; they do not supersede the current user manual or current platform guides.

## Documentation maintenance workflow

```bash
python3 tests/user_manual_regression.py .
python3 tests/documentation_consistency_regression.py .
./tools/generate_user_manual_pdf.sh
python3 tools/package_source.py MuzixDiagSys-source.zip --root . --prefix MuzixDiagSys
```

Update the Markdown sources first, regenerate derived PDF/DOCX artifacts, inspect their rendered pages, run both documentation regressions, and package only after all checks pass.


| [`FORMULA_ONE_REALISM_PLATFORM.md`](FORMULA_ONE_REALISM_PLATFORM.md) | Formula One suspension, tyre, circuit, damage, human, driveline, RF, pedigree, strategy, and wind-tunnel realism APIs and qualification guidance. |
| [`FORMULA_ONE_REALISM_IMPLEMENTATION_REPORT_2026-07-26.md`](../FORMULA_ONE_REALISM_IMPLEMENTATION_REPORT_2026-07-26.md) | Implementation scope, integration, corrections, and compatibility record. |
| [`FORMULA_ONE_REALISM_VALIDATION_2026-07-26.txt`](../FORMULA_ONE_REALISM_VALIDATION_2026-07-26.txt) | Compiler, runtime, sanitizer, documentation, PDF, and packaging validation. |


## Continuum reality, multiphase, and adaptive resolution

| Document | Coverage |
|---|---|
| [`CONTINUUM_REALITY_PLATFORM.md`](CONTINUUM_REALITY_PLATFORM.md) | Moving-interface CFD, turbulence hierarchy, porous-electrode electrochemistry, phase change, participating-media radiation, 3-D field assimilation, poromechanics, aerosol population balances, manufactured verification, and adaptive resolution. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 54 integrated operator workflow, build commands, convergence requirements, and qualification boundaries. |
| [`../CONTINUUM_REALITY_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md`](../CONTINUUM_REALITY_PLATFORM_IMPLEMENTATION_REPORT_2026-07-26.md) | Production architecture and source integration. |
| [`../CONTINUUM_REALITY_PLATFORM_VALIDATION_2026-07-26.txt`](../CONTINUUM_REALITY_PLATFORM_VALIDATION_2026-07-26.txt) | Compiler, runtime, sanitizer, documentation, PDF, and package validation record. |

| [`FORMULA_ONE_INTEGRATED_OPERATIONS_PLATFORM.md`](FORMULA_ONE_INTEGRATED_OPERATIONS_PLATFORM.md) | Spatial pit/garage operations, occupant safety, semantic radio, recovery, spray optics, carbon brakes, active aero, sustainable-fuel/turbo, switching ERS/EMC, and Bayesian aero fusion. |
| [`../FORMULA_ONE_INTEGRATED_OPERATIONS_IMPLEMENTATION_REPORT_2026-07-26.md`](../FORMULA_ONE_INTEGRATED_OPERATIONS_IMPLEMENTATION_REPORT_2026-07-26.md) | Integrated-operations implementation, algorithms, integration, compatibility, and qualification record. |
| [`../FORMULA_ONE_INTEGRATED_OPERATIONS_VALIDATION_2026-07-26.txt`](../FORMULA_ONE_INTEGRATED_OPERATIONS_VALIDATION_2026-07-26.txt) | Compiler, CMake, CTest, sanitizer, documentation, PDF, and packaging validation record. |

## Fundamental physics and runtime credibility

| Document | Coverage |
|---|---|
| [`FUNDAMENTAL_PHYSICS_PLATFORM.md`](FUNDAMENTAL_PHYSICS_PLATFORM.md) | Thermodynamic audits, nonlinear structures, surface chemistry, rarefied transport, phase fields, coupled waves, POD reduced models, runtime validity, D-optimal sensor placement, causal localization, and focused qualification commands. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 56 operator guidance, numerical contracts, focused build workflow, and qualification boundary. |
| [`../DEBUG_REFACTOR_REPORT_2026-07-27.md`](../DEBUG_REFACTOR_REPORT_2026-07-27.md) | Correctness defects, numerical refactors, build modularization, compatibility, and regression coverage. |
| [`../DEBUG_REFACTOR_VALIDATION_2026-07-27.txt`](../DEBUG_REFACTOR_VALIDATION_2026-07-27.txt) | Compiler, sanitizer, focused CTest, static regression, and validation-boundary record. |

## Electronics engineering, embedded hardware, manufacturing, and EMC assurance

| Document | Coverage |
|---|---|
| [`ELECTRONICS_ENGINEERING_ASSURANCE_PLATFORM.md`](ELECTRONICS_ENGINEERING_ASSURANCE_PLATFORM.md) | Low-voltage and HV distribution, sleep/wake, PMICs, analog/mixed-signal, converters, PCB SI/PI, ECAD, grounding, semiconductors, gate drivers, charging, communication physical layers, flashing, AUTOSAR, RTL, BIST, NVM, aging, PCBA, inspection, provisioning, physical attacks, chamber instrumentation, and EMC mitigation. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 61 integrated operator and developer reference with algorithms, API examples, test commands, and qualification limits. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Section 22 complete electronics engineering workflow and exact qualification commands. |
| [`../examples/electronics_engineering_assurance/`](../examples/electronics_engineering_assurance/) | Canonical ECAD connectivity and SPICE inputs plus focused build instructions. |
| [`../ELECTRONICS_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md`](../ELECTRONICS_ENGINEERING_ASSURANCE_IMPLEMENTATION_REPORT_2026-07-28.md) | Source architecture, algorithms, corrections, compatibility, and implementation scope. |

## NHRA championship, strategy, diagnosis, and Heritage competition

| Document | Coverage |
|---|---|
| [`NHRA_CHAMPIONSHIP_STRATEGY_PLATFORM.md`](NHRA_CHAMPIONSHIP_STRATEGY_PLATFORM.md) | National/divisional points, Countdown simulation, Mission Challenge, crew-chief optimization, causal diagnosis, Monte Carlo event strategy, and historical/Heritage competition. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 62 integrated operator and developer reference, request contracts, exact commands, evidence, and qualification boundary. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Section 23 reproducible NHRA CLI workflow. |
| [`../examples/nhra_championship_strategy/`](../examples/nhra_championship_strategy/) | Executable JSON requests for all seven domains. |
| [`../NHRA_CHAMPIONSHIP_STRATEGY_IMPLEMENTATION_REPORT_2026-07-29.md`](../NHRA_CHAMPIONSHIP_STRATEGY_IMPLEMENTATION_REPORT_2026-07-29.md) | Source architecture, algorithms, integration, compatibility, and qualification record. |

- [CTest Runtime-Artifact Fixture](CTEST_ARTIFACT_FIXTURE.md) — direct CTest build dependency closure, compiled-test fixture semantics, and missing-executable cascade prevention.

## Simulation assurance, resilience, and reproducibility

| Document | Coverage |
|---|---|
| [`SIMULATION_ASSURANCE_RESILIENCE_REPRODUCIBILITY.md`](SIMULATION_ASSURANCE_RESILIENCE_REPRODUCIBILITY.md) | Deterministic fault injection, transactional hierarchical checkpoints, structured error provenance, conservation ledger, numerical trust evidence, semantic result caching/incremental recalculation, certificates, CLI, beginner-menu integration, and qualification. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 63 operator workflow and command reference for the integrated assurance framework. |

## Frontier integration, assurance, and autonomous engineering

| Document | Coverage |
|---|---|
| [`FRONTIER_INTEGRATION_PLATFORM.md`](FRONTIER_INTEGRATION_PLATFORM.md) | DDS-XRCE/Zenoh, MACsec, EMC, wiring SI/PI, continuous H-infinity/structured-real robustness, system identification, proof assistants, OSLC/SACM, RTL/Verilator, SQLite engineering queries, manufacturing process physics, uncertainty propagation, multifidelity scheduling, and autonomous experiment campaigns. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 67 integrated operator/developer reference, exact CLI surface, algorithms, evidence and qualification boundaries. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Section 25 complete reproducible `frontier-integration` command workflow. |
| [`../examples/frontier_integration/`](../examples/frontier_integration/) | Fourteen executable JSON requests, one for every frontier-integration domain. |


## Motorsport CLI convenience commands

| Document | Coverage |
|---|---|
| [`MOTORSPORT_CLI_COMMANDS.md`](MOTORSPORT_CLI_COMMANDS.md) | Aggregate Formula One/IndyCar routing, complete NASCAR suite routing, 24 direct motorsport shortcuts, syntax, routing guarantees, examples, and regression procedure. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 69 authoritative operator reference for the additive Formula One, NASCAR, and IndyCar CLI commands. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Section 27 reproducible motorsport convenience-command workflow. |

## Backend executable / interactive-shell parity

| Document | Coverage |
|---|---|
| [`BACKEND_EXECUTABLE_CLI_PARITY.md`](BACKEND_EXECUTABLE_CLI_PARITY.md) | Complete nine-executable routing map, shared-runner architecture, authenticated engineering-session inheritance, completion behavior, long-running worker semantics, and regression contract. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Chapter 74 operator reference for standalone-to-interactive backend equivalence. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Section 28.12 exact backend-parity command workflow. |

## Integrated engineering UI platform

| Document | Coverage |
|---|---|
| [`ENGINEERING_UI_PLATFORM.md`](ENGINEERING_UI_PLATFORM.md) | Complete terminal/browser engineering UI architecture through V16, exact shell commands, synchronized-time behavior, graphical direct manipulation, real-data policy, security controls, persistence semantics, rendering backends, and qualification commands. |

- **V12 Professional Engineering Desktop** — see `ENGINEERING_UI_PLATFORM.md` and User Manual Chapter 76 for docking, streaming, campaigns, adaptive DOE, scenario timeline, workflow debugging, qualification review, live topology, virtual channels, and plot measurements.

- `PROFESSIONAL_ENGINEERING_OPERATIONS_V13.md` — V13 3D twin, runbooks, release qualification, engineering data catalog, calibration/correlation and live collaboration.

- `ENGINEERING_UI_PLATFORM.md` (V16 section) - V16 graphical docking desktop, WebGL twin renderer, out-of-core telemetry plots, virtualized engineering grid, graphical calibration/topology/scenario/workflow/track tools, Semantic CLI/Problems, browser security, and qualification.

## V19 help and diagnostics navigation

Chapter 80 of the User Manual is the authoritative operator reference for the unified V19 help/diagnostic workflow. `COMMAND_REGISTRY_AND_COMPLETION.md` documents how canonical metadata and nested grammar generate detailed help; `STREAMLINED_UI_EXPERIENCE.md` covers the terminal interaction; `ENGINEERING_UI_PLATFORM.md` covers graphical Problems/Semantic CLI integration; `ADVANCED_API_CLI_COMMANDS.md` retains domain request/schema details. This avoids a separate duplicated help manual while keeping focused engineering references intact.

### UI customization infrastructure

- `UI_CUSTOMIZATION_PLATFORM.md` — Version 20 presentation-only profiles, dashboard/signal presentation, semantic themes, shortcut capture, palette personalization, terminal rendering, UI performance budgets, multi-monitor mappings, and workflow/diagnostic profile composition.

## V20.1.2 integrated terminal engineering cockpit

| Document | Coverage |
|---|---|
| [`ENGINEERING_UI_PLATFORM.md`](ENGINEERING_UI_PLATFORM.md) | Authoritative backend/API-to-InteractiveShell mapping for Unicode sparklines, event timeline, time travel, causal inspector, experiment cockpit, jobs, notifications, tabbed lower pane, subsystem navigator, parameter/docs inspectors, pit wall, track map, friction circle, profiler, uncertainty view, and qualification. |
| [`GLOBAL_UI_ARCHITECTURE.md`](GLOBAL_UI_ARCHITECTURE.md) | Ownership and non-duplication boundaries for context, jobs, activity/state, navigation, and terminal projections. |
| [`STREAMLINED_UI_EXPERIENCE.md`](STREAMLINED_UI_EXPERIENCE.md) | Terminal/SSH interaction model and persisted analytical lower-pane views. |
| [`UI_CUSTOMIZATION_PLATFORM.md`](UI_CUSTOMIZATION_PLATFORM.md) | Preference boundary for persisted lower-pane view selection. |
| [`MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) | Exact operator quickstart for the integrated terminal engineering cockpit. |
| [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md) | Full Chapter 84 operator reference and CLI examples. |

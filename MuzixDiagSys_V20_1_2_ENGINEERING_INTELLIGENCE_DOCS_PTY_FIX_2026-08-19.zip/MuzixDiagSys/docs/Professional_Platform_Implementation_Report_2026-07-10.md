# MuzixDiagSys Professional Platform Implementation Report

**Implementation date:** 2026-07-10  
**Language standard:** C++17  
**Primary executable:** `muzixdiagsys`  
**New reusable library:** `aesim_professional`  
**Compatibility baseline:** `advanced_engine_sim_research_grade_2026-07-09`

## Executive summary

This revision implements the requested professional platform capabilities without removing the established simulator, research core, terminal dashboard, command families, data formats, ABI-v1 plugins, earlier FMI workflow, or regression coverage.

The implementation adds approximately 5,273 lines of focused C++ interfaces, implementation code, sample binary components, and end-to-end tests. The new functionality is organized in the independent `aesim_professional` static library and connected to the existing terminal application through compatibility adapters. Existing engine, transmission, vehicle, emissions, diagnostics, research, calibration, uncertainty, plugin, API, and terminal features remain available.

The completed capabilities are:

1. Full-state checkpointing, branch management, and deterministic command replay.
2. Compile-time dimensional quantities and checked unit conversion at professional subsystem boundaries.
3. Versioned configuration, calibration, checkpoint, and scenario schemas with migrations.
4. Continuous mass, energy, torque, numerical, map, state-clamp, and deadline health monitoring.
5. Declarative YAML/JSON scenarios with temporal assertions and condition-driven execution.
6. Native plugin ABI v2 with supervised out-of-process execution and serializable plugin state.
7. FMI 3.0.2 model export and import supporting Co-Simulation, Model Exchange, and Scheduled Execution.
8. Deterministic MIL/SIL execution modes, including shadow comparison modes and a stable SIL C ABI.

No requested feature is represented by a stub, placeholder, TODO branch, or deliberately unimplemented command path.

## Source architecture

### New public interfaces

```text
include/
├── aesim/
│   └── professional/
│       ├── checkpoint.hpp
│       ├── document.hpp
│       ├── execution.hpp
│       ├── fmi3.hpp
│       ├── health.hpp
│       ├── plugin_host.hpp
│       ├── research_state.hpp
│       ├── scenario.hpp
│       ├── schema.hpp
│       └── units.hpp
├── aesim_plugin_abi_v2.h
├── aesim_sil_controller_abi.h
└── fmi3/
    └── fmi3Functions.h
```

### New implementations

```text
src/professional/
├── checkpoint.cpp
├── document.cpp
├── execution.cpp
├── fmi3.cpp
├── health.cpp
├── plugin_host.cpp
├── research_state.cpp
├── scenario.cpp
├── schema.cpp
└── units.cpp
```

### Executable reference components and tests

```text
fmi/aesim_fmi3_model.cpp
plugins/sample_native_plugin_v2.cpp
plugins/sample_sil_controller.cpp
tests/professional_core_tests.cpp
tests/professional_platform_v2_regression.py
```

### CMake targets

- `aesim_core` — existing modular numerical and research core.
- `aesim_professional` — new professional platform library.
- `muzixdiagsys` — retained terminal simulator and compatibility surface.
- `aesim_fmi3_model` — FMI 3 model binary used in exported FMUs.
- `aesim_sample_native_plugin_v2` — complete ABI-v2 reference plugin.
- `aesim_sample_sil_controller` — complete SIL controller reference library.
- `professional_core_tests` — direct unit and integration tests for the new library.

Zlib is now a required build dependency for bounded ZIP/Deflate FMU package processing.

---

## 1. Full-state checkpoint, branching, and deterministic replay

### Checkpoint format

The implementation introduces the versioned `aesim.checkpoint` schema, currently at version `3.0.0`. A checkpoint image contains:

- complete legacy plant and controller state;
- transmission, vehicle, thermal, emissions, diagnostics, and readiness state;
- modular research-core state;
- cylinder and gas-path internal state;
- multi-rate scheduler time, periods, release points, and statistics;
- deterministic random-stream state;
- DTC records and freeze-frame memory;
- numerical-health snapshot and rolling residual histories;
- MIL/SIL manager mode, timing, controller state, and last output;
- ABI-v2 plugin descriptors, paths, isolation modes, enable state, and serialized state;
- checkpoint parent, branch, creation time, and metadata;
- SHA-256 integrity digest of canonical state serialization.

Checkpoint writes use temporary-file replacement so an interrupted save does not replace a valid prior image with a partial file. Loads validate the schema and digest before applying state.

### Branching

The branch manager stores named immutable checkpoint images. Branches can be created, listed, compared, removed, and restored. Comparison reports state hashes, parent relationships, branch metadata, and recursive document differences.

### Deterministic replay

Replay files use schema `aesim.replay` version `2.0.0` and embed the exact initial full-state checkpoint. Every recorded command contains:

- monotonically increasing sequence number;
- integer simulation time in nanoseconds;
- command text;
- deterministic state hash before execution;
- deterministic state hash after execution.

Replay pauses asynchronous stepping, restores the embedded checkpoint, executes each command, and verifies before/after state hashes. Wall-clock execution timings are retained in checkpoints for diagnostics but excluded from deterministic trajectory hashes because they are observational and do not alter simulated physics.

### Commands

```text
checkpoint status
checkpoint save <file.aecp>
checkpoint verify <file.aecp>
checkpoint inspect <file.aecp>
checkpoint load <file.aecp>
branch create <name>
branch list
branch compare <left> <right>
branch load <name>
branch remove <name>
replay start <file.aereplay>
replay stop
replay verify <file.aereplay>
```

### Correctness work completed during integration

- Added missing DTC and freeze-frame serialization.
- Added health-monitor rolling-history serialization rather than preserving only aggregate RMS values.
- Added backward restoration behavior for prior health snapshots.
- Added plugin and MIL/SIL state restoration.
- Corrected `checkpoint inspect <file>` routing so it inspects the requested artifact instead of returning live status.
- Removed wall-clock-derived counters from replay equivalence hashes while retaining them in checkpoint diagnostics.

---

## 2. Strong dimensional units

The new professional interfaces use `Quantity<Dimension, Rep>` types parameterized by compile-time SI base-dimension exponents. Addition and subtraction are restricted to identical dimensions; multiplication and division derive result dimensions at compile time.

Implemented quantity types include:

- dimensionless values;
- length, area, and volume;
- mass and mass flow;
- time and frequency;
- temperature;
- angle and angular speed;
- velocity and acceleration;
- force, pressure, energy, torque, and power;
- inertia and heat capacity.

Typed interfaces are used by:

- numerical-health samples;
- MIL/SIL controller inputs and outputs;
- professional plant-state adapters;
- scenario set/ramp conversion boundaries;
- controller and plugin conversion boundaries.

The unit registry provides normalized symbol lookup, offset-unit handling, compatibility checking, SI conversion, and conversion between compatible units. It rejects unknown units, dimension mismatches, and non-finite converted values.

Examples of supported categories include SI and common engineering representations for pressure, temperature, torque, power, mass flow, speed, angle, time, volume, and dimensionless percentages.

The established legacy plant internals remain source compatible and are adapted at subsystem boundaries. This preserves all existing behavior while ensuring that newly introduced professional interfaces cannot silently mix incompatible dimensions.

---

## 3. Versioned schemas and migrations

The schema registry implements semantic versions, canonical schema identifiers, validation findings, machine-readable JSON-schema descriptions, and deterministic major-version migration functions.

### Current schemas

| Schema | Current version | Purpose |
|---|---:|---|
| `aesim.config` | 2.0.0 | Engine and vehicle configuration |
| `aesim.calibration` | 2.0.0 | Typed calibration parameter sets |
| `aesim.checkpoint` | 3.0.0 | Full-state checkpoint image |
| `aesim.scenario` | 2.0.0 | Declarative scenario program |

### Implemented migrations

Configuration migration includes relocation of historical flat fields into structured engine and vehicle sections. Calibration migration converts earlier value maps into typed parameter arrays. Checkpoint migrations add scheduler/random state and then plugin/branch state. Scenario migration converts ordered command arrays into timestamped timeline events and adds temporal assertion support.

Validation reports include:

- inferred or explicit schema identity;
- document and current versions;
- path-specific errors and warnings;
- required-field and type validation;
- future-major-version rejection;
- older-version migration warning;
- final pass/fail counts.

### Commands

```text
schema list
schema show <schema>
schema validate <file> [schema]
schema migrate <input> <output> [schema]
schema diff <left> <right>
```

YAML and JSON documents share the same internal document tree and canonical JSON serializer, enabling reproducible hashes regardless of the source syntax.

---

## 4. Continuous conservation and numerical-health monitoring

The health monitor executes after every accepted plant step and consumes SI-typed values. It tracks latest and rolling RMS values for:

- whole-system mass conservation closure;
- energy conservation closure;
- torque balance;
- local numerical error;
- rejected solver steps;
- nonlinear iterations;
- map extrapolation events;
- state clamp events;
- MIL/SIL controller deadline misses.

Thresholds have warning and invalid-run levels. Findings use `Information`, `Warning`, `InvalidRun`, and `Abort` policies. The monitor exposes live status, human-readable reports, JSON export, checkpoint serialization, and exact restoration of rolling windows.

### Gas-path conservation correction

During final validation, the previous research gas-path value named `mass_balance_residual_g_s` was found to contain intake-manifold accumulation rather than a conservation residual. The calculation now evaluates whole-control-volume closure:

```text
external air + fuel
- turbine outlet
- wastegate outlet
- intake stored-mass rate
- exhaust stored-mass rate
```

Engine-cylinder transfer and EGR cancel as internal flows. The result is zero to integration precision unless a state guard clips accepted mass, in which case the residual correctly exposes the inconsistency. The nominal end-to-end scenario now remains valid without weakening thresholds.

### Commands

```text
health status
health reset
health limits
health json <output.json>
```

---

## 5. Declarative scenario and assertion language

The `aesim.scenario` v2 interpreter loads YAML or JSON, validates it, and executes it against callbacks supplied by the simulator.

### Event forms

- fixed-time events;
- condition-triggered events;
- unit-aware `set` events;
- linear ramps over deterministic integer step intervals;
- existing terminal command execution;
- checkpoint events;
- branch events;
- stop conditions.

Condition events are latched and execute once when their expression transitions true. Timeline events are sorted deterministically by release time and original document order.

### Expression engine

The expression parser supports:

- metric references;
- numeric literals;
- parentheses;
- unary operators;
- arithmetic operators;
- comparison operators;
- Boolean conjunction/disjunction;
- standard mathematical functions used by assertions and triggers.

Metric values are supplied by the simulator’s metric registry, so scenarios can evaluate plant, controller, research, and diagnostic channels.

### Temporal assertions

- `always` — must remain true for every evaluation.
- `eventually` — must become true before completion.
- `at_end` — evaluated against final state.

Severities are `warning`, `error`, and `abort`. Results include evaluation count, failure count, first pass/failure times, final value, and overall pass/fail state.

### Commands

```text
scenario2 validate <scenario.yaml>
scenario2 run <scenario.yaml> [result.json]
scenario2 explain <scenario.yaml>
```

The earlier `scenario` command family remains available for compatibility.

---

## 6. Plugin ABI v2 and process isolation

ABI v1 remains supported unchanged. ABI v2 is a stable C interface with:

- ABI and structure-size negotiation;
- descriptor and capability discovery;
- opaque plugin handles;
- deterministic seed/configuration input;
- explicit lifecycle calls;
- typed step context and output structures;
- bounded diagnostic strings;
- state-size query, serialization, and deserialization;
- structured status codes;
- host logging and service callbacks.

### Isolation modes

#### In-process

Loads the shared library with the platform dynamic-loader API and calls the ABI directly. This mode has the lowest overhead and is appropriate for trusted, tested plugins.

#### Process-isolated

On POSIX systems, the host creates a worker process and bounded IPC channel. The worker loads and owns the plugin. The parent performs request/response transactions with:

- explicit message framing and maximum payload sizes;
- poll-based timeouts;
- heartbeat-equivalent liveness through request completion;
- process-death detection;
- SIGPIPE avoidance;
- error and timeout counters;
- controlled restart accounting;
- state serialization across checkpoint operations;
- crash containment from the simulator process.

The implementation does not attempt to catch a segmentation fault inside the host process; process mode prevents that fault from occurring in the host in the first place.

### Commands

```text
plugin v2 abi
plugin v2 load <library> <inprocess|process> [configuration-json] [seed]
plugin v2 status
plugin v2 enable
plugin v2 disable
plugin v2 timeout <milliseconds>
plugin v2 unload
```

A complete `sample_native_plugin_v2` is built and tested in both direct unit tests and terminal workflows.

---

## 7. FMI 3.0.2 import and export

The implementation adds a functional FMI 3 model binary and FMU package manager. It supports all three FMI 3 interface classes exposed by this model:

- Co-Simulation;
- Model Exchange;
- Scheduled Execution.

### Export

Export creates a valid FMU directory structure and ZIP package containing:

- `modelDescription.xml` with FMI 3.0.2 metadata;
- interface declarations for enabled modes;
- scalar variables, causality, variability, units, and value references;
- continuous-state derivative metadata and `ModelStructure` dependencies;
- current-platform model binary;
- resource-state JSON;
- package documentation.

### Import and package security

The importer reads the ZIP central directory and supports normal stored and Deflate-compressed entries, including data descriptors. It validates CRC-32 and enforces bounded entry, aggregate extraction, path length, and file count limits.

It rejects:

- encrypted entries;
- unsupported compression methods;
- multi-disk archives;
- unsupported ZIP64 constructs;
- absolute paths;
- `..` path traversal;
- malformed offsets and truncated data;
- CRC mismatches;
- missing model description or host binary.

### Runtime execution

- **Co-Simulation:** initializes an FMU instance and advances using `fmi3DoStep`.
- **Model Exchange:** reads continuous states and derivatives, integrates them with deterministic RK4 substeps, writes states back, and processes event-mode transitions.
- **Scheduled Execution:** activates declared model partitions at deterministic clock intervals.
- **FMU state:** uses `fmi3GetFMUState`, serialized-size query, portable fixed-format state serialization, deserialization, and restoration.

### Commands

```text
fmi3 export <model.fmu>
fmi3 inspect <model.fmu>
fmi3 import <model.fmu> <cs|me|se>
fmi3 step <seconds> <throttle-percent> <load-torque-nm>
fmi3 state save <file>
fmi3 state load <file>
fmi3 unload
fmi3 cosim <model.fmu> <duration> <step> <trace.csv>
```

The implementation was tested with its native package and a package repacked using ordinary Deflate compression. It is an implemented FMI 3.0.2 subset for this model; no claim is made that a third-party FMI compliance suite has certified it.

---

## 8. MIL/SIL execution modes

The execution manager supplies deterministic integer-time controller scheduling and the following modes:

- `legacy` — existing simulator control remains authoritative;
- `mil` — built-in typed model controller drives the professional control output;
- `sil` — dynamically loaded production-style controller library drives output;
- `shadow_mil` — MIL executes and is measured but does not alter the plant;
- `shadow_sil` — SIL executes and is measured but does not alter the plant.

### Typed controller interface

Inputs include simulation time, driver pedal, engine angular speed, vehicle velocity, manifold and boost pressure, lambda, coolant temperature, knock index, and requested torque.

Outputs include throttle, wastegate, fuel multiplier, spark advance, requested torque, diagnostic flags, and a bounded diagnostic message.

### Deterministic scheduling

- signed 64-bit integer nanosecond release times;
- configurable controller period;
- fixed same-time behavior;
- skipped-release accounting;
- execution count, error count, maximum and mean wall execution time;
- deadline-miss accounting;
- serializable scheduler/controller state.

### SIL ABI

The stable C ABI provides query, create, reset, step, serialize, deserialize, and destroy functions using versioned structures and opaque handles. The included sample SIL controller is a real dynamically loaded controller and is exercised end to end.

### Commands

```text
execution status
execution mode <legacy|mil|sil|shadow_mil|shadow_sil>
execution period <seconds>
execution reset
execution mil configure <controller.json>
execution sil load <library> [configuration-json] [seed]
execution sil unload
```

This is the software foundation for future PIL/HIL adapters. It does not claim hard real-time execution or physical HIL I/O in this revision.

---

## Compatibility and retained features

The implementation is additive. The following remain intact:

- prior CLI and dashboard behavior;
- existing `state` save/load paths;
- existing scenario and schema commands;
- ABI-v1 manifest and native plugins;
- prior FMI/FMU workflow;
- research-core combustion, gas-path, calibration, uncertainty, validation, and provenance features;
- vehicle, transmission, diagnostics, emissions, aftertreatment, durability, safety, API, telemetry, reports, and data tooling;
- build hardening and optional sanitizers/LTO/native optimization.

Where a new subsystem supersedes a partial older facility, the older command remains a compatibility surface rather than being deleted.

---

## Verification and validation

### Toolchain

| Component | Version |
|---|---|
| GCC | 14.2.0 |
| Clang | 17.0.0 |
| CMake | 3.31.6 |
| Python | 3.13.5 |
| zlib | 1.3.1 |

### Test results

| Configuration | Result |
|---|---:|
| GCC Debug | 34/34 tests passed |
| GCC RelWithDebInfo | 34/34 tests passed |
| GCC ASan + UBSan + leak detection | Professional unit and end-to-end platform regressions passed; no sanitizer finding |
| Clang 17 Debug | Professional unit and end-to-end platform regressions passed |
| Marker scan | No TODO, FIXME, placeholder, stub, or “not implemented” marker in added professional modules/tests |
| Fresh extracted-package build | Configure, compile, professional unit tests, and terminal platform regression passed |

A separate clean extraction of the final ZIP was configured with CMake/Ninja, rebuilt without access to the working build trees, and passed `professional_core_tests` plus `professional_platform_v2_regression`.

The execution environment imposed an aggregate process ceiling during several long CTest invocations. The suite was therefore completed in deterministic ranges; every one of the 34 registered tests passed.

### New direct test coverage

`professional_core_tests` verifies:

- dimension arithmetic and unit compatibility;
- schema validation and migration;
- checkpoint save/load/integrity;
- state continuation and replay hashing;
- numerical-health serialization and restoration;
- scenario expression and assertion behavior;
- ABI-v2 plugin in-process and process-isolated operation;
- plugin state serialization;
- MIL and SIL operation and state restoration;
- FMI package export/import and FMU-state restoration.

`professional_platform_v2_regression.py` verifies through the actual terminal executable:

- configuration, calibration, and scenario migration;
- YAML ramp and condition events;
- checkpoint and branch events;
- `always`, `eventually`, and `at_end` assertions;
- condition-based stop;
- checkpoint verify/inspect/load;
- branch create/compare/load;
- replay restoration and zero state mismatches;
- valid nominal numerical-health output with rolling histories;
- MIL/SIL switching and controller loading;
- process-isolated ABI-v2 plugin loading and unloading;
- FMI 3 export, inspect, import, and stepping in CS/ME/SE modes;
- ordinary Deflate-compressed FMU import.

### Sanitizer coverage

The modular professional core and full terminal executable were built with AddressSanitizer and UndefinedBehaviorSanitizer. Leak detection and halt-on-error were enabled for the professional unit and end-to-end tests. No issue was reported.

---

## Build instructions

### Fedora

```bash
sudo dnf install gcc-c++ cmake ninja-build zlib-devel python3
```

### Configure and build

```bash
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DAESIM_ENABLE_HARDENING=ON

cmake --build build -j"$(nproc)"
ctest --test-dir build --output-on-failure
```

### Sanitizer build

```bash
cmake -S . -B build-sanitize \
  -DCMAKE_BUILD_TYPE=Debug \
  -DAESIM_ENABLE_SANITIZERS=ON

cmake --build build-sanitize -j"$(nproc)"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1 \
ctest --test-dir build-sanitize --output-on-failure
```

### Run

```bash
./build/muzixdiagsys
```

The professional implementation and command examples are documented at the beginning of `README.md`.

---

## Known boundaries

These are explicit scope boundaries, not stubs:

1. Process-isolated plugin execution is implemented for POSIX systems. In-process ABI-v2 remains the portable fallback on non-POSIX platforms.
2. FMU export packages the binary for the current build platform. Additional platform binaries require cross-builds and inclusion under the corresponding FMI binary directory.
3. The FMI implementation supports the variables and lifecycle of the included MuzixDiagSys model and is not presented as external compliance-suite certification.
4. MIL/SIL scheduling is deterministic simulation-time scheduling. Hard real-time operating-system guarantees, physical I/O, PIL transport, and HIL benches are future layers rather than claims of this release.
5. Strong quantities cover the new professional subsystem interfaces and adapters. Rewriting every internal field of the retained legacy monolithic compatibility layer would break substantial source compatibility and was deliberately avoided.

## Conclusion

The simulator now has a complete professional lifecycle layer around its existing research physics: exact state capture and replay, typed physical interfaces, schema governance, numerical validity monitoring, declarative experiments, isolated extension execution, FMI 3 interoperability, and deterministic controller execution. The implementation preserves the entire prior feature surface and establishes a technically credible base for later PIL/HIL adapters, additional FMU platforms, remote orchestration, and safety-campaign automation.

## 2026-07-12 next-generation vehicle-depth integration

Professional execution, traceability, and artifact workflows now include checkpoint hashes, branch names, replay archives, fidelity transitions, and the vehicle-depth signal namespace.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


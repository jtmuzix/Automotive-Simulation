# Frontier Next Platform

**Revision:** 2026-08-08

The Frontier Next platform is an additive sixteen-domain engineering layer in `aesim_advanced`. It does not replace the existing `frontier-runtime`, `frontier-expansion`, `frontier-systems`, `frontier-integration`, motorsports, diagnostics, or primary `muzixdiagsys` command surfaces.

## 1. Runtime discovery and aggregate execution

```bash
./build/full/muzixdiagsys_advanced_platform frontier-next capabilities \
  build/frontier-next/capabilities.json

./build/full/muzixdiagsys_advanced_platform frontier-next self-test \
  build/frontier-next/self-test-work \
  build/frontier-next/self-test.json

./build/full/muzixdiagsys_advanced_platform frontier-next DOMAIN \
  REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

A complete self-test reports `domain_count: 16`, `passed: 16`, and `pass: true`.

## 2. Dedicated CLI aliases

Every Frontier Next domain also has a first-class alias. Each alias accepts:

```text
ALIAS capabilities [output.json]
ALIAS self-test DIRECTORY [output.json]
ALIAS run REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
ALIAS OPERATION REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

When `OPERATION` is used instead of `run`, the CLI injects that operation into the request before dispatch. The aliases are:

| Alias | Domain |
|---|---|
| `wireless-phy` | `automotive-wireless-phy-coexistence-laboratory` |
| `secure-ranging` | `secure-uwb-bluetooth-ranging-platform` |
| `complex-mu` | `dynamic-complex-mu-synthesis-laboratory` |
| `stochastic-id` | `stochastic-subspace-identification-platform` |
| `protocol-verify` | `distributed-formal-protocol-verification-platform` |
| `static-verify` | `automotive-software-static-verification-laboratory` |
| `native-solvers` | `native-petsc-sundials-hypre-solver-platform` |
| `gpu-comm` | `advanced-distributed-gpu-communication-runtime` |
| `adios2-stream` | `adios2-high-rate-scientific-streaming-platform` |
| `mesh-interchange` | `cgns-xdmf-exodus-mesh-interchange-platform` |
| `ibis-ami` | `automotive-ibis-ami-sparameter-platform` |
| `heat-pump` | `advanced-refrigerant-heat-pump-laboratory` |
| `nde-metrology` | `advanced-nde-metrology-platform` |
| `model-maturity` | `model-maturity-validity-registry` |
| `scenario-coverage` | `scenario-space-coverage-metrics-platform` |
| `model-form-uq` | `probabilistic-model-form-uncertainty-platform` |

## 3. Automotive wireless PHY and coexistence

`automotive-wireless-phy-coexistence-laboratory` implements an executable system-level OFDM/QAM coexistence model. Inputs include carrier frequency, bandwidth, transmit power and antenna gains, path-loss exponent, shadowing, noise figure, temperature, MCS, packet length, vehicle relative speed, Rician K factor, and co-channel/adjacent interferers with duty-cycle and spectral-overlap factors.

The model computes:

- free-space/reference and log-distance path loss;
- received signal power and thermal-noise power;
- correctly aggregated interferer power in the linear domain;
- Rician fading;
- SINR and uncoded QAM BER;
- coded packet-error probability from MCS decoding margin and packet length;
- PHY rate and expected goodput;
- Doppler shift and coherence time;
- optional deterministic raw complex I/Q samples.

The implementation explicitly regression-tests dBm conversion: a -90 dBm interferer active 50% of the time contributes approximately -93.0103 dBm average interference power.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform wireless-phy run \
  examples/frontier_next/wireless_phy.json \
  build/frontier-next/wireless.json
```

## 4. Secure UWB and Bluetooth ranging

`secure-uwb-bluetooth-ranging-platform` implements UWB single-sided and double-sided two-way ranging plus Bluetooth channel-sounding-style ranging. It includes clock ppm error, antenna delays, timestamp quantization, range noise, NLOS bias, multipath bias, relay delay, angle-of-arrival array geometry, and optional prior-range fusion.

The report includes measured range, range error, time-of-flight evidence, detected relay contribution, AoA estimate when configured, uncertainty, and acceptance against the requested maximum range error.

## 5. Dynamic complex structured robustness

`dynamic-complex-mu-synthesis-laboratory` extends the earlier structured-real robustness work to complex, frequency-dependent uncertainty analysis. It evaluates the continuous-time state-space transfer function over a logarithmic frequency grid, forms user-declared uncertainty block partitions, iteratively searches diagonal D-scalings for an upper bound, and performs deterministic complex-phase searches for a destabilizing/lower-bound witness.

The result reports frequency-by-frequency upper/lower structured robustness bounds, the worst frequency, peak upper bound, and robust margin. It is an engineering numerical analysis; the exact block structure and frequency resolution supplied in the request remain part of the evidence contract.

## 6. Stochastic subspace identification

`stochastic-subspace-identification-platform` provides:

- ARMAX iterative innovation identification;
- N4SID-style block-Hankel subspace realization;
- MOESP-style projection realization;
- CVA-style covariance-weighted realization.

The subspace modes construct past/future block Hankel matrices, estimate a reduced observability/state basis, and recover state-space dynamics. ARMAX iteratively estimates autoregressive, exogenous-input, and innovation coefficients. Reports include identified order, coefficient/state matrices, residual/prediction metrics, and evidence digest.

## 7. Distributed formal protocol verification

`distributed-formal-protocol-verification-platform` performs explicit reachable-state exploration from bounded integer state variables. Transitions carry guards and state updates. The verifier checks:

- invariant predicates over every reachable state;
- deadlock states;
- state-space bounds;
- goal states;
- liveness-to-goal by reverse reachability from all goal states.

This is directly useful for failover, charging, OTA, authentication/key rollover, race-control, and distributed ECU state machines. It is separate from the proof-assistant bridge: the protocol verifier explores executable transition systems, while the proof bridge emits theorem artifacts.

## 8. Automotive software static verification

`automotive-software-static-verification-laboratory` contains deterministic source checks for selected MISRA/AUTOSAR/security-oriented hazards, including unsafe C library operations, dynamic allocation policy, `reinterpret_cast`, `goto`, and dangerous shift expressions. It can optionally execute a real installed Clang or GCC compiler with strict syntax/warning options and GCC `-fanalyzer` when requested.

External compiler invocation is direct on POSIX systems and does not use shell interpolation. The report separates internal findings from compiler acceptance.

## 9. Native PETSc, SUNDIALS, and HYPRE solvers

`native-petsc-sundials-hypre-solver-platform` always provides deterministic reference solvers and conditionally exposes actual native libraries when detected at configure time:

- reference conjugate gradient and RK4;
- PETSc sequential AIJ + KSP/CG;
- HYPRE IJ/ParCSR + PCG on `MPI_COMM_SELF`;
- SUNDIALS CVODE/BDF with a dense SUNMatrix/SUNLinearSolver for linear ODE systems.

Native requests are rejected when the corresponding library was not found. Native linear solutions are independently residual-checked by MuzixDiagSys after extraction.

```bash
./build/full/muzixdiagsys_advanced_platform native-solvers capabilities
./build/full/muzixdiagsys_advanced_platform native-solvers linear-solve \
  examples/frontier_next/native_solvers.json \
  build/frontier-next/native-solver.json
```

## 10. Advanced distributed GPU communication

`advanced-distributed-gpu-communication-runtime` provides:

- deterministic ring reduce-scatter/all-gather cost estimation;
- real `MPI_Allreduce` when MPI is initialized;
- real CUDA host/device round-trip qualification when a CUDA device exists;
- real NCCL GPU all-reduce when CUDA + MPI + NCCL are compiled and available;
- library visibility reporting for NCCL, NVSHMEM, and UCX.

The NCCL operation compares the GPU reduction against an independent MPI reduction before passing.

## 11. ADIOS2 high-rate scientific streaming

`adios2-high-rate-scientific-streaming-platform` always provides a bounded in-memory ring stream with step generation, drop accounting, throughput and checksums. When ADIOS2 is available, `backend=adios2` performs actual BP-style step writes. `operation=roundtrip` reopens the stream, reads every step, verifies shape/step count and independently recomputes the checksum.

## 12. CGNS/XDMF/Exodus mesh interchange

`cgns-xdmf-exodus-mesh-interchange-platform` supports line, triangle, quadrilateral, tetrahedral, and hexahedral cell topology through explicit `cell_types` or unambiguous inference. It provides:

- XDMF 3 mixed-topology geometry and nodal fields;
- native CGNS unstructured zones, coordinates, element connectivity, vertex solution fields and readback qualification;
- native Exodus II coordinates, element blocks/connectivity, nodal variables and readback qualification.

Native CGNS/Exodus requests fail clearly when those libraries are not compiled.

## 13. IBIS/AMI/S-parameter signal integrity

`automotive-ibis-ami-sparameter-platform` parses Touchstone S2P RI/MA/DB data, cascades aligned 2-port networks through ABCD matrices, and evaluates insertion loss, return loss and phase. It additionally parses a practical IBIS electrical subset:

- `[Voltage Range]`;
- `[Pullup]` and `[Pulldown]` tables, with median local dV/dI output-resistance extraction;
- `[Ramp]` `dV/dt_r` and `dV/dt_f` slew declarations.

The AMI parser recognizes `GetWave_Exists`, `Init_Returns_Impulse`, and numeric `FFE_Gain_dB`, `CTLE_Gain_dB`, and `DFE_Recovery_Fraction` declarations. Parsed driver impedance/swing/ramp and AMI equalization modify the resulting engineering eye-height, eye-width, and BER estimate.

## 14. Advanced refrigerant and heat-pump laboratory

`advanced-refrigerant-heat-pump-laboratory` supports R1234yf and R744/CO2 cycle calculations, including low/high-side pressure estimates, transcritical R744 operation, compressor isentropic efficiency, discharge temperature, charge fraction, mass flow, cooling/heating capacity, COP, superheat, and ambient/humidity frost risk.

The model is intended for comparative system engineering; detailed property-package validation should accompany high-consequence design decisions.

## 15. Advanced NDE and metrology

`advanced-nde-metrology-platform` executes four modalities:

- ultrasonic pulse/echo attenuation, reflection, time-of-flight and POD;
- eddy-current skin depth, defect response and POD;
- pulsed thermography diffusion/contrast and POD;
- digital image correlation affine displacement fit and planar strain/principal strain extraction.

## 16. Model maturity and validity registry

`model-maturity-validity-registry` persists model records containing calibration/validation evidence counts, numerical and parameter uncertainty, validation ranges, maturity score/level, and a content hash. Operations are `register`, `upsert`, `query`, and `assess`. Assessment reports validation/extrapolation status, extrapolation fraction, confidence and pass/fail against an explicit confidence requirement.

## 17. Scenario-space coverage metrics

`scenario-space-coverage-metrics-platform` partitions declared ODD dimensions into bins and evaluates occupied grid cells, one-way/two-way/three-way interaction coverage, boundary fraction, and optional behavior-space novelty from supplied embeddings. Coverage thresholds can be used as qualification gates or as feedback into the existing scenario-generation/falsification machinery.

## 18. Probabilistic model-form uncertainty

`probabilistic-model-form-uncertainty-platform` learns discrepancy between observed physical data and simulation predictions using a squared-exponential Gaussian-process model. It returns discrepancy mean, epistemic uncertainty, combined uncertainty including measurement/parameter/numerical terms, corrected predictions, and 95% intervals at requested query points.

This separates model-form discrepancy from ordinary solver tolerance: increasing floating-point precision does not remove a systematic discrepancy between a physical system and its model family.

## 19. Native capability policy

Run:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-next capabilities
```

The capability report is authoritative for PETSc, SUNDIALS, HYPRE, ADIOS2, CGNS, Exodus, MPI, CUDA, and NCCL. Missing optional native libraries are never reported as successfully executed. Reference/internal implementations remain available where the domain has a meaningful self-contained algorithm.

## 20. Canonical examples and regression

All sixteen executable requests are under `examples/frontier_next/`.

Focused regression:

```bash
cmake --build build/full --target \
  frontier_next_platform_tests \
  muzixdiagsys_advanced_platform --parallel "$(nproc)"

ctest --test-dir build/full --output-on-failure \
  -R '^frontier_next_(platform_unit_tests|source_regression|cli_regression)$'
```

The source regression also verifies domain/alias registration and rejects unfinished implementation markers from the Frontier Next production/API surface.

# Frontier Runtime, Numerical Integration, Positioning, and Sensing Platform

**Release:** 2026-08-07  
**CLI family:** `muzixdiagsys_advanced_platform frontier-runtime ...`  
**Public API:** `aesim/advanced/frontier_runtime_sensing_platform.hpp`

This additive platform provides resilient distributed execution, error-bounded checkpoint compression, out-of-core numerical storage, hardware-aware placement, machine-checkable floating-point error certificates, geometric and stiff integrators, carrier-phase GNSS factor-graph estimation, photon-counting and coherent LiDAR, and radar micro-Doppler/polarimetry. Existing simulator commands, libraries, project formats, SARR services, beginner menus, and the permanent command line remain unchanged.

## 1. Build and discover capabilities

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/full --target muzixdiagsys_advanced_platform frontier_runtime_sensing_platform_tests -j
./build/full/muzixdiagsys_advanced_platform frontier-runtime capabilities
```

The domains are:

```text
ulfm
checkpoint-compression
out-of-core
hardware-scheduler
floating-proof
lie-group
stiff-integrators
gnss-factor-graph
spad-lidar
coherent-lidar
radar-signature
```

General invocation:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-runtime DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

## 2. ULFM resilient distributed execution

`UlfmResilientRuntime` implements deterministic failed-rank membership, communicator generations, checkpoint integrity, survivor agreement semantics, mirrored rank state, and deterministic partition reassignment. A recovery advances the generation, removes failed ranks, assigns every partition to a survivor, selects a mirror survivor, verifies the SHA-256 of every recoverable failed-rank checkpoint, and emits an evidence SHA-256.

When the selected MPI implementation exports the User Level Failure Mitigation symbols `MPIX_Comm_revoke`, `MPIX_Comm_shrink`, and `MPIX_Comm_agree`, CMake defines `AESIM_HAVE_NATIVE_ULFM` and the recovery path can perform native communicator revocation, shrink, and agreement. If MPI/ULFM is not installed, the deterministic recovery engine remains fully operational for simulation, testing, scheduling, and failure studies. The capability document reports `native_ulfm_available`; the simulator does not claim native MPI repair when the symbols are absent.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform \
  frontier-runtime ulfm \
  examples/frontier_runtime/ulfm.json \
  build/results/ulfm.json
```

Important fields:

- `world_size`: original number of ranks.
- `partitions`: work partitions requiring ownership after recovery.
- `checkpoints[]`: `rank`, optional `mirror_rank`, and deterministic payload.
- `failed_ranks[]`: ranks to remove before recovery.

The result includes failed/surviving/recovered ranks, the new generation, partition owners/mirrors, native ULFM capability/attempt state, and evidence hash.

## 3. Error-bounded ZFP/SZ3 checkpoint compression

`ErrorBoundedCheckpointCompressor` implements two deterministic error-bounded checkpoint profiles:

- `zfp-fixed-accuracy`: fixed-accuracy scalar quantization with signed variable-length coding.
- `sz3-predictive`: the same strict error contract with predictive delta coding between quantized samples.

For a requested absolute error bound `E`, the quantization step is at most `2E`, so nearest-integer reconstruction has an ideal quantization error no larger than `E`; verification includes floating-point slack. If a positive relative bound is also requested, the compressor chooses a global step constrained by the smallest nonzero magnitude so both contracts can be checked.

The persisted `.mzcp` format contains codec identity, element count, absolute/relative bounds, quantization step, payload length, and payload. Payload SHA-256 is verified before decompression. Truncated files, invalid codec IDs, malformed variable-length integers, integer overflow, and trailing data are rejected.

The built-in codecs are complete MuzixDiagSys checkpoint formats. They are intentionally **not described as third-party ZFP or SZ3 bitstreams**. Native external-library adapters may be added when those libraries are available without changing the public checkpoint contract.

Examples:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime checkpoint-compression \
  examples/frontier_runtime/checkpoint_zfp.json build/results/zfp.json build/results/zfp-work

./build/full/muzixdiagsys_advanced_platform frontier-runtime checkpoint-compression \
  examples/frontier_runtime/checkpoint_sz3.json build/results/sz3.json build/results/sz3-work
```

The result reports compression ratio, payload size/hash, maximum observed absolute/relative error, and PASS/FAIL against the requested contract.

## 4. Out-of-core simulation arrays

`OutOfCoreArray` exposes a persistent binary64 array whose chunks are demand-paged from a backing file. The cache is bounded by `max_resident_chunks` and uses LRU eviction. Dirty chunks are written before eviction and on `flush()`/destruction. Reopening validates the exact expected file size.

Runtime statistics include:

- cache hits and misses;
- evictions;
- dirty flushes;
- current resident chunk count;
- chunk size and element count;
- optional SHA-256 of the fully flushed backing file.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime out-of-core \
  examples/frontier_runtime/out_of_core.json build/results/ooc.json build/results/ooc-work
```

Use this layer for state vectors, field tiles, ensemble buffers, long histories, and intermediate arrays that must exceed a configured in-memory working set without changing numerical values.

## 5. Hardware-aware runtime scheduler

`HardwareAwareScheduler::discover()` inventories logical CPUs, physical CPU packages, Linux NUMA nodes, node CPU lists, node memory capacity, DRM GPU devices, PCI addresses, and GPU NUMA locality where the OS exposes them. Other operating systems retain a portable single-node fallback.

`place()` selects a NUMA node that satisfies requested CPU threads, memory, optional GPU requirement, and optional preferred node. `apply_cpu_affinity()` uses Linux `sched_setaffinity` and returns an explicit error on unsupported systems or invalid CPU IDs.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime hardware-scheduler \
  examples/frontier_runtime/hardware_scheduler.json build/results/hardware.json
```

A missing GPU is a real infeasible placement when `require_gpu=true`; it is never silently substituted with a CPU.

## 6. Formal floating-point verification certificates

`FloatingPointVerifier` emits machine-checkable binary64 error certificates for:

- sequential summation;
- sequential dot products;
- Horner polynomial evaluation.

The certificates use the standard unit roundoff `u = epsilon/2` and a Higham-style `gamma_n = nu/(1-nu)` forward-error envelope. Reference values are accumulated in extended precision. Every certificate includes operation type/count, binary64 result, extended reference, observed error, certified bound, assumptions, PASS/FAIL, and SHA-256 over the certificate evidence.

This is a formal arithmetic error-bound certificate under its stated IEEE-754 assumptions. It does not prove the correctness of a physical model or algorithmic specification.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime floating-proof \
  examples/frontier_runtime/floating_proof.json build/results/floating-proof.json
```

Supported operations are `sum`, `dot`, and `horner`.

## 7. Lie-group and variational integrators

### 7.1 SO(3) rigid-body integration

`LieGroupIntegrator` evolves orientation using a quaternion exponential-map increment derived from the midpoint angular velocity. Body angular acceleration uses Euler rigid-body equations with principal inertias and applied torque. Every orientation update is normalized and validated.

The method avoids integrating quaternion components as unrelated Euclidean states and is intended for rigid-body attitude, wheel/sensor frames, multibody orientation blocks, and long-running rotational simulations.

### 7.2 Störmer-Verlet variational integration

`VariationalIntegrator::stormer_verlet()` performs momentum half-step, position drift, and final momentum half-step for separable Hamiltonian systems. It is time-reversible and symplectic for the documented problem class.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime lie-group \
  examples/frontier_runtime/lie_group.json build/results/lie-group.json
```

The command reports maximum quaternion norm deviation and maximum oscillator energy deviation during the requested integration.

## 8. Radau IIA, Rosenbrock-W, and IMEX integration

`StiffIntegrator` provides three general vector ODE families using `aesim::core::numerics` for stable Jacobians and linear solves:

### Radau IIA

The implementation is the two-stage, third-order Radau IIA collocation formula. Both stages are solved simultaneously with Newton iterations. The block Newton matrix contains finite-difference Jacobians evaluated at each collocation state. Failed linear solves or nonlinear convergence return a non-converged result rather than silently accepting a step.

### Rosenbrock-W

The Rosenbrock-W1 path forms a numerical Jacobian and solves the linearly implicit system `(I - hJ) k = f`, then advances `y += hk`. This is a robust first-order L-stable linearly implicit step for stiff decay and as a baseline member of the Rosenbrock family.

### IMEX

The IMEX path uses an explicit Heun predictor/corrector contribution combined with an implicit trapezoidal contribution. The implicit state is solved with Newton iterations and a numerical Jacobian of only the implicit partition.

Examples:

```bash
for method in radau rosenbrock-w imex; do
  ./build/full/muzixdiagsys_advanced_platform frontier-runtime stiff-integrators \
    examples/frontier_runtime/stiff_${method//-/_}.json \
    build/results/stiff-${method}.json
done
```

Result evidence includes method, final time/state, step count, nonlinear iterations, final residual, convergence, and a reference result for the built-in linear-decay CLI problem.

## 9. Full GNSS carrier-phase and factor-graph stack

`GnssCarrierPhaseFactorGraph` supports:

- Standalone, PPP, RTK, and PPP-RTK modes;
- pseudorange, carrier phase, and Doppler observations;
- dual-frequency ionosphere-free code and carrier combinations;
- satellite clock bias/drift corrections;
- ionosphere, troposphere mapping, code bias, phase bias, phase windup, and relativistic corrections;
- base-station differencing for RTK-family modes;
- floating carrier ambiguities and deterministic integer candidate/ratio testing;
- explicit cycle-slip ambiguity segmentation;
- sliding-window operation;
- nine navigation states per epoch: ECEF position (3), receiver clock bias, ECEF velocity (3), clock drift, and zenith-wet troposphere state;
- constant-velocity, clock, and troposphere process factors;
- IMU delta-position/delta-velocity preintegration factors;
- wheel-speed factors;
- map-position constraints;
- QR-based weighted least squares using the hardened numerical core;
- code, carrier, and Doppler RMS qualification metrics;
- SHA-256 evidence identity.

### Sign conventions

The carrier measurement supplied to the API is phase in cycles and a positive wavelength. Doppler is converted to observed range rate as `-doppler_hz * wavelength_m`. Satellite clock fields are expressed as range-equivalent meters or meters/second. Position/velocity are ECEF meters and meters/second.

### Dual-frequency combination

For frequencies `f1` and `f2`, code and carrier meters use:

```text
X_IF = (f1^2 X1 - f2^2 X2) / (f1^2 - f2^2)
```

The explicit ionosphere term is then zero in the combined measurement model.

### RTK-family base fields

Set `has_base=true` and provide `base_position_m`, `base_pseudorange_m`, and `base_carrier_phase_cycles`. The runtime removes the base measurement-minus-geometric-range common component before the rover factor is formed.

### Integer ambiguity ratio

Floating ambiguity meters are mapped to cycles using the measurement wavelength. The nearest integer candidate is the best candidate and the nearest alternative is used to construct a deterministic second/best squared-distance ratio. Integer results are reported only when the configured threshold is satisfied.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime gnss-factor-graph \
  examples/frontier_runtime/gnss_factor_graph.json build/results/gnss.json
```

The canonical example includes multi-epoch receiver motion, dual-frequency PPP, satellite clock/drift, IMU preintegration, wheel speed, and map factors.

## 10. SPAD photon-counting LiDAR

`SpadLidarSimulator` models:

- Poisson signal photons;
- photon-detection efficiency;
- background and dark-count Poisson processes;
- Gaussian timing jitter;
- detector dead time and suppressed-event accounting;
- finite histogram bins and observation window;
- two-way time-of-flight range estimation;
- deterministic random seeding.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime spad-lidar \
  examples/frontier_runtime/spad_lidar.json build/results/spad.json
```

The returned histogram is the accepted-detector histogram after dead-time suppression, not an ideal photon-arrival histogram.

## 11. Coherent FMCW LiDAR

`CoherentLidarSimulator` synthesizes noisy complex up/down chirp beat signals. The ideal beat pair is:

```text
f_up   = S tau + f_d
f_down = S tau - f_d
```

where `S` is chirp slope, `tau=2R/c`, and `f_d=2v/lambda`. The estimator derives beat frequency from complex adjacent-sample phase correlation and unwraps it around the known physical band. Range and velocity are recovered jointly:

```text
R = c (f_up + f_down) / (4 S)
v = lambda (f_up - f_down) / 4
```

Noise is complex Gaussian with amplitude determined by `snr_db` and deterministic `seed`.

## 12. Radar micro-Doppler and polarimetry

`RadarSignatureSimulator` builds coherent slow-time returns from multiple scatterers. Each scatterer may contain bulk radial velocity plus sinusoidal micro-velocity, which is analytically integrated into displacement before phase modulation. A deterministic DFT produces Doppler power, and the strongest bins are returned with radial-velocity conversion.

Polarimetry accepts complex HH/HV/VH/VV values represented as `[real, imag]`. The result contains cross-pol/co-pol ratios and three Pauli-basis powers. A SHA-256 identifies the result evidence.

Example:

```bash
./build/full/muzixdiagsys_advanced_platform frontier-runtime radar-signature \
  examples/frontier_runtime/radar_signature.json build/results/radar.json
```

## 13. Complete qualification

Focused qualification:

```bash
./build/full/frontier_runtime_sensing_platform_tests
python3 tests/frontier_runtime_sensing_cli_regression.py \
  ./build/full/muzixdiagsys_advanced_platform .
```

Full project qualification:

```bash
cmake --build build/full --target aesim_test_artifacts -j
ctest --test-dir build/full --output-on-failure
```

The dedicated C++ regression includes simultaneous rank failures, checkpoint corruption boundaries, both compression profiles, forced out-of-core LRU eviction/reopen, topology placement, floating-point certificate verification, long SO(3) integration, variational energy behavior, all three stiff solvers, dual-frequency PPP, RTK, PPP-RTK, IMU/wheel/map fusion, SPAD ranging, coherent range/velocity, and radar polarimetry/micro-Doppler.

## 14. Compatibility and engineering boundaries

- Existing public APIs and CLI families remain available.
- `frontier-runtime` is additive to `muzixdiagsys_advanced_platform`.
- Native ULFM is used only when the MPI implementation actually exposes the MPIX functions; otherwise capability state is explicit.
- The built-in ZFP/SZ3 profiles are complete deterministic MuzixDiagSys codecs with strict error contracts, not counterfeit external bitstreams.
- Hardware discovery depends on information exposed by the host OS; missing GPU/NUMA data remains explicit.
- Floating-point certificates prove only the documented arithmetic error envelope under their assumptions.
- GNSS, LiDAR, and radar outputs are simulation/engineering evidence and require external measurement correlation before physical qualification claims.

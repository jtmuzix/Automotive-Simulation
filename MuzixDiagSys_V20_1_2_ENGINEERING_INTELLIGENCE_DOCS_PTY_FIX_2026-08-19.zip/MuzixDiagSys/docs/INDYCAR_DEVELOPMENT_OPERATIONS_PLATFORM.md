# IndyCar Development and Operations Platform

**Revision:** 2026-07-23  
**Library:** `aesim_indycar`  
**Public header:** `include/aesim/advanced/indycar_development_operations_platform.hpp`  
**CLI family:** `muzixdiagsys_advanced_platform indycar-development`

## 1. Scope and architecture

The IndyCar Development and Operations Platform is the fifth additive IndyCar module in MuzixDiagSys. It extends the existing IR-18, operations, future-competition, and frontier-expansion systems with ten production-grade laboratories covering the development ladder, supplier quality, power-unit governance, renewable fuel and lubricant quality, electrical/cyber-physical engineering, race-engineering intelligence, driver/simulator qualification, factory logistics, circuit homologation, and medical operations.

The module is owned exclusively by `aesim_indycar`. It is exported through `aesim/advanced/platform.hpp` and is transitively available to clients that link `aesim_advanced`. Its production sources are not compiled into `aesim_formula_one` or `aesim_nascar`.

Every domain:

- accepts a structured JSON request through `aesim::doc::Value`;
- validates identifiers, finite values, ranges, uniqueness, dependencies, chronology, inventories, and dimensional constraints;
- emits a deterministic structured report;
- records qualification findings with severity, code, message, and evidence context;
- computes a canonical SHA-256 `evidence_digest`;
- optionally writes its report atomically beneath a caller-selected working directory;
- reports `passed` only when all mandatory engineering and operational gates are satisfied.

The platform supports virtual engineering, supplier and entrant planning, training, evidence organization, and reproducible research. It does not issue official INDYCAR approvals, replace accredited metrology or medical judgment, certify a circuit, approve a power-unit specification, or authorize a driver to compete.

## 2. Public API and runtime domains

| Runtime domain | Public class | Entry point |
|---|---|---|
| `development-ladder` | `IndyCarDevelopmentLadderPlatform` | `evaluate()` |
| `firestone-production` | `IndyCarFirestoneProductionMetrologyPlatform` | `evaluate()` |
| `power-unit-supply` | `IndyCarPowerUnitSupplyHomologationPlatform` | `evaluate()` |
| `renewable-fuel-quality` | `IndyCarRenewableFuelLubricantLaboratory` | `evaluate()` |
| `electrical-cyberphysical` | `IndyCarElectricalCyberPhysicalTwin` | `evaluate()` |
| `race-engineering-intelligence` | `IndyCarRaceEngineeringIntelligence` | `optimize()` |
| `driver-simulator-qualification` | `IndyCarDriverSimulatorQualificationLaboratory` | `evaluate()` |
| `team-factory-logistics` | `IndyCarTeamFactoryLogisticsTwin` | `evaluate()` |
| `circuit-homologation` | `IndyCarCircuitHomologationSafetyPlatform` | `evaluate()` |
| `medical-operations` | `IndyCarMedicalOperationsBiomechanicsPlatform` | `evaluate()` |

The aggregate class `IndyCarDevelopmentOperationsPlatform` provides:

```cpp
[[nodiscard]] aesim::doc::Value capabilities() const;
[[nodiscard]] aesim::doc::Value execute(
    const std::string& domain,
    const aesim::doc::Value& request,
    const std::string& working_directory = {}) const;
[[nodiscard]] aesim::doc::Value self_test(
    const std::string& working_directory = {}) const;
```

## 3. Build and validation

```bash
cmake -S . -B build/indycar-development -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/indycar-development --parallel --target \
  aesim_indycar \
  muzixdiagsys_advanced_platform \
  indycar_development_operations_platform_tests
ctest --test-dir build/indycar-development --output-on-failure \
  -R '^indycar_.*_unit_tests$'
python3 tests/indycar_development_operations_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```

Sanitizer configuration:

```bash
cmake -S . -B build/indycar-development-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF
cmake --build build/indycar-development-sanitize --parallel --target \
  indycar_development_operations_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --test-dir build/indycar-development-sanitize --output-on-failure \
  -R '^indycar_development_operations_platform_unit_tests$'
```

## 4. Command-line operation

List domains:

```bash
./build/indycar-development/muzixdiagsys_advanced_platform \
  indycar-development capabilities \
  build/indycar-development/capabilities.json
```

Run the deterministic ten-domain self-test:

```bash
./build/indycar-development/muzixdiagsys_advanced_platform \
  indycar-development self-test \
  build/indycar-development/evidence \
  build/indycar-development/self-test.json
```

Run one domain:

```bash
./build/indycar-development/muzixdiagsys_advanced_platform \
  indycar-development development-ladder \
  examples/indycar_development_operations/development_ladder.json \
  build/indycar-development/development-ladder.json \
  build/indycar-development/evidence
```

The same command pattern applies to each domain. The fourth argument is the JSON output path; the optional fifth argument is a working directory for atomic evidence output.

## 5. INDY NXT and driver-development ladder

`IndyCarDevelopmentLadderPlatform` evaluates candidates and available IndyCar seats using road, street, and oval skill, consistency, tire management, technical feedback, fitness, INDY NXT results, starts by circuit type, sponsorship, requested salary, and seat preference.

### Request contract

Required top-level fields:

- `minimum_readiness`: qualification threshold in `[0,1]`;
- `minimum_oval_starts`: non-negative integer;
- `minimum_nxt_starts`: non-negative integer;
- `seats`: unique seat and team definitions with available budget;
- `drivers`: unique driver records with age, skill components, experience, championship points, sponsorship, salary, and optional preferred seat.

### Computation

The model calculates a bounded readiness score from skill, consistency, tire management, engineering feedback, fitness, INDY NXT performance, and event-type experience. It separately evaluates Rookie Orientation readiness and commercial feasibility. Candidate-seat combinations are scored, sorted deterministically, and assigned without duplicating a driver or seat. The report distinguishes:

- technically ready candidates;
- commercially feasible candidates;
- ROP-ready candidates;
- assigned and unassigned seats;
- reasons a candidate failed a gate.

The optimizer never creates budget or experience that is absent from the request.

## 6. Firestone production, allocation, and metrology

`IndyCarFirestoneProductionMetrologyPlatform` models tire-batch genealogy and release quality before assigning accepted inventory to entrants.

### Production and metrology inputs

Each batch contains a specification, produced quantity, target mass, cure temperature, cure pressure, sustainable-material fraction, and serialized tire measurements. Tire records may include measured mass, radial-force variation, lateral-force variation, runout, balance, X-ray status, shearography status, and dimensional results.

### Release logic

The platform evaluates:

- cure-window conformance;
- target-mass tolerance;
- force-variation limits;
- runout and balance;
- X-ray and shearography acceptance;
- sustainability threshold;
- specification consistency;
- serialized count versus declared production.

Rejected tires remain traceable but are excluded from allocatable inventory. Allocations are processed in deterministic order, preserve specification identity, and fail when accepted inventory is insufficient. The report provides batch yield, rejected serials, accepted inventory, allocations, shortfalls, and material-traceability findings.

## 7. Power-unit supply, homologation, and customer parity

`IndyCarPowerUnitSupplyHomologationPlatform` verifies manufacturer declarations, entrant deliveries, serialized pools, seals, life limits, and works/customer parity.

### Governance model

Manufacturer records define homologated hardware and software baselines, season capacity, and emergency spares. Entrant supply records bind each entrant to an OEM, hardware ID, software ID, calibration release, works/customer status, and allocated unit count. The component pool records serial number, component type, entrant, seal, mileage, and life limit.

The platform detects:

- non-homologated hardware or software;
- customer/works calibration-release mismatches;
- duplicate component serials or seals;
- broken seals;
- life-limit exceedance;
- allocation exceeding production capacity plus authorized emergency supply;
- entrants referencing unknown manufacturers;
- inconsistent component ownership;
- performance-oriented changes submitted through reliability or safety pathways.

The result includes manufacturer utilization, parity status, pool condition, affected entrants, and an evidence-bound homologation decision record.

## 8. Renewable fuel, lubricant, and quality laboratory

`IndyCarRenewableFuelLubricantLaboratory` evaluates fuel chemistry and lubricant condition with batch-level chain of custody.

Fuel inputs include mass, temperature, density, kinematic viscosity, octane, lower heating value, stoichiometric air-fuel ratio, latent heat, renewable fraction, water contamination, and deposit index. The platform performs temperature-corrected density and energy calculations, evaluates knock margin and volatility-sensitive behavior, and checks renewable-content and contamination gates.

Lubricant samples include viscosity at 40 °C and 100 °C, fuel dilution, wear metals, and oxidation. The laboratory estimates viscosity index, degradation severity, contamination risk, and suitability for continued service. Fuel and lubricant reports remain separate so an accepted fuel batch cannot mask an unacceptable lubricant sample.

## 9. Electrical/electronic and cyber-physical twin

`IndyCarElectricalCyberPhysicalTwin` models approved firmware and calibrations, harness voltage drop, network loading, timing, authentication, sensor plausibility, and attack response.

### Node model

Each node supplies current demand, harness and ground resistance, firmware identity, approved firmware identity, calibration signature, approved signature, secure-boot state, authentication state, and sensor bias. The twin computes voltage drop and reports unsigned, unauthenticated, or implausible nodes.

### Network model

Each bus supplies bitrate, frame rate, average frame size, packet-loss fraction, and authentication state. The model calculates utilization, latency risk, message-loss risk, and available margin. It rejects impossible bus capacities and non-finite timing data.

### Adversarial model

Attack scenarios identify attack type, target, detection probability, containment probability, and replay-window state. The twin evaluates spoofing, replay, flooding, unauthorized firmware, and calibration tampering. A valid report requires approved identities, secure boot, acceptable bus utilization, bounded sensor bias, and sufficient detection/containment behavior.

## 10. Race-engineering intelligence and causal setup optimization

`IndyCarRaceEngineeringIntelligence` estimates setup effects from observed laps and ranks constrained candidate setups.

Inputs include named setup parameters, observations, a baseline setup, and candidate configurations. Each observation records driver, lap time, fuel, track temperature, traffic loss, tire age, and setup values. The optimizer normalizes major covariates before estimating the effect of each setup parameter. It then reports:

- effect direction and magnitude;
- sample support;
- uncertainty;
- corrected baseline performance;
- predicted candidate lap time;
- constraint compliance;
- ranked recommendation.

The method is deliberately causal-aware rather than a raw lap-time correlation. Results remain dependent on experiment design and data coverage; insufficient variation or confounding produces explicit uncertainty findings instead of false precision.

## 11. Driver-in-the-loop and simulator qualification

`IndyCarDriverSimulatorQualificationLaboratory` combines driver physiology and control workload with simulator fidelity.

Driving segments include duration, lateral and longitudinal acceleration, steering torque and rate, brake force, cockpit temperature, cooling power, radio rate, control-action rate, and visual occlusion. The physiological model integrates core temperature, sweat and hydration demand, neck and steering load, braking workload, visual workload, cognitive demand, and reaction-time degradation.

Simulator inputs include input, display, and motion latency; steering-torque error; pedal-force error; and vehicle-response correlation. Qualification requires bounded latency, acceptable control-force correlation, adequate vehicle-response correlation, safe driver thermal state, and adequate hydration reserve. The report exposes both driver and simulator failures so hardware fidelity cannot conceal an unsafe human-performance state.

## 12. Team factory, parts lifecycle, and event logistics

`IndyCarTeamFactoryLogisticsTwin` schedules dependency-constrained work against inventory, resources, shipments, cost, and event-readiness deadlines.

The scheduler:

- rejects duplicate IDs and cyclic task graphs;
- schedules only after all dependencies complete;
- respects resource capacity;
- verifies required parts before starting a task;
- consumes inventory only after all start conditions pass;
- leaves inventory unchanged for failed tasks;
- computes shipment arrival, probability, and freight cost;
- reports the critical completion time and deadline margin.

This conservation behavior is intentional: a failed task cannot consume unavailable parts or unblock dependent work.

## 13. Circuit homologation, barriers, and venue safety

`IndyCarCircuitHomologationSafetyPlatform` evaluates road, street, short-oval, and speedway configurations.

Each segment defines length, radius, width, friction, banking, maximum design speed, runoff, barrier angle and type, debris-fence height, sight distance, drainage capacity, and design rainfall. The platform computes kinetic energy, minimum sight distance, runoff demand, barrier-angle risk, drainage margin, and fence requirements. Ovals additionally require appropriate energy-absorbing barrier treatment.

Pit-lane width and entry/exit geometry, marshal-post spacing, medical response time, medical-center readiness, and helicopter or equivalent transport are assessed independently. A certificate is withheld whenever a mandatory finding remains unresolved.

## 14. Medical operations and injury biomechanics

`IndyCarMedicalOperationsBiomechanicsPlatform` consumes a crash pulse and operational resources to support incident planning.

The model integrates acceleration to estimate velocity change, computes peak acceleration and an HIC-like proxy, evaluates neck, chest, and lower-extremity loading, and combines these with fire, smoke, high-voltage, isolation, and egress conditions. It then evaluates available medical resources by dispatch delay, travel time, capacity, and availability, and selects an appropriate hospital using trauma capability, burn capability, and transport time.

Outputs are engineering estimates for training and resource planning. They do not diagnose injury, authorize treatment, or replace physicians, emergency personnel, accredited crash investigation, or official medical protocols.

## 15. Evidence and reproducibility

Every result contains:

- `domain` and schema/version identity;
- normalized metrics and decisions;
- structured `findings`;
- `passed`;
- canonical `evidence_digest` generated with SHA-256.

When a working directory is provided, the report is written atomically so interrupted execution cannot expose a partially written evidence document. Repeated execution of the same deterministic request produces the same canonical evidence digest.

## 16. Qualification boundaries

The platform is a virtual engineering and operations system. It does not:

- grant a driver licence or Rookie Orientation approval;
- approve an INDY NXT or IndyCar seat;
- release a Firestone tire batch;
- approve an OEM specification or supplier contract;
- certify fuel, lubricant, firmware, telemetry, a simulator, a factory process, a circuit, or medical readiness;
- replace official INDYCAR rules, bulletins, homologation files, supplier procedures, track certificates, or medical protocols.

Use current official requirements, calibrated instrumentation, controlled test facilities, qualified personnel, and human authorization for real-world decisions.

## Motorsport CLI convenience aliases

The original `indycar-development` family remains authoritative. `indycar run development DOMAIN ...` provides aggregate routing; `indycar-setup` and `indycar-driver` are direct shortcuts. See `MOTORSPORT_CLI_COMMANDS.md`.

# NASCAR Frontier Operations Guide

> **2026-07-28 additive assurance module:** The separate `nascar-assurance` command and `NascarEngineeringAssurancePlatform` add regulation digital-thread resolution, dynamic compliance, prospective-OEM management, timing observation fusion, officiating policy analysis, progressive contact damage, crash/SAFER elements, fire/rescue hazards, debris recovery, composite manufacturing, fleet reliability, and optimal test design. Existing contracts in this guide are unchanged. See `docs/NASCAR_ENGINEERING_ASSURANCE_PLATFORM.md` and Chapter 59 of the user manual.
**Revision:** 2026-07-22  
**Library:** `aesim_nascar` (publicly linked by `aesim_advanced`)

This guide documents the third ten-domain NASCAR expansion and the post-refactor correctness semantics. The combined `nascar` command now exposes 40 independently executable domains; this guide remains authoritative for the third ten-domain frontier layer.

## Additive NASCAR integrated-fidelity module

The 2026-07-27 source tree also provides the separate `nascar-integrated` command and `NascarIntegratedFidelityPlatform`. Its twelve domains add deterministic multi-rate co-simulation, telemetry assimilation/calibration, unified uncertainty and model-validity supervision, a 28-DOF flexible vehicle, detailed asymmetric tire construction/contact, unsteady aeroelastic wakes and flaps, closed-loop ECU/driveline control, cranktrain/dry-sump/fuel/thermal systems, a multi-car pit-road twin, occupant heat/egress, scanned pavement mechanics, and spray/optical visibility. These domains are additive and do not change this guide's existing `nascar` command contracts. See `docs/NASCAR_INTEGRATED_FIDELITY_PLATFORM.md` and Chapter 58 of the user manual.

## Command form

```bash
muzixdiagsys_advanced_platform nascar DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`REQUEST.json` is parsed before execution. `OUTPUT.json` receives the canonical result. When `WORKING_DIRECTORY` is supplied, the domain also writes its named evidence report there. Every report contains a SHA-256 `evidence_digest` calculated from canonical JSON with the digest field cleared.

## Domains

### `in-season-challenge`
Builds a power-of-two seeded bracket, pairs high and low seeds, resolves each matchup from penalty-adjusted finishing positions and disqualifications, applies the seed tiebreaker, and estimates championship probabilities with deterministic Monte Carlo simulation. Completed rounds are applied first; projection starts from the surviving live bracket, and eliminated drivers receive zero conditional probability.

### `rules-case-law`
Compiles rule conditions into executable comparisons, validates and applies add/replace/remove bulletins, evaluates an incident, retrieves similar historical cases, recommends a penalty only when the violated-rule ranges have a nonempty intersection, and validates an appeal against the panel's authority. Disjoint ranges produce `RULE-PENALTY-CONFLICT` and a JSON `null` recommendation.

### `fuel-mileage`
Integrates fuel-cell level, foam damping, longitudinal/lateral slosh, banking, collector transfer, pickup exposure, engine demand, draft savings, refueling efficiency, spill, starvation, reserve, and overtime exposure. Consumption accumulates delivered fuel only; unmet demand is represented by fractional starvation duration and remains visible in the mass balance.

### `tyre-supplier`
Calculates batch mean, standard deviation, Cpk, NDT failures, tyre quality, left/right set matching, deterministic team allocation, and allocation-quality fairness.

### `setup-rig`
Calculates wheel and ride rates, K&C changes, damper force/temperature fade/cavitation, optional pull-down equilibrium, and seven-post load correlation with RMSE and R².

### `rd-center`
Selects vehicles by winner/risk/finish priority, produces a cryptographic chain of custody, verifies component dimensions, serials, materials and seals, reconciles ECU and fuel evidence, and certifies or disqualifies each selected vehicle.

### `technical-forensics`
Hashes firmware, compares calibration objects, reconstructs engine torque from vehicle motion, reconciles throttle commands, detects unexplained limiting behavior, and calculates undeclared energy imbalance.

### `accident-forensics`
Reconstructs momentum, kinetic-energy loss and delta-v, fuses time-stamped evidence by reliability, and ranks competing accident hypotheses using normalized likelihoods.

### `driver-in-loop`
Integrates core temperature, hydration, fatigue, spotter trust, reaction time, steering error, wall-contact risk and motion-platform saturation, then produces coaching actions.

### `team-logistics`
Schedules dependency-constrained shop work on limited resources, commits parts and resource time only for runnable tasks, validates due dates, checks hauler mass/volume/arrival, and estimates season readiness under transport delay uncertainty. Failed tasks do not unblock dependents, and out-of-order declarations are resolved topologically.

## Correctness and failure semantics

### Input validation

All identifiers required for cross-reference are nonempty. Collections that require uniqueness reject duplicate identifiers. Numerical values used in probability, timing, mass, capacity, range, finish, penalty, and simulation calculations must be finite and within their domain bounds. Invalid input raises an execution error and returns exit code `1`; it is not converted into a completed negative qualification.

### Completed negative assessment versus malformed request

A physically or procedurally valid request may execute and return `passed=false`; the CLI writes its evidence and exits `2`. Examples include a genuine anti-cheating mismatch, an unavailable required part, a missed due date, or a rule conflict discovered during adjudication. A malformed request exits `1` and must not partially commit rulebook, inventory, task-resource, or simulation state.

### Null semantics

JSON `null` is used when a numerical recommendation or completion time does not exist. In particular, incompatible penalty ranges produce `recommended_penalty: null`. Consumers must not coerce this value to zero, because zero would be a substantive recommendation rather than absence of a valid result.

### Deterministic evidence

For identical canonical input, source revision, and numerical environment, each report's `evidence_digest` is deterministic. Monte Carlo paths use deterministic seeds supplied or derived by the implementation. Preserve the original request and output when changing one parameter for an A/B study.

## Focused build and tests

```bash
cmake -S . -B build/nascar -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON
cmake --build build/nascar --parallel --target \
  aesim_nascar \
  nascar_competition_platform_tests \
  nascar_ecosystem_platform_tests \
  nascar_frontier_platform_tests
ctest --test-dir build/nascar --output-on-failure \
  -R '^nascar_.*_unit_tests$'
```

Use `-DAESIM_ENABLE_SANITIZERS=ON -DAESIM_ENABLE_HARDENING=OFF` for the supported ASan/UBSan focused configuration. The 2026-07-22 validation passed all three NASCAR suites in normal and sanitizer builds.

## Integrated validation

```bash
./build/full/muzixdiagsys_advanced_platform nascar self-test build/full/nascar-self-test build/full/nascar-self-test.json
```

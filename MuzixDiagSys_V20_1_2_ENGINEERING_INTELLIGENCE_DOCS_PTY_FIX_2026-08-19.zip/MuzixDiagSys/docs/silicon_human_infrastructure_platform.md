# Silicon, Human, Infrastructure, and Execution Platform

This module extends MuzixDiagSys with ten deterministic engineering laboratories that connect embedded compute, formal control, physical sensing, human response, crash safety, energy infrastructure, environmental impact, physical cybersecurity, and heterogeneous numerical execution.

Public API:

```cpp
#include "aesim/advanced/silicon_human_infrastructure_platform.hpp"
```

The umbrella include `aesim/advanced/platform.hpp` also exports the complete API.

## 1. Silicon-to-System ECU and SoC Digital Twin

`SiliconToSystemDigitalTwin` executes periodic task models over heterogeneous CPU, DSP, GPU, NPU, and lockstep-core descriptions. It models instruction throughput, branch penalties, vector acceleration, L1/L2/DRAM behavior, coherency traffic, thermal RC response, power, throttling, task deadlines, ECC events, and injected permanent or transient hardware faults.

The result records every task instance, per-core utilization and temperature, cache/memory traffic, deadline misses, safe-state entry, findings, and a canonical SHA-256 evidence identifier.

## 2. Formal Controller Synthesis and Fault-Tolerant Control

`FormalControllerSynthesisLaboratory` performs discrete algebraic Riccati iteration and synthesizes stabilizing LQR feedback gains. The certificate includes the Riccati residual and closed-loop spectral radius.

Runtime simulation supports actuator effectiveness loss, stuck actuators, bounded allocation through a regularized pseudoinverse, control-barrier corrections, and runtime-assurance fallback when a predicted state leaves the configured safety envelope.

## 3. Sensor-Device Physics and Differentiable Rendering

`SensorDevicePhysicsRenderer` uses a common physical scene to generate:

- camera frames with aperture/exposure response, shot noise, dark current, read noise, saturation, radial distortion, and rolling shutter;
- lidar returns with beam geometry, range noise, reflectivity, incidence response, divergence, and time of flight;
- radar detections with range, radial velocity, radar cross section, propagation loss, FMCW beat frequency, Doppler, and phase-noise contribution.

The camera output includes finite-difference derivatives of pixel luminance with respect to all six sensor-pose degrees of freedom, enabling sensor-placement and calibration optimization.

## 4. Digital Human and Cognitive Workload Laboratory

`DigitalHumanCognitiveLaboratory` integrates a head/neck dynamic response with belt and airbag loading, chest deformation, HIC-15 proxy, Nij, workload, fatigue, reaction-time, vestibular conflict, and motion-sickness dose. Anthropometry, age, restraint fit, neck strength, thermal environment, sleep debt, visual motion, and task demand influence the result.

## 5. Advanced Crash and Post-Crash Safety

`AdvancedCrashPostCrashLaboratory` performs explicit time integration over progressive crush zones, fracture energy, restraint and load-limiter response, airbag support, occupant relative motion, battery intrusion, electrical-isolation decay, battery heating, leakage risk, and extraction-time consequences.

## 6. Vehicle-to-Grid and Charging Infrastructure

`VehicleGridChargingInfrastructureLab` creates a slot-by-slot deterministic dispatch for vehicles, chargers, and electrical buses. It accounts for arrival/departure constraints, target energy, minimum reserves, charger direction and efficiency, bidirectional export, renewable generation, base load, transformer limits, line-voltage drop, grid outages, demand response, electricity price, grid carbon intensity, and battery-throughput degradation cost.

The allocator prioritizes energy urgency and then performs bus-specific curtailment while retaining an explicit vehicle-to-charger and vehicle-to-bus assignment.

## 7. Non-Exhaust Emissions

`NonExhaustEmissionsLaboratory` predicts tire, brake, and road wear from vehicle load, speed, acceleration, tire temperature, regenerative braking, friction-brake energy, and road roughness. Generated mass is distributed into particle-size bins and partitioned among airborne, deposited, and wet-runoff pathways. A compact dispersion model reports a receptor concentration and an explicit mass-balance residual.

## 8. Circular Economy and Life-Cycle Assessment

`CircularEconomyLifecycleAssessmentLab` aggregates raw material, manufacturing, transport, use, maintenance, reuse, remanufacture, recycling, and disposal flows. It evaluates carbon dioxide equivalent, energy, water, critical materials, recovered mass, recycled-content and avoided-burden credits, second-life credit, contribution fractions, and a bounded circularity index.

Seeded uncertainty propagation provides reproducible 5th, 50th, and 95th percentile carbon results.

## 9. Hardware Side-Channel Cybersecurity

`HardwareSideChannelCybersecurityLab` evaluates physical traces using all 256 AES key-byte hypotheses and a Hamming-weight leakage model. It calculates peak correlation, key rank, timing-test statistics, signal-to-noise ratio, fault success, and estimated traces required. It also evaluates constant-time, balancing, and glitch-attack settings and emits actionable findings.

## 10. Heterogeneous Solver Compiler and GPU Runtime

`HeterogeneousSolverCompilerRuntime` validates a directed acyclic kernel graph, performs deterministic topological scheduling, selects available scalar CPU, threaded CPU, CUDA, HIP, or SYCL devices using compute, bandwidth, memory, transfer, and launch-cost models, and identifies fusible operations.

The execution engine implements elementwise arithmetic, fused multiply-add, transcendental operations, reductions, scalar broadcasting, deterministic replay, finite-result qualification, and reverse-mode gradients for selected input tensors.

## Validation and Evidence

Every input model validates finite ranges and structural consistency before numerical work begins. Allocation sizes and graph limits are bounded. Every result supports deterministic machine-readable serialization and a SHA-256 evidence identifier calculated from canonical JSON.

The dedicated regression executable exercises all ten laboratories and is registered as `silicon_human_infrastructure_platform_unit_tests` in CTest.

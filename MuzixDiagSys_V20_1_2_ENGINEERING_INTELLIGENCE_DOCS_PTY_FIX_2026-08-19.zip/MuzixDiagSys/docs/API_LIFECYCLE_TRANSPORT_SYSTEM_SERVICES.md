# API Lifecycle, Transport, XIL, Formal Verification, Network, and Safety Services

**Revision:** 2026-08-08  
**Current advanced API registry:** 214 commands  
**This chapter expansion:** commands 174-194 (21 services)

This guide covers the 21 API commands added after the orchestration/vehicle/assurance expansion. All commands execute in-process through the shared advanced dispatcher used by both `muzixdiagsys` and `muzixdiagsys_advanced_platform`. No subprocess bridge is required.

Inside the interactive simulator shell, every command below is available directly when its name is non-conflicting and is always available as `advanced <command> ...`.

## 1. Common command grammar

Every registered command supports the common discovery and qualification grammar:

```text
<command> capabilities
<command> describe
<command> schema
<command> example
<command> self-test [work-dir] [result.json]
<command> <operation> request.json result.json [evidence-dir]
```

The 21 commands in this expansion are:

```text
api-version          api-migrate          api-baseline
api-diff             api-replay           api-lineage
artifact-store       api-metrics          api-trace
grpc-server          telemetry-stream     xil-orchestrator
formal-reachability  wcet                 schedulability
slam                 network-digital-twin diagnostic-stack
road-surface         sotif                rss-safety
```

## 2. `api-version`

`api-version` establishes a semantic-version contract for every registered API. A version record includes the command, category, implementation API, API semantic version, request-schema identifier, result-schema identifier, minimum simulator version, deprecation state, and breaking-change metadata.

```text
api-version list
api-version show request.json result.json
api-version compatibility request.json result.json
api-version deprecated request.json result.json
api-version history request.json result.json
```

Example request:

```json
{
  "command": "bms",
  "from_version": "1.0.0",
  "to_version": "1.4.0"
}
```

Compatibility follows semantic-version major-version rules. Minor/patch evolution remains backward-compatible within the current versioned contract; a major-version transition is explicitly reported as migration-required.

## 3. `api-migrate`

`api-migrate` converts unversioned API requests/results into explicit MuzixDiagSys v1 envelopes and delegates known professional document schemas to the production schema registry migration engine.

```text
api-migrate inspect old.json inspection.json
api-migrate request migration.json result.json
api-migrate result migration.json result.json
api-migrate document migration.json result.json
```

Versioned request envelopes have this form:

```json
{
  "schema": "muzixdiagsys.api-request-envelope.v1",
  "version": "1.0.0",
  "command": "spice",
  "operation": "run",
  "request": {}
}
```

Migration records applied steps and can write the migrated document atomically to an output path.

## 4. `api-baseline`

`api-baseline` manages persistent golden numerical/API results. Baselines contain the exact request, qualified result, request/result SHA-256 digests, tolerances, command/operation, revision, and timestamp.

```text
api-baseline create baseline.json result.json
api-baseline capture baseline.json result.json
api-baseline update baseline.json result.json
api-baseline compare baseline.json result.json
api-baseline verify baseline.json result.json
api-baseline history baseline.json result.json
```

`create` rejects an existing name. `update` requires an existing baseline. `capture` supports first capture and subsequent revisions. Before an existing baseline is replaced, its complete previous revision is atomically preserved under the baseline repository's `history/<name>/` directory. `history` therefore reports real revision history rather than only the current revision number.

Comparison uses `api-diff` and automatically ignores execution-time noise such as elapsed/profile wall-clock metadata.

## 5. `api-diff`

`api-diff` is an engineering comparison engine rather than simple JSON equality.

```text
api-diff result request.json result.json
api-diff workflow request.json result.json
api-diff evidence request.json result.json
api-diff timeseries request.json result.json
api-diff distribution request.json result.json
```

Structural/numerical comparison supports absolute tolerance, relative tolerance, ignored dotted paths, bounded finding output, RMSE, maximum absolute error, and maximum relative error.

`timeseries` accepts arrays of numbers or timestamped object arrays. Timestamped series are linearly interpolated over their overlapping range before MAE/RMSE/tolerance evaluation. The default object paths are `time_s` and `value`, and both can be overridden.

`distribution` reports sample counts, means, population standard deviations, mean delta, and a two-sample empirical Kolmogorov-Smirnov statistic.

## 6. `api-replay`

`api-replay` re-executes versioned requests from supported persistent manifests:

- `muzixdiagsys.api-provenance.v1`
- `muzixdiagsys.api-job.v1`
- `muzixdiagsys.api-baseline.v1`
- `muzixdiagsys.api-request-envelope.v1`

```text
api-replay verify request.json result.json
api-replay replay request.json result.json
```

`verify` is a separate integrity operation. Provenance manifests require and verify the content, request, and result SHA-256 digests. Baselines verify request/result hashes. Job and request envelopes are structurally validated. By default, replay refuses an integrity-invalid source. A successful replay compares a stored result when one is available and classifies reproduction using the configured numerical tolerances.

## 7. `api-lineage`

`api-lineage` stores a durable directed lineage graph for requests, models, artifacts, results, and evidence.

```text
api-lineage record request.json result.json
api-lineage show request.json result.json
api-lineage ancestors request.json result.json
api-lineage descendants request.json result.json
api-lineage graph request.json result.json
api-lineage impact request.json result.json
```

Each node can carry a type, content digest, metadata, and parent relationships. Impact queries walk descendants; ancestry queries walk parents. The graph is persisted atomically in JSON.

## 8. `artifact-store`

`artifact-store` is an immutable SHA-256 content-addressed repository.

```text
artifact-store put request.json result.json
artifact-store get request.json result.json
artifact-store inspect request.json result.json
artifact-store verify request.json result.json
artifact-store refs request.json result.json
artifact-store pin request.json result.json
artifact-store list request.json result.json
artifact-store gc request.json result.json
```

Artifacts may originate from files, inline JSON documents, or inline text. The backend stores raw bytes by content digest and a separate metadata record containing media type, size, source, references, pin state, and creation information. `verify` recomputes the object digest. Garbage collection retains pinned and referenced artifacts and removes unreferenced objects/metadata.

## 9. `api-metrics`

`api-metrics` executes another registered API while measuring resource use and writes durable JSONL measurements.

```text
api-metrics measure request.json result.json
api-metrics show request.json result.json
api-metrics summarize request.json result.json
api-metrics list request.json result.json
```

Linux/POSIX measurements include wall time, user CPU time, system CPU time, process maximum resident set size, qualification state, and result digest. Summary output reports record count, passed count, mean timing, and peak recorded resident memory. The metrics file can be shared by repeated benchmark campaigns.

## 10. `api-trace`

`api-trace` uses the production `OpenTelemetryTracer` and emits standards-compatible OTLP JSON plus a deterministic sidecar index used for graph/critical-path queries.

```text
api-trace trace request.json result.json
api-trace show request.json result.json
api-trace graph request.json result.json
api-trace critical-path request.json result.json
api-trace export request.json result.json
```

`graph` returns explicit span nodes and parent-child edges. `critical-path` walks the measured trace hierarchy through the longest-duration child at each level and reports the root wall duration and critical span chain. This is computed directly from captured span timing data rather than descriptive-only output.

## 11. `grpc-server`

`grpc-server` exposes the in-process advanced dispatcher through a real unary gRPC service over HTTP/2 cleartext (h2c). It uses nghttp2 for HTTP/2 framing/session state and valid Protobuf/gRPC message framing.

```text
grpc-server start request.json result.json
grpc-server status request.json result.json
grpc-server call request.json result.json
grpc-server serve request.json result.json
grpc-server stop request.json result.json
grpc-server self-test
```

Service definition: `schemas/grpc/muzixdiagsys_advanced_api.proto`

```proto
service AdvancedApi {
  rpc Execute(ExecuteRequest) returns (ExecuteResponse);
}
```

The service binds to loopback by design in this CLI service. `call` uses the built-in nghttp2 gRPC client, so the transport self-test validates an actual TCP + HTTP/2 + gRPC + Protobuf round trip through the production API dispatcher.

## 12. `telemetry-stream`

`telemetry-stream` implements RFC 6455 WebSocket telemetry/event publishing.

```text
telemetry-stream start request.json result.json
telemetry-stream status request.json result.json
telemetry-stream topics request.json result.json
telemetry-stream publish request.json result.json
telemetry-stream probe request.json result.json
telemetry-stream stop request.json result.json
telemetry-stream self-test
```

The server performs the WebSocket HTTP Upgrade handshake, computes and validates `Sec-WebSocket-Accept`, emits valid text frames, tracks connected clients, sequence numbers, published frames, and observed topics. The protocol self-test opens a real socket, verifies the 101 response and accept key, publishes a frame, and reads the actual WebSocket frame from the client side.

## 13. `xil-orchestrator`

`xil-orchestrator` unifies model/software/processor/hardware/driver-in-loop campaign concepts with the production `XilTestbench`.

```text
xil-orchestrator script request.json result.json
xil-orchestrator campaign request.json result.json
xil-orchestrator compare request.json result.json
```

`script` drives the actual signal registry, loopback automotive network, MDF recorder, simulation-step clock, diagnostic/network actions, assertions, and fault injection/clearance supported by the XIL testbench.

`campaign`/`compare` execute the same registered API request across named MIL/SIL/PIL/HIL/DIL modes with optional dotted-path per-mode overrides. Results are normalized and compared through `api-diff` so cross-level differences are explicit.

## 14. `formal-reachability`

This command promotes the production `HybridReachabilityAnalyzer` and `FormalReachabilityEngine`.

```text
formal-reachability analyze request.json result.json
formal-reachability counterexample request.json result.json
formal-reachability certify request.json result.json
```

Requests define hybrid modes with affine dynamics, disturbances and invariants; guarded/reset transitions; interval initial states; unsafe predicates; integration step; and horizon. Certification can include affine barrier certificates with coefficients, offset, and minimum decay rate.

## 15. `wcet`

`wcet` promotes the production mixed-criticality virtual ECU WCET analyzer. Task records contain criticality, periods/deadlines, LO/HI budgets, and executable vECU instruction programs. Optional signal definitions are registered before execution.

```text
wcet analyze request.json result.json
wcet self-test
```

The backend performs measured/static execution analysis rather than only calculating WCET from user-supplied scalar values.

## 16. `schedulability`

`schedulability` promotes the production `WcetSchedulabilityAnalyzer`.

```text
schedulability analyze request.json result.json
schedulability partition request.json result.json
```

It supports fixed-priority-preemptive and EDF analysis, response times, slack, blocking/jitter, utilization/density, multicore qualification, and first-fit-decreasing partitioning.

## 17. `slam`

`slam` exposes production EKF SLAM with vehicle motion prediction and landmark measurement updates.

```text
slam estimate request.json result.json
```

The API supports initial pose/covariance, linear/yaw-rate motion prediction, range/bearing landmark observations, observation covariance, innovation gating, landmark initialization, covariance propagation, estimate history, and integrity state.

## 18. `network-digital-twin`

This API unifies three real network-engineering backends:

- `TsnScheduler`
- `CanXlProtocolEngine`
- `T1sPlcaNetworkLaboratory`

```text
network-digital-twin tsn request.json result.json
network-digital-twin can-xl request.json result.json
network-digital-twin t1s request.json result.json
network-digital-twin simulate request.json result.json
```

The TSN path synthesizes link/stream schedules and timing qualification. CAN XL runs the automotive standards conformance protocol engine. 10BASE-T1S executes the PLCA laboratory model. `simulate` can assemble the applicable network analyses into one engineering result.

## 19. `diagnostic-stack`

`diagnostic-stack` promotes the authoritative `DiagnosticService` domain instead of implementing a parallel diagnostic emulator.

```text
diagnostic-stack topology request.json result.json
diagnostic-stack obd request.json result.json
diagnostic-stack uds request.json result.json
diagnostic-stack doip request.json result.json
diagnostic-stack sovd request.json result.json
diagnostic-stack dtc request.json result.json
```

The service registers ECU identity/addressing and exercises OBD, raw UDS byte requests, DoIP, SOVD, topology, and DTC paths through the production diagnostic backend.

## 20. `road-surface`

`road-surface` exposes the production `RoadSurfaceField`.

```text
road-surface sample request.json result.json
road-surface export request.json result.json
```

The backend supports procedural road generation or OpenCRG input, material/profile configuration, deterministic seed, roughness, potholes, expansion joints, rutting, crown, grade, base friction, surface water/snow, surface temperature, point sampling, and CSV export.

## 21. `sotif`

`sotif` promotes the production `SOTIFFalsifier` for ISO 21448-oriented performance-insufficiency analysis.

```text
sotif analyze request.json result.json
sotif falsify request.json result.json
```

The analysis includes AEB safety margin evaluation. Falsification performs a deterministic triggering-condition search against the configured scenario/search space and reports the worst margin and qualification state.

## 22. `rss-safety`

`rss-safety` calculates longitudinal and lateral Responsibility-Sensitive Safety margins and proper-response state.

```text
rss-safety analyze request.json result.json
```

Longitudinal safe distance accounts for rear/front speeds, response time, rear acceleration during response, rear minimum braking, and front maximum braking. The result reports safe distances, measured gaps, safety margins, safe/unsafe classification, and whether a proper response is required.

## 23. Interactive shell usage

Start the primary simulator:

```bash
./build/full/muzixdiagsys
```

Then use the new APIs directly:

```text
api-version show api-version-request.json result.json
api-baseline capture baseline-request.json result.json
api-diff timeseries diff-request.json result.json
grpc-server self-test
telemetry-stream self-test
formal-reachability self-test
wcet self-test
schedulability self-test
slam self-test
network-digital-twin self-test
diagnostic-stack self-test
road-surface self-test
sotif self-test
rss-safety self-test
```

The explicit namespace always works as well:

```text
advanced api-version show api-version-request.json result.json
advanced grpc-server self-test
advanced formal-reachability self-test
```

## 24. Validation

The dedicated permanent regression is:

```bash
python3 tests/advanced_api_lifecycle_transport_system_regression.py \
  build/full/muzixdiagsys_advanced_platform
```

It verifies all 21 new commands' capabilities/schema/example/self-test surfaces plus deep persistence, revision, numerical comparison, replay-integrity, lineage, artifact, metrics, trace, gRPC, WebSocket, XIL, formal-verification, embedded scheduling, SLAM, network, diagnostic, road-surface, SOTIF, and RSS behaviors.

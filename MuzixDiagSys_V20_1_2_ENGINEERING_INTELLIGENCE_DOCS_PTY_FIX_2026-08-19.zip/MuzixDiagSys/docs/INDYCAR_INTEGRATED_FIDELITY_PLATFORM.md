# IndyCar Integrated Fidelity Platform

**Revision:** 2026-07-27  
**Library:** `aesim_indycar`  
**Public header:** `include/aesim/advanced/indycar_integrated_fidelity_platform.hpp`  
**CLI family:** `muzixdiagsys_advanced_platform indycar-integrated`

## 1. Purpose

The IndyCar Integrated Fidelity Platform is the sixth additive IndyCar module in MuzixDiagSys. It closes the principal coupling, estimation, detailed-physics, control, human-factors, and credibility gaps between the five existing IndyCar modules. The implementation contains ten executable domains:

1. deterministic integrated co-simulation;
2. telemetry assimilation and parameter calibration;
3. full multibody vehicle dynamics;
4. detailed tire contact, thermal, pressure, wear, and structural behavior;
5. unsteady aeroelastic aerodynamics;
6. closed-loop ECU and hybrid control;
7. radio semantics and timing uncertainty;
8. a multi-car pit-lane discrete-event twin;
9. occupant, helmet, HANS, restraint, injury, and egress biomechanics;
10. unified uncertainty quantification and model-validity supervision.

The module is additive. It does not replace or remove the IR-18, operations, future-competition, frontier-expansion, or development/operations platforms. It is compiled into `aesim_indycar`, exported by `aesim/advanced/platform.hpp`, and linked transitively by `aesim_advanced`.

Every domain validates finite arithmetic, dimensions, chronology, physical ranges, identifiers, and required topology before numerical execution. Each result is deterministic, contains structured findings, and includes a canonical SHA-256 `evidence_digest`. Reports can be written atomically to a caller-selected evidence directory.

## 2. Public API

| Runtime domain | Public class | Entry point |
|---|---|---|
| `integrated-cosimulation` | `IndyCarIntegratedCoSimulationRuntime` | `run()` |
| `telemetry-assimilation` | `IndyCarTelemetryAssimilationCalibration` | `assimilate()` |
| `full-multibody` | `IndyCarFullMultibodyVehicle` | `simulate()` |
| `tire-contact` | `IndyCarDetailedTireContactModel` | `evaluate()` |
| `aeroelastic-aerodynamics` | `IndyCarUnsteadyAeroelasticAerodynamics` | `simulate()` |
| `ecu-hybrid-control` | `IndyCarClosedLoopEcuHybridControl` | `simulate()` |
| `radio-timing` | `IndyCarRadioSemanticsTimingUncertainty` | `evaluate()` |
| `pit-lane-twin` | `IndyCarPitLaneDiscreteEventTwin` | `simulate()` |
| `occupant-biomechanics` | `IndyCarOccupantBiomechanics` | `evaluate()` |
| `uncertainty-validity` | `IndyCarUncertaintyModelValidityFramework` | `evaluate()` |

The aggregate platform provides:

```cpp
[[nodiscard]] aesim::doc::Value capabilities() const;
[[nodiscard]] aesim::doc::Value execute(
    const std::string& domain,
    const aesim::doc::Value& request,
    const std::string& working_directory = {}) const;
[[nodiscard]] aesim::doc::Value self_test(
    const std::string& working_directory = {}) const;
```

## 3. Build and validation

```bash
cmake -S . -B build/indycar-integrated -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF

cmake --build build/indycar-integrated --parallel --target \
  aesim_indycar \
  indycar_integrated_fidelity_platform_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/indycar-integrated --output-on-failure \
  -R '^indycar_.*(unit_tests|source_regression)$'
```

Clang sanitizer configuration:

```bash
cmake -S . -B build/indycar-integrated-sanitize -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON \
  -DAESIM_ENABLE_SANITIZERS=ON \
  -DAESIM_ENABLE_HARDENING=OFF \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build/indycar-integrated-sanitize --parallel --target \
  indycar_integrated_fidelity_platform_tests
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --test-dir build/indycar-integrated-sanitize --output-on-failure \
  -R '^indycar_integrated_fidelity_platform_unit_tests$'
```

## 4. Command-line operation

List domains:

```bash
./build/indycar-integrated/muzixdiagsys_advanced_platform \
  indycar-integrated capabilities \
  build/indycar-integrated/capabilities.json
```

Run all ten deterministic self-tests:

```bash
./build/indycar-integrated/muzixdiagsys_advanced_platform \
  indycar-integrated self-test \
  build/indycar-integrated/evidence \
  build/indycar-integrated/self-test.json
```

Run one domain:

```bash
./build/indycar-integrated/muzixdiagsys_advanced_platform \
  indycar-integrated tire-contact \
  examples/indycar_integrated_fidelity/tire_contact.json \
  build/indycar-integrated/tire-contact.json \
  build/indycar-integrated/evidence
```

The same command pattern applies to each domain. The request examples in `examples/indycar_integrated_fidelity/` are compiled into the focused unit-test workflow and must parse, execute, pass, and emit a 64-character evidence digest.

## 5. Integrated co-simulation runtime

`IndyCarIntegratedCoSimulationRuntime` advances vehicle motion, tire force and temperature, aero coefficient and structural-mode states, ECU torque control, hybrid deployment/regeneration, battery and coolant temperatures, fuel energy, and conservation evidence on one authoritative clock.

### 5.1 Multi-rate scheduler

The request defines:

- `base_step_s`;
- `controller_step_s`;
- `vehicle_step_s`;
- `aero_step_s`;
- `thermal_step_s`;
- `output_step_s`;
- `duration_s`.

Every subsystem interval must be an integer multiple of the base step. This removes fractional scheduler drift and makes update counts deterministic. The runtime rejects more than ten million base ticks in one request to prevent unbounded execution.

### 5.2 Coupled states

The state includes longitudinal and lateral speed, position, heading, yaw rate, roll, pitch, engine torque, boost, hybrid power, state of charge, battery and coolant temperature, aero coefficients, structural modal displacement and velocity, four tire temperatures, four tire wear fractions, and remaining fuel energy.

The vehicle solver receives downforce and drag from the current aero state. Tire capacity depends on downforce, temperature, wear, and water depth. The controller receives a tire-utilization guard, SOC, and thermal derating state. The thermal model receives tire dissipation, hybrid current, engine load, and road speed. These exchanges occur at declared synchronization points rather than through independent unsynchronized loops.

### 5.3 Numerical behavior

- vehicle integration uses bounded force capacity and deterministic semi-implicit state updates;
- aero coefficients use first-order unsteady response;
- the structural aero mode uses a backward-Euler velocity update to remain stable at production time steps;
- SOC and fuel energy are conserved with efficiency-aware accounting;
- the report contains an energy residual, normalized energy residual, coupling residual, scheduler counts, extrema, and complete checkpoint history.

A warning is emitted when the requested energy or coupling residual limit is exceeded. Thermal safety-envelope violations are errors.

## 6. Telemetry assimilation and calibration

`IndyCarTelemetryAssimilationCalibration` implements a general linearized state estimator with a gated scalar measurement update and a separate weighted parameter-identification stage.

### 6.1 State estimation

Required state inputs are:

- unique `state_names`;
- `initial_state`;
- symmetric `initial_covariance`;
- nonnegative `process_noise_variance`;
- time-ordered measurements.

An optional `continuous_dynamics` matrix propagates the state. Covariance propagation includes the continuous dynamics and process noise. Every measurement declares a sensitivity vector, variance, observed value, optional bias, and optional normalized-innovation-squared gate.

The update uses the Joseph covariance form. This retains covariance symmetry and reduces loss of positive semidefiniteness from finite precision. Outliers above the NIS gate are retained in the evidence log but excluded from the posterior state update.

### 6.2 Parameter calibration

`calibration_samples` contain a feature vector, target, and positive weight. The engine forms a weighted normal system, adds the requested ridge regularization, solves using pivoted elimination, and reports estimates, standard errors, and 95 percent confidence intervals. It also reports weighted calibration RMSE.

### 6.3 Outputs

The report includes posterior means and standard deviations, posterior covariance, all innovations, accepted and rejected counts, NIS statistics, residual RMSE and MAE, calibrated parameters, and evidence findings.

## 7. Full multibody vehicle

`IndyCarFullMultibodyVehicle` implements 22 dynamic degrees of freedom:

- chassis longitudinal, lateral, and vertical translation;
- chassis roll, pitch, and yaw;
- body angular rates;
- four unsprung vertical states and rates;
- four wheel rotational speeds.

The solver constructs a static preload equilibrium before the first time step. This prevents a nominal car from beginning with zero tire load or a spurious suspension transient.

Each corner includes spring, damper, tire vertical stiffness, wheel inertia, unsprung mass, road height, steering transformation, combined-slip tire force, drive torque, and brake torque. Chassis equations include aerodynamic drag and downforce, load-transfer moments, yaw moment, roll and pitch restoring forces, and world-frame position integration.

Outputs include the complete state history, corner normal loads, wheel speeds, acceleration, minimum wheel load, peak roll, peak lateral acceleration, and a mechanical-energy residual. Wheel-lift conditions are findings rather than silently clamped events.

## 8. Detailed tire contact model

`IndyCarDetailedTireContactModel` combines force generation, thermal evolution, pressure growth, wear, hydroplaning, moments, and structural margin.

### 8.1 Contact and force model

The model computes raw longitudinal and lateral brush forces from slip ratio, slip angle, and camber. A combined-slip friction ellipse limits the force vector. Available friction varies with:

- tread temperature relative to its optimum;
- inflation pressure;
- vertical-load sensitivity;
- water depth and hydroplaning fraction;
- accumulated wear;
- surface roughness.

The result includes longitudinal force, lateral force, aligning moment, overturning moment, rolling resistance, friction utilization, pneumatic trail, and contact-patch area.

### 8.2 Thermal and pressure model

Three states represent tread, carcass, and contained gas. Slip work and rolling loss heat the tread. Conductive and convective paths exchange energy among tread, carcass, gas, and ambient air. Inflation pressure follows the gas-temperature ratio. Wear integrates slip energy with a temperature acceleration factor.

### 8.3 Structural model

A belt-stress estimate combines inflation membrane stress and contact load. The report provides the minimum structural margin and emits an error when the margin drops below one.

## 9. Unsteady aeroelastic aerodynamics

`IndyCarUnsteadyAeroelasticAerodynamics` models ground effect, ride height, pitch, roll, yaw, crosswind, drafting, wall proximity, underbody separation hysteresis, coefficient lag, and multiple flexible modes.

The underbody stall state enters below an entry ride height and recovers only above a higher exit height. This hysteresis prevents unrealistic instantaneous stall recovery. Downforce and drag coefficients approach their targets at the configured response rate.

Each mode declares modal mass, stiffness, damping, lift coupling, and drag coupling. The mode update uses a stable implicit velocity formula. Modal displacement feeds back into aerodynamic coefficients and front balance. Outputs include downforce, drag, side force, front balance, stall state, modal coordinates, peak deflection, and maximum balance shift.

## 10. Closed-loop ECU and hybrid control

`IndyCarClosedLoopEcuHybridControl` executes deterministic control laws rather than accepting delivered torque as an input.

The controller contains:

- driver torque-demand interpretation;
- PI torque tracking with anti-windup bounds;
- throttle and boost actuator dynamics;
- engine-speed torque shaping;
- traction-slip reduction;
- shift torque cut;
- pit-speed override;
- push-to-pass and high-demand deployment;
- brake regeneration;
- SOC and battery-temperature derating;
- voltage/current limiting;
- battery, coolant, and oil thermal states;
- fuel-energy accounting.

The report exposes requested and delivered torque, engine and hybrid power, throttle and boost state, traction reduction, SOC, current, thermal states, degraded-mode status, deployed and regenerated energy, peak current, fuel energy, and torque-tracking error.

## 11. Radio semantics and timing uncertainty

`IndyCarRadioSemanticsTimingUncertainty` handles two distinct evidence problems in one synchronized report.

### 11.1 Radio semantics

Messages are normalized and tokenized. A deterministic lexicon scores warning, command, question, confirmation, correction, and status intents. Numeric car entities are extracted. Delivery probability depends on SNR, clipping, interference, and packet loss. Comprehension probability additionally depends on cognitive load, urgency-sensitive latency, semantic density, ambiguity, and read-back state.

A received mandatory read-back is treated as strong evidence of comprehension. Critical messages use a higher default acceptance threshold. The report distinguishes delivery from comprehension; a delivered message is not automatically considered understood.

### 11.2 Timing reconciliation

Each timing event can contain observations from primary and backup loops, video, telemetry, or another clocked source. Observation variance combines measurement variance, clock uncertainty, and quantization variance. The reconciled timestamp is the inverse-variance and detection-probability weighted estimate.

Outputs include standard deviation, 95 percent confidence interval, observation count, reduced chi-square, and a consistency decision. Statistically inconsistent sources create a finding without discarding the observations.

## 12. Pit-lane discrete-event twin

`IndyCarPitLaneDiscreteEventTwin` processes all cars in chronological and deterministic identifier order. Pit boxes have team ownership, lane position, and availability. Cars declare arrival time, box, entry speed, and a task graph.

Service tasks have:

- unique identifiers;
- duration and optional variability;
- a resource;
- optional dependencies.

The scheduler permits independent resources to work concurrently, serializes use of the same resource, and detects dependency cycles. It calculates queue delay, double stacking, service start and finish, box-reset time, release time, teammate interference, pit speeding, nearest lane conflict, and unsafe-release probability.

The output contains a chronologically sorted event log and per-car service record. Unsafe release and pit speeding are errors.

## 13. Occupant biomechanics

`IndyCarOccupantBiomechanics` models a driver, helmet, HANS load sharing, harness, torso, pelvis, neck, chest, femur loading, crash-pulse integration, and self-egress impairment.

The request provides a strictly increasing crash pulse with translational acceleration and optional pitch rate. The solver integrates torso, head, and pelvis relative motion. Harness and neck forces use spring-damper elements; HANS load share reduces the load transmitted through the anatomical neck path.

The report calculates:

- delta velocity;
- head resultant acceleration history;
- HIC15 using every admissible interval up to 15 ms;
- peak harness force;
- neck force and moment;
- combined neck injury criterion;
- chest deflection and normalized chest index;
- femur force and normalized femur index;
- injury-adjusted self-egress time.

Limits are request-configurable. Exceeding HIC15, Nij, chest, femur, or egress limits is an error.

## 14. Unified uncertainty and model validity

`IndyCarUncertaintyModelValidityFramework` uses deterministic Halton sampling, not an implementation-dependent random generator. Parameters may be normal or uniform and have declared physical ranges and calibration support.

The response model is a full quadratic form:

```text
y = intercept + linear^T x + 0.5 x^T quadratic x
```

The framework reports sample mean, aleatory standard deviation, model-form and numerical uncertainty, total standard deviation, P05/P50/P95, a 95 percent interval, optional threshold-failure probability, and normalized parameter importance based on squared correlation.

Model validity is evaluated separately from prediction uncertainty. The operating point is checked against every declared range and against normalized calibration distance. The report provides per-parameter distance, extrapolation, aggregate distance, calibration coverage, and `in_validity_domain`. A numerically precise prediction outside the validity domain still fails.

## 15. Evidence and failure semantics

All ten domains use the same evidence contract:

```json
{
  "schema": "muzixdiagsys.indycar-...v1",
  "passed": true,
  "findings": [],
  "evidence_digest": "64 hexadecimal characters"
}
```

Input-contract violations throw `std::invalid_argument` before numerical execution. Engineering-limit violations are returned as findings so the caller retains a complete report. `passed` is false when an error or fatal finding exists.

## 16. Qualification boundary

These are executable engineering models, not official INDYCAR rule interpretations, homologation decisions, medical diagnoses, timing certifications, tire approvals, or race-control decisions. Quantitative use requires series- and team-authorized parameter data, sensor calibration, uncertainty characterization, mesh or time-step studies where applicable, correlation to test and telemetry evidence, independent review, and documented validity limits.

The integrated runtime is intentionally deterministic and bounded. It is not a substitute for a validated real-time HIL scheduler until its execution-time behavior is qualified on the target hardware. The occupant model is a reduced-order biomechanics model and does not replace a validated finite-element human-body model or medical assessment.

## Motorsport CLI convenience aliases

The original `indycar-integrated` family remains authoritative. `indycar run integrated DOMAIN ...` provides aggregate routing; `indycar-hybrid`, `indycar-pit`, `indycar-radio`, and `indycar-tyres` are direct shortcuts. See `MOTORSPORT_CLI_COMMANDS.md`.

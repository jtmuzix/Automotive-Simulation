# Formula One Race-Engineering Digital Twin

The Formula One race-engineering module extends the existing Formula One platform with five executable laboratories. It is additive and retains the original technical compliance, 2026 power-unit, active-aerodynamics, tyre/track-evolution, and race-strategy APIs.

## Suspension, steering, heave, and platform control

`F1PlatformControlLaboratory` implements a coupled sprung-body and four-unsprung-mass model with heave, pitch, roll, tyre vertical compliance, nonlinear bump and droop stops, corner dampers, front and rear third-element behavior, anti-roll coupling, chassis torsional stiffness, load transfer, steering compliance, configurable Ackermann geometry, camber gain, bump steer, plank contact, wheel lift, and bottoming detection.

`evaluate_setup` and `optimize_setup` execute candidate heave, anti-roll, and ride-height configurations over a supplied lap load history. The objective includes platform error, floor contact, load variation, and plank wear.

## Carbon brakes and brake-by-wire

`F1CarbonBrakeLaboratory` models all four wheel ends using coupled disc, pad, caliper, rim, and tyre-gas thermal nodes. Hydraulic pressure has finite response time, friction varies with temperature and wear, and rear braking blends MGU-K recovery through a brake-by-wire state. The model reports torque, lockup margin, regenerative energy, thermal limits, wear, oxidation, flat spotting, fluid-boiling risk, and hydraulic fallback after a brake-by-wire failure.

## Survey-grade circuit and weather twin

`F1CircuitDigitalTwin` converts an ordered surveyed circuit centerline into spatial track cells while retaining elevation, banking, camber, roughness, drainage, and base grip. Spatial weather fields drive rainfall, solar heating, evaporation, wind, humidity, and local surface temperatures. Vehicle passages deposit tyre energy, rubber, marbles, and spray. The twin evolves water film, rubber, dust, oil, marbles, surface temperature, and local grip.

The wake model reports distance- and offset-dependent downforce, drag, cooling, turbulence, and lateral-flow multipliers.

## Live telemetry and pit-wall engineering

`F1LiveRaceEngineer` uses a deterministic ensemble estimator to assimilate timestamped telemetry. It estimates tyre core temperature and wear, grip, fuel, electrical state, floor damage, power-unit health, cooling margin, brake wear, and state uncertainty. Normalized innovations create bounded anomaly records.

`advise` combines the estimated car state with lap, traffic, weather, neutralization, and competitor context. It recommends pit timing, compound, energy deployment, cooling actions, reliability protection, and driver messages with an evidence hash.

## Reliability, damage, and component allocation

`F1ReliabilityLifecycleManager` tracks serialized components with Weibull life, thermal acceleration, vibration, loading, shock, distance, health, and failure probability. Direct damage events add impact, thermal, and severity damage. The allocation optimizer assigns serviceable components across sessions and families using bounded beam search, championship-weighted failure risk, sealed-component change penalties, and remaining health.

## Evidence and limitations

Every primary result provides deterministic document serialization; critical decision and optimization results include SHA-256 evidence seals. These are engineering simulation results and do not replace FIA scrutineering, physical brake testing, surveyed circuit certification, team telemetry systems, or manufacturer component lifing.

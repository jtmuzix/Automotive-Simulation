# MuzixDiagSys Integrated Vehicle–Occupant–Environment Ecosystem

**Revision:** 2026-07-12  
**Primary public header:** `include/aesim/high_fidelity/ecosystem.hpp`  
**Integrated runtime:** `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`

## 1. Purpose and scope

This implementation extends the existing next-generation vehicle-depth runtime without replacing or removing any pre-existing model, console command, test, plugin, FMU component, or interoperability path. It adds a conservative, deterministic vehicle-ecosystem layer spanning thermo-fluid networks, combustion mechanics, transmission internals, particle-scale battery degradation, raw perception signals, human behavior, interactive traffic, formal operational design domains, mechanism-based durability, and real-time FMI/OpenX execution.

The implementation is split across four production translation units:

- `src/vehicle/ecosystem_thermofluid_powertrain.cpp`
- `src/vehicle/ecosystem_battery_sensors.cpp`
- `src/vehicle/ecosystem_human_world_interop.cpp`
- `src/vehicle/ecosystem_integrated.cpp`

The integrated runtime owns each new subsystem and advances them in a physically ordered loop. Existing vehicle-depth physics remain available independently through `IntegratedVehicleDepthRuntime` and are also embedded in the new ecosystem runtime.

## 2. Unified one-dimensional thermo-fluid network

`UnifiedThermoFluidNetwork` is a finite-volume network for compressible and incompressible working fluids. Nodes contain pressure, temperature, mass, wall temperature, vapor quality, composition, and stored energy. Branches contain geometry, roughness, valve state, pump/compressor work, heat transfer, and transported species.

Implemented behavior includes:

- Air, exhaust, coolant, lubricating oil, gasoline, diesel, hydrogen, refrigerant, brake-fluid, and generic-liquid properties.
- Ideal-gas and weakly compressible liquid closure relations.
- Darcy–Weisbach friction with laminar and turbulent regimes.
- Choked and unchoked compressible orifice flow.
- Pump, compressor, turbine, and passive-duct shaft work.
- Cavitation and vapor-quality tracking.
- Wall-to-fluid heat transfer and wall thermal inertia.
- Conservative species advection and mixing.
- Node pressure and temperature updates from mass and energy balances.
- Cumulative boundary mass, energy, and species accounting.
- Per-step mass and energy residuals.

The default integrated network contains intake air, exhaust, engine coolant, battery coolant, oil, fuel rail, and refrigerant loops. Subsystems exchange heat and mass through explicit branch requests rather than hidden algebraic assignments.

## 3. Cranktrain, valvetrain, and EHL bearings

`CranktrainValvetrainEhlSystem` resolves crankshaft torsion, cylinder gas torque, flywheel/load coupling, cam-driven valve motion, and elastohydrodynamic bearing state.

Implemented behavior includes:

- Multiple torsional crank segments with inertia, stiffness, damping, angular position, and angular velocity.
- Cylinder-pressure gas torque using crank-slider geometry.
- Firing-order phase offsets.
- External load and accessory torques.
- Cam lift targets, follower dynamics, spring force, damping, lash, valve float, and valve bounce.
- Main-bearing Sommerfeld-like operating state.
- Minimum oil-film thickness.
- Peak hydrodynamic film pressure.
- Mixed-lubrication fraction and asperity friction.
- Bearing friction torque and temperature.
- Torsional stored energy and first-law residual.

The delivered crank torque drives the transmission model; the bearing losses and oil temperature load the thermo-fluid and durability systems.

## 4. Injection, spray, combustion, and emissions

`DetailedInjectionCombustionSystem` models the complete transient path from high-pressure fuel rail to cylinder heat release and engine-out species.

Implemented behavior includes:

- Fuel rail bulk compressibility and pump replenishment.
- Hydraulic injector force, needle mass, spring, damping, lift, and closure.
- Orifice mass flow constrained by commanded fuel per cycle.
- Multi-bin droplets with diameter, temperature, penetration, evaporation, and wall impingement.
- Wall-film accumulation and temperature-dependent evaporation.
- Trapped-air mass, compression temperature, equivalence ratio, and EGR sensitivity.
- Crank-angle ignition window and Wiebe-derived burn rate.
- Cylinder pressure, burned/unburned temperatures, indicated torque, and knock integral.
- Engine-out NOx, soot, HC, CO, CO2, and particulate-number rates.
- Fuel mass and chemical-energy residuals.

Fuel chemistry is selectable for gasoline, diesel, ethanol, hydrogen, ammonia, and synthetic fuels. Lower heating value, density, and stoichiometric air/fuel ratio are selected consistently with fuel type.

## 5. Full transmission, clutch, and planetary physics

`FullTransmissionSystem` supports conventional and electrified driveline architectures while retaining the pre-existing torsional driveline model.

Supported architectures include:

- Manual transmission.
- Automated manual transmission.
- Torque-converter automatic.
- Dual-clutch transmission.
- Continuously variable transmission.
- Dedicated hybrid transmission.
- Planetary power-split hybrid.
- Multi-speed e-axle.
- Transfer-case all-wheel drive.

Implemented effects include:

- Discrete ratio selection and ratio transition.
- Primary and secondary clutch normal force.
- Stribeck static/dynamic friction transition.
- Clutch slip torque, thermal capacity, friction energy, and wear.
- Torque-converter speed ratio, torque ratio, and lockup blending.
- Planetary sun, ring, and carrier kinematic constraints.
- Gear-mesh stiffness, damping, transmission error, force, and loss.
- Output shaft compliance, backlash contact, and torque reversal.
- Torque-driven compliant-shaft state that separates converter/clutch slip from shaft twist.
- Initial crank-speed synchronization and ratio selection by minimum kinematic speed mismatch.
- Bearing, seal, oil-churning, and mesh losses.
- Lubricant temperature and energy residual.

## 6. Particle-scale battery aging and abuse

`ParticleScaleBatteryPack` contains one electrochemical state for every simulated cell and radial solid-diffusion shells in each electrode.

Implemented behavior includes:

- Radial anode and cathode lithium fractions.
- Conservative equal-volume radial control volumes with pairwise inter-shell fluxes.
- Bounded electrochemical surface flux with exact solid-lithium inventory accounting.
- Electrolyte concentration depletion and recovery.
- Butler–Volmer-style charge-transfer overpotential.
- Concentration overpotential and ohmic drop.
- Cell-to-cell current sharing.
- SEI growth, capacity loss, and resistance growth.
- Lithium plating and stripping under cold or high-SOC charging.
- Gas generation, cell pressure, vent opening, and gas release.
- Internal-short current and Joule heating.
- Cell thermal capacity, coolant transfer, and neighbor conduction.
- Runaway initiation, reaction progress, heat release, and propagation.
- Pack voltage, energy, charge, capacity, gas, and runaway summaries.
- Thermodynamic stored energy computed from the integral of open-circuit voltage over state of charge, preserving dE/dQ = OCV.
- Series-cell-aware external charge accounting and first-law residual reporting.

The integrated runtime uses this pack as a detailed electrochemical shadow model alongside the existing production battery and HV-network models. It can therefore be used selectively under the multi-fidelity framework.

## 7. Raw radar, camera, and lidar simulation

`RawSensorSuite` owns waveform/image-level models rather than reporting only ideal object lists.

### Radar

`RawFmcwRadar` generates complex FMCW I/Q samples over chirps and receive samples. It includes range delay, Doppler, antenna gain, target radar cross section, multipath, rain attenuation, phase/noise terms, mutual interference, range-Doppler processing, and threshold detections.

### Camera

`RawCameraSensor` generates a Bayer mosaic using perspective projection, radial/tangential lens distortion, rolling-shutter row timing, exposure, photon shot noise, read noise, fog attenuation, rain artifacts, contamination, clipping, and saturation statistics.

### Lidar

`RawWaveformLidar` generates per-beam temporal waveforms with time-of-flight peaks, beam divergence, reflectance, atmospheric attenuation, fog/rain backscatter, thermal/electronic noise, multi-return extraction, and intensity/range output.

All random processes use deterministic seeds and become replayable when the enclosing runtime state and inputs are reproduced.

## 8. Human driver, HMI, and takeover behavior

`HumanDriverHmiModel` combines longitudinal/lateral driver control with attention, fatigue, trust, reaction delay, and automation handover.

Implemented behavior includes:

- Preview steering from lane offset, heading error, curvature, and lateral acceleration.
- Car-following and target-speed acceleration behavior.
- Throttle and brake actuator lag.
- Attention and fatigue evolution.
- Automation trust adaptation.
- Manual, assisted, automated, takeover-requested, and minimum-risk modes.
- Driver acknowledgement and hands-on-wheel state.
- Timed visual/audible/haptic escalation.
- Delayed human command queue.
- Automatic minimum-risk maneuver when takeover is not completed.

## 9. Closed-loop traffic, V2X, and formal ODD

`ClosedLoopTrafficV2xOddWorld` contains independently responding road users, traffic signals, V2X packets, and an explicit operational design domain.

Implemented behavior includes:

- Passenger cars, trucks, buses, motorcycles, bicycles, and pedestrians.
- IDM-style longitudinal response.
- Lane intent and lane changes.
- Signal phase cycling with offsets.
- V2X transmission latency, obstruction loss, authentication state, packet delivery, and loss.
- Nearest-lead detection for driver control.
- Formal ODD limits for temperature, precipitation, visibility, grade, friction, speed, map, V2X, and construction zones.
- Normalized boundary margin.
- Predicted ODD exit time.
- Minimum-risk-maneuver request.

## 10. Mechanism durability, prognostics, and RUL

`MechanismDurabilityPrognostics` converts simulated loads into damage and remaining-useful-life estimates.

Implemented mechanisms include structural fatigue, thermomechanical fatigue, bearing fatigue, gear pitting, brake wear, tire wear, battery capacity fade, battery resistance growth, catalyst aging, and connector fretting.

The model provides:

- Turning-point extraction and closed-cycle counting.
- Stress-life damage with configurable reference load and exponent.
- Mean-load influence.
- Arrhenius temperature acceleration.
- Energy- and throughput-driven wear.
- Paris-law crack propagation.
- Cumulative Miner-like damage.
- Health index and failure probability.
- Particle-population RUL estimate with mean and standard deviation.
- Fleet-ready deterministic randomization.

## 11. FMI/OpenX and real-time execution

`RealtimeSilPilHilExecutor` provides Offline, SIL, PIL, and HIL modes with periodic tasks, deadlines, priorities, wall-clock pacing, analog channels, network queues, jitter, real-time factor, and overrun accounting.

`FmiOpenXInteroperability` exports:

- FMI 3.0 `modelDescription.xml` with scalar value references and causality.
- OpenDRIVE `.xodr` road geometry.
- OpenSCENARIO `.xosc` actors, trajectories, and infrastructure.
- Formal ODD JSON.
- OSI-style ground truth JSON.
- OpenLABEL-style annotation JSON.

It also imports the supported OpenSCENARIO actor subset and updates the integrated snapshot.

## 12. Integrated execution order

For each ecosystem step, the runtime executes this causal order:

1. Update traffic agents, infrastructure, V2X delivery, and ODD assessment.
2. Update human driver and HMI/takeover state.
3. Compute injection, spray evaporation, combustion, emissions, and cylinder pressure.
4. Apply cylinder pressure to the cranktrain, valvetrain, bearings, and oil losses.
5. Transfer crank torque through clutches, gearsets, converter, and output shaft.
6. Advance the existing next-generation vehicle-depth runtime.
7. Advance cell-level battery electrochemistry, aging, gas, shorts, and propagation.
8. Exchange heat, mass, and shaft work through the unified thermo-fluid network.
9. Generate raw radar I/Q, camera pixels, and lidar waveforms at sensor cadence.
10. Accumulate mechanism damage and estimate RUL.
11. Execute real-time SIL/PIL/HIL tasks and I/O exchange.
12. Refresh FMI/OpenX scalar state and compute aggregate conservation residuals.

## 13. Console integration

The main command family is:

```text
industrial energy ecosystem ...
```

Aliases are `vehicle-ecosystem`, `whole-vehicle`, and `openx-runtime`.

Important commands:

```text
industrial energy ecosystem status
industrial energy ecosystem auto on
industrial energy ecosystem reset 298.15
industrial energy ecosystem step 0.02 2200 150 20 900 0.05 24
industrial energy ecosystem driver-mode automated
industrial energy ecosystem execution-mode hil on
industrial energy ecosystem target-speed 27
industrial energy ecosystem environment 8 450 0.05 4000
industrial energy ecosystem traffic-add lead-01 car 60 0 18 24 on
industrial energy ecosystem signal-add intersection-01 250 30 35 4 0
industrial energy ecosystem odd-set 253.15 323.15 35 80 0.12 0.35 36 on off off
industrial energy ecosystem battery-short 17 0.03
industrial energy ecosystem battery-short-clear 17
industrial energy ecosystem export ./ecosystem_openx
```

Subsystem reports are selected with `thermofluid`, `cranktrain`, `combustion`, `transmission`, `particle-battery`, `sensors`, `driver`, `traffic`, `durability`, `realtime`, and `interop`.

## 14. Signal namespace

The runtime publishes synchronized values under `electrification.ecosystem.*`, including:

- `time_s`
- `fluid.mass_residual_kg`
- `fluid.energy_residual_j`
- `crank.delivered_torque_nm`
- `combustion.indicated_torque_nm`
- `transmission.output_torque_nm`
- `battery.voltage_v`
- `battery.maximum_temperature_k`
- `sensor.radar_detections`
- `sensor.lidar_returns`
- `sensor.camera_saturation`
- `driver.automation_mode`
- `odd.inside`
- `odd.boundary_margin`
- `durability.minimum_health`
- `durability.earliest_rul_h`
- `realtime.factor`
- `realtime.overruns`
- `energy_residual_j`

## 15. Calibration requirements

The default parameters are physically bounded engineering values, not a claim of correlation to a particular vehicle. Predictive use requires measured or supplier-derived data for:

- Fluid volumes, line dimensions, roughness, pump/compressor maps, and heat-transfer coefficients.
- Crankshaft inertias, torsional stiffnesses, firing order, valve lift curves, spring forces, and bearing clearances.
- Injector current/lift/rate traces, spray SMD, wall-film data, cylinder pressure, and engine-out emissions.
- Gear ratios, clutch friction maps, converter maps, gear mesh stiffness, and lubricant losses.
- Cell electrode parameters, diffusivity, exchange current, aging coefficients, thermal contact, venting, and abuse calorimetry.
- Radar chirp/antenna/RCS data, camera optics/noise, lidar pulse/receiver characteristics, and material reflectance.
- Human factors distributions and HMI timing.
- Traffic behavior distributions, communication channel models, and ODD requirements.
- S–N/E–N curves, Paris constants, wear coefficients, and field failure records.
- Real ECU timing traces, network interfaces, I/O scaling, and HIL timing budgets.

## 16. Safety and certification statement

These models are engineering simulation, controls-development, and virtual-verification tools. They do not independently provide ISO 26262, ISO 21448, ISO/SAE 21434, UNECE R155/R156, FMI, ASAM, emissions, battery-abuse, crash, or regulatory certification. Formal use requires configuration control, physical correlation, requirements traceability, tool qualification where applicable, and independent review.

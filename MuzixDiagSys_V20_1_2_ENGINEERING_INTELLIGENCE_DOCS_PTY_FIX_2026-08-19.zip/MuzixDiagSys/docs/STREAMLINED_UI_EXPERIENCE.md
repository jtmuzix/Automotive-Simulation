# Streamlined Terminal UI Experience

## Purpose

MuzixDiagSys retains its complete command surface, compatibility aliases, fixed dashboards, scripts, project formats, and terminal workflows while adding a task-oriented interaction layer. The layer is implemented in `include/aesim/app/ui_experience.hpp` and `src/ui/ui_experience.cpp` and is integrated into the existing POSIX terminal frontend. It is not a replacement shell and does not hide executable capabilities.

## Compatibility contract

1. Every canonical command remains executable.
2. Every accepted compatibility alias remains executable.
3. Discovery profiles affect presentation only.
4. Generated forms emit ordinary canonical commands.
5. Guided workflows execute ordinary canonical commands.
6. Existing fixed dashboard pages remain available.
7. Custom dashboards are additive.
8. Existing UI preferences are preserved; new experience state is stored in the adjacent `.experience` file.
9. The existing editor, completion, history, filters, bookmarks, inspector, and dashboard-focus behavior remain available.
10. State undo uses the simulator's complete verified checkpoint serialization when the backend supports it.
11. Beginner menus are additive command front ends; the command prompt remains visible and authoritative.
12. Menu execution, menu insertion, typed commands, scripts, and generated forms share the same canonical dispatcher.

## Task-oriented home screen

Interactive sessions begin with a task-oriented home view rather than an undifferentiated command list.

```text
ui home
```

The screen reports project, vehicle, powertrain, execution state, current warnings, recent operational context, and the primary work areas:

- Operate Vehicle
- Diagnose
- Analyze & Validate
- Engineer Systems
- Motorsport
- Safety & Assurance
- Advanced Research

The complete command line remains available at all times.

## Beginner menus and the persistent command line

F7, Alt-M, or `ui menu open` opens a concise beginner-oriented overlay organized into Home, Model, Scenario, Run, Monitor, Analyze, Validate, and Help categories. The lower pane and prompt remain visible.

- Arrow keys move between categories and actions.
- Number keys 1–8 select a category.
- A displayed letter selects an action.
- Enter executes the selected canonical command through the ordinary command dispatcher.
- Tab closes the menu and inserts the canonical command into the persistent editor for review or modification.
- Esc closes the menu without executing or changing simulation state.

The menu contains no independent simulation logic. Each item is declarative metadata containing a title, concise explanation, shortcut, and canonical command. Menu execution therefore receives the same parser validation, state-change preview classification, transaction record, output formatting, undo capture, command history, and failure semantics as direct CLI entry.

```text
ui menu
ui menu open
ui menu close
```

The CLI is never removed, hidden as a product mode, or reduced to a secondary compatibility path. Menus teach and accelerate the command language rather than replacing it.

## Discovery profiles

```text
ui profile status
ui profile essential
ui profile professional
ui profile research
ui profile complete
```

Profiles change the actions promoted by the home screen and universal action index. They never reject manually entered commands.

| Profile | Intended presentation |
|---|---|
| Essential | Vehicle operation, common diagnostics, project and report actions |
| Professional | Calibration, validation, diagnostics, HIL, FMI, engineering workflows |
| Research | Advanced solvers, uncertainty, optimization, assurance, distributed execution |
| Complete | Every registered canonical action |

## Universal action palette

F2 or Ctrl-Space opens a single indexed search over:

- Commands
- Guided workflows
- Factory and custom dashboards
- Metrics
- Settings
- Named workspaces
- Contextual help targets

Command-line access:

```text
ui find coolant
ui find workflow:diagnostic
ui find metric:rpm
ui find dashboard:track
ui palette brake temperature
```

The index uses normalized direct and subsequence fuzzy scoring. Results carry an action kind, category, summary, canonical invocation, and score. Compatibility aliases contribute to matching but the result executes the canonical action.

## Declarative command metadata and generated forms

The UI registry defines command path, canonical title, category, summary, mutation classification, discovery promotion, aliases, tags, and typed parameter metadata. Parameters support:

- Text
- Integer
- Real
- Boolean
- Enumeration
- Path
- Required/optional state
- Units
- Defaults
- Minimum/maximum bounds
- Enumerated choices

Commands:

```text
ui metadata throttle
ui form open throttle
ui form set percent 45
ui form show
ui form command
ui form run
ui form close
```

Form validation rejects missing required values, invalid finite numbers, out-of-range values, invalid Boolean values, and enumeration values outside the declared choices. The generated canonical command is always shown before execution.

Live root-registry metadata is merged with richer parameter schemas. Registering the authoritative command list therefore cannot erase form constraints.

## Contextual quick actions

```text
ui actions
ui actions run <index>
```

Actions are derived from current simulator state. Examples include quick start when the engine is stopped, pause and inspect actions while running, thermal diagnosis when coolant is elevated, lubrication diagnosis when pressure is low, and guided diagnostics for emissions faults. Actions generate normal commands and remain optional.

## Named workspaces

A workspace captures presentation state independently of engineering project data:

- Dashboard visibility and selected page
- Lower command-activity pane visibility
- Status-bar visibility and segments
- Watch-panel visibility and metrics
- Discovery profile
- Accessibility mode
- Refresh profile

```text
ui workspace list
ui workspace save diagnostics-night No-color diagnostic workspace
ui workspace load diagnostics-night
ui workspace delete diagnostics-night
```

Workspaces are persisted atomically and indexed by the universal palette.

## Grouped command transactions and typed results

Every completed command is converted into a typed `CommandResult` containing:

- Status: success, warning, failure, cancelled, or running
- Summary
- Diagnostics with severity, code, message, and remediation
- Named properties
- Tables
- Artifact references
- Suggested next actions
- Optional progress
- Original raw output

The terminal records each execution as a transaction with command, start/completion timestamps, typed result, artifacts, and collapsed/expanded state.

```text
ui transactions
ui transactions toggle <id>
```

Raw command output remains available beneath the typed summary. No diagnostic detail is discarded.

## Context-sensitive help

```text
ui help current
ui help throttle
ui help form
ui help workflow
ui help issues
ui help dashboard
```

Current help follows the active form, workflow, metric, or operational state. Command help is generated from the same declarative metadata used by forms, validation, and universal search.

## Guided workflows

Built-in resumable workflows include:

- New project setup
- Guided diagnosis
- EMC qualification
- HIL commissioning
- WEC/IMSA endurance weekend
- Automated parking validation

```text
ui workflow list
ui workflow start diagnostic-scan
ui workflow show
ui workflow complete
ui workflow next
ui workflow back
ui workflow run
ui workflow cancel
```

Each step contains a title, explanation, command set, optional status, and completion state. `ui workflow run` queues the current step's canonical command through the normal simulator dispatch path.

## Custom dashboard pages and drill-down

Factory pages remain unchanged. Users can add persistent pages from live metric names:

```text
ui dashboard list
ui dashboard create thermal-watch Thermal qualification page
ui dashboard add thermal-watch coolant_c trend 108 118
ui dashboard add thermal-watch oil_pressure_kpa numeric 120 80
ui dashboard show thermal-watch
ui dashboard remove thermal-watch coolant_c
ui dashboard delete thermal-watch
ui dashboard factory engine
```

Supported display labels include numeric, gauge, trend, and table. The current terminal renderer uses the declared type and thresholds while retaining numeric values and units.

Metric drill-down:

```text
ui drill coolant_c
```

The report includes current value, known warning/critical thresholds, related commands, and recommended actions.

## Alert and issue center

The issue center observes both live simulator context and typed command diagnostics.

```text
ui issues
ui issues all
ui issues ack <id>
ui issues resolve <id>
```

Issues include severity, source, title, detail, remediation, occurrence count, acknowledgment, and resolution state. Live thermal, lubrication, emissions, and rev-limiter conditions resolve automatically when the condition normalizes. Manually acknowledged history remains available through `ui issues all`.

## Preview and dry-run

```text
ui preview reset
ui dry-run fault inject sensor map
```

Preview classifies mutation and computational expense, lists state that may change, lists state guaranteed to remain, and reports operation-specific warnings. Preview never executes the command.

## Simulation-state undo, redo, and UI branches

Before a state-changing command, the terminal asks the backend for a complete serialized simulator state. Successful commands record before/after revisions.

```text
ui state status
ui state undo
ui state redo
ui state branch-save baseline
ui state branch-load baseline
ui undo
ui redo
```

Restoration uses `Backend::restore_ui_state`. In the production runtime this delegates to `PowertrainSimulation::studio_restore_state`, preserving the established deterministic checkpoint validation path. Unsupported backends return an explicit error rather than pretending to restore state.

## Unified terminology

```text
ui terminology
```

The presentation layer uses canonical names such as Dashboard, Workspace, Command activity, Universal action palette, and Diagnostics. Historical spellings remain accepted aliases.

## Incremental rendering and output virtualization

The renderer constructs a terminal-row model and compares it to the previous frame.

- Initial render, resize, modal overlay, screen-reader mode, or more than 45% changed rows: full redraw.
- Otherwise: only dirty rows are moved to and rewritten.
- Cursor position is restored after the patch.
- Synchronized-update terminal mode brackets each patch.
- Output wrapping and filtering remain lazy; only viewport rows are materialized for drawing.
- Modal overlays invalidate the row cache to guarantee a clean redraw when closed.

```text
ui render
```

## Refresh-rate profiles

```text
ui refresh status
ui refresh local
ui refresh ssh
ui refresh low-bandwidth
ui refresh batch
```

| Profile | Dashboard interval |
|---|---:|
| local | 50 ms |
| ssh | 200 ms |
| low-bandwidth | 1000 ms |
| batch | Disabled/event-driven |

Screen-reader mode rate-limits deterministic full-frame announcements to 1000 ms unless the batch profile disables periodic refresh. The simulation thread reads the active profile dynamically. Changing a profile does not require restart.

## Accessibility modes

```text
ui accessibility status
ui accessibility standard
ui accessibility high-contrast
ui accessibility no-color
ui accessibility ascii-only
ui accessibility screen-reader
```

- **standard:** full terminal color and Unicode presentation.
- **high-contrast:** strips inherited colors and renders bold white on black.
- **no-color:** strips ANSI styling while retaining Unicode structure.
- **ascii-only:** strips styling and converts box drawing, arrows, markers, and sparklines to ASCII equivalents.
- **screen-reader:** emits plain ASCII-compatible row content and uses deterministic full-frame updates.

Statuses always include textual labels such as `[OK]`, `[WARN]`, `[FAIL]`, severity names, and explicit state names. Color is never the only indicator.

## Semantic color themes

The terminal uses semantic color roles rather than assigning unrelated colors per screen. Existing textual labels such as success, warning, error, running, stopped, and modified remain present so color is never the only indicator.

```text
ui theme list
ui theme status
ui theme set professional-dark
ui theme set professional-light
ui theme set high-contrast
ui theme set colorblind-safe
ui theme set monochrome
ui theme set amber-terminal
ui theme set system
```

The selected theme is persisted in the atomic UI preference file. `NO_COLOR` suppresses color output regardless of the stored theme. Accessibility modes continue to take precedence at rendering time: no-color, ASCII-only, and screen-reader modes strip styling, while high-contrast mode applies its dedicated accessible presentation. Theme changes invalidate the incremental-render cache so the complete frame is repainted consistently.

## Keybinding manager

```text
ui keys list
ui keys profile default
ui keys profile minimal-ssh
ui keys profile vim
ui keys profile accessibility
# Default profiles bind F7 and Alt-M to beginner-menu.
ui keys bind ctrl-shift-h home global
ui keys unbind ctrl-shift-h global
```

Bindings are contextual (`global`, `command`, `output`, or future contexts). The active terminal loop resolves context-specific bindings before global bindings. Implemented actions include palette, help, output-pane toggle, output focus, repaint, completion, overlay closure, output navigation, inspection, and command invocations. Unknown action strings are dispatched as ordinary commands. The decoder accepts ordinary control bytes, SS3/xterm function keys, Shift-Tab, Kitty/CSI-u modified keys, xterm `modifyOtherKeys`, and modified cursor-key sequences, allowing bindings such as `ctrl-shift-h` to work without hard-coded key cases.

## Persistence

The established UI preference file remains responsible for classic layout settings and the active semantic color theme. The additive experience file stores:

- Discovery, accessibility, and refresh profiles
- Named workspaces
- Custom dashboards and widgets
- Keybindings

Optional status-bar segments `profile`, `issues`, `accessibility`, and `refresh` expose the active experience state without altering the legacy full preset.

Writes use a temporary file and atomic replacement. Loading merges persisted custom dashboards over permanent factory dashboards so factory options cannot disappear.

## Verification

`tests/ui_experience_tests.cpp` covers metadata merging, form validation, universal search, workspaces, workflows, dashboards, drill-down, issue detection and counters, typed results, previews, state history, branches, transactions, terminology, keybindings, screen-reader refresh throttling, incremental rendering, and persistence. `tests/ui_streamlined_experience_pty.py` exercises the complete production terminal path, including generated commands, workspaces, workflows, custom dashboards, drill-down, state restoration, transactions, optional status segments, accessibility, and CSI-u key dispatch. `tests/ui_beginner_menu_theme_pty.py` verifies F7 and Alt-M navigation, canonical command insertion, normal dispatcher execution, direct CLI continuity, theme selection, and theme persistence. `tests/ui_no_color_pty.py` verifies that `NO_COLOR` overrides every semantic theme without removing textual state labels. Existing PTY, completion, golden-frame, preference, lower-pane, help-focus, resize, and input-fuzz tests continue to protect the legacy interface.

## Professional visual consistency

The terminal frontend uses one responsive panel grammar across factory dashboards, compact and minimal dashboard modes, custom dashboards, the command-activity pane, hidden-panel notices, and the engineering workspace home screen.

Visual conventions:

- Rounded `╭ │ ╰` frames identify dashboards and workspace surfaces.
- Square `┌ │ └` frames identify command activity and chronological output.
- `├─ SECTION ─┤` dividers establish dashboard hierarchy without introducing unrelated box styles.
- Quantitative dashboard instruments use bracketless solid-line scales: `━` is the measured fraction and `─` is the remaining range. The line-weight distinction survives monochrome/`NO_COLOR` operation and replaces shaded/block progress-bar furniture on factory dashboards.
- Dashboard metric rows use stable label/value/instrument columns so changing values do not shift gauges horizontally.
- Page-level semantic accents unify the frame, section heading, and metric labels; gauge/value colors then communicate domain or threshold state. Green/yellow/red remain health/caution/critical signals, while blue/cyan/magenta distinguish mechanical/control/pressure domains.
- Panel width follows the active terminal width, with bounded rendering from 20 through 200 columns.
- Narrow layouts use shorter, semantically equivalent control captions rather than blindly truncating full-width instructions.
- Full, compact, narrow, and minimal layouts retain the same status vocabulary and navigation model.
- The activity pane exposes its active severity/text filter, scroll position, dashboard visibility, and keyboard controls in consistent header and footer locations.
- ASCII-only and screen-reader modes translate all panel glyphs, arrows, bullets, and status separators into terminal-safe equivalents.

The engineering workspace home screen uses aligned fields and stable sections for session context, work areas, live state, recommended actions, and navigation. Declarative metadata search ranks exact command matches ahead of incidental matches in summaries or categories, keeping forms and parameter information predictable.

Golden terminal frames are maintained for 80×24, 100×24, 120×36, and 132×44 layouts. PTY regressions additionally exercise the 55-column minimal layout, dynamic resizing, scroll-anchor preservation, dashboard visibility, lower-pane visibility, preferences, modified keys, input fuzzing, and professional workflows.

## V16 browser graphical projection

V16 adds a full graphical browser projection without replacing the terminal experience described above. The browser consumes the same workspace, command metadata, permissions, telemetry, calibration, topology, scenario, workflow, comparison, and semantic-analysis models. Interactive docking, WebGL 3D inspection, Canvas/SVG engineering visualization, graphical editing, and the Problems panel therefore remain synchronized with canonical state rather than maintaining a competing client-side engineering model. The complete browser behavior and operator controls are documented in `ENGINEERING_UI_PLATFORM.md` and Chapter 78 of `MUZIXDIAGSYS_USER_MANUAL.md`.

## V19 contextual help and diagnostic workflow

The streamlined interface now treats help as a path-aware engineering service rather than a static command dump. `help <path>` combines canonical root metadata with nested completion grammar and reports purpose, behavior, syntax, aliases, state impact, discoverable next tokens, examples, and validation/recovery actions. `help search <term>` searches canonical roots and literal nested paths; `help errors [CODE]` explains diagnostic meaning, likely cause, recovery, and an example.

`ui help <metadata-rich-command>` adds typed parameter details: engineering units, defaults, required state, allowed ranges/enumerations, generated-form access, and a safe operating workflow. The Canonical Command Completion inspector now projects that path-aware guidance directly into its independently scrollable right pane: availability/permission, purpose, syntax, next choices with explanations, state impact/side effects, engineering guidance, examples, semantic preflight, non-executing preview, full-help/schema/error-recovery commands, and completion controls. It points to the same `help <path>` authority rather than maintaining a competing help database, preventing drift between completion and documentation.

Semantic validation now carries `cause`, `remediation`, and `example` in text and JSON. The graphical Problems panel consumes the same structured diagnostics. Raw command failures are classified into command-discovery, authorization, capability, numeric/unit/range, I/O, transport, and runtime-state guidance rather than receiving one generic remedy.

Recommended sequence for an unfamiliar command:

```text
help search <concept>
help <canonical-path>
ui semantic <full-command-line>
ui preview <full-command-line>
<full-command-line>
```


## V20.1.2 integrated engineering workspace

The streamlined terminal experience now has a second level for dense engineering operation: `ui desktop select unified-engineering` activates the coordinated schema-driven workspace, while `ui pane ...` controls the physical terminal arrangement of the already-existing dashboard, diagnostics/output, command, and watch views.

The pane framework supports named horizontal/vertical layouts, weighted panes, focus cycling, show/hide, resize, and validated persistence. On terminals wide enough for a useful split, horizontal layouts place dashboard and watch data side-by-side; narrow terminals retain the established stacked rendering path. This is intentionally adaptive so an SSH session does not inherit an unusable desktop-oriented geometry.

F2/Ctrl-Space continues to open the Universal Command Palette. `ui palette <query>` now also searches structured engineering objects and live signal metadata. `ui signal-explorer`, `ui time`, `ui diagnostic-center`, `ui run-manager`, `ui causal-difference`, `ui dashboard-designer`, and `ui equivalence` are all discoverable through that same palette and invoke canonical commands.


## Research-grade workbench discovery

All 28 research-grade workbenches participate in the normal Workbench Library, Universal Command Palette, schema-driven desktop, and CLI/GUI equivalence registry. They do not add another navigation system. In the browser, an advanced workbench presents its canonical command bar plus action templates from the same `WorkbenchSchema` returned by `/api/schema`; in SSH/TUI usage, tab completion exposes the same command families.

For a dense research session, activate `ui desktop select unified-engineering`, then open specialized workbenches from the normal library or palette. The existing pane framework remains responsible for terminal layout; the new features do not replace it.

## V20.1.2 tabbed analytical lower pane

The lower terminal pane is no longer limited to Command Activity, but Command Activity remains the default and retains its existing logical scroll anchor, filters, search, bookmarks, mouse-wheel/PageUp/PageDown handling, and PTY behavior. Use `ui lowerpane tabs` to inspect the available views and `ui lowerpane view <name>` to select `activity`, `events`, `timeline`, `jobs`, `notifications`, `experiments`, `profiler`, `navigator`, or `causal`. `ui lowerpane next|previous` cycles views.

The selected view is persisted with UI preferences and project layout metadata. `ui prefs reset` restores `activity`. Analytical views are read-model projections over existing engineering services; they do not duplicate events, jobs, alerts, experiment records, profiler samples, context objects, or causal dependencies.

The main terminal also exposes compact operator surfaces directly through `ui sparkline`, `ui event-timeline`, `ui time-travel`, `ui causal-inspector`, `ui experiment-cockpit`, `ui jobs`, `ui notifications`, `ui navigator`, `ui parameter-inspector`, `ui doc-inspect`, `ui pit-wall`, `ui track-map`, `ui friction-circle`, `ui performance-profiler`, and `ui uncertainty-view`. These commands are appropriate for SSH use because they produce bounded terminal-native text/Unicode output and retain ASCII/screen-reader fallbacks through the existing rendering policy where applicable.

## Terminal-native selection and readable status meters

Normal terminal text selection is now the default interaction policy. MuzixDiagSys does not enable application mouse reporting merely because the terminal supports SGR mouse coordinates. This allows ordinary drag highlighting and terminal-native copy/paste without requiring an application-specific selection mode.

Use `ui mouse on` only when click/wheel interaction with TUI hit-test regions is desired. The application enables button/wheel reporting but omits continuous motion modes. Use `ui mouse off` to release all application mouse modes and return drag selection to the terminal emulator. Bracketed-paste protection remains active in both states.

The raw-input decoder consumes complete mouse sequences even when capture is disabled, so accidental/stale mouse reports cannot become command text or leave the shell blocked until Escape. `tests/ui_input_fuzz_pty.py` explicitly exercises this recovery path and proves that a normal shell command can be executed immediately after mouse traffic.

Bounded progress, coverage, utilization, and balance indicators use one high-resolution Unicode meter implementation with eighth-cell fill resolution. Legacy `#` fill bars are not used for these meters. Telemetry sparklines remain unchanged because their glyph sequence represents signal history, not percentage fill.

The complete practical workflow is documented in [`REAL_WORLD_TUI_USAGE_GUIDE.md`](REAL_WORLD_TUI_USAGE_GUIDE.md).


## V20.1.2 professional operator analysis and workflow layer

The terminal now coordinates live reference analysis, forensic navigation, and command workflow through existing engineering authorities rather than separate feature stores.

### Dashboard references, trends, and metric evidence

Factory gauges use solid `━/─` tracks with semantic `◆` target, `│` warning, and `┃` critical markers. Main-page live trend indicators show signed rates as well as arrows. Use `ui metric-inspect <signal>` for signal kind, quality/freshness, source, provenance, engineering limits, current/cursor value, and least-squares trend.

Freeze only the displayed dashboard with `ui dashboard-reference freeze [label]`; return to live presentation with `ui dashboard-reference live`. Capture a live baseline with `ui dashboard-reference baseline capture [label]`, or project an existing N-way comparison run with `ui dashboard-reference baseline run <run-id> [time-s]`. Per-metric `ΔF` and `ΔB` remain derived from the single live telemetry authority.

### Linked investigation and first-out analysis

`ui linked-cursor` binds the existing primary time cursor and existing plot A/B cursors. `ui transient-lens` ranks normalized pre/post-event signal shifts from retained telemetry. `ui soe` observes the existing Mission Control alert stream and identifies the first event in quiet-gap-delimited bursts. `ui transient-lens first-out ...` bridges those two existing evidence paths without copying alerts or waveforms.

### Output navigation and multi-selection

The Command Activity minimap summarizes existing logical scrollback with semantic markers for selection, search, bookmarks, severity, and transactions. `ui minimap on|off|toggle` controls only that projection. In Output focus, Space toggles the current record in the shared output selection set. `ui multi-select` also supports visible/range selection and bulk bookmark, unbookmark, or CSV export using stable logical record IDs.

### Safe staged execution and repeatable macros

`ui command-stage add <command>` uses the current semantic validator and preview. `ui command-stage commit` revalidates every entry against current state and then queues canonical commands through the ordinary command/transaction dispatcher. It is not a second executor.

`ui macro record <name>` captures successfully completed commands; `ui macro stop` commits the recording; `ui macro parameterize` converts literal tokens into named parameters; `ui macro run` replays through that same normal dispatch path. Libraries use the validated versioned `MZUX-MACRO|1` persistence format.

### Performance and adaptive visual density

`ui performance-hud on` exposes the existing UI performance monitor in the status bar and detailed report, including render time, input-to-paint latency, changed rows/spans, indexed objects, retained records, and update rate. `ui declutter dim|compress` can reduce the prominence of stable rows after a configurable rendered-frame threshold; warning, critical, fault, blocked, limit, and context rows are never compressed. `ui declutter off` restores the complete presentation immediately.

These capabilities remain compatible with custom themes, `NO_COLOR`, ASCII-only/screen-reader modes, responsive narrow layouts, terminal-native text selection, explicit application mouse capture, Canonical Command Completion, the Universal Command Palette, and all existing workbenches.

## Next-generation operator analysis and responsive layout

The advanced operator layer adds statistical run-family envelopes (`ui statistical-envelope`), auditable semantic highlight explanations (`ui highlight-explain`), live time/cursor/event change ranking (`ui what-changed`), and metadata-derived provenance graphs (`ui provenance-graph`). Control hysteresis (`ui hysteresis`) and state ribbons (`ui state-ribbon`) project existing telemetry/state-machine authorities, while `ui alarm-flood` analyzes the existing SOE chronology without creating a second alert store.

`ui incident-workspace first-out|event <sequence>` composes the existing linked cursors, dashboard reference, pane layout, diagnostics and workspace manager around an incident. `ui pane maximize|restore` and `ui pane breakpoint|apply-breakpoint` remain operations of the single persistent TUI pane model. Width changes preserve the first visible command transaction boundary so responsive reflow does not destroy scroll investigation context.

The persistent command-path ribbon (`ui command-ribbon`) is generated from the same semantic CLI, preview, permission and completion services as the command editor. Atomic staging (`ui command-stage atomic on|off`) adds rollback only when simulator/workspace checkpoints can actually own the affected state; irreversible/external and unsupported presentation mutations are rejected rather than given false atomic semantics.

The engineering scratchpad (`ui scratchpad eval|convert`) reuses the existing virtual-channel expression engine and semantic unit registry. Frame-jank capture (`ui jank`) observes the real render path and stores only bounded threshold excursions. Live requirement margins (`ui requirement-margin <requirement-id>`) derive tolerance margin from the existing verification matrix and live telemetry. Together with the existing 78-feature operator layer, the focused engineering UI qualification contract now covers **93 feature families**.


## Operator-status hierarchy

Full-density factory dashboards now separate a compact `OPERATOR STATUS` block from page-specific engineering metrics. The block exposes System status, Priority, Page focus, Next action, and the solid-line gauge legend. Severity is encoded by both color and shape (`●` good, `◆` information, `▲` caution, `✖` critical, `◇` neutral), so SSH sessions remain understandable when color is unavailable. Constrained layouts automatically drop these explanatory rows before essential metrics are removed.


## PTY regression synchronization contract (2026-08-19)

Interactive PTY regressions must synchronize on observable UI state rather than fixed sleeps. For command transactions that require both a result marker and return to command focus, the test harness uses one continuous accumulation buffer and requires the markers in order: the command-result marker first, then `FOCUS COMMAND`. Do not implement this as two independent `read_until()` calls: a legal PTY read boundary can split `FOCUS COMMAND` between those buffers (for example `FOC` / `US COMMAND`) and produce a false timeout even though the UI rendered correctly. The ordered helper also prevents an old focus repaint emitted before the command result from satisfying the new transaction.

This contract affects test synchronization only; it does not change terminal rendering, command execution, focus behavior, or operator-visible features.

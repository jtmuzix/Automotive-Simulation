# MuzixDiagSys Validation Lifecycle Platform

## Scope

The validation lifecycle layer extends the authenticated engineering platform with
formal behavioral verification, uncertainty and calibration studies,
multi-fidelity modeling, adaptive experiment planning, safety-case management,
thermal and battery lifecycle simulation, ECU/network timing analysis,
X-in-the-loop execution, virtual-fleet studies, predictive maintenance, NVH
analysis, physical consistency checking, collaborative approval workflows, and
an engineering knowledge graph.

The implementation is part of the production `aesim_engineering` library. It is
available through:

- the authenticated `muzixdiagsys_engineering` executable;
- the `muzixdiag.Client` Python API;
- the C++ API in `aesim/platform/validation_lifecycle.hpp`.

All command execution uses the same user database, role-based authorization, and
tamper-evident audit log as the rest of the engineering platform.

## Authentication and permissions

Every command below requires an owner-only credential file:

```text
jtmuzix
T1k1@420
```

On POSIX systems, protect the file before use:

```bash
chmod 600 credentials.txt
```

General invocation:

```bash
muzixdiagsys_engineering \
  --credential-file credentials.txt \
  --database users.json \
  COMMAND ...
```

The built-in roles expose these lifecycle capabilities:

| Role | Lifecycle access |
|---|---|
| `administrator` | Complete access |
| `simulation-engineer` | Read/write/run access to all lifecycle domains, including XIL |
| `analyst` | Requirements, UQ, calibration, surrogate prediction, experiment design, assurance read, fleet, maintenance, NVH, consistency, graph read |
| `auditor` | Read-only requirements, assurance, collaboration, graph, manifest, and audit evidence |
| `operator` | Existing approved simulation operations; no lifecycle administration |
| `learner` | Existing learning and safe demonstration operations |

Permissions are domain-scoped, such as `requirements.run`, `assurance.read`,
`xil.run`, `collaboration.write`, and `graph.read`. Wildcard permissions such as
`requirements.*` are resolved by the existing RBAC matcher.

## 1. Formal requirements and runtime monitors

### Requirement modes

The runtime monitor supports:

- `always`: the expression must remain true for every trace sample;
- `eventually`: the expression must become true at least once;
- `response-within`: every rising trigger must receive a response within a
  bounded interval;
- `until`: a hold expression must remain true until the release expression
  becomes true.

Expressions support arithmetic, comparisons, Boolean composition, variables,
and these functions:

```text
abs sqrt exp log sin cos tanh min max clamp
```

### Requirement document

```json
{
  "requirements": [
    {
      "id": "REQ-BRAKE-001",
      "title": "Brake-pressure response",
      "mode": "response-within",
      "trigger_expression": "brake_request >= 0.5",
      "expression": "brake_pressure_bar >= 80",
      "window_s": 0.15,
      "severity": "safety",
      "tags": ["braking", "ASIL-D"]
    }
  ]
}
```

### Trace document

```json
{
  "samples": [
    {
      "time_s": 0.0,
      "signals": {
        "brake_request": 0.0,
        "brake_pressure_bar": 0.0
      }
    }
  ]
}
```

### Command

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  requirements evaluate requirements.json trace.json requirements-result.json
```

The result contains pass/fail state, minimum robustness, evaluated-sample count,
trigger count, violations, and a human-readable report. A failed requirement
returns process status `1`; malformed input or authorization failures return an
error status.

## 2. Uncertainty quantification and sensitivity analysis

The UQ engine combines:

- seeded Latin-hypercube sampling;
- bounded uniform, normal, and lognormal variables;
- sample distributions and confidence intervals;
- Pearson and standardized-regression sensitivities;
- Saltelli first-order and total-order Sobol indices;
- local central finite-difference derivatives and elasticities.

```json
{
  "parameters": [
    {
      "name": "road_mu",
      "distribution": "normal",
      "location": 0.8,
      "scale": 0.08,
      "lower": 0.2,
      "upper": 1.2
    }
  ],
  "nominal": {"road_mu": 0.8},
  "model": {
    "outputs": {
      "stopping_distance_m": "42 / road_mu"
    }
  },
  "samples": 256,
  "sobol_base_samples": 64,
  "seed": 420
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  uncertainty run uncertainty-study.json uncertainty-result.json
```

## 3. Automatic calibration and parameter estimation

The calibration engine fits expression-model parameters to weighted
observations using the existing global-plus-local optimizer. Bounds and
finite-difference steps are explicit, and output includes convergence,
termination reason, objective reduction, standard errors, parameter
correlations, bound activity, and per-metric RMSE.

```json
{
  "parameters": [
    {
      "name": "gain",
      "value": 1.0,
      "lower": 0.0,
      "upper": 5.0,
      "finite_difference_step": 0.0001
    }
  ],
  "observations": [
    {
      "id": "sample-001",
      "inputs": {"x": 2.0},
      "observed": {"y": 5.0},
      "standard_deviation": {"y": 0.05}
    }
  ],
  "model": {"outputs": {"y": "gain*x+offset"}},
  "options": {
    "global_generations": 20,
    "population_size": 32,
    "local_iterations": 40,
    "seed": 99
  }
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  calibration fit calibration-study.json calibration-result.json
```

## 4. Multi-fidelity and surrogate-model management

`SurrogateModel` implements normalized ridge-regression response surfaces with
linear or quadratic bases. Quadratic bases include intercept, linear terms,
squares, and pairwise interactions. Model documents persist:

- ordered input/output names;
- training-domain bounds;
- means and scales;
- fitted coefficients;
- validation RMSE;
- selected basis.

```json
{
  "samples": [
    {"inputs": {"speed": 10.0}, "outputs": {"energy": 2.5}},
    {"inputs": {"speed": 20.0}, "outputs": {"energy": 8.0}},
    {"inputs": {"speed": 30.0}, "outputs": {"energy": 17.5}}
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  fidelity train samples.json energy-surrogate.json quadratic

muzixdiagsys_engineering --credential-file credentials.txt \
  fidelity predict energy-surrogate.json '{"speed":25.0}'
```

Predictions report whether the point is inside the training domain and a
normalized extrapolation measure. The C++ `MultiFidelityManager` selects the
lowest-cost registered model satisfying requested certified-error and cost
limits and can dispatch either a full evaluator or a trained surrogate.

## 5. Adaptive experiment design

Two deterministic design criteria are available:

- `maximin`: maximizes distance from existing and already selected points;
- `doptimal`: greedily improves the log determinant of the information matrix.

```json
{
  "candidates": [
    {"temperature_c": -20, "soc": 0.2},
    {"temperature_c": -20, "soc": 0.8},
    {"temperature_c": 40, "soc": 0.2},
    {"temperature_c": 40, "soc": 0.8}
  ],
  "existing": [
    {"temperature_c": 20, "soc": 0.5}
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  experiment select candidates.json selected.json 3 doptimal
```

## 6. Safety-case and assurance-case management

The safety-case graph supports goals, strategies, contexts, assumptions,
justifications, evidence, and directed support links. Evidence files are
SHA-256 sealed. Evaluation recursively identifies failed nodes and evidence
whose current digest no longer matches its recorded digest.

```json
{
  "schema": "muzixdiagsys.safety-case",
  "version": "1.0.0",
  "nodes": [
    {
      "id": "G1",
      "kind": "goal",
      "statement": "Emergency braking is acceptably safe",
      "verdict": "unreviewed",
      "artifact": "",
      "artifact_sha256": "",
      "tags": ["braking"]
    },
    {
      "id": "E1",
      "kind": "evidence",
      "statement": "Campaign evidence",
      "verdict": "pass",
      "artifact": "reports/braking.json",
      "artifact_sha256": "DIGEST",
      "tags": []
    }
  ],
  "links": [
    {"parent": "G1", "child": "E1", "relation": "supported-by"}
  ],
  "approvals": []
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  assurance evaluate safety-case.json G1

muzixdiagsys_engineering --credential-file credentials.txt \
  assurance impact safety-case.json E1
```

Approvals carry actor, decision, time, comment, and digest. Safety-case
persistence is atomic through the shared document layer.

## 7. Full thermal-management and HVAC network

The EV default network includes:

- battery and battery-coolant nodes;
- motor, inverter, and powertrain-coolant nodes;
- radiator and chiller;
- cabin air and cabin thermal mass;
- windshield and ambient boundary;
- conductive and fluid heat-transfer links;
- heat-pump cooling/heating, resistive heating, blower, pumps, and fans;
- solar and occupant loading;
- humidity, ventilation, dehumidification, and fog-risk estimation;
- energy-residual reporting.

```json
{
  "steps": 600,
  "dt_s": 0.1,
  "heat_sources_w": {
    "battery": 1500,
    "motor": 1000,
    "inverter": 500
  },
  "environment": {
    "ambient_temperature_k": 308.15,
    "solar_load_w": 700,
    "vehicle_speed_m_s": 25,
    "occupant_heat_w": 200,
    "ambient_humidity": 0.75
  },
  "control": {
    "cabin_setpoint_k": 295.15,
    "compressor_command": 0.9,
    "heater_command": 0.0,
    "blower_command": 0.8,
    "pump_command": 1.0,
    "fan_command": 0.7
  }
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  thermal run thermal-study.json thermal-result.json
```

## 8. Battery degradation and safety modeling

The lifecycle model accumulates:

- elapsed calendar time and ampere-hour throughput;
- equivalent full cycles;
- SEI-related capacity loss;
- active-material loss;
- low-temperature/high-rate lithium plating;
- gas generation under thermal and voltage stress;
- resistance growth;
- state of health and projected RUL;
- charge-derating and high-risk isolation requests.

```json
{
  "duty": [
    {
      "duration_s": 1800,
      "current_a": -200,
      "temperature_k": 278.15,
      "soc": 0.85,
      "depth_of_discharge": 0.4,
      "terminal_voltage_v": 410,
      "coolant_available": true
    }
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  battery-life run battery-duty.json battery-life-result.json
```

## 9. ECU scheduler and automotive-network timing

The timing simulator provides:

- preemptive fixed-priority ECU task execution;
- phases, periods, deadlines, WCETs, and priorities;
- release, completion, response-time, jitter, and deadline statistics;
- fixed-priority response-time analysis;
- CAN and CAN-FD serialization and arbitration ordering;
- message deadline monitoring;
- CPU and bus utilization;
- deterministic event-driven releases, including releases crossed by execution.

```json
{
  "duration_ns": 1000000000,
  "tasks": [
    {
      "id": "brake_control",
      "period_ns": 10000000,
      "deadline_ns": 10000000,
      "wcet_ns": 1500000,
      "priority": 10,
      "phase_ns": 0
    }
  ],
  "messages": [
    {
      "id": "brake_status",
      "producer_task": "brake_control",
      "arbitration_id": 256,
      "payload_bytes": 8,
      "period_ns": 10000000,
      "deadline_ns": 10000000,
      "bitrate_bps": 500000,
      "can_fd": false
    }
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  timing run timing-model.json timing-result.json
```

## 10. Real-time SIL, PIL, and HIL execution

### Deterministic built-in exchange

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  xil run sil 1000 1000000 sil-result.json

muzixdiagsys_engineering --credential-file credentials.txt \
  xil run hil 1000 1000000 hil-result.json realtime
```

### File-defined I/O exchange

`xil execute` supports deterministic loopback I/O and timestamped UDP HIL I/O.
Channel types are:

- `analog_voltage`;
- `analog_current`;
- `digital`;
- `pwm`;
- `frequency`;
- `encoder`;
- `thermocouple`.

```json
{
  "mode": "hil",
  "cycles": 100,
  "period_ns": 1000000,
  "real_time": false,
  "overrun_policy": "count",
  "io": {
    "backend": "loopback",
    "channels": [
      {
        "id": 1,
        "name": "pedal",
        "direction": "input",
        "type": "analog_voltage",
        "unit": "1",
        "minimum": 0,
        "maximum": 1,
        "safe_value": 0
      },
      {
        "id": 2,
        "name": "command",
        "direction": "output",
        "type": "pwm",
        "unit": "1",
        "minimum": 0,
        "maximum": 1,
        "safe_value": 0
      }
    ],
    "input_series": {
      "pedal": [0.0, 0.25, 0.5, 0.75, 1.0]
    },
    "read_timeout_ns": 0
  },
  "controller": {
    "outputs": {
      "command": "clamp(pedal*2,0,1)"
    }
  }
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  xil execute xil-spec.json xil-result.json
```

For UDP HIL, replace `backend` with `udp` and supply `local_address`,
`local_port`, `remote_address`, and `remote_port`. All exits attempt to enter the
configured safe output state and close the hardware transport. Overrun policies
are `stop`, `count`, and `skip`.

## 11. Manufacturing tolerance and virtual-fleet analysis

Fleet generation supports bounded uniform, normal, and lognormal tolerance
variables, a positive-definite correlation matrix, deterministic seeded draws,
expression-defined metrics, per-vehicle acceptance, yield, and metric means plus
1st and 99th percentiles.

```json
{
  "fleet_size": 10000,
  "seed": 1234,
  "tolerances": [
    {
      "name": "mass",
      "distribution": "normal",
      "nominal": 1800,
      "spread": 80,
      "lower": 1500,
      "upper": 2100
    },
    {
      "name": "drag",
      "distribution": "normal",
      "nominal": 0.29,
      "spread": 0.02,
      "lower": 0.22,
      "upper": 0.38
    }
  ],
  "correlation": [[1.0, 0.35], [0.35, 1.0]],
  "model": {
    "outputs": {"energy": "0.012*mass+120*drag"}
  },
  "acceptance": "energy < 65"
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  fleet run fleet-study.json fleet-result.json
```

## 12. Predictive maintenance and RUL

The prognostic estimator performs centered, scaled, ridge-stabilized regression
of health against time and usage. This formulation remains solvable when time
and accumulated usage are strongly or perfectly correlated. It reports:

- current health;
- combined degradation rate per day;
- expected RUL;
- residual-based 95% RUL interval;
- conditional 30-day Weibull failure probability;
- service recommendation.

```json
{
  "history": [
    {"time_days": 0, "health_indicator": 1.0, "usage": 0},
    {"time_days": 30, "health_indicator": 0.97, "usage": 2500},
    {"time_days": 60, "health_indicator": 0.94, "usage": 5200}
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  maintenance estimate health-history.json maintenance-result.json 0.70
```

## 13. NVH simulation and analysis

The NVH analyzer computes:

- RMS, peak, crest factor, and kurtosis;
- Hann-windowed single-sided FFT spectrum;
- coherent-gain amplitude correction;
- dominant frequency;
- ranked spectral peaks;
- shaft orders when RPM is provided.

```json
{
  "sample_rate_hz": 1024,
  "shaft_speed_rpm": 1920,
  "samples": [0.0, 0.1, -0.1]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  nvh analyze waveform.json nvh-result.json 1024 1920
```

## 14. Model consistency and conservation checking

The checker validates:

- finite signal values;
- physical lower/upper bounds;
- storage-rate balance against named inflows and outflows;
- maximum residual per balance equation;
- timestamped issue records.

```json
{
  "bounds": [
    {"signal": "soc", "minimum": 0, "maximum": 1, "unit": "1"}
  ],
  "balances": [
    {
      "id": "energy",
      "inflows": ["power_in"],
      "outflows": ["power_out"],
      "storage": "stored_energy",
      "tolerance": 0.05,
      "unit": "W"
    }
  ]
}
```

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  consistency check consistency-model.json trace.json consistency-result.json
```

A detected inconsistency returns process status `1` while still producing the
complete machine-readable report.

## 15. Collaborative review and approval

Artifacts use immutable, hash-chained revisions. Repository mutations use a
cross-process lock with stale-lock recovery and optimistic expected-revision
checks. Supported states are draft, in review, approved, rejected, and
superseded.

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration create reviews REQ-001 jtmuzix content.json

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration revise reviews REQ-001 1 jtmuzix revised-content.json

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration comment reviews REQ-001 2 reviewer "Check cold-weather evidence"

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration submit reviews REQ-001 2 jtmuzix

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration decide reviews REQ-001 3 safety_manager approve "Evidence accepted"

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration latest reviews REQ-001

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration history reviews REQ-001

muzixdiagsys_engineering --credential-file credentials.txt \
  collaboration verify reviews REQ-001
```

## 16. Engineering knowledge graph

The graph stores typed nodes and directed, labeled edges. It supports:

- idempotent node upsert;
- validated edges between existing nodes;
- text/type search;
- downstream impact traversal;
- shortest directed paths;
- node removal with incident-edge cleanup;
- atomic JSON persistence.

```bash
muzixdiagsys_engineering --credential-file credentials.txt \
  graph upsert engineering-graph.json REQ-001 requirement "Stopping distance"

muzixdiagsys_engineering --credential-file credentials.txt \
  graph upsert engineering-graph.json TEST-001 test "Emergency braking"

muzixdiagsys_engineering --credential-file credentials.txt \
  graph edge engineering-graph.json TEST-001 REQ-001 verifies

muzixdiagsys_engineering --credential-file credentials.txt \
  graph search engineering-graph.json braking

muzixdiagsys_engineering --credential-file credentials.txt \
  graph impact engineering-graph.json TEST-001

muzixdiagsys_engineering --credential-file credentials.txt \
  graph path engineering-graph.json TEST-001 REQ-001
```

## Python API

```python
from pathlib import Path
from muzixdiag import Client

client = Client(
    "credentials.txt",
    database="users.json",
    executable="muzixdiagsys_engineering",
)

result = client.evaluate_requirements(
    {
        "requirements": [
            {
                "id": "REQ-SPEED",
                "mode": "always",
                "expression": "speed >= 0",
            }
        ]
    },
    {
        "samples": [
            {"time_s": 0.0, "signals": {"speed": 10.0}},
            {"time_s": 1.0, "signals": {"speed": 0.0}},
        ]
    },
    Path("requirements-result.json"),
)
assert result["passed"]
```

The Python API writes mapping/sequence arguments to temporary JSON files and
removes them after execution. Paths can be supplied directly for large studies.
Errors are surfaced as `MuzixDiagError`; permission enforcement and audit
recording remain in the executable rather than being bypassed in Python.

## C++ API

```cpp
#include "aesim/platform/validation_lifecycle.hpp"

using namespace aesim::platform;

RuntimeRequirementMonitor monitor;
monitor.add({"REQ-1", "Nonnegative speed", RequirementMode::Always,
             "speed >= 0", "", "", 0.0, "error", {}});
monitor.observe({0.0, {{"speed", 12.0}}});
monitor.observe({1.0, {{"speed", 0.0}}});
const auto results = monitor.finalize();
```

All APIs validate missing identifiers, invalid ranges, inconsistent sample
shapes, nonmonotonic time, unsupported modes, and nonfinite physical inputs.

## Reproducibility and audit behavior

For reproducible studies:

1. Store input files in a workspace.
2. Generate a sealed workspace manifest.
3. Use explicit seeds for UQ, fleet, calibration, and experiment studies.
4. Save outputs and add them as workspace resources.
5. Link requirements, tests, models, and reports in the knowledge graph.
6. Submit immutable artifacts for review.
7. Verify both the artifact chain and the global audit chain before release.

Every lifecycle command records actor, action, target, outcome, detail, session,
previous hash, and current hash in the tamper-evident audit log.

## Validation

The lifecycle implementation is covered by:

- `validation_lifecycle_unit_tests`: C++ coverage of every lifecycle domain,
  persistence, deterministic behavior, concurrent revision conflicts, and
  invalid physical states;
- `validation_python_api_regression`: authenticated end-to-end Python coverage
  through the production command executable;
- `authentication_unit_tests`: lifecycle RBAC checks for engineer, analyst, and
  auditor roles;
- the complete existing CTest suite, preserving simulator, terminal, plugin,
  diagnostics, vehicle, standards, and engineering-platform behavior.

Run focused tests:

```bash
ctest --test-dir build --output-on-failure \
  -R 'validation_lifecycle|validation_python_api|authentication'
```

Run all tests:

```bash
ctest --test-dir build --output-on-failure -j2
```

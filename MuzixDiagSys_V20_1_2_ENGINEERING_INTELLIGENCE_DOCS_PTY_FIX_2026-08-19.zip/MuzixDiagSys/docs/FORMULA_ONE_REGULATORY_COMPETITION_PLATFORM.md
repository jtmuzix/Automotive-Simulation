# Formula One Regulatory and Competition Platform

**Revision:** 2026-07-23  
**Public header:** `include/aesim/advanced/formula_one_regulatory_competition_platform.hpp`  
**Focused library:** `aesim_formula_one`  
**CLI family:** `f1-regulatory`

## Purpose

This platform adds ten Formula One-specific production systems for the 2026 electrical architecture, full-grid competition, championship governance, power-unit governance, operational restrictions, race-control evidence, pit-lane and parc ferme vision, regulatory case law, accident reconstruction, and Grade 1 circuit qualification.

The implementation is additive. Existing Formula One physics, race-engineering, performance, team, design, frontier, physical-operations, and championship-operations APIs remain available without source-level changes. `aesim_advanced` links `aesim_formula_one` publicly, so existing aggregate consumers retain access to the complete Formula One stack.

Every domain:

- rejects malformed, duplicate, non-finite, chronologically invalid, or physically impossible input;
- returns a canonical JSON-compatible `doc::Value` report;
- records explicit findings with identifiers, severity, subject, and measured value;
- produces a SHA-256 `evidence_digest` over the complete canonical report;
- optionally writes its report atomically to a caller-supplied working directory;
- is exercised by compiled positive, negative, deterministic, and boundary regressions.

## Public API

```cpp
#include "aesim/advanced/formula_one_regulatory_competition_platform.hpp"

using namespace aesim::advanced::f1reg;

FormulaOneRegulatoryCompetitionPlatform platform;
auto capabilities = platform.capabilities();
auto report = platform.execute("ers-electrical-hardware", request, "evidence/f1");
auto self_test = platform.self_test("evidence/f1-self-test");
```

Direct class entry points are also available:

| System | Public class | Method |
|---|---|---|
| 2026 ERS hardware, metering, and Overtake Mode | `F12026ErsElectrothermalLaboratory` | `evaluate` |
| 22-car full-field competition | `F1FullFieldCompetitionEngine` | `simulate` |
| Championship and Super-Licence governance | `F1ChampionshipGovernancePlatform` | `evaluate` |
| Power-unit homologation and supply | `F1PowerUnitHomologationPlatform` | `evaluate` |
| ATR, CFD, testing, and factory operations | `F1OperationalRestrictionsPlatform` | `evaluate` |
| FIA remote race-control fusion | `F1RemoteRaceControlFusionCenter` | `evaluate` |
| Pit-lane and parc ferme vision | `F1PitLaneVisionOfficiatingPlatform` | `evaluate` |
| Appeals, protests, directives, and precedent | `F1RegulatoryCaseLawCompiler` | `evaluate` |
| ADR and black-box accident reconstruction | `F1AccidentReconstructionLaboratory` | `reconstruct` |
| Grade 1 circuit homologation | `F1CircuitHomologationPlatform` | `evaluate` |

## CLI usage

```bash
./build/full/muzixdiagsys_advanced_platform f1-regulatory capabilities \
  build/f1-regulatory-capabilities.json

./build/full/muzixdiagsys_advanced_platform f1-regulatory self-test \
  build/f1-regulatory-self-test \
  build/f1-regulatory-self-test.json

./build/full/muzixdiagsys_advanced_platform f1-regulatory DOMAIN \
  REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Supported domains:

```text
ers-electrical-hardware
full-field-competition
championship-governance
power-unit-governance
operational-restrictions
remote-race-control
pit-lane-vision
regulatory-case-law
accident-reconstruction
circuit-homologation
```

Canonical requests are in `examples/formula_one_regulatory_competition/`.

## 1. 2026 ERS hardware, energy metering, and Overtake Mode

**Domain:** `ers-electrical-hardware`  
**Class:** `F12026ErsElectrothermalLaboratory`

The laboratory resolves the complete electrical path from the cell topology to MGU-K shaft delivery. Hardware inputs define cell series/parallel topology, capacity, voltage bounds, resistance, thermal capacity, cooling, current limits, MGU-K torque-speed envelope, MGU and inverter efficiency, DC resistance, component thermal limits, isolation threshold, and energy-meter bias/uncertainty.

Mission segments define duration, MGU speed, requested shaft power, available braking power, coolant and ambient temperature, isolation resistance, Straight Mode state, Overtake Mode state, proximity eligibility, and yellow-condition restriction.

The solver performs the following operations for every segment:

1. Validates Overtake Mode eligibility and yellow-condition restrictions.
2. Applies the speed-dependent MGU-K torque and power envelope.
3. Applies lap deployment and harvesting energy limits.
4. Solves the energy-store terminal-current quadratic rather than assuming nominal voltage.
5. Applies charge/discharge current, available-charge, and empty-capacity limits.
6. Recomputes DC power, shaft power, and torque after every limiting operation.
7. Integrates SOC and exact first-order cell, MGU, and inverter thermal states.
8. Accounts for pack resistance, inverter resistance/switching-equivalent losses, and MGU losses.
9. Compares true and reported electrical energy against declared meter uncertainty.
10. Emits isolation, illegal-mode, voltage, thermal, deploy-limit, harvest-limit, and metering findings.

Important outputs include `final_soc`, deployed and harvested energy, electrical loss, true and reported meter energy, meter uncertainty, peak current, peak shaft power, voltage extrema, thermal extrema, segment history, findings, and evidence digest.

## 2. Full-field 22-car, 11-team competition engine

**Domain:** `full-field-competition`  
**Class:** `F1FullFieldCompetitionEngine`

The engine requires exactly 22 unique cars, 22 unique drivers, and 11 unique teams with two cars per team. Each entrant defines baseline pace, skill, aggression, tire management, race-finish reliability, electrical-energy management, planned pit lap, pit loss, initial fuel, and initial electrical energy.

The deterministic lap loop includes:

- exact conversion of race-finish reliability into a per-lap failure probability;
- fuel burn, tire aging, tire-management effects, and traffic-independent pace variation;
- Overtake Mode usage and electrical-energy harvesting;
- planned and degradation-triggered pit stops;
- Safety Car, Virtual Safety Car, and red-flag states;
- incident probability, damage accumulation, and retirement;
- end-of-lap classification;
- pairwise green-flag overtake counting that excludes pit-cycle and retirement changes;
- Grand Prix or configurable Sprint points;
- driver and constructor scoring summaries;
- fixed-seed reproducibility through a platform-local deterministic RNG.

Outputs include complete classification, winner, fastest lap, overtakes, neutralization counts, points, lap summaries, and evidence digest.

## 3. Championship, points, entries, and Super-Licence governance

**Domain:** `championship-governance`  
**Class:** `F1ChampionshipGovernancePlatform`

The governance engine consumes driver credentials, race and Sprint classifications, configurable points tables, partial-points fractions, exclusions, disqualifications, bonus points, points deductions, and championship penalties.

It computes:

- driver and constructor points;
- classification eligibility;
- race and Sprint points;
- disqualification and points-deduction effects;
- race-start and finish records;
- win and countback statistics;
- deterministic championship tiebreaks by finishing-position counts and identifier;
- Super-Licence eligibility from age, possession state, and configurable points threshold;
- final driver and constructor champions;
- event-by-event audit records.

The points rules are data-driven so historical, current, or prospective profiles can be evaluated without code changes.

## 4. Power-unit homologation, supply, parity, and pool governance

**Domain:** `power-unit-governance`  
**Class:** `F1PowerUnitHomologationPlatform`

The platform models manufacturer registration, homologated specification identity, approved software versions, declared supply capacity, works/customer supply records, hardware and software parity, calibration release parity, serialized seasonal elements, seals, allocation limits, grid penalties, and controlled specification changes.

Implemented checks include:

- team supply against a registered manufacturer;
- manufacturer supply-capacity limits;
- hardware identity against the homologated baseline;
- software identity against the approved release set;
- works/customer equivalence across hardware, software, and calibration release;
- duplicate element serial rejection;
- allowed element types and configurable seasonal limits;
- per-driver excess-element grid-penalty calculation;
- change-request gating for reliability, safety, cost-saving, or supply-continuity reasons;
- rejection of incomplete evidence or expected performance-gain changes.

## 5. ATR, wind-tunnel, CFD, testing, and factory operations

**Domain:** `operational-restrictions`  
**Class:** `F1OperationalRestrictionsPlatform`

The operational compliance engine calculates championship-position-dependent ATR entitlement using a configurable factor table. It qualifies wind-tunnel runs, restricted CFD jobs, track-test categories, driver/circuit/instrumentation eligibility, mileage limits, and factory-shutdown observance.

Wind-tunnel checks include nominated facility, occupancy chronology, overlapping records, model scale, run count, and wind-on time. CFD checks include unique job identity, solver, geometry revision, declared Formula One purpose, and restricted compute usage. Track-test categories include TCC, TPC, TMC, tire, young-driver, filming, and demonstration profiles with configurable mileage limits. Factory activities are interval-tested against shutdown periods.

Outputs report allowed and used wind-on hours, run count, compute units, per-category mileage, findings, and evidence digest.

## 6. FIA remote operations and multimodal race-control fusion

**Domain:** `remote-race-control`  
**Class:** `F1RemoteRaceControlFusionCenter`

The fusion center combines video, telemetry, timing, radio, light-panel, marshal, and other evidence through a common observation contract. Every observation has a unique reference, incident identity, source, type, time, latency, confidence, source reliability, involved cars, and optional measured value.

The implementation:

- corrects observation time for source latency;
- groups evidence by incident;
- computes reliability-weighted incident type, event time, and car participation;
- measures synchronization spread;
- applies confidence review thresholds;
- maps incident types to configured rules and recommendations;
- prioritizes incidents by confidence and evidence density;
- calculates authenticated local, remote, and combined network availability;
- identifies the primary control mode;
- creates a SHA-256 chained decision audit log.

Recommendations remain decision support. The system intentionally does not replace human official authority.

## 7. Pit-lane and parc ferme computer-vision officiating

**Domain:** `pit-lane-vision`  
**Class:** `F1PitLaneVisionOfficiatingPlatform`

The platform validates car identity, non-overlapping pit-box geometry, speed limits, line crossings, release gaps, wheel control, wheel-nut retention, car movement before wheel completion, crew placement, equipment obstruction, pit-box use, adjacent-box interference, authorized parc ferme work, like-for-like replacement, and access windows.

Observations are sorted globally and temporally coalesced only when car, violation type, and interval proximity agree. Evidence references are deduplicated. The final violation list is chronological and contains start/end times, confidence, car identity, violation type, and evidence references.

## 8. Appeals, protests, technical directives, and precedent compiler

**Domain:** `regulatory-case-law`  
**Class:** `F1RegulatoryCaseLawCompiler`

The compiler versions rules and directives by identity, jurisdiction, effective time, supersession, repeal state, and tags. Precedents contain jurisdiction, decision time, tags, outcome, and penalty units. Filings support protest, right-of-review, and appeal procedures.

Implemented procedural gates include:

- unique filing identity;
- valid rule and jurisdiction;
- effective and non-repealed rule version;
- standing;
- filing deadline;
- fee payment;
- evidence admissibility;
- the new, significant, and relevant evidence test for right-of-review filings;
- request for a stay of penalty;
- Jaccard tag similarity against earlier precedents in the same jurisdiction;
- deterministic best-precedent selection;
- recommended outcome and penalty units.

## 9. Accident reconstruction, ADR, and black-box forensics

**Domain:** `accident-reconstruction`  
**Class:** `F1AccidentReconstructionLaboratory`

The laboratory ingests serialized vehicle masses, strictly time-ordered telemetry, optional camera-derived positions, and one or more vehicle/barrier contacts. It performs circular heading interpolation, position fusion that does not dilute telemetry speed or acceleration, contact-normal projection, relative closing-speed reconstruction, reduced-mass impulse calculation, delta-V, dissipated energy, barrier deformation, peak acceleration, HIC15 estimate, neck-load estimate, and uncertainty bounds.

Outputs include complete reconstructed trajectories, contact-pair identity, event time, relative speed and angle, impulse, delta-V, energy, deformation, injury-related estimates, uncertainty interval, threshold findings, and evidence digest.

The outputs support engineering investigation; they are not medical diagnoses or legal determinations.

## 10. Grade 1 circuit homologation and safety design

**Domain:** `circuit-homologation`  
**Class:** `F1CircuitHomologationPlatform`

Each circuit segment defines length, radius, width, friction, gradient, crossfall, runoff, runoff deceleration, barrier type and angle, sight distance, drainage capacity, and design rainfall. A reference car defines mass, downforce coefficient, and frontal area.

The platform computes:

- aero-assisted design speed;
- segment kinetic energy;
- energy-based required runoff;
- reaction-and-braking sight distance;
- width compliance;
- barrier-angle compliance;
- drainage margin;
- pit-lane width, fast-lane width, entry, and exit geometry;
- circular marshal-post spacing;
- medical response, medical-center, and helicopter readiness;
- light-panel visibility and redundant power;
- Grade 1 eligibility and certificate status.

An unsafe design returns `certificate_status: withheld`; it never selects a nominal grade merely because the calculation completed.

## Focused build and validation

```bash
cmake -S . -B build/f1-regulatory -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON

cmake --build build/f1-regulatory --parallel --target \
  aesim_formula_one \
  formula_one_regulatory_competition_platform_tests

ctest --test-dir build/f1-regulatory --output-on-failure \
  -R '^formula_one_.*_unit_tests$'

python3 tests/formula_one_regulatory_competition_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```

Sanitizer validation may be performed through the project option or by instrumenting the three new production translation units and compiled test with AddressSanitizer and UndefinedBehaviorSanitizer.

## Qualification boundaries

This platform is an engineering, rules-development, training, and evidence-organization system. It does not grant FIA homologation, issue a Super Licence, authorize an Overtake Mode activation, impose a sporting penalty, certify an energy meter, approve a power-unit change, certify a circuit, or replace officials, stewards, medical professionals, accredited metrology, or formal legal proceedings.

Regulatory thresholds and procedures are deliberately configurable. Before using an output for a real program, bind the request to the applicable regulation issue, event notes, technical directives, measurement procedures, track certificate, and official decisions. Preserve the request, executable identity, source revision, result, and evidence digest together.

## Motorsport CLI convenience aliases

The original `f1-regulatory` family remains authoritative. Additive suite routing is available through `f1 run regulatory DOMAIN ...`; shortcuts include `f1-race`, `f1-ers`, and `f1-race-control`. See `MOTORSPORT_CLI_COMMANDS.md`.

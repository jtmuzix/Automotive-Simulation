# MuzixDiagSys Perception, ODD, Digital-Twin, and Real-World Measurement Extension
## Implementation and Validation Report

**Release date:** 2026-07-11  
**Base release:** Coupled and advanced vehicle realism release  
**Validation build:** `/mnt/data/aesim_stage4_build`  
**Registered tests:** 75  
**Result:** 75 passed, 0 failed

## 1. Scope

This release preserves every existing MuzixDiagSys feature and extends the same live vehicle plant with physical steering, multidimensional aerodynamics, material-dependent road and sensor behavior, camera/radar/lidar/ultrasonic sensing, OSI/OSMP exchange, OpenODD scenario generation, sensor fusion/localization, bounded digital-twin estimation, non-exhaust particulate emissions, and virtual PEMS measurement.

The implementation is additive. It reuses the existing:

- Six-degree-of-freedom body and four-corner suspension plant.
- Combined-slip thermal tire and compliant driveline states.
- OpenDRIVE, OpenCRG, and OpenSCENARIO runtime.
- OSI world representation.
- Production-style ECU scheduler.
- Progressive degradation model.
- Typed industrial signal registry.
- XCP/A2L calibration and measurement interface.
- MDF 4.10 recorder and validator.
- Multi-experiment Bayesian calibration.

No parallel demonstration-only plant or duplicate measurement registry was introduced.

## 2. Physical steering and suspension kinematics

`PhysicalSteeringSystem` models:

- Steering-wheel inertia and angular rate.
- Column torsional stiffness and damping.
- Rack mass, damping, travel, and Coulomb friction.
- Speed-dependent electric power-steering assist.
- Caster-trail self-aligning torque.
- Lateral-force-dependent compliance steer.
- Ackermann inside/outside wheel geometry.
- Steering-angle and rack-travel saturation.

The live plant receives independent left and right front-wheel angles. The direct `industrial vehicle sixdof step` command uses the identical steering path.

Commands:

```text
industrial vehicle steering status
industrial vehicle steering reset
industrial vehicle steering step <seconds> [command_-1..1]
```

Writable XCP/A2L calibrations include steering ratio, steering bias, and EPS peak assist.

## 3. Aerodynamic coefficient maps

`AerodynamicCoefficientMap` stores and interpolates a complete five-dimensional coefficient grid indexed by:

1. Relative airspeed.
2. Aerodynamic yaw angle.
3. Body pitch angle.
4. Front ride height.
5. Rear ride height.

Map outputs include drag, side force, front/rear lift, yaw moment, pitch moment, and cooling-flow factor. Import requires a complete, finite rectangular grid. Export uses round-trip-safe numeric precision.

Commands:

```text
industrial vehicle aero status
industrial vehicle aero reset
industrial vehicle aero load <map.csv>
industrial vehicle aero export <map.csv>
industrial vehicle aero sample <speed_m_s> <yaw_rad> <pitch_rad> <front_ride_m> <rear_ride_m>
```

The coefficients apply forces and moments to the live six-DOF body. The digital-twin aero scale and writable XCP aero calibration are applied transactionally.

## 4. OpenMATERIAL-derived surface properties

`OpenMaterialSurfaceRepository` provides bounded material profiles with:

- Dry and wet friction.
- Rolling resistance.
- Surface roughness.
- Camera reflectance.
- Lidar reflectivity.
- Radar reflectivity.
- Ultrasonic reflectivity.
- Infrared emissivity.
- Thermal conductivity.
- Water retention.
- Brake-dust retention.

Road and object classifications can be assigned independently. Wet friction interpolates from dry to wet values according to rain intensity. Rolling resistance enters each wheel's force balance and tire heat generation; it is not report-only metadata.

Commands:

```text
industrial vehicle material status
industrial vehicle material load <openmaterial.yaml|json>
industrial vehicle material reset
industrial vehicle material assign-road <road-id> <material-id>
industrial vehicle material assign-object <classification> <material-id>
industrial vehicle material export <json>
```

The supplied example is `data/vehicle_openmaterial.json`.

## 5. Camera, radar, lidar, and ultrasonic sensors

`PerceptionSensorSuite` supports independently configured sensor definitions with:

- Position and orientation.
- Horizontal and vertical fields of view.
- Minimum and maximum range.
- Update period.
- Delivery latency.
- Range, angle, and radial-velocity uncertainty.
- Dropout probability.
- False-positive rate.
- Visibility and rain sensitivity.
- Material-dependent response.
- Occlusion state.
- Deterministic seeded random behavior.
- Bounded pending-frame queues.

Default sensors are a front camera, front radar, roof lidar, and front ultrasonic sensor. Ground truth, delivered sensor frames, and fused state estimates remain distinct.

Commands:

```text
industrial vehicle sensor status
industrial vehicle sensor defaults [seed]
industrial vehicle sensor clear
industrial vehicle sensor reset [seed]
industrial vehicle sensor step <seconds> [visibility_m] [rain_0..1]
industrial vehicle sensor export <json>
```

The writable `vehicle6dof.cal.sensor_noise_scale` calibration modifies live sensor uncertainty. Progressive sensor degradation increases effective uncertainty without mutating nominal definitions.

## 6. OSI and OSMP sensor interfaces

The existing OSI ground-truth world remains authoritative for actors, host pose, geometry, classification, and velocity. The advanced six-DOF host state is synchronized into that world before sensor evaluation.

`OsmpSensorInterface` serializes delivered sensor frames into a bounded binary engineering envelope containing:

- `OSMP` magic.
- Interface version.
- Payload length.
- CRC-32.
- Structured sensor-frame document.

Imports reject invalid magic, unsupported versions, unsafe lengths, malformed payloads, and CRC mismatches.

Commands:

```text
industrial vehicle osi status
industrial vehicle osi export <file>
industrial vehicle osi import <file>
industrial vehicle osmp status
industrial vehicle osmp export <file>
industrial vehicle osmp import <file>
```

The OSMP file is a validated MuzixDiagSys engineering envelope for deterministic exchange. It is not presented as unrestricted certification of every external OSMP/FMI packaging profile.

## 7. OpenODD-driven scenario generation

`OpenOddScenarioGenerator` loads bounded YAML or JSON ODD definitions containing numeric and categorical dimensions. Generation supports:

- Deterministic seeds.
- Interior samples.
- Explicit minimum/maximum boundary cases.
- Numeric and categorical coverage summaries.
- Generated OpenSCENARIO XML files.
- JSON manifest with parameters, coverage, seed, and file names.
- Optional road context from the active OpenDRIVE map.

Commands:

```text
industrial vehicle odd status
industrial vehicle odd load <odd.yaml|json>
industrial vehicle odd generate <directory> <count> [seed]
```

Generated cases are immediately consumable by the existing OpenSCENARIO runtime.

## 8. Sensor fusion and localization

`SensorFusionLocalization` separates estimated state from truth and provides:

- Acceleration/yaw-rate prediction.
- GNSS position correction.
- Wheel-speed correction.
- Heading correction.
- Position, velocity, and yaw uncertainty.
- Innovation magnitude.
- Multisensor object-track association.
- Track age and time-since-update.
- Sensor-contribution accounting.
- Stale-track removal.

Commands:

```text
industrial vehicle fusion status
industrial vehicle fusion reset
industrial vehicle fusion predict <dt> <ax> <ay> <yaw_rate>
industrial vehicle fusion gnss <x_m> <y_m> <sigma_m>
industrial vehicle fusion wheel <speed_m_s> <sigma_m_s>
industrial vehicle fusion heading <yaw_rad> <sigma_rad>
industrial vehicle fusion step <seconds>
```

The live integration path predicts from body acceleration and yaw rate, applies bounded GNSS/wheel/heading updates, and fuses the delivered perception frame.

## 9. Digital-twin state estimation

`DigitalTwinEstimator` estimates bounded corrections for:

- Sprung-mass scale.
- Aerodynamic coefficient scale.
- Tire-friction scale.
- Steering bias.
- Longitudinal velocity bias.

It reports observation count and position, velocity, and yaw RMSE. Applied corrections are transactional and reversible. Restore returns exactly to the captured nominal calibration values.

Commands:

```text
industrial vehicle twin status
industrial vehicle twin reset
industrial vehicle twin load <measurement.csv>
industrial vehicle twin run
industrial vehicle twin apply
industrial vehicle twin restore
industrial vehicle twin export <json>
```

## 10. Brake, tire, and road-dust particulate emissions

`NonExhaustParticulateModel` calculates separate mass rates and cumulative mass for:

- Brake PM10 and PM2.5.
- Tire PM10 and PM2.5.
- Resuspended road-dust PM10.

Inputs include per-wheel brake power, slip power, normal load, road wetness, roughness, surface retention, brake-pad loss, and tread loss. The model also maintains per-rotor temperature and cooling.

Commands:

```text
industrial vehicle nonexhaust status
industrial vehicle nonexhaust reset
industrial vehicle nonexhaust export <csv>
```

Non-exhaust particulate mass is deliberately separate from tailpipe PEMS PM.

## 11. Virtual PEMS measurement

`VirtualPemsInstrument` models the measurement chain rather than exposing perfect tailpipe truth. It includes:

- Configurable sample period.
- Sample-line transport delay.
- First-order analyzer response.
- GPS delay.
- Relative analyzer noise.
- Exhaust-flow uncertainty.
- Seeded repeatability.
- Zero-offset calibration.
- Bounded recording state.
- CSV export.

Measured channels include time, position, speed, exhaust mass flow, CO2, CO, HC, NOx, and exhaust PM.

Commands:

```text
industrial vehicle pems status
industrial vehicle pems configure <sample_s> <line_delay_s> <tau_s> <gps_delay_s> <noise_sigma> <flow_uncertainty> [seed]
industrial vehicle pems start
industrial vehicle pems stop
industrial vehicle pems reset
industrial vehicle pems zero
industrial vehicle pems export <csv>
```

## 12. XCP/A2L and MDF integration

All new measurements and writable calibrations use the shared typed signal registry. As a result, the existing XCP service and A2L generator can access the advanced plant without a secondary address space.

Representative measurements:

```text
vehicle6dof.steering.wheel_angle_rad
vehicle6dof.aero.cd
vehicle6dof.perception.detections
vehicle6dof.localization.x_m
vehicle6dof.twin.mass_scale
emissions.nonexhaust.brake_pm10_g_s
emissions.pems.nox_g_s
```

Representative calibrations:

```text
vehicle6dof.cal.steering_ratio
vehicle6dof.cal.steering_bias_rad
vehicle6dof.cal.eps_peak_assist_nm
vehicle6dof.cal.aero_scale
vehicle6dof.cal.sensor_noise_scale
vehicle6dof.cal.pems_noise_sigma
```

The existing MDF 4.10 recorder logs these signals and validates the generated measurement file.

## 13. Previously implemented systems retained

The release retains and validates:

- Six-degree-of-freedom body dynamics.
- Full four-corner suspension and unsprung masses.
- Combined-slip thermal tires.
- Detailed differential and compliant driveline.
- OpenDRIVE and OpenCRG ingestion.
- OpenSCENARIO traffic and maneuver execution.
- Production-style discrete ECU scheduling.
- XCP/A2L calibration access.
- MDF logging.
- Multi-experiment Bayesian calibration.
- Progressive component degradation and selective servicing.

## 14. Error handling and numerical safeguards

The new implementation enforces:

- Finite-value validation at public numerical interfaces.
- Safe ranges for FOV, range, latency, periods, uncertainties, probabilities, and map dimensions.
- Complete rectangular aerodynamic grids.
- Round-trip-safe map export precision.
- Bounded sensor frame queues and OSMP payloads.
- CRC validation on binary imports.
- Bounded ODD case counts and deterministic seeds.
- Material-reference validation.
- Measurement-signal initialization inside declared ranges.
- Reversible digital-twin calibration application.
- Separate tailpipe and non-exhaust particulate accounting.
- Direct-command and live-integration path parity.

## 15. Automated validation

The final build registers 75 CTest targets. The complete serial suite result was:

```text
75/75 tests passed
0 failures
Total test time: 429.39 seconds
```

Dedicated new coverage verifies:

- Ackermann steering and finite steering dynamics.
- Five-dimensional aerodynamic-map interpolation and exact CSV round-trip.
- Wet-material friction behavior.
- Material rolling resistance in the six-DOF coastdown force balance.
- Deterministic physical radar detection.
- OSMP encode/decode and CRC corruption rejection.
- Localization uncertainty reduction and object-track creation.
- Digital-twin apply/restore behavior.
- OpenODD boundary generation and OpenSCENARIO ingestion.
- Brake/tire particulate accumulation.
- PEMS delay/analyzer response and CSV export.
- Shared signal publication.
- Complete CLI workflow through OpenDRIVE, OpenCRG, OpenSCENARIO, OpenMATERIAL, perception, OSMP, ODD, fusion, digital twin, PEMS, A2L, and MDF.

The broader suite also covers the existing regulatory cycles, physics ledger, calibration/UQ, automatic-transmission anti-hunting, dashboard/PTTY behavior, completion scrolling, terminal fuzzing, plugins, FMI, federation, API, industrial, professional, research, assurance, frontier, vehicle, electrification, command documentation, and non-finite input rejection.

## 16. Documentation and artifacts

Updated documentation includes:

- `README.md`
- `docs/ADVANCED_VEHICLE_REALISM.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`
- Current `--advanced-help` output and completion paths

The PDF manual was regenerated as a 90-page, letter-size, searchable technical document using embedded DejaVu fonts. All 90 pages were rendered for verification. The PDF contains no replacement glyphs and no detected text blocks outside the page boundary.

## 17. Completion statement

The requested systems are implemented as live, coupled, test-covered functionality. No existing command family or simulator subsystem was removed. The newly added source and test files contain no TODO, TBD, placeholder, stub, or unimplemented markers.

## 2026-07-12 next-generation vehicle-depth integration

Perception and digital-twin studies can now include sensor-pose error from flexible structures, spatial surface variation, timing-induced control delay, and counterfactual replay branches.

The authoritative design, equations, public API, command reference, signal namespace, calibration requirements, and coupling order are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_IMPLEMENTATION.md). Validation criteria and reproducibility requirements are documented in [`NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md`](NEXT_GENERATION_VEHICLE_DEPTH_VALIDATION.md).

Compatibility commitments:

- Existing public commands, presets, signals, plugins, FMU paths, federation services, and model APIs remain available.
- The new runtime is additive and is selected through `industrial energy depth`.
- Deterministic replay uses the same coupled execution path as normal advancement.
- Fidelity transitions retain physical state and publish explicit energy, mass, charge, and momentum corrections.
- Vehicle-specific correlation requires measured calibration data; default parameters are bounded engineering defaults.

---

## 2026-07-12 Vehicle Ecosystem Extension

This document remains applicable. The production simulator has additionally been extended with a fully coupled vehicle–occupant–environment ecosystem while preserving the behavior and interfaces described above.

The extension adds:

- A conservative one-dimensional thermo-fluid network for gas, liquid, refrigerant, fuel, lubricant, coolant, hydrogen, and brake-fluid paths.
- Cranktrain torsion, valvetrain dynamics, and elastohydrodynamic main-bearing behavior.
- Injector hydraulics, spray droplets, wall films, crank-angle combustion, and engine-out emissions formation.
- Full transmission, clutch, torque-converter, CVT, planetary, hybrid, e-axle, and transfer-case physics.
- Particle-scale battery diffusion, aging, lithium plating, gas generation, venting, internal shorts, and thermal propagation.
- Raw FMCW radar I/Q, Bayer camera pixels, and lidar waveform/return simulation.
- Human driver, HMI, attention, fatigue, takeover, and minimum-risk-maneuver behavior.
- Closed-loop traffic agents, infrastructure, V2X communication, and formal ODD assessment.
- Mechanism-based fatigue, wear, crack growth, prognostics, and remaining-useful-life estimation.
- FMI 3.0/OpenDRIVE/OpenSCENARIO/ODD/OSI/OpenLABEL exchange and Offline/SIL/PIL/HIL execution.

The operational command family is `industrial energy ecosystem`. The public C++ entry point is `aesim::high_fidelity::IntegratedVehicleEcosystemRuntime`, declared in `include/aesim/high_fidelity/ecosystem.hpp`.

See [VEHICLE_ECOSYSTEM_IMPLEMENTATION.md](VEHICLE_ECOSYSTEM_IMPLEMENTATION.md) for equations, APIs, coupling order, commands, signals, and calibration requirements. See [VEHICLE_ECOSYSTEM_VALIDATION.md](VEHICLE_ECOSYSTEM_VALIDATION.md) for verification scope and correlation requirements.


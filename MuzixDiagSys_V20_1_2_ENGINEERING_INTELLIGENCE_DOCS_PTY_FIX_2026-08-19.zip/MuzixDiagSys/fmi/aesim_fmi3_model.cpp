#include "fmi3/fmi3Functions.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <new>
#include <string>

namespace {
constexpr const char* kInstantiationToken = "{69212d8c-184b-4d75-a875-a9db8a9e4f3c}";
constexpr std::array<std::uint8_t, 8> kStateMagic{{'A', 'E', 'S', 'F', '3', 'S', 'T', '1'}};
constexpr std::size_t kSerializedDoubleCount = 13;
constexpr std::size_t kSerializedStateSize = kStateMagic.size() + kSerializedDoubleCount * 8 + 2;

enum class Kind : std::uint8_t { ModelExchange = 0, CoSimulation = 1, ScheduledExecution = 2 };
enum ValueReference : std::uint32_t {
    Time = 1,
    Throttle = 2,
    LoadTorque = 3,
    AmbientPressure = 4,
    AmbientTemperature = 5,
    Rpm = 10,
    Torque = 11,
    Speed = 12,
    ManifoldPressure = 13,
    Lambda = 14,
    TurboSpeed = 15,
    FuelFlow = 16,
    RpmDerivative = 20,
    SpeedDerivative = 21,
    ManifoldPressureDerivative = 22,
    TurboSpeedDerivative = 23,
    ControllerClock = 100,
    PlantClock = 101
};

struct State {
    double time = 0.0;
    double throttle = 0.0;
    double load = 0.0;
    double ambient_pressure = 101325.0;
    double ambient_temperature = 298.15;
    double rpm = 800.0;
    double torque = 0.0;
    double speed = 0.0;
    double manifold_pressure = 101325.0;
    double lambda = 1.0;
    double turbo_speed = 30000.0;
    double fuel_flow = 0.0;
    double throttle_command = 0.0;
    bool initialized = false;
    Kind kind = Kind::CoSimulation;
};

struct Instance {
    State state;
    fmi3InstanceEnvironment environment = nullptr;
    fmi3LogMessageCallback logger = nullptr;
    fmi3ClockUpdateCallback clock_update = nullptr;
};

Instance* cast(fmi3Instance instance) {
    return static_cast<Instance*>(instance);
}

void log_message(Instance* instance, fmi3Status status, const char* category,
                 const std::string& message) {
    if (instance && instance->logger) {
        instance->logger(instance->environment, status, category, message.c_str());
    }
}

bool valid_token(fmi3String token) {
    return token && std::strcmp(token, kInstantiationToken) == 0;
}

Instance* create_instance(Kind kind, fmi3String token,
                          fmi3InstanceEnvironment environment,
                          fmi3LogMessageCallback logger) {
    if (!valid_token(token)) return nullptr;
    try {
        auto* instance = new Instance{};
        instance->state.kind = kind;
        instance->environment = environment;
        instance->logger = logger;
        return instance;
    } catch (...) {
        return nullptr;
    }
}

void calculate_derivatives(const State& state, double derivatives[4]) {
    const double target_map = state.ambient_pressure + 80000.0 * state.throttle;
    const double pressure_driven_flow =
        std::max(0.0, (target_map - state.manifold_pressure) * 1.2e-5);
    const double target_turbo_speed = 30000.0 + 150000.0 * state.throttle;
    const double speed_derating =
        1.0 - std::max(0.0, state.rpm - 6500.0) / 8000.0;
    const double indicated_torque =
        std::max(0.0, 430.0 * state.throttle *
                          (state.manifold_pressure / std::max(1.0, state.ambient_pressure)) *
                          speed_derating);

    derivatives[0] =
        (indicated_torque - state.load - 0.018 * (state.rpm - 800.0)) / 0.16;
    derivatives[1] = std::max(0.0, indicated_torque - state.load) * 0.012 -
                     state.speed * 0.65;
    derivatives[2] = (target_map - state.manifold_pressure) / 0.055 +
                     pressure_driven_flow * 1000.0;
    derivatives[3] = (target_turbo_speed - state.turbo_speed) / 0.10;
}

void update_outputs(State& state) {
    const double speed_derating =
        1.0 - std::max(0.0, state.rpm - 6500.0) / 8000.0;
    state.torque = std::max(
        0.0, 430.0 * state.throttle *
                 (state.manifold_pressure / std::max(1.0, state.ambient_pressure)) *
                 speed_derating);
    state.lambda = std::clamp(
        1.02 - 0.16 * state.throttle +
            0.000001 * (state.manifold_pressure - state.ambient_pressure),
        0.72, 1.25);
    state.fuel_flow = std::max(
        0.0, state.torque * std::max(800.0, state.rpm) *
                 2.0 * 3.14159265358979323846 / 60.0 / (0.34 * 43.0e6));
}

void integrate(State& state, double interval) {
    interval = std::clamp(interval, 1.0e-7, 0.1);
    constexpr double maximum_step = 0.001;
    const double ratio = interval / maximum_step;
    const double boundary_tolerance =
        64.0 * std::numeric_limits<double>::epsilon() * std::max(1.0, std::abs(ratio));
    const int substeps =
        std::max(1, static_cast<int>(std::ceil(ratio - boundary_tolerance)));
    const double step = interval / static_cast<double>(substeps);
    for (int index = 0; index < substeps; ++index) {
        double derivative[4]{};
        calculate_derivatives(state, derivative);
        state.rpm = std::max(0.0, state.rpm + derivative[0] * step);
        state.speed = std::max(0.0, state.speed + derivative[1] * step);
        state.manifold_pressure =
            std::max(1000.0, state.manifold_pressure + derivative[2] * step);
        state.turbo_speed = std::max(0.0, state.turbo_speed + derivative[3] * step);
        state.time += step;
        update_outputs(state);
    }
}

void write_u64(std::uint8_t* destination, std::uint64_t value) {
    for (unsigned index = 0; index < 8; ++index) {
        destination[index] = static_cast<std::uint8_t>((value >> (index * 8U)) & 0xffU);
    }
}

std::uint64_t read_u64(const std::uint8_t* source) {
    std::uint64_t value = 0;
    for (unsigned index = 0; index < 8; ++index) {
        value |= static_cast<std::uint64_t>(source[index]) << (index * 8U);
    }
    return value;
}

void write_double(std::uint8_t* destination, double value) {
    static_assert(sizeof(double) == sizeof(std::uint64_t));
    std::uint64_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    write_u64(destination, bits);
}

double read_double(const std::uint8_t* source) {
    const std::uint64_t bits = read_u64(source);
    double value = 0.0;
    std::memcpy(&value, &bits, sizeof(value));
    return value;
}

std::array<double, kSerializedDoubleCount> state_doubles(const State& state) {
    return {state.time,
            state.throttle,
            state.load,
            state.ambient_pressure,
            state.ambient_temperature,
            state.rpm,
            state.torque,
            state.speed,
            state.manifold_pressure,
            state.lambda,
            state.turbo_speed,
            state.fuel_flow,
            state.throttle_command};
}

bool assign_state_doubles(State& state,
                          const std::array<double, kSerializedDoubleCount>& values) {
    for (const double value : values) {
        if (!std::isfinite(value)) return false;
    }
    state.time = values[0];
    state.throttle = values[1];
    state.load = values[2];
    state.ambient_pressure = values[3];
    state.ambient_temperature = values[4];
    state.rpm = values[5];
    state.torque = values[6];
    state.speed = values[7];
    state.manifold_pressure = values[8];
    state.lambda = values[9];
    state.turbo_speed = values[10];
    state.fuel_flow = values[11];
    state.throttle_command = values[12];
    return true;
}

} // namespace

extern "C" const char* fmi3GetVersion() { return "3.0.2"; }

extern "C" fmi3Status fmi3SetDebugLogging(fmi3Instance instance, fmi3Boolean,
                                            size_t, const fmi3String[]) {
    return instance ? fmi3OK : fmi3Error;
}

extern "C" fmi3Instance fmi3InstantiateModelExchange(
    fmi3String, fmi3String token, fmi3String, fmi3Boolean, fmi3Boolean,
    fmi3InstanceEnvironment environment, fmi3LogMessageCallback logger) {
    return create_instance(Kind::ModelExchange, token, environment, logger);
}

extern "C" fmi3Instance fmi3InstantiateCoSimulation(
    fmi3String, fmi3String token, fmi3String, fmi3Boolean, fmi3Boolean,
    fmi3Boolean, fmi3Boolean, const fmi3ValueReference[], size_t,
    fmi3InstanceEnvironment environment, fmi3LogMessageCallback logger,
    fmi3IntermediateUpdateCallback) {
    return create_instance(Kind::CoSimulation, token, environment, logger);
}

extern "C" fmi3Instance fmi3InstantiateScheduledExecution(
    fmi3String, fmi3String token, fmi3String, fmi3Boolean, fmi3Boolean,
    fmi3InstanceEnvironment environment, fmi3LogMessageCallback logger,
    fmi3ClockUpdateCallback clock_update, fmi3LockPreemptionCallback,
    fmi3UnlockPreemptionCallback) {
    auto* instance = create_instance(Kind::ScheduledExecution, token, environment, logger);
    if (instance) instance->clock_update = clock_update;
    return instance;
}

extern "C" void fmi3FreeInstance(fmi3Instance instance) { delete cast(instance); }

extern "C" fmi3Status fmi3EnterInitializationMode(
    fmi3Instance instance, fmi3Boolean, fmi3Float64, fmi3Float64 start_time,
    fmi3Boolean, fmi3Float64) {
    if (!instance || !std::isfinite(start_time)) return fmi3Error;
    cast(instance)->state.time = start_time;
    return fmi3OK;
}

extern "C" fmi3Status fmi3ExitInitializationMode(fmi3Instance instance) {
    if (!instance) return fmi3Error;
    cast(instance)->state.initialized = true;
    update_outputs(cast(instance)->state);
    return fmi3OK;
}

extern "C" fmi3Status fmi3EnterEventMode(fmi3Instance instance) {
    return instance ? fmi3OK : fmi3Error;
}

extern "C" fmi3Status fmi3Terminate(fmi3Instance instance) {
    if (!instance) return fmi3Error;
    cast(instance)->state.initialized = false;
    return fmi3OK;
}

extern "C" fmi3Status fmi3Reset(fmi3Instance instance) {
    if (!instance) return fmi3Error;
    const Kind kind = cast(instance)->state.kind;
    cast(instance)->state = State{};
    cast(instance)->state.kind = kind;
    return fmi3OK;
}

extern "C" fmi3Status fmi3GetFloat64(
    fmi3Instance instance, const fmi3ValueReference references[], size_t count,
    fmi3Float64 values[], size_t value_count) {
    if (!instance || !references || !values || value_count < count) return fmi3Error;
    auto& state = cast(instance)->state;
    double derivative[4]{};
    calculate_derivatives(state, derivative);
    for (size_t index = 0; index < count; ++index) {
        switch (references[index]) {
            case Time: values[index] = state.time; break;
            case Throttle: values[index] = state.throttle_command; break;
            case LoadTorque: values[index] = state.load; break;
            case AmbientPressure: values[index] = state.ambient_pressure; break;
            case AmbientTemperature: values[index] = state.ambient_temperature; break;
            case Rpm: values[index] = state.rpm; break;
            case Torque: values[index] = state.torque; break;
            case Speed: values[index] = state.speed; break;
            case ManifoldPressure: values[index] = state.manifold_pressure; break;
            case Lambda: values[index] = state.lambda; break;
            case TurboSpeed: values[index] = state.turbo_speed; break;
            case FuelFlow: values[index] = state.fuel_flow; break;
            case RpmDerivative: values[index] = derivative[0]; break;
            case SpeedDerivative: values[index] = derivative[1]; break;
            case ManifoldPressureDerivative: values[index] = derivative[2]; break;
            case TurboSpeedDerivative: values[index] = derivative[3]; break;
            default: return fmi3Error;
        }
    }
    return fmi3OK;
}

extern "C" fmi3Status fmi3SetFloat64(
    fmi3Instance instance, const fmi3ValueReference references[], size_t count,
    const fmi3Float64 values[], size_t value_count) {
    if (!instance || !references || !values || value_count < count) return fmi3Error;
    auto& state = cast(instance)->state;
    for (size_t index = 0; index < count; ++index) {
        if (!std::isfinite(values[index])) return fmi3Error;
        switch (references[index]) {
            case Throttle:
                state.throttle_command = std::clamp(values[index], 0.0, 1.0);
                if (state.kind != Kind::ScheduledExecution) state.throttle = state.throttle_command;
                break;
            case LoadTorque: state.load = std::max(0.0, values[index]); break;
            case AmbientPressure:
                state.ambient_pressure = std::max(1000.0, values[index]);
                break;
            case AmbientTemperature:
                state.ambient_temperature = std::max(1.0, values[index]);
                break;
            case Rpm: state.rpm = std::max(0.0, values[index]); break;
            case Speed: state.speed = std::max(0.0, values[index]); break;
            case ManifoldPressure:
                state.manifold_pressure = std::max(1000.0, values[index]);
                break;
            default: return fmi3Error;
        }
    }
    update_outputs(state);
    return fmi3OK;
}

extern "C" fmi3Status fmi3GetInt32(fmi3Instance, const fmi3ValueReference[],
                                     size_t, fmi3Int32[], size_t) {
    return fmi3Error;
}
extern "C" fmi3Status fmi3SetInt32(fmi3Instance, const fmi3ValueReference[],
                                     size_t, const fmi3Int32[], size_t) {
    return fmi3Error;
}
extern "C" fmi3Status fmi3GetBoolean(fmi3Instance, const fmi3ValueReference[],
                                      size_t, fmi3Boolean[], size_t) {
    return fmi3Error;
}
extern "C" fmi3Status fmi3SetBoolean(fmi3Instance, const fmi3ValueReference[],
                                      size_t, const fmi3Boolean[], size_t) {
    return fmi3Error;
}

extern "C" fmi3Status fmi3GetFMUState(fmi3Instance instance, fmi3FMUState* state) {
    if (!instance || !state) return fmi3Error;
    try {
        *state = new State(cast(instance)->state);
        return fmi3OK;
    } catch (...) {
        return fmi3Error;
    }
}

extern "C" fmi3Status fmi3SetFMUState(fmi3Instance instance, fmi3FMUState state) {
    if (!instance || !state) return fmi3Error;
    cast(instance)->state = *static_cast<State*>(state);
    return fmi3OK;
}

extern "C" fmi3Status fmi3FreeFMUState(fmi3Instance, fmi3FMUState* state) {
    if (!state) return fmi3Error;
    delete static_cast<State*>(*state);
    *state = nullptr;
    return fmi3OK;
}

extern "C" fmi3Status fmi3SerializedFMUStateSize(fmi3Instance,
                                                   fmi3FMUState state,
                                                   size_t* size) {
    if (!state || !size) return fmi3Error;
    *size = kSerializedStateSize;
    return fmi3OK;
}

extern "C" fmi3Status fmi3SerializeFMUState(fmi3Instance,
                                              fmi3FMUState opaque_state,
                                              fmi3Byte bytes[], size_t size) {
    if (!opaque_state || !bytes || size < kSerializedStateSize) return fmi3Error;
    const auto& state = *static_cast<State*>(opaque_state);
    std::copy(kStateMagic.begin(), kStateMagic.end(), bytes);
    const auto values = state_doubles(state);
    std::size_t offset = kStateMagic.size();
    for (const double value : values) {
        write_double(bytes + offset, value);
        offset += 8;
    }
    bytes[offset++] = state.initialized ? 1 : 0;
    bytes[offset] = static_cast<std::uint8_t>(state.kind);
    return fmi3OK;
}

extern "C" fmi3Status fmi3DeserializeFMUState(
    fmi3Instance, const fmi3Byte bytes[], size_t size, fmi3FMUState* opaque_state) {
    if (!bytes || size != kSerializedStateSize || !opaque_state) return fmi3Error;
    if (!std::equal(kStateMagic.begin(), kStateMagic.end(), bytes)) return fmi3Error;
    std::array<double, kSerializedDoubleCount> values{};
    std::size_t offset = kStateMagic.size();
    for (double& value : values) {
        value = read_double(bytes + offset);
        offset += 8;
    }
    const std::uint8_t initialized = bytes[offset++];
    const std::uint8_t kind = bytes[offset];
    if (kind > static_cast<std::uint8_t>(Kind::ScheduledExecution)) return fmi3Error;
    try {
        auto* state = new State{};
        if (!assign_state_doubles(*state, values)) {
            delete state;
            return fmi3Error;
        }
        state->initialized = initialized != 0;
        state->kind = static_cast<Kind>(kind);
        *opaque_state = state;
        return fmi3OK;
    } catch (...) {
        return fmi3Error;
    }
}

extern "C" fmi3Status fmi3DoStep(
    fmi3Instance instance, fmi3Float64 current_time, fmi3Float64 step_size,
    fmi3Boolean, fmi3Boolean* event_encountered, fmi3Boolean* terminate,
    fmi3Boolean* early_return, fmi3Float64* last_successful_time) {
    if (!instance || !std::isfinite(current_time) || !std::isfinite(step_size) ||
        step_size <= 0.0) {
        return fmi3Error;
    }
    auto& state = cast(instance)->state;
    if (std::abs(state.time - current_time) > 1.0e-6) state.time = current_time;
    integrate(state, step_size);
    if (event_encountered) *event_encountered = 0;
    if (terminate) *terminate = 0;
    if (early_return) *early_return = 0;
    if (last_successful_time) *last_successful_time = state.time;
    return fmi3OK;
}

extern "C" fmi3Status fmi3SetTime(fmi3Instance instance, fmi3Float64 time) {
    if (!instance || !std::isfinite(time)) return fmi3Error;
    cast(instance)->state.time = time;
    return fmi3OK;
}

extern "C" fmi3Status fmi3GetContinuousStates(fmi3Instance instance,
                                                fmi3Float64 states[], size_t count) {
    if (!instance || !states || count < 4) return fmi3Error;
    const auto& state = cast(instance)->state;
    states[0] = state.rpm;
    states[1] = state.speed;
    states[2] = state.manifold_pressure;
    states[3] = state.turbo_speed;
    return fmi3OK;
}

extern "C" fmi3Status fmi3SetContinuousStates(
    fmi3Instance instance, const fmi3Float64 states[], size_t count) {
    if (!instance || !states || count < 4) return fmi3Error;
    for (size_t index = 0; index < 4; ++index) {
        if (!std::isfinite(states[index])) return fmi3Error;
    }
    auto& state = cast(instance)->state;
    state.rpm = std::max(0.0, states[0]);
    state.speed = std::max(0.0, states[1]);
    state.manifold_pressure = std::max(1000.0, states[2]);
    state.turbo_speed = std::max(0.0, states[3]);
    update_outputs(state);
    return fmi3OK;
}

extern "C" fmi3Status fmi3GetContinuousStateDerivatives(
    fmi3Instance instance, fmi3Float64 derivatives[], size_t count) {
    if (!instance || !derivatives || count < 4) return fmi3Error;
    calculate_derivatives(cast(instance)->state, derivatives);
    return fmi3OK;
}

extern "C" fmi3Status fmi3GetEventIndicators(fmi3Instance instance,
                                               fmi3Float64 indicators[], size_t count) {
    if (!instance || !indicators || count < 1) return fmi3Error;
    indicators[0] = 7000.0 - cast(instance)->state.rpm;
    return fmi3OK;
}

extern "C" fmi3Status fmi3CompletedIntegratorStep(
    fmi3Instance instance, fmi3Boolean, fmi3Boolean* enter_event_mode,
    fmi3Boolean* terminate) {
    if (!instance) return fmi3Error;
    if (enter_event_mode) *enter_event_mode = cast(instance)->state.rpm >= 7000.0;
    if (terminate) *terminate = 0;
    update_outputs(cast(instance)->state);
    return fmi3OK;
}

extern "C" fmi3Status fmi3EnterContinuousTimeMode(fmi3Instance instance) {
    return instance ? fmi3OK : fmi3Error;
}

extern "C" fmi3Status fmi3UpdateDiscreteStates(
    fmi3Instance instance, fmi3Boolean* discrete_states_need_update,
    fmi3Boolean* terminate, fmi3Boolean* nominals_changed,
    fmi3Boolean* values_changed, fmi3Boolean* next_event_time_defined,
    fmi3Float64* next_event_time) {
    if (!instance) return fmi3Error;
    if (discrete_states_need_update) *discrete_states_need_update = 0;
    if (terminate) *terminate = 0;
    if (nominals_changed) *nominals_changed = 0;
    if (values_changed) *values_changed = 0;
    if (next_event_time_defined) *next_event_time_defined = 0;
    if (next_event_time) *next_event_time = 0.0;
    return fmi3OK;
}

extern "C" fmi3Status fmi3ActivateModelPartition(
    fmi3Instance instance, fmi3ValueReference clock_reference,
    fmi3Float64 activation_time) {
    if (!instance || !std::isfinite(activation_time)) return fmi3Error;
    auto& state = cast(instance)->state;
    if (clock_reference == ControllerClock) {
        if (activation_time + 1.0e-12 < state.time) return fmi3Error;
        state.time = activation_time;
        state.throttle = std::clamp(state.throttle_command, 0.0, 1.0);
        update_outputs(state);
        return fmi3OK;
    }
    if (clock_reference == PlantClock) {
        if (activation_time < state.time) return fmi3Error;
        const double interval = activation_time - state.time;
        if (interval > 0.0) integrate(state, interval);
        if (cast(instance)->clock_update) cast(instance)->clock_update(cast(instance)->environment);
        return fmi3OK;
    }
    log_message(cast(instance), fmi3Error, "clock", "unknown model-partition clock");
    return fmi3Error;
}

# Formula One Predictive-Fidelity Platform Implementation Report

**Date:** 2026-07-25  
**Project:** MuzixDiagSys  
**Scope:** Additive Formula One realism, correlation, and uncertainty expansion

## 1. Result

The Formula One simulator now includes a complete predictive-fidelity platform
with no deliberately incomplete public functions, fabricated outputs, or
intentionally unimplemented execution paths. Existing Formula One, IndyCar, NASCAR, vehicle,
diagnostics, industrial, and advanced-platform features remain in the source
and build graph.

The production implementation adds:

- `include/aesim/advanced/formula_one_fidelity_platform.hpp`
- `src/advanced/formula_one_fidelity_platform.cpp`
- `tests/formula_one_fidelity_platform_tests.cpp`
- `tests/formula_one_fidelity_source_regression.py`
- `docs/FORMULA_ONE_FIDELITY_PLATFORM.md`

The implementation contains 2,278 lines of production public API and C++ source,
plus focused unit, source-integrity, and documentation coverage.

## 2. Build integration

`src/advanced/formula_one_fidelity_platform.cpp` is compiled directly into the
existing `aesim_formula_one` static library. The public API is reachable through:

```cpp
#include "aesim/advanced/formula_one_fidelity_platform.hpp"
```

It is also re-exported by:

```cpp
#include "aesim/advanced/formula_one_platform.hpp"
#include "aesim/advanced/platform.hpp"
```

The focused executable and CTest registration are:

- `formula_one_fidelity_platform_tests`
- `formula_one_fidelity_platform_unit_tests`
- `formula_one_fidelity_source_regression`

No existing source file, target, test, public class, or command family was
removed.

## 3. Fully coupled full-car dynamic simulation kernel

### Public implementation

- `F1CoupledCarConfiguration`
- `F1CoupledCarEnvironment`
- `F1CoupledCarControl`
- `F1CoupledCarState`
- `F1CoupledCarStepResult`
- `F1FullyCoupledCarDynamicsKernel`

### State and coupling

The kernel advances one common state containing:

- World position.
- Body-frame longitudinal, lateral, and vertical velocity.
- Roll, pitch, and yaw attitude.
- Roll, pitch, and yaw angular velocity.
- Body acceleration.
- Four suspension compression and velocity states.
- Four full transient tyre states.
- Fuel mass.
- Cumulative fuel, tyre, and aerodynamic energy terms.

Every internal substep calculates:

1. World-to-body wind transformation.
2. Air-relative dynamic pressure.
3. Active-aero drag and downforce.
4. Ride-height and pitch aerodynamic platform response.
5. Aerodynamic center-of-pressure moment.
6. Static and aerodynamic corner loads.
7. Four spring, damper, anti-roll, and bump-stop forces.
8. Four steered wheel-frame contact velocities.
9. Four transient tyre advances.
10. Four wheel rotational equations.
11. Ground-force transformation into the body frame.
12. Roll, pitch, and yaw moment accumulation.
13. Body translational and rotational integration.
14. Body-to-world velocity transformation.
15. Fuel burn from drive energy.
16. Mechanical-energy and dissipation audit.

The public time step is automatically divided by `maximum_internal_step_s`, so
larger process calls do not bypass the configured high-rate coupling interval.

### Correct coordinate convention

The implementation uses a single right-handed frame throughout:

- `x`: forward.
- `y`: vehicle left.
- `z`: upward.
- Positive roll raises the left side.
- Positive pitch follows right-hand rotation about `y` and lowers the nose.
- Positive yaw turns left.

During focused regression development, inconsistent pitch geometry and gravity
projection produced an unstable positive feedback. That defect was corrected by
aligning corner-height kinematics, vertical velocity, gravity projection,
aerodynamic center-of-pressure moment, and ground-force moment signs. Left and
right static camber were also made symmetric so camber thrust cancels during a
straight run.

## 4. Advanced transient tyre and wet-contact model

### Public implementation

- `F1TransientTyreConfiguration`
- `F1TransientTyreInput`
- `F1TransientTyreState`
- `F1TransientTyreResult`
- `F1AdvancedTransientTyreModel`

### Implemented physics

- Instantaneous longitudinal slip ratio.
- Instantaneous lateral slip angle.
- Speed-dependent longitudinal relaxation.
- Speed-dependent lateral relaxation.
- Combined-slip saturation.
- Peak-to-sliding friction transition.
- Load sensitivity.
- Pressure sensitivity.
- Temperature-window sensitivity.
- Rubber and roughness effects.
- Wear and flat-spot degradation.
- Camber thrust.
- Pneumatic trail and aligning moment.
- Rolling resistance.
- Contact-patch area and length.
- Vertical deflection.

### Wet-contact model

The wet model uses:

- Water-film depth.
- Groove void fraction.
- Remaining tread depth.
- Time-dependent groove drainage.
- Inflation pressure.
- Contact speed.
- Retained water saturation.
- Smooth aquaplaning onset.

It returns drained water, wet-friction scale, and aquaplaning fraction without a
discontinuous global wet-grip switch.

### Thermal and degradation model

Three thermal states represent surface, carcass, and internal gas. Heat paths
include surface-to-carcass, surface-to-track, carcass-to-gas, and
carcass-to-ambient transfer. Sources include longitudinal slip, lateral slip,
and brake heat. Water increases surface cooling. Gas temperature updates tyre
pressure, and slip energy advances tread wear. Severe locked-wheel behavior
advances a persistent flat-spot state.

## 5. Sensor, DAQ, latency, and synchronization realism

### Public implementation

- `F1SensorChannelConfiguration`
- `F1SensorChannelState`
- `F1DaqPacket`
- `F1SensorDaqPipeline`
- `F1ClockSynchronizationObservation`
- `F1ClockSynchronizationResult`
- `F1ClockSynchronizationEstimator`

### Channel realism

Each channel independently implements:

- Sample rate.
- Scale-factor error.
- Static bias.
- White noise.
- Bias random walk.
- Temperature coefficient.
- Quantization.
- Saturation.
- First-order low-pass filtering.
- Dropout probability.
- Mean latency.
- Latency jitter.
- Local clock offset.
- Local clock drift in parts per million.
- Deterministic pseudo-random generation.

Packets are queued according to arrival time rather than source time, allowing
latency jitter to create delivery reordering. Reset restores all filter, clock,
sequence, random-walk, and pseudo-random state.

### Synchronization

The synchronization estimator performs weighted affine least squares:

```text
reference_time = scale * source_time + offset
```

It reports RMS and maximum residual and provides direct correction of future
source timestamps.

## 6. Telemetry-driven state and parameter estimation

### Public implementation

- `F1TelemetryMeasurementType`
- `F1TelemetryMeasurement`
- `F1EstimatorProcessInput`
- `F1EstimatedVehicleState`
- `F1EstimatorConfiguration`
- `F1EstimatorUpdateResult`
- `F1TelemetryStateParameterEstimator`

### Estimated state and parameters

The estimator jointly maintains:

1. Longitudinal speed.
2. Lateral speed.
3. Yaw rate.
4. Roll angle.
5. Pitch angle.
6. Longitudinal accelerometer bias.
7. Lateral accelerometer bias.
8. Yaw-rate bias.
9. Wheel-speed scale.
10. Tyre-friction scale.
11. Aerodynamic scale.
12. Vehicle-mass scale.

### Numerical method

The nonlinear process model includes axle geometry, front and rear cornering
stiffness, saturated axle force, drive force, brake force, aerodynamic drag,
aerodynamic downforce, scaled mass, and roll/pitch response. A midpoint
transition integrates the dynamic states.

Transition and observation Jacobians are calculated with deterministic finite
differences. Covariance propagation uses the complete transition matrix.
Sequential scalar measurement updates use the Joseph covariance form. A
measurement is rejected when the absolute normalized innovation exceeds eight.
Parameter scale states are bounded to physically meaningful numerical ranges.

Supported observations include longitudinal speed, wheel speed, yaw rate,
longitudinal and lateral acceleration, roll angle, pitch angle, and front and
rear ride height.

## 7. Validation framework

`F1ValidationFramework` computes:

- Mean error.
- Mean absolute error.
- Root-mean-square error.
- Normalized RMSE.
- Maximum absolute error.
- Correlation coefficient.
- Lag-one residual autocorrelation.
- Prediction-interval coverage.

The implementation validates synchronized vector lengths, finite values, and
ordered prediction intervals. Optional acceptance gates enforce an RMSE maximum
and correlation minimum.

## 8. Uncertainty quantification

`F1UncertaintyQuantificationFramework` supports:

- Uniform distributions.
- Normal distributions.
- Triangular distributions.
- Deterministic Latin-hypercube sampling.
- Independent Monte Carlo sampling.
- Seeded reproducibility.
- Confidence quantiles.
- Pearson sensitivity.
- Multiple standardized regression coefficients.

Normal quantiles use a rational inverse-normal approximation followed by a
refinement step. Multiple regression uses the sampled parameter-correlation
matrix with numerical regularization. Non-finite model outputs terminate the
study.

## 9. Identifiability framework

`F1IdentifiabilityFramework` calculates:

- Centered finite-difference observation sensitivity.
- Parameter-scale normalization.
- Measurement-uncertainty normalization.
- Fisher information matrix.
- Symmetric Jacobi eigen decomposition.
- Singular values.
- Numerical rank.
- Condition number.
- Regularized parameter covariance.
- Parameter-correlation matrix.
- Weak-parameter classification.

A problem is identifiable only when numerical rank equals the parameter count
and condition number remains within the configured limit. Parameters are marked
weak when sensitivity is very small or posterior correlation is extreme.

## 10. Input and numerical safety

The new platform validates:

- Every public time step.
- Mass, inertia, geometry, stiffness, damping, pressure, temperature, and load.
- Probability and normalized-fraction ranges.
- Sensor limits and sample rates.
- Distribution parameters.
- Vector dimensions.
- Measurement standard deviation.
- Finite state, control, environment, and model output.

No NaN or infinity is intentionally propagated into returned model state.

## 11. Regression coverage

The focused unit test exercises:

- Tyre relaxation.
- Dry longitudinal and lateral force.
- Thermal and wear evolution.
- Standing-water drainage.
- Aquaplaning and wet-friction reduction.
- Invalid wet-contact input rejection.
- Full-car acceleration.
- Aerodynamic load.
- Fuel-energy coupling.
- Energy-audit finiteness.
- Cornering yaw, lateral force, and roll.
- Reduced wet acceleration.
- Sensor sample count.
- DAQ latency.
- Quantization.
- Clock offset and drift.
- Affine synchronization recovery.
- State convergence.
- Wheel-speed scale estimation.
- Yaw-rate bias estimation.
- Posterior uncertainty reduction.
- Validation metrics and interval coverage.
- Latin-hypercube uncertainty statistics.
- Sensitivity ranking.
- Full-rank identifiability.
- Rank-deficient parameter confounding.

The source-integrity regression verifies public implementation, test coverage,
CMake integration, manual/guide coverage, and the absence of incomplete-source
markers in the new production files.

## 12. Documentation

Updated current documentation includes:

- `README.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/FORMULA_ONE_FIDELITY_PLATFORM.md`
- This implementation report.
- The dated validation record.

Historical dated implementation and validation records remain unchanged because
they describe earlier source states.

## 13. Qualification boundary

The platform is executable and complete, but it remains a reduced-order research
model. It does not claim FIA homologation, confidential team-level correlation,
or validity outside calibrated parameter and operating ranges. Reliable use
requires calibrated inputs, controlled source data, independent validation,
identifiability review, and uncertainty reporting.

## 14. Final validation result

The completed implementation passed strict GCC 14 and Clang 17 builds, focused
AddressSanitizer and UndefinedBehaviorSanitizer execution, all 14 registered
Formula One compiled/source regressions, documentation consistency and user
manual regressions, deterministic source-package validation, generated-artifact
cleanliness validation, and PDF preflight/render inspection. Detailed commands,
coverage, and qualification limits are recorded in
`FORMULA_ONE_FIDELITY_VALIDATION_2026-07-25.txt`.

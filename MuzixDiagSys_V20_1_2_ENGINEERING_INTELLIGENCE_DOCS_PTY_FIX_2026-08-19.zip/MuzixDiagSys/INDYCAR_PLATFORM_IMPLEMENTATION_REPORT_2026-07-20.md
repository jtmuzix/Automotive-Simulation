# IndyCar Platform Implementation Report — 2026-07-20

## Summary

Implemented ten additive IndyCar engineering and competition systems without removing or renaming existing simulator features:

1. IndyCar IR-18 vehicle and versioned rule-profile platform.
2. Oval, short-oval, and superspeedway vehicle dynamics.
3. Approved aerodynamic configurations and pack-racing wake interaction.
4. Driver-operated weight jacker and anti-roll-bar controls.
5. Hybrid deployment, regeneration, self-start, and push-to-pass orchestration.
6. Firestone serialized tyre allocation, no-warmer preparation, and compound strategy.
7. Indianapolis 500 Month-of-May preparation, qualifying, and race planning.
8. Road/street and oval qualification procedures.
9. Race-control, caution, restart, and pit-lane state machine.
10. Sealed engine and hybrid pool mileage, assignment, reliability, and penalty management.

## Architecture

Added public API:

- `include/aesim/advanced/indycar_platform.hpp`

Added implementation:

- `src/advanced/indycar_platform_a.cpp`
- `src/advanced/indycar_platform_b.cpp`

Added regression coverage:

- `tests/indycar_platform_tests.cpp`

Added documentation:

- `docs/INDYCAR_PLATFORM.md`

Updated integration:

- `CMakeLists.txt`
- `include/aesim/advanced/platform.hpp`
- `tests/source_package_regression.py`
- `README.md`

## Technical implementation

### Rule and vehicle profile

The versioned rule profile contains circuit-specific minimum masses, driver-equivalency mass, fuel-cell capacity, engine displacement and speed, boost limits, wheelbase and height limits, wheel dimensions, hybrid allocation, push-to-pass limits, and prohibited systems. Scrutineering validates approved and sealed parts, keel ballast, power steering, software identity, and dimensional limits. Results include severity-ranked violations, margins, and SHA-256 configuration evidence.

### Oval dynamics

The reduced-order oval solver resolves banking support, aero load, front/rear roll distribution, crossweight, tyre stagger, asymmetric right-side loads, tyre utilization, steering effort without assistance, aero heave, bumps, bottoming, and tyre thermal accumulation over multiple laps.

### Pack aerodynamics

The pack solver uses longitudinal wake decay and lateral wake spreading for arbitrary car groups. It calculates tow gain, downforce loss, drag reduction, balance migration, turbulence, side-draft forces, wall proximity effects, crosswind sensitivity, and cooling-flow reduction.

### Driver setup controls

Weight-jacker commands are integrated with travel and rate limits. Spring-perch displacement generates crossweight change, while anti-roll-bar commands alter balance. Commands identify their source; external or automatic weight-jacker commands are rejected as illegal.

### Hybrid and push-to-pass

The orchestrator enforces state-of-charge limits, deployment power, regeneration power and torque, usable energy, total push-to-pass time, maximum activation duration, race-control permission, opening-start lockout, command-blue lockout, and base/elevated boost. Road/street self-start requires driver acknowledgement, safety clearance, and sufficient energy; oval self-start requests are rejected.

### Firestone tyre strategy

Every set retains entrant and four corner serials, compound, laps, heat cycles, tread, structure, temperature, pressure, and return state. A bounded exhaustive allocation search enforces session eligibility, wet authorization, new-set requirements, no warmers, no treatment, and primary/alternate use. Cold first-lap grip, thermal recovery, wear, and structural degradation are calculated.

### Indianapolis 500

The Month-of-May model checks staged rookie-orientation speeds, predicts no-tow performance, searches aerodynamic trim, calculates four-lap qualifying averages, completion and advancement probabilities, fuel windows, caution-adjusted stint length, pit-stop count, race speed, and race duration.

### Qualification

Road/street qualification supports groups, advancement, final classification, interference penalties, technical eligibility, and elimination. Oval qualification supports multi-lap averages, guaranteed attempts, prior-time withdrawal, technical rejection, field-size bumping, and classified order.

### Race control

The chronological state machine implements incidents, full-course cautions, pit opening and closing, wave-arounds, one-to-go, restart, red/green states, closed-pit penalties, timed penalties, retirements, completed laps, order reconstruction, and evidence-bearing timeline snapshots.

### Engine and hybrid pools

The pool manager tracks serials, manufacturer, seals, accumulated mileage, life limit, availability, and base failure rate. Event assignments account for event mileage, importance, Indianapolis severity, manufacturer compatibility, free allocation counts, seal violations, expected failure cost, and unauthorized-change penalties.

## Evidence and defensive behavior

- All numerical public inputs validate finiteness and physical bounds.
- Identity collections reject duplicate car, tyre, part, and power-asset identifiers.
- Ordered streams reject overlapping hybrid segments and nonchronological race events.
- All primary results include deterministic SHA-256 evidence digests.
- No TODO, FIXME, stub, placeholder, or unimplemented markers were added.

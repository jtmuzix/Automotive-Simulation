# MuzixDiagSys Stability Debug and Refactor Report

Date: 2026-07-15

## Scope

This pass hardened the performance-refactored automotive simulator for runtime stability while preserving all nonredundant features, commands, compatibility aliases, file formats, and public APIs.

## Implemented stability improvements

### Telemetry broker fault containment

- Subscriber callbacks now execute outside the broker mutex as before, but each callback is isolated with an exception boundary.
- A defective plugin, observer, or user callback can no longer unwind through `TelemetryBroker::publish`, terminate the simulation loop, or prevent later healthy subscribers from receiving the same frame.
- Frames remain committed to bounded telemetry history before callbacks execute, preserving replay and post-mortem evidence.

### Telemetry TCP server lifecycle hardening

- Serialized `start()` and `stop()` lifecycle transitions.
- Added deterministic rollback for listener creation, broker subscription, and thread-construction failures.
- Prevented exceptions from escaping the accept-thread entry point, avoiding `std::terminate`.
- Replaced indefinite blocking `accept()` dependence with a bounded 100 ms readiness wait, making shutdown deterministic across platforms where closing a listener from another thread does not reliably interrupt `accept()`.
- Made `stop()` clean partially initialized and unexpectedly stopped states instead of returning early and leaking resources.
- Reset subscription and broker state after shutdown and retained idempotent cleanup semantics.

### Python API process-boundary hardening

- Normalized `FileNotFoundError`, `PermissionError`, and other `OSError` launch failures into the documented `MuzixDiagError` API.
- Added validation that command timeouts are finite and strictly positive when supplied.
- Added validation that accepted return-code collections are not empty.
- Preserved every existing Python method and command invocation shape.

## Regression coverage added

- A throwing telemetry subscriber cannot disrupt a healthy subscriber.
- Telemetry history and sequence ordering remain correct after observer failure.
- Failure-path subscriptions remain removable.
- Missing engineering executables produce `MuzixDiagError`, not an implementation-specific Python exception.
- Non-positive command timeouts are rejected before process creation.

## Validation performed

- Clean Debug configuration with GCC 14.2 and ASan/UBSan instrumentation: configured successfully.
- Complete non-sanitized Debug build: passed for the main simulator, engineering CLI, plugins, worker tools, and all test executables.
- `engineering_platform_unit_tests`: passed.
- `engineering_python_api_regression`: passed.
- `validation_python_api_regression`: passed.
- CLI, authentication, source-package, generated-artifact, build-footprint, PIC/PIE, command-completion, branding, UI, drivetrain, and multiple vehicle-regression tests completed without failures during the extended CTest run.
- The complete 111-test suite had passed before this stability pass. The post-change full run was execution-window limited after progressing through the suite without an observed failure; all directly affected tests were rerun to completion and passed.
- `git diff --check`: passed.

## Compatibility statement

No feature or command was removed. No compatibility alias, serialized schema, report format, public C++ signature, Python method, or command-line grammar was deleted or renamed.

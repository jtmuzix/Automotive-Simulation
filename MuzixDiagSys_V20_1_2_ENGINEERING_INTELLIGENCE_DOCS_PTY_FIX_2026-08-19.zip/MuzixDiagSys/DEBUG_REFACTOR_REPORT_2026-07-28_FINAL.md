# MuzixDiagSys Advanced Automotive Simulator
## Debugging and Refactoring Report — 2026-07-28 Final

## 1. Scope and preservation policy

The supplied MuzixDiagSys source archive was inspected, configured, compiled, tested, and audited as a C++17/CMake automotive simulation platform. The work was intentionally conservative:

- no feature, command, simulation module, protocol, competition platform, test, document, or public API was removed;
- existing behavior was preserved except where a reproducible defect or unsafe build/package behavior required correction;
- changes were limited to lifecycle synchronization, regression coverage, build portability, source-package integrity, executable permissions, and synchronized documentation.

The final source archive remains a source-only package. Build products, generated test output, caches, Git metadata, and temporary files are excluded.

## 2. Baseline assessment

The codebase contains broad vehicle, powertrain, electrification, diagnostics, industrial, advanced research, Formula One, IndyCar, NASCAR, federation, assurance, engineering-studio, CLI, Python, and terminal-UI functionality. The baseline project configured and compiled successfully, and its existing tests passed. That result did not expose a responder lifecycle race because the previous tests exercised ordinary sequential start/stop behavior only.

Manual concurrency and ownership review identified the following defects and delivery risks.

### 2.1 OBD-II responder lifecycle race

`SocketCanObdResponder::start()` checked `running()` without serializing the complete lifecycle transition. Two callers could both observe a stopped responder and then attempt to assign a new worker to the same `std::thread`. Assigning over a still-joinable thread invokes `std::terminate`.

A related restart path existed when the worker stopped itself after a transport or protocol exception. The atomic running flag became false, but the old worker object remained joinable. A later start could again assign over that joinable thread and terminate the process.

### 2.2 Stop and transport-transition races

Concurrent `stop()` calls could race while joining and closing the transport. `configure()`, `use_loopback()`, and `use_socketcan()` also performed check-then-act lifecycle operations that were not serialized against a simultaneous start.

### 2.3 Unsafe detach fallback

The previous exceptional stop path could detach a worker as a last resort. The worker stores and uses a raw `this` pointer, so detachment could allow background access after responder destruction. The fallback avoided an immediate join failure but introduced an object-lifetime hazard.

### 2.4 Source packaging hardening gaps

The source packager accepted an arbitrary archive prefix, including parent traversal, did not explicitly reject symlinks, and could include its own output when asked to write inside the source tree. These conditions could produce ambiguous member paths, disclose data outside the requested source root, or recursively package an output archive.

### 2.5 Build-wrapper portability and delivery permissions

The documented transactional build wrapper relied directly on `nproc`, did not validate `AESIM_BUILD_JOBS`, and was delivered without executable permission. The manual-PDF wrapper also lacked executable permission. Script contents were valid, but direct invocation failed on Unix-like systems.

## 3. Implemented corrections

### 3.1 Serialized responder lifecycle

A dedicated `lifecycle_mutex_` now serializes start, stop, configuration, and transport replacement independently from the protocol-state mutex. This prevents lifecycle calls from assigning over, joining, closing, or replacing the same resources concurrently.

`start()` now:

- returns idempotently when a worker is already active;
- joins a completed but still-joinable worker before creating a replacement;
- rejects a pathological self-restart from the worker thread;
- preserves the existing isolated-bench arming requirement;
- restores the stopped/closed state if thread construction fails.

`stop()` now:

- atomically requests shutdown;
- joins the worker exactly once under lifecycle serialization;
- never detaches a worker that references the responder;
- closes the transport and resets ISO-TP request/response state after worker completion;
- remains `noexcept` for destructor safety.

Transport selection now stops and collects the prior worker before replacing the transport. Configuration changes remain prohibited while running and are now race-free with respect to start.

No public method was removed or renamed. The only header-level structural additions are a private lifecycle mutex and a private shutdown helper.

### 3.2 Independent lifecycle regression target

A new `obd_responder_lifecycle_tests` target links only the diagnostics boundary and performs repeated synchronized start/stop stress rounds. It verifies:

- eight simultaneous starts produce one active worker without exceptions;
- eight simultaneous stops safely collect the worker;
- repeated restart remains functional;
- active configuration replacement still raises `std::logic_error`.

The broader CAN/OBD synthesis test also contains lifecycle stress coverage so the behavior is exercised in both focused and integrated diagnostic contexts.

### 3.3 Source-package integrity controls

`tools/package_source.py` now:

- requires a real source directory and a `.zip` output;
- accepts only a non-empty relative POSIX archive prefix;
- rejects absolute, dot, parent-traversing, or backslash-containing prefixes;
- excludes the output archive and temporary archive even when written under the source root;
- rejects non-generated symbolic links instead of following or preserving ambiguous external references;
- retains deterministic timestamps, ordering, compression, and permission metadata.

The package regression suite now checks traversal rejection, symlink rejection, in-tree output exclusion, deterministic output, archive size limits, required files, and executable-mode retention.

### 3.4 Build workflow portability

`tools/build_full_and_test.sh` now:

- detects parallelism through `nproc`, then `getconf`, then a safe single-job fallback;
- validates the final job count as a positive integer;
- permits an explicit `--jobs` argument to override an invalid environment value;
- retains the existing transactional configure/build/test behavior and HIP/SYCL options.

Both documented shell entry points now carry Unix executable permissions. Regression tests invoke the wrapper directly, verify help output, and verify invalid/overridden job-count behavior.

### 3.5 Documentation synchronization

`docs/SOCKETCAN_OBD_RESPONDER.md` now documents lifecycle serialization, idempotent concurrent start/stop behavior, restart collection, active-reconfiguration rejection, and the no-detach object-lifetime guarantee.

## 4. Validation results

### 4.1 Fresh clean production-style build

A new, empty `RelWithDebInfo` Ninja build directory was configured through the repaired transactional wrapper.

- Compiler: GNU C++ 14.2.0
- CMake: 3.31.6
- Ninja: 1.12.1
- Python: 3.13.5
- OpenSSL: 3.5.5
- SQLite: 3.46.1
- Zlib: 1.3.1
- Build steps: 473 of 473 completed
- Compiler warnings detected in captured clean-build output: 0
- Compiler/link errors: 0
- CTest: 195 of 195 registered tests passed
- Optional skip: `advanced_platform_python_runtime` was reported as skipped by its existing test contract
- CTest elapsed time: 201.51 seconds

The clean build covered all compiled libraries, executables, plugins, test targets, Formula One, IndyCar, NASCAR, industrial/diagnostic, engineering, federation, Python, packaging, documentation, CLI, and PTY/UI regressions.

### 4.2 Sanitizer qualification

The focused lifecycle target was built and run with AddressSanitizer and UndefinedBehaviorSanitizer enabled.

- test: `obd_responder_lifecycle_unit_tests`
- result: passed
- ASan halt-on-error: enabled
- leak detection: enabled
- UBSan halt-on-error and stack traces: enabled
- reported sanitizer defects: 0

### 4.3 Static and script checks

The final tree also passed:

- `git diff --check`;
- Bash syntax validation for the build and manual-generation wrappers;
- Python bytecode compilation for the modified package and regression scripts;
- incremental no-work rebuild verification after the clean build.

## 5. Accelerator qualification boundary

HIP and SYCL were requested during configuration. The delivery environment did not contain a HIP compiler and did not qualify a SYCL compiler, so CMake correctly omitted the native HIP and SYCL translation units and completed the CPU build. The source-level mixed-language CMake protections remain intact, but actual ROCm/HIP device compilation and hardware execution could not be performed in this environment. That limitation is environmental, not represented as a successful GPU qualification.

## 6. Files changed

- `CMakeLists.txt`
- `include/aesim/industrial/can_obd.hpp`
- `src/industrial/can_obd.cpp`
- `tests/obd_responder_lifecycle_tests.cpp` (new)
- `tests/can_obd_synthesis_tests.cpp`
- `tests/build_transaction_workflow_regression.py`
- `tests/source_package_regression.py`
- `tools/build_full_and_test.sh`
- `tools/generate_user_manual_pdf.sh` (permission correction)
- `tools/package_source.py`
- `docs/SOCKETCAN_OBD_RESPONDER.md`
- this report and the associated validation record

## 7. Final disposition

The corrected source package preserves the existing feature surface and resolves the identified termination, race, lifetime, packaging, and build-entry defects. It has completed a fresh clean 473-step build and the complete 195-test suite, plus focused sanitizer qualification. No known test failure remains in the validated CPU configuration.

# MuzixDiagSys Performance and Stability Refactor Report

Date: 2026-07-15

## Objective

Debug and refactor the advanced automotive simulator while preserving all existing features, public APIs, command surfaces, serialized formats, standards workflows, and test coverage. No stubs or placeholders were introduced.

## Scope of this pass

This pass concentrated on high-risk process, socket, distributed-study, mutation-qualification, vECU, numerical-validation, and C++17 portability paths. These areas can destabilize an otherwise correct simulation through leaked processes, leaked file descriptors, unbounded blocking, malformed input, partial startup, or undefined indexing.

Modified implementation files:

- `src/federation/qualification_cloud.cpp`
- `src/federation/vecu_control.cpp`
- `src/research2/standards_perception_intelligence.cpp`
- `src/research2/standards_formal_runtime.cpp`
- `src/research2/standards_scenario_odd.cpp`
- `tests/federation_platform_tests.cpp`

## Implemented changes

### 1. Mutation qualification process containment

The mutation runner was converted from loosely managed process execution to deterministic ownership and cleanup:

- Added RAII ownership for pipes and file descriptors.
- Validated that mutation timeouts are strictly positive before creating a process.
- Placed each mutation command in a dedicated process group.
- On timeout, terminates the shell, test process, and all descendants rather than killing only the immediate child.
- Reaps the immediate child deterministically and handles `EINTR` correctly.
- Replaced periodic sleep-based output collection with `poll()`-driven collection.
- Made the output pipe nonblocking and bounded captured output to 8 MiB, preventing memory growth from a noisy or defective test command.
- Added robust handling for partial reads, closed pipes, and wait failures.
- Added baseline-failure diagnostics containing exit status, timeout state, duration, command, and captured output.

This prevents timed-out mutants from retaining sockets, files, CPU, or subprocesses that corrupt later qualification runs.

### 2. Distributed study-control server and client hardening

The study-control transport was refactored for deterministic lifecycle behavior:

- Serialized server lifecycle transitions with an explicit lifecycle mutex.
- Added rollback-safe listener startup; invalid addresses, bind failures, listen failures, and thread-construction failures no longer leave partial resources.
- Made `stop()` idempotent and capable of cleaning partially initialized state.
- Converted listener, accepted-client, and client-side sockets to RAII ownership.
- Added nonblocking connect, send, and receive paths with absolute deadlines.
- Added complete partial-send and partial-receive handling.
- Added 8 MiB request and response limits before allocation or transmission.
- Isolated malformed/disconnected clients from the accept loop.
- Prevented exceptions from escaping the server thread entry point.
- Added active-client shutdown during server stop so a half-open peer cannot block shutdown.
- Preserved restartability after stop and after startup failure.

### 3. QEMU vECU lifecycle and QMP transport refactor

The QEMU adapter previously treated a process as owned only after the full startup sequence completed. A failure after `fork()` but before setting the active flag could therefore leave QEMU or child processes running. The adapter now provides complete process ownership from fork through shutdown:

- Validates positive startup deadlines and Unix-socket path length.
- Tracks partial startup state and rolls it back on every exception path.
- Starts QEMU in a dedicated process group so descendants are contained.
- Reaps processes that exit during startup and reports exit code or signal.
- On failed startup, performs bounded `SIGTERM`, escalation to `SIGKILL`, and deterministic reaping.
- Allows the same adapter object to restart after a failed startup.
- Makes `stop()` clean both fully active and partially initialized states.
- Uses a bounded graceful QMP quit followed by bounded process termination.
- Replaced one-byte blocking QMP reads with buffered 4 KiB nonblocking reads.
- Preserves extra QMP lines in a receive buffer instead of discarding over-read data.
- Handles partial sends and `EINTR`/`EAGAIN` correctly.
- Applies an overall bounded response deadline rather than allowing repeated asynchronous event lines to multiply the timeout.
- Retains the complete existing pause, resume, status, snapshot-save, and snapshot-load feature set.

### 4. Numerical and data-shape stability

The domain-adaptation discrepancy calculation previously indexed the target mean using the source feature dimension without first proving that both datasets had the same width. It now:

- Rejects ragged datasets explicitly.
- Rejects source/target feature-dimension mismatches before indexing.
- Uses explicit floating-point normalization and structured loops.

This removes a possible out-of-bounds read and converts malformed research data into a deterministic diagnostic.

### 5. C++17 portability and diagnostic cleanup

- Removed a C++20-only structured-binding lambda-capture pattern from the SSP/OpenX standards implementation while retaining identical behavior under C++17.
- Braced the OpenSCENARIO repeat execution loop to eliminate misleading control-flow interpretation.
- Reformatted ODD reporting loops so violation and unknown-attribute output cannot be visually confused.
- Marked retained internal research utilities as `[[maybe_unused]]` rather than deleting them, preserving feature code while maintaining warning-clean builds.

## Regression coverage added

The federation platform tests now verify:

- Mutation baseline execution and mutant detection.
- Timeout reporting.
- Termination of mutation-command descendants.
- QEMU startup-failure rollback.
- Termination and reaping of a failed QEMU helper and its descendants.
- Restarting a QEMU adapter after failed startup.
- Normal QMP status, pause, resume, save, load, and stop operations.
- Idempotent QEMU stop.
- Invalid study-server address rollback.
- Client timeout validation.
- Shutdown while a client is half-open.
- Idempotent study-server stop.
- Study-server restart and request handling after stop.

## Validation results

### Build validation

- Clean CMake/Ninja Debug configuration: passed.
- Complete Debug build of the simulator, libraries, CLIs, plugins, tools, and test executables: passed.
- Final incremental relink after all source changes: passed for all 33 affected product/test targets, including `muzixdiagsys`.
- GCC optimized (`-O2 -DNDEBUG`) object compilation: passed for the modified federation sources, modified formal-runtime source, modified perception-intelligence source, and federation regression test.
- Clang C++17 warning/syntax checks: passed for all six modified files.

`src/research2/standards_scenario_odd.cpp` is an exceptionally large, monolithic translation unit. Its full standalone GCC `-O2` object compilation exceeded the execution window after producing no source error; the same modified file passed Clang C++17 syntax/warning validation and compiled successfully in the complete Debug build. This is a compile-time scalability limitation, not an observed runtime failure.

### Test validation

- Unit and CLI self-tests: **36/36 passed**.
- Targeted high-value regression tests: **12/12 passed**, including source packaging, PIC/PIE, accelerator linkage, plugin loading, professional platform, industrial platform, federation platform, command surface, path case sensitivity, native plugin stepping, nonfinite-input rejection, and API server behavior.
- Targeted AddressSanitizer and UndefinedBehaviorSanitizer federation build: passed.
- AddressSanitizer leak detection at process exit: passed.
- Extended Debug regression run: the first **57 of 117** selected tests passed without an observed failure before the execution window was exhausted by simulation-duration-intensive drive-cycle cases. Directly affected and high-risk tests were subsequently rerun to completion as listed above.

## Performance effects

- Mutation output handling is readiness-driven instead of sleep-driven.
- QMP response handling performs buffered reads rather than one system call per byte.
- Socket connect/send/receive operations use nonblocking deadlines rather than potentially indefinite blocking.
- Bounded message and output sizes prevent pathological memory consumption.
- Failure cleanup prevents orphaned processes from consuming CPU and memory across later simulations or test campaigns.
- Lifecycle state is reset deterministically, avoiding expensive process restarts or contaminated subsequent studies.

## Compatibility statement

No existing feature was removed. No public C++ signature, CLI grammar, compatibility alias, file format, report schema, standards workflow, plugin interface, or serialized document version was deleted or renamed. No stub, placeholder, mock implementation, or disabled feature path was added to production code.

## Remaining structural engineering debt

The simulator retains several very large translation units, particularly `src/simulation_runtime.cpp` and `src/research2/standards_scenario_odd.cpp`. They increase optimized-build time and compiler memory pressure. Splitting them along existing subsystem boundaries would improve incremental compilation, but that is a broad architectural migration requiring dedicated ABI, packaging, and full-drive-cycle verification. This pass deliberately avoided an unsafe mechanical split while correcting the concrete runtime and lifecycle defects identified above.

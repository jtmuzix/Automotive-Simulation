# MuzixDiagSys Product-Rename Implementation Report

**Date:** 2026-07-12  
**New product name:** MuzixDiagSys  
**Primary executable:** `muzixdiagsys`  
**Compatibility executable:** `engine_sim`

## Objective

Rename the complete simulator product to **MuzixDiagSys** throughout the executable, terminal interface, generated reports, manuals, platform documentation, SDK documentation, examples, configuration-facing messages, diagnostic identities, and delivery artifacts without removing existing features or breaking established integration contracts.

## Program changes

- Renamed the CMake project to `MuzixDiagSys`.
- Renamed the primary executable target to `muzixdiagsys`.
- Renamed the monolithic front-end source to `src/muzixdiagsys.cpp`.
- Retained `engine_sim` as a copied executable and compatibility build target.
- Rebranded the interactive console, dashboard, help overlay, command reference, reports, generated documentation, doctor output, plugin diagnostics, FMI display metadata, DBC descriptions, and dataset/report headings.
- Changed new command-history and UI-preference storage to MuzixDiagSys-specific names and directories.
- Added `MUZIXDIAGSYS_PROJECT_ROOT`, `MUZIXDIAGSYS_POWERTRAIN_CATALOG`, `MUZIXDIAGSYS_UI_PREFS`, and `MUZIXDIAGSYS_UI_PREFS_DISABLE` as preferred settings.
- Updated virtual OBD-II identity defaults, calibration identifiers, ECU labels, UDS software identity, ISO 15118 session identifiers, OTA sample identity, AI-model sample identity, RSU identifiers, and EVSE examples.
- Renamed default generated DBC and FMU artifacts to `muzixdiagsys_generated.dbc` and `muzixdiagsys_model.fmu`.
- Rebuilt product-named FMUs so their external `modelName`, documentation, resource metadata, and generation-tool name display MuzixDiagSys.

## Compatibility retained

The following identifiers intentionally remain unchanged because they are public technical contracts rather than displayed product branding:

- `aesim::` C++ namespaces and `include/aesim/...` headers.
- `AESIM_*` CMake options and environment-variable aliases.
- `aesim.*` schemas and serialized-format identifiers.
- FMI `aesim_powertrain` model identifier used by existing co-simulation integrations.
- Native plugin and SIL ABI symbols beginning with `aesim_` or `AESIM_`.
- Legacy `.engine_sim_history` and `.engine_sim_ui_preferences` migration reads.
- Legacy `engine_sim` executable and build-target compatibility.

## Documentation changes

- Renamed the authoritative manuals to:
  - `docs/MUZIXDIAGSYS_USER_MANUAL.md`
  - `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`
- Regenerated the 129-page PDF from the renamed Markdown source.
- Updated README, generated command documentation, SocketCAN responder documentation, virtual automotive laboratory documentation, implementation reports, SDK documentation, examples, shell commands, configuration paths, and troubleshooting references.
- Added `docs/MUZIXDIAGSYS_BRANDING_AND_COMPATIBILITY.md` to distinguish the public product identity from retained technical ABI/schema identifiers.
- Updated the manual regression to require the MuzixDiagSys title, executable, manual filenames, compatibility launcher, and preferred project-root setting.

## User-interface preservation

The terminal layout and command hierarchy were not redesigned. Golden terminal frames were regenerated only because the product-name width changed. Dashboard regions, command output, help overlays, keyboard behavior, completion, and all simulation functions remain available.

## Validation

Qualification evidence is supplied in `muzixdiagsys_rebranding_qualification_2026-07-12.txt`. The delivery verifies the primary executable, compatibility launcher, user-manual Markdown and PDF, generated product artifacts, SocketCAN responder workflow, command surface, golden terminal frames, branding regression, archive integrity, and absence of the abandoned intermediate product name.

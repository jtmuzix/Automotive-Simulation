# Build Warning Fix Report — 2026-08-08

## Scope

This maintenance release addresses the warning set reported from a Release build of the Advanced API CLI simulator. Existing features, command families, APIs, physics models, motorsports platforms, and build options are preserved.

## Corrected warnings

### GCC `-Wdangling-pointer` in `next_generation_labs.cpp`

The nominal co-design scenario no longer originates in a conditional-expression temporary. `aggregate_codesign()` now constructs an explicitly owned `effective_scenarios` vector and inserts the nominal scenario when the caller supplies no scenarios. This preserves the previous behavior while making the lifetime unambiguous to GCC 16.

### `-Wunused-but-set-variable` in `frontier_integration_platform_c.cpp`

The unused Verilator generation variable `ci` and its increments were removed. It did not contribute to generated RTL, simulation state, evidence, or output.

### HIP `[[nodiscard]]`/`-Wunused-result` from `hipFree()`

`frontier_expansion_particle_hip.hip` now uses checked release on successful SPH/DEM paths and a no-throw cleanup helper during exception unwinding. Normal releases therefore diagnose actual HIP deallocation failures, while exception cleanup consumes the HIP status without throwing a second exception.

### glibc `_FORTIFY_SOURCE requires compiling with optimization (-O)`

The large non-numerical CLI/orchestration translation units previously received `-O0` after `_FORTIFY_SOURCE=2` was enabled. The bounded Release compile policy now uses `-Og`. This retains the low-cost optimization policy for the large front ends while leaving `__OPTIMIZE__` enabled so glibc fortification is actually active. Numerical/physics libraries retain their normal Release optimization.

## Regression protection

`tests/build_warning_policy_regression.py` now guards all four fixes, including the explicit co-design scenario lifetime, absence of the dead Verilator counter, checked Frontier particle HIP cleanup, and a no-Release-`-O0` FORTIFY-compatible build policy.

## Validation performed

- Release configuration with hardening and strict numerics: PASS.
- Affected C++ object compilation on GCC 14.2: PASS with zero warnings in the captured targeted build log.
- `next_generation_labs.cpp`: compiled cleanly.
- `frontier_integration_platform_c.cpp`: compiled cleanly.
- Advanced API registry/front-end objects: compiled cleanly.
- `advanced_platform_cli.cpp`: compiled cleanly with `_FORTIFY_SOURCE=2` and `-Og`.
- `console_authentication.cpp`: compiled cleanly with `_FORTIFY_SOURCE=2` and `-Og`.
- `simulation_runtime.cpp`: compiled cleanly with `_FORTIFY_SOURCE=2` and `-Og`.
- `build_warning_policy_regression`: PASS.
- `frontier_integration_source_regression.py`: PASS.
- `frontier_expansion_source_regression.py`: PASS.
- `source_package_regression.py`: PASS.

The validation container does not provide a HIP compiler, so the modified HIP translation unit could not be natively compiled here. Its cleanup implementation is source-policy regression protected. The user's reported ROCm warning is addressed by consuming/checking every `hipFree()` return value in the affected SPH/DEM paths.

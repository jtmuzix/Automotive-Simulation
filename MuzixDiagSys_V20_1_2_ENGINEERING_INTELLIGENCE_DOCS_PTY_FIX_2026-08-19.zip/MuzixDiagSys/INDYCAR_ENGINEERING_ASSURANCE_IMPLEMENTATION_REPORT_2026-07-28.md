# IndyCar Engineering Assurance Implementation Report

**Date:** 2026-07-28  
**Status:** Production implementation complete  
**Compatibility:** Additive; no existing feature or public command removed

## Scope

This change adds a seventh IndyCar module containing fourteen fully executable C++17 domains:

1. regulation digital thread;
2. dynamic compliance;
3. next-generation certification;
4. prospective manufacturer program;
5. timing observation fusion;
6. officiating policy laboratory;
7. contact damage and raceability;
8. crash and SAFER finite-element twin;
9. fire and rescue hazards;
10. debris recovery;
11. composite manufacturing;
12. fleet reliability;
13. test design and calibration;
14. tire material digital thread.

## Source architecture

Public API:

- `include/aesim/advanced/indycar_engineering_assurance_platform.hpp`

Internal numerical support:

- `src/advanced/indycar_engineering_assurance_internal.hpp`

Production translation units:

- `src/advanced/indycar_engineering_assurance_platform_a.cpp`
- `src/advanced/indycar_engineering_assurance_platform_b.cpp`
- `src/advanced/indycar_engineering_assurance_platform_c.cpp`
- `src/advanced/indycar_engineering_assurance_platform_d.cpp`
- `src/advanced/indycar_engineering_assurance_platform_e.cpp`
- `src/advanced/indycar_engineering_assurance_platform_f.cpp`

The source is compiled into `aesim_indycar`. The aggregate header exports the API, and the production CLI exposes `indycar-assurance` without changing existing IndyCar command families.
Focused verification is provided by `indycar_engineering_assurance_platform_tests` and `tests/indycar_engineering_assurance_source_regression.py`.

## Algorithms implemented

- Effective-dated rule selection with lifecycle, precedence, specificity, revision, provenance, conflicts, and study invalidation.
- Time-evolving technical measurements with two-sided Gaussian noncompliance probability and statistical guard bands.
- Requirement/evidence certification matrices with revision invalidation, maturity, uncertainty, calibration coverage, dependency propagation, provisional-rule penalties, and deployment readiness.
- Dependency-checked manufacturer program critical path, cost, test allocation, parity, and supplier readiness.
- Latency-corrected inverse-variance timing fusion with iterative Huber weighting and alternative-order probability.
- Officiating policy scoring across safety, consistency, competitive impact, sanction proportionality, and due process.
- Progressive open-wheel contact damage with structural, alignment, tire, aerodynamic, cooling, thermal, repair, and raceability consequences.
- Explicit nonlinear structural dynamics with elastoplastic yielding, failure, wall/barrier contact, intrusion, HIC15, and energy audit.
- Coupled fuel/oil fire, smoke, carbon monoxide, visibility, suppression, ventilation, rescue route, and extraction dynamics.
- Three-dimensional fragment transport, detection probability, puncture risk, cleanup routing, and reopening confidence.
- Arrhenius composite cure, exotherm, thermal transfer, void compaction, laminate transformation, spring-back, bondline, repair, metrology, and capability.
- Bayesian-shrunk Weibull fleet populations with lot, overload, thermal, inspection, conditional-event risk, and remaining life.
- Cost-constrained D-optimal sequential experiment design and posterior covariance prediction.
- Tire-compound cure and aging kinetics, raw-material genealogy, viscoelastic/strength prediction, lot variability, sustainability, and circularity.

## Canonical workflows

Fourteen JSON requests are provided under `examples/indycar_engineering_assurance/`. The focused test parses every file, executes the corresponding domain, requires `passed=true`, and verifies a 64-character evidence digest. The platform self-test runs independent in-code canonical requests for all domains.

## Documentation changes

- Added `docs/INDYCAR_ENGINEERING_ASSURANCE_PLATFORM.md`.
- Added Chapter 60 to `docs/MUZIXDIAGSYS_USER_MANUAL.md`.
- Updated the README, documentation index, exact-command tutorial, aggregate CLI help, and package/documentation regressions.
- Regenerated and visually inspected `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`.

## Compatibility

The change is additive. No existing source, test, API, example, command family, or documentation asset is intentionally removed. Existing IndyCar, NASCAR, and Formula One libraries remain in the build graph.

## Qualification boundary

The implementation provides deterministic engineering models and evidence generation. It is not an official rule source, homologation decision, technical inspection, classification, officiating ruling, structural or medical certification, tire approval, or parts-life authorization. Physical use requires current rules, measured data, correlation, convergence, uncertainty, and qualified review.

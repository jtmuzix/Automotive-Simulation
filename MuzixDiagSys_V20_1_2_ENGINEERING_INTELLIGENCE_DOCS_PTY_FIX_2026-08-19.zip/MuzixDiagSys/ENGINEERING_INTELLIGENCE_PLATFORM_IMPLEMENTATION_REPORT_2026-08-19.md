# Engineering Intelligence Platform Implementation Report — 2026-08-19

## Scope

This change implements ten integrated engineering-intelligence capabilities in MuzixDiagSys without removing existing functionality and without introducing parallel implementations of facilities already present in the simulator:

1. Whole-Vehicle Consequence Engine
2. Zonal E/E Architecture Synthesizer
3. Vehicle Software Service-Graph Simulator
4. End-to-End Timebase Laboratory
5. Cross-Domain Conservation Auditor
6. Parameter Identifiability & Sloppiness Laboratory
7. Signal-Lineage / Calibration Provenance
8. Simulation Causality Microscope
9. Computational Reproducibility Capsules
10. Cross-Layer Requirement Propagation

## Integration strategy

The implementation deliberately extends canonical existing subsystems where equivalent functionality already existed:

- `EeArchitectureSynthesizer` remains the single E/E architecture solver. It was extended with zonal physical placement, harness metrics, cross-zone penalties, failure-domain diversity, and independent power-feed diversity.
- `ConservationGovernor` remains the single conservation-checking implementation. It was extended with whole-vehicle cross-domain aggregation and evidence reporting.
- `F1IdentifiabilityFramework` remains the canonical SVD/rank/parameter-correlation implementation. The general identifiability/sloppiness laboratory delegates its numerical decomposition to this existing solver and adds domain-independent interpretation.
- Whole-vehicle consequence propagation and the simulation causality microscope use one shared `EngineeringDependencyGraph`; no second causal/dependency graph implementation was added for those two capabilities.
- Existing SHA-256/provenance facilities in `aesim::core` are reused for evidence/capsule integrity rather than introducing another digest implementation.

## New platform API

The public header `include/aesim/advanced/engineering_intelligence_platform.hpp` defines the common engineering-dependency graph and the new engines. It is exported through `include/aesim/advanced/platform.hpp` and implemented in three translation units to keep compile units manageable:

- `src/advanced/engineering_intelligence_platform_a.cpp`
- `src/advanced/engineering_intelligence_platform_b.cpp`
- `src/advanced/engineering_intelligence_platform_c.cpp`

The unified `EngineeringIntelligencePlatform` facade exposes exactly ten domain identifiers through `capabilities()`, `execute()`, and `self_test()`.

## 1. Whole-Vehicle Consequence Engine

The consequence engine performs bounded deterministic propagation of engineering changes through a directed, typed whole-vehicle dependency graph. Nodes carry domain, quantity, unit, baseline value, criticality, and metadata. Edges carry dependency type, local sensitivity/gain, confidence, delay, and descriptive rationale.

Implemented behavior includes:

- absolute and relative initiating changes;
- multiple simultaneous initiating changes;
- accumulation of propagated effects at common downstream nodes;
- confidence multiplication along propagation paths;
- delay accumulation;
- configurable maximum depth and per-node visit limits for feedback graphs;
- minimum-effect and minimum-confidence pruning;
- per-domain effect aggregation;
- causal path retention for every reported impact;
- graph validation and deterministic evidence SHA-256 output.

The engine supports physical, software, signal, calibration, network, power, thermal, requirement, human, and manufacturing dependency kinds.

## 2. Zonal E/E Architecture Synthesizer

The existing `EeArchitectureSynthesizer` was enhanced instead of duplicated. Compute-node candidates now optionally carry:

- independent failure-domain identity;
- independent power-feed identity;
- physical x/y/z location.

Function requirements now optionally carry:

- physical endpoint location;
- harness mass per metre;
- harness cost per metre;
- maximum harness length;
- failure-domain diversity requirement;
- power-feed diversity requirement.

The existing branch-and-bound allocation evaluates these constraints inside its canonical complete-solution evaluator. The objective can include harness mass/cost and cross-zone allocation penalties while preserving existing node/network cost, mass, power, and latency terms. Results report total harness length/mass/cost, cross-zone allocations, and diversity status.

A legacy edge case was corrected: when `require_diverse_replicas` is enabled and `diversity_group` is unspecified, the node ID is now used as the fallback group. Two distinct nodes with omitted optional group metadata are therefore treated as distinct rather than incorrectly conflicting because both strings are empty.

## 3. Vehicle Software Service-Graph Simulator

The service-graph simulator models software-defined vehicle functions as deterministic services and communication links. It implements:

- directed service routing using minimum-latency paths;
- execution-time and serialization/propagation latency;
- per-service single-server queueing and queue-capacity enforcement;
- per-service restart time;
- request release time and end-to-end deadline checking;
- service crash and recovery;
- service throttling;
- communication-link partition and healing;
- deterministic request ordering;
- completed/dropped request accounting;
- maximum observed latency and service busy fractions;
- evidence hashing.

Failures therefore affect actual routability, service availability, queueing, and deadlines rather than being recorded as annotations only.

## 4. End-to-End Timebase Laboratory

The timebase laboratory models and estimates clock synchronization across vehicle sensors and computers. It supports:

- initial clock offset;
- oscillator drift in ppm;
- timestamp quantization;
- Gaussian timestamp jitter with deterministic seed control;
- forward/reverse path delay asymmetry;
- weighted clock observations;
- affine local-to-reference clock correction;
- estimated drift, correction scale, and correction offset;
- RMS/max residual timing error;
- conversion of timestamp error into spatial-registration error at a supplied object/vehicle speed;
- synchronization acceptance against a configurable tolerance.

## 5. Cross-Domain Conservation Auditor

`ConservationGovernor::audit_domains` extends the existing interface conservation checker with whole-vehicle domain aggregation. It computes:

- interface residuals and normalized residuals;
- domain absolute residual;
- domain normalized residual;
- relative contribution of each domain to total residual magnitude;
- dominant interface and dominant domain;
- cross-domain pass/fail status;
- deterministic evidence SHA-256.

It can be used for energy, mass, charge, species, momentum, or any other conserved quantity represented consistently at subsystem interfaces.

## 6. Parameter Identifiability & Sloppiness Laboratory

The new laboratory accepts a parameter list and a sensitivity/Jacobian matrix. It delegates SVD/rank/correlation calculations to the existing validated `F1IdentifiabilityFramework`, then adds general-purpose engineering outputs:

- singular values;
- numerical rank;
- condition number;
- parameter correlation matrix;
- normalized information eigenvalues (squared singular values);
- sloppiness ratio;
- weak/unidentifiable parameter reporting;
- configurable strong-correlation pair detection;
- evidence hashing.

The laboratory therefore detects both outright rank deficiency and practically sloppy parameter directions.

## 7. Signal-Lineage / Calibration Provenance

This capability provides signal-level provenance rather than duplicating the existing artifact/data-lineage systems. It records signal-processing nodes, directed transformations, and calibration records and supports:

- upstream lineage tracing for a selected signal;
- downstream impact analysis from a selected source;
- scale and delay accumulation along the selected lineage;
- versioned calibration records;
- canonical hashes of calibration parameter sets;
- validation for duplicate/missing nodes and invalid edges;
- deterministic provenance evidence hashing.

This enables traceability from a controller-visible derived signal back through estimators, filters, calibrations, buses, and original measurements.

## 8. Simulation Causality Microscope

The causality microscope traverses the same `EngineeringDependencyGraph` used by the consequence engine, but in the reverse direction from an observed anomaly. It performs bounded upstream traversal and ranks candidate root causes by a score combining:

- observed effect magnitude;
- accumulated path gain;
- accumulated confidence;
- node criticality;
- accumulated causal delay.

Each candidate includes its complete path to the observed node. Feedback graphs are handled with bounded traversal and explicit diagnostics rather than unbounded recursion.

## 9. Computational Reproducibility Capsules

The capsule builder creates a replayable filesystem capsule containing:

- canonical `capsule.json` manifest;
- canonical `configuration.json`;
- copied input/artifact files;
- SHA-256 for every copied artifact;
- SHA-256 of the configuration document;
- selected environment variables;
- source revision and model version;
- random seed;
- compiler identity;
- platform identity;
- executable identity;
- tags;
- executable `replay.sh`.

The verifier re-hashes configuration and artifacts and rejects tampering or missing required files. Capsule paths are sanitized and all required source artifacts are validated before capsule creation.

## 10. Cross-Layer Requirement Propagation

The requirement engine represents quantitative requirements as an acyclic parent/child budget graph. It implements:

- maximum and minimum requirement directions;
- measured leaf values;
- allocated child budgets;
- interface overhead;
- recursive effective-value aggregation;
- committed child-budget validation;
- requirement margin calculation;
- upstream violation-chain reconstruction;
- hypothetical measured-value change evaluation;
- graph cycle detection;
- deterministic evidence hashing.

This supports end-to-end latency, mass, energy, thermal, reliability, bandwidth, and similar engineering budgets across system layers.

## CLI and interactive exposure

The standalone advanced-platform CLI exposes:

```text
muzixdiagsys_advanced_platform engineering-intelligence capabilities [output.json]
muzixdiagsys_advanced_platform engineering-intelligence self-test DIRECTORY [output.json]
muzixdiagsys_advanced_platform engineering-intelligence DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

`engineering-intelligence` is also registered in the primary interactive advanced-command catalog. The public-facade source audit was updated so this platform is treated as a first-class command facade rather than an undocumented special case.

## Regression coverage

`tests/engineering_intelligence_platform_tests.cpp` exercises all ten capabilities directly, including:

- consequence propagation/path correctness;
- zonal E/E harness and diversity constraints;
- service request timing and fault-induced failure;
- clock drift/offset estimation;
- cross-domain conservation;
- identifiability and sloppiness;
- signal lineage and calibration hashing;
- causal root ranking;
- capsule verification and tamper detection;
- requirement propagation and violation behavior.

`tests/engineering_intelligence_cli_regression.py` verifies:

- the exact ten-domain capability inventory;
- declared reuse/integration invariants;
- 10/10 facade self-test execution;
- direct domain routing through the standalone CLI;
- numerical consequence output through the file-based CLI contract.

The existing interactive facade inventory regression was extended to include `EngineeringIntelligencePlatform`.

## Preservation and duplication policy

No production feature was removed. Existing feature-retention and duplicate-implementation regressions are part of validation. The implementation intentionally reuses or extends canonical E/E synthesis, conservation, identifiability, digest/provenance, and shared dependency-graph mechanisms where overlap exists.

## Validation status

Final validation on 2026-08-19 established the following:

- The working tree preserves every file from the supplied refactored input archive: **0 original files missing**.
- **13 existing files** were modified for integration and regression policy updates; **7 new approved source/test/report files** were added. No production feature file was deleted.
- The canonical source-package manifest contains **1,604 approved members**. Generated build trees, runtime state, HSM/private-key material, shell history, and cache files are excluded from the release package.
- The aggregate `aesim_test_artifacts` build completed successfully after the final hardening changes.
- Final warning scans of the affected build logs found **0 compiler warnings**.
- The new implementation/test surfaces contain **0 TODO/FIXME/stub/placeholder/not-implemented markers**.
- `EngineeringIntelligencePlatform::self_test` passes **10/10 domains**.
- The final targeted integration CTest group passes **13/13**, covering the new unit/CLI tests plus engineering validation, assured operations, digital thread, feature retention, source regression, warning policy, duplicate implementation, interactive facade discovery, command-surface, and README audits.
- The canonical source-package regression passes after adding the new approved members.
- Broad CTest execution completed successfully for **268 of 269 test entries exercised in this environment**. The remaining entry, `regulatory_cycle_tracking_regression`, is an intentionally long multi-cycle regression with a 900-second CTest timeout and did not complete inside the execution harness's shorter orchestration window; no test failure was observed before termination. A transient `ui_features_pty` failure occurred only under concurrent PTY execution and passed when rerun independently.

The release artifact is therefore packaged from the canonical approved-source manifest rather than from the build tree.


## Documentation closure (2026-08-19)

The user-facing documentation set now includes `docs/ENGINEERING_INTELLIGENCE_PLATFORM.md`, User Manual Chapter 91, the Engineering Intelligence tutorial workflow, advanced-platform CLI routing, README release notes, and documentation-index entries. The User Manual table of contents was also corrected to include Chapters 87-91, and its PDF is regenerated from the authoritative Markdown source. Documentation regressions explicitly retain the Chapter 91/domain vocabulary.

The same maintenance pass hardens `ui_streamlined_experience_pty.py` against PTY marker fragmentation. Ordered command-result/focus synchronization now uses one continuous buffer, eliminating the reported `FOC` / `US COMMAND` split-marker false timeout without altering production UI behavior.

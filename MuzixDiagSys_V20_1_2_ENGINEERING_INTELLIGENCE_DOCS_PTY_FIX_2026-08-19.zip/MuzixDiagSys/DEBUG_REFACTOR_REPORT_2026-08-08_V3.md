# Debug, Refactor, and Robustness Report — 2026-08-08 V3

**Project:** MuzixDiagSys Advanced Automotive Simulator  
**Scope:** C++/Python correctness hardening, persistence integrity, formal-model validation, runtime-adapter invariants, bounded-query behavior, and build qualification  
**Compatibility policy:** No existing simulator feature, command, alias, option, platform, model, public command family, or build option was removed or disabled.

## Executive summary

This pass was deliberately preservation-first. The supplied tree already contains a very large engineering and motorsports surface with substantial regression coverage, so changes were limited to defects that could be demonstrated from the implementation and protected with focused tests.

The complete Release production target, including the primary `muzixdiagsys` executable and its Formula One, IndyCar, NASCAR, advanced engineering, FMI, plugin, studio, and advanced-CLI dependency closure, builds and links successfully after the changes. The production command reference also executes successfully with `--help`.

## 1. Workspace persistence integrity and portability

The workspace serializer escaped reserved characters when writing, but the loader previously split records on every `|` character without respecting those escape sequences. A workspace name, tab title/URI/dashboard, expanded object, or filter containing a literal `|` could therefore be parsed into the wrong number of fields and fail to round-trip.

`WorkspacePersistence` now uses an escape-aware tokenizer that preserves escaped delimiters and backslashes until field-level unescaping. The loader additionally:

- accepts both LF and CRLF workspace files;
- rejects dangling escape sequences;
- parses schema versions, scroll offsets, and split ratios with strict non-throwing conversion helpers;
- rejects zero/invalid and future schema versions explicitly instead of silently coercing an unknown future format to the current schema;
- validates exact field counts for known record types;
- validates pinned flags, split orientation, and finite split ratios strictly inside `(0, 1)`;
- reports malformed input with a source line number;
- distinguishes read failures from normal EOF;
- continues to ignore unknown record types within a supported schema, preserving additive forward compatibility for metadata records.

The saver now clears stale caller error strings on entry, validates split geometry before writing, checks close/write completion, and reports a write failure if the persistence operation did not complete successfully.

## 2. UI bounded-query semantics and small performance corrections

`ContextGraph::search(query, 0)` and `VirtualizedRecordStore::page(offset, 0, filter)` previously could return one result because the limit was checked only after an insertion. Both now honor a zero-sized request exactly.

`ContextGraph::search` was also refactored so property matches use the same bounded insertion path as display-name/type/ID matches; this prevents the property branch from exceeding the requested result limit. The result vector reserves an appropriate bounded capacity.

`VirtualizedRecordStore::page` now computes its effective page size once, reserves that capacity, and stops exactly at the requested/cache-bound row count.

A direct `::isspace(char)` use in rich-form expression parsing was replaced with an unsigned-character-safe predicate, removing undefined behavior for negative signed-character values.

## 3. Probabilistic model-checker input integrity

The reachability checker previously validated transition probabilities but did not validate transition endpoints against the declared state set. Because value iteration used `map::operator[]`, a transition to an undeclared target could silently create a synthetic state value and produce a result from a malformed DTMC/MDP.

The expected-reward checker was less strict: it did not validate the initial state, transition probability range/sums, endpoints, rewards, or solver controls before iteration.

Both paths now share one validation routine covering:

- non-empty and unique declared state names;
- a declared initial state;
- declared target and avoid states;
- disjoint target/avoid terminal sets;
- declared transition source and target states;
- non-empty action names;
- finite probabilities in `[0, 1]`;
- finite transition rewards;
- per-state/per-action probability distributions summing to one within the existing numerical tolerance;
- finite positive convergence tolerance;
- a non-zero iteration budget.

After validation, iteration uses checked `.at()` state access rather than insertion-on-read, making undeclared-state corruption impossible in the solver path. The expected-reward semantics for valid models remain unchanged: `target_states` terminate reward accumulation while `avoid_states` retain their prior behavior for this API.

## 4. Python Gymnasium/PettingZoo adapter invariants

The RL wrappers previously merged user configuration after adapter-owned topology fields. A caller could therefore override `environments` or `agents_per_environment` while the Python observation/action spaces retained the constructor-requested dimensions. That could desynchronize the Gymnasium/PettingZoo API surface from the C++ batch backend.

The wrappers now preserve every other user-provided simulation setting while enforcing only the topology owned by each wrapper:

- `MuzixVehicleEnv`: exactly 1 environment and 1 agent;
- `MuzixVectorEnv`: constructor `num_envs` and exactly 1 agent per environment;
- `MuzixMultiAgentEnv`: exactly 1 environment and constructor `agents` per environment.

Backend timeout validation now rejects positive/negative infinity and NaN in addition to zero and negative values, preventing invalid values from reaching `subprocess.run()`.

## 5. Regression coverage added or expanded

`global_ui_architecture_tests.cpp` now covers escaped delimiter/backslash/newline round trips, zero-limit query behavior, CRLF input, malformed schema versions, future schemas, invalid numeric tab metadata, invalid split orientation/ratio, invalid save geometry, and zero-row virtualized pages.

`standards_deployment_platform_tests.cpp` now covers the original valid DTMC plus expected-reward convergence and negative cases for undeclared targets, non-normalized probability distributions, missing initial states, non-finite rewards, target/avoid conflicts, invalid tolerances, and zero iteration budgets.

`advanced_python_runtime_tests.py` now verifies non-finite/invalid timeout rejection and adapter-topology protection when optional Gymnasium/PettingZoo dependencies are available. The dependency-free C++ runtime portion remains executable when those optional Python packages are absent.

## 6. Documentation

`docs/GLOBAL_UI_ARCHITECTURE.md` now documents the escape-aware workspace format, CRLF compatibility, explicit rejection of unsupported future schemas, and non-throwing malformed-record diagnostics.

## Validation summary

The following were completed successfully in the supplied environment:

- Release CMake configure with GCC 14.2, Ninja, OpenSSL, SQLite, Zlib, hardening, strict numerics, and testing enabled.
- Complete `muzixdiagsys` production build and link: PASS.
- `muzixdiagsys --help`: PASS, return code 0.
- `global_ui_architecture_tests`: PASS in Release.
- `global_ui_architecture_tests`: PASS under AddressSanitizer + UndefinedBehaviorSanitizer.
- `standards_deployment_platform_tests`: PASS in Release.
- `advanced_python_runtime_tests.py` against `muzixdiagsys_advanced_platform`: PASS for the dependency-free backend; optional Gymnasium/PettingZoo and PyArrow portions reported unavailable because those packages are not installed in the validation image.
- Python `compileall` over `python/`, `tools/`, and `tests/`: PASS.
- Existing source-policy, documentation-consistency, user-manual, build-warning-policy, HIP-option-isolation, motorsports source, frontier source, and engineering-source regression scripts exercised during the audit: PASS.

The validation image does not provide a HIP compiler or MPI implementation, so native HIP/MPI device/distributed compilation was not possible. Those paths remain capability-detected and were not disabled or altered by this pass.

See `DEBUG_REFACTOR_VALIDATION_2026-08-08_V3.txt` for the condensed qualification record.

# Frontier Systems Implementation Report — 2026-08-07

## Scope and compatibility policy

This release adds twelve requested engineering domains to the existing MuzixDiagSys Advanced Automotive Simulator. The implementation is additive: no existing simulator feature, motorsport platform, public command family, command-line workflow, numerical-assurance subsystem, test, or documentation family was intentionally removed or hidden.

The production command surface is:

```text
muzixdiagsys_advanced_platform frontier-systems ...
```

The public C++ API is exported by:

```text
include/aesim/advanced/frontier_systems_platform.hpp
```

The implementation is compiled into `aesim_advanced` from four production translation units:

```text
src/advanced/frontier_systems_platform_a.cpp
src/advanced/frontier_systems_platform_b.cpp
src/advanced/frontier_systems_platform_c.cpp
src/advanced/frontier_systems_platform_d.cpp
```

Optional native dependencies are capability gated. Missing Kokkos, MPI/CUDA GPU-direct, or Enzyme capability is reported as unavailable; it is never represented by a fake successful native execution.

## Implemented domains

### 1. automotive-tsn-profile-conformance-laboratory

Implemented a deterministic automotive TSN engineering qualification model with:

- BMCA-style grandmaster selection using priority1, clock class, clock accuracy, offset-scaled log variance, priority2, and identity;
- initial clock offset, drift, wander, timestamp noise, timestamp quantization, synchronization interval, and synchronization-error limits;
- Ethernet serialization, propagation delay, bridge residence delay, guard bands, finite queue capacities, and failed-link state;
- supplied IEEE 802.1Qbv-style gate windows and deterministic Qbv schedule synthesis from stream demand;
- Qbu/802.3br-style preemption blocking using a configurable fragment size;
- Qci-style token policing, ATS/Qcr-style token shaping, and Qav-style idle-slope limits;
- primary and redundant route analysis, disjoint-route single-link-failure evidence, and earliest valid delivery;
- phase-aware Qbv delay bounds when deterministic phase information is preserved, with conservative maximum-closed-gate treatment when interfering traffic destroys phase knowledge;
- fixed-point same/higher-priority interference, lower-priority blocking, queue bounds, end-to-end latency certificates, and deadline qualification;
- legacy result aliases retained for compatibility (`policer_drops`, `deadline_misses`, and `worst_latency_us`) alongside v2 certificate fields;
- SHA-256 evidence sealing.

This is an engineering conformance laboratory and does not claim third-party IEEE certification.

### 2. native-scientific-data-interchange-platform

Implemented deterministic `write`, `read`, and `roundtrip` operations for multidimensional binary64 scientific arrays, shape metadata, units, and titles:

- Zarr v2 with `.zgroup`, `.zattrs`, per-array `.zarray`/`.zattrs`, and C-order little-endian binary64 chunks;
- native HDF5 datasets when HDF5 is detected;
- native NetCDF-4 variables/dimensions and unit metadata when NetCDF is detected;
- automatic parent-directory creation;
- strict name/unit/shape/value-count reconstruction;
- configurable round-trip numeric tolerance and evidence sealing.

On the qualification host, HDF5 1.14.5 and NetCDF 4.9.3 were detected and their native round trips were exercised.

### 3. mesh-field-interchange-and-insitu-visualization-platform

Implemented:

- VTK legacy ASCII unstructured-grid read/write;
- Gmsh 2.2 ASCII mesh read/write with point/cell field data;
- native VTKHDF unstructured-grid HDF5 read/write when HDF5 is available;
- explicit VTKHDF `Type`/`Version`, `Points`, `Connectivity`, `Offsets`, `Types`, point/cell/connectivity counts, `/VTKHDF/PointData`, `/VTKHDF/CellData`, and field unit metadata;
- vertex, line, triangle, quad, tetrahedron, and hexahedron topology;
- point- and cell-associated multi-component fields;
- deterministic topology/value round-trip qualification;
- in-situ geometric and field reduction (bounds, minimum, maximum, mean, and L2 norm) so complete fields need not be emitted for every run.

### 4. external-cae-solver-federation

Implemented real case generation for:

- OpenFOAM (`blockMesh` + `laplacianFoam` case tree);
- SU2 (`SU2_CFD` configuration/mesh);
- CalculiX (`ccx` input deck);
- Code_Aster (`MAIL`/`COMM`/export artifacts);
- Elmer (`ElmerSolver` mesh/SIF artifacts).

Execution mode performs direct process invocation without shell interpolation on POSIX, timeout/termination control, stdout/stderr capture, residual extraction, independent acceptance against a requested residual tolerance, executable discovery/capability reporting, multi-request federation, and evidence sealing. Regression coverage executes an actual temporary external solver process rather than a symbol-presence check.

### 5. portable-heterogeneous-kernel-runtime

Implemented AXPY, dot product, CSR sparse matrix-vector multiplication, and a three-dimensional seven-point stencil with:

- deterministic serial paths;
- native OpenMP paths when OpenMP is compiled;
- genuine optional Kokkos paths for all four operations when `Kokkos::kokkos` exists;
- safe Kokkos initialization/finalization ownership;
- deterministic dot-product accumulation through fixed host ordering after backend-side product evaluation;
- CSR index validation before parallel execution;
- explicit rejection of unknown/unavailable backends.

OpenMP was compiled and tested on the qualification host. Kokkos was not installed on the host and therefore was not falsely reported as available.

### 6. gpu-direct-pgas-communication-runtime

Implemented:

- deterministic local symmetric-memory qualification on every host;
- MPI RMA one-sided transfer through an MPI window when MPI is compiled and initialized;
- CUDA-device-memory MPI RMA attempt when both MPI and a working CUDA Runtime device are available;
- explicit `require_gpu_direct` qualification gating;
- rank/world-size/native capability reporting and SHA-256 evidence.

MPI/CUDA GPU-direct was not available on the qualification host; the native path remains capability gated rather than emulated.

### 7. certified-robust-control-synthesis-laboratory

Implemented:

- discrete algebraic Riccati iteration and LQR gain synthesis;
- positive Q/R dimensional and definiteness validation;
- uncertain `A_vertices` evaluation using one common feedback gain;
- common quadratic Lyapunov decrease matrix construction;
- Cholesky-based positive-definiteness margin search;
- closed-loop infinity-norm bound;
- sampled disturbance-to-output frequency response on the unit circle;
- configurable sampled gain acceptance and cryptographic evidence.

The frequency metric is intentionally labeled sampled; it is not represented as a continuous-frequency structured-singular-value theorem.

### 8. safety-critical-mpc-estimation-platform

Implemented three executable modes:

- `mpc`: finite-horizon linear-quadratic MPC with bounded inputs, adjoint gradients, forward rollout, control-barrier-function projection, disturbance tube bound, complete control sequence, terminal state, intervention accounting, barrier residual, and recursive-feasibility evidence;
- `mhe`: information-matrix moving-horizon estimation with prior/measurement variance weighting, observability propagation, state reconstruction, and measurement RMSE;
- `barrier-filter`: one-step barrier projection of an externally supplied control action.

Uncontrollable barrier constraints fail explicitly rather than returning a nominally safe result.

### 9. compiler-native-automatic-differentiation-runtime

Implemented a reverse-mode computational tape for constants, indexed variables, add/subtract/multiply/divide, sine, cosine, exponential, logarithm, square root, hyperbolic tangent, and fixed-exponent power. Gradients are independently validated by central finite differences.

When a real Enzyme LLVM plugin is supplied, `method=enzyme` emits a C translation unit, invokes Clang directly with the plugin, builds a derivative shared library, loads and executes it, and compares the compiler-generated derivative with the deterministic reverse-mode result. Clang was detected on the qualification host; an Enzyme plugin was not present and therefore was reported unavailable.

### 10. event-camera-neuromorphic-vision-platform

Implemented:

- log-intensity DVS event generation with positive/negative thresholds;
- deterministic per-pixel threshold mismatch;
- log-domain shot noise;
- refractory period and reference-level leak;
- Poisson background activity;
- timestamp interpolation and optional timestamp quantization;
- bandwidth saturation and dropped-event accounting;
- polarity counts, event centroid, and last-frame APS statistics;
- calibration mode estimating positive/negative thresholds from known log-intensity changes/event counts;
- early/late event-centroid optical-flow estimation;
- optional focal-length/depth conversion to angular-rate and lateral ego-motion estimates.

### 11. raw-radar-rf-adc-signal-chain-laboratory

Implemented a complete deterministic FMCW receive-chain simulation with:

- range, velocity, azimuth, amplitude, and phase target physics;
- target multipath components with excess range, velocity/azimuth offsets, amplitude scaling, and phase offsets;
- independent beat/Doppler interferers;
- MIMO receive-array spatial phase;
- independent phase noise and PLL phase random walk;
- sample-clock jitter and chirp nonlinearity;
- per-channel gain/phase/DC offsets and receive-channel coupling;
- I/Q gain and phase mismatch;
- complex Gaussian receiver noise;
- ADC clipping and finite-bit quantization;
- range resolution derived from the actual observed fast-time aperture;
- configured unambiguous range/velocity enforcement unless aliasing is explicitly requested;
- Hann-windowed range and Doppler DFTs;
- range-Doppler power cube generation;
- median-noise local-maximum detections;
- coherent receive-array beam scanning for azimuth;
- optional raw complex I/Q and bounded range-Doppler output.

### 12. semantic-physics-contract-system

Implemented executable cross-subsystem coupling contracts carrying:

- physical quantity and unit;
- frame and time basis;
- producer/consumer causality;
- conservation group;
- admissible source/target ranges;
- one-sigma uncertainty;
- numerical absolute and relative error budgets;
- differentiability class;
- interpolation and extrapolation policies.

The unit algebra spans mechanical, thermal, angular, pressure, energy/power, and electrical dimensions (current, voltage, resistance, capacitance, inductance, conductance, magnetic flux/flux density), plus common automotive units such as psi, mph, g0, and lb*ft. Affine Celsius/Kelvin conversion is supported.

Frame conversion requires an orthonormal proper 3x3 rotation with determinant +1 and supports optional translated position vectors with an explicit translation unit. Time-basis changes require bounded synchronization uncertainty. Transfer qualification checks source range before conversion, target range after conversion, differentiability compatibility, interpolation/extrapolation policy, combined uncertainty/error evidence, and optional maximum accepted uncertainty.

Conservation checks require common conservation-group identity, convert every signed term to a common unit, propagate uncertainty/error by root-sum-square, and evaluate the balance against absolute, relative, and sigma-weighted tolerance contributions.

## CLI and regression integration

The following existing surfaces were extended additively:

- `CMakeLists.txt`: new production sources, optional HDF5/NetCDF/OpenMP/Kokkos/CUDA integration, unit/source/CLI regressions;
- `include/aesim/advanced/platform.hpp`: exports the public frontier-systems API;
- `tools/advanced_platform_cli.cpp`: `frontier-systems capabilities`, `self-test`, and per-domain execution;
- `tests/frontier_systems_platform_tests.cpp`: algorithmic/native round trips, native CAE process execution, TSN synthesis/redundancy, event-camera calibration, radar estimation, physics-contract validation, and integrated self-test;
- `tests/frontier_systems_source_regression.py`: source/package/registration/no-unfinished-marker policy;
- `tests/frontier_systems_cli_regression.py`: production CLI discovery and execution;
- `examples/frontier_systems/*.json`: one canonical executable request for every domain.

## Documentation

Updated:

- `README.md`;
- `docs/DOCUMENTATION_INDEX.md`;
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`;
- `docs/FRONTIER_SYSTEMS_PLATFORM.md`;
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`;
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`.

The user manual now contains Chapter 65 for the preceding Frontier Expansion platform and Chapter 66 for Frontier Systems. The regenerated PDF is 308 pages and was rendered/visually inspected on the new chapter pages after the final documentation edits.

## Additional defects corrected while implementing the platform

- Native HDF5/NetCDF/VTKHDF writers now create missing parent directories consistently.
- TSN unlimited policing no longer consumes a finite burst bucket.
- Phase-aware Qbv certification avoids falsely assigning an arbitrary worst-cycle phase to exactly periodic streams while remaining conservative when interference removes phase information.
- VTKHDF now stores native unstructured-grid topology/field datasets rather than relying on a private complete-mesh payload.
- Optional Kokkos execution now performs all supported kernels through Kokkos and manages runtime ownership correctly.
- Raw radar rejects physically out-of-unambiguous-domain targets unless aliasing is explicitly requested.

## No-stub policy

The new production sources contain executable algorithms, binary/native file I/O, native process execution, numerical solvers, physical sensor simulation, scheduling/network analysis, control/estimation, automatic differentiation, integrity/evidence calculations, and validation logic. Optional native backends are compiled/executed only when their real dependencies are present. The source regression rejects unfinished implementation markers in the new production/API surface.

# Build Warning, Error, and Failure Fix Report

**Project:** MuzixDiagSys Advanced Automotive Simulator  
**Date:** 2026-08-07  
**Baseline:** Frontier Runtime, Positioning, and Sensing release

## Scope

This corrective pass addresses every warning and fatal failure present in the supplied GCC 16.1.1 / ROCm HIP build transcript without removing simulator functionality.

## Corrections

### Modern SQLite imported target

CMake now prefers `SQLite3::SQLite3` on current CMake releases and retains `SQLite::SQLite3` only as a compatibility fallback for older supported CMake versions. All project targets link through the selected `AESIM_SQLITE_TARGET`, eliminating the CMake 4.x deprecation warning.

### Sanitizer runtime preflight

When `AESIM_ENABLE_SANITIZERS=ON`, configuration now verifies that the selected host compiler can compile and link AddressSanitizer plus UndefinedBehaviorSanitizer before any project targets are built. An incomplete compiler/runtime installation therefore fails during configuration with an actionable diagnostic rather than failing late while linking the FMI library or a plugin.

Normal Release builds with `-DAESIM_ENABLE_SANITIZERS=OFF` remain completely free of sanitizer link options. Configuration prints the effective hardening, strict-numerics, sanitizer, LTO, SYCL, and HIP policy so accidental cache settings are visible immediately.

### HIP backend resource/error handling

`src/electrification/acceleration_hip.hip` was refactored to use exception-safe device-buffer ownership. Normal-path frees check the `hipFree` return code; exception cleanup consumes the return code without throwing from destructors. Kernel launches are followed by `hipGetLastError`, synchronization errors are checked, and zero-length requests return without an invalid zero-grid launch. This removes the `nodiscard` warnings while improving resource cleanup and launch diagnostics.

### Formula One cooling optimizer

The previously unused `heat_w` accumulator is replaced by `circuit_base_heat_w`, which is reused to calculate component heat shares. This preserves the previous share semantics and removes repeated `std::accumulate` work inside the component loop.

### Formula One survival-cell twin

The unused laminate `total_t` accumulator was removed. Ply thickness already participates directly in stiffness, tensile-capacity, and fracture-energy calculations, so removing the dead accumulator changes no model output.

### Regression guard

`tests/build_warning_policy_regression.py` permanently checks the modern SQLite target policy, sanitizer-runtime preflight, HIP RAII/checked-free/launch-error handling, zero-length HIP guard, and the two Formula One warning regressions.

## Validation

- Clean Release/LTO configure with hardening and strict numerics enabled: PASS, no CMake warnings.
- FMI shared library `aesim_powertrain.so`: PASS; the original late sanitizer link failure is absent with sanitizers disabled.
- Formula One performance laboratory tests: PASS.
- Formula One frontier laboratory tests: PASS.
- Build-warning policy regression: PASS.
- HIP/C++ compile-option isolation regression: PASS.
- Source-package regression: PASS.
- Documentation-consistency regression: PASS.
- Completed production/source compilation passes emitted no warnings or link failures before the remaining LTO-only test-link phase.

The validation host used for this corrective pass does not provide a ROCm/HIP compiler, so the HIP source was not device-compiled locally. The corrected backend is protected by the source regression and preserves the existing optional-HIP capability detection. The supplied build transcript demonstrates that the user's host does provide HIP; rerunning the full build there will exercise the corrected HIP translation unit directly.

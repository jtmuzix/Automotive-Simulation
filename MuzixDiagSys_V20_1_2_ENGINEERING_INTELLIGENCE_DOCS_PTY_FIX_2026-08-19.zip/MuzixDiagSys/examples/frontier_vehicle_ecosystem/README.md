# Frontier Vehicle Ecosystem Platform

This example area documents the integrated APIs in
`aesim/advanced/frontier_vehicle_ecosystem_platform.hpp`. The implementation is
part of `aesim_advanced` and requires no proprietary SDK for the default build.
Runtime adapters encode deterministic, checksummed frames that can be carried by
a vendor-specific transport process or gateway.

## C++ build and test

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DAESIM_BUILD_TESTS=ON
cmake --build build --target frontier_vehicle_ecosystem_platform_tests
ctest --test-dir build -R frontier_vehicle_ecosystem_platform --output-on-failure
```

## Included workflows

- CISPR-style corrected emissions and ISO 7637/11452 engineering calculations.
- MATLAB/Simulink S-function generation and deterministic HIL frames.
- Dense gradients, Jacobians, and vector-Jacobian products.
- Heavy truck, endurance racing, motorcycle, parking, traffic, occupant, GIS,
  sensor-cleaning, noise, particle-fate, and motorsport operations.
- Peridynamic, D2Q9 LBM, acoustic BEM, and isogeometric beam solvers.

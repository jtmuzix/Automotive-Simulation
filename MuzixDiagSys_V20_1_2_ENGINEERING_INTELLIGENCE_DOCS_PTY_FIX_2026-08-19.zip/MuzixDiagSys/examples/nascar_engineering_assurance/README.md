# NASCAR Engineering Assurance Canonical Requests

Run a domain with:

```bash
./build/muzixdiagsys_advanced_platform nascar-assurance DOMAIN REQUEST.json OUTPUT.json evidence
```

The twelve JSON files in this directory are complete executable inputs for the regulation, compliance, OEM, observation-fusion, officiating, contact, crash, fire, debris, composite, reliability, and optimal-test-design domains. Each successful result includes a deterministic `evidence_digest`.

# Next-generation platform API examples

The next-generation features are C++ APIs exposed through:

```cpp
#include "aesim/advanced/platform.hpp"
```

Build and run the comprehensive executable example/test:

```bash
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build --target next_generation_platform_tests -j
./build/next_generation_platform_tests
```

`tests/next_generation_platform_tests.cpp` is intentionally written as executable reference code. It demonstrates:

- construction, optimization, MLIR emission, and deterministic execution of simulation IR;
- safety-game and architecture synthesis;
- ONNX interval and deployment-equivalence checks;
- SDV service scheduling and updates;
- ML-KEM, ML-DSA, hybrid KEM, and HSM campaigns;
- NR-V2X, NTN, and edge tasks;
- USDA and deterministic synthetic datasets;
- Monte Carlo, cross-entropy, subset simulation, and FORM;
- multicore/cache/NPU timing;
- generated C compilation and MIL/SIL/PIL/HIL equivalence;
- manufacturing capability and genealogy;
- fleet prognostics and robust federated aggregation.

# Emerging Mobility examples

Run `./build/full/muzixdiagsys_advanced_platform emerging DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]`. Each JSON file maps to the same hyphenated domain name shown by `emerging capabilities`.

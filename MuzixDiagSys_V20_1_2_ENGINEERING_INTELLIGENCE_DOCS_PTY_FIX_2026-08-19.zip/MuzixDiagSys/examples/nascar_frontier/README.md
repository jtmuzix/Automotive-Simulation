# NASCAR Frontier Examples

Run any request from the repository root after building:

```bash
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN examples/nascar_frontier/REQUEST.json output.json output-directory
```

| Domain | Request |
|---|---|
| `in-season-challenge` | `in_season_challenge.json` |
| `rules-case-law` | `rules_case_law.json` |
| `fuel-mileage` | `fuel_mileage.json` |
| `tyre-supplier` | `tyre_supplier.json` |
| `setup-rig` | `setup_rig.json` |
| `rd-center` | `rd_center.json` |
| `technical-forensics` | `technical_forensics.json` |
| `accident-forensics` | `accident_forensics.json` |
| `driver-in-loop` | `driver_in_loop.json` |
| `team-logistics` | `team_logistics.json` |


## 2026-07-22 correctness checks

- `in-season-challenge`: completed rounds condition future probability; eliminated drivers must report zero probability.
- `rules-case-law`: invalid bulletins are rejected; disjoint violated-rule ranges return `RULE-PENALTY-CONFLICT` and `recommended_penalty: null`.
- `fuel-mileage`: total consumption equals delivered fuel, not unmet pickup demand.
- `team-logistics`: failed tasks consume no parts or resource time and cannot unblock dependents; declaration order does not override dependencies.

Focused validation:

```bash
cmake --build build/full --parallel --target \
  aesim_nascar nascar_frontier_platform_tests
ctest --test-dir build/full --output-on-failure \
  -R '^nascar_frontier_platform_unit_tests$'
```

# NASCAR Competition Platform Examples

Run the complete platform self-test:

```bash
./build/full/muzixdiagsys_advanced_platform nascar self-test \
  build/full/nascar-self-test build/full/nascar-self-test.json
```

Run an individual request:

```bash
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN \
  examples/nascar_competition/REQUEST.json \
  build/full/nascar-DOMAIN.json \
  build/full/nascar-artifacts
```

The ten domain identifiers are `cup-next-gen-vehicle`, `superspeedway-pack`,
`race-control`, `chase-championship`, `timing-smt`, `single-lug-pit-crew`,
`goodyear-tyre`, `track-surface`, `oss-inspection`, and `crash-safety`.


## Focused validation

```bash
cmake --build build/full --parallel --target \
  aesim_nascar nascar_competition_platform_tests
ctest --test-dir build/full --output-on-failure \
  -R '^nascar_competition_platform_unit_tests$'
```

The integrated `nascar self-test` executes all 40 NASCAR domains; this directory contains the original ten competition requests.

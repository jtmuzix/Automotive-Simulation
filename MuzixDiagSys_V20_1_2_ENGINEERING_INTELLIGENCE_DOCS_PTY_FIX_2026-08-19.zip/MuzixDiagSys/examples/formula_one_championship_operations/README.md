# Formula One Championship Operations Examples

Run any request with:

```bash
./build/full/muzixdiagsys_advanced_platform f1-operations DOMAIN REQUEST.json OUTPUT.json build/f1-operations-artifacts
```

Use `f1-operations capabilities` to list the ten domain identifiers.

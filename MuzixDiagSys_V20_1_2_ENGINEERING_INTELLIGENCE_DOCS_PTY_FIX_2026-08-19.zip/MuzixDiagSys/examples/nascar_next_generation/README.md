# NASCAR Next-Generation Examples

These requests exercise the ten domains documented in
`docs/NASCAR_NEXT_GENERATION_PLATFORM.md`. Run any file with:

```bash
./build/full/muzixdiagsys_advanced_platform nascar DOMAIN \
  examples/nascar_next_generation/FILE.json \
  build/examples/OUTPUT.json \
  build/examples
```

The examples are intentionally small, deterministic qualification inputs. Copy
an input before changing one parameter. Preserve both the baseline report and
its `evidence_digest` for comparison.

| Domain | File |
|---|---|
| `electrified-stock-car` | `electrified_stock_car.json` |
| `v8-combustion-fuel` | `v8_combustion_fuel.json` |
| `aero-raceability` | `aero_raceability.json` |
| `full-field-racecraft` | `full_field_racecraft.json` |
| `remote-race-control` | `remote_race_control.json` |
| `temporary-venue` | `temporary_venue.json` |
| `wheel-end-durability` | `wheel_end_durability.json` |
| `electrical-cyberphysical` | `electrical_cyberphysical.json` |
| `race-engineering-intelligence` | `race_engineering_intelligence.json` |
| `broadcast-streaming` | `broadcast_streaming.json` |

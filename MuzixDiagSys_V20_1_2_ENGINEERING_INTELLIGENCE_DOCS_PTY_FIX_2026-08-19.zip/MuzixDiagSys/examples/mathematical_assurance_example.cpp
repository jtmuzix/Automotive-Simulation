#include "aesim/core/mathematical_assurance.hpp"

#include <cmath>
#include <iostream>

int main() {
    using namespace aesim::core::math_assurance;

    const auto exact = exact_sum({1.0e16, 1.0, -1.0e16});
    std::cout << "exact sum: " << exact.exact_rational_numerator << '/'
              << exact.exact_rational_denominator << "\n";
    std::cout << "rounded binary64: " << exact.correctly_rounded_binary64 << "\n";

    auto problem = make_polynomial_precision_problem(
        {1.0, -2.0, 1.0}, 1.0 + 1.0e-8, "cancellation-sensitive polynomial");
    AdaptivePrecisionPolicy policy;
    policy.condition_estimate = 1.0e8;
    policy.minimum_verified_digits = 20.0;
    const auto precision = evaluate_adaptive_precision(problem, policy);
    std::cout << "selected precision: " << precision_tier_name(precision.selected_tier)
              << "\nverified digits: " << precision.verified_digits << "\n";

    ManufacturedPoisson1DProblem manufactured;
    manufactured.name = "sine Poisson reference";
    manufactured.exact_solution = [](double x) { return std::sin(3.14159265358979323846 * x); };
    manufactured.forcing_negative_second_derivative = [](double x) {
        constexpr double pi = 3.14159265358979323846;
        return pi * pi * std::sin(pi * x);
    };
    const auto convergence = run_manufactured_poisson_1d_test(manufactured);
    std::cout << "observed order: " << convergence.convergence.observed_order
              << "\nqualified: " << (convergence.passed ? "yes" : "no") << "\n";
    return convergence.passed ? 0 : 1;
}

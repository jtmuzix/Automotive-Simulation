# IndyCar Frontier Expansion Examples

The complete executable regression in `tests/indycar_frontier_expansion_platform_tests.cpp` supplies valid end-to-end inputs for all ten frontier domains:

1. 2028 2.4-liter power-unit co-design and homologation;
2. MGU/inverter/twenty-cell ultracapacitor electrothermal simulation;
3. gearbox, clutch, bellhousing, differential, and driveline durability;
4. hydraulic and carbon-brake simulation;
5. laser-scanned weather/grip evolution;
6. full-field racecraft;
7. synchronized video/telemetry incident reconstruction;
8. pit-lane vision officiating;
9. appeals and precedent review;
10. complete Indianapolis 500 Month-of-May operations.

Build and run the examples as tests:

```bash
cmake -S . -B build/indy-frontier -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_TESTING=ON
cmake --build build/indy-frontier --target \
  indycar_frontier_expansion_platform_tests --parallel "$(nproc)"
ctest --test-dir build/indy-frontier --output-on-failure \
  -R '^indycar_frontier_expansion_platform_unit_tests$'
```

The test intentionally includes valid and invalid cases. It is the canonical copy-ready C++ example because it is compiled under the same warning, hardening, strict-numerics, and sanitizer settings as the production library.

# NASCAR Ecosystem Examples

These requests exercise the ten additive NASCAR ecosystem domains through the existing `nascar` command family.

```bash
./build/full/muzixdiagsys_advanced_platform nascar multi-series examples/nascar_ecosystem/multi_series.json build/reports/multi_series.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar manufacturer-homologation examples/nascar_ecosystem/manufacturer_homologation.json build/reports/manufacturer_homologation.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar v8-transaxle-durability examples/nascar_ecosystem/v8_transaxle_durability.json build/reports/v8_transaxle.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar special-event-formats examples/nascar_ecosystem/special_event_formats.json build/reports/special_events.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar charter-team-economics examples/nascar_ecosystem/charter_team_economics.json build/reports/economics.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar pit-road-vision examples/nascar_ecosystem/pit_road_vision.json build/reports/pit_vision.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar radio-intelligence examples/nascar_ecosystem/radio_intelligence.json build/reports/radio.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar trackside-safety-drying examples/nascar_ecosystem/trackside_safety_drying.json build/reports/trackside.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar dvp-garage-repair examples/nascar_ecosystem/dvp_garage_repair.json build/reports/dvp.json build/reports
./build/full/muzixdiagsys_advanced_platform nascar wet-weather-visibility examples/nascar_ecosystem/wet_weather_visibility.json build/reports/wet_visibility.json build/reports
```

Every command returns exit code `0` when `passed` is true, `2` when a completed assessment returns `passed=false`, and `1` for invalid input or execution errors.


## Focused validation

```bash
cmake --build build/full --parallel --target \
  aesim_nascar nascar_ecosystem_platform_tests
ctest --test-dir build/full --output-on-failure \
  -R '^nascar_ecosystem_platform_unit_tests$'
```

These ten requests are the ecosystem layer of the 40-domain integrated self-test. Keep the checked-in request unchanged as a baseline and write modified experiments to a separate directory.

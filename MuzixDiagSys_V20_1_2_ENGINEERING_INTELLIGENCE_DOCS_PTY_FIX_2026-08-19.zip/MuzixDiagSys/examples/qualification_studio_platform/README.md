# Qualification and collaborative engineering examples

This directory contains compact inputs for the qualification/studio extension:

- `compliance_profile.json` demonstrates the machine-readable information used to configure a release-evidence profile.
- `example.a2l` exercises the native ASAP2/A2L parser and emitter.
- `example.arxml` exercises the deterministic AUTOSAR semantic-profile importer, validator, RTE generator, and exporter.

The complete executable reference workflow is `tests/qualification_studio_platform_tests.cpp`. Build and run it with:

```bash
cmake -S . -B build -DAESIM_BUILD_TESTS=ON -DAESIM_BUILD_TOOLS=ON
cmake --build build --target qualification_studio_platform_tests muzixdiagsys_advanced_platform -j
ctest --test-dir build -R 'qualification_studio_platform|advanced_platform_cli_self_test' --output-on-failure
```

The collaborative studio backend can export a self-contained static client containing `index.html`, `styles.css`, `app.js`, and a cryptographically identified `project.json` snapshot.

# Continuous Engineering Platform Examples

This directory contains deterministic inputs for the continuous-engineering
subsystems added to `aesim_advanced`.

## OpenSCENARIO compiler and coverage closure

`emergency_braking.osc2` demonstrates the supported typed scenario language:

- numeric and Boolean parameters;
- bounded parameter domains;
- actors and initial state;
- timestamped state actions;
- invariants;
- coverage goals; and
- metadata.

The C++ API compiles, executes, emits canonical source, and computes a bounded
coverage-closing test set:

```cpp
#include "aesim/advanced/platform.hpp"
#include <fstream>
#include <sstream>

std::ifstream input("examples/continuous_engineering_platform/emergency_braking.osc2");
std::stringstream source;
source << input.rdbuf();

aesim::advanced::OpenScenario2Compiler compiler;
auto compiled = compiler.compile(source.str());
if (!compiled.valid) {
    throw std::runtime_error("scenario compilation failed");
}

auto trace = compiler.execute(compiled.program,
                              {{"target_speed", 15.0}, {"wet", true}});
auto closure = compiler.close_coverage(compiled.program, 8, 512);
```

## Qualification

Build and execute the dedicated suite:

```bash
cmake -S . -B build -G Ninja \
  -DAESIM_BUILD_TESTS=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build --target continuous_engineering_platform_tests advanced_platform_cli
ctest --test-dir build -R 'continuous_engineering_platform|advanced_platform_cli_self_test' \
  --output-on-failure
```

The broader API and algorithm reference is in
`docs/CONTINUOUS_ENGINEERING_PLATFORM.md`.

# MuzixDiagSys Diagnostic Workflow Report

- **Case:** EXAMPLE-HV-001
- **Workflow:** ev-isolation — EV High-Voltage Isolation
- **Status:** active
- **Started:** 2026-07-13T21:01:44Z
- **Updated:** 2026-07-13T21:01:44Z

## Symptom

High-voltage insulation resistance is below the allowable threshold

## Evidence

| Class | Outcome | Step | Metric | Observed | Expected | Source | Note |
|---|---|---|---|---:|---|---|---|
| fact | pass | preconditions | hv_safety_interlock_ok | 1 bool | HV safety interlock and test authorization confirmed | HVIL monitor |  |
| model-derived | pass | preconditions | battery_voltage_v | 13.8 V | 12-V support voltage >= 11 V | electrical-supply-model |  |

## Branch Decisions

- **preconditions / pass:** Safety preconditions and low-voltage support are valid. → `confirm-isolation`

## Candidate Root Causes

No failed branch has established a candidate root cause.

## Repair Verification

Not completed. Use the workflow repair-verification command after corrective action.

## Evidence Semantics

- **fact:** directly observed sensor, DTC, freeze-frame, electrical, or physical-test evidence.
- **model-derived:** calculated by the simulator from authoritative model state.
- **heuristic:** ranked diagnostic inference that requires a confirming test.
- **missing:** required evidence has not been obtained.

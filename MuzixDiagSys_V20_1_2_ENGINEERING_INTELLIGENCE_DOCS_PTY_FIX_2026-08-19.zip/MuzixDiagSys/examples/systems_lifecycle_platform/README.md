# Systems and lifecycle engineering platform examples

The public umbrella header is:

```cpp
#include "aesim/advanced/platform.hpp"
```

The following test is a complete executable reference covering every subsystem:

```text
tests/digital_thread_lifecycle_tests.cpp
```

## SysML v2 and digital thread

`sysml_model.json` is accepted by `SysmlV2DigitalThread::import_sysml_v2_json`.
The model can be validated, traced, baselined, compared, impact-analyzed, and
exported as canonical JSON or SysML v2-style textual notation.

## Qualification

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --target digital_thread_lifecycle_tests \
  muzixdiagsys_advanced_platform -j
./build/digital_thread_lifecycle_tests
./build/muzixdiagsys_advanced_platform self-test \
  build/systems-lifecycle-self-test build/systems-lifecycle-self-test.json
```

The self-test JSON exposes these verdicts:

- `sysml_v2_digital_thread`
- `calibration_system_identification`
- `spice_emc_harness`
- `cell_resolved_battery_abuse`
- `ee_architecture_synthesis`
- `distributed_shared_world`
- `spectral_synthetic_data`
- `city_scale_infrastructure`
- `crash_occupant_biomechanics`
- `lifecycle_circular_economy`

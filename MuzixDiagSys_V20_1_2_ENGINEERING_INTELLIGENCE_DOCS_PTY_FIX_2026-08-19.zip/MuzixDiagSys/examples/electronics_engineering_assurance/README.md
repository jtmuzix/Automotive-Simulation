# Electronics engineering and assurance examples

The examples in this directory exercise the public APIs declared by:

- `aesim/advanced/electronics_power_distribution_platform.hpp`
- `aesim/advanced/electronics_circuit_conversion_platform.hpp`
- `aesim/advanced/embedded_electronics_assurance_platform.hpp`

Build and run the qualification binaries:

```bash
cmake -S . -B build/electronics -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_TESTING=ON
cmake --build build/electronics --parallel --target \
  electronics_power_distribution_platform_tests \
  electronics_circuit_conversion_platform_tests \
  embedded_electronics_assurance_platform_tests
ctest --test-dir build/electronics --output-on-failure \
  -R '^(electronics_power_distribution|electronics_circuit_conversion|embedded_electronics_assurance)_platform_unit_tests$'
```

`reference_connectivity.csv` is a deterministic ECAD connectivity input for `EcadImporter`. `reference_spice.cir` exercises SPICE-netlist connectivity import. The focused tests contain complete executable examples for all platform classes.

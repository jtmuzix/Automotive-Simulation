# Frontier Next executable examples

These sixteen JSON requests exercise every Frontier Next production domain through the permanent advanced-platform CLI.

```bash
./build/full/muzixdiagsys_advanced_platform frontier-next self-test \
  build/frontier-next/self-test-work build/frontier-next/self-test.json
```

Dedicated aliases are available for each request:

```text
wireless-phy       wireless_phy.json
secure-ranging     secure_ranging.json
complex-mu         complex_mu.json
stochastic-id      stochastic_id.json
protocol-verify    protocol_verify.json
static-verify      static_verify.json
native-solvers     native_solvers.json
gpu-comm           gpu_comm.json
adios2-stream      adios2_stream.json
mesh-interchange   mesh_interchange.json
ibis-ami            ibis_ami.json
heat-pump           heat_pump.json
nde-metrology       nde_metrology.json
model-maturity      model_maturity.json
scenario-coverage   scenario_coverage.json
model-form-uq       model_form_uq.json
```

Example invocation:

```bash
./build/full/muzixdiagsys_advanced_platform wireless-phy run \
  examples/frontier_next/wireless_phy.json build/frontier-next/wireless.json
```

Use `ALIAS capabilities` before requesting an optional native dependency such as PETSc, SUNDIALS, HYPRE, ADIOS2, CGNS, Exodus, MPI/CUDA, or NCCL.

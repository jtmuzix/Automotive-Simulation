# NHRA championship and strategy examples

Build the advanced platform CLI, then execute any request:

```bash
cmake -S . -B build/nhra -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_TESTING=ON
cmake --build build/nhra --parallel --target muzixdiagsys_advanced_platform nhra_championship_strategy_platform_tests

./build/nhra/muzixdiagsys_advanced_platform nhra national_divisional_points \
  examples/nhra_championship_strategy/mission_points.json \
  build/nhra/mission_points.result.json build/nhra/nhra-evidence
```

Replace the domain and request file with:

- `countdown_simulation` / `countdown.json`
- `mission_challenge` / `mission_challenge.json`
- `crew_chief_optimization` / `crew_chief.json`
- `causal_run_diagnosis` / `causal_diagnosis.json`
- `monte_carlo_event_strategy` / `event_strategy.json`
- `heritage_competition` / `heritage.json`

Every result contains a canonical SHA-256 evidence digest. Fixed seeds make stochastic studies reproducible.

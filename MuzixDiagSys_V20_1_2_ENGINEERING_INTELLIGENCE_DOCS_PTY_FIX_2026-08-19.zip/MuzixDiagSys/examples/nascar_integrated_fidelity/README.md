# NASCAR Integrated Fidelity Examples

Run any request with:

```bash
./build/muzixdiagsys_advanced_platform nascar-integrated DOMAIN REQUEST.json OUTPUT.json evidence
```

The directory contains one canonical request for each of the twelve integrated NASCAR domains.

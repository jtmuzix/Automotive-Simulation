# Advanced API CLI examples

`nominal_request.json` is the common minimal request accepted by the additive advanced API CLI adapters. Each adapter uses the request's `scale`, `seed`, and `strict` values to perturb or qualify a deterministic production-API scenario while permitting domain-specific additional fields.

Discover commands and generate per-command examples directly from the executable:

```bash
./build/full/muzixdiagsys_advanced_platform commands --compact
./build/full/muzixdiagsys_advanced_platform describe credibility
./build/full/muzixdiagsys_advanced_platform credibility example build/credibility-example.json
```

Execute a command:

```bash
./build/full/muzixdiagsys_advanced_platform credibility run   examples/advanced_api_cli/nominal_request.json   build/credibility.json build/credibility-evidence --profile --explain
```

The canonical exhaustive regression executes all 146 registered command self-tests through the production binary.

## Lifecycle and reproducibility examples

The lifecycle expansion includes runnable request examples for API contract/version inspection, legacy request migration, revisioned baseline capture, and integrity-only replay verification:

```bash
./build/full/muzixdiagsys_advanced_platform api-version show \
  examples/advanced_api_cli/api-version-show.json build/api-version-show.json
./build/full/muzixdiagsys_advanced_platform api-migrate request \
  examples/advanced_api_cli/api-migrate-request.json build/api-migrated.json
./build/full/muzixdiagsys_advanced_platform api-baseline capture \
  examples/advanced_api_cli/api-baseline-capture.json build/api-baseline-capture.json
./build/full/muzixdiagsys_advanced_platform api-replay verify \
  examples/advanced_api_cli/api-replay-verify.json build/api-replay-verify.json
```

For every other API, use `<command> example [output.json]` to emit a schema-consistent seed request before editing it for a study.


## Control / physical-system / co-simulation examples

Runnable request examples added for the 214-command revision:

- `control-synthesis.json`
- `nvh.json`
- `aftertreatment.json`
- `fmi-cosim.json`
- `depot-energy.json`
- `probabilistic-model-check.json`

Example invocation:

```bash
./build/full/muzixdiagsys_advanced_platform control-synthesis synthesize \
  examples/advanced_api_cli/control-synthesis.json build/control-result.json
```

The remaining commands expose their canonical requests with `<command> example --compact`; all are documented in `docs/CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md`.

# MuzixDiagSys Formula One Team and Competition Implementation Report

Date: 2026-07-18

## Scope

This release adds five executable Formula One systems without removing or replacing existing behavior:

1. Multi-car race dynamics and racecraft laboratory.
2. Pit-stop, garage, and trackside-operations digital twin.
3. Sporting-regulation, race-control, and stewarding engine.
4. Trackside sensor-metrology and correlation campaign manager.
5. Competitor intelligence, game theory, and championship optimizer.

The built-in sporting profile identifies the FIA 2026 Formula One Section B Sporting Regulations, Issue 07, published 2026-06-25. The profile and rule collection are data-driven so later issue records can be supplied without changing the adjudication engine.

## Added source

- `include/aesim/advanced/formula_one_team_competition.hpp`
- `src/advanced/formula_one_team_competition.cpp`
- `tests/formula_one_team_competition_tests.cpp`
- `docs/FORMULA_ONE_TEAM_COMPETITION.md`
- `FORMULA_ONE_TEAM_COMPETITION_IMPLEMENTATION_REPORT_2026-07-18.md`
- `FORMULA_ONE_TEAM_COMPETITION_VALIDATION_2026-07-18.txt`

## Modified integration files

- `CMakeLists.txt`
- `README.md`
- `include/aesim/advanced/platform.hpp`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf`

## Multi-car race dynamics and racecraft

`F1MultiCarRacecraftLaboratory` advances a vector of car states on a periodic circuit. The implementation includes power- and brake-driven longitudinal acceleration, quadratic drag, curvature-dependent speed limits, bounded lateral response, electrical deployment, lap wrapping, pairwise wake interaction, cooling loss, side-by-side detection, collision probability, deterministic geometric contact, contact speed loss, aerodynamic damage, and race ordering by unwrapped distance.

`choose_racecraft_command` uses gap, overtaking quality, relative speed, tire grip, and state of charge to select an attack line, energy deployment, throttle/brake demand, or defensive state.

## Pit-stop and garage operations

`F1TracksideOperationsTwin` executes pit tasks as a dependency graph. It reserves role-qualified crew and equipment, accounts for reaction time, skill, fatigue, equipment cycle time, reproducible duration variation, equipment reliability, failure recovery, double stacking, and release traffic gap. Cycles and missing dependencies are rejected.

Garage work orders respect predecessor completion, technician capacity, serialized inventory, parts consumption, and deadlines.

## Sporting, race control, and stewarding

`F1SportingRaceControlEngine` stores active green/yellow/VSC/safety-car/red-flag and related commands, evaluates required delta, and adjudicates supported incident evidence against the selected profile. Implemented incident categories are track limits, pit speeding, unsafe release, yellow-flag overtaking, collision, impeding, jump start, and VSC delta.

Decisions include rule identifier, infringement, penalty, uncertainty-aware confidence, severity, reasoning, and canonical SHA-256 evidence. The subsystem is engineering decision support rather than an official FIA determination.

## Trackside metrology and correlation

`F1TracksideMetrologyCampaign` validates sensor identity, calibration, uncertainty, bandwidth, sample rate, and Nyquist compliance. It applies scale, bias, drift, time-offset correction, and uncertainty propagation.

Channel correlation uses the shared qualification-grade column-pivoted QR implementation with uncertainty weights. Reports include scale, bias, RMSE, uncertainty-normalized RMS, stable correlation, observation count, three-sigma outliers, synchronization dispersion, overall score, and evidence.

## Competitor intelligence and championship optimization

`F1CompetitorGameTheoryOptimizer` maintains beliefs for pace, pit loss, degradation, reliability, aggression, and wet skill. Lap and pit observations perform scalar Bayesian updates; finish/retirement observations update reliability.

A reproducible Monte Carlo optimizer evaluates attack, defend, pit, extend, conserve, undercut, and overcut actions. It accounts for pace uncertainty, tire age, electrical attack benefit, action cost, pit loss, safety-car advantage, rain probability, and stochastic reliability. It returns finish-position expectation, win/podium probabilities, points, championship value, all action values, rationale, and evidence.

## Defects corrected during validation

- The initial racecraft regression requested too little target-speed margin to overcome modeled aerodynamic drag; the test was corrected to exercise genuine positive net acceleration.
- Severity escalation initially changed a strict pit-speeding profile penalty from five to ten seconds. Escalation was restricted so the profile-defined pit-speed penalty is preserved.
- A misleading-indentation warning and an unused helper were removed before final validation.

## Compatibility

No established public class, function, command, target, plugin, package format, or test was removed. The new module is additive and is re-exported through `aesim/advanced/platform.hpp`.

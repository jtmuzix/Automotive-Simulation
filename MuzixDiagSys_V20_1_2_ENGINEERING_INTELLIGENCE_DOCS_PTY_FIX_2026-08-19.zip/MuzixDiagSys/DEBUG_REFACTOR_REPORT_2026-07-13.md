# MuzixDiagSys Debug and Refactor Report

**Date:** 2026-07-13
**Configuration validated:** Linux, CMake/Ninja, Debug, C++17, SYCL disabled, HIP disabled

## Scope

This pass concentrated on reproducible defects and diagnostic-architecture drift without removing simulator features. The changes preserve the existing CLI and compatibility interfaces while moving protocol semantics toward the authoritative `aesim::industrial::DiagnosticService` implementation.

## Defects corrected

### 1. Stale OBD-II Mode 02 freeze frames

`DiagnosticService::update_live_data()` preserved a freeze frame indefinitely after confirmed DTCs were cleared. A later diagnostic episode could therefore report operating data from an unrelated earlier fault.

The corrected lifecycle is:

1. Capture the pre-fault operating point on the clean-to-confirmed-fault transition.
2. Preserve that snapshot while confirmed faults remain active.
3. Reset the snapshot when the authoritative confirmed-DTC list becomes empty.
4. Capture a new snapshot for the next independent fault episode.

The local fallback state in `SocketCanObdResponder` now follows the same rules.

### 2. Case-sensitive paths corrupted by command parsing

Several command dispatch branches lowercased every token. On case-sensitive filesystems, an export such as:

```text
combustion export /.../MuzixDiagSys/.../Trace.CSV
```

was changed to a different path containing `/muzixdiagsys/` and `trace.csv`. The exporters then failed even though their own file-writing logic was correct.

The parser now preserves non-keyword arguments for combustion, thermal, tire, chassis, and safety commands. Each subsystem remains responsible for case-insensitive interpretation of its own command keywords. A dedicated mixed-case-path regression covers all five export families.

### 3. DTC formatting helper mutated the running vehicle

The legacy `dtc_to_obd_bytes()` helper updated the global authoritative diagnostic service merely to format a DTC. Calling a display/formatting function could therefore replace live DTCs, alter MIL state, and change freeze-frame state.

The helper now uses an isolated `DiagnosticService` instance. Formatting is side-effect free.

### 4. Unconditionally failing CTest registration

CTest registered `tests/build_footprint_regression.py`, but the script was absent. The test now exists and validates:

- the primary executable;
- the compatibility launcher;
- symlink behavior on Unix;
- build-local runtime resources; and
- native plugins that do not escape into the source tree.

### 5. QA checks referenced the obsolete launcher translation unit

The command-completion and user-manual regressions still inspected the five-line `src/muzixdiagsys.cpp` launcher after runtime and UI logic had moved elsewhere. They now inspect the actual command registry, simulation runtime, and console frontend.

### 6. Source packager excluded legitimate files beginning with `build`

The source-packaging filter applied build-directory detection to every path component, including the filename. As a result, a legitimate source file such as `tests/build_footprint_regression.py` was silently omitted from the release archive.

The filter now evaluates directory components only and recognizes `build`, `build-*`, and `cmake-build-*` directories without excluding ordinary source filenames. The package regression explicitly requires the new diagnostics implementation and both added regression scripts.

## Refactoring performed

### Legacy diagnostics facade moved out of a header

`include/modules/can_uds.hpp` is now a declaration-oriented compatibility header. Its implementation moved to:

```text
src/industrial/diagnostic_compat.cpp
```

This removes dense header-only protocol glue, reduces recompilation exposure, improves error handling for UDS DIDs, and makes it explicit that OBD/UDS semantics delegate to the industrial diagnostics library.

### Responder synchronization centralized

Repeated `DiagnosticService` snapshot-copy blocks in `SocketCanObdResponder` were consolidated into `refresh_diagnostic_snapshot_locked()`. The default constructor now delegates to the authoritative-service constructor, so initialization and binding follow one path.

### Command argument extraction centralized for affected paths

The affected command families now use a shared `read_command_arguments()` helper that preserves user data. Command normalization is limited to semantic keywords inside each subsystem.

## Regression coverage added or expanded

- Two independent freeze-frame episodes, including reset and recapture.
- Compatibility DTC encoding purity against the authoritative service.
- Mixed-case absolute export paths for safety, combustion, thermal, tire, and chassis artifacts.
- Build-footprint and plugin-staging checks.
- Architecture-aware command-completion and documentation audits.

## Validation results

- Clean CMake configure and Ninja Debug build: **PASS**
- Diagnostic authority unit tests: **PASS**
- CAN/OBD synthesis unit tests: **PASS**
- Professional operations regression: **PASS**
- Professional feature regression: **PASS**
- Research-level regression: **PASS**
- Mixed-case path regression: **PASS**
- All non-regulatory registered tests, exercised across the full run and the new targeted test: **97/97 PASS**
- Regulatory-cycle tracking regression: **PASS (289.40 seconds)**
- Overall registered CTest coverage, exercised across the full and isolated runs: **98/98 PASS**
- Focused ASan/UBSan diagnostic validation: **PASS (2/2 focused diagnostic suites)**
- Deterministic source-package regression and exact-archive required-file audit: **PASS**
- Exact packaged-source CMake configuration and `aesim_diagnostics` rebuild: **PASS**

## Documentation regeneration

The 2026-07-13 documentation set was synchronized after the code fixes. The authoritative Markdown User Manual now documents the diagnostic service, corrected freeze-frame lifecycle, ELM, DoIP, and SOVD entry points, shared ISO-TP/CAN-FD behavior, kernel backend boundary, measured-data workflow, case-sensitive paths, package validation, and current test evidence. `docs/MUZIXDIAGSYS_USER_MANUAL.pdf` was regenerated from the Markdown source and visually and structurally validated. The README, CAN/OBD platform guide, SocketCAN responder guide, and command-registry guide were updated in the same pass.

## Remaining structural debt

The primary launcher is already minimal, but two translation units remain disproportionately large:

- `src/simulation_runtime.cpp` — 12,541 lines
- `src/ui/console_frontend.cpp` — 7,066 lines

They should be split incrementally along stable domain boundaries rather than by arbitrary line count. Recommended next seams are command parsing/dispatch, report/export services, vehicle-control commands, simulation orchestration, terminal rendering, completion, history/preferences, and PTY event handling. This pass intentionally avoided a high-risk bulk split while active defects were still being isolated.

## Reproduction commands

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DAESIM_ENABLE_SYCL=OFF \
  -DAESIM_ENABLE_HIP=OFF
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

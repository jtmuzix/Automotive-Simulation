# MuzixDiagSys SocketCAN OBD-II Responder Implementation Report

**Implementation date:** 2026-07-12  
**Baseline:** `advanced_engine_sim_can_obd_data_synthesis_complete_2026-07-12`  
**Primary executable:** `muzixdiagsys` (`engine_sim` remains a compatibility launcher)  
**Language standard:** C++17

## 1. Objective

This revision adds a persistent vehicle-side SocketCAN OBD-II responder to MuzixDiagSys. The existing diagnostic tester/client, loopback virtual ECU, CAN/CAN-FD capture, OBD decoding, trace analysis, and data-synthesis features remain available.

The responder allows MuzixDiagSys to behave as an ISO 15765-4 engine ECU on an isolated CAN bench network. It listens for functional or physical requests from an external scan tool, obtains values from the active simulation, and transmits standards-oriented OBD-II responses.

## 2. Architectural integration

The implementation is centered on `aesim::industrial::SocketCanObdResponder` and reuses MuzixDiagSys's existing `CanTransport`, `CanFrame`, SocketCAN, ISO-TP, OBD encoding, and live-vehicle data structures.

The data flow is:

```text
MuzixDiagSys vehicle plant
    -> thread-safe immutable OBD snapshot
    -> OBD service dispatcher
    -> ISO-TP response segmentation
    -> guarded SocketCAN transmit path
    -> external OBD-II reader
```

Incoming traffic follows the reverse path:

```text
SocketCAN receive worker
    -> request-address filtering
    -> ISO-TP request reassembly
    -> OBD service/PID validation
    -> response construction
```

The responder is separate from the existing OBD tester/client. Both functions continue to coexist.

## 3. Persistent responder service

Implemented a long-running responder with:

- Background receive/transmit worker.
- Deterministic start and stop lifecycle.
- Defensive shutdown in the destructor.
- Thread-safe live-state publication.
- Thread-safe diagnostic state.
- Configurable P2 delay and polling period.
- Response-rate limiting.
- Bounded request and log storage.
- Timestamped RX/TX audit records.
- Loopback injection for deterministic qualification.
- Native Linux SocketCAN transport for physical operation.

The responder accepts classical CAN or CAN-FD framing. Classical ISO 15765-4 operation remains the default for conventional OBD-II readers.

## 4. Addressing

Default 11-bit identifiers are:

| Function | CAN identifier |
|---|---:|
| Functional request | `0x7DF` |
| Physical engine request | `0x7E0` |
| Engine response | `0x7E8` |

All identifiers are configurable. The implementation also supports a consistent 29-bit addressing set. Validation prevents accidental mixing of 11-bit and 29-bit identifiers and rejects duplicate request/response identifiers.

Functional and physical request acceptance can be enabled independently.

## 5. ISO-TP implementation

The responder implements both request-side reassembly and response-side segmentation:

- Single Frame.
- First Frame.
- Consecutive Frame.
- Flow Control Continue To Send.
- Flow Control Wait.
- Flow Control Overflow/Abort.
- Sequence-number validation.
- Request-side block-size enforcement.
- Response-side block-size handling.
- Configurable STmin.
- Millisecond and 100-microsecond STmin decoding.
- Flow-control timeout.
- Bounded payload size.
- Prevention of response interleaving while a multi-frame exchange is active.

Long VIN, calibration, ECU-name, and DTC responses therefore use the same multi-frame exchange expected by an ISO-TP-capable reader.

## 6. OBD-II services

Implemented vehicle-side handling for:

| Mode | Capability |
|---:|---|
| `01` | Current powertrain data and readiness |
| `02` | Freeze-frame data |
| `03` | Confirmed/stored DTCs |
| `04` | Clear confirmed and pending DTCs |
| `06` | Onboard monitor result |
| `07` | Pending DTCs |
| `09` | Vehicle information |
| `0A` | Permanent DTCs |

Unsupported services and unsupported PIDs produce standards-oriented negative responses rather than silent success.

### Mode 01 additions

The shared virtual ECU now includes:

- PID `01`: MIL, confirmed-DTC count, ignition type, and readiness state.
- PID `03`: fuel-system status.
- PID `1C`: OBD standard.
- PID `21`: distance traveled with MIL active.
- PID `30`: warm-up cycles since DTC clear.
- PID `31`: distance since DTC clear.
- PID `4D`: time with MIL active.
- PID `4E`: time since DTC clear.

Previously supported live engine, speed, temperature, airflow, fuel, voltage, torque, and emissions-related PIDs remain intact.

### Mode 09 identity

The responder provides:

- PID `00`: exact supported-information bitmap.
- PID `02`: VIN.
- PID `04`: calibration identifier.
- PID `06`: deterministic calibration verification number.
- PID `0A`: ECU name.

## 7. Diagnostic state

The diagnostic model now maintains separate stores for:

- Confirmed/stored DTCs.
- Pending DTCs.
- Permanent DTCs.

DTCs are validated, normalized to uppercase, and support `P`, `C`, `B`, and `U` categories.

The first confirmed DTC captures a freeze-frame snapshot. Live RPM, speed, temperature, and load updates do not overwrite the diagnostic identity, DTC stores, readiness state, or captured freeze frame.

Mode 04 behavior is policy controlled:

- When allowed, it clears confirmed and pending DTCs.
- Permanent DTCs are retained.
- When denied, the responder returns `7F 04 22`.

## 8. Readiness and MIL behavior

The responder exposes:

- MIL state.
- Confirmed-DTC count.
- Spark-ignition or compression-ignition selection.
- Supported non-continuous monitor mask.
- Completed monitor mask.
- Distance/time/warm-up counters.

These values are encoded into Mode 01 PID 01 and related PIDs.

## 9. Live MuzixDiagSys binding

The responder is integrated into `AutomotiveLabPlatform::update_live_bus`. The active simulation publishes:

- Engine RPM.
- Vehicle speed.
- Calculated load.
- Coolant and intake-air temperature.
- MAP and barometric pressure.
- Mass airflow.
- Throttle and accelerator position.
- Equivalence ratio.
- Catalyst temperature.
- Low-voltage module voltage.
- Fuel rate and fuel level.
- Commanded, actual, and reference engine torque.
- Odometer.

Dynamic plant values update continuously while diagnostic configuration remains persistent.

## 10. Safety controls

Physical transmission is deliberately guarded.

Selecting a real SocketCAN interface or changing addressing automatically disarms the responder. A physical responder can start only after the operator explicitly enters:

```text
industrial vehicle experience lab obd-server arm isolated-bench
```

This guard reduces the risk of unintentionally placing an emulated ECU on a live road vehicle network.

The documentation explicitly requires:

- An isolated bench network.
- Correct CAN transceiver and termination.
- Correct bitrate.
- Fused power for the scan tool.
- No simultaneous connection to a real vehicle ECU network.

MuzixDiagSys does not supply electrical power or termination through software.

## 11. Command interface

The following aliases address the same subsystem:

```text
obd-server
obd-responder
ecu-emulator
```

Principal operations include:

```text
interface loopback
interface socketcan <interface> [classic|fd]
arm isolated-bench
disarm
start
stop
status
stats
ids <functional> <physical> <response>
timing <p2_ms> <flow_timeout_ms> <stmin_byte> <block_size> [max_fps]
accept functional|physical|both
mode04 allow|deny
padding <hex>
identity <vin> <calibration_id> <ecu_name...>
dtc add|remove <stored|pending|permanent> <code>
dtc clear [all|stored|pending|permanent]
readiness <supported_hex> <complete_hex> <spark|compression>
simulate-request <functional|physical|hex_id> <payload...>
log [count]
log-clear
export-log <file.jsonl>
```

All operations are integrated into nested Tab completion.

## 12. Audit logging

Responder traffic can be exported as JSON Lines using schema:

```text
aesim.obd-responder-log.v1
```

Each record contains:

- Timestamp.
- Direction.
- CAN identifier.
- Payload.
- Event description.

This allows deterministic review of requests, responses, ISO-TP control frames, and rejected operations.

## 13. Tests added and expanded

The C++ suite now verifies:

- Functional addressing.
- Physical addressing.
- 29-bit addressing.
- Rejection of mixed-width identifiers.
- Live PID scaling.
- MIL/readiness encoding.
- DTC normalization.
- Confirmed, pending, and permanent stores.
- Freeze-frame persistence.
- Mode 04 allow and deny policies.
- Permanent-code retention.
- Multi-frame VIN transmission.
- Tester flow-control processing.
- Tester-to-ECU multi-frame request reassembly.
- Request block-size enforcement and repeated flow control.
- JSONL audit output.
- Persistent worker-thread operation through loopback transport.
- Physical start rejection until explicit bench arming.
- Preservation of diagnostic state during live plant updates.

A dedicated end-to-end CLI regression validates the public command path and exported audit log.

## 14. Compatibility

The revision preserves:

- Existing CAN and CAN-FD gateway functions.
- Existing OBD-II tester/client operation.
- Existing internal virtual ECU.
- Existing data synthesis, DBC, candump, CSV, and JSONL export.
- Existing GUI/TUI composition.
- Existing command aliases and completion structure.
- Existing vehicle, industrial, professional, lifecycle, research, federation, and assurance systems.

The golden-frame terminal regression passed.

## 15. Qualification results

Passed:

- Complete GNU Debug build at 100%.
- Main `muzixdiagsys` compile and link.
- Every existing library, plugin, tool, and compiled test target.
- Dedicated CAN/OBD C++ unit suite.
- Dedicated SocketCAN OBD responder CLI regression.
- Existing CAN/OBD gateway and synthesis CLI regression.
- Exhaustive command completion audit.
- Command-surface regression.
- Golden-frame TUI regression.
- Modified-file Python syntax check.
- Modified-file placeholder and whitespace audit.
- GNU Release compilation of all modified C++ translation units.

Completion coverage:

```text
Root commands:   229
Command paths:   16,226
Nested checks:   16,029
```

## 16. Hardware qualification boundary

No physical CAN adapter or external OBD-II reader was available in the delivery environment. Creation of a Linux `vcan` interface was denied by container network privileges.

Accordingly:

- The native SocketCAN code path compiles.
- All modified translation units compile under Debug and Release optimization.
- The persistent receive worker, request dispatcher, ISO-TP state machine, and transmit path are qualified using loopback transport.
- Actual adapter drivers, CAN electrical levels, bitrate, termination, scan-tool protocol detection, and bench wiring remain target-hardware qualification items.

This limitation is not represented as a physical-reader pass.

## 17. Primary changed files

- `include/aesim/industrial/can_obd.hpp`
- `include/aesim/experience/automotive_lab.hpp`
- `src/industrial/can_obd.cpp`
- `src/industrial/platform.cpp`
- `src/vehicle/automotive_lab.cpp`
- `tests/can_obd_synthesis_tests.cpp`
- `tests/can_obd_synthesis_cli_regression.py`
- `tests/socketcan_obd_responder_cli_regression.py`
- `docs/SOCKETCAN_OBD_RESPONDER.md`
- `data/lab/obd_responder_demo_commands.txt`
- `CMakeLists.txt`
- `README.md`

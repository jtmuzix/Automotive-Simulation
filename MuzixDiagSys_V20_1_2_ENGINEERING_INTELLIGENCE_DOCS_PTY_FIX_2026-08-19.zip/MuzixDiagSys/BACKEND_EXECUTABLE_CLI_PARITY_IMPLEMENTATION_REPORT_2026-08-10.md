# Backend Executable / Interactive-Shell Parity Implementation Report

**Project:** MuzixDiagSys Advanced Automotive Simulator  
**Date:** 2026-08-10  
**Input baseline:** V6 debugged/refactored/deduplicated source package  
**Change policy:** additive/conservative; no existing non-duplicate feature removed

## Executive summary

The primary authenticated `muzixdiagsys` interactive shell now exposes a fully functional equivalent command surface for **every non-test backend/tool executable declared by the top-level CMake build**. The implementation avoids command duplication: standalone executables and interactive commands call the same reusable C++ runners/dispatchers.

Nine backend/tool executables are covered:

1. `muzixdiagsys_advanced_platform`
2. `muzixdiagsys_engineering`
3. `muzixdiagsys_causal_lab`
4. `muzixdiagsys_advanced_safety`
5. `muzixdiagsys_specification_discovery`
6. `muzixdiagsys_standards_deployment`
7. `muzixdiagsys_frontier_professional`
8. `aesim_study_worker`
9. `research_reference_generator`

The primary `muzixdiagsys` executable itself is not counted as a backend because it is the interactive host.

## Interactive mappings

| Standalone executable | Canonical direct interactive root | Collision-safe namespace |
|---|---|---|
| `muzixdiagsys_advanced_platform` | `advanced-platform ...` | `backend advanced-platform ...` |
| `muzixdiagsys_engineering` | `engineering-cli ...` | `backend engineering-cli ...` |
| `muzixdiagsys_causal_lab` | `causal-lab ...` | `backend causal-lab ...` |
| `muzixdiagsys_advanced_safety` | `advanced-safety-cli ...` | `backend advanced-safety-cli ...` |
| `muzixdiagsys_specification_discovery` | `specification-discovery ...` | `backend specification-discovery ...` |
| `muzixdiagsys_standards_deployment` | `standards-deployment ...` | `backend standards-deployment ...` |
| `muzixdiagsys_frontier_professional` | `frontier-professional ...` | `backend frontier-professional ...` |
| `aesim_study_worker` | `study-worker ...` | `backend study-worker ...` |
| `research_reference_generator` | `research-reference-generator ...` | `backend research-reference-generator ...` |

`backend list` provides runtime discovery.

## Architecture

### Reusable backend-runner API

Added `include/aesim/app/backend_cli.hpp` with reusable runners and descriptor/registry functions.

### Shared registry

Added `tools/backend_cli_registry.cpp`. It owns the standalone backend inventory, canonical shell roots, aliases, completion operations, in-process dispatch, authenticated-shell session state, and interactive backend error-stream bridging.

### Thin standalone `main()` wrappers

The previous monolithic standalone entry points were split so implementation code can be reused without embedding another program's `main()`:

- `tools/engineering_main.cpp`
- `tools/causal_simulation_main.cpp`
- `tools/advanced_safety_main.cpp`
- `tools/specification_discovery_main.cpp`
- `tools/standards_deployment_main.cpp`
- `tools/frontier_professional_main.cpp`
- `tools/study_worker_main.cpp`
- `tools/research_reference_generator_main.cpp`

The implementation files now export runner functions. The executable wrappers call those runners directly; the interactive registry calls the same runners.

### Advanced-platform dispatcher

`muzixdiagsys_advanced_platform` was already implemented through the shared `aesim::advanced_cli` dispatcher. The interactive roots `advanced-platform ...` and `backend advanced-platform ...` route to that same dispatcher, preserving the existing `advanced ...` namespace and direct advanced roots.

## Engineering authentication equivalence

A standalone `muzixdiagsys_engineering` process retains its independent credential-file authentication contract.

Inside the primary shell, the operator has already authenticated. The backend bridge now records the authenticated shell session and invokes the engineering runner with the existing `UserIdentity` and authentication database. This provides true interactive equivalence for all shell authentication modes instead of requiring a second credential file or relying on `MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE`.

Security controls remain active:

- engineering permission checks remain unchanged;
- the engineering audit-log chain is verified before command execution;
- engineering commands still append success/failure audit events;
- the inherited identity does not gain permissions beyond the authenticated shell account.

The parity regression explicitly removes `MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE` from the interactive environment and proves that engineering commands still execute through authenticated-session inheritance.

## Argument handling

Backend arguments read by the interactive runtime now support quoted values, including whitespace-containing paths. Both single-quoted and double-quoted arguments are recognized; escaped spaces/quotes are handled without treating ordinary path backslashes as escapes.

The regression executes `research-reference-generator` against paths containing spaces and uses quoted interactive arguments. Its standalone and interactive CSV/metadata outputs must be byte-identical.

## Error and signal behavior

### Interactive backend errors

Standalone executables retain their native `stderr` behavior. The in-process interactive registry temporarily routes backend `stderr` into the interactive shell's captured command output so validation/authentication errors participate in the normal Command Activity/result stream.

### Study worker

The reusable study-worker runner was hardened for repeated in-process use:

- invocation state is reset each time;
- TCP port validation rejects values outside `[0, 65535]`;
- previous `SIGINT`/`SIGTERM` handlers are restored on exit;
- the direct and namespaced interactive forms call the same worker runner as `aesim_study_worker`.

The worker remains intentionally long-running when supplied valid arguments.

## Completion and command schema

`src/ui/console_frontend.cpp` now exposes backend roots in help, root metadata, and nested completion. Existing simulator roots retain ownership; backend commands do not replace native command families.

The current global completion regression validates:

- **454** root commands;
- **51,028** command paths; and
- **50,573** nested completion checks.

The advanced/motorsport regression independently confirms:

- **214** advanced API commands;
- **39** motorsport commands;
- **20** source-audited public façade APIs; and
- **267** advanced names represented in the 454-root global shell.

## Build-system integration

The CMake build now separates reusable backend implementations into focused static libraries rather than linking every backend dependency into every standalone executable. An aggregate `aesim_backend_cli` library contains the interactive registry and links the specific reusable runner libraries required by the primary shell.

The standalone executables remain separate deployable binaries and preserve their existing names.

## Regression coverage

Added `tests/backend_executable_cli_parity_regression.py`. The gate:

- checks the complete nine-executable inventory;
- requires a direct shell root for every executable;
- requires `backend ...` namespaced exposure for every executable;
- validates operation-level completion;
- runs safe executable-level standalone and interactive probes;
- proves authenticated engineering-session inheritance;
- compares reference-generator artifacts byte-for-byte;
- exercises worker validation without leaving a server running; and
- requires the interactive command schema to validate.

`tests/all_commands_completion_regression.py` was updated to model the data-driven backend roots so the global completion gate remains authoritative.

`tests/documentation_consistency_regression.py` now prevents the backend parity mapping from silently disappearing from current documentation.

## Documentation

Added/updated:

- `docs/BACKEND_EXECUTABLE_CLI_PARITY.md`
- `README.md`
- `docs/DOCUMENTATION_INDEX.md`
- `docs/MUZIXDIAGSYS_USER_MANUAL.md` (Chapter 74)
- `docs/MUZIXDIAGSYS_USER_MANUAL.pdf` (regenerated and visually inspected)
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md` (§28.12)

## Compatibility

No existing non-duplicate feature was removed. Existing native simulator roots, `advanced ...`, direct advanced roots, `motorsport ...`, and all standalone executable names remain available. The new `backend ...` namespace and canonical backend roots are additive.

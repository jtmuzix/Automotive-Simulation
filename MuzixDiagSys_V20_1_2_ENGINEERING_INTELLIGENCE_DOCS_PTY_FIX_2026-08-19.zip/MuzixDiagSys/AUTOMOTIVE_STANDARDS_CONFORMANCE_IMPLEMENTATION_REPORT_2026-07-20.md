# Automotive Standards Conformance Platform — Implementation Report

Date: 2026-07-20

## Scope

This change set adds production C++17 implementations for the requested standards and vehicle-interface domains while preserving all existing simulator features and public commands:

1. ASAM Quality Checker and Quantifying Simulation Quality (QSQ)
2. ASAM CEA component execution
3. ASAM OpenTestSpecification
4. UN Regulation No. 171 DCAS homologation
5. ISO/SAE 21434, UN R155, UN R156, and ISO 24089 lifecycle assurance
6. ISO 26262-11 semiconductor functional safety
7. SAE J3400/NACS and ISO 15118-20 charging conformance
8. CAN XL and 10BASE-T1S/PLCA
9. Automotive SerDes
10. CCC Digital Key

CAN XL and 10BASE-T1S/PLCA are independently modeled and independently reported, so the integrated self-test contains eleven result domains for the ten requested feature groups.

## Source integration

New public API:

```text
include/aesim/advanced/automotive_standards_conformance_platform.hpp
```

New implementation:

```text
src/advanced/automotive_standards_conformance_platform.cpp
```

New regression suite:

```text
tests/automotive_standards_conformance_platform_tests.cpp
```

New documentation and executable samples:

```text
docs/AUTOMOTIVE_STANDARDS_CONFORMANCE_PLATFORM.md
examples/automotive_standards/*.json
```

The implementation is linked into `aesim_advanced`, exported through `aesim/advanced/platform.hpp`, and exposed through `muzixdiagsys_advanced_platform`.

## CLI

```bash
muzixdiagsys_advanced_platform standards self-test DIRECTORY [output.json]

muzixdiagsys_advanced_platform \
  standards DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Supported domains:

```text
quality
cea
opentest
r171
cyber-lifecycle
semiconductor
charging
canxl
t1s
serdes
digital-key
```

## Implemented behavior

### ASAM Quality/QSQ

- Dotted-path artifact queries
- Presence, non-empty, equality, inequality, range, regex, uniqueness, and monotonicity rules
- Severity and fatal-gate handling
- Weighted quality dimensions
- Aggregate QSQ score and minimum release gate
- Baseline/candidate regression comparison
- Canonical evidence digest

### ASAM CEA

- Typed producer/consumer ports
- Direction, type, dimension, and unit validation
- Deterministic unit conversion
- Connection validation
- Cycle detection with explicit delay semantics
- Topological execution stages
- Source, gain, sum, clamp, delay, integrator, and sink components
- Deterministic time-step execution and trace evidence

### ASAM OpenTestSpecification

- Test specifications, cases, requirements, resources, parameters, and steps
- Cartesian parameter expansion with cardinality/overflow guard
- Required-resource enforcement
- Set, add, equality/range assertions, wait, capture, fault injection, and fault clearing
- Per-step and per-instance verdicts
- Requirement coverage
- Evidence digests

### UN R171 DCAS

- Active/deactivated state evidence
- Driver-attention and hands-on supervision
- Visual, acoustic, and haptic warning deadlines
- Driver-override relinquishment timing
- Lateral-error and TTC qualification
- Lane-change safety gating
- ODD-exit transition/minimum-risk behavior
- Compliance percentage and approval verdict

### Automotive cybersecurity and software updates

- Asset impact model
- Attack-feasibility model
- Initial and residual cyber risk
- Verified preventive, detective, corrective, and recovery controls
- Cybersecurity goals for untreated residual risk
- CSMS and SUMS process evidence and audit coverage
- Signed update, rollback, recovery, compatibility, impact, user-information, and campaign-state gates
- Separate readiness verdicts for ISO/SAE 21434, UN R155, UN R156, and ISO 24089

### ISO 26262-11 semiconductor safety

- Element and failure-mode decomposition
- FIT accounting
- Single-point/residual and latent multiple-point modeling
- Diagnostic coverage
- SPFM, LFM, and PMHF calculations
- ASIL-specific targets
- SEooC assumptions
- Safety-mechanism integration checks

### J3400/NACS and ISO 15118-20

- Voltage/current/contact resistance validation
- Connector-loss and temperature-rise calculation
- Latch, proximity, pilot, insulation, insertion, and retention checks
- ISO 15118 session ordering
- TLS, Plug & Charge, certificate, revocation, and signature checks
- Mutual service negotiation
- Bidirectional metering and AC DER checks
- Delivered-energy integration

### CAN XL

- Deterministic binary encode/decode
- Priority, VCID, SDU type, acceptance field, secured flag, and payload representation
- 1–2048-byte payload enforcement
- CRC-32 generation and corruption rejection
- Arbitration/data phase timing and bus-load estimates

### 10BASE-T1S/PLCA

- Unique node and PLCA-ID validation
- Coordinator and endpoint-state enforcement
- Segment and node limits
- Beacon and transmit-opportunity scheduling
- Serialization, deadline, utilization, and latency calculations
- Delivered/dropped packet evidence

### Automotive SerDes

- MIPI A-PHY, ASA Motion Link, GMSL, and FPD-Link profiles
- Channel and connector loss
- Received power, SNR, and eye margin
- Raw BER and FEC residual BER
- Packet error rate
- Payload capacity and serialization latency
- Synchronization skew
- Burst-error, common-mode noise, training, and reverse-channel faults

### CCC Digital Key

- Persistent HSM-backed Ed25519 issuer and device keys
- Owner-key issuance
- Permission-constrained delegation
- Validity-window enforcement
- Parent/child revocation propagation
- Challenge-response signature verification
- NFC, BLE, and UWB proximity policies
- UWB time-of-flight distance calculation
- Relay-attack detection
- Credential inventory and authorization evidence

## Negative regression coverage

The dedicated test suite confirms rejection of:

- duplicate quality identifiers;
- a CEA combinational cycle without delay;
- unavailable OpenTestSpecification resources;
- delayed DCAS driver override;
- an unsigned software update;
- insufficient semiconductor diagnostics;
- an overheated charging connector;
- a corrupt CAN XL frame;
- PLCA operation without a coordinator;
- a failed SerDes reverse channel;
- a revoked Digital Key child credential.

## Compatibility

- No existing source file or subsystem was removed.
- No existing public command was removed or renamed.
- The new API is additive.
- The existing advanced-platform self-test now includes the new integrated standards result.
- Existing build options remain valid.
- The implementation contains no TODOs, stubs, placeholder returns, or `not implemented` branches.

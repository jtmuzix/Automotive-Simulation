# MuzixDiagSys Causal Simulation Implementation Report

**Date:** 2026-07-15  
**Scope:** Complete implementation of ten requested causal, resilience,
observability, sensor, security, rare-event, and differentiable-simulation
capabilities while retaining the existing project architecture and features.

## Delivered implementation

| Requested capability | Production implementation |
|---|---|
| Deterministic time-travel debugger | Event-sourced state/input timeline, deterministic random-state capture, SHA-256 parent/state hash chain, bounded checkpoints, rewind, branching, replay divergence localization, JSON persistence and validation. |
| Causal run-difference analyzer | Sequence/time alignment, state and input metrics, first divergence, integrated error, lag/gain/confidence dependency graph attribution, upstream cause ranking and causal-chain report. |
| Simulation observability and performance tracing | Thread-safe nested spans, attributes, events, counters, gauges, histograms, p50/p95/p99 summaries, critical-path reconstruction, structured document output, Chrome trace export. |
| Causal diagnostic reasoning | Validated Bayesian noisy-OR DAG, evidence reliability, exact enumeration, likelihood-weighted inference for larger graphs, interventions, root-cause posterior ranking, information gain and explanation paths. |
| Scenario mining from real-world logs | CSV ingestion, sliding-window mean/deviation/range/trend features, normalization, deterministic k-means++ clustering, anomaly scoring, support filtering, exemplars, trigger generation and JSON export. |
| Perception-grade sensor simulation | Camera/radar/lidar/ultrasonic cadence and latency, extrinsics, FOV/range, uncertainty, weather/illumination/interference attenuation, occlusion, dropouts, false positives, image projection and lidar returns. |
| Cyber-physical attack laboratory | Bias/scale/drift/freeze/replay/delay/drop/saturation/timestamp-skew/packet-injection campaigns, independent deterministic RNG streams, residual/CUSUM detection, bounded audit history and serialization. |
| Graceful-degradation analysis | Component dependencies and cascade closure, capability scoring, nominal/degraded/minimum-risk/lost classification, exact or Monte Carlo probability analysis, inclusion-minimal critical-set discovery. |
| Rare-event acceleration | Cross-entropy adaptive Gaussian importance sampling with log weights, ESS/COV/CI diagnostics and subset simulation with conditional thresholds and Markov-chain propagation. |
| Differentiable simulation | Fixed-step RK4 state integration, forward sensitivities, analytic or finite-difference Jacobians, reverse discrete adjoint, terminal gradients, central finite-difference checks and reports. |

## Integration points

- Public API: `include/aesim/research2/causal_simulation.hpp`
- Umbrella export: `include/aesim/research2/research2.hpp`
- Runtime implementation:
  - `src/research2/causal_runtime.cpp`
  - `src/research2/resilience_simulation.cpp`
  - `src/research2/rare_differentiable.cpp`
- Operator CLI: `tools/causal_simulation_cli.cpp`
- Unit/regression suite: `tests/causal_simulation_tests.cpp`
- User guide: `docs/CAUSAL_SIMULATION_LAB.md`
- Build integration: `CMakeLists.txt`

The implementation is linked into the existing `aesim_industrial` library and
exposed through the existing research2 umbrella. No existing source target,
command, API, test, plugin, or compatibility interface was removed.

## Additional archive repair

The supplied source archive registered `tests/build_footprint_regression.py` in
CTest and required it in the deterministic source-package regression, but the
file itself was absent. A complete regression was restored. It validates:

- the primary `muzixdiagsys` executable;
- executable permissions;
- the relocatable Unix `engine_sim` symlink and inode behavior;
- build-local, non-symlinked `data`, `configs`, and `plugins` staging;
- completeness of staged runtime resources;
- build-local native plugin products;
- absence of native plugin binaries in the source tree.

This repair restores an existing documented feature; it does not introduce a
placeholder or weaken the regression.

## Verification performed

- CMake configuration and complete project build succeeded.
- `causal_simulation_unit_tests` passed.
- Existing adjacent research, frontier, perception, diagnostics, project causal,
  network fault, and industrial-core suites passed.
- `build_footprint_regression` passed after restoration.
- `source_package_regression` passed and confirmed deterministic source packaging.
- The causal laboratory CLI `status` command executed successfully.
- Across the complete 112-test CTest inventory, 111 tests passed. The remaining legacy `regulatory_cycle_tracking_regression` exceeded its existing 900-second CTest limit; it did not report an assertion failure, and the individual HWFET validation completed successfully. The new subsystem and all directly adjacent regression suites passed.
- The cross-entropy rare-event reference was checked against a known Gaussian
  tail range, with an effective-sample-size guard.
- Differentiable simulation forward/adjoint results were checked against central
  finite differences.

## Engineering notes

The new code uses deterministic seeds and bounded stores where stochastic or
historical data are retained. Exact Bayesian and degradation enumeration are
bounded at 22 nodes/components; larger models automatically use seeded Monte
Carlo methods. Rare-event likelihood ratios are evaluated in the log domain.
The debugger rejects non-finite state and validates timeline hashes on load.

The APIs are deliberately model-neutral: existing MuzixDiagSys vehicle,
powertrain, controls, diagnostics, perception, and network systems can supply
state, inputs, causal graphs, sensor objects, failure components, or derivative
callbacks without being rewritten.

# MuzixDiagSys Debug and Refactor Report — 2026-07-24

## Executive summary

The uploaded Formula One industrial-ecosystem automotive simulation was unpacked, configured, compiled, exercised, and refactored without removing existing features or public command surfaces.

The maintenance pass corrected four classes of defects:

1. **Build scalability:** unrestricted Ninja compilation could overcommit memory because the repository contains numerous feature-dense C++ translation units. A configurable compile job pool now limits simultaneous compiler processes while preserving parallel linking and custom commands.
2. **Formula One industrial-platform correctness:** several domains accepted duplicate identities, allowed invalid uncertainty relationships, produced ambiguous non-finite/missing-resource output, scheduled nominally parallel factory work serially, or selected a noncompliant aerodynamic package despite a compliant alternative.
3. **Terminal/UI determinism:** raw-terminal activation discarded type-ahead and function-key input queued during the initial dashboard render. PTY tests also depended on fixed sleeps rather than observed terminal state.
4. **Regression orchestration:** the partial-throttle realism test launched four complete authenticated Debug sessions concurrently with unrelated heavy tests, but its aggregate CTest timeout was shorter than the possible child-process budget.

The complete default build succeeds. All 168 registered tests were covered in two non-overlapping CTest ranges: **167 passed, 0 failed, and 1 optional Python runtime test was skipped because `gymnasium` is unavailable**. The targeted Formula One industrial suite also passed with AddressSanitizer and UndefinedBehaviorSanitizer enabled.

## Repository baseline

- Approximate repository size: 1,023 files / 20 MB
- C++ translation units: 306
- C/C++ headers: 158
- Python files: 96
- Build system: CMake + Ninja
- Validation environment:
  - Debian/Linux sandbox
  - GCC 14.2.0
  - CMake 3.31.6
  - Ninja 1.12.1
  - Python 3.13.5
  - Debug build with testing enabled

## Defects corrected

### 1. Memory-safe build parallelism

The first unrestricted parallel build exhausted the execution environment. This was not a compiler error; it was a build-scheduling defect caused by simultaneous compilation of many large translation units.

`CMakeLists.txt` now exposes:

```cmake
AESIM_MAX_PARALLEL_COMPILES
```

For Ninja generators it defaults to `4` and assigns C++ compilation to a named job pool. A caller may still use a larger `cmake --build --parallel` value; only compiler concurrency is capped. Setting the cache variable to `0` restores the generator default.

This makes ordinary builds stable on memory-constrained workstations and CI runners without serializing linking or custom tasks.

### 2. Formula One industrial numerical integrity

A shared `finite_result` guard was added for computed outputs and cumulative quantities. It rejects overflow or other non-finite results before an evidence report is finalized.

Applied protections include:

- converted manufacturer ledger values;
- financial totals, reconciliation discrepancy, and cost-cap headroom;
- tyre production counters and weighted traceability;
- sustainable-fuel feedstock, process, blend, carbon-intensity, and efficiency calculations;
- factory cost and carbon totals;
- assembly normalized-error and RSS calculations;
- cyber/RF trust, utilization, resilience, and risk aggregates;
- medical and driver-performance aggregates.

### 3. Identity and traceability validation

Duplicate identifiers now fail explicitly where identity uniqueness is required:

- sustainable-fuel feedstocks;
- fuel process steps;
- fuel blend components;
- required parts within one manufacturing task;
- aerodynamic circuit profiles;
- medical stints and response resources;
- driver-development seats.

This prevents double counting, ambiguous evidence references, and silent overwriting in maps or result sets.

### 4. Factory resource scheduling

The manufacturing scheduler previously serialized all tasks assigned to one work center, even when the center declared multiple parallel resource lanes.

It now:

- honors each work center’s declared capacity;
- reserves each task’s exact `resource_units` for its duration;
- permits independent tasks to overlap when sufficient capacity exists;
- maintains dependency, inventory, cost, carbon, and release-deadline semantics;
- reports resource-unit usage in task evidence.

### 5. Sustainable-fuel efficiency semantics

Per-process efficiency and aggregate process efficiency now use the same energy accounting convention:

```text
fuel energy output / (fuel energy output + process energy input)
```

This removes a contradictory report in which identical energy flows could be represented by different efficiency definitions.

### 6. Assembly metrology validation

Instrument uncertainty must now be strictly smaller than the associated datum tolerance. The former implementation protected a zero denominator with an epsilon, which converted an invalid metrology specification into an extreme but apparently valid normalized error.

Additional corrections:

- actual torque must be nonnegative;
- the maximum RSS-normalized-error limit must be positive;
- normalized and cumulative values must remain finite.

### 7. Causal setup baseline uncertainty

The baseline setup’s self-comparison standard error is now exactly zero. Previously it received the same two-sample uncertainty term as a comparison between different setups, artificially penalizing the baseline.

### 8. Aerodynamic compliance-first selection

The aerodynamic design laboratory previously selected the numerically highest scoring package after applying a fixed noncompliance penalty. A sufficiently high raw score could therefore defeat the penalty even when a compliant package existed.

Selection is now lexicographic:

1. choose the highest-scoring compliant package when any compliant package exists;
2. otherwise choose the highest-scoring package and emit `AERO-NO-COMPLIANT-PACKAGE`.

### 9. Medical-resource absence semantics

When no medical response resource is available, the report no longer serializes infinity or fabricates a response time.

It now emits canonical machine-readable state:

```json
{
  "medical_response_available": false,
  "fastest_medical_response_time_s": null
}
```

The failed finding retains an explicit sentinel value while the evidence digest remains deterministic.

### 10. Driver eligibility enforcement

The driver-development allocator now preserves medical fitness as a hard eligibility constraint. Medically unfit candidates cannot receive seats even when their performance score is high.

The `fp1-rookie` role additionally requires rookie status, and duplicate seat identities are rejected.

### 11. Terminal startup input loss

`RawTerminalMode` previously entered and exited raw mode using `TCSAFLUSH`. The initial dashboard is rendered before the command reader creates the raw-terminal guard, so a fast function-key press could already be queued. `TCSAFLUSH` discarded that queued input.

The transition now uses `TCSANOW`, preserving valid type-ahead and function keys while applying terminal attributes immediately. The same correction prevents input loss at subsequent command-reader transitions.

### 12. PTY synchronization

The PTY test support now provides marker-driven synchronization helpers. UI tests wait for required rendered states rather than sleeping for a fixed duration.

Updated coverage includes:

- F1 help-overlay activation;
- dashboard page transitions;
- command-completion insertion and schema validation;
- completion-popup behavior;
- focused help interactions.

This removes load-sensitive false failures while still testing the real terminal behavior.

### 13. Partial-throttle regression scheduling

The four-vehicle realism regression is now marked `RUN_SERIAL`. Its CTest timeout is 420 seconds, which exceeds the four 90-second child-process budgets plus orchestration overhead.

The exact regression completes in approximately 60 seconds in the validated Debug environment. No vehicle-dynamics logic was changed to conceal scheduler contention.

## Files modified

- `CMakeLists.txt`
- `README.md`
- `docs/FORMULA_ONE_INDUSTRIAL_ECOSYSTEM_PLATFORM.md`
- `src/advanced/formula_one_industrial_ecosystem_internal.hpp`
- `src/advanced/formula_one_industrial_ecosystem_platform_a.cpp`
- `src/advanced/formula_one_industrial_ecosystem_platform_b.cpp`
- `src/advanced/formula_one_industrial_ecosystem_platform_c.cpp`
- `src/ui/console_frontend.cpp`
- `tests/formula_one_industrial_ecosystem_platform_tests.cpp`
- `tests/formula_one_industrial_ecosystem_source_regression.py`
- `tests/pty_test_support.py`
- `tests/ui_features_pty.py`
- `tests/ui_preferences_pty.py`
- `tests/all_commands_completion_pty.py`
- `tests/help_focus_pty.py`

No source file, public library target, CLI family, vehicle preset, racing-series implementation, or existing test was removed.

## Validation results

### Configuration and complete build

The Debug configuration succeeded, and the complete default target graph compiled and linked successfully under the bounded Ninja compile pool. This included the simulator, Formula One, IndyCar, NASCAR, industrial, vehicle, electrification, research, engineering, plugin, FMI, diagnostics, and test targets.

### Complete CTest coverage

The 168 registered tests were executed in two non-overlapping ranges:

- tests 1–96: 96 accounted for; 95 passed and one optional runtime test skipped;
- tests 97–168: 72 passed;
- aggregate: **167 passed, 0 failed, 1 skipped**.

The skipped test was:

```text
advanced_platform_python_runtime
```

It requires the optional `gymnasium` Python package, which was not installed in the validation environment. This was a dependency skip, not a product failure.

### Sanitizers

The Formula One industrial ecosystem unit executable was rebuilt and run with AddressSanitizer and UndefinedBehaviorSanitizer. It passed without a reported sanitizer violation.

### Additional checks

- aggregate `aesim_formula_one` library linked successfully;
- all ten Formula One compiled unit suites and both Formula One source-regression guards passed;
- Python regression files compile successfully;
- clean-generated-artifact, source-package, documentation-consistency, build-footprint, PIC/PIE, case-sensitive-path, command-surface, and non-finite-input regressions passed;
- the four EPA/WLTP closed-loop cycle validations passed in 288.38 seconds;
- the repaired partial-throttle realism regression passed in 59.92 seconds inside the complete later-stage matrix.

## Remaining environmental limitations

The validation was performed on Linux with GCC and Ninja. Platform-specific behavior on MSVC, Apple Clang, Windows consoles, macOS terminals, and hardware accelerator backends was not executed in this environment.

The optional `gymnasium`-dependent runtime test was not run because that dependency was unavailable. All code and tests that were runnable in the supplied environment completed without failure.

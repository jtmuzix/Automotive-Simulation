# NASCAR Integrated Fidelity Platform Implementation Report

**Date:** 2026-07-27  
**Module:** Fifth additive NASCAR production module  
**Focused library:** `aesim_nascar`  
**Aggregate library:** `aesim_advanced`

## 1. Scope

This change implements the twelve requested NASCAR capabilities as executable
C++17 production systems. No existing NASCAR source, public API, command family,
test, example, or documentation asset was removed. The implementation follows
the repository's deterministic JSON request/result contracts, canonical
SHA-256 evidence behavior, focused-library architecture, exception-based input
rejection, and CTest registration conventions.

Implemented capabilities:

1. integrated NASCAR co-simulation runtime;
2. telemetry assimilation and calibration;
3. unified uncertainty quantification and model-validity supervision;
4. full flexible 28-DOF multibody Next Gen vehicle;
5. detailed tire contact and construction model;
6. unsteady aeroelastic body and multi-car wake model;
7. closed-loop ECU, sequential transaxle, and driveline controller;
8. cranktrain, dry-sump lubrication, fuel, and thermal twin;
9. multi-car pit-road discrete-event twin;
10. occupant biomechanics, heat strain, carbon-monoxide exposure, and egress;
11. pavement mechanics and scanned-track twin; and
12. spray-plume and optical-visibility physics.

## 1.1 Executable domain identifiers

- `integrated-cosimulation`
- `telemetry-assimilation`
- `uncertainty-validity`
- `flexible-multibody`
- `tire-construction-contact`
- `aeroelastic-wake`
- `ecu-driveline-control`
- `cranktrain-lubrication-fuel-thermal`
- `pit-road-twin`
- `occupant-heat-egress`
- `pavement-scanned-track`
- `spray-optical-visibility`

## 2. Source architecture

### 2.1 Public API

- `include/aesim/advanced/nascar_integrated_fidelity_platform.hpp`

The public namespace is `aesim::advanced::nascarint`. Twelve domain classes
provide focused `run`, `assimilate`, `evaluate`, or `simulate` entry points.
`NascarIntegratedFidelityPlatform` supplies capability discovery, dispatch, and
deterministic self-test. The header is exported through
`include/aesim/advanced/platform.hpp`.

### 2.2 Production implementation

- `src/advanced/nascar_integrated_fidelity_internal.hpp`
- `src/advanced/nascar_integrated_fidelity_platform_a.cpp`
- `src/advanced/nascar_integrated_fidelity_platform_b.cpp`
- `src/advanced/nascar_integrated_fidelity_platform_c.cpp`
- `src/advanced/nascar_integrated_fidelity_platform_d.cpp`
- `src/advanced/nascar_integrated_fidelity_platform_e.cpp`

The internal support layer implements strict document extraction, finite/range
validation, identifier/topology checks, deterministic report finalization,
atomic evidence writes, dense linear algebra with pivoting, symmetric matrix
operations, Cholesky correlation, Halton sampling, inverse-normal mapping,
quantiles, and common finding semantics.

Production source is partitioned by coupled domain to reduce translation-unit
size while preserving one focused static library:

- A: tire construction/contact, aeroelastic wake, and flexible multibody plant;
- B: telemetry assimilation, ECU/driveline, and cranktrain/oil/fuel/thermal;
- C: pit road, occupant/heat/egress, and uncertainty/model validity;
- D: scanned pavement and spray/optical visibility;
- E: integrated runtime, canonical requests, registry, dispatch, and self-test.

### 2.3 Build and command integration

`CMakeLists.txt` compiles all five implementation units into `aesim_nascar`,
registers the focused C++ unit test and Python source regression, and preserves
public transitive linkage through `aesim_advanced`. The advanced CLI adds the
`nascar-integrated` family without altering the existing 40-domain `nascar`
command. The aggregate advanced-platform self-test now includes the new module.

## 3. Numerical and operational implementations

### 3.1 Integrated multi-rate co-simulation

The scheduler uses a single integer base-tick clock. Controller, vehicle, tire,
aero, thermal, pavement, spray, and output intervals must be exact integer
multiples. This eliminates fractional scheduler drift and enables deterministic
replay. The runtime couples chassis motion, flexible modes, driveline torsion,
engine torque, four tire thermal/pressure/wear states, unsteady aero/wake,
thermal/fuel systems, water/grip, spray visibility, and driver heat strain.
Reports expose scheduler counts, full checkpoints, energy accounting,
`normalized_energy_residual`, coupling residual, extrema, and findings.

### 3.2 Telemetry assimilation and calibration

The estimator performs time-ordered linearized prediction and scalar
measurement updates. Normalized innovation squared gates outliers. Accepted
measurements use Joseph-form covariance updates to preserve symmetry and
numerical robustness. Weighted ridge calibration solves regularized normal
equations with pivoting and reports coefficients, residuals, weighted RMSE,
covariance, and conditioning evidence.

### 3.3 Unified uncertainty and model validity

Bounded normal and uniform marginals are correlated through a validated
positive-definite correlation matrix and Cholesky transformation. Deterministic
Halton samples propagate through a full quadratic response model. Outputs
include quantiles, exceedance probability, extrema, and ranked sensitivities.
The validity supervisor evaluates declared normalized criteria, reports
`in_validity_domain`, and emits explicit mitigation actions for failed
calibration, numerical, conservation, disagreement, innovation, or
extrapolation limits.

### 3.4 Flexible 28-DOF multibody vehicle

The vehicle solver represents six rigid-body chassis coordinates, four
unsprung masses, four wheel-spin coordinates, suspension/steering transient
states, and flexible chassis torsion/front-clip/rear-clip modes. It establishes
static suspension preload before transient advancement and couples springs,
dampers, anti-roll behavior, nonlinear bump stops, banking, road-height input,
steering, distributed aero, drive/brake torque, corner loads, and structural
feedback. Energy, bottoming, wheel-load loss, travel, and structural-envelope
evidence remain explicit.

### 3.5 Tire contact and construction

The tire solver distinguishes all four corner constructions and supports oval
left/right asymmetry. It combines load-sensitive transient slip relaxation,
camber thrust, friction-ellipse saturation, moments, rolling loss, contact area,
carcass deflection, and hydroplaning. Tread, shoulder, carcass, and gas thermal
states drive pressure growth. Wear, flat spots, belt stress, sidewall strain,
standing-wave index, structural margin, and `belt_fatigue_damage` accumulate
through the history.

### 3.6 Unsteady aeroelastic body and wake

The aerodynamics solver includes underfloor/diffuser separation and
reattachment hysteresis, ride-height and attitude sensitivity, wall proximity,
multiple convecting wake sources, turbulence, cooling reduction, and flexible
splitter/body/rear/undertray modes. Modal deformation feeds back into force and
front balance. Roof-flap and A-post-flap angle/rate states include aerodynamic
moment, hinge stiffness, damping, and deployment delay.

### 3.7 Closed-loop ECU and driveline

The controller executes PI torque tracking with anti-windup, throttle dynamics,
engine-speed shaping, rev and pit-road limiting, adjacent-only sequential
shifts, predicted over-rev rejection, shift torque interruption, flexible shaft
torsion, limited-slip preload/locking, rear torque split, brake-bias reporting,
and fuel accounting. Illegal skipped shifts are rejected rather than silently
accepted.

### 3.8 Cranktrain, lubrication, fuel, and thermal twin

A two-inertia crank/flywheel torsional system is coupled to a damper, dry-sump
pump/scavenge network, oil aeration and viscosity, gallery pressure, bearing
film, fuel-cell/collector/pickup/pump dynamics, and coolant/oil/head/fuel thermal
states. The result reports oil and fuel margins, starvation, minimum
`bearing_film_ratio`, temperatures, torsional extrema, heat flow, and fatigue
damage.

### 3.9 Multi-car pit-road discrete events

The event engine validates boxes, cars, tasks, resources, dependencies, and
acyclic task graphs. Box occupancy, resource availability, dependency finish,
team overlap, lane traffic, and arrival chronology determine task and release
times. Results include queues, double stacking, speeding, service/wait/total
time, resource utilization, release margin, unsafe-release probability, and a
deterministic event trace.

### 3.10 Occupant biomechanics, heat strain, and egress

Head/helmet, thorax, and pelvis lumped states advance against a crash pulse with
harness, seat, HANS, headrest, and cockpit contact. Outputs include HIC15, neck,
chest, femur, harness, tether, and excursion metrics. The thermal model
calculates heat storage, sweat loss, dehydration, core-temperature rise,
`heat_strain_index`, cognitive capacity, and carbon-monoxide dose. Egress
combines restraint/window-net/steering release, injury, strength, smoke,
inversion, self-egress, and assisted extraction.

### 3.11 Pavement mechanics and scanned track

Ordered scan points and alignment pairs generate station offset/RMSE, grade,
curvature, bank transition, cross slope, tire-envelope elevation,
roughness/joint excitation, wheel-load variation, water depth, wet friction,
rutting, and fatigue. The report exposes aligned history, IRI-like roughness,
geometry extrema, load excitation, friction/water range, rut depth, and damage.

### 3.12 Spray plume and optical visibility

Each car generates a water-displacement and droplet plume derived from tire
width, speed, depth, Weber/Reynolds behavior, spread, advection, settling, and
decay. Multiple sources superpose at each driver/camera observer. Optical
extinction produces visibility, target contrast, screen contamination,
transmission, and `brake_light_detection_probability` with observer-specific
raceability findings.

## 4. Reliability and integrity controls

- Every external numeric value is checked for finiteness.
- Dimensions, identifiers, chronology, topology, covariance, and physical
  parameters are validated before state advancement.
- Singular or non-positive-definite systems are rejected.
- Runtime ticks, arrays, and solver sizes are bounded.
- Sequential transaxle constraints are enforced.
- Event dependency cycles and unknown references are rejected.
- Conservation and coupling residuals are reported rather than hidden.
- Every result receives a canonical SHA-256 evidence digest.
- Evidence files use atomic replacement when a working directory is supplied.
- Canonical examples are parsed and executed by the C++ unit target.
- Negative tests cover invalid scheduler ratios and unknown domains.

## 5. Tests and examples

New tests:

- `tests/nascar_integrated_fidelity_platform_tests.cpp`
- `tests/nascar_integrated_fidelity_source_regression.py`

Canonical examples:

- `examples/nascar_integrated_fidelity/integrated_cosimulation.json`
- `examples/nascar_integrated_fidelity/telemetry_assimilation.json`
- `examples/nascar_integrated_fidelity/uncertainty_validity.json`
- `examples/nascar_integrated_fidelity/flexible_multibody.json`
- `examples/nascar_integrated_fidelity/tire_construction_contact.json`
- `examples/nascar_integrated_fidelity/aeroelastic_wake.json`
- `examples/nascar_integrated_fidelity/ecu_driveline_control.json`
- `examples/nascar_integrated_fidelity/cranktrain_lubrication_fuel_thermal.json`
- `examples/nascar_integrated_fidelity/pit_road_twin.json`
- `examples/nascar_integrated_fidelity/occupant_heat_egress.json`
- `examples/nascar_integrated_fidelity/pavement_scanned_track.json`
- `examples/nascar_integrated_fidelity/spray_optical_visibility.json`

## 6. Documentation

Added or updated:

- `docs/NASCAR_INTEGRATED_FIDELITY_PLATFORM.md`;
- `docs/MUZIXDIAGSYS_USER_MANUAL.md` and generated PDF (Chapter 58);
- `docs/MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`;
- `docs/DOCUMENTATION_INDEX.md`;
- existing NASCAR competition, frontier, and next-generation guides;
- `README.md`;
- documentation and manual regressions; and
- source-package integrity requirements.

The detailed guide defines APIs, algorithms, request/output behavior, build and
CLI commands, canonical examples, qualification workflow, and validation
limits.

## 7. Compatibility statement

The implementation is additive. The existing 40-domain NASCAR platform remains
available under `nascar`; the new twelve-domain platform is exposed separately
under `nascar-integrated`. Existing NASCAR classes, schemas, examples, tests,
focused library linkage, Formula One/IndyCar modules, and generalized platform
features remain present.

## 8. Engineering qualification boundary

The implementations are complete software models, not automatic homologation,
medical certification, or proof of competition compliance. Predictive use
requires vehicle-specific geometry and inertia, tire construction and force
data, aerodynamic/wake/flap correlation, ECU/transaxle calibration, oil/fuel
and thermal measurements, pit-road geometry, occupant/restraint and thermal
data, scanned pavement, optical measurements, convergence studies, uncertainty
budgets, and independent validation over the intended operating envelope.

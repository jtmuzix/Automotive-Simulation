# Debug and Refactor Report — 2026-08-07 V2

**Project:** MuzixDiagSys Advanced Automotive Simulator  
**Scope:** Debugging, defensive input handling, validation-harness refactoring, and regression coverage  
**Feature policy:** No existing simulator feature, CLI command, motorsports platform, engineering subsystem, or command-line interface was removed or disabled.

## Executive summary

The supplied source tree was configured and compiled as a Release build with the project's normal hardening, strict-numerics, warning, PIC/PIE, and size-optimization policies. The main executable and the full compiled target closure built without compiler/linker warnings in the completed build passes.

The existing regression surface was then exercised across core numerics, diagnostics, vehicle dynamics, electrification, Formula One, IndyCar, NASCAR, advanced/frontier platforms, CLI behavior, documentation, packaging, and PTY/UI paths. The supplied baseline was already substantially healthy; rather than changing stable code without evidence, this pass focused on a concrete input-integrity defect found during review and on a test-harness isolation issue discovered while profiling long drive-cycle qualification runs.

## Corrected defect: malformed custom drive-cycle rows could be skipped silently

`PowertrainSimulation::load_cycle_csv()` previously treated *any* row that could not be parsed as two floating-point values as ignorable. This behavior was intended to permit the single CSV header row, but it also meant that malformed user data in the middle of a drive cycle could be silently discarded.

Example of the old failure mode:

```csv
time_s,speed_kmh
0,0
not-a-time,35
2,50
```

The malformed row could be skipped and the remaining points simulated as though the input were valid. That is undesirable for an engineering simulator because the resulting target trace no longer matches the source artifact while no diagnostic identifies the corruption.

### New behavior

The loader now:

- accepts the documented `time_s,speed_kmh` header once, before numeric data;
- preserves compatibility with legacy headerless two-column traces;
- accepts blank lines and `#` comment lines, including comments with leading whitespace;
- rejects malformed nonnumeric rows after or before the recognized header;
- rejects repeated headers after data begins;
- rejects unexpected data after the `speed_kmh` field;
- retains all existing finite-value, speed-range, strictly-increasing-time, point-count, and duration safety checks;
- reports the exact source line number for malformed input instead of silently skipping it.

This is a correctness and provenance improvement: an invalid source trace can no longer be transformed implicitly into a different valid trace.

## Drive-cycle runner refactor

The drive-cycle execution path was simplified without changing numerical behavior:

- removed an `errors` vector that was populated on every integration sample but never consumed;
- retained the authoritative sample-time, target-speed, and actual-speed vectors used by `summarize_tracking()`;
- changed per-segment `CyclePoint` temporaries to const references, avoiding unnecessary copies.

These changes reduce needless allocation/write traffic on long regulatory cycles while leaving the integration rate, closed-loop driver, vehicle physics, fuel/emissions accounting, tolerance logic, and grading thresholds unchanged.

## Regulatory qualification harness isolation

`tests/regulatory_cycle_tracking_regression.py` previously created a temporary HOME directory with `mkdtemp()` and never removed it. It also inherited the common CTest user-database path for each complete simulator session.

The harness now uses `TemporaryDirectory`, automatically removing each temporary HOME, and assigns each cycle run its own `MUZIXDIAGSYS_USER_DB` inside that temporary directory. Authentication still uses the production authentication path and the same CTest credential file; no authentication bypass was introduced.

This isolates complete simulator processes from one another and from concurrent CTest workers, reducing filesystem contention and preventing qualification runs from leaving temporary authentication state behind.

## New regression coverage

Added `tests/regulatory_cycle_input_validation_regression.py` and registered it with CTest. It verifies:

- a valid documented headered custom cycle is accepted;
- a legacy headerless two-column cycle remains accepted;
- leading-space comment lines are accepted;
- a malformed midstream row is rejected with its line number;
- unexpected third-column data is rejected;
- a repeated header after data begins is rejected;
- an unrecognized textual preamble is rejected rather than silently ignored.

The test runs through the production `muzixdiagsys` CLI and authentication path, so it validates actual user-visible behavior rather than only source text.

## Documentation updates

Updated both `README.md` and `docs/MUZIXDIAGSYS_USER_MANUAL.md` to state the strict custom-cycle input policy. The documentation now makes clear that invalid rows are rejected, not skipped.

## Environment/capability notes

The validation container provided GCC 14.2, OpenSSL 3.5.5, SQLite 3.46.1, Zlib, and Ninja. Native ROCm/HIP and native MPI/ULFM were not installed, so those optional capability-detected paths were not device/native-MPI compiled in this environment. Existing HIP source-policy regressions passed.

See `DEBUG_REFACTOR_VALIDATION_2026-08-07_V2.txt` for executed validation details and limitations.

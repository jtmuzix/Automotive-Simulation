# MuzixDiagSys Login Authentication Implementation Report

**Date:** 2026-07-14  
**Scope:** Authenticated simulator startup, protected password storage, user creation, and delegated user-management permission.  
**Compatibility requirement:** No existing simulator feature or command family removed.

## Implemented behavior

- MuzixDiagSys authenticates the operator before creating the simulation thread or starting the interactive or batch command session.
- The first account is `jtmuzix` with the requested initial password and user-management permission.
- New accounts default to `can_create_users=false`.
- An authorized account can grant or revoke user-management permission.
- A delegated account can create additional users; those additional users still default to no user-management permission unless explicitly delegated.
- The final active user-management account cannot have its permission revoked or be disabled.
- Accounts can be enabled or disabled.
- Users can change their own passwords after confirming the current password.
- Authorized user managers can reset another account's password.
- `logout` terminates the authenticated session cleanly.

## Security design

- Passwords are stored as PBKDF2-HMAC-SHA-256 verifiers, not reversible ciphertext.
- Each newly created or changed password receives a random 256-bit salt.
- PBKDF2 uses 600,000 iterations and produces a 256-bit verifier.
- Password verification uses `CRYPTO_memcmp` for constant-time comparison.
- Unknown usernames execute the same derivation path to reduce coarse timing-based account enumeration.
- Secret buffers used for derived hashes and interactive/file passwords are cleansed after use where practical.
- The user database uses the existing hardened atomic-file replacement implementation.
- User-administration writes use a cross-process database lock.
- The user database and its directory are restricted to owner access on supported filesystems.
- POSIX password and credential files must be regular files owned by the current user with no group or world permissions.
- Passwords are not accepted as literal command arguments and therefore do not enter command history.
- The production authentication implementation contains only a salted one-way verifier for the bootstrap account, not the bootstrap plaintext password.

## New commands

```text
user help
user whoami
user list
user create <username> [--can-create-users] [--password-file <path>]
user permission <username> on|off
user enable <username>
user disable <username>
user passwd [username] [--password-file <path>]
logout
```

## Startup and automation options

```text
--auth-user <username>
--auth-password-file <owner-only-path>
--auth-credential-file <owner-only-path>
```

The environment variable `MUZIXDIAGSYS_AUTH_CREDENTIAL_FILE` selects the same two-line credential-file mechanism. `MUZIXDIAGSYS_USER_DB` overrides the database path.

Informational modes (`--help`, command-schema output, and completion queries) do not start the simulator and remain available without authentication.

## Files added

- `include/aesim/security/authentication.hpp`
- `include/aesim/app/authentication_console.hpp`
- `src/security/authentication.cpp`
- `src/security/console_authentication.cpp`
- `tests/authentication_tests.cpp`
- `tests/authentication_cli_regression.py`
- `docs/AUTHENTICATION.md`
- `AUTHENTICATION_IMPLEMENTATION_REPORT_2026-07-14.md`

## Files updated

- `CMakeLists.txt`
- `src/simulation_runtime.cpp`
- `src/ui/console_frontend.cpp`
- `README.md`

## Validation

- Complete RelWithDebInfo project build: passed.
- Definitive final CTest run from the exact deliverable source state: **105 of 105 tests passed**, with zero failures, in **199.37 seconds**.
- Authentication unit tests: passed.
- End-to-end authentication CLI regression: passed.
- The final suite included legacy CLI, command-surface, API-server, interactive PTY/UI, plugin, vehicle-platform, industrial-platform, research-workflow, regulatory-cycle, and authentication regressions.
- The regulatory-cycle tracking regression passed in 147.72 seconds during the definitive final run.
- Strict Clang syntax/diagnostic validation of both new production modules passed with `-Wall -Wextra -Wpedantic -Wshadow -Wconversion` and no warnings.
- Incorrect credentials return exit code 3 and do not start the simulator.
- Insecure POSIX credential files are rejected before their contents are read.
- Persisted user databases were checked to ensure they contain no tested plaintext passwords.

## Operational note

The requested bootstrap credential is a known initial credential. Change it after first deployment with `user passwd`, and protect any automation credential files with owner-only permissions.

# IndyCar Operations Platform Implementation Report

**Project:** MuzixDiagSys Advanced Automotive and Motorsport Simulator
**Implementation date:** 2026-07-20
**Baseline:** `MuzixDiagSys_indycar_fully_implemented_2026-07-20.zip`
**Language:** C++17
**Status:** Fully implemented; no stubs or placeholders; existing functionality retained

## Executive summary

This change adds a second dedicated IndyCar platform focused on entrant operations,
regulated data and inspection, human performance, pit-lane safety, detailed
power-unit physics, and temporary street-circuit loading. The original IR-18,
oval, pack-aerodynamics, hybrid, Firestone, Indianapolis, qualification,
race-control, and power-asset systems remain unchanged.

The implementation adds ten production subsystems:

1. IndyCar fuel allotment, gravity refueling, and pit-stop safety.
2. Twin-turbo V6 renewable-ethanol power-unit and durability simulation.
3. Aeroscreen optics, cockpit cooling, visibility, and debris impact.
4. Spotter, radio, and oval situational awareness.
5. Technical inspection, aero metrology, and approved-part compliance.
6. Telemetry, locked calibration, and mandatory-channel compliance.
7. Approved testing, ROP, refresher, and development allocation.
8. Backup-car, crash repair, and return-to-competition management.
9. IndyCar-specific pit crew, wheel gun, refueling, and human reliability.
10. Street-circuit bump, wall, steering-kickback, and brake-duty simulation.

All APIs validate finite values and physical ranges. Deterministic evidence is
provided by SHA-256 content identifiers. Stochastic human/reliability models use
explicit seeds and are reproducible.

## Source integration

### Added files

- `include/aesim/advanced/indycar_operations_platform.hpp`
- `src/advanced/indycar_operations_platform_a.cpp`
- `src/advanced/indycar_operations_platform_b.cpp`
- `tests/indycar_operations_platform_tests.cpp`
- `docs/INDYCAR_OPERATIONS_PLATFORM.md`
- `INDYCAR_OPERATIONS_PLATFORM_IMPLEMENTATION_REPORT_2026-07-20.md`
- `INDYCAR_OPERATIONS_PLATFORM_VALIDATION_2026-07-20.txt`

### Updated files

- `CMakeLists.txt`
- `include/aesim/advanced/platform.hpp`
- `README.md`
- `tests/source_package_regression.py`

The core API, implementation, regression, and engineering documentation add
3,461 lines before the implementation and validation reports.

## 1. Fuel-allotment, refueling, and pit-stop safety twin

### Rule model

The event profile calculates the maximum event fuel allocation from scheduled
miles, regulatory miles per gallon, and an optional reserve. Circuit class and
ambient/fuel-temperature constraints are retained in the evidence record.

### Refueling physics

The simulation resolves:

- onboard and pit-tank capacity;
- hydrostatic gravity head;
- temperature-adjusted ethanol density;
- hose diameter, length, and line area;
- dry-break and vent effective areas;
- discharge coefficient;
- viscosity-induced flow reduction;
- tank-head depletion;
- receiver backpressure as the onboard cell fills;
- probe and vent engagement;
- leakage and spill volume;
- retained onboard fuel and pit-tank withdrawal.

Fuel mass/volume accounting is conservative: pit-tank withdrawal equals onboard
retention plus spill.

### Operational and safety qualification

The stop validates fuel-temperature legality, car positioning, extinguisher
readiness, dedicated fueler assignment, emergency shutoff, static grounding,
dry-break engagement, vent engagement, tyre-service interference, spill limits,
and release-after-disconnect. The result includes a complete flow trace, stop
time, fire probability, safe-release status, violations, and SHA-256 evidence.

## 2. Twin-turbo V6 and durability laboratory

The power-unit model resolves each operating segment at a configurable time step.
It includes:

- 2.2-litre six-cylinder four-stroke airflow;
- ambient pressure, temperature, and humidity correction;
- volumetric efficiency;
- requested and achieved boost;
- separate left/right turbo shaft states and spool constants;
- compressor/turbine efficiency parameters;
- renewable-ethanol stoichiometry and lower heating value;
- lambda enrichment;
- indicated efficiency;
- mechanical efficiency and speed-dependent friction;
- crank power and torque;
- optional hybrid crank contribution;
- exhaust temperature;
- radiator and oil-cooler heat rejection;
- coolant and oil thermal storage.

Durability damage is accumulated from knock, turbo overspeed, coolant/oil
temperature, and exhaust temperature. Qualification checks turbo speed,
coolant, oil, exhaust, knock, and remaining life.

## 3. Aeroscreen, visibility, cooling, and debris impact

### Optical and weather model

The aeroscreen simulation includes polycarbonate transmission and refractive
index, haze, water film, rain, spray, oil/rubber contamination, aerodynamic
shedding, evaporation, fogging, tear-off removal, solar load, and anti-fog
heating. Visibility is calculated from transmission, haze, water, contamination,
fog, and optical distortion.

### Cockpit and driver thermal state

Upper, lower, and helmet inlet areas are coupled with vehicle speed and exit
area to determine airflow. Cockpit air temperature includes solar, radiant, and
convective terms. Helmet airflow and a cumulative driver heat-strain index are
reported.

### Impact model

Debris impacts resolve normal kinetic energy, stopping force, contact stress,
polycarbonate absorption, frame load sharing, titanium-frame stress, and
penetration margin. Visibility, thermal, and impact qualification are independent
so the cause of failure remains explicit.

## 4. Spotter, radio, and situational-awareness twin

The system converts time-ordered traffic observations into operational calls:
inside, outside, still there, clear, three wide, check up, wreck ahead, pit open,
pit closed, and blend traffic.

It models visual range, angular resolution, experience, fatigue, visibility,
closing speed, overlap, workload memory, radio latency, interference, message
loss, perception error, and false-clear probability. Fixed seeds yield
reproducible Monte Carlo outcomes. Outputs include message histories, latency,
missed-hazard rate, false-clear rate, avoided-contact probability, workload, and
qualification status.

## 5. Technical inspection and aero metrology

The inspection platform registers calibrated instruments with standard
uncertainty and calibration state. Dimensional checks support minimum, maximum,
range, and nominal-tolerance comparison. Combined instrument and repeatability
uncertainty is multiplied by a configurable coverage factor and used for
guard-banded acceptance.

Aero load tests resolve elastic deflection, permanent set, and temperature
correction. Approved components are checked by serial, approved/fitted part
number, seal requirement, seal identity, and seal integrity. Every finding
contains corrected value, expanded uncertainty, margin, explanation, and rule ID.

## 6. Telemetry and locked-calibration compliance

The telemetry subsystem verifies:

- ECU software and SHA-256 identity;
- calibration version and digest;
- logger configuration digest;
- locked and team-owned parameters;
- approved values and tolerances;
- mandatory channels and units;
- minimum sample rates;
- continuity gaps;
- sequence gaps;
- duplicate samples;
- session time bounds;
- dataset completeness.

Samples are canonically ordered by channel, timestamp, and sequence before the
dataset digest is calculated. The dataset digest and manifest digests are bound
into a separate compliance evidence digest.

## 7. Approved testing, ROP, refresher, and development allocation

Supported test categories are team, open, manufacturer, Firestone, straight-line,
wind tunnel, rookie, evaluation, and refresher. Each opportunity includes date,
venue, approval, blackout state, eligible drivers, restricted-day consumption,
cost, tyre sets, fuel, component mileage, weather success, lap-time gain,
reliability gain, and driver-learning gain.

An exact bounded branch-and-bound search selects the highest-value legal
portfolio subject to all constraints. ROP phase speeds and selected rookie or
refresher activities determine driver eligibility completion.

## 8. Crash repair and backup-car recovery

Damage is represented by zone, severity, labor, cost, safety relevance, and
trackside repairability. The manager selects among:

- repair primary;
- replace corner;
- replace floor;
- change engine;
- change hybrid;
- substitute backup;
- retire.

The decision accounts for time until the next session, labor, cost, impound
approval, backup readiness, setup completeness, inspection state, driver fit,
calibration compatibility, post-qualifying consequences, reinspection, and
late-race repaired-car return limits.

## 9. IndyCar pit crew and human reliability

The model requires exactly seven roles: four tyre changers, air-jack operator,
fueler, and aeroscreen attendant. Crew members have reaction time, skill,
fatigue, and base error probability.

Wheel service resolves socket alignment, cross-thread risk, gun torque, impact
frequency, thread efficiency, clamp force, seating confidence, and completion
time. Fuel, tyres, and aeroscreen service execute concurrently. Pit traffic,
neighboring-box interference, double stacking, caution bunching, and car-box
error affect stop time and risk.

The result reports wheel-specific clamp/seating results, fuel delivered, stop
time, equipment failure, crew injury, unsafe-release probability, incidents, and
safe-release qualification.

## 10. Street-circuit bump, wall, steering, and brake duty

Street segments define curvature, camber, friction, bump height and wavelength,
concrete, paint, standing water, wall clearance, and braking duty. The vehicle
model resolves:

- water/paint/concrete grip effects;
- lateral force and steering angle;
- manual steering torque and rack load;
- bump displacement and road velocity;
- unsprung-mass acceleration;
- suspension force and kickback;
- floor clearance;
- brake work, cooling, disc temperature, and fade;
- lateral tracking error and wall-contact energy.

An implicit wheel/suspension integration step prevents instability in stiff,
heavily damped wheel-corner dynamics. Qualification gates cover steering torque,
brake temperature, floor clearance, wall contact, and wheel acceleration.

## Defects found and corrected during implementation

1. Initial wheel-nut seating confidence made safe completion mathematically
   unreachable at physically valid clamp loads. Alignment dispersion and seating
   sensitivity were recalibrated while retaining cross-thread and clamp checks.
2. The initial explicit street-circuit suspension integrator became unstable for
   realistic IndyCar spring and damping rates. It was replaced with an implicit
   update for the coupled velocity/deflection state.

## Compatibility

- Existing `indycar_platform.hpp` remains unchanged.
- The new module uses distinct type names and introduces no namespace collisions.
- `aesim/advanced/platform.hpp` includes both IndyCar modules.
- All pre-existing Formula One and IndyCar native tests pass.
- The source packaging manifest includes all new production, test, and
  documentation files.

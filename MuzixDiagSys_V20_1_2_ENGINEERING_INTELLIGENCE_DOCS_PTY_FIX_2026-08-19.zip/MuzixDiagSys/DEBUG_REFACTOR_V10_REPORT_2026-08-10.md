# MuzixDiagSys V10 Debug and Refactor Report — 2026-08-10

## Scope

This pass preserves the existing simulator feature surface and focuses on correctness, stability, deterministic terminal integration behavior, concurrency efficiency, and provenance/hashing performance.

## Production changes

### Event-driven loopback CAN transport

- Replaced 1 ms receive polling with `std::condition_variable` synchronization.
- `send()` wakes blocked receivers immediately.
- `close()` wakes blocked receivers so shutdown does not depend on polling latency.
- Preserved public transport behavior and queue ordering.
- Added multithreaded send/wakeup and close/wakeup regressions.

### Streaming SHA-256 provenance path

- Added `Sha256::digest_bytes(const void*, std::size_t)` for binary evidence buffers.
- Reworked SHA-256 into an incremental block accumulator.
- File hashing now uses a fixed 64 KiB read buffer instead of loading the complete file into memory.
- In-memory hashing no longer requires a second full-payload padding copy.
- Research numeric-vector evidence hashing now uses the raw-byte API instead of constructing intermediate strings.
- Added empty-input, `abc`, raw-byte/string parity, invalid-null-buffer, and one-million-byte multi-block standard vectors.

### Terminal modifier validation

- CSI-u/xterm modified-key decoding now rejects modifier values outside the supported 1..8 range rather than silently misclassifying unsupported modifier bits.
- Added invalid-modifier regressions.

## Test-stability change

### Resize/scroll-anchor PTY synchronization

`terminal_resize_anchor_pty.py` previously submitted 28 synthetic commands using fixed 120 ms sleeps and discarded the acknowledgments. Under loaded CI this could outrun the terminal event loop and produce a false `final synthetic anchor` failure.

The regression now:

- synchronizes every synthetic command on its actual `unknown command: anchorNN` execution record;
- waits for synchronized-output frame completion (`CSI ? 2026 h/l`);
- synchronizes resize and dashboard transitions on complete frames rather than fixed sleeps;
- preserves the original scroll-anchor assertions.

This is a test-orchestration hardening change; the renderer's anchor semantics are unchanged.

## Compatibility

No documented simulator feature, CLI command, vehicle model, motorsport platform, research module, interoperability backend, or data format was removed. The public SHA-256 API was extended, not replaced. Existing SHA-256 digest strings remain byte-for-byte compatible.

# Simulation Assurance, Resilience, and Reproducibility Framework

Date: 2026-08-07

## Scope

This release fully implements a cross-cutting Simulation Assurance, Resilience, and Reproducibility Framework without removing existing simulator features. The existing command-line dispatcher remains authoritative; beginner menu actions route to the same canonical commands.

Implemented capabilities:

1. Deterministic fault-injection and chaos framework.
2. Hierarchical checkpoint/restart with transactional recovery.
3. Structured error taxonomy and causal failure-provenance graph.
4. Cross-subsystem conservation ledger.
5. Numerical provenance and confidence-aware result evidence.
6. Semantic result cache with dependency-aware incremental invalidation/recalculation.
7. Integrated run manifests and tamper-evident assurance certificates.

## Deterministic fault injection

`DeterministicChaosEngine` provides invocation-, simulation-time-, event-, and deterministic-probability triggers. Effects include fail, exception, bounded delay, drop, numeric corruption, and resource-exhaustion injection. Probability decisions are derived deterministically from the configured seed, rule identity, and invocation index, permitting exact replay after reset.

Fault manifests are loaded transactionally. Rules are validated before activation, duplicate identifiers are rejected, invalid event/probability/delay/corruption contracts are rejected, and a failed manifest load cannot partially replace the active fault campaign.

The production industrial command path is guarded by this engine. Real industrial signal writes support deterministic drop and numeric corruption while retaining normal signal validation. Assurance/status/control routes remain reachable for recovery.

## Hierarchical checkpoint/restart

`HierarchicalCheckpointManager` registers state-bearing components by hierarchical path. Checkpoints record component snapshots, per-component SHA-256 digests, aggregate SHA-256 identity, parent checkpoint identity, and metadata.

Restore is transactional. Before applying a checkpoint, pre-restore state is captured for every affected component. Components restore in deterministic order. If any component fails after partial mutation, the failing component and every previously restored component are rolled back in reverse order. Scope restore supports hierarchical prefixes.

The assurance platform registers a real simulator state component, `industrial.signals`, so checkpoint/restart operates on actual signal state rather than a demonstration-only state container.

## Structured errors and failure provenance

`ErrorProvenanceGraph` separates stable error descriptors from runtime occurrences. Occurrences record subsystem, operation, message, causal occurrence IDs, metadata, state hash, and UTC evidence. Causal references must point to valid earlier occurrences, restored IDs are validated, and invalid graph state is rejected.

Built-in framework taxonomy includes deterministic fault, conservation, numerical, and recovery errors. Recursive traces provide machine-readable causal provenance.

## Cross-subsystem conservation

`CrossSubsystemConservationLedger` supports dynamically registered conserved quantities with units and absolute/relative tolerances. Default quantities include energy, mass, electric charge, linear momentum, and angular momentum.

The ledger records domain storage, external signed rates, and signed transfers between domains. Closing a step compares observed storage change against integrated external and inter-domain flow and reports absolute/normalized residuals and PASS/FAIL status. Missing storage initialization cannot silently disappear from the balance.

## Numerical provenance and confidence-aware results

`NumericalEvidenceRegistry` records value, unit, uncertainty, confidence, algorithm/solver, precision bits, residual, tolerance, condition estimate, iteration count, convergence, model-validity-domain status, provenance inputs, SHA-256 identities, timestamp, trust score, and trust classification.

Invalid evidence contracts are rejected: nonfinite values/residuals, negative uncertainty/tolerance/condition estimate, confidence outside [0,1], impossible precision, and malformed hashes. Trust classification can be HIGH, MEDIUM, LOW, or REJECT.

## Semantic cache and incremental recalculation

`SemanticResultCache` derives cache identity from namespace, canonical input, canonical settings, and a sorted set of named dependency hashes. Dependency updates invalidate only cache entries that reference the changed dependency. `get_or_compute` reuses unchanged results and recomputes only after a semantic miss or dependency invalidation.

The cache supports namespace/tag/dependency invalidation, atomic persistence, dependency-coherence checks on restore, and hit/miss/invalidation statistics.

## Integrated assurance framework

`SimulationAssuranceFramework` owns and coordinates the error graph, chaos engine, checkpoint manager, conservation ledger, numerical evidence registry, and semantic cache. Operation guards translate triggered faults into controlled behavior and structured error occurrences.

Run manifests use schema `aesim.simulation-assurance-resilience-reproducibility.v1` and include the complete assurance state plus a canonical SHA-256 digest. Certificate verification canonicalizes parsed JSON, so formatting changes do not invalidate evidence while semantic tampering does.

## CLI surface

The framework is exposed through the existing command dispatcher under:

- `industrial assurance framework ...`
- `industrial assurance chaos ...`
- `industrial assurance checkpoint ...`
- `industrial assurance error ...`
- `industrial assurance conservation ...`
- `industrial assurance numerics ...`
- `industrial assurance cache ...`

Aliases include resilience/SAR/reproducibility, fault/faults, checkpoints, errors, ledger, numerical, and cache. F7 beginner menus expose assurance health, recovery checkpoints, deterministic fault status, numerical confidence, and conservation status by emitting these same canonical commands.

## Qualification additions

New unit and CLI regressions cover deterministic replay, corruption, real command dropping, transactional checkpoint rollback after partial mutation, hierarchical scope restore, real industrial signal restoration, causal error traces, balanced/unbalanced conservation, numerical trust and invalid evidence rejection, semantic-cache hit/invalidation/recomputation, certificate generation/verification/tamper detection, and malformed rule rejection.

A focused AddressSanitizer + UndefinedBehaviorSanitizer build with leak detection completed the assurance resilience test suite without findings.

No TODO, FIXME, placeholder, "not implemented", or stub markers are present in the implemented assurance framework sources/tests.

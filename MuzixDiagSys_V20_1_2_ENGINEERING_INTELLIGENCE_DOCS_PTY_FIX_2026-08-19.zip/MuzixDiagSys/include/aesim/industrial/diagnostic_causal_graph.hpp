#pragma once

#include "aesim/industrial/diagnostic_workflow.hpp"

#include <map>
#include <string>
#include <vector>

namespace aesim::diagnostic {

enum class CausalNodeType {
    Symptom,
    Dtc,
    FreezeFrame,
    Sensor,
    Actuator,
    WiringOrNetworkPath,
    OperatingCondition,
    CandidateRootCause,
    ConfirmingTest
};

enum class CausalEdgeType {
    ObservedWith,
    Indicates,
    Affects,
    TravelsThrough,
    OccursUnder,
    Requires,
    Confirms,
    Contradicts
};

struct CausalNode {
    std::string id;
    CausalNodeType type = CausalNodeType::Symptom;
    std::string label;
    EvidenceClass evidence_class = EvidenceClass::Missing;
    double confidence = 0.0;
    std::string value;
    std::string source;
    std::string explanation;
};

struct CausalEdge {
    std::string from;
    std::string to;
    CausalEdgeType type = CausalEdgeType::Indicates;
    double weight = 1.0;
    std::string rationale;
};

struct RankedCause {
    std::string node_id;
    std::string label;
    double score = 0.0;
    std::vector<std::string> supporting_evidence;
    std::vector<std::string> contradicting_evidence;
    std::vector<std::string> confirming_tests;
};

class CausalGraph {
public:
    void add_node(CausalNode node);
    void add_edge(CausalEdge edge);
    [[nodiscard]] const std::map<std::string, CausalNode>& nodes() const noexcept { return nodes_; }
    [[nodiscard]] const std::vector<CausalEdge>& edges() const noexcept { return edges_; }
    [[nodiscard]] const CausalNode* node(const std::string& id) const;
    [[nodiscard]] std::vector<RankedCause> rank_causes() const;
    [[nodiscard]] std::vector<CausalNode> missing_evidence() const;
    [[nodiscard]] std::string validate() const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] std::string explain(const std::string& node_id) const;
    [[nodiscard]] std::string to_json() const;
    [[nodiscard]] std::string to_dot() const;

private:
    std::map<std::string, CausalNode> nodes_;
    std::vector<CausalEdge> edges_;
};

class CausalGraphBuilder {
public:
    [[nodiscard]] static CausalGraph build(
        const std::string& workflow_id,
        const DiagnosticContext& context,
        const WorkflowState* workflow_state = nullptr,
        const std::vector<std::string>& ecu_names = {});
};

[[nodiscard]] const char* causal_node_type_name(CausalNodeType value) noexcept;
[[nodiscard]] const char* causal_edge_type_name(CausalEdgeType value) noexcept;

} // namespace aesim::diagnostic

#pragma once

#include "aesim/professional/document.hpp"

#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::diagnostic {

enum class EvidenceClass { Fact, ModelDerived, Heuristic, Missing };
enum class EvidenceOutcome { Pass, Fail, Missing };
enum class WorkflowStatus { Idle, Active, WaitingForEvidence, Concluded, Verified, Failed };
enum class WorkflowPhase { Preconditions, DiagnosticRequest, Analysis, ConfirmingTest, RepairVerification };
enum class Comparator {
    BetweenInclusive,
    GreaterOrEqual,
    LessOrEqual,
    BooleanTrue,
    BooleanFalse,
    AbsoluteDifferenceLessOrEqual,
    RatioBetweenInclusive
};

struct Measurement {
    std::optional<double> value;
    std::string unit;
    EvidenceClass evidence_class = EvidenceClass::Fact;
    std::string source;
    std::string note;
};

struct DiagnosticContext {
    double simulation_time_s = 0.0;
    std::map<std::string, Measurement> measurements;
    std::set<std::string> active_dtcs;
    std::map<std::string, doc::Value> freeze_frames;
    std::vector<std::string> diagnostic_responses;
};

struct ExpectedCheck {
    std::string metric;
    Comparator comparator = Comparator::BetweenInclusive;
    double low = 0.0;
    double high = 0.0;
    std::string other_metric;
    std::string expectation;
};

struct WorkflowStep {
    std::string id;
    WorkflowPhase phase = WorkflowPhase::Analysis;
    std::string title;
    std::string instructions;
    std::vector<std::string> diagnostic_requests;
    std::vector<ExpectedCheck> checks;
    std::string pass_step;
    std::string fail_step;
    std::string pass_conclusion;
    std::string fail_hypothesis;
    bool terminal_on_pass = false;
    bool terminal_on_fail = false;
};

struct WorkflowDefinition {
    std::string id;
    std::string title;
    std::string symptom;
    std::string description;
    std::string first_step;
    std::string verification_step;
    std::vector<WorkflowStep> steps;
};

struct EvidenceRecord {
    std::string id;
    std::string step_id;
    std::string metric;
    std::optional<double> observed;
    std::string unit;
    std::string expected;
    EvidenceClass evidence_class = EvidenceClass::Fact;
    EvidenceOutcome outcome = EvidenceOutcome::Missing;
    std::string source;
    std::string note;
    double simulation_time_s = 0.0;
};

struct DecisionRecord {
    std::string step_id;
    std::string branch;
    std::string conclusion;
    std::string next_step;
    double simulation_time_s = 0.0;
};

struct WorkflowState {
    std::string definition_id;
    std::string case_id;
    WorkflowStatus status = WorkflowStatus::Idle;
    std::string current_step;
    std::string started_utc;
    std::string updated_utc;
    std::vector<EvidenceRecord> evidence;
    std::vector<DecisionRecord> decisions;
    std::vector<std::string> candidate_root_causes;
    std::map<std::string, Measurement> supplied_evidence;
    std::string final_conclusion;
};

struct EvaluationResult {
    EvidenceOutcome outcome = EvidenceOutcome::Missing;
    std::string step_id;
    std::string next_step;
    std::string conclusion;
    std::vector<EvidenceRecord> evidence;
    [[nodiscard]] std::string report() const;
};

class WorkflowEngine {
public:
    [[nodiscard]] static const std::vector<WorkflowDefinition>& definitions();
    [[nodiscard]] static const WorkflowDefinition* find_definition(const std::string& id);
    [[nodiscard]] static std::string list_report();

    void start(const std::string& definition_id, std::string case_id = {});
    void reset();
    void restore(WorkflowState state);
    void add_evidence(std::string metric, Measurement measurement);
    bool remove_evidence(const std::string& metric);
    [[nodiscard]] EvaluationResult evaluate(const DiagnosticContext& context);
    [[nodiscard]] std::vector<EvaluationResult> run(const DiagnosticContext& context,
                                                    std::size_t maximum_steps = 32);
    [[nodiscard]] EvaluationResult verify_repair(const DiagnosticContext& context);

    [[nodiscard]] const WorkflowState& state() const noexcept { return state_; }
    [[nodiscard]] const WorkflowDefinition* active_definition() const;
    [[nodiscard]] const WorkflowStep* current_step() const;
    [[nodiscard]] std::string status_report() const;
    [[nodiscard]] std::string requests_report() const;
    [[nodiscard]] std::string markdown_report() const;
    bool export_report(const std::string& path, std::string& error) const;
    bool save_state(const std::string& path, std::string& error) const;
    void load_state(const std::string& path);

    [[nodiscard]] static doc::Value to_document(const WorkflowState& state);
    [[nodiscard]] static WorkflowState from_document(const doc::Value& document);
    [[nodiscard]] static std::string utc_now();

private:
    WorkflowState state_;
    [[nodiscard]] const WorkflowStep* find_step(const std::string& id) const;
};

[[nodiscard]] const char* evidence_class_name(EvidenceClass value) noexcept;
[[nodiscard]] const char* evidence_outcome_name(EvidenceOutcome value) noexcept;
[[nodiscard]] const char* workflow_status_name(WorkflowStatus value) noexcept;
[[nodiscard]] const char* workflow_phase_name(WorkflowPhase value) noexcept;

} // namespace aesim::diagnostic

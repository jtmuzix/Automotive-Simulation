#pragma once

#include "aesim/industrial/fault_campaign.hpp"
#include "aesim/industrial/hil_io.hpp"
#include "aesim/industrial/mdf.hpp"
#include "aesim/industrial/network.hpp"
#include "aesim/industrial/realtime.hpp"
#include "aesim/industrial/signals.hpp"
#include "aesim/industrial/ssp.hpp"
#include "aesim/industrial/traceability.hpp"
#include "aesim/industrial/xcp.hpp"
#include "aesim/industrial/xil.hpp"
#include "aesim/assurance/assurance.hpp"
#include "aesim/vehicle/vehicle.hpp"
#include "aesim/electrification/electrification.hpp"
#include "aesim/frontier/frontier.hpp"
#include "aesim/research2/research2.hpp"
#include "aesim/federation/federation.hpp"

#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace aesim::industrial {

struct PlantSample {
    double time_s = 0.0;
    double step_s = 0.001;
    double rpm = 0.0;
    double torque_nm = 0.0;
    double power_w = 0.0;
    double vehicle_speed_m_s = 0.0;
    double manifold_pressure_pa = 101325.0;
    double boost_pressure_pa = 0.0;
    double coolant_temperature_k = 298.15;
    double oil_temperature_k = 298.15;
    double exhaust_temperature_k = 298.15;
    double air_mass_flow_kg_s = 0.0;
    double fuel_mass_flow_kg_s = 0.0;
    double lambda = 1.0;
    double co2_g_s = 0.0;
    double co_g_s = 0.0;
    double hc_g_s = 0.0;
    double nox_g_s = 0.0;
    double pm_g_s = 0.0;
    double throttle_fraction = 0.0;
    double brake_fraction = 0.0;
    int gear = 0;
    std::uint64_t health_deadline_misses = 0;
    std::uint64_t health_state_clamps = 0;
};

class IndustrialPlatform {
public:
    using ResetCallback = std::function<void()>;
    using StepCallback = std::function<void(double)>;
    using TimeCallback = std::function<double()>;
    using CommandCallback = std::function<std::string(const std::string&)>;
    using FaultInjectCallback = std::function<std::string(const std::string&, const std::string&, double)>;
    using FaultClearCallback = std::function<std::string(const std::string&)>;

    IndustrialPlatform();
    ~IndustrialPlatform();

    void configure_callbacks(ResetCallback reset, StepCallback step, TimeCallback time,
                             CommandCallback command, FaultInjectCallback inject_fault,
                             FaultClearCallback clear_fault);
    void update(const PlantSample& sample);
    [[nodiscard]] std::string command(const std::vector<std::string>& arguments);
    [[nodiscard]] std::string status() const;

    // Authoritative command schema used by dispatch, Tab completion, the command
    // palette, help generation, and schema-regression tests.  `arguments` are
    // the tokens following `industrial`; `ends_space` describes the editor
    // cursor position so nested completion can distinguish a partial token from
    // a request for the next command level.
    [[nodiscard]] static std::vector<std::string> completion_candidates(
        const std::vector<std::string>& arguments, bool ends_space);
    [[nodiscard]] static std::vector<std::string> command_aliases();
    [[nodiscard]] static std::string command_schema_report();

    [[nodiscard]] std::optional<double> requested_throttle() const;
    [[nodiscard]] std::optional<double> requested_brake() const;
    [[nodiscard]] bool experience_driver_enabled() const noexcept;
    [[nodiscard]] std::optional<double> requested_experience_throttle() const;
    [[nodiscard]] std::optional<double> requested_experience_brake() const;
    [[nodiscard]] std::optional<double> requested_experience_clutch_pedal() const;
    [[nodiscard]] std::optional<int> requested_experience_gear() const;
    void clear_command_overrides();
    void clear_brake_override();

    SignalRegistry& signals() noexcept;
    RealtimeRuntime& realtime() noexcept;
    [[nodiscard]] const RealtimeRuntime& realtime() const noexcept;
    HilIoManager& hil_io() noexcept;
    AutomotiveNetwork& network() noexcept;
    [[nodiscard]] const AutomotiveNetwork& network() const noexcept;
    XcpServer& xcp() noexcept;
    MdfRecorder& mdf() noexcept;
    SspOrchestrator& ssp() noexcept;
    TraceabilityRepository& traceability() noexcept;

private:
    SignalRegistry signals_;
    RealtimeRuntime realtime_;
    HilIoManager hil_io_;
    AutomotiveNetwork network_;
    XcpServer xcp_;
    MdfRecorder mdf_;
    SspOrchestrator ssp_;
    TraceabilityRepository traceability_;
    aesim::assurance::AssurancePlatform assurance_;
    aesim::vehicle::VehiclePlatform vehicle_;
    aesim::electrification::ElectrificationPlatform electrification_;
    aesim::frontier::FrontierPlatform frontier_;
    aesim::research2::ResearchIntegrationPlatform research2_;
    aesim::federation::FederationPlatform federation_;
    std::unique_ptr<XilTestbench> xil_;
    std::unique_ptr<FaultCampaignRunner> campaigns_;
    std::uint64_t update_count_ = 0;
    std::uint64_t network_publish_divider_ = 10;
    std::string last_error_;

    void register_signals();
    [[nodiscard]] std::string hil_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string network_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string xcp_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string mdf_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string xil_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string ssp_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string traceability_command(const std::vector<std::string>& args);
    [[nodiscard]] std::string campaign_command(const std::vector<std::string>& args);
    void publish_network(const PlantSample& sample);
};

} // namespace aesim::industrial

#pragma once

#include "aesim/industrial/network.hpp"

#include <chrono>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <thread>
#include <vector>

namespace aesim::industrial {

class DiagnosticService;
DiagnosticService& authoritative_diagnostic_service();

// Live values exposed by the virtual OBD ECU.  The structure intentionally uses
// engineering units so that the protocol encoder is the only place where SAE
// PID scaling and clamping are applied.
struct ObdLiveData {
    double engine_rpm = 0.0;
    double vehicle_speed_kmh = 0.0;
    double calculated_load_pct = 0.0;
    double coolant_temperature_c = 20.0;
    double intake_temperature_c = 20.0;
    double ambient_temperature_c = 20.0;
    double manifold_pressure_kpa = 101.325;
    double barometric_pressure_kpa = 101.325;
    double mass_air_flow_g_s = 0.0;
    double throttle_position_pct = 0.0;
    double accelerator_position_pct = 0.0;
    double commanded_lambda = 1.0;
    double short_term_fuel_trim_pct = 0.0;
    double long_term_fuel_trim_pct = 0.0;
    double ignition_timing_advance_deg = 0.0;
    double upstream_o2_voltage_v = 0.45;
    double downstream_o2_voltage_v = 0.45;
    double evap_vapor_pressure_pa = 0.0;
    double fuel_rail_pressure_kpa = 300.0;
    double ethanol_fuel_pct = 0.0;
    double engine_oil_temperature_c = 20.0;
    double injection_timing_deg = 0.0;
    double absolute_load_pct = 0.0;
    std::uint16_t engine_run_time_s = 0;
    double catalyst_temperature_c = 20.0;
    double control_module_voltage_v = 12.6;
    double fuel_rate_l_h = 0.0;
    double fuel_level_pct = 75.0;
    double commanded_torque_pct = 0.0;
    double actual_torque_pct = 0.0;
    double reference_torque_nm = 400.0;
    double odometer_km = 0.0;
    std::string vin = "MUZIXDIAGSYS00000";
    std::string calibration_id = "MUZIXDIAGSYS-CAL-2026.07";
    std::string ecu_name = "MUZIXDIAGSYS POWERTRAIN ECU";
    std::vector<std::string> diagnostic_trouble_codes;
    std::vector<std::string> pending_diagnostic_trouble_codes;
    std::vector<std::string> permanent_diagnostic_trouble_codes;
    bool malfunction_indicator_lamp = false;
    bool compression_ignition = false;
    std::uint8_t readiness_supported_mask = 0xE1U;
    std::uint8_t readiness_complete_mask = 0xE1U;
    std::uint16_t distance_with_mil_km = 0;
    std::uint16_t distance_since_clear_km = 0;
    std::uint8_t warmups_since_clear = 0;
    std::uint16_t time_with_mil_minutes = 0;
    std::uint16_t time_since_clear_minutes = 0;
};

struct ObdValue {
    std::uint64_t timestamp_ns = 0;
    std::uint32_t ecu_id = 0;
    std::uint8_t mode = 0;
    std::uint8_t pid = 0;
    std::string name;
    std::string unit;
    double value = 0.0;
    bool numeric = false;
    std::string text;
    std::vector<std::uint8_t> payload;
};

enum class CanAccessMode {
    ListenOnly,
    DiagnosticRead,
    DiagnosticWrite,
    RawAllowList
};

struct CanGatewayPolicy {
    CanAccessMode access = CanAccessMode::ListenOnly;
    double maximum_transmit_frames_per_second = 50.0;
    std::set<std::uint32_t> raw_transmit_allowlist;
};

struct CanCaptureRecord {
    CanFrame frame;
    bool transmitted = false;
};

struct CanIdentifierAnalysis {
    std::uint32_t id = 0;
    bool extended = false;
    bool fd = false;
    std::size_t frames = 0;
    double mean_period_ms = 0.0;
    double period_jitter_ms = 0.0;
    double estimated_frequency_hz = 0.0;
    double byte_entropy_bits = 0.0;
    double bit_flip_fraction = 0.0;
    int likely_counter_byte = -1;
    int likely_crc_byte = -1;
};

struct CanTraceAnalysis {
    std::vector<CanIdentifierAnalysis> identifiers;
    double duration_s = 0.0;
    double estimated_classical_bus_load = 0.0;
    std::size_t total_frames = 0;
    std::vector<std::string> observations;
};

// Guarded CAN/OBD gateway.  Real transmit is disabled by default.  Diagnostic
// reads, diagnostic writes, and arbitrary raw traffic require progressively
// stronger explicit access modes so a trace-analysis session cannot
// accidentally control a connected vehicle.
class CanObdGateway {
public:
    CanObdGateway();
    explicit CanObdGateway(DiagnosticService& service, std::string ecu_name = "powertrain");
    ~CanObdGateway();

    void use_loopback();
    void use_socketcan(const std::string& interface_name, bool can_fd = false,
                       std::vector<std::uint32_t> accepted_ids = {});
    void open();
    void close() noexcept;
    [[nodiscard]] bool is_open() const noexcept;
    [[nodiscard]] std::string status() const;

    void set_policy(CanGatewayPolicy policy);
    [[nodiscard]] const CanGatewayPolicy& policy() const noexcept { return policy_; }
    void allow_raw_identifier(std::uint32_t id);
    void clear_raw_allowlist();

    void bind_diagnostic_service(DiagnosticService& service, std::string ecu_name = "powertrain");
    void update_virtual_ecu(ObdLiveData data);
    [[nodiscard]] const ObdLiveData& virtual_ecu() const noexcept { return virtual_data_; }

    void send_raw(const CanFrame& frame);
    [[nodiscard]] std::vector<CanFrame> receive(std::size_t maximum_frames,
                                                std::chrono::milliseconds timeout);
    [[nodiscard]] std::vector<ObdValue> query_pid(std::uint8_t mode, std::uint8_t pid,
                                                  std::chrono::milliseconds timeout = std::chrono::milliseconds(250));
    [[nodiscard]] std::vector<std::pair<std::uint32_t,std::vector<std::uint8_t>>> request_obd(
        const std::vector<std::uint8_t>& payload,
        std::chrono::milliseconds timeout = std::chrono::milliseconds(250));
    [[nodiscard]] std::vector<std::uint16_t> supported_mode01_pids(
        std::chrono::milliseconds timeout = std::chrono::milliseconds(250));
    [[nodiscard]] std::vector<std::string> read_diagnostic_trouble_codes(
        std::chrono::milliseconds timeout = std::chrono::milliseconds(250));
    [[nodiscard]] std::string read_vin(
        std::chrono::milliseconds timeout = std::chrono::milliseconds(500));
    bool clear_diagnostic_trouble_codes(
        std::chrono::milliseconds timeout = std::chrono::milliseconds(250));

    void clear_capture();
    [[nodiscard]] const std::vector<CanCaptureRecord>& capture() const noexcept { return capture_; }
    void import_candump(const std::string& path);
    void export_candump(const std::string& path, const std::string& interface_name = "can0") const;
    void export_capture_csv(const std::string& path) const;
    [[nodiscard]] CanTraceAnalysis analyze_capture() const;
    void export_analysis_json(const std::string& path) const;

    [[nodiscard]] const std::map<std::string, ObdValue>& last_obd_values() const noexcept {
        return last_obd_values_;
    }
    [[nodiscard]] std::map<std::string,double> derived_obd_features() const;

private:
    std::unique_ptr<CanTransport> transport_;
    DiagnosticService* diagnostic_service_ = nullptr;
    std::string diagnostic_ecu_name_{"powertrain"};
    bool loopback_ = true;
    CanGatewayPolicy policy_{};
    ObdLiveData virtual_data_{};
    std::vector<CanCaptureRecord> capture_;
    std::map<std::string, ObdValue> last_obd_values_;
    std::deque<std::chrono::steady_clock::time_point> transmit_history_;

    void require_diagnostic_read() const;
    void require_diagnostic_write() const;
    void enforce_rate_limit();
    void transmit(const CanFrame& frame, bool diagnostic);
    [[nodiscard]] std::vector<std::pair<std::uint32_t,std::vector<std::uint8_t>>> request_payload(
        const std::vector<std::uint8_t>& payload, std::chrono::milliseconds timeout);
    [[nodiscard]] std::vector<std::pair<std::uint32_t,std::vector<std::uint8_t>>> virtual_response(
        const std::vector<std::uint8_t>& payload);
    void record(const CanFrame& frame, bool transmitted);
};

// Vehicle-side OBD-II responder configuration.  The default identifier set is
// the normal 11-bit engine-ECU arrangement used by generic scan tools:
// functional requests on 0x7DF, physical requests/flow control on 0x7E0, and
// engine ECU responses on 0x7E8.
struct ObdResponderConfiguration {
    std::uint32_t functional_request_id = 0x7DFU;
    std::uint32_t physical_request_id = 0x7E0U;
    std::uint32_t response_id = 0x7E8U;
    bool accept_functional_requests = true;
    bool accept_physical_requests = true;
    bool allow_mode04_clear = true;
    bool can_fd = false;
    std::uint8_t padding_byte = 0x00U;
    std::chrono::milliseconds p2_delay{8};
    std::chrono::milliseconds receive_poll{10};
    std::chrono::milliseconds flow_control_timeout{750};
    std::uint8_t default_block_size = 0U;
    std::uint8_t default_separation_time_ms = 0U;
    double maximum_responses_per_second = 100.0;
    std::size_t maximum_request_payload = 0xFFFFFU;
    std::size_t log_capacity = 1024U;
};

struct ObdResponderStatistics {
    std::uint64_t received_frames = 0;
    std::uint64_t accepted_requests = 0;
    std::uint64_t functional_requests = 0;
    std::uint64_t physical_requests = 0;
    std::uint64_t transmitted_frames = 0;
    std::uint64_t positive_responses = 0;
    std::uint64_t negative_responses = 0;
    std::uint64_t malformed_frames = 0;
    std::uint64_t rate_limited_responses = 0;
    std::uint64_t flow_control_timeouts = 0;
    std::uint64_t cleared_dtc_requests = 0;
};

struct ObdResponderLogEntry {
    std::uint64_t timestamp_ns = 0;
    bool transmitted = false;
    std::uint32_t can_id = 0;
    std::vector<std::uint8_t> payload;
    std::string event;
};

// Persistent vehicle-side OBD-II ECU emulator.  It owns a CAN transport and a
// worker thread, listens for functional/physical tester requests, performs
// ISO-TP request reassembly and response flow control, then emits responses
// from a thread-safe snapshot of the running MuzixDiagSys vehicle.
class SocketCanObdResponder {
public:
    SocketCanObdResponder();
    explicit SocketCanObdResponder(DiagnosticService& service, std::string ecu_name = "powertrain");
    ~SocketCanObdResponder();
    SocketCanObdResponder(const SocketCanObdResponder&) = delete;
    SocketCanObdResponder& operator=(const SocketCanObdResponder&) = delete;

    void use_loopback();
    void use_socketcan(const std::string& interface_name, bool can_fd = false);
    void configure(ObdResponderConfiguration configuration);
    [[nodiscard]] ObdResponderConfiguration configuration() const;

    // A real SocketCAN responder must be explicitly armed for an isolated
    // bench bus.  Loopback mode does not require arming.
    void arm_isolated_bench(bool armed);
    [[nodiscard]] bool isolated_bench_armed() const;

    void bind_diagnostic_service(DiagnosticService& service, std::string ecu_name = "powertrain");
    void update_live_data(ObdLiveData data);
    [[nodiscard]] ObdLiveData live_data() const;
    void add_dtc(const std::string& category, const std::string& code);
    void remove_dtc(const std::string& category, const std::string& code);
    void clear_dtcs(const std::string& category = "all");
    void set_readiness(std::uint8_t supported_mask, std::uint8_t complete_mask,
                       bool compression_ignition);

    void start();
    void stop() noexcept;
    [[nodiscard]] bool running() const noexcept;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] ObdResponderStatistics statistics() const;
    [[nodiscard]] std::vector<ObdResponderLogEntry> recent_log(std::size_t maximum_entries = 100U) const;
    void clear_log();
    void export_log_jsonl(const std::string& path) const;

    // Deterministic protocol entry point used by qualification tests and local
    // tooling.  It processes one incoming CAN frame and returns the immediate
    // response frames; the background worker uses the same state machine.
    [[nodiscard]] std::vector<CanFrame> process_frame(const CanFrame& frame);
    // Inject a frame into the in-process virtual bench while the loopback
    // worker is running.  This exercises the identical background receive and
    // transmit path without requiring a kernel vcan interface.
    void inject_loopback_frame(const CanFrame& frame);

private:
    struct RequestAssembly {
        std::size_t expected_size = 0;
        std::uint8_t next_sequence = 1U;
        std::uint8_t frames_in_block = 0U;
        std::vector<std::uint8_t> payload;
        std::chrono::steady_clock::time_point deadline{};
    };
    struct PendingResponse {
        std::vector<CanFrame> frames;
        std::size_t next_index = 1U;
        std::chrono::steady_clock::time_point deadline{};
    };

    // Serializes lifecycle transitions independently from protocol-state access.
    // A dedicated mutex prevents concurrent start/stop/reconfiguration calls from
    // assigning over a joinable worker thread or replacing its active transport.
    mutable std::mutex lifecycle_mutex_;
    mutable std::mutex mutex_;
    std::unique_ptr<CanTransport> transport_;
    DiagnosticService* diagnostic_service_ = nullptr;
    std::string diagnostic_ecu_name_{"powertrain"};
    bool loopback_ = true;
    bool isolated_bench_armed_ = false;
    std::string interface_name_ = "loopback";
    ObdResponderConfiguration configuration_{};
    ObdLiveData live_data_{};
    std::optional<ObdLiveData> freeze_frame_;
    RequestAssembly request_assembly_{};
    std::optional<PendingResponse> pending_response_;
    ObdResponderStatistics statistics_{};
    std::deque<ObdResponderLogEntry> log_;
    std::deque<std::chrono::steady_clock::time_point> response_history_;
    std::string last_error_;
    std::atomic<bool> running_{false};
    std::thread worker_;

    void worker_loop() noexcept;
    [[nodiscard]] bool stop_locked() noexcept;
    void refresh_diagnostic_snapshot_locked();
    [[nodiscard]] std::vector<CanFrame> process_frame_locked(const CanFrame& frame);
    [[nodiscard]] std::vector<CanFrame> dispatch_request_locked(
        const std::vector<std::uint8_t>& payload, bool functional);
    [[nodiscard]] std::vector<CanFrame> begin_response_locked(
        const std::vector<std::uint8_t>& payload);
    [[nodiscard]] std::vector<CanFrame> continue_response_locked(
        std::uint8_t block_size, std::uint8_t separation_time);
    bool consume_response_budget_locked();
    void expire_state_locked(std::chrono::steady_clock::time_point now);
    void append_log_locked(bool transmitted, const CanFrame& frame,
                           const std::string& event);
    void send_frames(const std::vector<CanFrame>& frames);
};

struct CanSynthesisOptions {
    double duration_s = 60.0;
    double sample_period_s = 0.01;
    std::uint64_t seed = 1;
    std::string drive_cycle = "urban";
    std::string fault = "none";
    double fault_severity = 0.7;
    double timestamp_jitter_us = 50.0;
    double dropout_probability = 0.0;
    bool include_can_fd = true;
};

struct SyntheticSignalRow {
    double time_s = 0.0;
    double speed_kmh = 0.0;
    double engine_rpm = 0.0;
    double throttle_pct = 0.0;
    double brake_pct = 0.0;
    double coolant_c = 0.0;
    double fuel_rate_l_h = 0.0;
    double battery_voltage_v = 0.0;
    double battery_soc_pct = 0.0;
    double yaw_rate_deg_s = 0.0;
    double steering_deg = 0.0;
    int gear = 0;
    std::string fault_label;
};

struct SyntheticCanDataset {
    CanSynthesisOptions options;
    std::vector<CanFrame> frames;
    std::vector<SyntheticSignalRow> signals;
    std::map<std::uint32_t,std::string> message_names;
};

// Produces coherent multi-ECU traffic and labelled ground truth.  The generator
// uses one physical state trajectory for every message, so engine, chassis,
// battery, body, and OBD channels remain mutually consistent instead of being
// independent random signals.
class CanDataSynthesizer {
public:
    const SyntheticCanDataset& generate(CanSynthesisOptions options);
    const SyntheticCanDataset& augment(const std::vector<CanCaptureRecord>& source,
                                       const std::string& transformation,
                                       double severity, std::uint64_t seed);
    [[nodiscard]] const SyntheticCanDataset* last() const noexcept;
    [[nodiscard]] std::string status() const;
    void export_signal_csv(const std::string& path) const;
    void export_candump(const std::string& path, const std::string& interface_name = "vcan0") const;
    void export_jsonl(const std::string& path) const;
    void export_dbc(const std::string& path) const;
private:
    std::optional<SyntheticCanDataset> last_;
};

// Authoritative protocol encoder used by the DiagnosticService. The overload
// carrying a freeze frame and clear flag is the complete stateful form; the
// shorter overload is retained for compatibility and stateless tooling.
[[nodiscard]] std::vector<std::uint8_t> encode_obd_service_response(
    ObdLiveData& data, const std::optional<ObdLiveData>& freeze_frame,
    const std::vector<std::uint8_t>& request, bool allow_mode04_clear,
    bool* cleared_dtcs);
[[nodiscard]] std::vector<std::uint8_t> encode_obd_service_response(
    ObdLiveData& data, const std::vector<std::uint8_t>& request,
    bool allow_mode04_clear = true);

[[nodiscard]] std::string can_access_mode_name(CanAccessMode mode);
[[nodiscard]] CanAccessMode parse_can_access_mode(const std::string& text);

} // namespace aesim::industrial

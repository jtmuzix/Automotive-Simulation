#pragma once

#include "aesim/industrial/signals.hpp"

#include <array>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::industrial {

class NetworkFaultLaboratory;

struct CanFrame {
    std::uint32_t id = 0;
    std::array<std::uint8_t, 64> data{};
    std::uint8_t size = 0;
    bool extended = false;
    bool fd = false;
    bool bitrate_switch = false;
    bool error_state_indicator = false;
    std::uint64_t timestamp_ns = 0;
};

struct CanStatistics {
    std::uint64_t transmitted = 0;
    std::uint64_t received = 0;
    std::uint64_t dropped = 0;
    std::uint64_t invalid = 0;
    std::uint64_t bus_errors = 0;
};

class CanTransport {
public:
    virtual ~CanTransport() = default;
    virtual void open() = 0;
    virtual void close() noexcept = 0;
    [[nodiscard]] virtual bool is_open() const noexcept = 0;
    virtual void send(const CanFrame& frame) = 0;
    [[nodiscard]] virtual std::optional<CanFrame> receive(std::chrono::milliseconds timeout) = 0;
    [[nodiscard]] virtual std::string description() const = 0;
};

class LoopbackCanTransport final : public CanTransport {
public:
    void open() override;
    void close() noexcept override;
    [[nodiscard]] bool is_open() const noexcept override;
    void send(const CanFrame& frame) override;
    [[nodiscard]] std::optional<CanFrame> receive(std::chrono::milliseconds timeout) override;
    [[nodiscard]] std::string description() const override;
    void inject(const CanFrame& frame);
private:
    mutable std::mutex mutex_;
    std::condition_variable condition_;
    bool open_ = false;
    std::deque<CanFrame> queue_;
};

class SocketCanTransport final : public CanTransport {
public:
    explicit SocketCanTransport(std::string interface_name, bool enable_fd = true,
                                std::vector<std::uint32_t> accepted_ids = {});
    ~SocketCanTransport() override;
    void open() override;
    void close() noexcept override;
    [[nodiscard]] bool is_open() const noexcept override;
    void send(const CanFrame& frame) override;
    [[nodiscard]] std::optional<CanFrame> receive(std::chrono::milliseconds timeout) override;
    [[nodiscard]] std::string description() const override;
private:
    std::string interface_name_;
    bool enable_fd_ = true;
    std::vector<std::uint32_t> accepted_ids_;
    int socket_ = -1;
};

enum class IsoTpAddressingMode {
    Normal,
    Extended
};

enum class IsoTpFlowStatus : std::uint8_t {
    ContinueToSend = 0,
    Wait = 1,
    Overflow = 2
};

struct IsoTpFlowControl {
    IsoTpFlowStatus status{IsoTpFlowStatus::ContinueToSend};
    std::uint8_t block_size{0};
    std::uint8_t separation_time{0};
};

struct IsoTpConfiguration {
    std::uint32_t transmit_id = 0x7E8;
    std::uint32_t receive_id = 0x7E0;
    std::size_t link_payload = 8;
    std::uint8_t block_size = 0;
    std::uint8_t separation_time_ms = 0;
    bool extended_ids = false;
    IsoTpAddressingMode addressing_mode = IsoTpAddressingMode::Normal;
    std::uint8_t transmit_address_extension = 0;
    std::uint8_t receive_address_extension = 0;
    bool pad_frames = true;
    std::uint8_t padding_byte = 0xAA;
    bool can_fd_bitrate_switch = true;
    std::size_t maximum_payload = 0xFFFFFU;
    std::chrono::milliseconds reassembly_timeout{1000};
};

struct KernelIsoTpConfiguration {
    std::string interface_name{"vcan0"};
    std::uint32_t transmit_id{0x7E8};
    std::uint32_t receive_id{0x7E0};
    bool extended_ids{false};
    bool can_fd{false};
    bool transmit_padding{true};
    bool receive_padding{false};
    std::uint8_t transmit_padding_byte{0x00};
    std::uint8_t receive_padding_byte{0x00};
    std::uint8_t block_size{0};
    std::uint8_t separation_time{0};
    std::chrono::milliseconds receive_timeout{1000};
    std::optional<std::uint8_t> transmit_address_extension;
    std::optional<std::uint8_t> receive_address_extension;
};

class KernelIsoTpTransport {
public:
    explicit KernelIsoTpTransport(KernelIsoTpConfiguration configuration);
    KernelIsoTpTransport(std::string interface_name, std::uint32_t transmit_id,
                         std::uint32_t receive_id, bool extended_ids = false,
                         bool can_fd = false);
    ~KernelIsoTpTransport();
    KernelIsoTpTransport(const KernelIsoTpTransport&) = delete;
    KernelIsoTpTransport& operator=(const KernelIsoTpTransport&) = delete;
    void open();
    void close() noexcept;
    [[nodiscard]] bool is_open() const noexcept;
    void send(const std::vector<std::uint8_t>& payload);
    [[nodiscard]] std::optional<std::vector<std::uint8_t>> receive(
        std::chrono::milliseconds timeout);
    [[nodiscard]] std::string description() const;
private:
    KernelIsoTpConfiguration configuration_{};
    int socket_{-1};
};

class IsoTpEndpoint {
public:
    explicit IsoTpEndpoint(IsoTpConfiguration configuration = {});
    [[nodiscard]] std::vector<CanFrame> segment(const std::vector<std::uint8_t>& payload,
                                                std::uint64_t timestamp_ns = 0) const;
    [[nodiscard]] std::optional<std::vector<std::uint8_t>> ingest(const CanFrame& frame);
    [[nodiscard]] CanFrame flow_control(IsoTpFlowStatus status = IsoTpFlowStatus::ContinueToSend,
                                        std::uint8_t block_size = 0,
                                        std::uint8_t separation_time = 0,
                                        std::uint64_t timestamp_ns = 0) const;
    [[nodiscard]] std::optional<IsoTpFlowControl> parse_flow_control(const CanFrame& frame) const;
    void reset() noexcept;
    [[nodiscard]] const IsoTpConfiguration& configuration() const noexcept;
private:
    IsoTpConfiguration configuration_;
    std::vector<std::uint8_t> receive_buffer_;
    std::size_t expected_size_ = 0;
    std::uint8_t next_sequence_ = 1;
    std::chrono::steady_clock::time_point receive_deadline_{};
};

struct DiagnosticTroubleCode {
    std::uint32_t code = 0;
    std::uint8_t status = 0;
    std::uint32_t occurrence_count = 0;
    std::string description;
};

class UdsServer {
public:
    enum class Session : std::uint8_t { Default = 1, Programming = 2, Extended = 3 };
    UdsServer();

    void set_did(std::uint16_t did, std::vector<std::uint8_t> value, bool writable = false);
    [[nodiscard]] std::optional<std::vector<std::uint8_t>> did(std::uint16_t did) const;
    void set_dtc(DiagnosticTroubleCode dtc);
    void clear_dtcs();
    [[nodiscard]] std::vector<DiagnosticTroubleCode> dtcs() const;
    [[nodiscard]] std::vector<std::uint8_t> handle(const std::vector<std::uint8_t>& request);
    [[nodiscard]] Session session() const noexcept;
    [[nodiscard]] bool security_unlocked() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    struct DidEntry { std::vector<std::uint8_t> value; bool writable = false; };
    std::map<std::uint16_t, DidEntry> dids_;
    std::map<std::uint32_t, DiagnosticTroubleCode> dtcs_;
    Session session_ = Session::Default;
    bool security_unlocked_ = false;
    std::uint32_t seed_ = 0x4A17C39B;
    std::uint64_t request_counter_ = 0;
    bool communication_enabled_ = true;
    bool dtc_setting_enabled_ = true;
    std::vector<std::uint8_t> memory_{std::vector<std::uint8_t>(65536U, 0xFFU)};
    bool download_active_ = false;
    std::uint32_t download_address_ = 0;
    std::uint32_t download_expected_size_ = 0;
    std::vector<std::uint8_t> download_buffer_;
    std::uint8_t next_block_sequence_counter_ = 1U;
    std::map<std::uint16_t,std::vector<std::uint8_t>> io_control_state_;

    static std::vector<std::uint8_t> negative(std::uint8_t service, std::uint8_t code);
    static std::uint32_t derive_key(std::uint32_t seed);
};

struct J1939Name {
    std::uint64_t identity_number = 1;
    std::uint16_t manufacturer_code = 0x7FF;
    std::uint8_t ecu_instance = 0;
    std::uint8_t function_instance = 0;
    std::uint8_t function = 0;
    std::uint8_t vehicle_system = 0;
    std::uint8_t vehicle_system_instance = 0;
    std::uint8_t industry_group = 0;
    bool arbitrary_address_capable = true;
    [[nodiscard]] std::uint64_t encode() const noexcept;
};

struct J1939Message {
    std::uint8_t priority = 6;
    std::uint32_t pgn = 0;
    std::uint8_t source = 0x80;
    std::uint8_t destination = 0xFF;
    std::vector<std::uint8_t> payload;
};

class J1939Stack {
public:
    explicit J1939Stack(J1939Name name = {}, std::uint8_t preferred_address = 0x80);
    [[nodiscard]] std::vector<CanFrame> encode(const J1939Message& message,
                                               std::uint64_t timestamp_ns = 0) const;
    [[nodiscard]] std::optional<J1939Message> ingest(const CanFrame& frame);
    [[nodiscard]] CanFrame address_claim(std::uint64_t timestamp_ns = 0) const;
    [[nodiscard]] J1939Message dm1(const std::vector<DiagnosticTroubleCode>& dtcs) const;
    [[nodiscard]] J1939Message dm2(const std::vector<DiagnosticTroubleCode>& dtcs) const;
    [[nodiscard]] std::uint8_t address() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    struct BamAssembly {
        std::uint32_t pgn = 0;
        std::size_t expected_bytes = 0;
        std::uint8_t expected_packets = 0;
        std::uint8_t next_packet = 1;
        std::vector<std::uint8_t> payload;
    };
    J1939Name name_;
    std::uint8_t address_ = 0x80;
    std::map<std::uint8_t, BamAssembly> bam_;
    std::uint64_t received_messages_ = 0;
    std::uint64_t transmitted_messages_ = 0;

    static std::uint32_t can_id(const J1939Message& message);
    static J1939Message decode_single(const CanFrame& frame);
};

class AutomotiveNetwork {
public:
    AutomotiveNetwork();
    ~AutomotiveNetwork();

    void use_loopback();
    void use_socketcan(const std::string& interface_name, bool can_fd = true);
    void open();
    void close() noexcept;
    [[nodiscard]] bool is_open() const noexcept;
    [[nodiscard]] std::string status() const;

    void send(const CanFrame& frame);
    [[nodiscard]] std::optional<CanFrame> receive(std::chrono::milliseconds timeout = std::chrono::milliseconds(0));
    [[nodiscard]] std::vector<CanFrame> uds_request(const std::vector<std::uint8_t>& request);
    void poll();

    UdsServer& uds() noexcept;
    J1939Stack& j1939() noexcept;
    NetworkFaultLaboratory& fault_lab() noexcept;
    [[nodiscard]] const NetworkFaultLaboratory& fault_lab() const noexcept;
    [[nodiscard]] CanStatistics statistics() const;
private:
    std::unique_ptr<CanTransport> transport_;
    IsoTpEndpoint diagnostic_endpoint_;
    UdsServer uds_;
    J1939Stack j1939_;
    std::unique_ptr<NetworkFaultLaboratory> fault_lab_;
    bool peer_supports_fd_ = true;
    std::deque<CanFrame> receive_backlog_;
    mutable std::mutex mutex_;
    CanStatistics statistics_;
};

[[nodiscard]] std::string can_frame_string(const CanFrame& frame);
[[nodiscard]] std::vector<std::uint8_t> parse_hex_bytes(const std::string& text);
[[nodiscard]] std::string hex_bytes(const std::vector<std::uint8_t>& bytes);

} // namespace aesim::industrial

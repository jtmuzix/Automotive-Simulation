#pragma once

#include <chrono>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

namespace aesim::industrial {

enum class IoDirection { Input, Output, Bidirectional };
enum class IoType { AnalogVoltage, AnalogCurrent, Digital, Pwm, Frequency, Encoder, Thermocouple };

struct IoChannel {
    std::uint16_t id = 0;
    std::string name;
    IoDirection direction = IoDirection::Input;
    IoType type = IoType::AnalogVoltage;
    std::string unit = "V";
    double minimum = 0.0;
    double maximum = 5.0;
    double safe_value = 0.0;
};

struct IoValue {
    std::uint16_t channel = 0;
    double value = 0.0;
    std::uint64_t timestamp_ns = 0;
    std::uint32_t quality = 0;
};

class HilIoBackend {
public:
    virtual ~HilIoBackend() = default;
    virtual void configure(const std::vector<IoChannel>& channels) = 0;
    virtual void open() = 0;
    virtual void close() noexcept = 0;
    [[nodiscard]] virtual bool is_open() const noexcept = 0;
    [[nodiscard]] virtual std::vector<IoValue> read_inputs(std::chrono::nanoseconds timeout) = 0;
    virtual void write_outputs(const std::vector<IoValue>& values) = 0;
    virtual void enter_safe_state() noexcept = 0;
    [[nodiscard]] virtual std::string description() const = 0;
};

class LoopbackHilIo final : public HilIoBackend {
public:
    void configure(const std::vector<IoChannel>& channels) override;
    void open() override;
    void close() noexcept override;
    [[nodiscard]] bool is_open() const noexcept override;
    [[nodiscard]] std::vector<IoValue> read_inputs(std::chrono::nanoseconds timeout) override;
    void write_outputs(const std::vector<IoValue>& values) override;
    void enter_safe_state() noexcept override;
    [[nodiscard]] std::string description() const override;
    void inject_input(IoValue value);
    [[nodiscard]] std::optional<IoValue> output(std::uint16_t channel) const;
private:
    mutable std::mutex mutex_;
    bool open_ = false;
    std::map<std::uint16_t, IoChannel> channels_;
    std::deque<IoValue> inputs_;
    std::map<std::uint16_t, IoValue> outputs_;
};

class UdpHilIo final : public HilIoBackend {
public:
    UdpHilIo(std::string local_address, std::uint16_t local_port,
             std::string remote_address, std::uint16_t remote_port);
    ~UdpHilIo() override;
    void configure(const std::vector<IoChannel>& channels) override;
    void open() override;
    void close() noexcept override;
    [[nodiscard]] bool is_open() const noexcept override;
    [[nodiscard]] std::vector<IoValue> read_inputs(std::chrono::nanoseconds timeout) override;
    void write_outputs(const std::vector<IoValue>& values) override;
    void enter_safe_state() noexcept override;
    [[nodiscard]] std::string description() const override;
private:
    std::string local_address_;
    std::uint16_t local_port_ = 0;
    std::string remote_address_;
    std::uint16_t remote_port_ = 0;
    std::map<std::uint16_t, IoChannel> channels_;
    int socket_ = -1;
};

class HilIoManager {
public:
    HilIoManager();
    void use_loopback();
    void use_udp(const std::string& local_address, std::uint16_t local_port,
                 const std::string& remote_address, std::uint16_t remote_port);
    void configure(std::vector<IoChannel> channels);
    void open();
    void close() noexcept;
    [[nodiscard]] bool is_open() const noexcept;
    [[nodiscard]] std::vector<IoValue> read(std::chrono::nanoseconds timeout = std::chrono::nanoseconds(0));
    void write(const std::vector<IoValue>& values);
    void safe_state() noexcept;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] const std::vector<IoChannel>& channels() const noexcept;
private:
    std::unique_ptr<HilIoBackend> backend_;
    std::vector<IoChannel> channels_;
    std::uint64_t reads_ = 0;
    std::uint64_t writes_ = 0;
    std::uint64_t errors_ = 0;
};

[[nodiscard]] std::string io_type_name(IoType type);
[[nodiscard]] std::string io_direction_name(IoDirection direction);

} // namespace aesim::industrial

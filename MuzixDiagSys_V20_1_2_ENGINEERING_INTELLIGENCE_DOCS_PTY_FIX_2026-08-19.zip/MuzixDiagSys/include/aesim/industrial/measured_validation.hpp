#pragma once

#include <cstddef>
#include <functional>
#include <limits>
#include <string>
#include <vector>

namespace aesim::industrial {

struct ValidationSample {
    double time_s{0.0};
    double measured{0.0};
    double simulated{0.0};
    double weight{1.0};
};

struct ValidationMetrics {
    double measured_mean{0.0};
    double simulated_mean{0.0};
    double bias{0.0};
    double mae{0.0};
    double rmse{0.0};
    double nrmse{0.0};
    double cvrmse_pct{0.0};
    double maximum_absolute_error{0.0};
    double p95_absolute_error{0.0};
    double r2{0.0};
    double correlation{0.0};
    std::size_t samples{0};
};

struct ParameterFit {
    std::vector<double> coefficients;
    double rmse{0.0};
    std::size_t samples{0};
};

struct ParameterDefinition {
    std::string name;
    double initial{0.0};
    double lower{-std::numeric_limits<double>::infinity()};
    double upper{std::numeric_limits<double>::infinity()};
    double finite_difference_step{0.0};
};

struct IdentificationOptions {
    std::size_t maximum_iterations{100};
    double objective_tolerance{1.0e-10};
    double parameter_tolerance{1.0e-8};
    double initial_damping{1.0e-3};
    double huber_delta{1.5};
    bool robust_loss{true};
};

struct IdentificationResult {
    std::vector<std::string> parameter_names;
    std::vector<double> initial_parameters;
    std::vector<double> parameters;
    ValidationMetrics initial_metrics;
    ValidationMetrics final_metrics;
    double initial_objective{0.0};
    double final_objective{0.0};
    std::size_t iterations{0};
    std::size_t accepted_steps{0};
    bool converged{false};
    std::string termination_reason;
};

using ModelEvaluator = std::function<std::vector<double>(
    const std::vector<double>& parameters,
    const std::vector<ValidationSample>& samples)>;

class MeasuredDataPipeline {
public:
    void load_csv(const std::string& path, const std::string& time_column,
                  const std::string& measured_column,
                  const std::string& simulated_column,
                  const std::string& weight_column = {});
    void set_samples(std::vector<ValidationSample> samples);
    void sort_and_validate();
    void select_time_window(double start_s, double end_s);
    void reject_outliers(double median_absolute_deviation_multiplier = 6.0);

    [[nodiscard]] const std::vector<ValidationSample>& samples() const noexcept {
        return samples_;
    }
    [[nodiscard]] ValidationMetrics validate() const;
    [[nodiscard]] ValidationMetrics validate_predictions(
        const std::vector<double>& predictions) const;
    [[nodiscard]] ParameterFit identify_affine() const;
    [[nodiscard]] ParameterFit identify_polynomial(unsigned degree,
                                                   double ridge = 0.0) const;
    [[nodiscard]] IdentificationResult identify_parameters(
        const std::vector<ParameterDefinition>& parameters,
        const ModelEvaluator& evaluator,
        const IdentificationOptions& options = {}) const;

    void export_residual_csv(const std::string& path) const;
    void export_report(const std::string& path) const;
    void export_identification_report(const std::string& path,
                                      const IdentificationResult& result) const;

private:
    std::vector<ValidationSample> samples_;
};

} // namespace aesim::industrial

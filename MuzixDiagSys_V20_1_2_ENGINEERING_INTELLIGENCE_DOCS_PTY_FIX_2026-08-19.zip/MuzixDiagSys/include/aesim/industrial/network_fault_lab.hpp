#pragma once

#include "aesim/industrial/network.hpp"
#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

namespace aesim::industrial {

enum class NetworkDirection { Transmit, Receive };
enum class CanControllerState { ErrorActive, ErrorPassive, BusOff };

enum class NetworkFaultMode {
    CanCongestion,
    CanErrorPassive,
    CanBusOff,
    FrameDrop,
    FrameDelay,
    FrameDuplicate,
    FrameReorder,
    RollingCounter,
    Checksum,
    GatewayRoute,
    CanFdMismatch,
    IsoTpSequence,
    IsoTpFlowControl,
    DoipActivation,
    SomeIpDiscovery,
    EthernetJitter,
    TsnViolation
};

struct NetworkFaultSetting {
    NetworkFaultMode mode = NetworkFaultMode::FrameDrop;
    bool enabled = true;
    double severity = 0.0;
    double probability = 1.0;
    std::string scope{"*"};
    doc::Value parameters{doc::Value::Object{}};
};

struct NetworkFaultEvent {
    std::uint64_t sequence = 0;
    std::uint64_t timestamp_ns = 0;
    NetworkFaultMode mode = NetworkFaultMode::FrameDrop;
    NetworkDirection direction = NetworkDirection::Transmit;
    std::string action;
    std::string detail;
    std::optional<std::uint32_t> can_id;
};

struct NetworkFaultStatistics {
    std::uint64_t input_frames = 0;
    std::uint64_t output_frames = 0;
    std::uint64_t dropped_frames = 0;
    std::uint64_t delayed_frames = 0;
    std::uint64_t duplicated_frames = 0;
    std::uint64_t reordered_frames = 0;
    std::uint64_t corrupted_frames = 0;
    std::uint64_t routing_errors = 0;
    std::uint64_t protocol_failures = 0;
    std::uint64_t bus_state_transitions = 0;
    std::uint64_t ethernet_packets = 0;
    std::uint64_t tsn_violations = 0;
    std::map<std::string, std::uint64_t> triggers;
};

struct CanNodeFaultState {
    std::string node{"default"};
    std::uint16_t transmit_error_counter = 0;
    std::uint16_t receive_error_counter = 0;
    CanControllerState state = CanControllerState::ErrorActive;
    std::uint64_t bus_off_since_ns = 0;
    std::uint64_t recover_at_ns = 0;
};

struct DoipActivationResult {
    bool accepted = true;
    std::uint8_t response_code = 0x10;
    std::string reason{"routing activation accepted"};
};

struct SomeIpDiscoveryResult {
    bool available = true;
    bool stale_offer = false;
    std::uint32_t ttl_ms = 3000;
    std::uint64_t delivery_delay_ns = 0;
    std::string reason{"service available"};
};

struct EthernetDeliveryResult {
    bool delivered = true;
    std::uint64_t delivery_timestamp_ns = 0;
    std::int64_t jitter_ns = 0;
    bool tsn_violation = false;
    std::string reason{"delivered within schedule"};
};

class NetworkFaultLaboratory {
public:
    explicit NetworkFaultLaboratory(std::uint64_t seed = 1);

    void reset(std::uint64_t seed = 1);
    void clear_faults();
    void set_seed(std::uint64_t seed);
    [[nodiscard]] std::uint64_t seed() const;

    void set_fault(NetworkFaultSetting setting);
    bool remove_fault(NetworkFaultMode mode);
    [[nodiscard]] std::optional<NetworkFaultSetting> fault(NetworkFaultMode mode) const;
    [[nodiscard]] std::vector<NetworkFaultSetting> faults() const;

    // CAN traffic is processed in deterministic order. Delayed and reordered
    // traffic is retained internally and released by release_due_can().
    [[nodiscard]] std::vector<CanFrame> process_can(
        const CanFrame& frame, NetworkDirection direction,
        std::uint64_t now_ns, bool peer_supports_fd = true);
    [[nodiscard]] std::vector<CanFrame> release_due_can(
        NetworkDirection direction, std::uint64_t now_ns, bool flush_all = false);

    [[nodiscard]] std::vector<CanFrame> process_isotp(
        const std::vector<CanFrame>& frames, NetworkDirection direction,
        std::uint64_t now_ns, bool peer_supports_fd = true);

    void inject_can_error(const std::string& node, unsigned transmit_points,
                          unsigned receive_points, std::uint64_t now_ns);
    void recover_node(const std::string& node, std::uint64_t now_ns, bool force = false);
    void tick(std::uint64_t now_ns);
    [[nodiscard]] CanNodeFaultState controller_state(const std::string& node = "default") const;

    [[nodiscard]] DoipActivationResult evaluate_doip_activation(
        std::uint16_t source_address, std::uint16_t target_address,
        std::uint8_t activation_type, std::uint64_t now_ns);
    [[nodiscard]] SomeIpDiscoveryResult evaluate_someip_discovery(
        std::uint16_t service_id, std::uint16_t instance_id,
        std::uint32_t advertised_ttl_ms, std::uint64_t now_ns);
    [[nodiscard]] EthernetDeliveryResult process_ethernet(
        std::size_t payload_bytes, unsigned priority,
        std::uint64_t scheduled_timestamp_ns, std::uint64_t now_ns);

    [[nodiscard]] NetworkFaultStatistics statistics() const;
    [[nodiscard]] std::vector<NetworkFaultEvent> events(std::size_t maximum = 128) const;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] std::string events_report(std::size_t maximum = 32) const;
    [[nodiscard]] std::string command(const std::vector<std::string>& arguments);

    [[nodiscard]] doc::Value to_document() const;
    void from_document(const doc::Value& document);
    bool save(const std::string& path, std::string& error) const;
    void load(const std::string& path);

private:
    struct PendingCanFrame {
        CanFrame frame;
        NetworkDirection direction = NetworkDirection::Transmit;
        std::uint64_t due_ns = 0;
        std::uint64_t ordinal = 0;
    };

    mutable std::mutex mutex_;
    std::uint64_t seed_ = 1;
    std::uint64_t rng_state_ = 1;
    std::uint64_t event_sequence_ = 0;
    std::uint64_t pending_ordinal_ = 0;
    std::map<NetworkFaultMode, NetworkFaultSetting> faults_;
    std::map<std::string, CanNodeFaultState> nodes_;
    std::deque<PendingCanFrame> pending_can_;
    std::optional<PendingCanFrame> held_tx_reorder_;
    std::optional<PendingCanFrame> held_rx_reorder_;
    std::map<std::string, std::uint8_t> frozen_counters_;
    std::deque<NetworkFaultEvent> events_;
    NetworkFaultStatistics statistics_;

    [[nodiscard]] std::uint64_t next_random_locked();
    [[nodiscard]] double uniform_locked();
    [[nodiscard]] bool triggers_locked(const NetworkFaultSetting& setting,
                                       const CanFrame* frame,
                                       NetworkDirection direction);
    [[nodiscard]] bool scope_matches_locked(const NetworkFaultSetting& setting,
                                            const CanFrame* frame,
                                            NetworkDirection direction) const;
    [[nodiscard]] static double parameter_number(const NetworkFaultSetting& setting,
                                                 const std::string& key,
                                                 double fallback);
    [[nodiscard]] static std::string parameter_string(const NetworkFaultSetting& setting,
                                                      const std::string& key,
                                                      const std::string& fallback);
    [[nodiscard]] static bool parameter_bool(const NetworkFaultSetting& setting,
                                             const std::string& key,
                                             bool fallback);
    void event_locked(NetworkFaultMode mode, NetworkDirection direction,
                      std::uint64_t timestamp_ns, std::string action,
                      std::string detail, std::optional<std::uint32_t> can_id = {});
    void update_node_state_locked(CanNodeFaultState& node, std::uint64_t now_ns);
    [[nodiscard]] std::vector<CanFrame> release_due_can_locked(
        NetworkDirection direction, std::uint64_t now_ns, bool flush_all);
};

[[nodiscard]] const char* network_fault_mode_name(NetworkFaultMode mode) noexcept;
[[nodiscard]] const char* network_direction_name(NetworkDirection direction) noexcept;
[[nodiscard]] const char* can_controller_state_name(CanControllerState state) noexcept;
[[nodiscard]] std::optional<NetworkFaultMode> parse_network_fault_mode(const std::string& text);

} // namespace aesim::industrial

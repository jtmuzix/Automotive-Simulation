#pragma once

#include "aesim/industrial/signals.hpp"

#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace aesim::industrial {

struct MdfRecordingConfiguration {
    std::string path;
    std::vector<std::string> channels;
    double sample_period_s = 0.001;
    std::size_t maximum_samples = 10'000'000;
    std::string comment = "MuzixDiagSys deterministic measurement recording";
};

struct MdfStatistics {
    std::uint64_t samples = 0;
    std::uint64_t skipped_samples = 0;
    std::uint64_t bytes_written = 0;
    double first_time_s = 0.0;
    double last_time_s = 0.0;
};

class MdfRecorder {
public:
    explicit MdfRecorder(SignalRegistry& signals);
    ~MdfRecorder();

    void start(MdfRecordingConfiguration configuration);
    void sample(double simulation_time_s);
    void stop();
    [[nodiscard]] bool active() const noexcept;
    [[nodiscard]] MdfStatistics statistics() const;
    [[nodiscard]] std::string status() const;

    static bool validate_file(const std::string& path, std::string& error);
private:
    SignalRegistry& signals_;
    mutable std::mutex mutex_;
    bool active_ = false;
    MdfRecordingConfiguration configuration_;
    std::vector<SignalDescriptor> descriptors_;
    std::vector<double> rows_; // row-major: time + configured channels
    double next_sample_time_s_ = 0.0;
    MdfStatistics statistics_;

    void write_file_locked();
};

} // namespace aesim::industrial

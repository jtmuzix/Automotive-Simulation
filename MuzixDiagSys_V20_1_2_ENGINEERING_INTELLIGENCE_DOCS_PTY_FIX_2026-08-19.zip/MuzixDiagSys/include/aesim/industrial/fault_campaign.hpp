#pragma once

#include "aesim/industrial/network.hpp"
#include "aesim/professional/document.hpp"

#include <functional>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::industrial {

struct FaultCase {
    std::string id;
    std::string target;
    std::string fault;
    double value = 1.0;
    double injection_time_s = 0.0;
    double duration_s = 1.0;
    std::uint32_t expected_dtc = 0;
    double detection_deadline_s = 1.0;
    std::string safety_expression;
    double maximum_safe_state_latency_s = 1.0;
    // ISO 26262-style ordinal factors support risk-weighted coverage rather
    // than treating a cosmetic sensor fault like a loss of braking authority.
    int severity = 5;
    int exposure = 5;
    int controllability = 5;
    double occurrence_probability = 1.0;
};

struct FaultCaseResult {
    FaultCase fault_case;
    bool injection_succeeded = false;
    bool detected = false;
    bool correct_dtc = false;
    bool safety_preserved = true;
    bool safe_state_reached = false;
    double detection_latency_s = -1.0;
    double safe_state_latency_s = -1.0;
    std::vector<std::uint32_t> observed_dtcs;
    std::vector<std::uint32_t> unexpected_dtcs;
    double initial_risk_score = 0.0;
    double residual_risk_score = 0.0;
    std::string message;
    [[nodiscard]] bool passed() const noexcept;
};

struct DiagnosticCoverageReport {
    std::string name;
    std::vector<FaultCaseResult> cases;
    std::size_t injected = 0;
    std::size_t detected = 0;
    std::size_t correct_dtc = 0;
    std::size_t safe = 0;
    std::size_t passed = 0;
    std::size_t false_positives = 0;
    double diagnostic_coverage_percent = 0.0;
    double correct_classification_percent = 0.0;
    double safe_mitigation_percent = 0.0;
    double mean_detection_latency_s = 0.0;
    double maximum_detection_latency_s = 0.0;
    double weighted_diagnostic_coverage_percent = 0.0;
    double weighted_safe_mitigation_percent = 0.0;
    double initial_risk_score = 0.0;
    double residual_risk_score = 0.0;
    double risk_reduction_percent = 0.0;
    std::size_t true_positives = 0;
    std::size_t false_negatives = 0;
    std::size_t true_negatives = 0;
    std::size_t control_runs = 0;
    std::map<std::string,double> coverage_by_target_percent;
    std::map<std::string,double> coverage_by_fault_percent;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] doc::Value to_document() const;
};

class FaultCampaignRunner {
public:
    using ResetCallback = std::function<void()>;
    using StepCallback = std::function<void(double)>;
    using TimeCallback = std::function<double()>;
    using ReadCallback = std::function<double(const std::string&)>;
    using InjectCallback = std::function<std::string(const std::string&, const std::string&, double)>;
    using ClearCallback = std::function<std::string(const std::string&)>;
    using DtcCallback = std::function<std::vector<DiagnosticTroubleCode>()>;

    FaultCampaignRunner(ResetCallback reset, StepCallback step, TimeCallback time,
                        ReadCallback read, InjectCallback inject, ClearCallback clear,
                        DtcCallback dtcs);

    [[nodiscard]] DiagnosticCoverageReport run_file(const std::string& manifest_path,
                                                     const std::string& output_directory = {});
    [[nodiscard]] DiagnosticCoverageReport run_document(const doc::Value& manifest,
                                                         const std::string& output_directory = {});
    [[nodiscard]] const DiagnosticCoverageReport& last_report() const noexcept;
    static void write_template(const std::string& path);

private:
    ResetCallback reset_;
    StepCallback step_;
    TimeCallback time_;
    ReadCallback read_;
    InjectCallback inject_;
    ClearCallback clear_;
    DtcCallback dtcs_;
    DiagnosticCoverageReport last_report_;

    [[nodiscard]] std::vector<FaultCase> parse_cases(const doc::Value& manifest) const;
    [[nodiscard]] FaultCaseResult execute_case(const FaultCase& fault_case,
                                               double precondition_s, double observation_s,
                                               double step_s);
    [[nodiscard]] bool evaluate(const std::string& expression) const;
    void advance(double seconds, double step_s);
    static void write_outputs(const DiagnosticCoverageReport& report, const std::string& directory);
};

} // namespace aesim::industrial

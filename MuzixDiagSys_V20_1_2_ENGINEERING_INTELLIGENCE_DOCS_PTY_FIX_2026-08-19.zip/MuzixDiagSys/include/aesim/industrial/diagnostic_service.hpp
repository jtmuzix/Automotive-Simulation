#pragma once

#include "aesim/industrial/can_obd.hpp"

#include <cstdint>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::industrial {

class NetworkFaultLaboratory;

struct DiagnosticEcu {
    std::string name{"powertrain"};
    std::uint16_t logical_address{0x10};
    std::uint32_t functional_request_id{0x7DF};
    std::uint32_t request_id{0x7E0};
    std::uint32_t response_id{0x7E8};
    bool obd_enabled{true};
    bool uds_enabled{true};
    ObdLiveData live{};
    std::optional<ObdLiveData> freeze_frame;
    UdsServer uds{};
};

struct DiagnosticCanResponse {
    std::string ecu;
    std::uint32_t response_id{0};
    std::vector<std::uint8_t> payload;
};

struct DoipDiagnosticMessage {
    std::uint16_t source_address{0x0E00};
    std::uint16_t target_address{0};
    std::vector<std::uint8_t> user_data;
};

// Canonical diagnostic domain service. No transport or UI is permitted to
// maintain independent PID, DTC, VIN, DID, or UDS service semantics. Transport
// adapters perform framing/routing and call this object for the actual service
// result.
class DiagnosticService {
public:
    DiagnosticService();

    void bind_network_fault_laboratory(NetworkFaultLaboratory* laboratory);

    void upsert_ecu(DiagnosticEcu ecu);
    bool remove_ecu(const std::string& name);
    void clear_ecus();

    void update_live_data(const std::string& name, ObdLiveData data);
    void add_dtc(const std::string& name, const std::string& category,
                 const std::string& code);
    void remove_dtc(const std::string& name, const std::string& category,
                    const std::string& code);
    void clear_dtcs(const std::string& name, const std::string& category = "all");

    [[nodiscard]] std::vector<std::string> ecu_names() const;
    [[nodiscard]] std::optional<DiagnosticEcu> ecu(const std::string& name) const;
    [[nodiscard]] std::optional<DiagnosticEcu> ecu_by_request_id(std::uint32_t id) const;
    [[nodiscard]] std::optional<DiagnosticEcu> ecu_by_response_id(std::uint32_t id) const;
    [[nodiscard]] std::optional<DiagnosticEcu> ecu_by_logical_address(
        std::uint16_t address) const;

    [[nodiscard]] std::vector<std::uint8_t> request_obd(
        const std::string& ecu, const std::vector<std::uint8_t>& request,
        bool allow_mode04_clear = true);
    [[nodiscard]] std::vector<std::uint8_t> request_uds(
        const std::string& ecu, const std::vector<std::uint8_t>& request);

    // CAN-facing route. Functional OBD requests may return one response per
    // OBD-capable ECU; physical requests return only the addressed ECU.
    [[nodiscard]] std::vector<DiagnosticCanResponse> request_can(
        std::uint32_t request_id, const std::vector<std::uint8_t>& request,
        bool allow_mode04_clear = true);

    [[nodiscard]] std::vector<std::uint8_t> request_doip(
        std::uint16_t logical_address, const std::vector<std::uint8_t>& uds);
    [[nodiscard]] DoipDiagnosticMessage request_doip(
        const DoipDiagnosticMessage& request);
    [[nodiscard]] std::vector<std::uint8_t> request_doip_packet(
        const std::vector<std::uint8_t>& packet);

    // SOVD-compatible resource facade. Supported paths include:
    // /entities, /entities/<ecu>, /entities/<ecu>/faults,
    // /entities/<ecu>/data/<pid>, and /entities/<ecu>/operations/uds.
    [[nodiscard]] std::string request_sovd(
        const std::string& method, const std::string& path,
        const std::string& body = {});

    [[nodiscard]] std::string pid_directory() const;
    [[nodiscard]] std::string uds_directory() const;
    [[nodiscard]] std::string topology_report() const;
    [[nodiscard]] std::string topology_json() const;

private:
    mutable std::mutex mutex_;
    std::map<std::string, DiagnosticEcu> ecus_;
    NetworkFaultLaboratory* network_fault_laboratory_ = nullptr;

    [[nodiscard]] static std::vector<std::uint8_t> negative(
        const std::vector<std::uint8_t>& request, std::uint8_t nrc);
    static void validate_ecu(const DiagnosticEcu& ecu);
    static void normalize_live_data(ObdLiveData& data);
    static void synchronize_uds(DiagnosticEcu& ecu);
};

DiagnosticService& authoritative_diagnostic_service();

} // namespace aesim::industrial

#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>

namespace aesim::industrial::archive {

struct Limits {
    std::size_t maximum_entries = 4096;
    std::uint64_t maximum_entry_bytes = 512ULL * 1024ULL * 1024ULL;
    std::uint64_t maximum_total_bytes = 2ULL * 1024ULL * 1024ULL * 1024ULL;
};

bool write_zip(const std::string& path, const std::map<std::string, std::string>& files,
               std::string& error, bool deflate = true);
bool read_zip(const std::string& path, std::map<std::string, std::string>& files,
              std::string& error, const Limits& limits = {});
[[nodiscard]] bool safe_entry_name(const std::string& name);

} // namespace aesim::industrial::archive

#pragma once

#include "aesim/industrial/diagnostic_service.hpp"
#include "aesim/industrial/network.hpp"
#include "aesim/industrial/virtual_diagnostics.hpp"

#include <cstdint>
#include <map>
#include <optional>
#include <random>
#include <set>
#include <string>
#include <vector>

namespace aesim::industrial {

enum class EcmDtcState { Passed, TestFailed, Pending, Confirmed, Permanent, Healed };
enum class MonitorState { Disabled, Waiting, Running, Complete, Failed, Aborted };
enum class FlashState { Application, ProgrammingSession, Erasing, Downloading, Verifying, PendingActivation, Recovery };

struct EcmPlantInputs {
    double time_s{0.0};
    bool ignition_on{true};
    bool engine_running{false};
    double rpm{0.0};
    double speed_kmh{0.0};
    double throttle_pct{0.0};
    double accelerator_pct{0.0};
    double load_pct{0.0};
    double coolant_c{20.0};
    double intake_c{20.0};
    double ambient_c{20.0};
    double map_kpa{101.325};
    double baro_kpa{101.325};
    double maf_g_s{0.0};
    double lambda{1.0};
    double upstream_o2_v{0.45};
    double downstream_o2_v{0.45};
    double catalyst_temp_c{20.0};
    double catalyst_efficiency{1.0};
    double fuel_level_pct{75.0};
    double fuel_rate_l_h{0.0};
    double module_voltage_v{12.6};
    double evap_pressure_pa{0.0};
    double evap_leak_fraction{0.0};
    double misfire_fraction{0.0};
    double commanded_torque_pct{0.0};
    double actual_torque_pct{0.0};
    double reference_torque_nm{400.0};
    double hv_battery_soc_pct{80.0};
    double hv_battery_voltage_v{400.0};
    double hv_battery_current_a{0.0};
    double inverter_temp_c{25.0};
    double traction_motor_temp_c{25.0};
    double fuel_cell_voltage_v{0.0};
};

struct SignalProvenance {
    std::string diagnostic_name;
    std::string physical_source;
    std::string transformation;
    std::string unit;
    double sample_period_ms{10.0};
    double filter_time_constant_ms{0.0};
    double quantization{0.0};
    double last_physical{0.0};
    double last_diagnostic{0.0};
    bool valid{true};
};

struct EcmDtcRecord {
    std::string code;
    std::string description;
    EcmDtcState state{EcmDtcState::Passed};
    std::uint32_t fail_count{0};
    std::uint32_t pass_count{0};
    std::uint32_t occurrence_count{0};
    std::uint32_t aging_count{0};
    std::uint32_t warmups_since_failure{0};
    bool test_failed_this_cycle{false};
    bool warning_requested{false};
    bool permanent{false};
    double first_failure_s{-1.0};
    double last_failure_s{-1.0};
    std::map<std::string,double> freeze_frame;
};

struct EcmMonitorRecord {
    std::string name;
    MonitorState state{MonitorState::Waiting};
    bool supported{true};
    bool enabled{true};
    std::uint32_t attempts{0};
    std::uint32_t passes{0};
    std::uint32_t failures{0};
    double last_value{0.0};
    double threshold{0.0};
    double progress{0.0};
    std::string blocking_reason;
    std::string last_result;
};

struct CalibrationParameter {
    double value{0.0};
    double minimum{0.0};
    double maximum{0.0};
    std::string unit;
    bool runtime_writable{true};
};

struct HarnessFault {
    std::string path;
    std::string mode;
    double severity{0.0};
    bool active{true};
};

struct TransportFaultProfile {
    std::uint64_t frame_counter{0};
    std::uint32_t drop_every_n{0};
    std::uint32_t corrupt_every_n{0};
    std::uint32_t duplicate_every_n{0};
    std::uint32_t reorder_every_n{0};
    std::uint8_t forced_sequence_delta{0};
    double latency_ms{0.0};
    bool bus_off{false};
};

struct EcmConformanceResult {
    std::size_t passed{0};
    std::size_t failed{0};
    std::vector<std::string> failures;
    [[nodiscard]] bool ok() const noexcept { return failed == 0; }
    [[nodiscard]] std::string report() const;
};

class EcmObdPlatform {
public:
    explicit EcmObdPlatform(DiagnosticService& service = authoritative_diagnostic_service());

    void reset(bool preserve_permanent = true);
    void step(double dt_s, const EcmPlantInputs& input);
    [[nodiscard]] ObdLiveData live_data() const;

    [[nodiscard]] std::string command(const std::vector<std::string>& args);
    [[nodiscard]] std::string status_report() const;
    [[nodiscard]] std::string scheduler_report() const;
    [[nodiscard]] std::string provenance_report(const std::string& signal = {}) const;
    [[nodiscard]] std::string dtc_report(const std::string& category = "all") const;
    [[nodiscard]] std::string monitor_report(const std::string& name = {}) const;
    [[nodiscard]] std::string calibration_report(const std::string& name = {}) const;
    [[nodiscard]] std::string flash_report() const;
    [[nodiscard]] std::string harness_report() const;
    [[nodiscard]] std::string root_cause_report() const;
    [[nodiscard]] std::string test_plan(const std::string& code) const;
    [[nodiscard]] std::string active_test_report() const;
    [[nodiscard]] std::string hil_report() const;

    void set_calibration(const std::string& name, double value);
    void set_harness_fault(const std::string& path, const std::string& mode, double severity);
    void clear_harness_fault(const std::string& path = "all");
    void set_active_test(const std::string& actuator, double command_pct);
    void clear_active_tests();

    [[nodiscard]] std::vector<std::uint8_t> legacy_obd(const std::vector<std::uint8_t>& request);
    [[nodiscard]] std::vector<std::uint8_t> obdonuds(const std::vector<std::uint8_t>& request);
    [[nodiscard]] std::vector<std::uint8_t> wwh_obd(const std::vector<std::uint8_t>& request);
    [[nodiscard]] std::vector<std::uint8_t> zev_on_uds(const std::vector<std::uint8_t>& request);
    [[nodiscard]] std::vector<std::uint8_t> uds(const std::vector<std::uint8_t>& request);
    [[nodiscard]] std::vector<CanFrame> isotp_round_trip(const std::vector<std::uint8_t>& payload,
                                                        bool can_fd = false);
    [[nodiscard]] std::vector<std::uint8_t> doip(const std::vector<std::uint8_t>& uds_request,
                                                 std::uint16_t logical_address = 0x10U);

    [[nodiscard]] EcmConformanceResult run_conformance();
    [[nodiscard]] EcmConformanceResult run_fuzz(std::uint64_t seed, std::size_t cases,
                                                std::size_t maximum_payload = 128U);
    [[nodiscard]] std::string run_campaign(const std::string& name, std::size_t cycles,
                                           std::uint64_t seed = 1U);

    [[nodiscard]] const std::map<std::string,EcmDtcRecord>& dtcs() const noexcept { return dtcs_; }
    [[nodiscard]] const std::map<std::string,EcmMonitorRecord>& monitors() const noexcept { return monitors_; }
    [[nodiscard]] const std::map<std::string,SignalProvenance>& provenance() const noexcept { return provenance_; }
    [[nodiscard]] TransportFaultProfile& transport_faults() noexcept { return transport_faults_; }

private:
    DiagnosticService* service_{nullptr};
    EcmPlantInputs input_{};
    EcmPlantInputs previous_{};
    ObdLiveData live_{};
    std::map<std::string,EcmDtcRecord> dtcs_;
    std::map<std::string,EcmMonitorRecord> monitors_;
    std::map<std::string,SignalProvenance> provenance_;
    std::map<std::string,CalibrationParameter> calibrations_;
    std::map<std::string,HarnessFault> harness_faults_;
    std::map<std::string,double> active_tests_;
    TransportFaultProfile transport_faults_{};
    FlashState flash_state_{FlashState::Application};
    std::vector<std::uint8_t> flash_image_;
    std::uint32_t flash_crc_{0};
    std::uint32_t flash_generation_{1};
    bool bootloader_valid_{true};
    bool flash_verified_{true};
    bool hil_enabled_{false};
    bool hil_can_fd_{false};
    std::string hil_interface_{"vcan0"};
    double uptime_s_{0.0};
    double key_on_s_{0.0};
    double engine_run_s_{0.0};
    double warm_time_s_{0.0};
    double distance_km_{0.0};
    std::uint32_t drive_cycles_{0};
    std::uint32_t warmup_cycles_{0};
    bool was_running_{false};
    bool was_warm_{false};
    double stft_pct_{0.0};
    double ltft_pct_{0.0};
    double catalyst_integral_{0.0};
    double o2_switch_metric_{0.0};
    double evap_integral_{0.0};
    double misfire_integral_{0.0};
    std::uint64_t scheduler_ticks_{0};
    std::uint64_t scheduler_deadline_misses_{0};

    void initialize_catalogs();
    void apply_harness_faults();
    void update_provenance();
    void update_monitors(double dt_s);
    void evaluate_dtc(const std::string& code, const std::string& description,
                      bool failing, bool two_trip, bool permanent_capable);
    void rebuild_live_data();
    void synchronize_service();
    void clear_obd_dtcs(bool preserve_permanent = true);
    [[nodiscard]] std::vector<std::string> codes_for_state(EcmDtcState state) const;
    [[nodiscard]] static std::string lower(std::string value);
    [[nodiscard]] static std::vector<std::uint8_t> parse_hex_joined(const std::vector<std::string>& args,
                                                                    std::size_t begin);
    [[nodiscard]] static std::string hex(const std::vector<std::uint8_t>& bytes);
    [[nodiscard]] static std::uint32_t crc32(const std::vector<std::uint8_t>& data);
    [[nodiscard]] static const char* dtc_state_name(EcmDtcState state) noexcept;
    [[nodiscard]] static const char* monitor_state_name(MonitorState state) noexcept;
    [[nodiscard]] static const char* flash_state_name(FlashState state) noexcept;
};

} // namespace aesim::industrial

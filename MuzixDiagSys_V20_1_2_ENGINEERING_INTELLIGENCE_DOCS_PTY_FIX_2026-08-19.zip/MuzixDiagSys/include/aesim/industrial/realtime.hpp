#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

namespace aesim::industrial {

enum class OverrunPolicy { CountAndContinue, SkipNextRelease, StopRun };

struct RealtimePolicy {
    std::int64_t period_ns = 1'000'000;
    std::int64_t warning_ns = 700'000;
    int fifo_priority = 70;
    std::vector<unsigned> cpu_affinity;
    bool lock_memory = true;
    bool prefault_stack = true;
    bool use_sched_fifo = true;
    bool strict = false;
    OverrunPolicy overrun_policy = OverrunPolicy::StopRun;
};

struct RealtimeCapabilities {
    bool posix = false;
    bool monotonic_raw = false;
    bool memory_lock_supported = false;
    bool sched_fifo_supported = false;
    bool cpu_affinity_supported = false;
    bool absolute_sleep_supported = false;
    std::string kernel;
    std::string report() const;
};

struct RealtimeStatistics {
    std::uint64_t cycles = 0;
    std::uint64_t warning_overruns = 0;
    std::uint64_t deadline_misses = 0;
    std::uint64_t skipped_releases = 0;
    std::uint64_t clock_resets = 0;
    std::int64_t last_execution_ns = 0;
    std::int64_t maximum_execution_ns = 0;
    std::int64_t minimum_slack_ns = 0;
    long double mean_execution_ns = 0.0L;
    long double m2_execution_ns = 0.0L;
    [[nodiscard]] double standard_deviation_ns() const;
};

class RealtimeRuntime {
public:
    RealtimeRuntime();

    void configure(const RealtimePolicy& policy);
    [[nodiscard]] RealtimePolicy policy() const;
    [[nodiscard]] RealtimeCapabilities capabilities() const;
    [[nodiscard]] RealtimeStatistics statistics() const;
    [[nodiscard]] std::string status() const;

    void set_enabled(bool enabled);
    [[nodiscard]] bool enabled() const noexcept;
    [[nodiscard]] bool stop_requested() const noexcept;
    void clear_stop_request() noexcept;
    [[nodiscard]] bool consume_skip_release() noexcept;

    // Call from the actual simulation thread. Re-applies policy only when the
    // configuration generation changes, so no privileged operations occur in
    // the steady-state cycle path.
    void prepare_current_thread();
    [[nodiscard]] std::chrono::steady_clock::time_point begin_cycle();
    void end_cycle(std::chrono::steady_clock::time_point start,
                   std::chrono::steady_clock::time_point scheduled_release);
    void sleep_until(std::chrono::steady_clock::time_point release);
    [[nodiscard]] std::chrono::nanoseconds period() const;
    void reset_statistics();

private:
    mutable std::mutex mutex_;
    RealtimePolicy policy_;
    RealtimeCapabilities capabilities_;
    RealtimeStatistics statistics_;
    std::atomic<bool> enabled_{false};
    std::atomic<bool> stop_requested_{false};
    std::atomic<bool> skip_next_release_{false};
    std::atomic<std::uint64_t> generation_{1};
    static thread_local std::uint64_t applied_generation_;

    static RealtimeCapabilities detect_capabilities();
    void apply_thread_policy(const RealtimePolicy& policy);
};

[[nodiscard]] std::string overrun_policy_name(OverrunPolicy policy);
[[nodiscard]] OverrunPolicy parse_overrun_policy(const std::string& value);

} // namespace aesim::industrial

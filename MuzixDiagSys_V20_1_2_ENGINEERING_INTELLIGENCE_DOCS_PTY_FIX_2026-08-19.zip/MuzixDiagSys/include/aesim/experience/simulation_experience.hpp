#pragma once

#include "aesim/professional/document.hpp"
#include "aesim/experience/automotive_lab.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <vector>

namespace aesim::experience {

// -----------------------------------------------------------------------------
// Persistent vehicle lifecycle, component damage, and maintenance.
// -----------------------------------------------------------------------------

enum class ComponentCondition { Nominal, Incipient, Degraded, Severe, Intermittent, Failed };

struct ComponentHealth {
    std::string id;
    double wear_fraction = 0.0;
    double damage_fraction = 0.0;
    double contamination_fraction = 0.0;
    double thermal_age_hours = 0.0;
    double equivalent_cycles = 0.0;
    double remaining_useful_life_hours = 1.0e6;
    ComponentCondition condition = ComponentCondition::Nominal;
};

struct MaintenanceRecord {
    double odometer_km = 0.0;
    double engine_hours = 0.0;
    std::string action;
    std::string component;
    double quality = 1.0;
    double cost = 0.0;
    std::string notes;
};

struct PersistentVehicleState {
    std::string id;
    std::string vehicle_preset;
    std::string engine_preset;
    double odometer_km = 0.0;
    double engine_hours = 0.0;
    double idle_hours = 0.0;
    std::uint64_t cold_starts = 0;
    std::uint64_t hot_starts = 0;
    std::uint64_t launches = 0;
    std::uint64_t shifts = 0;
    double clutch_slip_energy_j = 0.0;
    double brake_energy_j = 0.0;
    double fuel_consumed_l = 0.0;
    double electrical_energy_kwh = 0.0;
    double corrosion_exposure_hours = 0.0;
    double water_exposure_hours = 0.0;
    double collision_energy_j = 0.0;
    std::map<std::string,ComponentHealth> components;
    std::vector<MaintenanceRecord> maintenance;
    std::vector<std::string> active_faults;
};

struct LifecycleOperatingPoint {
    double speed_m_s = 0.0;
    double engine_rpm = 0.0;
    double engine_load_fraction = 0.0;
    double oil_temperature_k = 373.15;
    double coolant_temperature_k = 363.15;
    double transmission_temperature_k = 353.15;
    double battery_temperature_k = 298.15;
    double clutch_slip_power_w = 0.0;
    double brake_power_w = 0.0;
    double fuel_rate_l_s = 0.0;
    double electrical_power_w = 0.0;
    double road_roughness_m = 0.002;
    double rain_rate_mm_h = 0.0;
    double salt_fraction = 0.0;
    double impact_energy_j = 0.0;
    bool engine_running = false;
    bool idling = false;
    bool launch_event = false;
    bool shift_event = false;
};

class PersistentVehicleGarage {
public:
    void set_storage_directory(std::string directory);
    bool create(std::string id, std::string vehicle_preset, std::string engine_preset);
    bool load(const std::string& id);
    bool save();
    bool remove(const std::string& id);
    void advance(const LifecycleOperatingPoint& operating_point, double dt_s);
    bool service(const std::string& action, const std::string& component,
                 double quality, double cost, const std::string& notes = {});
    void apply_damage(const std::string& component, double damage_increment,
                      const std::string& fault_code = {});
    [[nodiscard]] std::vector<std::string> list() const;
    [[nodiscard]] const PersistentVehicleState* active() const noexcept;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] doc::Value to_document() const;
private:
    std::string storage_directory_ = "garage";
    std::optional<PersistentVehicleState> active_;
    bool dirty_ = false;
    static void initialize_components(PersistentVehicleState& state);
    static void update_condition(ComponentHealth& health);
    [[nodiscard]] std::string path_for(const std::string& id) const;
};

// -----------------------------------------------------------------------------
// Interactive scenario timeline, branches, and deterministic event emission.
// -----------------------------------------------------------------------------

struct ScenarioAction {
    std::string id;
    double time_s = 0.0;
    std::string target;
    std::string operation = "set";
    double value = 0.0;
    std::string text;
    int priority = 0;
};

struct TimelineBranch {
    std::string name;
    double time_s = 0.0;
    std::size_t next_event = 0;
    std::map<std::string,double> values;
};

class ScenarioTimeline {
public:
    void clear();
    void load(const std::string& path);
    void add(ScenarioAction action);
    void pause(bool paused);
    [[nodiscard]] std::vector<ScenarioAction> advance(double dt_s);
    [[nodiscard]] std::vector<ScenarioAction> step_to_next_event();
    bool seek(double time_s);
    bool create_branch(const std::string& name);
    bool select_branch(const std::string& name);
    [[nodiscard]] std::string compare(const std::string& lhs, const std::string& rhs) const;
    [[nodiscard]] double time_s() const noexcept { return time_s_; }
    [[nodiscard]] bool paused() const noexcept { return paused_; }
    [[nodiscard]] const std::map<std::string,double>& values() const noexcept { return values_; }
    [[nodiscard]] std::string status() const;
    void export_trace(const std::string& path) const;
private:
    std::vector<ScenarioAction> actions_;
    std::vector<ScenarioAction> emitted_;
    std::map<std::string,TimelineBranch> branches_;
    std::map<std::string,double> values_;
    std::string active_branch_ = "main";
    double time_s_ = 0.0;
    std::size_t next_event_ = 0;
    bool paused_ = true;
    void apply(const ScenarioAction& action);
    void save_active_branch();
};

// -----------------------------------------------------------------------------
// Causal graph and deterministic explanation generation.
// -----------------------------------------------------------------------------

struct CausalEvent {
    std::uint64_t id = 0;
    double time_s = 0.0;
    std::string category;
    std::string summary;
    std::map<std::string,double> evidence;
    std::vector<std::uint64_t> causes;
    std::string recommendation;
};

class CausalExplanationEngine {
public:
    std::uint64_t record(CausalEvent event);
    void clear();
    [[nodiscard]] std::optional<CausalEvent> latest(const std::string& category = {}) const;
    [[nodiscard]] std::string explain(std::uint64_t event_id) const;
    [[nodiscard]] std::string explain_latest(const std::string& category = {}) const;
    [[nodiscard]] std::string status() const;
    void export_json(const std::string& path) const;
private:
    std::vector<CausalEvent> events_;
    std::uint64_t next_id_ = 1;
    void render(std::uint64_t event_id, std::size_t depth,
                std::vector<std::uint64_t>& stack, std::string& output) const;
};

// -----------------------------------------------------------------------------
// Procedural audio driven by physical state; output is standard PCM WAV.
// -----------------------------------------------------------------------------

struct AudioFrameInput {
    double engine_rpm = 0.0;
    double engine_load_fraction = 0.0;
    std::size_t cylinders = 4;
    double gear_mesh_hz = 0.0;
    double vehicle_speed_m_s = 0.0;
    double tire_roughness_m = 0.002;
    double wind_speed_m_s = 0.0;
    double brake_power_w = 0.0;
    double clutch_slip_power_w = 0.0;
    double intake_pressure_ratio = 1.0;
    double exhaust_temperature_k = 700.0;
    double listener_pan = 0.0;
};

class ProceduralAudioSynthesizer {
public:
    void configure(unsigned sample_rate_hz, unsigned channels, std::uint64_t seed = 1);
    void reset();
    void render(const AudioFrameInput& input, double duration_s);
    void write_wav(const std::string& path) const;
    [[nodiscard]] std::size_t frames() const noexcept;
    [[nodiscard]] double duration_s() const noexcept;
    [[nodiscard]] double peak() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    unsigned sample_rate_hz_ = 48000;
    unsigned channels_ = 2;
    std::uint64_t seed_ = 1;
    std::mt19937_64 random_{1};
    std::vector<std::int16_t> pcm_;
    double engine_phase_ = 0.0;
    double gear_phase_ = 0.0;
    double wind_state_ = 0.0;
    double peak_ = 0.0;
};

// -----------------------------------------------------------------------------
// OpenCRG/procedural road surface and distributed contact-patch tire model.
// -----------------------------------------------------------------------------

enum class RoadMaterial { Asphalt, Concrete, Cobblestone, Gravel, Dirt, Snow, Ice, Water };

struct RoadSurfaceSample {
    double x_m = 0.0;
    double y_m = 0.0;
    double height_m = 0.0;
    double normal_x = 0.0;
    double normal_y = 0.0;
    double normal_z = 1.0;
    double friction = 1.0;
    double roughness_m = 0.002;
    double water_depth_m = 0.0;
    double snow_depth_m = 0.0;
    double temperature_k = 293.15;
    RoadMaterial material = RoadMaterial::Asphalt;
};

struct ProceduralRoadConfiguration {
    std::string profile = "degraded_asphalt";
    std::uint64_t seed = 1;
    double length_m = 5000.0;
    double width_m = 8.0;
    double roughness_rms_m = 0.003;
    double potholes_per_km = 4.0;
    double expansion_joint_spacing_m = 0.0;
    double rut_depth_m = 0.0;
    double crown_rad = 0.0;
    double grade_rad = 0.0;
    double base_friction = 0.95;
    RoadMaterial material = RoadMaterial::Asphalt;
};

class RoadSurfaceField {
public:
    void clear();
    void load_opencrg(const std::string& path);
    void generate(ProceduralRoadConfiguration configuration);
    void set_weather(double water_depth_m, double snow_depth_m, double temperature_k);
    [[nodiscard]] RoadSurfaceSample sample(double x_m, double y_m) const;
    [[nodiscard]] std::string status() const;
    void export_csv(const std::string& path, double x_step_m, double y_step_m) const;
private:
    ProceduralRoadConfiguration procedural_{};
    bool generated_ = true;
    std::string source_ = "procedural";
    std::vector<double> crg_height_;
    std::size_t crg_rows_ = 0;
    std::size_t crg_columns_ = 0;
    double crg_u_start_ = 0.0;
    double crg_u_step_ = 1.0;
    double crg_v_start_ = 0.0;
    double crg_v_step_ = 1.0;
    double water_depth_m_ = 0.0;
    double snow_depth_m_ = 0.0;
    double temperature_k_ = 293.15;
    [[nodiscard]] double procedural_height(double x_m, double y_m) const;
    [[nodiscard]] double crg_height(double x_m, double y_m) const;
};

struct ContactPatchInput {
    double center_x_m = 0.0;
    double center_y_m = 0.0;
    double heading_rad = 0.0;
    double patch_length_m = 0.18;
    double patch_width_m = 0.20;
    std::size_t longitudinal_cells = 12;
    std::size_t lateral_cells = 6;
    double normal_load_n = 4000.0;
    double longitudinal_slip = 0.0;
    double lateral_slip = 0.0;
    double camber_rad = 0.0;
    double tire_temperature_k = 320.0;
    double tread_depth_m = 0.007;
};

struct ContactCellState {
    double x_m = 0.0;
    double y_m = 0.0;
    double normal_force_n = 0.0;
    double friction = 0.0;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double slip_power_w = 0.0;
    bool hydroplaning = false;
};

struct DistributedContactState {
    std::vector<ContactCellState> cells;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double enveloped_height_m = 0.0;
    double effective_friction = 0.0;
    double contact_area_m2 = 0.0;
    double slip_power_w = 0.0;
    double hydroplaning_fraction = 0.0;
};

class DistributedTireContactModel {
public:
    const DistributedContactState& evaluate(const RoadSurfaceField& road,
                                             const ContactPatchInput& input);
    [[nodiscard]] const DistributedContactState& state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    DistributedContactState state_;
};

struct SuspensionComplianceInput {
    std::array<double,4> wheel_vertical_force_n{};
    std::array<double,4> wheel_longitudinal_force_n{};
    std::array<double,4> wheel_lateral_force_n{};
    std::array<double,4> road_height_m{};
    double steering_angle_rad = 0.0;
    double speed_m_s = 0.0;
};

struct SuspensionCornerState {
    double travel_m = 0.0;
    double velocity_m_s = 0.0;
    double camber_rad = 0.0;
    double toe_rad = 0.0;
    double caster_rad = 0.0;
    double compliance_steer_rad = 0.0;
    double bushing_energy_j = 0.0;
};

class SuspensionComplianceModel {
public:
    void reset();
    const std::array<SuspensionCornerState,4>& step(const SuspensionComplianceInput& input,
                                                    double dt_s);
    [[nodiscard]] const std::array<SuspensionCornerState,4>& state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    std::array<SuspensionCornerState,4> state_{};
};

// -----------------------------------------------------------------------------
// Dynamic weather, road state, and heterogeneous traffic ecology.
// -----------------------------------------------------------------------------

struct WeatherCell {
    std::string id;
    double center_x_m = 0.0;
    double center_y_m = 0.0;
    double radius_m = 500.0;
    double velocity_x_m_s = 0.0;
    double velocity_y_m_s = 0.0;
    double rain_rate_mm_h = 0.0;
    double snow_rate_mm_h = 0.0;
    double fog_visibility_m = 10000.0;
    double wind_x_m_s = 0.0;
    double wind_y_m_s = 0.0;
    double temperature_k = 293.15;
};

struct WeatherRoadState {
    double time_s = 0.0;
    double rain_rate_mm_h = 0.0;
    double snow_rate_mm_h = 0.0;
    double visibility_m = 10000.0;
    double wind_x_m_s = 0.0;
    double wind_y_m_s = 0.0;
    double air_temperature_k = 293.15;
    double road_temperature_k = 293.15;
    double water_depth_m = 0.0;
    double snow_depth_m = 0.0;
    double ice_fraction = 0.0;
    double friction_scale = 1.0;
};

class DynamicWeatherRoadModel {
public:
    void reset(double temperature_k = 293.15);
    void add_cell(WeatherCell cell);
    bool remove_cell(const std::string& id);
    const WeatherRoadState& step(double x_m, double y_m, double traffic_spray,
                                 double solar_w_m2, double dt_s);
    [[nodiscard]] const WeatherRoadState& state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    std::vector<WeatherCell> cells_;
    WeatherRoadState state_{};
};

enum class RoadUserKind { PassengerCar, HeavyTruck, Bus, Motorcycle, Bicycle, Pedestrian, EmergencyVehicle, DisabledVehicle };

struct RoadUser {
    std::string id;
    RoadUserKind kind = RoadUserKind::PassengerCar;
    double x_m = 0.0;
    double y_m = 0.0;
    double speed_m_s = 0.0;
    double desired_speed_m_s = 20.0;
    double acceleration_m_s2 = 0.0;
    double desired_headway_s = 1.5;
    double aggression = 0.5;
    double courtesy = 0.5;
    double reaction_time_s = 0.8;
    double distraction = 0.0;
    int lane = 0;
    int target_lane = 0;
    bool connected = false;
    bool active = true;
};

struct TrafficEcologyState {
    double time_s = 0.0;
    std::vector<RoadUser> users;
    std::size_t lane_changes = 0;
    std::size_t emergency_brakes = 0;
    std::size_t rule_violations = 0;
    double nearest_lead_distance_m = 1.0e9;
    double nearest_lead_speed_m_s = 0.0;
};

class HeterogeneousTrafficEcology {
public:
    void reset(std::uint64_t seed = 1);
    void add(RoadUser user);
    bool remove(const std::string& id);
    void populate(std::size_t count, double road_length_m, std::uint64_t seed);
    const TrafficEcologyState& step(double ego_x_m, double ego_y_m, double ego_speed_m_s,
                                    double friction, double visibility_m, double dt_s);
    [[nodiscard]] const TrafficEcologyState& state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    TrafficEcologyState state_{};
    std::mt19937_64 random_{1};
};

// -----------------------------------------------------------------------------
// Workshop diagnostics, virtual tests, fault solving, and scoring.
// -----------------------------------------------------------------------------

struct DiagnosticEvidence {
    std::string name;
    double value = 0.0;
    std::string unit;
    double sigma = 0.0;
    std::string interpretation;
};

struct DiagnosticCase {
    std::string id;
    std::string hidden_fault;
    std::string description;
    std::map<std::string,DiagnosticEvidence> evidence;
    std::vector<std::string> allowed_tests;
    std::vector<std::string> performed_tests;
    double test_cost = 0.0;
    double elapsed_minutes = 0.0;
    bool solved = false;
    double score = 0.0;
};

class WorkshopDiagnostics {
public:
    void create_case(const std::string& id, const std::string& fault, std::uint64_t seed = 1);
    void load_case(const std::string& path);
    [[nodiscard]] std::string run_test(const std::string& test_name);
    [[nodiscard]] std::string submit_diagnosis(const std::string& diagnosis);
    [[nodiscard]] std::string status(bool reveal = false) const;
    void export_report(const std::string& path) const;
    [[nodiscard]] const std::optional<DiagnosticCase>& active_case() const noexcept { return case_; }
private:
    std::optional<DiagnosticCase> case_;
    std::mt19937_64 random_{1};
    static DiagnosticCase generate(const std::string& id, const std::string& fault,
                                   std::mt19937_64& random);
};

// -----------------------------------------------------------------------------
// Software-only visualization, ghost comparison, and uncertainty rendering.
// -----------------------------------------------------------------------------

struct VisualizationObject {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    double heading_rad = 0.0;
    double length_m = 4.5;
    double width_m = 1.8;
    std::string label;
};

struct GhostSample {
    double time_s = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double speed_m_s = 0.0;
    double engine_rpm = 0.0;
    int gear = 0;
};

class SimulationVisualizer {
public:
    void set_host(VisualizationObject host);
    void set_objects(std::vector<VisualizationObject> objects);
    void load_ghost_csv(const std::string& path);
    void add_simulated_sample(GhostSample sample);
    [[nodiscard]] std::string render_ascii(std::size_t width, std::size_t height,
                                           double meters_per_cell) const;
    void export_svg_2d(const std::string& path, double width_m, double height_m) const;
    void export_svg_3d(const std::string& path, double width_m, double height_m) const;
    void export_ghost_comparison(const std::string& path) const;
    [[nodiscard]] std::string ghost_status() const;
private:
    VisualizationObject host_;
    std::vector<VisualizationObject> objects_;
    std::vector<GhostSample> ghost_;
    std::vector<GhostSample> simulated_;
};

// -----------------------------------------------------------------------------
// Adaptive fidelity, uncertainty visualization, reports, and driver skill.
// -----------------------------------------------------------------------------

enum class ExperienceFidelity { Fast, Interactive, Engineering, Validation, FullResearch };

struct FidelityDecision {
    double time_s = 0.0;
    ExperienceFidelity previous = ExperienceFidelity::Engineering;
    ExperienceFidelity selected = ExperienceFidelity::Engineering;
    double predicted_error = 0.0;
    double computational_load = 0.0;
    std::string reason;
};

class AdaptiveExperienceFidelity {
public:
    void reset(ExperienceFidelity level = ExperienceFidelity::Engineering);
    void set_automatic(bool enabled, double compute_budget);
    const FidelityDecision& update(double time_s, double event_severity,
                                   double uncertainty, double real_time_load);
    [[nodiscard]] ExperienceFidelity level() const noexcept { return level_; }
    [[nodiscard]] double update_period_scale() const noexcept;
    [[nodiscard]] std::size_t tire_cells() const noexcept;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] const std::vector<FidelityDecision>& history() const noexcept { return history_; }
private:
    ExperienceFidelity level_ = ExperienceFidelity::Engineering;
    bool automatic_ = false;
    double compute_budget_ = 0.75;
    FidelityDecision decision_{};
    std::vector<FidelityDecision> history_;
};

struct UncertainMetric {
    std::string name;
    double nominal = 0.0;
    double standard_deviation = 0.0;
    double model_form_fraction = 0.0;
    std::string unit;
};

class AutomaticExperienceReport {
public:
    void set_title(std::string title);
    void set_metadata(std::map<std::string,std::string> metadata);
    void add_metric(UncertainMetric metric);
    void add_section(std::string title, std::string body);
    void add_warning(std::string warning);
    [[nodiscard]] std::string uncertainty_bar(const UncertainMetric& metric,
                                              std::size_t width = 48) const;
    void write_markdown(const std::string& path) const;
    void write_json(const std::string& path) const;
    [[nodiscard]] std::string status() const;
private:
    std::string title_ = "MuzixDiagSys Simulation Experience Report";
    std::map<std::string,std::string> metadata_;
    std::vector<UncertainMetric> metrics_;
    std::vector<std::pair<std::string,std::string>> sections_;
    std::vector<std::string> warnings_;
};

struct DriverSkillConfiguration {
    double clutch_skill = 0.7;
    double shift_skill = 0.7;
    double rev_match_skill = 0.5;
    double throttle_smoothness = 0.7;
    double brake_smoothness = 0.7;
    double steering_skill = 0.7;
    double reaction_time_s = 0.75;
    double fatigue_rate_per_hour = 0.03;
    double distraction_probability_per_minute = 0.01;
    double aggression = 0.5;
    double eco_tendency = 0.5;
    std::uint64_t seed = 1;
};

struct DriverSkillInput {
    double target_speed_m_s = 0.0;
    double vehicle_speed_m_s = 0.0;
    double engine_rpm = 0.0;
    double idle_rpm = 750.0;
    double redline_rpm = 6500.0;
    int gear = 1;
    int maximum_gear = 6;
    double road_curvature_1_m = 0.0;
    double lane_error_m = 0.0;
    double heading_error_rad = 0.0;
    double lead_distance_m = 1.0e9;
    double lead_speed_m_s = 0.0;
    double road_grade = 0.0;
    bool manual_transmission = true;
};

struct DriverSkillState {
    double time_s = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    double clutch_pedal = 0.0;
    double steering = 0.0;
    int requested_gear = 1;
    double fatigue = 0.0;
    double attention = 1.0;
    std::uint64_t stalls = 0;
    std::uint64_t missed_shifts = 0;
    std::uint64_t harsh_events = 0;
    bool shifting = false;
};

class HumanDriverSkillModel {
public:
    HumanDriverSkillModel();
    explicit HumanDriverSkillModel(DriverSkillConfiguration configuration);
    void configure(DriverSkillConfiguration configuration);
    void reset();
    const DriverSkillState& step(const DriverSkillInput& input, double dt_s);
    [[nodiscard]] const DriverSkillState& state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    DriverSkillConfiguration configuration_{};
    DriverSkillState state_{};
    std::mt19937_64 random_{1};
    double shift_timer_s_ = 0.0;
    int shift_target_ = 1;
};

// Unified command-facing runtime used by the existing vehicle platform.
class SimulationExperiencePlatform {
public:
    SimulationExperiencePlatform();
    void update(double simulation_time_s, double dt_s, double engine_rpm,
                double engine_load_fraction, double speed_m_s, double x_m,
                double y_m, int gear, double brake_power_w,
                double clutch_slip_power_w);
    [[nodiscard]] std::string command(const std::vector<std::string>& args);
    [[nodiscard]] std::string status() const;
    [[nodiscard]] std::vector<ScenarioAction> take_pending_actions();

    [[nodiscard]] PersistentVehicleGarage& garage() noexcept { return garage_; }
    [[nodiscard]] ScenarioTimeline& timeline() noexcept { return timeline_; }
    [[nodiscard]] CausalExplanationEngine& explanations() noexcept { return explanations_; }
    [[nodiscard]] RoadSurfaceField& road() noexcept { return road_; }
    [[nodiscard]] const RoadSurfaceField& road() const noexcept { return road_; }
    [[nodiscard]] DynamicWeatherRoadModel& weather() noexcept { return weather_; }
    [[nodiscard]] const WeatherRoadState& weather_state() const noexcept { return weather_.state(); }
    [[nodiscard]] HeterogeneousTrafficEcology& traffic() noexcept { return traffic_; }
    [[nodiscard]] const TrafficEcologyState& traffic_state() const noexcept { return traffic_.state(); }
    [[nodiscard]] HumanDriverSkillModel& driver() noexcept { return driver_; }
    [[nodiscard]] const DriverSkillState& driver_state() const noexcept { return driver_.state(); }
    [[nodiscard]] const DistributedContactState& tire_contact_state() const noexcept { return tire_contact_.state(); }
    [[nodiscard]] const std::array<SuspensionCornerState,4>& suspension_state() const noexcept { return suspension_.state(); }
    [[nodiscard]] ExperienceFidelity fidelity_level() const noexcept { return fidelity_.level(); }
    [[nodiscard]] bool driver_control_enabled() const noexcept { return driver_control_enabled_; }
    [[nodiscard]] AutomotiveLabPlatform& automotive_lab() noexcept { return automotive_lab_; }
private:
    PersistentVehicleGarage garage_;
    ScenarioTimeline timeline_;
    CausalExplanationEngine explanations_;
    ProceduralAudioSynthesizer audio_;
    RoadSurfaceField road_;
    DistributedTireContactModel tire_contact_;
    SuspensionComplianceModel suspension_;
    DynamicWeatherRoadModel weather_;
    HeterogeneousTrafficEcology traffic_;
    WorkshopDiagnostics workshop_;
    SimulationVisualizer visualization_;
    AdaptiveExperienceFidelity fidelity_;
    AutomaticExperienceReport report_;
    HumanDriverSkillModel driver_;
    AutomotiveLabPlatform automotive_lab_;
    double time_s_ = 0.0;
    double last_speed_m_s_ = 0.0;
    double last_engine_rpm_ = 0.0;
    int last_gear_ = 0;
    bool driver_control_enabled_ = false;
    double driver_target_speed_m_s_ = 0.0;
    bool driver_manual_transmission_ = true;
    int driver_maximum_gear_ = 6;
    bool live_audio_capture_enabled_ = false;
    double live_audio_capture_limit_s_ = 300.0;
    std::vector<ScenarioAction> pending_actions_;
};

[[nodiscard]] std::string to_string(ComponentCondition value);
[[nodiscard]] std::string to_string(RoadMaterial value);
[[nodiscard]] std::string to_string(RoadUserKind value);
[[nodiscard]] std::string to_string(ExperienceFidelity value);
[[nodiscard]] ExperienceFidelity parse_fidelity(const std::string& text);

} // namespace aesim::experience

#pragma once

#include "aesim/professional/document.hpp"
#include "aesim/industrial/can_obd.hpp"

#include <cstdint>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <vector>

namespace aesim::experience {

struct LabComponent {
    std::string id;
    std::string category;
    std::string interface_family;
    double mass_kg = 0.0;
    double cost = 0.0;
    double torque_capacity_nm = 0.0;
    double power_capacity_kw = 0.0;
    double voltage_v = 0.0;
    double thermal_capacity_kw = 0.0;
    std::map<std::string,double> parameters;
    std::vector<std::string> required_categories;
    std::vector<std::string> conflicts;
};

struct CompatibilityFinding {
    enum class Severity { Information, Warning, Error } severity = Severity::Information;
    std::string code;
    std::string component;
    std::string message;
};

struct VehicleBuild {
    std::string id;
    std::map<std::string,std::string> installed;
    std::map<std::string,double> calibrations;
    double total_mass_kg = 0.0;
    double total_cost = 0.0;
    double predicted_power_kw = 0.0;
    double predicted_wheel_torque_nm = 0.0;
    std::vector<CompatibilityFinding> findings;
};

class ModularVehicleBuilder {
public:
    void load_catalog(const std::string& path);
    void create(std::string build_id);
    void install(const std::string& component_id);
    void remove_category(const std::string& category);
    [[nodiscard]] const VehicleBuild& validate();
    [[nodiscard]] std::string status() const;
    void export_yaml(const std::string& path) const;
    [[nodiscard]] const VehicleBuild* active() const noexcept;
    [[nodiscard]] VehicleBuild* active() noexcept;
    [[nodiscard]] const std::map<std::string,LabComponent>& catalog() const noexcept { return catalog_; }
private:
    std::map<std::string,LabComponent> catalog_;
    std::optional<VehicleBuild> active_;
};

struct ModificationResult {
    std::string name;
    double previous_value = 0.0;
    double requested_value = 0.0;
    double applied_value = 0.0;
    double reliability_multiplier = 1.0;
    double emissions_multiplier = 1.0;
    std::vector<std::string> warnings;
};

class VehicleTuningWorkshop {
public:
    void bind(VehicleBuild* build);
    ModificationResult set(const std::string& parameter, double value);
    [[nodiscard]] std::string status() const;
    void export_calibration(const std::string& path) const;
private:
    VehicleBuild* build_ = nullptr;
    std::vector<ModificationResult> history_;
};

struct LabSample {
    double x = 0.0;
    double speed_rpm = 0.0;
    double torque_nm = 0.0;
    double power_kw = 0.0;
    double efficiency = 0.0;
    double temperature_c = 0.0;
    double fuel_or_energy_rate = 0.0;
};

struct LaboratoryResult {
    std::string test_name;
    std::vector<LabSample> samples;
    std::map<std::string,double> metrics;
    std::vector<std::string> limit_violations;
};

class VirtualTestLaboratory {
public:
    LaboratoryResult run_chassis_dyno(const VehicleBuild& build, double start_kph, double end_kph, double step_kph);
    LaboratoryResult run_engine_bench(const VehicleBuild& build, double start_rpm, double end_rpm, double step_rpm);
    LaboratoryResult run_transmission_bench(const VehicleBuild& build, double input_torque_nm, int shifts);
    LaboratoryResult run_battery_bench(const VehicleBuild& build, double power_kw, double duration_s);
    [[nodiscard]] const LaboratoryResult* last() const noexcept;
    [[nodiscard]] std::string status() const;
    void export_csv(const std::string& path) const;
private:
    std::optional<LaboratoryResult> last_;
};

struct EngineeringRecommendation {
    int priority = 0;
    std::string category;
    std::string action;
    std::string rationale;
    std::vector<std::string> required_channels;
};

class EngineeringAssistant {
public:
    [[nodiscard]] std::vector<EngineeringRecommendation> investigate(
        const std::string& problem, const VehicleBuild* build,
        const LaboratoryResult* result) const;
    [[nodiscard]] std::string render(const std::vector<EngineeringRecommendation>& recommendations) const;
};

struct TelemetryChannel {
    std::string name;
    std::string unit;
    std::vector<double> values;
};

class TelemetryReplayStudio {
public:
    void import_csv(const std::string& path);
    void seek(double time_s);
    void step(double dt_s);
    [[nodiscard]] std::map<std::string,double> frame() const;
    [[nodiscard]] std::string status() const;
    void export_engineering_svg(const std::string& path, const std::string& channel) const;
    void export_cinematic_script(const std::string& path) const;
private:
    std::vector<double> time_s_;
    std::map<std::string,TelemetryChannel> channels_;
    double cursor_s_ = 0.0;
    std::string source_;
};

struct CrashEvidence {
    double vehicle_mass_kg = 1500.0;
    double other_mass_kg = 1500.0;
    double skid_length_m = 0.0;
    double road_friction = 0.8;
    double impact_angle_deg = 0.0;
    double crush_depth_m = 0.0;
    double crush_stiffness_kn_m = 500.0;
    double final_speed_m_s = 0.0;
    double sigma_fraction = 0.05;
};

struct CrashReconstruction {
    double pre_brake_speed_m_s = 0.0;
    double impact_speed_m_s = 0.0;
    double delta_v_m_s = 0.0;
    double impact_energy_j = 0.0;
    double lower95_delta_v_m_s = 0.0;
    double upper95_delta_v_m_s = 0.0;
    std::vector<std::string> assumptions;
};

class CrashForensics {
public:
    CrashReconstruction solve(const CrashEvidence& evidence, std::uint64_t seed = 1, std::size_t samples = 4000);
    [[nodiscard]] std::string status() const;
    void export_report(const std::string& path) const;
private:
    std::optional<CrashReconstruction> last_;
};

struct GeneratedMission {
    std::string id;
    std::string title;
    std::string objective;
    std::vector<std::string> route_nodes;
    std::map<std::string,double> constraints;
    std::uint64_t seed = 0;
};

class OpenWorldMissionGenerator {
public:
    void generate_world(const std::string& type, std::size_t width, std::size_t height, std::uint64_t seed);
    GeneratedMission generate_mission(const std::string& theme, std::uint64_t seed);
    [[nodiscard]] std::string status() const;
    void export_world(const std::string& path) const;
    void export_mission(const std::string& path) const;
private:
    std::string type_;
    std::size_t width_ = 0;
    std::size_t height_ = 0;
    std::uint64_t seed_ = 0;
    std::vector<std::string> nodes_;
    std::vector<std::pair<std::size_t,std::size_t>> edges_;
    std::optional<GeneratedMission> mission_;
};

struct ManufacturedVariant {
    std::string id;
    std::map<std::string,double> parameter_multipliers;
    std::vector<std::string> defects;
    double predicted_quality_score = 1.0;
};

class ManufacturingVariationEngine {
public:
    ManufacturedVariant build(const VehicleBuild& base, const std::string& id,
                              std::uint64_t seed, double sigma_fraction,
                              double defect_probability);
    [[nodiscard]] std::string status() const;
    void export_json(const std::string& path) const;
private:
    std::optional<ManufacturedVariant> last_;
};

struct TeardownFinding {
    std::string component;
    std::string observation;
    std::string probable_cause;
    double severity = 0.0;
    double confidence = 0.0;
};

class ComponentTeardownAnalyzer {
public:
    void inspect(const std::map<std::string,double>& wear,
                 const std::map<std::string,double>& damage,
                 const std::vector<std::string>& faults);
    [[nodiscard]] std::string status() const;
    void export_report(const std::string& path) const;
private:
    std::vector<TeardownFinding> findings_;
};

struct PluginManifestRecord {
    std::string id;
    std::string name;
    std::string version;
    std::uint32_t abi_major = 2;
    std::uint32_t abi_minor = 0;
    std::string library;
    std::vector<std::string> capabilities;
    std::string manifest_path;
};

class ModdingSdkManager {
public:
    PluginManifestRecord validate_manifest(const std::string& path) const;
    void register_manifest(const std::string& path);
    void scaffold(const std::string& directory, const std::string& plugin_id,
                  const std::string& plugin_name) const;
    [[nodiscard]] std::string status() const;
    void export_registry(const std::string& path) const;
private:
    std::map<std::string,PluginManifestRecord> plugins_;
};

class AutomotiveLabPlatform {
public:
    [[nodiscard]] std::string command(const std::vector<std::string>& args);
    [[nodiscard]] std::string status() const;
    void update_live_bus(double simulation_time_s, double dt_s, double engine_rpm,
                         double engine_load_fraction, double vehicle_speed_m_s,
                         double ambient_temperature_c = 20.0);
    ModularVehicleBuilder& builder() noexcept { return builder_; }
    aesim::industrial::CanObdGateway& can_obd_gateway() noexcept { return can_obd_; }
    aesim::industrial::SocketCanObdResponder& obd_responder() noexcept { return obd_responder_; }
    aesim::industrial::CanDataSynthesizer& can_synthesizer() noexcept { return can_synthesizer_; }
private:
    ModularVehicleBuilder builder_;
    VehicleTuningWorkshop tuning_;
    VirtualTestLaboratory laboratory_;
    EngineeringAssistant assistant_;
    TelemetryReplayStudio telemetry_;
    CrashForensics forensics_;
    OpenWorldMissionGenerator world_;
    ManufacturingVariationEngine manufacturing_;
    ComponentTeardownAnalyzer teardown_;
    ModdingSdkManager sdk_;
    aesim::industrial::CanObdGateway can_obd_;
    aesim::industrial::SocketCanObdResponder obd_responder_;
    aesim::industrial::CanDataSynthesizer can_synthesizer_;
};

} // namespace aesim::experience

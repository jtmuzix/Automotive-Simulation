#pragma once

#include "aesim/core/numerical_rigor.hpp"

#include <complex>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::core::math_assurance {

enum class ErrorCategory {
    FloatingPoint,
    LinearSolver,
    NonlinearSolver,
    TimeDiscretization,
    SpatialDiscretization,
    Interpolation,
    Quadrature,
    Sampling,
    Surrogate,
    Parameter,
    Measurement,
    ModelForm,
    Other
};

enum class ErrorCombinationMethod { RootSumSquare, WorstCase, CorrelationGroups };

struct ErrorContribution {
    std::string name;
    ErrorCategory category = ErrorCategory::Other;
    double absolute_bound = 0.0;
    double standard_uncertainty = 0.0;
    std::string correlation_group;
    double confidence_level = 0.682689492137;
    std::string rationale;
};

struct ErrorBudgetSummary {
    std::vector<ErrorContribution> contributions;
    ErrorCombinationMethod combination = ErrorCombinationMethod::CorrelationGroups;
    double numerical_uncertainty = 0.0;
    double parameter_uncertainty = 0.0;
    double measurement_uncertainty = 0.0;
    double model_form_uncertainty = 0.0;
    double total_predictive_uncertainty = 0.0;
    std::vector<ErrorContribution> dominant_sources;
    bool valid = false;
    std::string diagnostic;
};

class ErrorBudgetBuilder {
public:
    void add(ErrorContribution contribution);
    void add_dense_solve(const numerics::DenseSolveResult& result, double result_scale,
                         std::string name = "dense linear solve");
    void add_quadrature(const numerics::QuadratureResult& result,
                        std::string name = "adaptive quadrature");
    void add_ode(const numerics::OdeResult& result, double state_scale,
                 std::string name = "time integration");
    [[nodiscard]] ErrorBudgetSummary summarize(
        ErrorCombinationMethod method = ErrorCombinationMethod::CorrelationGroups,
        std::size_t dominant_count = 5) const;
    [[nodiscard]] const std::vector<ErrorContribution>& contributions() const noexcept {
        return contributions_;
    }
private:
    std::vector<ErrorContribution> contributions_;
};

enum class PrecisionTier { Binary64, Extended, Decimal50, Decimal100 };

struct PrecisionEvaluation {
    PrecisionTier tier = PrecisionTier::Binary64;
    std::string value_decimal;
    double value_binary64 = std::numeric_limits<double>::quiet_NaN();
    double absolute_change = std::numeric_limits<double>::infinity();
    double relative_change = std::numeric_limits<double>::infinity();
    double verified_digits = 0.0;
    bool finite = false;
};

struct AdaptivePrecisionPolicy {
    PrecisionTier minimum_tier = PrecisionTier::Binary64;
    PrecisionTier maximum_tier = PrecisionTier::Decimal100;
    double relative_tolerance = 1.0e-13;
    double absolute_tolerance = 1.0e-15;
    double condition_estimate = 1.0;
    double minimum_verified_digits = 11.0;
    bool escalate_on_condition = true;
};

struct AdaptivePrecisionProblem {
    std::string name;
    std::function<double()> binary64;
    std::function<long double()> extended;
    std::function<std::string()> decimal50;
    std::function<std::string()> decimal100;
};

struct AdaptivePrecisionReport {
    std::string name;
    std::vector<PrecisionEvaluation> evaluations;
    PrecisionTier selected_tier = PrecisionTier::Binary64;
    std::string selected_value_decimal;
    double selected_value = std::numeric_limits<double>::quiet_NaN();
    double estimated_absolute_error = std::numeric_limits<double>::infinity();
    double estimated_relative_error = std::numeric_limits<double>::infinity();
    double verified_digits = 0.0;
    bool converged = false;
    std::string diagnostic;
};

[[nodiscard]] AdaptivePrecisionReport evaluate_adaptive_precision(
    const AdaptivePrecisionProblem& problem,
    const AdaptivePrecisionPolicy& policy = {});

[[nodiscard]] AdaptivePrecisionProblem make_polynomial_precision_problem(
    std::vector<double> coefficients_low_to_high, double x,
    std::string name = "polynomial");

struct ExactReductionResult {
    std::size_t term_count = 0;
    std::string exact_integer;
    int binary_exponent = 0;
    std::string exact_rational_numerator;
    std::string exact_rational_denominator;
    std::string decimal_100_digits;
    double correctly_rounded_binary64 = 0.0;
    bool exact = false;
    bool overflowed_binary64 = false;
    std::string diagnostic;
};

[[nodiscard]] ExactReductionResult exact_sum(const std::vector<double>& values);
[[nodiscard]] ExactReductionResult exact_dot(const std::vector<double>& left,
                                             const std::vector<double>& right);
[[nodiscard]] ExactReductionResult exact_polynomial_reference(
    const std::vector<double>& coefficients_low_to_high, double x);

struct ReferenceComparison {
    double candidate = 0.0;
    double reference = 0.0;
    double absolute_error = 0.0;
    double relative_error = 0.0;
    std::int64_t ulp_distance = 0;
    double verified_digits = 0.0;
    bool within_tolerance = false;
};

[[nodiscard]] ReferenceComparison compare_with_reference(
    double candidate, const ExactReductionResult& reference,
    double absolute_tolerance = 0.0, double relative_tolerance = 0.0);

struct RefinementSample {
    double characteristic_step = 0.0;
    double value = 0.0;
    double exact_error = std::numeric_limits<double>::quiet_NaN();
    std::size_t degrees_of_freedom = 0;
};

struct ConvergenceReport {
    std::vector<RefinementSample> samples;
    double observed_order = std::numeric_limits<double>::quiet_NaN();
    double extrapolated_value = std::numeric_limits<double>::quiet_NaN();
    double fine_grid_gci = std::numeric_limits<double>::infinity();
    double coarse_grid_gci = std::numeric_limits<double>::infinity();
    double asymptotic_ratio = std::numeric_limits<double>::infinity();
    bool monotonic = false;
    bool oscillatory = false;
    bool asymptotic_range = false;
    bool converged = false;
    std::string diagnostic;
};

[[nodiscard]] ConvergenceReport analyze_convergence(
    std::vector<RefinementSample> samples, double safety_factor = 1.25);

struct ManufacturedOdeProblem {
    std::string name;
    std::function<double(double)> exact_solution;
    std::function<double(double)> exact_derivative;
    double initial_time = 0.0;
    double final_time = 1.0;
    std::vector<double> maximum_steps{0.2, 0.1, 0.05, 0.025};
};

struct ManufacturedPoisson1DProblem {
    std::string name;
    std::function<double(double)> exact_solution;
    std::function<double(double)> forcing_negative_second_derivative;
    double lower = 0.0;
    double upper = 1.0;
    std::vector<std::size_t> interior_points{15, 31, 63, 127};
};

struct ManufacturedSolutionReport {
    std::string name;
    std::string equation;
    std::vector<double> l1_errors;
    std::vector<double> l2_errors;
    std::vector<double> linfinity_errors;
    ConvergenceReport convergence;
    double expected_order = 0.0;
    bool passed = false;
    std::string diagnostic;
};

[[nodiscard]] ManufacturedSolutionReport run_manufactured_ode_test(
    const ManufacturedOdeProblem& problem,
    double minimum_acceptable_order = 3.5);
[[nodiscard]] ManufacturedSolutionReport run_manufactured_poisson_1d_test(
    const ManufacturedPoisson1DProblem& problem,
    double minimum_acceptable_order = 1.8);

struct DerivativeProblem {
    std::string name;
    double point = 0.0;
    double scale = 1.0;
    std::function<double(double)> real_function;
    std::function<std::complex<double>(std::complex<double>)> complex_function;
    std::function<double(double)> analytic_derivative;
};

struct DerivativeCertificate {
    std::string name;
    double point = 0.0;
    double analytic = std::numeric_limits<double>::quiet_NaN();
    double complex_step = std::numeric_limits<double>::quiet_NaN();
    double five_point = std::numeric_limits<double>::quiet_NaN();
    double richardson = std::numeric_limits<double>::quiet_NaN();
    double maximum_absolute_disagreement = std::numeric_limits<double>::infinity();
    double maximum_relative_disagreement = std::numeric_limits<double>::infinity();
    double taylor_remainder_ratio = std::numeric_limits<double>::infinity();
    bool passed = false;
    std::string diagnostic;
};

[[nodiscard]] DerivativeCertificate certify_derivative(
    const DerivativeProblem& problem,
    double relative_tolerance = 1.0e-7,
    double absolute_tolerance = 1.0e-10);

struct OptimizationCertificationProblem {
    std::string name;
    std::vector<double> point;
    std::vector<double> objective_gradient;
    std::vector<double> equality_values;
    numerics::DenseMatrix equality_jacobian;
    std::vector<double> equality_multipliers;
    std::vector<double> inequality_values;
    numerics::DenseMatrix inequality_jacobian;
    std::vector<double> inequality_multipliers;
    std::vector<double> lower_bounds;
    std::vector<double> upper_bounds;
    numerics::DenseMatrix lagrangian_hessian;
};

struct OptimizationCertificate {
    std::string name;
    double primal_feasibility = std::numeric_limits<double>::infinity();
    double dual_feasibility = std::numeric_limits<double>::infinity();
    double complementarity = std::numeric_limits<double>::infinity();
    double stationarity = std::numeric_limits<double>::infinity();
    double projected_gradient = std::numeric_limits<double>::infinity();
    double kkt_residual = std::numeric_limits<double>::infinity();
    double hessian_minimum_eigenvalue = std::numeric_limits<double>::quiet_NaN();
    bool hessian_positive_semidefinite = false;
    bool passed = false;
    std::string diagnostic;
};

[[nodiscard]] OptimizationCertificate certify_optimization(
    const OptimizationCertificationProblem& problem,
    double feasibility_tolerance = 1.0e-8,
    double stationarity_tolerance = 1.0e-7);

struct SolverResultVector {
    std::string solver;
    std::vector<double> value;
    bool independently_implemented = true;
};

struct SolverPairDisagreement {
    std::string left_solver;
    std::string right_solver;
    double absolute_disagreement = 0.0;
    double relative_disagreement = 0.0;
};

struct ConsensusReport {
    std::vector<SolverResultVector> results;
    std::vector<double> consensus_value;
    std::vector<SolverPairDisagreement> pairwise;
    std::vector<std::string> outlier_solvers;
    double maximum_absolute_disagreement = 0.0;
    double maximum_relative_disagreement = 0.0;
    bool passed = false;
    std::string diagnostic;
};

[[nodiscard]] ConsensusReport cross_solver_consensus(
    std::vector<SolverResultVector> results,
    double absolute_tolerance = 1.0e-10,
    double relative_tolerance = 1.0e-8,
    std::size_t minimum_independent_solvers = 2);

struct PropertySpecification {
    std::string name;
    std::vector<std::pair<double, double>> ranges;
    std::size_t trials = 1000;
    std::uint64_t seed = 0;
    std::function<bool(const std::vector<double>&, std::string&)> predicate;
};

struct PropertyTestReport {
    std::string name;
    std::size_t trials_requested = 0;
    std::size_t trials_executed = 0;
    std::uint64_t seed = 0;
    bool passed = false;
    std::vector<double> counterexample;
    std::vector<double> shrunk_counterexample;
    std::string failure;
};

[[nodiscard]] PropertyTestReport run_property_test(
    const PropertySpecification& specification);

struct MathematicalEvidenceCertificate {
    std::string schema = "aesim.mathematical-evidence.v1";
    std::string result_id;
    std::string operation;
    std::string method;
    std::string precision;
    std::string created_utc;
    double absolute_tolerance = 0.0;
    double relative_tolerance = 0.0;
    std::size_t iterations = 0;
    double residual_norm = std::numeric_limits<double>::quiet_NaN();
    double backward_error = std::numeric_limits<double>::quiet_NaN();
    double condition_estimate = std::numeric_limits<double>::quiet_NaN();
    double verified_digits = 0.0;
    bool converged = false;
    bool qualified = false;
    ErrorBudgetSummary error_budget;
    std::optional<ConvergenceReport> convergence;
    std::optional<DerivativeCertificate> derivative;
    std::optional<OptimizationCertificate> optimization;
    std::optional<ConsensusReport> consensus;
    std::vector<PropertyTestReport> properties;
    std::map<std::string, std::string> metadata;
    std::string evidence_sha256;

    [[nodiscard]] std::string canonical_json(bool include_digest = true) const;
    void seal();
    [[nodiscard]] bool verify_digest() const;
};

[[nodiscard]] MathematicalEvidenceCertificate certify_dense_solve_result(
    std::string result_id, std::string operation,
    const numerics::DenseSolveResult& result, double result_scale,
    const numerics::TolerancePolicy& tolerance = numerics::tolerance_policy());
[[nodiscard]] MathematicalEvidenceCertificate certify_quadrature_result(
    std::string result_id, std::string operation,
    const numerics::QuadratureResult& result,
    double absolute_tolerance = 1.0e-10,
    double relative_tolerance = 1.0e-9);
[[nodiscard]] MathematicalEvidenceCertificate certify_ode_result(
    std::string result_id, std::string operation,
    const numerics::OdeResult& result, double state_scale,
    const numerics::OdeOptions& options = {});

[[nodiscard]] std::string precision_tier_name(PrecisionTier tier);
[[nodiscard]] std::string error_category_name(ErrorCategory category);

}  // namespace aesim::core::math_assurance

#pragma once

#include <string>

namespace aesim::core {

struct GasPathOperatingPoint {
    double rpm = 850.0;
    double throttle = 0.0;
    double ambient_pressure_kpa = 101.325;
    double ambient_temperature_c = 25.0;
    double displacement_m3 = 0.002;
    double volumetric_efficiency = 0.85;
    double fuel_flow_g_s = 0.0;
    double exhaust_temperature_c = 450.0;
    double wastegate_position = 0.75;
    double egr_fraction = 0.0;
    double intake_vvt_deg = 0.0;
    double exhaust_vvt_deg = 0.0;
};

struct GasPathParameters {
    double intake_manifold_volume_m3 = 0.0032;
    double exhaust_manifold_volume_m3 = 0.0024;
    double compressor_inlet_volume_m3 = 0.0015;
    double throttle_area_max_m2 = 0.00155;
    double turbine_area_m2 = 0.00062;
    double wastegate_area_m2 = 0.00038;
    double egr_area_m2 = 0.00010;
    double throttle_discharge_coefficient = 0.78;
    double turbine_discharge_coefficient = 0.72;
    double intercooler_effectiveness = 0.72;
    double intercooler_pressure_drop_kpa_at_100gs = 5.0;
    double turbo_inertia_kg_m2 = 1.4e-5;
    double turbo_friction_w_per_krpm = 0.45;
    double compressor_flow_scale = 1.0;
    double turbine_flow_scale = 1.0;
    double heat_transfer_multiplier = 1.0;
    double minimum_turbo_rpm = 8000.0;
    double maximum_turbo_rpm = 260000.0;
};

struct GasPathState {
    double compressor_inlet_pressure_kpa = 101.325;
    double compressor_outlet_pressure_kpa = 101.325;
    double compressor_outlet_temperature_c = 25.0;
    double intercooler_outlet_temperature_c = 25.0;
    double manifold_pressure_kpa = 101.325;
    double manifold_temperature_c = 30.0;
    double exhaust_manifold_pressure_kpa = 105.0;
    double exhaust_manifold_temperature_c = 450.0;
    double turbo_speed_rpm = 18000.0;
    double compressor_pressure_ratio = 1.0;
    double turbine_pressure_ratio = 1.04;
    double compressor_efficiency = 0.60;
    double turbine_efficiency = 0.62;
    double compressor_flow_g_s = 0.0;
    double throttle_flow_g_s = 0.0;
    double engine_air_flow_g_s = 0.0;
    double turbine_flow_g_s = 0.0;
    double wastegate_flow_g_s = 0.0;
    double egr_flow_g_s = 0.0;
    double compressor_power_kw = 0.0;
    double turbine_power_kw = 0.0;
    double surge_margin = 1.0;
    double choke_margin = 1.0;
    double mass_balance_residual_g_s = 0.0;
    double energy_balance_residual_kw = 0.0;
    bool compressor_map_extrapolated = false;
    bool turbine_map_extrapolated = false;
};

struct GasPathSnapshot {
    GasPathState state;
    double intake_mass_kg = 0.0;
    double exhaust_mass_kg = 0.0;
};

class LumpedGasPathModel {
public:
    LumpedGasPathModel() = default;
    explicit LumpedGasPathModel(GasPathParameters parameters);

    void set_parameters(const GasPathParameters& parameters);
    [[nodiscard]] const GasPathParameters& parameters() const noexcept;
    [[nodiscard]] const GasPathState& state() const noexcept;
    void reset(double ambient_pressure_kpa = 101.325, double ambient_temperature_c = 25.0);
    const GasPathState& step(double dt_s, const GasPathOperatingPoint& input);
    [[nodiscard]] std::string report() const;
    [[nodiscard]] GasPathSnapshot snapshot() const noexcept;
    void restore(const GasPathSnapshot& snapshot);

private:
    GasPathParameters parameters_;
    GasPathState state_;
    double intake_mass_kg_ = 0.0035;
    double exhaust_mass_kg_ = 0.0015;

    static double clamp(double value, double low, double high);
    static double compressible_orifice_flow(double upstream_pa, double downstream_pa,
                                            double upstream_temp_k, double area_m2,
                                            double discharge_coefficient,
                                            double gas_constant, double gamma);
};

}  // namespace aesim::core

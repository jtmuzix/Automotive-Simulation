#pragma once

#include <cstddef>
#include <cstdint>
#include <fstream>
#include <map>
#include <mutex>
#include <string>
#include <vector>

namespace aesim::core {

// Canonical process/build identity helpers used by manifests, workspace
// snapshots, and qualification records. Keeping one implementation prevents
// platform-specific drift between provenance producers.
[[nodiscard]] std::string compiler_identity();
[[nodiscard]] std::string platform_identity();
[[nodiscard]] std::string executable_path();

class Sha256 {
public:
    static std::string digest_bytes(const void* data, std::size_t size);
    static std::string digest_string(const std::string& data);
    static std::string digest_file(const std::string& path);
};

struct ExperimentMetadata {
    std::string name;
    std::string description;
    std::string source_revision;
    std::string model_version = "aesim.research-core.v1";
    std::string configuration_canonical;
    std::uint64_t random_seed = 0;
    std::map<std::string, std::string> tags;
};

struct ExperimentStatus {
    bool active = false;
    std::string run_id;
    std::string run_directory;
    std::string started_utc;
    std::string completed_utc;
    std::uint64_t samples = 0;
    std::uint64_t events = 0;
    std::vector<std::string> artifacts;
};

class ExperimentManager {
public:
    ExperimentManager() = default;
    ~ExperimentManager();
    ExperimentManager(const ExperimentManager&) = delete;
    ExperimentManager& operator=(const ExperimentManager&) = delete;

    std::string begin(const ExperimentMetadata& metadata, const std::string& root_directory);
    void record_sample(double simulation_time_s, const std::map<std::string, double>& metrics);
    void record_event(double simulation_time_s, const std::string& category, const std::string& message);
    bool add_artifact(const std::string& path, const std::string& role);
    std::string finalize(const std::map<std::string, double>& summary = {});
    void abort(const std::string& reason);

    [[nodiscard]] bool active() const;
    [[nodiscard]] ExperimentStatus status() const;
    [[nodiscard]] std::string report() const;
    static bool verify(const std::string& run_directory, std::string& report);

private:
    struct Artifact {
        // Portable path relative to the experiment run directory.
        std::string path;
        // Original registration source retained for auditability; verification
        // never depends on this external location.
        std::string source_path;
        std::string role;
        std::string sha256;
        std::uintmax_t size = 0;
    };

    mutable std::mutex mutex_;
    ExperimentMetadata metadata_;
    ExperimentStatus status_;
    std::vector<Artifact> artifacts_;
    std::ofstream samples_stream_;
    std::ofstream events_stream_;
    std::vector<std::string> sample_columns_;

    static std::string utc_now();
    static std::string sanitize_name(const std::string& name);
    static std::string json_escape(const std::string& text);
    static std::string compiler_identity();
    static std::string platform_identity();
    static std::string executable_path();
    bool register_artifact_locked(const std::string& source_path, const std::string& role,
                                  bool copy_external);
    void close_streams_noexcept();
    void write_manifest_locked(const std::map<std::string, double>& summary);
};

}  // namespace aesim::core

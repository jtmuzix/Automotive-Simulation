#pragma once

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace aesim::core {

struct CalibrationParameter {
    std::string name;
    double value = 0.0;
    double lower = -1.0e300;
    double upper = 1.0e300;
    double finite_difference_step = 1.0e-4;
};

struct CalibrationObservation {
    std::string id;
    std::map<std::string, double> inputs;
    std::map<std::string, double> observed;
    std::map<std::string, double> standard_deviation;
};

struct CalibrationOptions {
    std::size_t global_generations = 24;
    std::size_t population_size = 0;
    std::size_t local_iterations = 40;
    double differential_weight = 0.72;
    double crossover_probability = 0.88;
    double initial_damping = 1.0e-2;
    double gradient_tolerance = 1.0e-8;
    double step_tolerance = 1.0e-8;
    double huber_delta = 2.5;
    std::uint64_t seed = 0xA351BEEF1234ULL;
};

struct FittedParameter {
    std::string name;
    double value = 0.0;
    double standard_error = 0.0;
    double lower = 0.0;
    double upper = 0.0;
    bool at_bound = false;
};

struct CalibrationFitResult {
    bool converged = false;
    std::string termination_reason;
    std::size_t evaluations = 0;
    std::size_t global_generations = 0;
    std::size_t local_iterations = 0;
    double initial_cost = 0.0;
    double final_cost = 0.0;
    double root_mean_square_weighted_residual = 0.0;
    double condition_estimate = 0.0;
    std::vector<FittedParameter> parameters;
    std::vector<std::vector<double>> correlation_matrix;
    std::map<std::string, double> metric_rmse;
};

class CalibrationOptimizer {
public:
    using Model = std::function<std::map<std::string, double>(
        const std::map<std::string, double>& inputs,
        const std::map<std::string, double>& parameters)>;

    static CalibrationFitResult fit(const std::vector<CalibrationObservation>& observations,
                                    const std::vector<CalibrationParameter>& parameters,
                                    const Model& model,
                                    const CalibrationOptions& options = {});
    static std::string render_text(const CalibrationFitResult& result);
    static bool export_json(const CalibrationFitResult& result, const std::string& path);
};

}  // namespace aesim::core

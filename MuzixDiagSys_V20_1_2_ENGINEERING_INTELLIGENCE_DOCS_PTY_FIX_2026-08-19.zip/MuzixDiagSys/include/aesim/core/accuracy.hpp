#pragma once

#include "aesim/core/calibration.hpp"
#include "aesim/core/provenance.hpp"
#include "aesim/core/uncertainty.hpp"

#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::core {

// -----------------------------------------------------------------------------
// Conservation auditing
// -----------------------------------------------------------------------------

// A single value object carries every conserved quantity used by the simulator.
// Keeping the arithmetic centralized prevents individual subsystems from using
// inconsistent sign conventions for energy, mass, charge, or momentum.
struct ConservedQuantities {
    double energy_j = 0.0;
    double mass_kg = 0.0;
    double charge_c = 0.0;
    double linear_momentum_kg_m_s = 0.0;
    double angular_momentum_kg_m2_s = 0.0;

    ConservedQuantities& operator+=(const ConservedQuantities& other) noexcept;
    ConservedQuantities& operator-=(const ConservedQuantities& other) noexcept;
};

[[nodiscard]] ConservedQuantities operator+(ConservedQuantities lhs,
                                             const ConservedQuantities& rhs) noexcept;
[[nodiscard]] ConservedQuantities operator-(ConservedQuantities lhs,
                                             const ConservedQuantities& rhs) noexcept;
[[nodiscard]] ConservedQuantities operator*(ConservedQuantities value, double scale) noexcept;

struct ConservationTolerance {
    ConservedQuantities absolute{1.0, 1.0e-8, 1.0e-6, 1.0e-5, 1.0e-5};
    ConservedQuantities relative{1.0e-5, 1.0e-7, 1.0e-7, 1.0e-6, 1.0e-6};
};

struct ConservationDomainResult {
    std::string domain;
    ConservedQuantities storage_change;
    ConservedQuantities external_net_input;
    ConservedQuantities transfer_net_input;
    ConservedQuantities residual;
    ConservedQuantities normalized_residual;
    std::uint64_t violations = 0;
    bool passed = true;
};

struct ConservationAuditResult {
    double time_s = 0.0;
    double step_s = 0.0;
    std::uint64_t step_index = 0;
    std::vector<ConservationDomainResult> domains;
    ConservedQuantities global_residual;
    ConservedQuantities global_normalized_residual;
    std::uint64_t violations = 0;
    bool passed = true;
};

class ConservationAuditor {
public:
    void set_tolerance(ConservationTolerance tolerance);
    void reset(double time_s = 0.0);

    // Storage is an absolute state sampled at the beginning or end of a step.
    void set_storage(const std::string& domain, const ConservedQuantities& storage);

    // External rates use the convention positive = entering the named domain.
    void add_external_rate(const std::string& domain, const ConservedQuantities& net_rate);

    // Transfers are recorded once. The auditor adds the rate to `to_domain` and
    // subtracts it from `from_domain`, allowing mismatched interfaces to be found.
    void add_transfer_rate(const std::string& from_domain, const std::string& to_domain,
                           const ConservedQuantities& rate);

    [[nodiscard]] ConservationAuditResult close_step(double end_time_s);
    [[nodiscard]] const ConservationAuditResult& last_result() const noexcept;
    [[nodiscard]] std::string report() const;
    bool export_csv(const std::string& path) const;

private:
    struct DomainLedger {
        ConservedQuantities previous_storage;
        ConservedQuantities current_storage;
        ConservedQuantities external_rate;
        ConservedQuantities transfer_rate;
        bool initialized = false;
        std::uint64_t violations = 0;
    };

    ConservationTolerance tolerance_;
    std::map<std::string, DomainLedger> ledgers_;
    ConservationAuditResult last_;
    std::vector<ConservationAuditResult> history_;
    double previous_time_s_ = 0.0;
    std::uint64_t step_index_ = 0;
};

// -----------------------------------------------------------------------------
// Test-data ingestion, synchronization, and unit normalization
// -----------------------------------------------------------------------------

enum class TestChannelRole { Time, Input, Observed, Sigma, Auxiliary };
enum class InterpolationKind { Hold, Linear };

struct TestChannelDescriptor {
    std::string name;
    std::string source_name;
    // Row maps use a role-qualified key (for example observed.speed and
    // sigma.speed) so channels sharing the same physical metric cannot overwrite
    // one another after the role prefix is parsed.
    std::string storage_key;
    std::string source_unit;
    std::string canonical_unit;
    TestChannelRole role = TestChannelRole::Auxiliary;
    InterpolationKind interpolation = InterpolationKind::Linear;
    double scale = 1.0;
    double offset = 0.0;
};

struct TestDataRow {
    double time_s = 0.0;
    std::map<std::string, double> values;
    std::map<std::string, bool> valid;
};

struct TestDataSet {
    std::string name;
    std::string source_path;
    std::string source_sha256;
    std::vector<TestChannelDescriptor> channels;
    std::vector<TestDataRow> rows;
    std::vector<std::string> warnings;
};

struct TestDataIngestionOptions {
    char delimiter = '\0';                 // '\0' performs delimiter detection.
    std::string time_column = "time";
    std::string default_time_unit = "s";
    bool sort_by_time = true;
    bool merge_duplicate_timestamps = true;
    bool reject_non_monotonic_time = false;
    double resample_period_s = 0.0;        // <=0 preserves the source timestamps.
    double maximum_interpolation_gap_s = 1.0e300;
};

class TestDataIngestor {
public:
    static TestDataSet load_delimited(const std::string& path,
                                      const TestDataIngestionOptions& options = {});
    static TestDataSet resample(const TestDataSet& source, double period_s,
                                double maximum_gap_s = 1.0e300);
    static TestDataSet synchronize(const std::vector<TestDataSet>& sources,
                                   double period_s,
                                   double maximum_gap_s = 1.0e300);
    static bool export_csv(const TestDataSet& dataset, const std::string& path);
    static std::string report(const TestDataSet& dataset);
};

// -----------------------------------------------------------------------------
// Residual analysis
// -----------------------------------------------------------------------------

struct ResidualSegmentStatistics {
    std::size_t first_index = 0;
    std::size_t last_index = 0;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    double bias = 0.0;
    double rmse = 0.0;
    double maximum_absolute_error = 0.0;
};

struct ResidualChannelAnalysis {
    std::string metric;
    std::size_t count = 0;
    double bias = 0.0;
    double mae = 0.0;
    double rmse = 0.0;
    double normalized_rmse = 0.0;
    double residual_standard_deviation = 0.0;
    double maximum_absolute_error = 0.0;
    double r_squared = 0.0;
    double durbin_watson = 0.0;
    double lag1_autocorrelation = 0.0;
    double ljung_box_q = 0.0;
    double linear_drift_per_s = 0.0;
    double best_phase_lag_s = 0.0;
    double spectral_rmse = 0.0;
    double low_frequency_power_fraction = 0.0;
    std::vector<ResidualSegmentStatistics> segments;
};

struct ResidualAnalysisResult {
    std::string dataset_name;
    std::vector<ResidualChannelAnalysis> channels;
    std::vector<std::string> warnings;
};

class ResidualAnalyzer {
public:
    static ResidualAnalysisResult analyze(
        const TestDataSet& measured,
        const std::vector<std::map<std::string, double>>& predicted,
        std::size_t segment_count = 4,
        std::size_t maximum_phase_lag_samples = 100,
        std::size_t spectral_bins = 64);
    static std::string report(const ResidualAnalysisResult& result);
    static bool export_csv(const ResidualAnalysisResult& result, const std::string& path);
    static bool export_json(const ResidualAnalysisResult& result, const std::string& path);
};

// -----------------------------------------------------------------------------
// Automated calibration and correlated uncertainty propagation
// -----------------------------------------------------------------------------

struct AutomatedCalibrationOptions {
    CalibrationOptions optimizer;
    std::size_t multi_start_runs = 4;
    std::size_t robust_reweight_iterations = 2;
    std::size_t cross_validation_folds = 5;
    double outlier_sigma = 4.0;
    std::uint64_t seed = 0xA351CA11B4A7ULL;
};

struct AutomatedCalibrationResult {
    CalibrationFitResult fit;
    std::vector<double> fold_rmse;
    std::map<std::string, double> validation_metric_rmse;
    std::vector<std::string> identifiability_warnings;
    std::size_t candidate_fits = 0;
};

class AutomatedCalibrationPipeline {
public:
    static AutomatedCalibrationResult run(
        const std::vector<CalibrationObservation>& observations,
        const std::vector<CalibrationParameter>& parameters,
        const CalibrationOptimizer::Model& model,
        const AutomatedCalibrationOptions& options = {});
    static std::string report(const AutomatedCalibrationResult& result);
};

struct CorrelationEntry {
    std::string first;
    std::string second;
    double correlation = 0.0;
};

struct CorrelatedUncertaintyOptions {
    std::size_t samples = 256;
    std::uint64_t seed = 0xA351BEEF1234ULL;
    bool retain_samples = true;
    std::vector<CorrelationEntry> correlations;
    std::map<std::string, double> failure_thresholds;
};

struct CorrelatedUncertaintyResult {
    UncertaintyResult marginal;
    std::map<std::string, double> failure_probability;
    std::map<std::pair<std::string, std::string>, double> output_covariance;
    std::vector<std::string> warnings;
};

class CorrelatedUncertaintyPropagator {
public:
    static CorrelatedUncertaintyResult propagate(
        const std::vector<UncertainParameter>& parameters,
        const UncertaintyAnalyzer::Evaluator& evaluator,
        const CorrelatedUncertaintyOptions& options = {});
    static std::string report(const CorrelatedUncertaintyResult& result);
};

// -----------------------------------------------------------------------------
// Forward-mode automatic differentiation and implicit DAE integration
// -----------------------------------------------------------------------------

class DynamicDual {
public:
    DynamicDual() = default;
    explicit DynamicDual(double value, std::size_t derivatives = 0);
    DynamicDual(double value, std::vector<double> gradient);

    [[nodiscard]] double value() const noexcept;
    [[nodiscard]] const std::vector<double>& gradient() const noexcept;
    [[nodiscard]] std::vector<double>& gradient() noexcept;

    static DynamicDual variable(double value, std::size_t dimension, std::size_t index);

private:
    double value_ = 0.0;
    std::vector<double> gradient_;
};

DynamicDual operator+(const DynamicDual& lhs, const DynamicDual& rhs);
DynamicDual operator-(const DynamicDual& lhs, const DynamicDual& rhs);
DynamicDual operator*(const DynamicDual& lhs, const DynamicDual& rhs);
DynamicDual operator/(const DynamicDual& lhs, const DynamicDual& rhs);
DynamicDual operator-(const DynamicDual& value);
DynamicDual operator+(const DynamicDual& lhs, double rhs);
DynamicDual operator+(double lhs, const DynamicDual& rhs);
DynamicDual operator-(const DynamicDual& lhs, double rhs);
DynamicDual operator-(double lhs, const DynamicDual& rhs);
DynamicDual operator*(const DynamicDual& lhs, double rhs);
DynamicDual operator*(double lhs, const DynamicDual& rhs);
DynamicDual operator/(const DynamicDual& lhs, double rhs);
DynamicDual operator/(double lhs, const DynamicDual& rhs);
DynamicDual exp(const DynamicDual& value);
DynamicDual log(const DynamicDual& value);
DynamicDual sqrt(const DynamicDual& value);
DynamicDual sin(const DynamicDual& value);
DynamicDual cos(const DynamicDual& value);
DynamicDual tanh(const DynamicDual& value);
DynamicDual pow(const DynamicDual& base, double exponent);

struct SparseJacobianPattern {
    std::size_t rows = 0;
    std::size_t columns = 0;
    // Structural nonzero row indices for each column.  The representation is
    // intentionally independent of a specific sparse matrix package so the
    // core AD engine remains usable by every simulator domain.
    std::vector<std::vector<std::size_t>> rows_by_column;
    void validate() const;
};

struct SparseJacobianColoring {
    std::vector<std::size_t> color_of_column;
    std::size_t color_count = 0;
};

struct SparseAutomaticJacobianResult {
    std::vector<double> values;
    std::vector<std::vector<double>> jacobian;
    SparseJacobianColoring coloring;
    std::size_t dense_seed_dimension = 0;
    std::size_t compressed_seed_dimension = 0;
};

class AutomaticJacobian {
public:
    using Function = std::function<std::vector<DynamicDual>(const std::vector<DynamicDual>&)>;
    static std::pair<std::vector<double>, std::vector<std::vector<double>>>
    evaluate(const std::vector<double>& point, const Function& function);
    [[nodiscard]] static SparseJacobianColoring color_sparsity(
        const SparseJacobianPattern& pattern);
    [[nodiscard]] static SparseAutomaticJacobianResult evaluate_sparse_colored(
        const std::vector<double>& point, const Function& function,
        const SparseJacobianPattern& pattern);
};

enum class DaeMethod { BackwardEuler, Bdf2, ImplicitMidpoint };
enum class EventDirection { Any, Rising, Falling };

struct DaeEvent {
    std::string name;
    EventDirection direction = EventDirection::Any;
    bool terminal = false;
    double value_tolerance = 1.0e-10;
    double time_tolerance_s = 1.0e-10;
    std::function<double(double, const std::vector<double>&)> function;
    std::function<void(double, std::vector<double>&)> handler;
};

struct DaeSolverOptions {
    DaeMethod method = DaeMethod::Bdf2;
    double relative_tolerance = 1.0e-7;
    double absolute_tolerance = 1.0e-9;
    double minimum_step_s = 1.0e-8;
    double maximum_step_s = 0.05;
    unsigned maximum_newton_iterations = 20;
    unsigned maximum_rejections = 20;
    bool adaptive = true;
    bool localize_events = true;
    // When an automatic residual is configured, a supplied structural sparsity
    // pattern enables compressed forward-mode seeds via deterministic graph
    // coloring.  An empty pattern preserves the established dense AD path.
    std::optional<SparseJacobianPattern> automatic_jacobian_pattern;
};

struct DaeStepStatistics {
    std::uint64_t accepted_steps = 0;
    std::uint64_t rejected_steps = 0;
    std::uint64_t rollbacks = 0;
    std::uint64_t jacobian_evaluations = 0;
    std::uint64_t residual_evaluations = 0;
    std::uint64_t nonlinear_iterations = 0;
    std::uint64_t localized_events = 0;
    double last_step_s = 0.0;
    double last_error_norm = 0.0;
    double last_residual_norm = 0.0;
};

struct DaeSnapshot {
    double time_s = 0.0;
    std::vector<double> state;
    std::vector<double> previous_state;
    double previous_step_s = 0.0;
    bool has_history = false;
    DaeStepStatistics statistics;
};

class ImplicitDaeSolver {
public:
    using Residual = std::function<std::vector<double>(
        double time_s, const std::vector<double>& state,
        const std::vector<double>& derivative)>;
    using AutoResidual = std::function<std::vector<DynamicDual>(
        double time_s, const std::vector<DynamicDual>& state,
        const std::vector<DynamicDual>& derivative)>;

    void configure(DaeSolverOptions options);
    void set_residual(Residual residual);
    void set_automatic_residual(AutoResidual residual);
    void set_events(std::vector<DaeEvent> events);
    void initialize(double time_s, std::vector<double> state);
    void advance(double duration_s);

    [[nodiscard]] double time_s() const noexcept;
    [[nodiscard]] const std::vector<double>& state() const noexcept;
    [[nodiscard]] const DaeStepStatistics& statistics() const noexcept;
    [[nodiscard]] DaeSnapshot snapshot() const;
    void restore(const DaeSnapshot& snapshot);
    [[nodiscard]] std::string report() const;

private:
    struct TrialResult {
        bool converged = false;
        std::vector<double> state;
        double residual_norm = 0.0;
        unsigned iterations = 0;
    };

    DaeSolverOptions options_;
    Residual residual_;
    AutoResidual auto_residual_;
    std::vector<DaeEvent> events_;
    double time_s_ = 0.0;
    std::vector<double> state_;
    std::vector<double> previous_state_;
    double previous_step_s_ = 0.0;
    bool initialized_ = false;
    bool has_history_ = false;
    DaeStepStatistics statistics_;

    TrialResult solve_trial(double start_time_s, const std::vector<double>& start_state,
                            const std::vector<double>& older_state, bool has_older_state,
                            double step_s, DaeMethod method);
    double error_norm(const std::vector<double>& coarse,
                      const std::vector<double>& refined) const;
    bool process_events(double start_time_s, const std::vector<double>& start_state,
                        double end_time_s, std::vector<double>& end_state,
                        double& consumed_step_s);
};

// -----------------------------------------------------------------------------
// Multi-rate integration, rollback, and cross-domain coupling diagnostics
// -----------------------------------------------------------------------------

struct CouplingIterationDiagnostic {
    std::size_t iteration = 0;
    double maximum_state_residual = 0.0;
    double rms_state_residual = 0.0;
    double interface_power_mismatch_w = 0.0;
};

struct CouplingStepDiagnostic {
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    bool converged = false;
    bool rolled_back = false;
    std::vector<CouplingIterationDiagnostic> iterations;
    std::map<std::string, double> domain_execution_time_s;
    std::map<std::string, std::uint64_t> domain_substeps;
};

struct MultiRateDomainDefinition {
    std::string name;
    double period_s = 0.001;
    int priority = 0;
    std::function<std::vector<double>()> snapshot;
    std::function<void(const std::vector<double>&)> restore;
    std::function<void(double, double, const std::map<std::string, double>&)> advance;
    std::function<std::map<std::string, double>()> outputs;
};

struct MultiRateCouplingOptions {
    std::size_t maximum_iterations = 12;
    double absolute_tolerance = 1.0e-8;
    double relative_tolerance = 1.0e-6;
    double relaxation = 0.65;
    bool iterate = true;
    bool rollback_on_failure = true;
};

class MultiRateCouplingCoordinator {
public:
    void configure(MultiRateCouplingOptions options);
    void add_domain(MultiRateDomainDefinition domain);
    void clear();
    void initialize(double time_s = 0.0);
    CouplingStepDiagnostic advance(double macro_step_s);
    [[nodiscard]] double time_s() const noexcept;
    [[nodiscard]] const CouplingStepDiagnostic& last_diagnostic() const noexcept;
    [[nodiscard]] std::string report() const;

private:
    MultiRateCouplingOptions options_;
    std::vector<MultiRateDomainDefinition> domains_;
    double time_s_ = 0.0;
    CouplingStepDiagnostic last_;
};

// -----------------------------------------------------------------------------
// Configuration and result provenance
// -----------------------------------------------------------------------------

struct ProvenanceFile {
    std::string role;
    std::string path;
    std::string sha256;
    std::uintmax_t size = 0;
};

struct ProvenanceRecord {
    std::string schema = "aesim.provenance.v3";
    std::string run_id;
    std::string created_utc;
    std::string executable_path;
    std::string executable_sha256;
    std::string compiler;
    std::string platform;
    std::string command_line;
    std::uint64_t random_seed = 0;
    std::string configuration_sha256;
    // SHA-256 over canonical run metadata and all referenced file records. This
    // binds metadata edits to the same integrity check as configuration/results.
    std::string record_sha256;
    std::vector<ProvenanceFile> configurations;
    std::vector<ProvenanceFile> results;
    std::map<std::string, std::string> environment;
    std::map<std::string, std::string> tags;
};

class ProvenanceRecorder {
public:
    void begin(std::string command_line, std::uint64_t random_seed,
               std::map<std::string, std::string> tags = {});
    void add_configuration(const std::string& path, const std::string& role = "configuration");
    void add_result(const std::string& path, const std::string& role = "result");
    [[nodiscard]] const ProvenanceRecord& record() const noexcept;
    bool write_json(const std::string& path) const;
    static bool verify(const std::string& path, std::string& report);
    [[nodiscard]] std::string report() const;

private:
    void refresh_record_hash();
    ProvenanceRecord record_;
};

} // namespace aesim::core

#pragma once

#include <complex>
#include <cstddef>
#include <functional>
#include <limits>
#include <string>
#include <utility>
#include <vector>

namespace aesim::core::numerics {

enum class RigorLevel { Fast, Engineering, Qualification };

struct TolerancePolicy {
    RigorLevel level = RigorLevel::Qualification;
    double absolute = 1.0e-12;
    double relative = 1.0e-10;
    double pivot = 1.0e-14;
    double rank = 1.0e-12;
    std::size_t iterative_refinement_steps = 5;
    bool equilibrate = true;
};

[[nodiscard]] TolerancePolicy tolerance_policy(RigorLevel level = RigorLevel::Qualification);
[[nodiscard]] double scaled_tolerance(double reference, const TolerancePolicy& policy);
[[nodiscard]] bool approximately_equal(double left, double right,
                                       const TolerancePolicy& policy = tolerance_policy());

class CompensatedSum {
public:
    void add(double value) noexcept;
    void add_product(double left, double right) noexcept;
    [[nodiscard]] double value() const noexcept;
    [[nodiscard]] long double extended_value() const noexcept;
    void reset() noexcept;
private:
    long double sum_ = 0.0L;
    long double correction_ = 0.0L;
};

[[nodiscard]] double compensated_sum(const std::vector<double>& values);
[[nodiscard]] double compensated_dot(const std::vector<double>& left,
                                     const std::vector<double>& right);
[[nodiscard]] double stable_l2_norm(const std::vector<double>& values);
[[nodiscard]] double stable_rms(const std::vector<double>& values);

class OnlineMoments {
public:
    void add(double value);
    void merge(const OnlineMoments& other);
    [[nodiscard]] std::size_t count() const noexcept { return count_; }
    [[nodiscard]] double mean() const noexcept;
    [[nodiscard]] double variance_population() const noexcept;
    [[nodiscard]] double variance_sample() const noexcept;
    [[nodiscard]] double standard_deviation_sample() const noexcept;
    [[nodiscard]] double skewness() const noexcept;
    [[nodiscard]] double excess_kurtosis() const noexcept;
    [[nodiscard]] double minimum() const noexcept { return minimum_; }
    [[nodiscard]] double maximum() const noexcept { return maximum_; }
private:
    std::size_t count_ = 0;
    long double mean_ = 0.0L;
    long double m2_ = 0.0L;
    long double m3_ = 0.0L;
    long double m4_ = 0.0L;
    double minimum_ = std::numeric_limits<double>::infinity();
    double maximum_ = -std::numeric_limits<double>::infinity();
};

class OnlineCovariance {
public:
    void add(double x, double y);
    [[nodiscard]] std::size_t count() const noexcept { return count_; }
    [[nodiscard]] double covariance_sample() const noexcept;
    [[nodiscard]] double correlation() const noexcept;
    [[nodiscard]] double mean_x() const noexcept { return static_cast<double>(mean_x_); }
    [[nodiscard]] double mean_y() const noexcept { return static_cast<double>(mean_y_); }
private:
    std::size_t count_ = 0;
    long double mean_x_ = 0.0L;
    long double mean_y_ = 0.0L;
    long double c2_ = 0.0L;
    long double m2_x_ = 0.0L;
    long double m2_y_ = 0.0L;
};

class DenseMatrix {
public:
    DenseMatrix() = default;
    DenseMatrix(std::size_t rows, std::size_t columns, double value = 0.0);
    DenseMatrix(std::size_t rows, std::size_t columns, std::vector<double> data);
    [[nodiscard]] static DenseMatrix from_nested(const std::vector<std::vector<double>>& values);
    [[nodiscard]] std::vector<std::vector<double>> to_nested() const;
    [[nodiscard]] std::size_t rows() const noexcept { return rows_; }
    [[nodiscard]] std::size_t columns() const noexcept { return columns_; }
    [[nodiscard]] bool square() const noexcept { return rows_ == columns_; }
    [[nodiscard]] double& operator()(std::size_t row, std::size_t column);
    [[nodiscard]] double operator()(std::size_t row, std::size_t column) const;
    [[nodiscard]] const std::vector<double>& data() const noexcept { return data_; }
    [[nodiscard]] std::vector<double>& data() noexcept { return data_; }
    [[nodiscard]] std::vector<double> multiply(const std::vector<double>& x) const;
    [[nodiscard]] double infinity_norm() const;
private:
    std::size_t rows_ = 0;
    std::size_t columns_ = 0;
    std::vector<double> data_;
};

struct DenseSolveOptions {
    TolerancePolicy tolerance = tolerance_policy();
    bool estimate_condition = true;
    bool throw_on_singularity = true;
};

struct DenseSolveResult {
    std::vector<double> solution;
    bool converged = false;
    std::size_t rank = 0;
    std::size_t refinement_steps = 0;
    double residual_norm = std::numeric_limits<double>::infinity();
    double relative_residual = std::numeric_limits<double>::infinity();
    double componentwise_backward_error = std::numeric_limits<double>::infinity();
    double reciprocal_condition_estimate = 0.0;
    double pivot_growth = 0.0;
    std::string diagnostic;
};

[[nodiscard]] DenseSolveResult solve_linear(const DenseMatrix& matrix,
                                            const std::vector<double>& rhs,
                                            const DenseSolveOptions& options = {});
[[nodiscard]] DenseMatrix inverse(const DenseMatrix& matrix,
                                  const DenseSolveOptions& options = {});

struct ComplexDenseSolveResult {
    std::vector<std::complex<double>> solution;
    bool converged = false;
    std::size_t rank = 0;
    std::size_t refinement_steps = 0;
    double residual_norm = std::numeric_limits<double>::infinity();
    double relative_residual = std::numeric_limits<double>::infinity();
    double reciprocal_condition_estimate = 0.0;
    std::string diagnostic;
};

[[nodiscard]] ComplexDenseSolveResult solve_complex_linear(
    std::size_t dimension,
    const std::vector<std::complex<double>>& matrix,
    const std::vector<std::complex<double>>& rhs,
    const DenseSolveOptions& options = {});

struct LeastSquaresOptions {
    TolerancePolicy tolerance = tolerance_policy();
    double ridge = 0.0;
    bool compute_covariance = true;
};

struct LeastSquaresResult {
    std::vector<double> coefficients;
    DenseMatrix covariance;
    bool converged = false;
    std::size_t rank = 0;
    double residual_norm = std::numeric_limits<double>::infinity();
    double weighted_rms = std::numeric_limits<double>::infinity();
    double condition_estimate = std::numeric_limits<double>::infinity();
    std::vector<std::size_t> column_permutation;
    std::string diagnostic;
};

[[nodiscard]] LeastSquaresResult least_squares_qr(
    const DenseMatrix& design,
    const std::vector<double>& observations,
    const std::vector<double>& weights = {},
    const LeastSquaresOptions& options = {});

struct JacobianResult {
    DenseMatrix jacobian;
    std::vector<double> estimated_column_error;
    std::size_t evaluations = 0;
};

using VectorFunction = std::function<std::vector<double>(const std::vector<double>&)>;
[[nodiscard]] JacobianResult finite_difference_jacobian(
    const VectorFunction& function,
    const std::vector<double>& point,
    const std::vector<double>& lower_bounds = {},
    const std::vector<double>& upper_bounds = {});

struct RootResult {
    double root = 0.0;
    double residual = std::numeric_limits<double>::infinity();
    double bracket_width = std::numeric_limits<double>::infinity();
    std::size_t iterations = 0;
    bool converged = false;
};

[[nodiscard]] RootResult brent_root(const std::function<double(double)>& function,
                                    double lower, double upper,
                                    double absolute_tolerance = 1.0e-12,
                                    double relative_tolerance = 1.0e-10,
                                    std::size_t maximum_iterations = 100);

struct QuadratureResult {
    double integral = 0.0;
    double absolute_error = std::numeric_limits<double>::infinity();
    std::size_t evaluations = 0;
    std::size_t intervals = 0;
    bool converged = false;
};

[[nodiscard]] QuadratureResult adaptive_gauss_kronrod15(
    const std::function<double(double)>& function,
    double lower, double upper,
    double absolute_tolerance = 1.0e-10,
    double relative_tolerance = 1.0e-9,
    std::size_t maximum_intervals = 4096);

struct OdeOptions {
    double initial_step = 1.0e-3;
    double minimum_step = 1.0e-12;
    double maximum_step = 1.0;
    double absolute_tolerance = 1.0e-10;
    double relative_tolerance = 1.0e-8;
    std::size_t maximum_steps = 1000000;
};

struct OdeResult {
    std::vector<double> time;
    std::vector<std::vector<double>> states;
    std::size_t accepted_steps = 0;
    std::size_t rejected_steps = 0;
    std::size_t evaluations = 0;
    double maximum_normalized_error = 0.0;
    bool converged = false;
    std::string diagnostic;
};

using OdeFunction = std::function<std::vector<double>(double, const std::vector<double>&)>;
[[nodiscard]] OdeResult integrate_dormand_prince45(
    const OdeFunction& derivative,
    double initial_time,
    double final_time,
    const std::vector<double>& initial_state,
    const OdeOptions& options = {});

struct AuditObservation {
    std::string name;
    double computed = 0.0;
    double reference = 0.0;
    double absolute_tolerance = 0.0;
    double relative_tolerance = 0.0;
};

struct AuditEntry {
    std::string name;
    double absolute_error = 0.0;
    double relative_error = 0.0;
    double allowed_error = 0.0;
    bool passed = false;
};

struct NumericalAuditReport {
    std::vector<AuditEntry> entries;
    bool passed = true;
    double worst_normalized_error = 0.0;
};

[[nodiscard]] NumericalAuditReport audit_invariants(
    const std::vector<AuditObservation>& observations);

}  // namespace aesim::core::numerics

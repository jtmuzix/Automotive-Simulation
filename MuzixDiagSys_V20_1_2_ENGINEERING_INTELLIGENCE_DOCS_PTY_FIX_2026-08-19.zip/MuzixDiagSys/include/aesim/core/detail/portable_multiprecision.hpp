#pragma once

#include <algorithm>
#include <cstdint>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace aesim::core::math_assurance::detail {

class BigUnsigned {
public:
    BigUnsigned() = default;
    BigUnsigned(std::uint64_t value) {
        if (value != 0U) {
            limbs_.push_back(static_cast<std::uint32_t>(value));
            const auto high = static_cast<std::uint32_t>(value >> 32U);
            if (high != 0U) limbs_.push_back(high);
        }
    }

    [[nodiscard]] bool zero() const noexcept { return limbs_.empty(); }
    [[nodiscard]] bool odd() const noexcept { return !limbs_.empty() && (limbs_[0] & 1U) != 0U; }
    [[nodiscard]] std::size_t bit_length() const noexcept {
        if (limbs_.empty()) return 0U;
        const std::uint32_t high = limbs_.back();
#if defined(__GNUC__) || defined(__clang__)
        const unsigned leading = static_cast<unsigned>(__builtin_clz(high));
#else
        unsigned leading = 0U;
        for (std::uint32_t mask = 0x80000000U; mask != 0U && (high & mask) == 0U; mask >>= 1U) ++leading;
#endif
        return (limbs_.size() - 1U) * 32U + (32U - leading);
    }

    [[nodiscard]] bool test_bit(std::size_t bit) const noexcept {
        const std::size_t limb = bit / 32U;
        return limb < limbs_.size() && ((limbs_[limb] >> (bit % 32U)) & 1U) != 0U;
    }

    [[nodiscard]] bool any_bits_below(std::size_t bit) const noexcept {
        if (bit == 0U || limbs_.empty()) return false;
        const std::size_t full_limbs = bit / 32U;
        for (std::size_t i = 0; i < std::min(full_limbs, limbs_.size()); ++i) {
            if (limbs_[i] != 0U) return true;
        }
        const unsigned remainder = static_cast<unsigned>(bit % 32U);
        if (remainder != 0U && full_limbs < limbs_.size()) {
            const std::uint32_t mask = (std::uint32_t{1} << remainder) - 1U;
            return (limbs_[full_limbs] & mask) != 0U;
        }
        return false;
    }

    [[nodiscard]] int compare(const BigUnsigned& other) const noexcept {
        if (limbs_.size() != other.limbs_.size()) return limbs_.size() < other.limbs_.size() ? -1 : 1;
        for (std::size_t offset = 0; offset < limbs_.size(); ++offset) {
            const std::size_t i = limbs_.size() - 1U - offset;
            if (limbs_[i] != other.limbs_[i]) return limbs_[i] < other.limbs_[i] ? -1 : 1;
        }
        return 0;
    }

    BigUnsigned& operator+=(const BigUnsigned& other) {
        const std::size_t count = std::max(limbs_.size(), other.limbs_.size());
        limbs_.resize(count, 0U);
        std::uint64_t carry = 0U;
        for (std::size_t i = 0; i < count; ++i) {
            const std::uint64_t rhs = i < other.limbs_.size() ? other.limbs_[i] : 0U;
            const std::uint64_t sum = static_cast<std::uint64_t>(limbs_[i]) + rhs + carry;
            limbs_[i] = static_cast<std::uint32_t>(sum);
            carry = sum >> 32U;
        }
        if (carry != 0U) limbs_.push_back(static_cast<std::uint32_t>(carry));
        return *this;
    }

    BigUnsigned& subtract_assign(const BigUnsigned& other) {
        if (compare(other) < 0) throw std::logic_error("negative BigUnsigned subtraction");
        std::uint64_t borrow = 0U;
        for (std::size_t i = 0; i < limbs_.size(); ++i) {
            const std::uint64_t rhs = (i < other.limbs_.size() ? other.limbs_[i] : 0U) + borrow;
            const std::uint64_t lhs = limbs_[i];
            limbs_[i] = static_cast<std::uint32_t>(lhs - rhs);
            borrow = lhs < rhs ? 1U : 0U;
        }
        trim();
        return *this;
    }

    BigUnsigned& shift_left(std::size_t bits) {
        if (zero() || bits == 0U) return *this;
        const std::size_t whole = bits / 32U;
        const unsigned part = static_cast<unsigned>(bits % 32U);
        if (whole != 0U) limbs_.insert(limbs_.begin(), whole, 0U);
        if (part != 0U) {
            std::uint64_t carry = 0U;
            for (std::size_t i = whole; i < limbs_.size(); ++i) {
                const std::uint64_t value = (static_cast<std::uint64_t>(limbs_[i]) << part) | carry;
                limbs_[i] = static_cast<std::uint32_t>(value);
                carry = value >> 32U;
            }
            if (carry != 0U) limbs_.push_back(static_cast<std::uint32_t>(carry));
        }
        return *this;
    }

    BigUnsigned& shift_right(std::size_t bits) {
        if (zero() || bits == 0U) return *this;
        const std::size_t whole = bits / 32U;
        const unsigned part = static_cast<unsigned>(bits % 32U);
        if (whole >= limbs_.size()) {
            limbs_.clear();
            return *this;
        }
        if (whole != 0U) limbs_.erase(limbs_.begin(), limbs_.begin() + static_cast<std::ptrdiff_t>(whole));
        if (part != 0U) {
            std::uint32_t carry = 0U;
            for (std::size_t offset = 0; offset < limbs_.size(); ++offset) {
                const std::size_t i = limbs_.size() - 1U - offset;
                const std::uint32_t next_carry = static_cast<std::uint32_t>(limbs_[i] << (32U - part));
                limbs_[i] = static_cast<std::uint32_t>((limbs_[i] >> part) | carry);
                carry = next_carry;
            }
        }
        trim();
        return *this;
    }

    BigUnsigned& multiply_small(std::uint32_t factor) {
        if (factor == 0U || zero()) {
            limbs_.clear();
            return *this;
        }
        std::uint64_t carry = 0U;
        for (auto& limb : limbs_) {
            const std::uint64_t product = static_cast<std::uint64_t>(limb) * factor + carry;
            limb = static_cast<std::uint32_t>(product);
            carry = product >> 32U;
        }
        if (carry != 0U) limbs_.push_back(static_cast<std::uint32_t>(carry));
        return *this;
    }

    BigUnsigned& add_small(std::uint32_t value) {
        if (value == 0U) return *this;
        if (limbs_.empty()) limbs_.push_back(0U);
        std::uint64_t carry = value;
        for (std::size_t i = 0; carry != 0U && i < limbs_.size(); ++i) {
            const std::uint64_t sum = static_cast<std::uint64_t>(limbs_[i]) + carry;
            limbs_[i] = static_cast<std::uint32_t>(sum);
            carry = sum >> 32U;
        }
        if (carry != 0U) limbs_.push_back(static_cast<std::uint32_t>(carry));
        return *this;
    }

    [[nodiscard]] static BigUnsigned multiply(const BigUnsigned& left, const BigUnsigned& right) {
        if (left.zero() || right.zero()) return {};
        BigUnsigned result;
        result.limbs_.assign(left.limbs_.size() + right.limbs_.size(), 0U);
        for (std::size_t i = 0; i < left.limbs_.size(); ++i) {
            std::uint64_t carry = 0U;
            for (std::size_t j = 0; j < right.limbs_.size(); ++j) {
                const std::size_t k = i + j;
                const std::uint64_t product = static_cast<std::uint64_t>(left.limbs_[i]) * right.limbs_[j] +
                                              result.limbs_[k] + carry;
                result.limbs_[k] = static_cast<std::uint32_t>(product);
                carry = product >> 32U;
            }
            std::size_t k = i + right.limbs_.size();
            while (carry != 0U) {
                const std::uint64_t sum = static_cast<std::uint64_t>(result.limbs_[k]) + carry;
                result.limbs_[k] = static_cast<std::uint32_t>(sum);
                carry = sum >> 32U;
                ++k;
                if (k == result.limbs_.size() && carry != 0U) result.limbs_.push_back(0U);
            }
        }
        result.trim();
        return result;
    }

    [[nodiscard]] std::uint32_t divide_small(std::uint32_t divisor) {
        if (divisor == 0U) throw std::invalid_argument("BigUnsigned division by zero");
        std::uint64_t remainder = 0U;
        for (std::size_t offset = 0; offset < limbs_.size(); ++offset) {
            const std::size_t i = limbs_.size() - 1U - offset;
            const std::uint64_t current = (remainder << 32U) | limbs_[i];
            limbs_[i] = static_cast<std::uint32_t>(current / divisor);
            remainder = current % divisor;
        }
        trim();
        return static_cast<std::uint32_t>(remainder);
    }

    [[nodiscard]] std::uint64_t to_uint64() const {
        if (limbs_.size() > 2U) throw std::overflow_error("BigUnsigned does not fit uint64");
        std::uint64_t value = limbs_.empty() ? 0U : limbs_[0];
        if (limbs_.size() == 2U) value |= static_cast<std::uint64_t>(limbs_[1]) << 32U;
        return value;
    }

    [[nodiscard]] std::string to_decimal() const {
        if (zero()) return "0";
        BigUnsigned copy = *this;
        std::vector<std::uint32_t> chunks;
        while (!copy.zero()) chunks.push_back(copy.divide_small(1000000000U));
        std::string result = std::to_string(chunks.back());
        for (std::size_t offset = 1; offset < chunks.size(); ++offset) {
            const std::string chunk = std::to_string(chunks[chunks.size() - 1U - offset]);
            result.append(9U - chunk.size(), '0');
            result += chunk;
        }
        return result;
    }

    [[nodiscard]] static BigUnsigned from_decimal(std::string_view digits) {
        BigUnsigned result;
        for (char c : digits) {
            if (c < '0' || c > '9') throw std::invalid_argument("invalid decimal integer");
            result.multiply_small(10U);
            result.add_small(static_cast<std::uint32_t>(c - '0'));
        }
        return result;
    }

private:
    void trim() noexcept {
        while (!limbs_.empty() && limbs_.back() == 0U) limbs_.pop_back();
    }

    std::vector<std::uint32_t> limbs_;
};

inline bool operator==(const BigUnsigned& left, const BigUnsigned& right) noexcept { return left.compare(right) == 0; }
inline bool operator!=(const BigUnsigned& left, const BigUnsigned& right) noexcept { return !(left == right); }
inline bool operator<(const BigUnsigned& left, const BigUnsigned& right) noexcept { return left.compare(right) < 0; }
inline bool operator>(const BigUnsigned& left, const BigUnsigned& right) noexcept { return right < left; }
inline bool operator<=(const BigUnsigned& left, const BigUnsigned& right) noexcept { return !(right < left); }
inline bool operator>=(const BigUnsigned& left, const BigUnsigned& right) noexcept { return !(left < right); }
inline BigUnsigned operator+(BigUnsigned left, const BigUnsigned& right) { left += right; return left; }
inline BigUnsigned operator-(BigUnsigned left, const BigUnsigned& right) { left.subtract_assign(right); return left; }

class SignedBigInt {
public:
    SignedBigInt() = default;
    SignedBigInt(int value) { assign_signed(value); }
    SignedBigInt(std::int64_t value) { assign_signed(value); }
    SignedBigInt(std::uint64_t value) : sign_(value == 0U ? 0 : 1), magnitude_(value) {}

    [[nodiscard]] static SignedBigInt from_magnitude(BigUnsigned magnitude, bool negative = false) {
        SignedBigInt result;
        result.sign_ = magnitude.zero() ? 0 : (negative ? -1 : 1);
        result.magnitude_ = std::move(magnitude);
        return result;
    }

    [[nodiscard]] int sign() const noexcept { return sign_; }
    [[nodiscard]] bool zero() const noexcept { return sign_ == 0; }
    [[nodiscard]] bool odd() const noexcept { return magnitude_.odd(); }
    [[nodiscard]] std::size_t bit_length() const noexcept { return magnitude_.bit_length(); }
    [[nodiscard]] const BigUnsigned& magnitude() const noexcept { return magnitude_; }

    SignedBigInt operator-() const {
        SignedBigInt result = *this;
        result.sign_ = -result.sign_;
        return result;
    }

    SignedBigInt& operator+=(const SignedBigInt& other) {
        if (other.sign_ == 0) return *this;
        if (sign_ == 0) {
            *this = other;
            return *this;
        }
        if (sign_ == other.sign_) {
            magnitude_ += other.magnitude_;
        } else {
            const int order = magnitude_.compare(other.magnitude_);
            if (order == 0) {
                sign_ = 0;
                magnitude_ = BigUnsigned{};
            } else if (order > 0) {
                magnitude_.subtract_assign(other.magnitude_);
            } else {
                BigUnsigned magnitude = other.magnitude_;
                magnitude.subtract_assign(magnitude_);
                magnitude_ = std::move(magnitude);
                sign_ = other.sign_;
            }
        }
        normalize_sign();
        return *this;
    }

    SignedBigInt& operator-=(const SignedBigInt& other) { return *this += -other; }
    SignedBigInt& operator<<=(std::size_t bits) {
        magnitude_.shift_left(bits);
        normalize_sign();
        return *this;
    }
    SignedBigInt& operator>>=(std::size_t bits) {
        magnitude_.shift_right(bits);
        normalize_sign();
        return *this;
    }

    [[nodiscard]] std::string to_string() const {
        if (sign_ == 0) return "0";
        return (sign_ < 0 ? "-" : "") + magnitude_.to_decimal();
    }

    [[nodiscard]] std::uint64_t to_uint64() const {
        if (sign_ < 0) throw std::overflow_error("negative SignedBigInt to uint64");
        return magnitude_.to_uint64();
    }

private:
    template <typename Integer>
    void assign_signed(Integer value) {
        if (value == 0) return;
        if (value < 0) {
            sign_ = -1;
            const std::uint64_t magnitude = static_cast<std::uint64_t>(-(value + 1));
            magnitude_ = BigUnsigned(magnitude + 1U);
        } else {
            sign_ = 1;
            magnitude_ = BigUnsigned(static_cast<std::uint64_t>(value));
        }
    }
    void normalize_sign() noexcept { if (magnitude_.zero()) sign_ = 0; }

    int sign_ = 0;
    BigUnsigned magnitude_;
};

inline SignedBigInt operator+(SignedBigInt left, const SignedBigInt& right) { left += right; return left; }
inline SignedBigInt operator-(SignedBigInt left, const SignedBigInt& right) { left -= right; return left; }
inline SignedBigInt operator<<(SignedBigInt value, std::size_t bits) { value <<= bits; return value; }
inline SignedBigInt operator>>(SignedBigInt value, std::size_t bits) { value >>= bits; return value; }
inline SignedBigInt operator*(const SignedBigInt& left, const SignedBigInt& right) {
    return SignedBigInt::from_magnitude(BigUnsigned::multiply(left.magnitude(), right.magnitude()),
                                        left.sign() * right.sign() < 0);
}
inline bool operator==(const SignedBigInt& left, const SignedBigInt& right) noexcept {
    return left.sign() == right.sign() && left.magnitude() == right.magnitude();
}
inline bool operator!=(const SignedBigInt& left, const SignedBigInt& right) noexcept { return !(left == right); }
inline bool operator==(const SignedBigInt& left, int right) { return left == SignedBigInt(right); }
inline bool operator!=(const SignedBigInt& left, int right) { return !(left == right); }
inline bool operator<(const SignedBigInt& left, int right) {
    const SignedBigInt rhs(right);
    if (left.sign() != rhs.sign()) return left.sign() < rhs.sign();
    if (left.sign() == 0) return false;
    const int comparison = left.magnitude().compare(rhs.magnitude());
    return left.sign() > 0 ? comparison < 0 : comparison > 0;
}

}  // namespace aesim::core::math_assurance::detail

#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace aesim::core::terminal_visuals {

// Render a fixed-width horizontal meter with eighth-cell resolution.  The
// result occupies exactly `width` terminal columns (plus optional brackets)
// while preserving significantly more information than whole-cell or '#'
// progress bars.  This utility is header-only so simulation/research/UI
// modules can share one visual vocabulary without introducing link-layer
// dependencies between them.
[[nodiscard]] inline std::string high_resolution_bar(double fraction,
                                                      std::size_t width,
                                                      bool brackets = true) {
    static constexpr std::array<std::string_view, 9> fill{
        "", "▏", "▎", "▍", "▌", "▋", "▊", "▉", "█"
    };
    if (!std::isfinite(fraction)) fraction = 0.0;
    fraction = std::clamp(fraction, 0.0, 1.0);
    const auto eighths = static_cast<std::size_t>(std::llround(fraction * static_cast<double>(width * 8U)));
    const std::size_t full = std::min(width, eighths / 8U);
    const std::size_t partial = full < width ? eighths % 8U : 0U;

    std::string out;
    out.reserve(width * 3U + (brackets ? 2U : 0U));
    if (brackets) out.push_back('[');
    for (std::size_t column = 0; column < width; ++column) {
        if (column < full) out += fill[8];
        else if (column == full && partial != 0U) out += fill[partial];
        else out += "░";
    }
    if (brackets) out.push_back(']');
    return out;
}

[[nodiscard]] inline std::string high_resolution_bar(double value,
                                                      double minimum,
                                                      double maximum,
                                                      std::size_t width,
                                                      bool brackets = true) {
    const double span = maximum - minimum;
    const double fraction = std::abs(span) > 1.0e-15 ? (value - minimum) / span : 0.0;
    return high_resolution_bar(fraction, width, brackets);
}

// Professional dashboard instrument vocabulary.  Unlike block/shade progress
// bars this deliberately renders as one continuous horizontal instrument: a
// heavy solid line for the measured fraction and a thin solid line for the
// remaining range.  It has no ASCII brackets, tick marks, or padding glyphs
// and therefore reads as an engineering scale rather than a text progress bar.
// The return value occupies exactly `width` terminal columns.
[[nodiscard]] inline std::string solid_line_meter(double fraction,
                                                  std::size_t width) {
    if (!std::isfinite(fraction)) fraction = 0.0;
    fraction = std::clamp(fraction, 0.0, 1.0);
    if (width == 0U) return {};

    const auto active = std::min(width, static_cast<std::size_t>(
        std::llround(fraction * static_cast<double>(width))));
    std::string out;
    out.reserve(width * 3U);
    for (std::size_t i = 0; i < active; ++i) out += "━";
    for (std::size_t i = active; i < width; ++i) out += "─";
    return out;
}

[[nodiscard]] inline std::string solid_line_meter(double value,
                                                  double minimum,
                                                  double maximum,
                                                  std::size_t width) {
    const double span = maximum - minimum;
    const double fraction = std::abs(span) > 1.0e-15 ? (value - minimum) / span : 0.0;
    return solid_line_meter(fraction, width);
}


enum class MeterMarkerKind : unsigned char { target, warning, critical };

struct MeterMarker {
    double fraction = 0.0;
    MeterMarkerKind kind = MeterMarkerKind::target;
};

// Solid-line engineering instrument with overlaid target/warning/critical
// markers.  Markers occupy existing meter columns rather than widening the
// instrument, preserving stable dashboard geometry at every terminal width.
// Priority at coincident locations is critical > target > warning.
[[nodiscard]] inline std::string marked_solid_line_meter(
    double fraction, std::size_t width, const std::vector<MeterMarker>& markers) {
    if (!std::isfinite(fraction)) fraction = 0.0;
    fraction = std::clamp(fraction, 0.0, 1.0);
    if (width == 0U) return {};

    const auto active = std::min(width, static_cast<std::size_t>(
        std::llround(fraction * static_cast<double>(width))));
    std::vector<MeterMarkerKind> kinds(width, MeterMarkerKind::warning);
    std::vector<bool> occupied(width, false);
    auto priority = [](MeterMarkerKind kind) noexcept {
        switch (kind) {
            case MeterMarkerKind::critical: return 3;
            case MeterMarkerKind::target: return 2;
            case MeterMarkerKind::warning: return 1;
        }
        return 0;
    };
    for (const auto& marker : markers) {
        if (!std::isfinite(marker.fraction)) continue;
        const double clamped = std::clamp(marker.fraction, 0.0, 1.0);
        const auto column = std::min(width - 1U, static_cast<std::size_t>(
            std::llround(clamped * static_cast<double>(width - 1U))));
        if (!occupied[column] || priority(marker.kind) > priority(kinds[column])) {
            kinds[column] = marker.kind;
            occupied[column] = true;
        }
    }

    std::string out;
    out.reserve(width * 3U);
    for (std::size_t column = 0; column < width; ++column) {
        if (occupied[column]) {
            switch (kinds[column]) {
                case MeterMarkerKind::target: out += "◆"; break;
                case MeterMarkerKind::warning: out += "│"; break;
                case MeterMarkerKind::critical: out += "┃"; break;
            }
        } else {
            out += column < active ? "━" : "─";
        }
    }
    return out;
}

[[nodiscard]] inline std::string marked_solid_line_meter(
    double value, double minimum, double maximum, std::size_t width,
    const std::vector<std::pair<double, MeterMarkerKind>>& markers) {
    const double span = maximum - minimum;
    const double fraction = std::abs(span) > 1.0e-15 ? (value - minimum) / span : 0.0;
    std::vector<MeterMarker> normalized;
    normalized.reserve(markers.size());
    for (const auto& marker : markers) {
        const double marker_fraction = std::abs(span) > 1.0e-15
            ? (marker.first - minimum) / span : 0.0;
        normalized.push_back({marker_fraction, marker.second});
    }
    return marked_solid_line_meter(fraction, width, normalized);
}

[[nodiscard]] inline std::string confidence_cell(double confidence) {
    if (!std::isfinite(confidence)) return "·";
    confidence = std::clamp(confidence, 0.0, 1.0);
    if (confidence >= 0.875) return "█";
    if (confidence >= 0.625) return "▊";
    if (confidence >= 0.375) return "▌";
    if (confidence > 0.0) return "▎";
    return "·";
}

} // namespace aesim::core::terminal_visuals

#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace aesim::core {

struct CylinderGeometry {
    int cylinders = 4;
    double bore_m = 0.0825;
    double stroke_m = 0.0928;
    double rod_length_m = 0.145;
    double compression_ratio = 9.6;
};

struct CombustionOperatingPoint {
    double rpm = 850.0;
    double load = 0.0;
    double manifold_pressure_kpa = 101.325;
    double intake_temperature_c = 30.0;
    double exhaust_temperature_c = 450.0;
    double lambda = 1.0;
    double fuel_lower_heating_value_mj_kg = 42.7;
    double stoichiometric_afr = 14.7;
    double octane_aki = 93.0;
    double egr_fraction = 0.0;
    double residual_fraction = 0.05;
    double spark_deg_btdc = 12.0;
    double requested_bmep_bar = 0.0;
    CylinderGeometry geometry;
};

struct CombustionParameters {
    double crank_step_deg = 2.0;
    double burn_duration_deg = 42.0;
    double wiebe_a = 5.4;
    double wiebe_m = 2.25;
    double combustion_efficiency = 0.96;
    double wall_heat_transfer_multiplier = 1.0;
    double blowby_fraction = 0.006;
    double heat_release_scale = 1.0;
    double cylinder_flow_sigma = 0.012;
    double injector_sigma = 0.008;
    double spark_sigma_deg = 0.35;
    double compression_sigma = 0.003;
    double minimum_pressure_bar = 0.15;
    double maximum_pressure_bar = 300.0;
};

struct CrankAngleSample {
    double crank_deg_atdc = 0.0;
    double volume_cc = 0.0;
    double pressure_bar = 0.0;
    double burned_fraction = 0.0;
    double heat_release_j_deg = 0.0;
    double unburned_temperature_k = 0.0;
    double burned_temperature_k = 0.0;
};

struct CylinderCombustionResult {
    int cylinder = 1;
    double phase_deg = 0.0;
    double trapped_air_mg = 0.0;
    double fuel_mg = 0.0;
    double imep_bar = 0.0;
    double indicated_torque_nm = 0.0;
    double indicated_efficiency = 0.0;
    double peak_pressure_bar = 0.0;
    double peak_pressure_angle_deg = 0.0;
    double max_pressure_rise_bar_deg = 0.0;
    double ca10_deg_atdc = 0.0;
    double ca50_deg_atdc = 0.0;
    double ca90_deg_atdc = 0.0;
    double knock_integral = 0.0;
    double knock_index = 0.0;
    double ringing_index = 0.0;
    double exhaust_temperature_c = 0.0;
    double combustion_efficiency = 0.0;
    bool misfire = false;
    std::vector<CrankAngleSample> trace;
};

struct CylinderResolvedCombustionState {
    double mean_imep_bar = 0.0;
    double cov_imep_pct = 0.0;
    double indicated_torque_nm = 0.0;
    double peak_pressure_bar = 0.0;
    double peak_pressure_angle_deg = 0.0;
    double max_pressure_rise_bar_deg = 0.0;
    double mean_ca50_deg_atdc = 0.0;
    double mean_knock_index = 0.0;
    double maximum_knock_index = 0.0;
    double indicated_efficiency = 0.0;
    double torque_correction = 1.0;
    double cycle_energy_error_pct = 0.0;
    std::vector<CylinderCombustionResult> cylinders;
};

class CylinderResolvedCombustionModel {
public:
    CylinderResolvedCombustionModel() = default;
    explicit CylinderResolvedCombustionModel(CombustionParameters parameters);

    void set_parameters(const CombustionParameters& parameters);
    [[nodiscard]] const CombustionParameters& parameters() const noexcept;
    [[nodiscard]] const CylinderResolvedCombustionState& state() const noexcept;
    void reset();
    const CylinderResolvedCombustionState& evaluate(const CombustionOperatingPoint& input);
    [[nodiscard]] std::string report() const;
    void restore_state(const CylinderResolvedCombustionState& state);
    bool export_trace_csv(const std::string& path) const;

private:
    CombustionParameters parameters_;
    CylinderResolvedCombustionState state_;

    static double clamp(double value, double low, double high);
    static double deterministic_variation(int cylinder, double sigma, int channel);
};

}  // namespace aesim::core

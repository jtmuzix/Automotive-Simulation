#pragma once

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace aesim::core {

enum class DistributionKind { Uniform, Normal, LogNormal };

struct UncertainParameter {
    std::string name;
    DistributionKind distribution = DistributionKind::Uniform;
    double location = 0.0;
    double scale = 1.0;
    double lower = -1.0e300;
    double upper = 1.0e300;
};

struct UncertaintyMetricSummary {
    std::string metric;
    std::size_t samples = 0;
    double mean = 0.0;
    double standard_deviation = 0.0;
    double minimum = 0.0;
    double maximum = 0.0;
    double q025 = 0.0;
    double q05 = 0.0;
    double median = 0.0;
    double q95 = 0.0;
    double q975 = 0.0;
    double mean_ci95_low = 0.0;
    double mean_ci95_high = 0.0;
};

struct SensitivityIndex {
    std::string parameter;
    std::string metric;
    double pearson_correlation = 0.0;
    double standardized_regression = 0.0;
    double first_order_sobol = 0.0;
    double total_order_sobol = 0.0;
};

struct UncertaintyResult {
    std::uint64_t seed = 0;
    std::size_t samples = 0;
    std::vector<UncertaintyMetricSummary> metrics;
    std::vector<SensitivityIndex> sensitivity;
    std::vector<std::map<std::string, double>> parameter_samples;
    std::vector<std::map<std::string, double>> output_samples;
};

class UncertaintyAnalyzer {
public:
    using Evaluator = std::function<std::map<std::string, double>(const std::map<std::string, double>&)>;

    static UncertaintyResult latin_hypercube(const std::vector<UncertainParameter>& parameters,
                                             std::size_t samples,
                                             std::uint64_t seed,
                                             const Evaluator& evaluator,
                                             bool retain_samples = true);

    static std::vector<SensitivityIndex> saltelli_sobol(
        const std::vector<UncertainParameter>& parameters,
        std::size_t base_samples,
        std::uint64_t seed,
        const Evaluator& evaluator);

    static std::string render_text(const UncertaintyResult& result);
    static bool export_csv(const UncertaintyResult& result, const std::string& path);
    static bool export_json(const UncertaintyResult& result, const std::string& path);
};

}  // namespace aesim::core

#pragma once

#include <chrono>
#include <cstdint>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>

namespace aesim::core {

inline std::tm utc_calendar_time(std::time_t value) {
    std::tm utc{};
#if defined(_WIN32)
    if (gmtime_s(&utc, &value) != 0) throw std::runtime_error("UTC calendar conversion failed");
#else
    if (gmtime_r(&value, &utc) == nullptr) throw std::runtime_error("UTC calendar conversion failed");
#endif
    return utc;
}

inline std::string utc_timestamp_seconds(
    std::chrono::system_clock::time_point now = std::chrono::system_clock::now()) {
    // Explicitly floor rather than relying on implementation-defined to_time_t
    // rounding. This also gives correct timestamps for pre-epoch subsecond times.
    const auto whole_seconds = std::chrono::floor<std::chrono::seconds>(now);
    const std::time_t value = std::chrono::system_clock::to_time_t(whole_seconds);
    const std::tm utc = utc_calendar_time(value);
    std::ostringstream output;
    output << std::put_time(&utc, "%Y-%m-%dT%H:%M:%SZ");
    if (!output) throw std::runtime_error("UTC timestamp formatting failed");
    return output.str();
}

inline std::string utc_timestamp_milliseconds(
    std::chrono::system_clock::time_point now = std::chrono::system_clock::now()) {
    const auto whole_seconds = std::chrono::floor<std::chrono::seconds>(now);
    const std::time_t value = std::chrono::system_clock::to_time_t(whole_seconds);
    const std::tm utc = utc_calendar_time(value);
    const auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(now - whole_seconds).count();
    std::ostringstream output;
    output << std::put_time(&utc, "%Y-%m-%dT%H:%M:%S") << '.'
           << std::setw(3) << std::setfill('0') << millis << 'Z';
    if (!output) throw std::runtime_error("UTC timestamp formatting failed");
    return output.str();
}

inline std::uint64_t monotonic_nanoseconds() noexcept {
    const auto count = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    return count > 0 ? static_cast<std::uint64_t>(count) : 0U;
}

inline std::uint64_t monotonic_milliseconds() noexcept {
    const auto count = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    return count > 0 ? static_cast<std::uint64_t>(count) : 0U;
}

inline std::uint64_t unix_time_nanoseconds() noexcept {
    const auto count = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    return count > 0 ? static_cast<std::uint64_t>(count) : 0U;
}

inline std::uint64_t unix_time_milliseconds() noexcept {
    const auto count = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    return count > 0 ? static_cast<std::uint64_t>(count) : 0U;
}

} // namespace aesim::core

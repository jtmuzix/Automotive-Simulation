#pragma once

#include "aesim/core/cylinder_combustion.hpp"
#include "aesim/core/gas_path.hpp"
#include "aesim/core/multirate_kernel.hpp"

#include <cstdint>
#include <map>
#include <string>

namespace aesim::core {

struct ResearchCoreInput {
    double rpm = 850.0;
    double load = 0.0;
    double throttle = 0.0;
    double ambient_pressure_kpa = 101.325;
    double ambient_temperature_c = 25.0;
    double manifold_pressure_kpa = 101.325;
    double intake_temperature_c = 30.0;
    double exhaust_temperature_c = 450.0;
    double lambda = 1.0;
    double volumetric_efficiency = 0.85;
    double fuel_flow_g_s = 0.0;
    double lower_heating_value_mj_kg = 42.7;
    double stoichiometric_afr = 14.7;
    double octane_aki = 93.0;
    double egr_fraction = 0.0;
    double residual_fraction = 0.05;
    double spark_deg_btdc = 12.0;
    double requested_bmep_bar = 0.0;
    double wastegate_position = 0.75;
    double intake_vvt_deg = 0.0;
    double exhaust_vvt_deg = 0.0;
    CylinderGeometry geometry;
};

struct ResearchCoreConfiguration {
    double gas_path_period_s = 0.001;
    double combustion_period_s = 0.005;
    double diagnostics_period_s = 0.010;
    double coupling = 0.35;
    bool enabled = true;
};

struct ResearchCoreOutput {
    GasPathState gas_path;
    CylinderResolvedCombustionState combustion;
    KernelStats scheduler;
    double simulation_time_s = 0.0;
    double mass_conservation_score = 1.0;
    double energy_conservation_score = 1.0;
    std::uint64_t diagnostic_updates = 0;
};

struct ResearchCoreSnapshot {
    ResearchCoreConfiguration configuration;
    ResearchCoreInput input;
    ResearchCoreOutput output;
    KernelStats scheduler;
    GasPathSnapshot gas_path;
    CylinderResolvedCombustionState combustion;
};

class ResearchSimulationCore {
public:
    ResearchSimulationCore();

    void reset(double ambient_pressure_kpa = 101.325, double ambient_temperature_c = 25.0);
    void configure(const ResearchCoreConfiguration& configuration);
    [[nodiscard]] const ResearchCoreConfiguration& configuration() const noexcept;
    void set_combustion_parameters(const CombustionParameters& parameters);
    void set_gas_path_parameters(const GasPathParameters& parameters);
    [[nodiscard]] const CombustionParameters& combustion_parameters() const noexcept;
    [[nodiscard]] const GasPathParameters& gas_path_parameters() const noexcept;

    const ResearchCoreOutput& advance(double dt_s, const ResearchCoreInput& input);
    [[nodiscard]] const ResearchCoreOutput& output() const noexcept;
    [[nodiscard]] std::map<std::string, double> steady_state_prediction(
        const ResearchCoreInput& input, double settle_seconds = 1.5) const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] ResearchCoreSnapshot snapshot() const;
    void restore(const ResearchCoreSnapshot& snapshot);
    bool export_state_json(const std::string& path) const;
    bool export_combustion_trace_csv(const std::string& path) const;

private:
    ResearchCoreConfiguration configuration_;
    ResearchCoreInput input_;
    ResearchCoreOutput output_;
    DeterministicMultiRateKernel scheduler_;
    LumpedGasPathModel gas_path_;
    CylinderResolvedCombustionModel combustion_;
    std::size_t gas_task_ = 0;
    std::size_t combustion_task_ = 0;
    std::size_t diagnostics_task_ = 0;

    void install_tasks();
    void update_diagnostics();
};

}  // namespace aesim::core

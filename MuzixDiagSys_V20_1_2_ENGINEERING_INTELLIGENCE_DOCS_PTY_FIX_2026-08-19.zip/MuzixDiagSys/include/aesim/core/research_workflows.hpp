#pragma once

#include "aesim/core/calibration.hpp"
#include "aesim/core/research_core.hpp"
#include "aesim/core/uncertainty.hpp"
#include "aesim/core/validation.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::core {

struct ResearchWorkflowContext {
    ResearchCoreConfiguration configuration;
    CombustionParameters combustion;
    GasPathParameters gas_path;
    ResearchCoreInput base_input;
    double mechanical_efficiency = 0.84;
    double settle_seconds = 0.12;
};

struct ResearchCalibrationApplication {
    double mechanical_efficiency = 0.84;
    CombustionParameters combustion;
    GasPathParameters gas_path;
};

class ResearchWorkflowEngine {
public:
    static ResearchCoreInput input_from_record(const ResearchWorkflowContext& context,
                                               const ValidationRecord& record);
    static std::map<std::string, double> predict(const ResearchWorkflowContext& context,
                                                 const ResearchCoreInput& input);

    static ValidationResult validate(const ResearchWorkflowContext& context,
                                     const ValidationDataset& dataset,
                                     const std::vector<ValidationRequirement>& requirements = {});

    static UncertaintyResult quantify(const ResearchWorkflowContext& context,
                                      std::size_t samples,
                                      std::uint64_t seed,
                                      bool calculate_sobol = false,
                                      std::size_t sobol_base_samples = 0);

    static CalibrationFitResult calibrate(const ResearchWorkflowContext& context,
                                          const ValidationDataset& dataset,
                                          const CalibrationOptions& options = {});

    static ResearchCalibrationApplication apply_fit(const ResearchWorkflowContext& context,
                                                     const CalibrationFitResult& fit);

    static std::string context_fingerprint_material(const ResearchWorkflowContext& context);
};

}  // namespace aesim::core

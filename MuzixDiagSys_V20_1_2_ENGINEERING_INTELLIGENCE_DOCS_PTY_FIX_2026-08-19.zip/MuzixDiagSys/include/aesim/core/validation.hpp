#pragma once

#include <functional>
#include <map>
#include <string>
#include <vector>

namespace aesim::core {

struct ValidationRecord {
    std::string id;
    std::map<std::string, double> inputs;
    std::map<std::string, double> observed;
    std::map<std::string, double> sigma;
};

struct ValidationDataset {
    std::string name;
    std::string source;
    std::string version;
    std::vector<ValidationRecord> records;
};

struct MetricStatistics {
    std::string metric;
    std::size_t count = 0;
    double bias = 0.0;
    double mae = 0.0;
    double rmse = 0.0;
    double normalized_rmse = 0.0;
    double r_squared = 0.0;
    double maximum_absolute_error = 0.0;
    double residual_standard_deviation = 0.0;
    double mean_ci95_low = 0.0;
    double mean_ci95_high = 0.0;
    double residual_lag1_autocorrelation = 0.0;
    double reduced_chi_squared = 0.0;
};

struct ValidationRequirement {
    std::string metric;
    double maximum_rmse = 1.0e300;
    double maximum_absolute_bias = 1.0e300;
    double minimum_r_squared = -1.0e300;
};

struct ValidationResult {
    std::string dataset_name;
    std::string dataset_version;
    std::size_t records = 0;
    std::vector<MetricStatistics> metrics;
    std::vector<std::string> warnings;
    std::vector<std::string> failed_requirements;
    bool passed = true;
};

class ValidationFramework {
public:
    using Predictor = std::function<std::map<std::string, double>(const ValidationRecord&)>;

    static ValidationDataset load_csv(const std::string& path,
                                      std::string name = {},
                                      std::string source = {},
                                      std::string version = "1");
    static ValidationResult evaluate(const ValidationDataset& dataset,
                                     const Predictor& predictor,
                                     const std::vector<ValidationRequirement>& requirements = {});
    static std::string render_text(const ValidationResult& result);
    static bool export_markdown(const ValidationResult& result, const std::string& path);
    static bool export_json(const ValidationResult& result, const std::string& path);
};

}  // namespace aesim::core

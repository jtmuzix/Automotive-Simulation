#pragma once

#include "aesim/studio/engineering_studio.hpp"

#include <string>
#include <vector>

namespace aesim::app {

// Thin application boundary between the monolithic compatibility runtime and
// the modular engineering services. New frontends call this controller rather
// than reaching into PowertrainSimulation command parsing directly.
class EngineeringStudioRuntime {
public:
    explicit EngineeringStudioRuntime(studio::RuntimeBindings bindings = {});
    void set_bindings(studio::RuntimeBindings bindings);
    [[nodiscard]] bool handles(const std::string& line) const;
    [[nodiscard]] std::string execute(const std::string& line);
    void observe_step(double wall_time_ms, double simulated_dt_s, bool advanced);
    void record_command_event(const std::string& line, const std::string& output,
                              bool successful = true);
    [[nodiscard]] studio::EngineeringStudio& studio() noexcept;
    [[nodiscard]] const studio::EngineeringStudio& studio() const noexcept;
    [[nodiscard]] static std::vector<std::string> tokenize(const std::string& line);
private:
    studio::EngineeringStudio studio_;
};

} // namespace aesim::app

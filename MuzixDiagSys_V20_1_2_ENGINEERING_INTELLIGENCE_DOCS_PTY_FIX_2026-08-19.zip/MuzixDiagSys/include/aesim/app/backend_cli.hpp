#pragma once

#include "aesim/security/authentication.hpp"

#include <string>
#include <vector>

namespace aesim::backend_cli {

struct BackendCliDescriptor {
    std::string name;
    std::string executable;
    std::vector<std::string> aliases;
    std::vector<std::string> operations;
    std::string summary;
    bool long_running{false};
    // Literal command paths below the top-level backend root. These are metadata
    // for interactive discovery/completion; execution remains owned by the same
    // backend runner so the shell never duplicates backend behavior.
    std::vector<std::string> command_paths;
};

// Reusable entry points. Standalone executables and the authenticated interactive
// shell both call these exact functions, preventing CLI/backend behavior drift.
int run_engineering_cli(int argc, char** argv);
int run_engineering_cli_authenticated(const std::vector<std::string>& arguments,
                                      const std::string& database_path,
                                      const security::UserIdentity& identity);
int run_causal_simulation_cli(int argc, char** argv);
int run_advanced_safety_cli(int argc, char** argv);
int run_specification_discovery_cli(int argc, char** argv);
int run_standards_deployment_cli(int argc, char** argv);
int run_frontier_professional_cli(int argc, char** argv);
int run_study_worker_cli(int argc, char** argv);
int run_research_reference_generator_cli(int argc, char** argv);

// Inventory/dispatch used by the primary interactive shell. The advanced-platform
// executable is intentionally owned by aesim::advanced_cli and is added by the
// console bridge alongside this inventory.
const std::vector<BackendCliDescriptor>& standalone_backend_cli_descriptors();
const BackendCliDescriptor* find_standalone_backend_cli(const std::string& name_or_alias);
std::vector<std::string> standalone_backend_cli_names();
std::vector<std::string> standalone_backend_cli_operations(const std::string& name_or_alias);
// The primary shell supplies its already-authenticated session here so backend
// commands that require authentication reuse that exact identity instead of
// asking for a second credential source.
void configure_authenticated_shell_session(const std::string& database_path,
                                            const security::UserIdentity& identity);
void clear_authenticated_shell_session();
int run_standalone_backend_cli(const std::string& name_or_alias,
                               const std::vector<std::string>& arguments);
std::string standalone_backend_cli_help();
std::string standalone_backend_cli_help(const std::string& name_or_alias);

} // namespace aesim::backend_cli

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace sim::console::ux {

enum class DiscoveryProfile : unsigned char { essential, professional, research, complete };
enum class AccessibilityMode : unsigned char { standard, high_contrast, no_color, ascii_only, screen_reader };
enum class RefreshProfile : unsigned char { local, ssh, low_bandwidth, batch };
enum class ActionKind : unsigned char { command, workflow, dashboard, metric, setting, help, workspace, artifact };
enum class ParameterType : unsigned char { text, integer, real, boolean, enumeration, path };
enum class ResultStatus : unsigned char { success, warning, failure, cancelled, running };
enum class IssueSeverity : unsigned char { notice, warning, error, critical };

[[nodiscard]] const char* discovery_profile_name(DiscoveryProfile value) noexcept;
[[nodiscard]] std::optional<DiscoveryProfile> parse_discovery_profile(std::string value);
[[nodiscard]] const char* accessibility_mode_name(AccessibilityMode value) noexcept;
[[nodiscard]] std::optional<AccessibilityMode> parse_accessibility_mode(std::string value);
[[nodiscard]] const char* refresh_profile_name(RefreshProfile value) noexcept;
[[nodiscard]] std::optional<RefreshProfile> parse_refresh_profile(std::string value);
[[nodiscard]] const char* action_kind_name(ActionKind value) noexcept;
[[nodiscard]] const char* result_status_name(ResultStatus value) noexcept;
[[nodiscard]] const char* issue_severity_name(IssueSeverity value) noexcept;

struct RuntimeContext {
    bool loop_active = false;
    bool engine_running = false;
    bool ignition = false;
    bool starter = false;
    bool manual_transmission = false;
    bool rev_limited = false;
    bool catalyst_fault = false;
    double rpm = 0.0;
    double speed_kmh = 0.0;
    double coolant_c = 0.0;
    double oil_c = 0.0;
    double oil_pressure_kpa = 0.0;
    double fuel_flow_g_s = 0.0;
    double catalyst_temp_c = 0.0;
    std::string vehicle_name;
    std::string engine_name;
    std::string project_name;
    std::map<std::string, double> metrics;
};

struct ParameterMetadata {
    std::string name;
    std::string label;
    std::string description;
    ParameterType type = ParameterType::text;
    std::string unit;
    std::string default_value;
    bool required = false;
    std::optional<double> minimum;
    std::optional<double> maximum;
    std::vector<std::string> choices;
};

struct CommandMetadata {
    std::string path;
    std::string title;
    std::string category;
    std::string summary;
    bool mutating = false;
    std::set<DiscoveryProfile> promoted_in;
    std::vector<std::string> aliases;
    std::vector<std::string> tags;
    std::vector<ParameterMetadata> parameters;
};

struct DiagnosticMessage {
    IssueSeverity severity = IssueSeverity::notice;
    std::string code;
    std::string message;
    std::string remediation;
};

struct Property {
    std::string name;
    std::string value;
    std::string unit;
};

struct TableModel {
    std::string title;
    std::vector<std::string> columns;
    std::vector<std::vector<std::string>> rows;
};

struct ArtifactReference {
    std::string label;
    std::string path;
    std::string media_type;
};

struct CommandResult {
    ResultStatus status = ResultStatus::success;
    std::string summary;
    std::vector<DiagnosticMessage> diagnostics;
    std::vector<Property> properties;
    std::vector<TableModel> tables;
    std::vector<ArtifactReference> artifacts;
    std::vector<std::string> suggested_actions;
    std::optional<double> progress_fraction;
    std::string raw_output;

    [[nodiscard]] static CommandResult from_text(std::string command, std::string output, bool keep_running);
    [[nodiscard]] std::string render_text(bool compact = false) const;
};

struct ActionItem {
    std::string id;
    ActionKind kind = ActionKind::command;
    std::string title;
    std::string detail;
    std::string invocation;
    std::string category;
    int score = 0;
};

struct FormFieldState {
    ParameterMetadata metadata;
    std::string value;
    bool valid = true;
    std::string validation_message;
};

struct FormSession {
    std::string command_path;
    std::vector<FormFieldState> fields;
    [[nodiscard]] bool valid() const noexcept;
};

struct WorkspaceState {
    bool dashboard_visible = true;
    bool lower_pane_visible = true;
    bool status_bar_visible = true;
    bool watch_panel_visible = false;
    std::string dashboard_page = "main";
    std::vector<std::string> watch_metrics;
    std::vector<std::string> status_bar_segments;
    DiscoveryProfile discovery_profile = DiscoveryProfile::professional;
    AccessibilityMode accessibility_mode = AccessibilityMode::standard;
    RefreshProfile refresh_profile = RefreshProfile::local;
};

struct WorkspaceDefinition {
    std::string name;
    std::string description;
    WorkspaceState state;
    std::uint64_t updated_ms = 0;
};

struct WorkflowStep {
    std::string id;
    std::string title;
    std::string description;
    std::vector<std::string> commands;
    bool optional = false;
};

struct WorkflowDefinition {
    std::string id;
    std::string title;
    std::string description;
    std::vector<WorkflowStep> steps;
};

struct WorkflowSession {
    std::string workflow_id;
    std::size_t current_step = 0;
    std::set<std::size_t> completed_steps;
    std::map<std::string, std::string> values;
    bool active = false;
};

struct DashboardWidget {
    std::string metric;
    std::string display = "numeric";
    std::string label;
    std::optional<double> warning_threshold;
    std::optional<double> critical_threshold;
};

struct CustomDashboard {
    std::string name;
    std::string description;
    std::vector<DashboardWidget> widgets;
};

struct Issue {
    std::uint64_t id = 0;
    IssueSeverity severity = IssueSeverity::notice;
    std::string source;
    std::string title;
    std::string detail;
    std::string remediation;
    std::uint64_t occurrences = 1;
    bool acknowledged = false;
    bool resolved = false;
};

struct CommandPreview {
    std::string command;
    bool mutating = false;
    bool expensive = false;
    std::vector<std::string> changes;
    std::vector<std::string> preserved;
    std::vector<std::string> warnings;
    [[nodiscard]] std::string render() const;
};

struct KeyBinding {
    std::string key;
    std::string action;
    std::string context = "global";
};

struct Transaction {
    std::uint64_t id = 0;
    std::string command;
    CommandResult result;
    std::uint64_t started_ms = 0;
    std::uint64_t completed_ms = 0;
    bool collapsed = false;
};

struct StateRevision {
    std::uint64_t id = 0;
    std::string command;
    std::string before_state;
    std::string after_state;
};

struct RenderPatch {
    bool full_redraw = true;
    std::string ansi_payload;
    std::size_t changed_rows = 0;
};

class ExperienceManager {
public:
    ExperienceManager();

    void register_commands(std::vector<CommandMetadata> metadata);
    [[nodiscard]] const std::vector<CommandMetadata>& command_metadata() const noexcept;
    [[nodiscard]] const CommandMetadata* find_command(std::string_view path) const noexcept;
    [[nodiscard]] std::string metadata_report(std::string_view query = {}) const;

    void set_discovery_profile(DiscoveryProfile profile) noexcept;
    [[nodiscard]] DiscoveryProfile discovery_profile() const noexcept;
    [[nodiscard]] std::string discovery_report() const;

    void set_accessibility_mode(AccessibilityMode mode) noexcept;
    [[nodiscard]] AccessibilityMode accessibility_mode() const noexcept;
    [[nodiscard]] std::string accessibility_report() const;

    void set_refresh_profile(RefreshProfile profile) noexcept;
    [[nodiscard]] RefreshProfile refresh_profile() const noexcept;
    [[nodiscard]] int refresh_interval_ms() const noexcept;
    [[nodiscard]] std::string refresh_report() const;

    void rebuild_index(const std::vector<std::string>& dashboard_pages,
                       const std::vector<std::string>& metrics);
    [[nodiscard]] std::vector<ActionItem> search(std::string_view query, std::size_t limit = 16) const;
    [[nodiscard]] std::string search_report(std::string_view query, std::size_t limit = 16) const;

    [[nodiscard]] std::string home_screen(const RuntimeContext& context) const;
    [[nodiscard]] std::vector<ActionItem> contextual_actions(const RuntimeContext& context) const;
    [[nodiscard]] std::string contextual_action_report(const RuntimeContext& context) const;

    [[nodiscard]] bool begin_form(std::string_view command_path, std::string& error);
    [[nodiscard]] bool set_form_value(std::string_view field, std::string value, std::string& error);
    [[nodiscard]] const std::optional<FormSession>& active_form() const noexcept;
    [[nodiscard]] std::string form_report() const;
    [[nodiscard]] std::optional<std::string> generated_form_command(std::string& error) const;
    void clear_form() noexcept;

    void save_workspace(std::string name, std::string description, WorkspaceState state);
    [[nodiscard]] const WorkspaceDefinition* find_workspace(std::string_view name) const noexcept;
    [[nodiscard]] bool delete_workspace(std::string_view name);
    [[nodiscard]] std::string workspace_report() const;

    [[nodiscard]] const std::vector<WorkflowDefinition>& workflows() const noexcept;
    [[nodiscard]] bool start_workflow(std::string_view id, std::string& error);
    [[nodiscard]] bool workflow_next(std::string& error);
    [[nodiscard]] bool workflow_back(std::string& error);
    [[nodiscard]] bool workflow_complete_step(std::string& error);
    void cancel_workflow() noexcept;
    [[nodiscard]] const WorkflowSession& workflow_session() const noexcept;
    [[nodiscard]] std::string workflow_report() const;

    [[nodiscard]] bool create_dashboard(std::string name, std::string description, std::string& error);
    [[nodiscard]] bool add_dashboard_widget(std::string_view dashboard, DashboardWidget widget, std::string& error);
    [[nodiscard]] bool remove_dashboard_widget(std::string_view dashboard, std::string_view metric, std::string& error);
    [[nodiscard]] bool delete_dashboard(std::string_view name);
    [[nodiscard]] const CustomDashboard* find_dashboard(std::string_view name) const noexcept;
    [[nodiscard]] std::string dashboard_report(std::string_view name, const RuntimeContext& context) const;
    [[nodiscard]] std::string dashboard_list_report() const;
    [[nodiscard]] std::string drill_down(std::string_view metric, const RuntimeContext& context) const;

    void observe_context(const RuntimeContext& context);
    void observe_result(const std::string& command, const CommandResult& result);
    [[nodiscard]] std::string issue_report(bool include_resolved = false) const;
    [[nodiscard]] std::size_t active_issue_count() const noexcept;
    [[nodiscard]] std::size_t unacknowledged_issue_count() const noexcept;
    [[nodiscard]] bool acknowledge_issue(std::uint64_t id);
    [[nodiscard]] bool resolve_issue(std::uint64_t id);

    [[nodiscard]] CommandPreview preview(std::string_view command) const;

    void begin_state_change(std::string command, std::string before_state);
    void complete_state_change(std::string after_state, bool success);
    [[nodiscard]] std::optional<std::string> undo_state(std::string& description);
    [[nodiscard]] std::optional<std::string> redo_state(std::string& description);
    [[nodiscard]] bool create_state_branch(std::string name, std::string state, std::string& error);
    [[nodiscard]] std::optional<std::string> load_state_branch(std::string_view name, std::string& error) const;
    [[nodiscard]] std::string state_history_report() const;

    std::uint64_t record_transaction(std::string command, CommandResult result,
                                     std::uint64_t started_ms, std::uint64_t completed_ms);
    [[nodiscard]] bool toggle_transaction(std::uint64_t id);
    [[nodiscard]] std::string transaction_report(std::size_t limit = 20) const;

    [[nodiscard]] std::string canonical_term(std::string value) const;
    [[nodiscard]] std::string terminology_report() const;

    [[nodiscard]] bool set_keybinding(std::string key, std::string action,
                                      std::string context, std::string& error);
    [[nodiscard]] bool remove_keybinding(std::string_view key, std::string_view context);
    void apply_keybinding_profile(std::string_view profile);
    [[nodiscard]] std::optional<std::string> action_for_key(std::string_view key,
                                                            std::string_view context) const;
    [[nodiscard]] const std::vector<KeyBinding>& keybindings() const noexcept { return keybindings_; }
    [[nodiscard]] bool replace_keybindings(std::vector<KeyBinding> bindings, std::string& error);
    [[nodiscard]] std::string keybinding_report() const;

    [[nodiscard]] std::string contextual_help(std::string_view topic,
                                              const RuntimeContext& context) const;

    [[nodiscard]] RenderPatch incremental_patch(const std::vector<std::string>& rows,
                                                int terminal_rows, int terminal_cols,
                                                int cursor_row, int cursor_col);
    void invalidate_render_cache() noexcept;

    [[nodiscard]] bool save(const std::string& path, std::string& error) const;
    [[nodiscard]] bool load(const std::string& path, std::string& error);

private:
    std::vector<CommandMetadata> commands_;
    struct CommandLookupEntry {
        std::uint32_t command_index = 0;
        std::uint32_t alias_index = 0;
    };
    // Canonical paths and aliases indexed by command/alias position and sorted
    // case-insensitively for allocation-free binary lookup. Compact 32-bit
    // indices avoid self-referential pointers/string_views, preserve ordinary
    // object copy/move semantics, and halve cache storage versus size_t pairs.
    // alias_index == UINT32_MAX denotes the canonical path.
    std::vector<CommandLookupEntry> command_lookup_;
    std::vector<ActionItem> index_;
    // Factory dashboard/metric inputs are owned by the console front-end, but
    // the experience manager mutates workspaces, discovery profile and custom
    // dashboards internally.  Retaining the most recent external inputs lets
    // those mutations refresh the index without accidentally dropping factory
    // entries and lets repeated palette queries become a no-op rebuild.
    std::vector<std::string> indexed_dashboard_pages_;
    std::vector<std::string> indexed_metrics_;
    bool index_initialized_ = false;
    bool index_dirty_ = true;
    DiscoveryProfile discovery_profile_ = DiscoveryProfile::professional;
    AccessibilityMode accessibility_mode_ = AccessibilityMode::standard;
    RefreshProfile refresh_profile_ = RefreshProfile::local;
    std::optional<FormSession> form_;
    std::map<std::string, WorkspaceDefinition> workspaces_;
    std::vector<WorkflowDefinition> workflows_;
    WorkflowSession workflow_session_;
    std::map<std::string, CustomDashboard> dashboards_;
    std::vector<Issue> issues_;
    std::vector<Transaction> transactions_;
    std::vector<StateRevision> state_history_;
    std::size_t state_cursor_ = 0;
    std::optional<StateRevision> pending_state_;
    std::map<std::string, std::string> state_branches_;
    std::map<std::string, std::string> terminology_;
    std::vector<KeyBinding> keybindings_;
    std::vector<std::string> previous_rows_;
    int previous_terminal_rows_ = 0;
    int previous_terminal_cols_ = 0;
    std::uint64_t next_issue_id_ = 1;
    std::uint64_t next_transaction_id_ = 1;
    std::uint64_t next_revision_id_ = 1;

    void install_defaults();
    void rebuild_command_lookup();
    void refresh_index();
    void validate_form();
    void upsert_issue(IssueSeverity severity, std::string source, std::string title,
                      std::string detail, std::string remediation);
};

[[nodiscard]] std::vector<CommandMetadata> default_command_metadata();

} // namespace sim::console::ux

#pragma once

#include <cstddef>
#include <deque>
#include <functional>
#include <optional>
#include <string>
#include <string_view>

namespace sim::console::terminal_input {

// Buffered terminal bytes with amortized O(1) ordinary reads and explicit
// Ctrl-C preemption.  Interrupt discovery is performed when bytes are appended
// rather than rescanning the entire pending buffer on every decoded byte.
class InputQueue {
public:
    void append(std::string_view bytes);
    void replay_front(char byte);
    [[nodiscard]] bool take(char& value);
    [[nodiscard]] bool empty() const noexcept { return pending_.empty(); }
    [[nodiscard]] std::size_t size() const noexcept { return pending_.size(); }
    void clear() noexcept;

private:
    void refresh_interrupt_index();

    std::deque<char> pending_;
    std::optional<std::size_t> first_interrupt_index_;
};

// Return convention matches poll/read helpers in the console frontend:
//   1 => a byte was produced, 0 => timed out, -1 => input closed/error.
using TimedByteReader = std::function<int(char&, int)>;

[[nodiscard]] bool is_escape_recovery_byte(char value) noexcept;
[[nodiscard]] std::string read_escape_sequence(char second,
                                               const TimedByteReader& read_byte_timeout,
                                               InputQueue& input);
[[nodiscard]] std::string read_utf8_input(unsigned char first,
                                          const TimedByteReader& read_byte_timeout,
                                          InputQueue& input);
[[nodiscard]] bool is_function_key(std::string_view sequence, int number);
[[nodiscard]] std::optional<std::string> modified_key_name(std::string_view sequence);

} // namespace sim::console::terminal_input

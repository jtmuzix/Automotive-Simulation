#pragma once

namespace aesim::app {
int run_console_application(int argc, char** argv);
}

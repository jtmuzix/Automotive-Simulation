#pragma once

#include "aesim/app/global_ui_architecture.hpp"
#include "aesim/app/terminal_workstation_platform.hpp"
#include "aesim/studio/engineering_studio.hpp"

#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <functional>
#include <map>
#include <limits>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

namespace sim::console::engineeringui {

struct TerminalCapabilities {
    bool tty=false, ssh=false, tmux=false, unicode=false, truecolor=false, color256=false;
    bool sgr_mouse=false, focus_reporting=false, bracketed_paste=false, synchronized_output=false;
    bool braille=false, sixel=false, kitty_graphics=false, osc8_hyperlinks=false, osc52_clipboard=false, csi_u=false;
    int rows=0, columns=0;
    std::string term, terminal_program, source;
    [[nodiscard]] std::string report() const;
};
class TerminalCapabilityNegotiator {
public:
    [[nodiscard]] static TerminalCapabilities detect(int rows=0, int columns=0);
};

enum class MouseButton : unsigned char { none,left,middle,right,wheel_up,wheel_down };
enum class MouseAction : unsigned char { press,release,drag,motion,scroll };
struct MouseEvent { MouseButton button=MouseButton::none; MouseAction action=MouseAction::motion; int x=0,y=0; bool shift=false,alt=false,ctrl=false; };
[[nodiscard]] std::optional<MouseEvent> parse_sgr_mouse(std::string_view sequence);

struct HitRegion {
    std::string id, role;
    int left=1, top=1, right=1, bottom=1, z=0;
    std::string object_uri, primary_action, secondary_action, drag_action, scroll_action;
    [[nodiscard]] bool contains(int x,int y) const noexcept;
};
class HitTestMap {
public:
    void clear();
    void add(HitRegion region);
    [[nodiscard]] std::optional<HitRegion> hit(int x,int y) const;
    [[nodiscard]] std::vector<HitRegion> regions() const;
private: std::vector<HitRegion> regions_;
};

class DashboardDesigner {
public:
    bool create(std::string id,std::string title,int columns,std::string& error);
    bool import_layout(const globalui::DashboardLayout& layout,std::string& error);
    bool add_widget(std::string_view dashboard,globalui::RichWidget widget,globalui::LayoutCell cell,std::string& error);
    bool remove_widget(std::string_view dashboard,std::string_view widget,std::string& error);
    bool clone_widget(std::string_view dashboard,std::string_view widget,std::string new_id,std::string& error);
    bool move(std::string_view dashboard,std::string_view widget,int row,int col,std::string& error);
    bool resize(std::string_view dashboard,std::string_view widget,int width,int height,std::string& error);
    bool set_widget(std::string_view dashboard,std::string_view widget,std::string_view key,std::string value,std::string& error);
    bool undo(std::string_view dashboard,std::string& error);
    bool redo(std::string_view dashboard,std::string& error);
    [[nodiscard]] std::optional<globalui::DashboardLayout> layout(std::string_view dashboard) const;
    [[nodiscard]] std::vector<std::string> list() const;
    [[nodiscard]] std::string render(std::string_view dashboard,int terminal_columns=120) const;
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
private:
    struct State { globalui::DashboardLayout layout; std::vector<globalui::DashboardLayout> undo,redo; };
    std::map<std::string,State> dashboards_;
    static bool validate(const globalui::DashboardLayout& layout,std::string& error);
    static bool overlaps(const globalui::LayoutCell& a,const globalui::LayoutCell& b) noexcept;
    bool mutate(std::string_view dashboard,const std::function<bool(globalui::DashboardLayout&,std::string&)>& fn,std::string& error);
};

struct TimeEvent { double time_s=0; std::string kind,label,object_uri; };
class SynchronizedTimeCursor {
public:
    void update_live(double time_s);
    void set(double time_s);
    void set_window(double seconds);
    void set_speed(double speed);
    void play(); void pause(); void follow_live(bool enabled);
    void add_event(TimeEvent event); void bookmark(std::string label);
    bool next_event(); bool previous_event(); bool seek_bookmark(std::string_view label);
    [[nodiscard]] std::vector<TimeEvent> events(double begin_s=-std::numeric_limits<double>::infinity(),double end_s=std::numeric_limits<double>::infinity()) const;
    [[nodiscard]] std::map<std::string,double> bookmarks() const { return bookmarks_; }
    [[nodiscard]] std::string timeline(std::size_t width=100,std::size_t maximum_events=80) const;
    [[nodiscard]] std::string time_travel_panel(std::size_t width=100,std::size_t maximum_events=12) const;
    [[nodiscard]] double cursor_s() const noexcept { return cursor_s_; }
    [[nodiscard]] double live_s() const noexcept { return live_s_; }
    [[nodiscard]] double window_s() const noexcept { return window_s_; }
    [[nodiscard]] std::string report() const;
private:
    double cursor_s_=0,live_s_=0,window_s_=10,speed_=1;
    bool playing_=false,follow_live_=true;
    std::uint64_t last_tick_ms_=0;
    std::vector<TimeEvent> events_;
    std::map<std::string,double> bookmarks_;
};

struct SignalSample { double time_s=0,value=0; };
struct TelemetrySignalMetadata {
    std::string name,label,unit,description,subsystem,source;
    std::set<std::string> tags,consumers;
    std::optional<double> validated_minimum,validated_maximum;
    std::optional<double> target,warning_low,warning_high,critical_low,critical_high;
    aesim::studio::SignalKind kind=aesim::studio::SignalKind::Calculated;
    aesim::studio::SignalQuality quality=aesim::studio::SignalQuality::Good;
    std::vector<std::string> provenance;
    double nominal_sample_rate_hz=0.0;
    double stale_after_s=0.0;
};
struct SignalStatistics { std::size_t count=0; double min=0,max=0,mean=0,rms=0,stddev=0; };
struct SignalTrend {
    std::size_t samples=0;
    double begin_s=0,end_s=0,begin_value=0,end_value=0,delta=0,slope_per_s=0;
    [[nodiscard]] std::string direction(double deadband=1e-12) const;
};
struct SpectrumBin { double frequency_hz=0,magnitude=0; };
struct TelemetryStorageStatus { std::size_t signals=0,resident_samples=0,spilled_samples=0; std::uintmax_t disk_bytes=0; std::size_t resident_limit_per_signal=0,index_stride=0; std::string storage_root; [[nodiscard]] std::string report() const; };
class TelemetryWorkbench {
public:
    TelemetryWorkbench();
    ~TelemetryWorkbench();
    TelemetryWorkbench(const TelemetryWorkbench&)=delete;
    TelemetryWorkbench& operator=(const TelemetryWorkbench&)=delete;
    TelemetryWorkbench(TelemetryWorkbench&&)=delete;
    TelemetryWorkbench& operator=(TelemetryWorkbench&&)=delete;
    void define_signal(std::string name,std::string unit={});
    bool set_signal_metadata(TelemetrySignalMetadata metadata,std::string& error);
    [[nodiscard]] std::optional<TelemetrySignalMetadata> signal_metadata(std::string_view name) const;
    [[nodiscard]] std::vector<TelemetrySignalMetadata> search_signals(std::string_view query={},std::size_t limit=100) const;
    [[nodiscard]] std::string signal_report(std::string_view name) const;
    void append(std::string_view name,double time_s,double value);
    void clear(std::string_view name={});
    void configure_out_of_core(std::filesystem::path root,std::size_t resident_samples_per_signal=32768,std::size_t index_stride=65536,bool preserve_files=false);
    [[nodiscard]] std::vector<std::string> signals() const;
    [[nodiscard]] SignalStatistics statistics(std::string_view name,double begin_s,double end_s) const;
    [[nodiscard]] SignalTrend trend(std::string_view name,double end_s,double window_s=1.0) const;
    [[nodiscard]] std::string metric_inspector(std::string_view name,double cursor_s,double trend_window_s=1.0) const;
    [[nodiscard]] std::vector<SpectrumBin> fft(std::string_view name,double begin_s,double end_s,std::size_t max_bins=256) const;
    [[nodiscard]] std::vector<std::pair<double,std::size_t>> histogram(std::string_view name,double begin_s,double end_s,std::size_t bins) const;
    [[nodiscard]] std::optional<double> correlation(std::string_view a,std::string_view b,double begin_s,double end_s) const;
    [[nodiscard]] std::optional<double> interpolate(std::string_view name,double time_s) const;
    [[nodiscard]] std::vector<SignalSample> samples(std::string_view name,double begin_s=-std::numeric_limits<double>::infinity(),double end_s=std::numeric_limits<double>::infinity()) const;
    [[nodiscard]] std::vector<SignalSample> lod_samples(std::string_view name,double begin_s,double end_s,std::size_t pixel_width) const;
    [[nodiscard]] TelemetryStorageStatus storage_status() const;
    [[nodiscard]] std::string signal_unit(std::string_view name) const;
    [[nodiscard]] std::string render(double cursor_s,double window_s,std::size_t width=90) const;
    [[nodiscard]] std::string sparkline(std::string_view name,double begin_s,double end_s,std::size_t width=48,bool include_statistics=true) const;
private:
    struct IndexEntry { double time_s=0; std::uint64_t sample_index=0; };
    struct Signal { TelemetrySignalMetadata metadata; std::string unit; std::deque<SignalSample> recent; std::filesystem::path spill_path; std::uint64_t spilled_count=0; std::vector<IndexEntry> index; bool monotonic=true; double last_time=-std::numeric_limits<double>::infinity(); };
    std::map<std::string,Signal> signals_;
    std::filesystem::path storage_root_;
    std::size_t resident_limit_=32768,index_stride_=65536;
    bool preserve_files_=false;
    bool owns_storage_root_=true;
    void spill_if_needed(std::string_view name,Signal& signal);
    [[nodiscard]] std::vector<SignalSample> spilled_samples(const Signal& signal,double begin_s,double end_s,std::size_t maximum=0,bool keep_last=false) const;
};

struct DashboardReferenceValue {
    std::string signal;
    double live=std::numeric_limits<double>::quiet_NaN();
    std::optional<double> frozen,baseline;
    [[nodiscard]] std::optional<double> freeze_delta() const;
    [[nodiscard]] std::optional<double> baseline_delta() const;
};
struct StatisticalEnvelopeSample {
    std::string signal,unit;
    double time_s=0.0,live=std::numeric_limits<double>::quiet_NaN();
    double low=std::numeric_limits<double>::quiet_NaN(),median=std::numeric_limits<double>::quiet_NaN(),high=std::numeric_limits<double>::quiet_NaN();
    std::size_t runs=0;
    [[nodiscard]] bool outside() const noexcept { return std::isfinite(live)&&std::isfinite(low)&&std::isfinite(high)&&(live<low||live>high); }
};

struct SemanticHighlightExplanation {
    std::string signal,severity,reason,detail;
    double value=std::numeric_limits<double>::quiet_NaN();
    [[nodiscard]] std::string report() const;
};
class SemanticHighlightExplainer {
public:
    [[nodiscard]] SemanticHighlightExplanation explain(std::string_view signal,double value,double time_s,const TelemetryWorkbench& telemetry) const;
};

struct MetricChangeFinding {
    std::string signal,unit;
    double before=0.0,after=0.0,delta=0.0,relative=0.0,score=0.0;
};
class WhatChangedInvestigator {
public:
    [[nodiscard]] std::vector<MetricChangeFinding> compare(const TelemetryWorkbench& telemetry,double before_s,double after_s,std::size_t limit=20,double absolute_floor=1e-12) const;
    [[nodiscard]] std::string report(const TelemetryWorkbench& telemetry,double before_s,double after_s,std::size_t limit=20) const;
};

class MetricProvenanceGraphProjector {
public:
    [[nodiscard]] std::string render(std::string_view signal,const TelemetryWorkbench& telemetry,std::size_t width=100) const;
    [[nodiscard]] std::string dot(std::string_view signal,const TelemetryWorkbench& telemetry) const;
};

struct HysteresisControlView {
    std::string id,signal,label;
    double engage=0.0,release=0.0;
    bool high_side=true,active=false;
    std::deque<std::pair<double,bool>> transitions;
};
class ControlLoopHysteresisVisualizer {
public:
    bool upsert(HysteresisControlView view,std::string& error);
    bool erase(std::string_view id);
    void clear();
    void evaluate(double time_s,const TelemetryWorkbench& telemetry);
    [[nodiscard]] std::string report(std::string_view id={},double time_s=std::numeric_limits<double>::quiet_NaN(),const TelemetryWorkbench* telemetry=nullptr) const;
private:
    std::map<std::string,HysteresisControlView> views_;
};

class DashboardReferenceOverlay {
public:
    void update_live(double time_s,const std::map<std::string,double>& signals);
    bool freeze(std::string label={});
    void thaw();
    bool capture_baseline(std::string label={});
    bool set_baseline(std::string label,double time_s,std::map<std::string,double> values,std::string& error);
    void clear_baseline();
    [[nodiscard]] bool frozen() const noexcept { return frozen_; }
    [[nodiscard]] double live_time_s() const noexcept { return live_time_s_; }
    [[nodiscard]] double freeze_time_s() const noexcept { return freeze_time_s_; }
    [[nodiscard]] double baseline_time_s() const noexcept { return baseline_time_s_; }
    [[nodiscard]] std::string freeze_label() const { return freeze_label_; }
    [[nodiscard]] std::string baseline_label() const { return baseline_label_; }
    [[nodiscard]] std::optional<DashboardReferenceValue> value(std::string_view signal) const;
    [[nodiscard]] std::map<std::string,double> displayed_values() const;
    [[nodiscard]] std::string report(std::size_t limit=16) const;
private:
    double live_time_s_=0.0,freeze_time_s_=0.0,baseline_time_s_=0.0;
    bool frozen_=false;
    std::string freeze_label_,baseline_label_;
    std::map<std::string,double> live_,frozen_values_,baseline_values_;
};

struct TransientSignalFinding {
    std::string signal,unit;
    std::size_t pre_samples=0,post_samples=0;
    double pre_mean=0,post_mean=0,delta=0,pre_min=0,pre_max=0,post_min=0,post_max=0,score=0;
};
struct TransientInvestigationResult {
    double event_time_s=0,pre_window_s=0,post_window_s=0;
    std::vector<TransientSignalFinding> findings;
};
class TransientInvestigationLens {
public:
    [[nodiscard]] TransientInvestigationResult analyze(double event_time_s,double pre_window_s,double post_window_s,
        const TelemetryWorkbench& telemetry,const std::vector<std::string>& preferred_signals={},std::size_t maximum_signals=12) const;
    [[nodiscard]] std::string report(const TransientInvestigationResult& result) const;
};

enum class TraceProtocol : unsigned char { can,can_fd,can_xl,lin,flexray,ethernet,someip,doip,uds,xcp,dds,ros2,v2x,opcua,custom };
struct TraceFrame {
    std::uint64_t sequence=0; double time_s=0; TraceProtocol protocol=TraceProtocol::custom;
    std::string bus,identifier; std::vector<std::uint8_t> payload; std::map<std::string,std::string> fields; std::string summary;
};
class ProtocolTraceAnalyzer {
public:
    std::uint64_t append(TraceFrame frame); void clear();
    [[nodiscard]] std::vector<TraceFrame> query(std::string_view expression,std::size_t limit=200) const;
    [[nodiscard]] std::string inspect(std::uint64_t sequence) const;
    [[nodiscard]] std::string render(std::string_view expression,std::size_t limit=30) const;
    [[nodiscard]] static std::optional<TraceProtocol> protocol(std::string_view name);
    [[nodiscard]] static std::string protocol_name(TraceProtocol protocol);
private:
    std::deque<TraceFrame> frames_; std::uint64_t next_sequence_=1;
    static void decode(TraceFrame& frame); static bool matches(const TraceFrame& frame,std::string_view expression);
};

class ConfigurationDiffViewer {
public:
    void store(std::string name,globalui::PropertyBag values);
    [[nodiscard]] std::string diff(std::string_view left,std::string_view right,bool changed_only=false) const;
    [[nodiscard]] globalui::MergeResult merge(std::string_view base,std::string_view ours,std::string_view theirs) const;
    bool accept(std::string_view target,std::string_view source,std::string_view field,std::string& error);
    [[nodiscard]] std::vector<std::string> list() const;
private: std::map<std::string,globalui::PropertyBag> configs_;
};

class WorkflowGraphEditor {
public:
    bool create(std::string id,std::string title,std::string& error);
    bool add_node(std::string_view graph,globalui::WorkflowNode node,std::string& error);
    bool remove_node(std::string_view graph,std::string_view node,std::string& error);
    bool connect(std::string_view graph,std::string from,std::string to,std::string condition,std::string& error);
    bool disconnect(std::string_view graph,std::string_view from,std::string_view to,std::string& error);
    bool set_start(std::string_view graph,std::string node,std::string& error);
    [[nodiscard]] std::optional<globalui::WorkflowGraph> graph(std::string_view id) const;
    [[nodiscard]] std::vector<std::string> list() const;
    [[nodiscard]] std::string render(std::string_view id) const;
    [[nodiscard]] std::string graph_json(std::string_view id) const;
private: std::map<std::string,globalui::WorkflowGraph> graphs_;
};

struct SolverSample {
    double time_s=0,dt_s=std::numeric_limits<double>::quiet_NaN(),residual=std::numeric_limits<double>::quiet_NaN();
    double condition=std::numeric_limits<double>::quiet_NaN(),local_error=std::numeric_limits<double>::quiet_NaN(),conservation_error=std::numeric_limits<double>::quiet_NaN();
    int nonlinear_iterations=-1,linear_iterations=-1; bool accepted=true;
};
class SolverConvergenceConsole {
public:
    void append(SolverSample sample); void clear();
    [[nodiscard]] std::optional<SolverSample> latest() const;
    [[nodiscard]] std::optional<SolverSample> worst_residual() const;
    [[nodiscard]] std::string report(std::size_t history=20) const;
    [[nodiscard]] std::string report_range(double begin_s,double end_s,std::size_t history=20) const;
private: std::deque<SolverSample> samples_;
};

struct RuntimeProfileSample {
    std::uint64_t timestamp_ms=0; double process_cpu_percent=0,system_cpu_percent=0;
    std::uint64_t rss_bytes=0,read_bytes=0,write_bytes=0; int mpi_rank=-1,mpi_size=1;
    std::string gpu_name; double gpu_utilization_percent=std::numeric_limits<double>::quiet_NaN();
    std::uint64_t gpu_memory_used_bytes=0,gpu_memory_total_bytes=0;
};
class RuntimeProfiler {
public:
    RuntimeProfileSample sample(); void clear();
    [[nodiscard]] std::vector<RuntimeProfileSample> history() const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] std::string dashboard(std::size_t width=80) const;
private:
    mutable std::mutex mutex_; std::deque<RuntimeProfileSample> samples_;
    std::uint64_t previous_process_ticks_=0,previous_system_ticks_=0,previous_idle_ticks_=0,previous_wall_ms_=0;
};

struct ExperimentRun {
    ExperimentRun() = default;
    ExperimentRun(std::string id_value,std::string state_value,
                  std::map<std::string,double> parameter_values={},
                  std::map<std::string,double> objective_values={},
                  std::map<std::string,std::string> tag_values={})
        : id(std::move(id_value)), state(std::move(state_value)), parameters(std::move(parameter_values)),
          objectives(std::move(objective_values)), tags(std::move(tag_values)) {}
    std::string id,state;
    std::map<std::string,double> parameters,objectives;
    std::map<std::string,std::string> tags;
    std::string parent_id,scenario,vehicle,configuration_hash,build_id,host,notes;
    std::uint64_t random_seed=0,started_ms=0,completed_ms=0;
    std::vector<std::string> artifacts;
};
class ExperimentMatrix {
public:
    bool upsert(ExperimentRun run,std::string& error); bool erase(std::string_view id);
    bool set_state(std::string_view id,std::string state,std::string& error);
    bool annotate(std::string_view id,std::string notes,std::string& error);
    bool attach_artifact(std::string_view id,std::string artifact,std::string& error);
    [[nodiscard]] std::optional<ExperimentRun> get(std::string_view id) const;
    [[nodiscard]] std::vector<ExperimentRun> query(std::string_view expression={}) const;
    [[nodiscard]] std::vector<std::string> pareto(const std::vector<std::string>& objectives,bool minimize=true) const;
    [[nodiscard]] std::string render(std::string_view expression={}) const;
    [[nodiscard]] std::string inspect(std::string_view id) const;
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
private: std::map<std::string,ExperimentRun> runs_;
};

struct ArtifactRecord { std::string path,sha256; std::uint64_t size=0,modified_ms=0; bool signed_artifact=false; };
class ArtifactEvidenceBrowser {
public:
    std::size_t index(const std::filesystem::path& root,std::string& error);
    [[nodiscard]] std::vector<ArtifactRecord> query(std::string_view expression={}) const;
    [[nodiscard]] std::optional<ArtifactRecord> inspect(std::string_view path) const;
    [[nodiscard]] std::string tree(std::size_t limit=100) const;
private: std::map<std::string,ArtifactRecord> artifacts_;
};

struct RegressionCase { std::string name,state; double seconds=0; std::string detail; };
class RegressionTriageDashboard {
public:
    bool load_ctest_log(const std::filesystem::path& path,std::string& error);
    void set_cases(std::vector<RegressionCase> cases);
    [[nodiscard]] std::vector<RegressionCase> cases() const { return cases_; }
    [[nodiscard]] std::vector<RegressionCase> failures() const;
    [[nodiscard]] std::string report() const;
private: std::vector<RegressionCase> cases_;
};


class EngineeringFlightRecorder;
enum class MissionHealth : unsigned char { nominal, degraded, critical, offline };
struct MissionSubsystem {
    std::string id,label,detail,object_uri;
    MissionHealth health=MissionHealth::nominal;
    std::uint64_t updated_ms=0;
};
struct MissionAlert {
    std::uint64_t id=0,first_ms=0,last_ms=0,count=1;
    std::string severity,title,detail,object_uri;
    bool acknowledged=false;
};
class EngineeringMissionControl {
public:
    void update_runtime(double simulation_time_s,const std::map<std::string,double>& metrics,const RuntimeProfileSample& profile);
    bool set_subsystem(MissionSubsystem subsystem,std::string& error);
    std::uint64_t raise_alert(std::string severity,std::string title,std::string detail={},std::string object_uri={});
    bool acknowledge(std::uint64_t id,std::string& error);
    bool clear_alert(std::uint64_t id);
    [[nodiscard]] std::vector<MissionSubsystem> subsystems() const;
    [[nodiscard]] std::vector<MissionAlert> alerts(bool include_acknowledged=true) const;
    [[nodiscard]] std::string report(const globalui::JobManager& jobs,const RegressionTriageDashboard& regressions) const;
    [[nodiscard]] static std::optional<MissionHealth> parse_health(std::string_view value);
    [[nodiscard]] static std::string health_name(MissionHealth value);
private:
    mutable std::mutex mutex_;
    std::map<std::string,MissionSubsystem> subsystems_;
    std::map<std::uint64_t,MissionAlert> alerts_;
    std::uint64_t next_alert_id_=1;
    double simulation_time_s_=0.0;
    std::map<std::string,double> runtime_metrics_;
    RuntimeProfileSample runtime_profile_{};
};


struct SequenceOfEventsRecord {
    std::uint64_t sequence=0,alert_id=0;
    double simulation_time_s=0.0;
    std::string severity,title,detail,object_uri;
    bool first_out=false,acknowledged=false;
};
class SequenceOfEventsAnalyzer {
public:
    void observe(double simulation_time_s,const std::vector<MissionAlert>& alerts);
    void record(double simulation_time_s,std::string severity,std::string title,std::string detail={},std::string object_uri={});
    void clear();
    void set_quiet_gap(double seconds);
    [[nodiscard]] std::vector<SequenceOfEventsRecord> events(std::size_t limit=100) const;
    [[nodiscard]] std::optional<SequenceOfEventsRecord> first_out() const;
    [[nodiscard]] std::string report(std::size_t limit=40) const;
private:
    std::deque<SequenceOfEventsRecord> events_;
    std::set<std::uint64_t> seen_alerts_;
    std::uint64_t next_sequence_=1;
    double last_event_time_s_=-std::numeric_limits<double>::infinity(),quiet_gap_s_=2.0;
    bool burst_open_=false;
};

class ProfessionalDiagnosticCenter {
public:
    [[nodiscard]] std::string report(const EngineeringMissionControl& mission,const RegressionTriageDashboard& regressions,const SolverConvergenceConsole& solver,const EngineeringFlightRecorder& recorder,std::size_t limit=40) const;
    [[nodiscard]] std::string explain(std::string_view reference,const EngineeringMissionControl& mission,const EngineeringFlightRecorder& recorder) const;
};
struct ComparisonRun {
    std::string id,label,state;
    std::map<std::string,std::string> tags,units;
    std::map<std::string,std::vector<SignalSample>> channels;
};
struct RunComparisonStatistic {
    std::string run_id,channel,axis;
    std::size_t samples=0;
    double mean_baseline=std::numeric_limits<double>::quiet_NaN();
    double mean_candidate=std::numeric_limits<double>::quiet_NaN();
    double bias=std::numeric_limits<double>::quiet_NaN();
    double mae=std::numeric_limits<double>::quiet_NaN();
    double rmse=std::numeric_limits<double>::quiet_NaN();
    double max_abs=std::numeric_limits<double>::quiet_NaN();
    double correlation=std::numeric_limits<double>::quiet_NaN();
};
class NWayRunComparisonWorkbench {
public:
    bool upsert(ComparisonRun run,std::string& error);
    bool erase(std::string_view id);
    void clear();
    bool set_baseline(std::string_view id,std::string& error);
    [[nodiscard]] std::string baseline() const;
    [[nodiscard]] std::vector<ComparisonRun> runs() const;
    [[nodiscard]] std::size_t run_count() const noexcept { return runs_.size(); }
    [[nodiscard]] std::vector<double> values_at(std::string_view channel,double time_s) const;
    [[nodiscard]] std::string channel_unit(std::string_view channel) const;
    [[nodiscard]] std::optional<ComparisonRun> get(std::string_view id) const;
    bool load_csv(std::string id,const std::filesystem::path& path,std::string time_column,std::string& error);
    [[nodiscard]] std::vector<RunComparisonStatistic> compare(std::string_view channel,std::string_view axis="time",std::size_t max_points=5000) const;
    [[nodiscard]] std::string report(std::string_view channel,std::string_view axis="time") const;
    [[nodiscard]] std::string envelope(std::string_view channel,std::string_view axis="time",std::size_t points=40) const;
    [[nodiscard]] std::string list_report() const;
    [[nodiscard]] std::string track_lap_json(std::size_t max_points=2400) const;
    [[nodiscard]] std::string track_map(std::size_t width=76,std::size_t height=22,std::size_t max_points=2400) const;
    [[nodiscard]] std::string cockpit(double time_s,std::size_t maximum_channels=24) const;
private:
    std::map<std::string,ComparisonRun> runs_;
    std::string baseline_;
};

struct CausalDifferenceDependency {
    std::string source,target;
    double maximum_lag_s=0.0;
    double confidence=1.0;
};
struct CausalDivergence {
    std::string signal;
    double first_time_s=std::numeric_limits<double>::quiet_NaN();
    double maximum_absolute_difference=0.0;
    double root_mean_square_difference=0.0;
};
class StatisticalBaselineEnvelope {
public:
    [[nodiscard]] std::optional<StatisticalEnvelopeSample> sample(const NWayRunComparisonWorkbench& runs,std::string_view signal,double time_s,double live,double low_quantile=0.05,double high_quantile=0.95) const;
    [[nodiscard]] std::string report(const NWayRunComparisonWorkbench& runs,std::string_view signal,double time_s,double live,double low_quantile=0.05,double high_quantile=0.95) const;
};

class AlarmFloodChatterAnalyzer {
public:
    [[nodiscard]] std::string report(const SequenceOfEventsAnalyzer& soe,double window_s=10.0,double chatter_gap_s=0.5,std::size_t limit=12) const;
};

class CausalDifferenceExplorer {
public:
    bool add_dependency(CausalDifferenceDependency dependency,std::string& error);
    bool remove_dependency(std::string_view source,std::string_view target);
    void clear();
    [[nodiscard]] std::vector<CausalDifferenceDependency> dependencies() const;
    [[nodiscard]] std::vector<CausalDivergence> divergences(const NWayRunComparisonWorkbench& runs,std::string_view candidate,double absolute_tolerance=1e-9,double relative_tolerance=1e-6) const;
    [[nodiscard]] std::string explain(const NWayRunComparisonWorkbench& runs,std::string_view candidate,std::string_view target,double absolute_tolerance=1e-9,double relative_tolerance=1e-6,std::size_t maximum_depth=12) const;
    [[nodiscard]] std::string report() const;
private:
    std::vector<CausalDifferenceDependency> dependencies_;
};

enum class VerificationVerdict : unsigned char { unverified, pass, fail, inconclusive, stale };
struct RequirementRecord {
    std::string id,title,standard,clause,owner,criticality="normal";
    std::set<std::string> tags;
};
struct VerificationRecord {
    std::string id,title,run_id,metric,detail;
    std::set<std::string> requirement_ids;
    VerificationVerdict verdict=VerificationVerdict::unverified;
    double observed=std::numeric_limits<double>::quiet_NaN();
    double expected=std::numeric_limits<double>::quiet_NaN();
    double tolerance=std::numeric_limits<double>::quiet_NaN();
};
struct EvidenceRecord {
    std::uint64_t id=0;
    std::string verification_id,path,sha256,description;
    std::uint64_t size=0,recorded_ms=0;
};
struct RequirementMargin {
    std::string requirement_id,verification_id,metric;
    double current=std::numeric_limits<double>::quiet_NaN(),expected=std::numeric_limits<double>::quiet_NaN(),tolerance=std::numeric_limits<double>::quiet_NaN(),margin=std::numeric_limits<double>::quiet_NaN();
    VerificationVerdict verdict=VerificationVerdict::unverified;
};
class RequirementsVerificationEvidenceMatrix {
public:
    bool upsert_requirement(RequirementRecord requirement,std::string& error);
    bool upsert_verification(VerificationRecord verification,std::string& error);
    bool erase_requirement(std::string_view id);
    bool erase_verification(std::string_view id);
    bool attach_evidence(std::string_view verification_id,const std::filesystem::path& path,std::string description,std::string& error);
    [[nodiscard]] std::vector<std::string> stale_evidence() const;
    [[nodiscard]] VerificationVerdict requirement_verdict(std::string_view requirement_id) const;
    [[nodiscard]] std::string matrix_report() const;
    [[nodiscard]] std::string coverage_report() const;
    [[nodiscard]] std::string trace_report(std::string_view requirement_id) const;
    [[nodiscard]] std::optional<RequirementRecord> requirement(std::string_view id) const;
    [[nodiscard]] std::vector<RequirementRecord> requirements() const;
    [[nodiscard]] std::vector<VerificationRecord> verifications_for(std::string_view requirement_id) const;
    [[nodiscard]] std::vector<EvidenceRecord> evidence() const;
    [[nodiscard]] std::vector<RequirementMargin> live_margins(const TelemetryWorkbench& telemetry,double time_s,std::size_t limit=100) const;
    [[nodiscard]] std::string margin_report(std::string_view requirement_id,const TelemetryWorkbench* telemetry=nullptr,double time_s=std::numeric_limits<double>::quiet_NaN()) const;
    [[nodiscard]] static std::optional<VerificationVerdict> parse_verdict(std::string_view value);
    [[nodiscard]] static std::string verdict_name(VerificationVerdict value);
private:
    std::map<std::string,RequirementRecord> requirements_;
    std::map<std::string,VerificationRecord> verifications_;
    std::map<std::uint64_t,EvidenceRecord> evidence_;
    std::uint64_t next_evidence_id_=1;
    [[nodiscard]] bool evidence_stale(const EvidenceRecord& record) const;
};

struct DesignSpaceSensitivity {
    std::string parameter,objective;
    std::size_t samples=0;
    double correlation=std::numeric_limits<double>::quiet_NaN();
};
class DesignSpaceExplorer {
public:
    [[nodiscard]] std::string summary(const std::vector<ExperimentRun>& runs) const;
    [[nodiscard]] std::vector<DesignSpaceSensitivity> sensitivities(const std::vector<ExperimentRun>& runs,std::string_view objective) const;
    [[nodiscard]] std::string sensitivity_report(const std::vector<ExperimentRun>& runs,std::string_view objective) const;
    [[nodiscard]] std::string correlation_matrix(const std::vector<ExperimentRun>& runs) const;
    [[nodiscard]] std::string parallel_coordinates(const std::vector<ExperimentRun>& runs,std::size_t width=80) const;
    [[nodiscard]] std::vector<ExperimentRun> feasible(const std::vector<ExperimentRun>& runs,std::string_view constraints,std::string& error) const;
    [[nodiscard]] std::string feasible_report(const std::vector<ExperimentRun>& runs,std::string_view constraints,std::string& error) const;
};

enum class FlightSeverity : unsigned char { trace, info, notice, warning, error, critical };
struct FlightRecord {
    std::uint64_t sequence=0,wall_ms=0;
    double simulation_time_s=std::numeric_limits<double>::quiet_NaN();
    FlightSeverity severity=FlightSeverity::info;
    std::string kind,title,detail,object_uri,command,correlation_id;
    std::map<std::string,double> metrics;
};
class EngineeringFlightRecorder {
public:
    std::uint64_t record(FlightRecord event);
    std::uint64_t record_command(std::string command,double simulation_time_s);
    std::uint64_t record_result(std::string command,std::string result,double simulation_time_s);
    void record_telemetry(double simulation_time_s,const std::map<std::string,double>& metrics);
    std::uint64_t bookmark(std::string label,double simulation_time_s,std::string object_uri={});
    bool set_capacity(std::size_t capacity,std::string& error);
    void clear();
    [[nodiscard]] std::vector<FlightRecord> query(std::string_view expression={},std::size_t limit=200) const;
    [[nodiscard]] std::optional<FlightRecord> get(std::uint64_t sequence) const;
    bool export_jsonl(const std::filesystem::path& path,std::string& error) const;
    bool export_csv(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string report(std::string_view expression={},std::size_t limit=50) const;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] static std::optional<FlightSeverity> parse_severity(std::string_view value);
    [[nodiscard]] static std::string severity_name(FlightSeverity value);
private:
    mutable std::mutex mutex_;
    std::deque<FlightRecord> records_;
    std::uint64_t next_sequence_=1;
    std::size_t capacity_=200000;
    double last_telemetry_s_=-std::numeric_limits<double>::infinity();
};

class AutomotiveVisualization {
public:
    [[nodiscard]] static std::string four_corner(const std::map<std::string,double>& metrics);
    [[nodiscard]] static std::string system_flow(const std::map<std::string,double>& metrics);
    [[nodiscard]] static std::string energy_flow(const std::map<std::string,double>& metrics);
    [[nodiscard]] static std::string motorsport_pit_wall(const std::map<std::string,double>& metrics,std::string_view series={});
    [[nodiscard]] static std::string friction_circle(const std::map<std::string,double>& metrics,int width=45,int height=17);
    [[nodiscard]] static std::string uncertainty_compact(const std::map<std::string,double>& metrics,std::size_t width=100,std::size_t maximum_rows=24);
};

struct PersistentSessionRecord { std::string id,name,owner,state_path; bool attached=false; std::set<std::string> observers; std::uint64_t created_ms=0,updated_ms=0; };
class PersistentSessionRegistry {
public:
    explicit PersistentSessionRegistry(std::filesystem::path path={});
    [[nodiscard]] static bool valid_identifier(std::string_view id) noexcept;
    bool create(std::string id,std::string name,std::string owner,std::string state_path,std::string& error);
    bool detach(std::string_view id,std::string& error);
    bool attach(std::string_view id,std::string_view actor,bool read_only,std::string& error);
    bool release(std::string_view id,std::string_view actor,std::string& error);
    bool rename(std::string_view id,std::string name,std::string& error);
    [[nodiscard]] std::vector<PersistentSessionRecord> list() const;
    [[nodiscard]] std::string report() const;
private:
    std::filesystem::path path_; std::map<std::string,PersistentSessionRecord> sessions_;
    bool load(std::string& error); bool save(std::string& error) const;
};

enum class GraphicsMode : unsigned char { automatic,ascii,unicode,braille,sixel,kitty };
class HighResolutionRenderer {
public:
    void set_mode(GraphicsMode mode) noexcept { mode_=mode; }
    [[nodiscard]] GraphicsMode mode() const noexcept { return mode_; }
    [[nodiscard]] GraphicsMode negotiate(const TerminalCapabilities& capabilities) const noexcept;
    [[nodiscard]] std::string line_plot(const std::vector<double>& values,int width,int height,const TerminalCapabilities& capabilities) const;
    [[nodiscard]] std::string bitmap(const std::vector<std::uint8_t>& pixels,int width,int height,const TerminalCapabilities& capabilities) const;
    [[nodiscard]] static std::optional<GraphicsMode> parse_mode(std::string_view value);
    [[nodiscard]] static std::string mode_name(GraphicsMode mode);
private: GraphicsMode mode_=GraphicsMode::automatic;
};

struct SearchDocument { std::string id,kind,title,summary,object_uri,command; std::map<std::string,std::string> fields; };
class StructuredGlobalSearch {
public:
    void upsert(SearchDocument document); void erase(std::string_view id);
    [[nodiscard]] std::vector<SearchDocument> query(std::string_view expression,std::size_t limit=50) const;
    [[nodiscard]] std::string report(std::string_view expression,std::size_t limit=25) const;
    [[nodiscard]] std::size_t size() const noexcept { return documents_.size(); }
private: std::map<std::string,SearchDocument> documents_;
};

struct UiCommandEquivalence {
    std::string action_id,label,canonical_command,context;
    bool mutating=false;
};
class CliGuiEquivalenceRegistry {
public:
    bool register_mapping(UiCommandEquivalence mapping,std::string& error);
    bool erase(std::string_view action_id);
    [[nodiscard]] std::optional<UiCommandEquivalence> lookup(std::string_view action_id) const;
    [[nodiscard]] std::vector<UiCommandEquivalence> search(std::string_view query={},std::size_t limit=100) const;
    [[nodiscard]] std::string report(std::string_view query={}) const;
private: std::map<std::string,UiCommandEquivalence> mappings_;
};

struct OscPolicy { bool hyperlinks=true,clipboard=false; std::size_t max_clipboard_bytes=65536; };
class TerminalOscIntegration {
public:
    void set_policy(OscPolicy policy) noexcept { policy_=policy; }
    [[nodiscard]] const OscPolicy& policy() const noexcept { return policy_; }
    [[nodiscard]] std::string hyperlink(std::string_view target,std::string_view label) const;
    [[nodiscard]] std::optional<std::string> clipboard_sequence(std::string_view text,bool sensitive,std::string& error) const;
private: OscPolicy policy_;
};

class NavigationContext {
public:
    void visit(globalui::ObjectId id); [[nodiscard]] std::optional<globalui::ObjectId> current() const;
    bool back(); bool forward(); bool pin(globalui::ObjectId id); bool unpin(const globalui::ObjectId& id);
    void set_peek(std::optional<globalui::ObjectId> id) { peek_=std::move(id); }
    [[nodiscard]] std::string breadcrumbs(const globalui::ContextGraph& graph) const;
    [[nodiscard]] std::string pinned_report(const globalui::ContextGraph& graph) const;
    [[nodiscard]] std::optional<globalui::ObjectId> peek() const { return peek_; }
private: std::vector<globalui::ObjectId> history_; std::size_t cursor_=0; std::set<globalui::ObjectId> pinned_; std::optional<globalui::ObjectId> peek_;
};

enum class TuiPaneAxis : unsigned char { horizontal, vertical };
struct TuiPane { std::string id,title,view,command; double weight=1.0; bool visible=true; std::string parent_id="root"; TuiPaneAxis split_axis=TuiPaneAxis::vertical; };
struct TuiPaneLayout { std::string name; std::vector<TuiPane> panes; std::size_t focused=0; TuiPaneAxis axis=TuiPaneAxis::vertical; };
class TuiPaneLayoutManager {
public:
    TuiPaneLayoutManager();
    bool create(std::string name,TuiPaneAxis axis,std::string& error);
    bool select(std::string_view name,std::string& error);
    bool add(TuiPane pane,std::string& error);
    bool remove(std::string_view pane_id,std::string& error);
    bool focus(std::string_view pane_id,std::string& error);
    bool next(); bool previous();
    bool resize(std::string_view pane_id,double weight,std::string& error);
    bool split(std::string_view target_pane,TuiPaneAxis axis,TuiPane pane,std::string& error);
    bool move(std::string_view pane_id,std::string_view new_parent,std::string& error);
    bool swap(std::string_view a,std::string_view b,std::string& error);
    bool set_visible(std::string_view pane_id,bool visible,std::string& error);
    bool maximize(std::string_view pane_id,std::string& error);
    bool restore_maximized(std::string& error);
    bool set_breakpoint(int min_columns,std::vector<std::string> visible_panes,std::string& error);
    bool apply_breakpoint(int columns,std::string& error);
    [[nodiscard]] bool maximized() const noexcept { return maximized_.has_value(); }
    [[nodiscard]] const TuiPaneLayout* active() const;
    [[nodiscard]] std::vector<std::string> layouts() const;
    [[nodiscard]] std::string report() const;
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
private:
    std::map<std::string,TuiPaneLayout> layouts_; std::string active_;
    std::optional<TuiPaneLayout> maximized_;
    std::map<std::string,std::map<int,std::vector<std::string>,std::greater<int>>> responsive_breakpoints_;
};


// -----------------------------------------------------------------------------
// V12 professional engineering desktop and orchestration workbenches
// -----------------------------------------------------------------------------

enum class DockOrientation : unsigned char { horizontal, vertical };
struct DesktopTab {
    std::string id,title,object_uri,command;
    bool pinned=false;
};
struct DockNode {
    std::string id;
    bool split=false;
    DockOrientation orientation=DockOrientation::horizontal;
    double ratio=0.5;
    std::string first,second;
    std::vector<DesktopTab> tabs;
    std::string active_tab;
};
struct DesktopWindow {
    std::string id,title,monitor="primary",root_node;
    int x=80,y=80,width=1440,height=900;
};
struct DesktopWorkspace {
    std::string name;
    std::map<std::string,DockNode> nodes;
    std::map<std::string,DesktopWindow> windows;
};
struct WorkbenchSchema {
    std::string id,title,category,command,description,object_uri;
    std::vector<std::string> actions;
};
class SchemaDrivenEngineeringDesktop {
public:
    SchemaDrivenEngineeringDesktop();
    bool register_workbench(WorkbenchSchema schema,std::string& error);
    bool create_workspace(std::string name,std::string& error);
    bool select_workspace(std::string_view name,std::string& error);
    bool open_tab(std::string window_id,std::string node_id,DesktopTab tab,std::string& error);
    bool close_tab(std::string_view tab_id,std::string& error);
    bool activate_tab(std::string_view tab_id,std::string& error);
    bool reorder_tab(std::string_view tab_id,std::size_t target_index,std::string& error);
    bool split_node(std::string_view node_id,DockOrientation orientation,double ratio,std::string new_group_id,std::string& error);
    bool move_tab(std::string_view tab_id,std::string_view target_node,std::string& error);
    bool detach_tab(std::string_view tab_id,std::string window_id,std::string monitor,int x,int y,int width,int height,std::string& error);
    bool set_window_geometry(std::string_view window_id,std::string monitor,int x,int y,int width,int height,std::string& error);
    bool set_split_ratio(std::string_view node_id,double ratio,std::string& error);
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] std::string active_workspace() const;
    [[nodiscard]] std::vector<WorkbenchSchema> workbenches() const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] std::string schema_json() const;
    [[nodiscard]] std::string workspace_json() const;
private:
    std::map<std::string,WorkbenchSchema> schemas_;
    std::map<std::string,DesktopWorkspace> workspaces_;
    std::string active_="default";
    [[nodiscard]] DesktopWorkspace* current();
    [[nodiscard]] const DesktopWorkspace* current() const;
    [[nodiscard]] bool validate(const DesktopWorkspace& workspace,std::string& error) const;
};

struct StreamFrame {
    std::uint64_t sequence=0;
    double simulation_time_s=0.0;
    std::uint64_t wall_ms=0;
    std::map<std::string,double> metrics;
};
struct StreamSubscription {
    std::uint64_t id=0,cursor=0,dropped=0;
    std::set<std::string> signals;
    double max_rate_hz=20.0;
    std::size_t max_queue=256;
};
class RealTimeTelemetryStreamingFabric {
public:
    std::uint64_t subscribe(std::set<std::string> signals,double max_rate_hz,std::size_t max_queue,std::uint64_t resume_after,std::string& error);
    bool unsubscribe(std::uint64_t id);
    void publish(double simulation_time_s,const std::map<std::string,double>& metrics);
    [[nodiscard]] std::vector<StreamFrame> poll(std::uint64_t id,std::size_t max_frames,std::string& error);
    [[nodiscard]] std::string poll_json(std::uint64_t since,const std::set<std::string>& signals,double max_rate_hz,std::size_t max_frames,int wait_ms=0) const;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] std::uint64_t latest_sequence() const;
    void set_history_capacity(std::size_t capacity);
private:
    mutable std::mutex mutex_;
    mutable std::condition_variable condition_;
    std::deque<StreamFrame> history_;
    std::map<std::uint64_t,StreamSubscription> subscriptions_;
    std::uint64_t next_sequence_=1,next_subscription_=1;
    std::size_t history_capacity_=8192;
};

struct CampaignResourceBudget {
    std::size_t cpu_threads=1,memory_bytes=1024ULL*1024ULL*1024ULL,gpu_slots=0,mpi_ranks=1;
};
struct CampaignResourceEstimate {
    std::size_t runs=0,concurrency=1,waves=0;
    std::size_t peak_cpu_threads=0,peak_memory_bytes=0,peak_gpu_slots=0,peak_mpi_ranks=0;
    double estimated_seconds=0.0;
    std::string backend;
};
struct CampaignParameterSpec {
    std::string name,unit;
    double minimum=0.0,maximum=0.0;
    std::size_t points=1;
};
class CampaignOrchestrationResourcePlanner {
public:
    void reset();
    bool configure(std::string name,std::uint64_t seed,std::size_t workers,std::string backend,std::string& error);
    bool set_budget(CampaignResourceBudget budget,std::string& error);
    bool add_parameter(CampaignParameterSpec parameter,std::string& error);
    bool add_remote_worker(std::string host,std::uint16_t port,std::string& error);
    [[nodiscard]] CampaignResourceEstimate estimate(std::size_t memory_per_run,double seconds_per_run,std::size_t gpu_slots_per_run=0,std::size_t mpi_ranks_per_run=1) const;
    bool execute(std::string& error);
    std::size_t import_experiments(ExperimentMatrix& matrix,std::string& error) const;
    [[nodiscard]] std::vector<ExperimentRun> last_runs() const;
    [[nodiscard]] std::string plan_report() const;
    [[nodiscard]] std::string result_report() const;
private:
    std::string name_="campaign"; std::uint64_t seed_=1; std::size_t workers_=0; std::string backend_="auto";
    CampaignResourceBudget budget_{}; std::vector<CampaignParameterSpec> parameters_;
    std::vector<std::pair<std::string,std::uint16_t>> remote_workers_;
    std::vector<ExperimentRun> last_runs_; std::string last_report_;
};

struct DoeParameterBound { std::string name; double minimum=0.0,maximum=1.0; };
enum class DoeStrategy : unsigned char { latin_hypercube, quasi_random, bayesian_expected_improvement, uncertainty_sampling, hybrid };
struct DoeProposal { std::string id; std::map<std::string,double> parameters; double predicted_mean=0.0,predicted_sigma=0.0,acquisition=0.0; };
class AdaptiveDoeOptimizationStudio {
public:
    bool configure(std::string objective,bool minimize,std::uint64_t seed,std::string& error);
    bool set_bound(DoeParameterBound bound,std::string& error);
    bool remove_bound(std::string_view name);
    [[nodiscard]] std::vector<DoeProposal> propose(const std::vector<ExperimentRun>& observations,std::size_t count,DoeStrategy strategy,std::string& error) const;
    std::size_t stage_proposals(const std::vector<DoeProposal>& proposals,ExperimentMatrix& matrix,std::string& error) const;
    [[nodiscard]] std::string convergence_report(const std::vector<ExperimentRun>& observations) const;
    [[nodiscard]] std::string bounds_report() const;
    [[nodiscard]] static std::optional<DoeStrategy> parse_strategy(std::string_view value);
    [[nodiscard]] static std::string strategy_name(DoeStrategy value);
private:
    std::string objective_; bool minimize_=true; std::uint64_t seed_=1; std::map<std::string,DoeParameterBound> bounds_;
};

struct TimelineParameter { std::string name,unit; double value=0.0; };
struct ScenarioTimelineEvent {
    std::uint64_t id=0; std::string track,action,target,condition;
    double start_s=0.0,duration_s=0.0;
    std::size_t repeat_count=1; double repeat_period_s=0.0;
    std::vector<TimelineParameter> parameters;
};
struct ScenarioAssertion { std::string expression,message,mode="always",severity="error"; };
class VisualScenarioEventTimelineComposer {
public:
    void reset(std::string name="scenario");
    bool configure(double duration_s,double step_s,std::uint64_t seed,std::string& error);
    bool set_environment(std::string name,double value,std::string unit,std::string& error);
    bool set_vehicle(std::string name,double value,std::string unit,std::string& error);
    bool add_event(ScenarioTimelineEvent event,std::string& error);
    bool add_ramp(std::string track,std::string target,std::string parameter,double start_s,double end_s,double from,double to,std::string unit,std::string& error);
    bool add_assertion(ScenarioAssertion assertion,std::string& error);
    bool erase_event(std::uint64_t id);
    bool move_event(std::uint64_t id,double start_s,std::string track,std::string& error);
    bool resize_event(std::uint64_t id,double duration_s,std::string& error);
    [[nodiscard]] std::vector<std::string> validate() const;
    bool save_json(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string json() const;
    [[nodiscard]] std::string render(std::size_t width=100) const;
private:
    std::string name_="scenario"; double duration_s_=60.0,step_s_=0.01; std::uint64_t seed_=1,next_event_id_=1;
    std::map<std::string,TimelineParameter> environment_,vehicle_;
    std::map<std::uint64_t,ScenarioTimelineEvent> events_; std::vector<ScenarioAssertion> assertions_;
};

enum class WorkflowDebugState : unsigned char { idle,running,paused,waiting_command,completed,failed };
struct WorkflowDebugSnapshot {
    WorkflowDebugState state=WorkflowDebugState::idle;
    std::string graph_id,node_id,pending_command,last_output;
    std::size_t command_index=0,steps=0;
};
class WorkflowExecutionDebugger {
public:
    bool load(globalui::WorkflowGraph graph,std::string& error);
    bool start(std::string& error);
    void reset();
    bool add_breakpoint(std::string node,std::string condition,std::string& error);
    bool remove_breakpoint(std::string_view node);
    void clear_breakpoints();
    void set_variable(std::string name,double value);
    [[nodiscard]] std::optional<std::string> step(bool ignore_breakpoint,std::string& error);
    [[nodiscard]] std::optional<std::string> continue_execution(std::string& error);
    bool observe_result(std::string_view command,std::string output,bool success,std::string& error);
    [[nodiscard]] WorkflowDebugSnapshot snapshot() const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] std::string state_json() const;
private:
    std::optional<globalui::WorkflowGraph> graph_; WorkflowDebugSnapshot state_; std::set<std::string> completed_,failed_;
    std::map<std::string,std::string> breakpoints_; std::map<std::string,double> variables_; bool breakpoint_latched_=false;
    [[nodiscard]] bool condition_true(std::string_view expression) const;
    bool select_next_node(std::string& error);
};

enum class ReviewStatus : unsigned char { pending,approved,rejected,changes_requested,superseded };
enum class ReviewDecisionKind : unsigned char { approve,reject,request_changes };
struct QualificationReviewer { std::string id,name,role,organization; int authority=0; };
struct QualificationReviewDecision {
    std::uint64_t sequence=0,wall_ms=0; std::string reviewer_id,comment,digest,previous_digest;
    ReviewDecisionKind decision=ReviewDecisionKind::approve;
};
struct QualificationReviewItem {
    std::string id,title,kind,object_uri,submitter,required_role;
    std::size_t required_approvals=1; bool independent_review=true; ReviewStatus status=ReviewStatus::pending;
    std::vector<QualificationReviewDecision> decisions;
};
class QualificationReviewApprovalCenter {
public:
    bool add_reviewer(QualificationReviewer reviewer,std::string& error);
    bool submit(QualificationReviewItem item,std::string& error);
    bool decide(std::string_view item_id,std::string_view reviewer_id,ReviewDecisionKind decision,std::string comment,std::string& error);
    bool supersede(std::string_view item_id,std::string& error);
    [[nodiscard]] std::vector<QualificationReviewItem> inbox(std::string_view reviewer_id={}) const;
    [[nodiscard]] std::string report(std::string_view reviewer_id={}) const;
    [[nodiscard]] std::string audit(std::string_view item_id) const;
    [[nodiscard]] static std::optional<ReviewDecisionKind> parse_decision(std::string_view value);
    [[nodiscard]] static std::string status_name(ReviewStatus status);
private:
    std::map<std::string,QualificationReviewer> reviewers_; std::map<std::string,QualificationReviewItem> items_; std::uint64_t next_sequence_=1;
};

struct TopologyNode { std::string id,label,type,object_uri,health="nominal"; std::map<std::string,double> metrics; };
struct TopologyLink {
    std::string id,from,to,protocol,bus,health="nominal";
    double capacity_bps=0.0,latency_ms=0.0,load_bps=0.0;
    std::uint64_t frames=0,bytes=0,last_sequence=0;
};
class LiveEeCosimulationTopologyCanvas {
public:
    bool upsert_node(TopologyNode node,std::string& error);
    bool upsert_link(TopologyLink link,std::string& error);
    bool erase_node(std::string_view id);
    bool erase_link(std::string_view id);
    void observe(const TraceFrame& frame);
    bool set_node_health(std::string_view id,std::string health,std::string& error);
    [[nodiscard]] std::string render(std::size_t width=120) const;
    [[nodiscard]] std::string dot() const;
    [[nodiscard]] std::string json() const;
private:
    std::map<std::string,TopologyNode> nodes_; std::map<std::string,TopologyLink> links_;
};

struct DerivedSignalDefinition { std::string name,expression,unit,dimension; std::set<std::string> dependencies; };
class DerivedSignalVirtualChannelLaboratory {
public:
    bool define(std::string name,std::string expression,std::string unit,const TelemetryWorkbench& telemetry,std::string& error);
    bool erase(std::string_view name);
    void clear();
    [[nodiscard]] std::optional<double> evaluate(std::string_view name,double time_s,const TelemetryWorkbench& telemetry,std::string& error) const;
    std::size_t update_all(double time_s,TelemetryWorkbench& telemetry,std::string& error) const;
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string,DerivedSignalDefinition> definitions_;
};

struct PlotAnnotation { std::uint64_t id=0; std::string signal,label,detail; double time_s=0.0,value=std::numeric_limits<double>::quiet_NaN(); };
struct PlotMeasurement { std::string signal,measurement,unit; double value=std::numeric_limits<double>::quiet_NaN(); double begin_s=0.0,end_s=0.0; };
class InstrumentGradePlotMeasurementToolkit {
public:
    void set_cursor(char cursor,double time_s);
    [[nodiscard]] std::optional<double> cursor(char cursor) const;
    [[nodiscard]] std::optional<PlotMeasurement> measure(std::string_view signal,std::string_view measurement,const TelemetryWorkbench& telemetry,double threshold,std::string& error) const;
    std::uint64_t annotate(std::string signal,double time_s,double value,std::string label,std::string detail={});
    bool erase_annotation(std::uint64_t id);
    [[nodiscard]] std::string annotation_report(std::string_view signal={}) const;
    bool export_annotations_csv(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string status() const;
private:
    std::optional<double> cursor_a_,cursor_b_; std::map<std::uint64_t,PlotAnnotation> annotations_; std::uint64_t next_annotation_=1;
};

class LinkedEngineeringCursorBus {
public:
    void attach(SynchronizedTimeCursor* time_cursor,InstrumentGradePlotMeasurementToolkit* plot_toolkit) noexcept;
    bool set(std::string_view cursor,double time_s,std::string& error);
    bool nudge(std::string_view cursor,double delta_s,std::string& error);
    void follow_live(bool enabled);
    [[nodiscard]] std::optional<double> get(std::string_view cursor) const;
    [[nodiscard]] std::string report() const;
private:
    SynchronizedTimeCursor* time_cursor_{};
    InstrumentGradePlotMeasurementToolkit* plot_toolkit_{};
    std::optional<double> cursor_a_,cursor_b_;
};


// -----------------------------------------------------------------------------
// V13 professional engineering operations workbenches
// -----------------------------------------------------------------------------
struct TwinSceneObject {
    std::string id,kind="component",label,parent,object_uri;
    double x=0.0,y=0.0,z=0.0,roll=0.0,pitch=0.0,yaw=0.0,sx=1.0,sy=1.0,sz=1.0;
    std::map<std::string,double> metrics;
};
class EngineeringDigitalTwinViewport3D {
public:
    bool upsert(TwinSceneObject object,std::string& error);
    bool erase(std::string_view id); void clear();
    void set_camera(double x,double y,double z,double yaw,double pitch) noexcept;
    void update_live_signals(double time_s,const std::map<std::string,double>& signals);
    [[nodiscard]] std::optional<TwinSceneObject> get(std::string_view id) const;
    [[nodiscard]] std::optional<double> distance(std::string_view a,std::string_view b) const;
    [[nodiscard]] std::string section_report(char axis,double coordinate) const;
    [[nodiscard]] std::string scene_json() const;
    [[nodiscard]] std::string webgl_payload() const { return scene_json(); }
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_; std::map<std::string,TwinSceneObject> objects_;
    double camera_x_=8,camera_y_=4,camera_z_=3,camera_yaw_=180,camera_pitch_=-12,time_s_=0;
};

enum class RunbookStepState : unsigned char { pending,ready,running,passed,failed,skipped };
struct QualificationRunbookStep {
    std::uint64_t id=0; std::string title,command,acceptance,operator_id,comment,evidence_path,evidence_sha256;
    std::vector<std::uint64_t> prerequisites; bool requires_dual_approval=false,hold_point=false;
    RunbookStepState state=RunbookStepState::pending; std::set<std::string> approvals;
};
class ElectronicQualificationRunbook {
public:
    void reset(std::string title);
    std::uint64_t add_step(QualificationRunbookStep step,std::string& error);
    bool begin(std::uint64_t id,std::string operator_id,std::string& error);
    bool approve(std::uint64_t id,std::string reviewer,std::string& error);
    bool complete(std::uint64_t id,bool pass,std::string operator_id,std::string comment,std::string evidence_path,std::string& error);
    bool skip(std::uint64_t id,std::string operator_id,std::string justification,std::string& error);
    [[nodiscard]] bool ready(std::uint64_t id) const; [[nodiscard]] bool complete() const;
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
    bool save_json(const std::filesystem::path& path,std::string& error) const;
private:
    std::string title_="qualification"; std::map<std::uint64_t,QualificationRunbookStep> steps_; std::uint64_t next_id_=1;
};

struct ReleaseQualificationAction { std::string id,type,target,reason,command,status="pending"; bool mandatory=true; };
struct ChangeQualificationPlan {
    std::string change_id,summary; std::vector<std::string> affected_objects,stale_evidence;
    std::vector<ReleaseQualificationAction> actions; std::set<std::string> approvals;
};
class ChangeQualificationReleasePlanner {
public:
    bool create(std::string change_id,std::string summary,const std::vector<std::string>& seeds,const globalui::ContextGraph& context,const RequirementsVerificationEvidenceMatrix& verification,const RegressionTriageDashboard& regressions,std::string& error);
    bool set_action_status(std::string_view id,std::string status,std::string& error);
    bool approve(std::string reviewer,std::string& error);
    [[nodiscard]] const ChangeQualificationPlan& plan() const noexcept { return plan_; }
    [[nodiscard]] bool releasable(std::string& reason) const;
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
    bool save_json(const std::filesystem::path& path,std::string& error) const;
private: ChangeQualificationPlan plan_;
};

enum class EngineeringDataQuality : unsigned char { unknown,valid,stale,invalid };
struct EngineeringDataAsset {
    std::string id,name,kind,uri,format,unit,owner,source,provenance_uri,sha256;
    double sample_rate_hz=0.0,uncertainty=0.0; std::uint64_t size_bytes=0;
    EngineeringDataQuality quality=EngineeringDataQuality::unknown; std::set<std::string> tags,consumers;
};
class UnifiedEngineeringDataCatalog {
public:
    bool upsert(EngineeringDataAsset asset,std::string& error); bool erase(std::string_view id);
    [[nodiscard]] std::optional<EngineeringDataAsset> get(std::string_view id) const;
    [[nodiscard]] std::vector<EngineeringDataAsset> query(std::string_view expression={}) const;
    bool verify(std::string_view id,std::string& error); bool add_consumer(std::string_view id,std::string consumer,std::string& error);
    [[nodiscard]] std::string report(std::string_view expression={}) const; [[nodiscard]] std::string json() const;
    bool save_json(const std::filesystem::path& path,std::string& error) const;
private: std::map<std::string,EngineeringDataAsset> assets_;
};

struct CalibrationCorrelationResult { std::size_t samples=0; double bias=0,mae=0,rmse=0,correlation=0,r_squared=0; };
class InteractiveCalibrationCorrelationWorkbench {
public:
    bool load_map(const aesim::studio::CalibrationMap& map,std::string& error);
    bool create_map(std::string name,std::size_t nx,std::size_t ny,std::string unit,std::string& error);
    bool set_cell(std::size_t ix,std::size_t iy,double value,std::string& error);
    bool edit_region(std::size_t x0,std::size_t y0,std::size_t x1,std::size_t y1,double value,std::string& error);
    bool smooth(std::size_t radius,std::string& error);
    [[nodiscard]] std::vector<std::string> validate() const;
    [[nodiscard]] std::string map_json() const;
    [[nodiscard]] CalibrationCorrelationResult correlate(const std::vector<double>& measured,const std::vector<double>& simulated,std::string& error) const;
    bool stage(std::string name,std::string reviewer,std::string& error); bool approve(std::string reviewer,std::string& error);
    bool save(const std::filesystem::path& path,std::string& error) const; bool export_csv(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] const aesim::studio::CalibrationMap& current_map() const { return studio_.map(); }
private:
    aesim::studio::CalibrationMapStudio studio_; std::string staged_name_,staged_by_,approved_by_; bool staged_=false,approved_=false;
};

struct CollaborationParticipant { std::string id,name,role; std::uint64_t last_heartbeat_ms=0; };
struct CollaborationCursor { std::string user_id,object_uri; double time_s=0.0; std::string selection; };
struct CollaborationComment { std::uint64_t id=0; std::string user_id,object_uri,text,resolved_by; double time_s=0.0; bool resolved=false; };
class RealTimeCollaborativeEngineeringSession {
public:
    bool create(std::string id,std::string title,std::string& error); bool join(CollaborationParticipant participant,std::string& error);
    bool leave(std::string_view id); bool heartbeat(std::string_view id,std::string& error); bool update_cursor(CollaborationCursor cursor,std::string& error);
    std::uint64_t comment(std::string user,std::string uri,double time_s,std::string text,std::string& error);
    bool resolve(std::uint64_t id,std::string reviewer,std::string& error); bool set_presenter(std::string id,std::string& error);
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string state_json() const;
private:
    mutable std::mutex mutex_; std::string id_,title_,presenter_; std::map<std::string,CollaborationParticipant> participants_;
    std::map<std::string,CollaborationCursor> cursors_; std::map<std::uint64_t,CollaborationComment> comments_; std::uint64_t next_comment_=1;
};


// -----------------------------------------------------------------------------
// V17 research-grade engineering workbenches.  These are presentation and
// analysis adapters over the existing authoritative simulator/backend services;
// they do not replace formal solvers, safety engines, plugin loaders, co-sim
// runtimes, or configuration-migration backends.
// -----------------------------------------------------------------------------

enum class PredicateOperator : unsigned char { lt,le,gt,ge,eq,ne };
struct MetricPredicate { std::string signal; PredicateOperator op=PredicateOperator::gt; double threshold=0.0; };
[[nodiscard]] std::optional<PredicateOperator> parse_predicate_operator(std::string_view text);
[[nodiscard]] std::string predicate_operator_name(PredicateOperator op);
[[nodiscard]] bool evaluate_predicate(double value,PredicateOperator op,double threshold,double tolerance=1e-12);

struct FormalCounterexampleStep { double time_s=0.0; std::string state,transition,detail; };
struct FormalVerificationView {
    std::string property,verdict="unknown",method,detail;
    double horizon_s=0.0,margin=std::numeric_limits<double>::quiet_NaN();
    std::vector<FormalCounterexampleStep> counterexample;
};
class FormalVerificationCounterexampleExplorer {
public:
    bool upsert(FormalVerificationView view,std::string& error);
    bool add_step(std::string_view property,FormalCounterexampleStep step,std::string& error);
    bool erase(std::string_view property); void clear();
    [[nodiscard]] std::string report(std::string_view property={}) const;
    [[nodiscard]] std::string graph_json(std::string_view property) const;
private: std::map<std::string,FormalVerificationView> views_;
};

struct ScientificFieldSample { double x=0,y=0,z=0,value=0,vx=0,vy=0,vz=0; };
struct ScientificFieldDataset { std::string id,quantity,unit,domain; std::vector<ScientificFieldSample> samples; };
class MultiphysicsFieldVisualizationWorkbench {
public:
    bool define(ScientificFieldDataset field,std::string& error);
    bool append(std::string_view id,ScientificFieldSample sample,std::string& error);
    bool erase(std::string_view id); void clear();
    [[nodiscard]] std::optional<ScientificFieldSample> probe(std::string_view id,double x,double y,double z) const;
    [[nodiscard]] std::vector<ScientificFieldSample> slice(std::string_view id,char axis,double coordinate,double tolerance) const;
    [[nodiscard]] std::string report(std::string_view id={}) const;
    [[nodiscard]] std::string field_json(std::string_view id,std::size_t maximum_points=5000) const;
private: std::map<std::string,ScientificFieldDataset> fields_;
};

struct SparseJacobianEntry { std::size_t row=0,column=0; double value=0.0; };
struct SparseJacobianStatistics { std::size_t rows=0,columns=0,nonzeros=0,colors=0; double density=0,max_abs=0,min_nonzero_abs=0; };
class SparseJacobianInspector {
public:
    bool reset(std::size_t rows,std::size_t columns,std::string& error);
    bool set(std::size_t row,std::size_t column,double value,std::string& error); void clear();
    [[nodiscard]] SparseJacobianStatistics statistics() const;
    [[nodiscard]] std::vector<std::size_t> greedy_column_coloring() const;
    [[nodiscard]] std::string report(std::size_t preview=48) const;
    [[nodiscard]] std::string json(std::size_t maximum_entries=10000) const;
private: std::size_t rows_=0,columns_=0; std::map<std::pair<std::size_t,std::size_t>,double> entries_;
};

struct DistributedTraceSpan { std::uint64_t id=0,parent=0; std::string name,service,host,thread; int rank=-1; double start_ms=0,end_ms=0; std::map<std::string,std::string> attributes; };
class DistributedTraceWaterfallWorkbench {
public:
    bool append(DistributedTraceSpan span,std::string& error); void clear();
    [[nodiscard]] std::vector<std::uint64_t> critical_path() const;
    [[nodiscard]] std::vector<DistributedTraceSpan> spans() const;
    [[nodiscard]] std::string report(std::size_t limit=100) const;
    [[nodiscard]] std::string json(std::size_t limit=5000) const;
private: std::map<std::uint64_t,DistributedTraceSpan> spans_;
};

struct HpcHostTopology { std::string id,hostname; std::size_t logical_cpus=0,numa_nodes=0; std::uint64_t memory_bytes=0; std::vector<std::string> gpus; };
struct HpcPlacementRecord { std::string workload,host; int numa=-1,gpu=-1,rank=-1; std::size_t cpu_threads=0; double utilization_percent=0.0; };
class HpcHardwarePlacementWorkbench {
public:
    HpcHardwarePlacementWorkbench();
    bool upsert_host(HpcHostTopology host,std::string& error); bool place(HpcPlacementRecord placement,std::string& error);
    bool erase_host(std::string_view id); void clear_placements();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::map<std::string,HpcHostTopology> hosts_; std::map<std::string,HpcPlacementRecord> placements_;
};

struct SafetyGraphNode { std::string id,type,title,criticality,requirement,evidence; double probability=std::numeric_limits<double>::quiet_NaN(); };
struct SafetyGraphEdge { std::string source,target,logic="causes",detail; };
class GraphicalSafetyAnalysisWorkbench {
public:
    bool upsert(SafetyGraphNode node,std::string& error); bool connect(SafetyGraphEdge edge,std::string& error);
    bool erase(std::string_view id); void clear();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::map<std::string,SafetyGraphNode> nodes_; std::vector<SafetyGraphEdge> edges_;
};

struct TemporalBisectionResult { bool found=false; double first_bad_s=std::numeric_limits<double>::quiet_NaN(),lower_s=0,upper_s=0,resolution_s=0; std::size_t probes=0; std::string signal,predicate; };
class DeterministicTemporalBisectionDebugger {
public:
    [[nodiscard]] TemporalBisectionResult locate(const TelemetryWorkbench& telemetry,std::string_view signal,PredicateOperator op,double threshold,double begin_s,double end_s,double resolution_s) const;
    [[nodiscard]] std::string report(const TemporalBisectionResult& result) const;
};

struct ContractDefinition { std::string id,title,severity="error"; MetricPredicate predicate; double duration_s=0.0; };
struct ContractEvaluation { std::string id,title,severity; bool satisfied=true; double value=std::numeric_limits<double>::quiet_NaN(),violating_for_s=0.0,last_time_s=0.0; };
class LiveContractInvariantMonitor {
public:
    bool upsert(ContractDefinition contract,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::vector<ContractEvaluation> evaluate(double time_s,const std::map<std::string,double>& metrics);
    [[nodiscard]] std::vector<ContractEvaluation> states() const; [[nodiscard]] std::string report() const;
private:
    struct State { ContractDefinition definition; ContractEvaluation evaluation; double first_violation_s=std::numeric_limits<double>::quiet_NaN(); bool alerted=false; };
    std::map<std::string,State> contracts_;
};

struct StateMachineTransitionView { std::string from,to,event,guard; };
struct StateMachineView { std::string id,title,initial,active; std::set<std::string> states; std::vector<StateMachineTransitionView> transitions; std::vector<std::string> history; };
class GenericStateMachineExplorer {
public:
    bool create(std::string id,std::string title,std::string initial,std::string& error);
    bool add_state(std::string_view id,std::string state,std::string& error); bool add_transition(std::string_view id,StateMachineTransitionView transition,std::string& error);
    bool set_active(std::string_view id,std::string state,std::string& error); bool trigger(std::string_view id,std::string_view event,std::string& error);
    [[nodiscard]] std::optional<StateMachineView> machine(std::string_view id) const;
    [[nodiscard]] std::vector<std::string> machines() const;
    [[nodiscard]] std::string ribbon(std::string_view id,std::size_t max_transitions=6) const;
    [[nodiscard]] std::string report(std::string_view id={}) const; [[nodiscard]] std::string json(std::string_view id) const;
private: std::map<std::string,StateMachineView> machines_;
};

struct ErrorBudgetContribution { std::string id,category,unit,source; double sigma=0.0,sensitivity=1.0; };
class NumericalTrustErrorBudgetWorkbench {
public:
    bool upsert(ErrorBudgetContribution contribution,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] double combined_standard_uncertainty() const; [[nodiscard]] std::string report(const SolverConvergenceConsole* solver=nullptr) const; [[nodiscard]] std::string json() const;
private: std::map<std::string,ErrorBudgetContribution> contributions_;
};

class RunLineageBranchDagExplorer {
public:
    [[nodiscard]] std::string report(const ExperimentMatrix& experiments,std::string_view root={}) const;
    [[nodiscard]] std::string json(const ExperimentMatrix& experiments) const;
};

struct RealtimeDeadlineSample { std::string task; double release_ms=0,start_ms=0,finish_ms=0,deadline_ms=0,period_ms=0; };
class RealtimeDeadlineJitterAnalyzer {
public:
    bool append(RealtimeDeadlineSample sample,std::string& error); void clear();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::vector<RealtimeDeadlineSample> samples_;
};

struct CosimSynchronizationEvent { std::string participant,kind; double simulation_time_s=0,wall_time_ms=0,step_s=0,latency_ms=0; bool rollback=false,deadline_missed=false; };
class CosimulationSynchronizationAnalyzer {
public:
    bool append(CosimSynchronizationEvent event,std::string& error); void clear();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::vector<CosimSynchronizationEvent> events_;
};

struct CoverageArtifact { std::string id,kind,title,status; double coverage=std::numeric_limits<double>::quiet_NaN(); };
struct CoverageLink { std::string source,target,relation; };
class SourceRequirementTestCoverageExplorer {
public:
    bool upsert(CoverageArtifact artifact,std::string& error); bool link(CoverageLink link,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::map<std::string,CoverageArtifact> artifacts_; std::vector<CoverageLink> links_;
};

struct CyberAttackNode { std::string id,type,title,trust_zone,privilege; double risk=0.0; };
struct CyberAttackEdge { std::string source,target,technique,mitigation; double likelihood=1.0; };
class CyberAttackGraphWorkbench {
public:
    bool upsert(CyberAttackNode node,std::string& error); bool connect(CyberAttackEdge edge,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::vector<std::string> shortest_path(std::string_view source,std::string_view target) const;
    [[nodiscard]] std::string report(std::string_view source={},std::string_view target={}) const; [[nodiscard]] std::string json() const;
private: std::map<std::string,CyberAttackNode> nodes_; std::vector<CyberAttackEdge> edges_;
};

enum class NotebookCellKind : unsigned char { markdown,command,telemetry,evidence };
struct EngineeringNotebookCell { std::uint64_t id=0; NotebookCellKind kind=NotebookCellKind::markdown; std::string source,result,run_id,build_id,result_sha256; std::uint64_t executed_ms=0; };
struct EngineeringNotebookDocument { std::string id,title; std::vector<EngineeringNotebookCell> cells; std::uint64_t next_cell=1; };
class EmbeddedEngineeringNotebook {
public:
    bool create(std::string id,std::string title,std::string& error); bool add_cell(std::string_view id,NotebookCellKind kind,std::string source,std::string& error,std::uint64_t* cell_id=nullptr);
    bool start_investigation(std::string id,std::string title,std::string& error);
    bool investigation_note(std::string_view id,std::string text,std::string& error);
    bool investigation_capture(std::string_view id,std::string reference,std::string& error);
    bool finish_investigation(std::string_view id,std::string& error);
    bool set_result(std::string_view id,std::uint64_t cell,std::string result,std::string run_id,std::string build_id,std::string& error);
    bool erase(std::string_view id); [[nodiscard]] std::string report(std::string_view id={}) const;
    bool save(const std::filesystem::path& path,std::string& error) const; bool load(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] static std::optional<NotebookCellKind> parse_kind(std::string_view value); [[nodiscard]] static std::string kind_name(NotebookCellKind value);
private: std::map<std::string,EngineeringNotebookDocument> notebooks_; std::set<std::string> active_investigations_;
};

struct EvidenceReportSection { std::uint64_t id=0; std::string title,body,source_uri,sha256; };
class EvidenceLinkedReportComposer {
public:
    void reset(std::string title); std::uint64_t add(EvidenceReportSection section,std::string& error); bool remove(std::uint64_t id); void clear_sections();
    [[nodiscard]] std::string report() const; bool export_markdown(const std::filesystem::path& path,std::string& error) const;
private: std::string title_="Engineering Report"; std::map<std::uint64_t,EvidenceReportSection> sections_; std::uint64_t next_id_=1;
};

struct CrdtFieldValue { std::string value,actor; std::uint64_t logical_clock=0; bool tombstone=false; };
class CrdtCollaborativeDocumentStore {
public:
    bool set(std::string document,std::string key,std::string value,std::string actor,std::uint64_t clock,std::string& error);
    bool erase(std::string document,std::string key,std::string actor,std::uint64_t clock,std::string& error);
    bool merge(std::string_view target,std::string_view source,std::string& error); void clear();
    [[nodiscard]] std::string report(std::string_view document={}) const; bool save(const std::filesystem::path& path,std::string& error) const; bool load(const std::filesystem::path& path,std::string& error);
private: std::map<std::string,std::map<std::string,CrdtFieldValue>> documents_;
};

class SimulationDependencyHeatmapWorkbench {
public:
    [[nodiscard]] std::string report(const CausalDifferenceExplorer& causal) const;
    [[nodiscard]] std::string json(const CausalDifferenceExplorer& causal) const;
};
class AutomatedPerformanceRootCauseInvestigator {
public: [[nodiscard]] std::string analyze(const RuntimeProfiler& profiler,const SolverConvergenceConsole& solver,const DistributedTraceWaterfallWorkbench& trace) const;
};
class AutomatedCrossRunDivergenceInvestigator {
public: [[nodiscard]] std::string analyze(const ExperimentMatrix& experiments,const NWayRunComparisonWorkbench& runs,const CausalDifferenceExplorer& causal,std::string_view candidate,std::string_view target) const;
};
class RegressionFailureClusteringWorkbench {
public: [[nodiscard]] std::string report(const RegressionTriageDashboard& regressions) const; [[nodiscard]] std::string json(const RegressionTriageDashboard& regressions) const;
};

struct EngineeringAlertRule { std::string id,title,severity="warning"; MetricPredicate predicate; double duration_s=0,hysteresis=0; };
class EngineeringAlertRuleBuilder {
public:
    bool upsert(EngineeringAlertRule rule,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::vector<std::string> evaluate(double time_s,const std::map<std::string,double>& metrics,EngineeringMissionControl& mission);
    [[nodiscard]] std::string report() const;
private:
    struct State { EngineeringAlertRule rule; double first_true_s=std::numeric_limits<double>::quiet_NaN(); bool active=false; std::uint64_t alert_id=0; };
    std::map<std::string,State> rules_;
};

struct ProductFeature { std::string id,group,title; bool selected=false; };
struct ProductConstraint { std::string id,kind,left,right,detail; };
class VariantProductLineExplorer {
public:
    bool upsert(ProductFeature feature,std::string& error); bool add_constraint(ProductConstraint constraint,std::string& error); bool select(std::string_view id,bool selected,std::string& error); void clear();
    [[nodiscard]] std::vector<std::string> violations() const; [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::map<std::string,ProductFeature> features_; std::vector<ProductConstraint> constraints_;
};

struct ControlRoomHost { std::string id,address,state="unknown",run_id; double realtime_factor=0,cpu_percent=0,gpu_percent=std::numeric_limits<double>::quiet_NaN(); std::uint64_t last_seen_ms=0; };
class MultiHostEngineeringControlRoom {
public:
    bool upsert(ControlRoomHost host,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::string report() const; [[nodiscard]] std::string json() const;
private: std::map<std::string,ControlRoomHost> hosts_;
};

class BrowserEngineeringServer {
public:
    using StateProvider=std::function<std::string()>; using CommandExecutor=std::function<std::string(const std::string&)>;
    using SchemaProvider=std::function<std::string()>;
    using StreamProvider=std::function<std::string(std::uint64_t,const std::set<std::string>&,double,std::size_t,int)>;
    BrowserEngineeringServer(); ~BrowserEngineeringServer();
    BrowserEngineeringServer(const BrowserEngineeringServer&)=delete; BrowserEngineeringServer& operator=(const BrowserEngineeringServer&)=delete;
    bool start(std::string address,std::uint16_t port,StateProvider state,CommandExecutor execute,std::string& error,SchemaProvider schema={},StreamProvider stream={});
    void stop(); [[nodiscard]] bool running() const noexcept { return running_.load(); }
    [[nodiscard]] std::uint16_t port() const noexcept { return port_.load(); }
    [[nodiscard]] std::string token() const; [[nodiscard]] std::string url() const; [[nodiscard]] std::string report() const;
private:
    std::atomic<bool> running_{false}; std::atomic<int> listen_fd_{-1}; std::atomic<std::uint16_t> port_{0};
    std::thread thread_; std::mutex lifecycle_mutex_; mutable std::mutex mutex_;
    std::string bind_address_="127.0.0.1",token_; StateProvider state_; CommandExecutor execute_; SchemaProvider schema_; StreamProvider stream_;
    void serve();
};

class MultiSelectionRegistry {
public:
    bool add(std::string collection,std::string item);
    bool remove(std::string_view collection,std::string_view item);
    bool toggle(std::string collection,std::string item);
    void clear(std::string_view collection={});
    [[nodiscard]] bool selected(std::string_view collection,std::string_view item) const;
    [[nodiscard]] std::vector<std::string> items(std::string_view collection) const;
    [[nodiscard]] std::string report(std::string_view collection={}) const;
private:
    std::map<std::string,std::set<std::string>> selections_;
};

struct StagedCommand {
    std::uint64_t id=0;
    std::string command,canonical,preview;
    bool valid=false,mutating=false;
    std::string validation;
};
class CommandStagingQueue {
public:
    std::uint64_t add(StagedCommand command);
    bool erase(std::uint64_t id);
    bool move(std::uint64_t id,std::size_t one_based_position);
    void clear();
    void set_atomic(bool enabled) noexcept { atomic_=enabled; }
    [[nodiscard]] bool atomic() const noexcept { return atomic_; }
    [[nodiscard]] std::vector<StagedCommand> entries() const;
    [[nodiscard]] bool committable(std::string& reason) const;
    [[nodiscard]] std::vector<std::string> commands() const;
    [[nodiscard]] std::string report() const;
private:
    std::vector<StagedCommand> commands_;
    std::uint64_t next_id_=1;
    bool atomic_=false;
};

struct RecordedCommandMacro {
    std::string name;
    std::vector<std::string> commands;
    std::map<std::string,std::string> defaults;
};
class CommandMacroLibrary {
public:
    bool start(std::string name,std::string& error);
    bool record(std::string command);
    bool stop(std::string& error);
    void cancel();
    bool erase(std::string_view name);
    bool parameterize(std::string_view name,std::string literal,std::string parameter,std::string default_value,std::string& error);
    [[nodiscard]] std::vector<std::string> expand(std::string_view name,const std::map<std::string,std::string>& arguments,std::string& error) const;
    [[nodiscard]] bool recording() const noexcept { return recording_.has_value(); }
    [[nodiscard]] std::string recording_name() const { return recording_ ? recording_->name : std::string{}; }
    [[nodiscard]] std::string report(std::string_view name={}) const;
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
private:
    std::map<std::string,RecordedCommandMacro> macros_;
    std::optional<RecordedCommandMacro> recording_;
};

struct FrameJankEvent {
    std::uint64_t sequence=0,wall_ms=0;
    double frame_ms=0.0,threshold_ms=0.0;
    int rows=0,columns=0;
    std::string context;
};
class FrameJankDetector {
public:
    void configure(double threshold_ms,std::size_t capacity=128);
    void observe(double frame_ms,int rows,int columns,std::string context);
    void clear();
    [[nodiscard]] std::vector<FrameJankEvent> events(std::size_t limit=20) const;
    [[nodiscard]] std::string report(std::size_t limit=20) const;
private:
    double threshold_ms_=40.0; std::size_t capacity_=128; std::uint64_t next_sequence_=1; std::deque<FrameJankEvent> events_;
};

struct EngineeringUiSuite {
    EngineeringUiSuite();
    TerminalCapabilities terminal; globalui::ContextGraph context; HitTestMap hit_test; DashboardDesigner dashboard_designer;
    SynchronizedTimeCursor time_cursor; TelemetryWorkbench scope; DashboardReferenceOverlay dashboard_reference; TransientInvestigationLens transient_lens; ProtocolTraceAnalyzer trace; ConfigurationDiffViewer diff;
    WorkflowGraphEditor workflow_editor; SolverConvergenceConsole solver; RuntimeProfiler profiler; ExperimentMatrix experiments;
    ArtifactEvidenceBrowser artifacts; RegressionTriageDashboard regressions; PersistentSessionRegistry sessions;
    globalui::JobManager mission_jobs; EngineeringMissionControl mission_control; ProfessionalDiagnosticCenter diagnostic_center; NWayRunComparisonWorkbench run_compare; CausalDifferenceExplorer causal_difference;
    RequirementsVerificationEvidenceMatrix verification_matrix; DesignSpaceExplorer design_space; EngineeringFlightRecorder flight_recorder;
    HighResolutionRenderer graphics; StructuredGlobalSearch search; CliGuiEquivalenceRegistry equivalence; TerminalOscIntegration osc; NavigationContext navigation; TuiPaneLayoutManager tui_layout;
    SchemaDrivenEngineeringDesktop desktop; RealTimeTelemetryStreamingFabric streaming; CampaignOrchestrationResourcePlanner campaign;
    AdaptiveDoeOptimizationStudio adaptive_doe; VisualScenarioEventTimelineComposer scenario_timeline; WorkflowExecutionDebugger workflow_debugger;
    QualificationReviewApprovalCenter qualification_reviews; LiveEeCosimulationTopologyCanvas topology;
    DerivedSignalVirtualChannelLaboratory virtual_channels; InstrumentGradePlotMeasurementToolkit plot_measurements; LinkedEngineeringCursorBus linked_cursors;
    EngineeringDigitalTwinViewport3D twin_viewport; ElectronicQualificationRunbook runbook;
    ChangeQualificationReleasePlanner release_planner; UnifiedEngineeringDataCatalog data_catalog;
    InteractiveCalibrationCorrelationWorkbench calibration_correlation; RealTimeCollaborativeEngineeringSession collaboration_session;
    FormalVerificationCounterexampleExplorer formal_verification; MultiphysicsFieldVisualizationWorkbench field_visualization; SparseJacobianInspector jacobian_inspector;
    DistributedTraceWaterfallWorkbench distributed_trace; HpcHardwarePlacementWorkbench hpc_placement; GraphicalSafetyAnalysisWorkbench safety_analysis;
    DeterministicTemporalBisectionDebugger temporal_bisection; LiveContractInvariantMonitor contract_monitor; GenericStateMachineExplorer state_machine_explorer;
    NumericalTrustErrorBudgetWorkbench numerical_trust; RunLineageBranchDagExplorer run_lineage; RealtimeDeadlineJitterAnalyzer realtime_deadlines;
    CosimulationSynchronizationAnalyzer cosim_sync; SourceRequirementTestCoverageExplorer coverage_explorer; CyberAttackGraphWorkbench cyber_attack_graph;
    EmbeddedEngineeringNotebook notebook; EvidenceLinkedReportComposer report_composer; CrdtCollaborativeDocumentStore crdt_documents;
    SimulationDependencyHeatmapWorkbench dependency_heatmap; AutomatedPerformanceRootCauseInvestigator performance_investigator; AutomatedCrossRunDivergenceInvestigator divergence_investigator;
    RegressionFailureClusteringWorkbench failure_clustering; EngineeringAlertRuleBuilder alert_rules; SequenceOfEventsAnalyzer sequence_of_events; VariantProductLineExplorer product_line; MultiHostEngineeringControlRoom control_room;
    MultiSelectionRegistry selections; CommandStagingQueue command_staging; CommandMacroLibrary macros;
    SemanticHighlightExplainer highlight_explainer; WhatChangedInvestigator what_changed; MetricProvenanceGraphProjector provenance_graph;
    ControlLoopHysteresisVisualizer hysteresis; StatisticalBaselineEnvelope statistical_envelope; AlarmFloodChatterAnalyzer alarm_flood; FrameJankDetector jank_detector;
    terminalws::TerminalWorkstationPlatform terminal_workstation;
    BrowserEngineeringServer browser;
    void update_live_signals(double time_s,const std::map<std::string,double>& signals);
    [[nodiscard]] std::string capability_report() const;
};

} // namespace sim::console::engineeringui

#pragma once

#include "aesim/app/global_ui_architecture.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::terminalws {

struct GridColumn { std::string id,title; std::size_t width=12; bool visible=true,frozen=false; };
using GridRow = std::map<std::string,std::string>;
struct GridFilter { std::string column,contains; bool case_sensitive=false; };
class VirtualGrid {
public:
    void set_columns(std::vector<GridColumn> columns);
    void set_rows(std::vector<GridRow> rows);
    bool sort(std::string_view column, bool ascending, std::string& error);
    void set_filter(GridFilter filter); void clear_filter();
    void set_viewport(std::size_t first,std::size_t count);
    bool select(std::size_t visible_index,bool extend,std::string& error);
    [[nodiscard]] std::vector<GridRow> visible_rows() const;
    [[nodiscard]] std::string render(std::size_t terminal_width=120) const;
    [[nodiscard]] std::string export_csv(bool selected_only=false) const;
    [[nodiscard]] std::size_t total_rows() const noexcept { return rows_.size(); }
private:
    std::vector<GridColumn> columns_; std::vector<GridRow> rows_;
    std::optional<GridFilter> filter_; std::size_t first_=0,count_=24;
    std::set<std::size_t> selected_source_rows_;
    [[nodiscard]] std::vector<std::size_t> filtered_indices() const;
};

struct PlotSeries { std::string id,label,unit; std::vector<std::pair<double,double>> samples; };
struct PlotCursor { std::string name; double x=0; bool enabled=false,snap=true; };
enum class PlotMode : unsigned char { time_series, xy, scatter, histogram, fft, psd, bode, nyquist };
class ScientificPlotSurface {
public:
    void set_mode(PlotMode mode) noexcept { mode_=mode; }
    void upsert(PlotSeries series); bool erase(std::string_view id);
    void viewport(double xmin,double xmax,double ymin,double ymax); void autoscale();
    void pan(double dx,double dy); void zoom(double factor,double center_x,double center_y);
    bool cursor(std::string name,double x,bool snap,std::string& error);
    [[nodiscard]] std::optional<double> nearest_value(std::string_view series,double x) const;
    [[nodiscard]] std::string measure() const;
    [[nodiscard]] std::string render(std::size_t width=90,std::size_t height=20) const;
private:
    PlotMode mode_=PlotMode::time_series; std::map<std::string,PlotSeries> series_; std::map<std::string,PlotCursor> cursors_;
    double xmin_=0,xmax_=1,ymin_=0,ymax_=1; bool auto_=true;
};

struct TransportObservation { double frame_ms=0,bytes=0,input_latency_ms=0,jitter_ms=0,dirty_ratio=1; };
struct AdaptiveRenderPolicy { int frame_interval_ms=100; int scope_interval_ms=100; bool animations=true,graphics=true,synchronized_updates=true; std::size_t byte_budget=262144; };
class AdaptiveRemoteRenderer {
public:
    void set_remote(bool remote) noexcept { remote_=remote; }
    void observe(TransportObservation observation);
    [[nodiscard]] AdaptiveRenderPolicy policy() const;
    [[nodiscard]] std::string report() const;
private:
    bool remote_=false; std::vector<TransportObservation> history_;
};

struct CaptureTrigger { std::string id,signal; double threshold=0; bool greater=true; double pre_s=10,post_s=30; bool armed=true; };
struct InvestigationCapture { std::uint64_t id=0; std::string trigger; double event_s=0,begin_s=0,end_s=0; std::map<std::string,std::string> evidence; bool complete=false; };
class TriggeredInvestigationManager {
public:
    bool add(CaptureTrigger trigger,std::string& error); bool remove(std::string_view id); void clear();
    std::optional<std::uint64_t> observe(std::string_view signal,double time_s,double value);
    void attach(std::uint64_t id,std::string key,std::string value); void complete(double time_s);
    [[nodiscard]] std::vector<InvestigationCapture> captures() const; [[nodiscard]] std::string report() const;
private: std::map<std::string,CaptureTrigger> triggers_; std::vector<InvestigationCapture> captures_; std::uint64_t next_id_=1; std::map<std::string,double> previous_;
};

enum class AlarmState : unsigned char { active, acknowledged, returned_to_normal, shelved, suppressed, out_of_service };
struct ManagedAlarm { std::uint64_t id=0; std::string source,message,severity,reason; AlarmState state=AlarmState::active; std::uint64_t raised_ms=0,changed_ms=0,shelve_until_ms=0; std::size_t occurrences=1; };
class ProfessionalAlarmManager {
public:
    std::uint64_t raise(std::string source,std::string severity,std::string message,std::uint64_t now_ms);
    bool acknowledge(std::uint64_t id,std::string actor,std::uint64_t now_ms,std::string& error);
    bool return_to_normal(std::uint64_t id,std::uint64_t now_ms,std::string& error);
    bool shelve(std::uint64_t id,std::uint64_t duration_ms,std::string reason,std::uint64_t now_ms,std::string& error);
    bool suppress(std::uint64_t id,std::string reason,std::uint64_t now_ms,std::string& error);
    void tick(std::uint64_t now_ms);
    [[nodiscard]] std::vector<ManagedAlarm> alarms(bool include_inactive=true) const; [[nodiscard]] std::string report(std::uint64_t now_ms) const;
private: std::map<std::uint64_t,ManagedAlarm> alarms_; std::uint64_t next_id_=1;
};

struct PresentationRule { std::string dimension,unit; int precision=3; double scientific_below=1e-4,scientific_above=1e7; };
class PresentationProfiles {
public:
    PresentationProfiles();
    bool select(std::string_view name,std::string& error); bool define(std::string name,std::map<std::string,PresentationRule> rules,std::string& error);
    [[nodiscard]] std::string active() const { return active_; }
    [[nodiscard]] std::string format(double si_value,std::string_view canonical_unit,std::string_view dimension,const globalui::UnitRegistry& units) const;
    [[nodiscard]] std::string report() const;
private: std::map<std::string,std::map<std::string,PresentationRule>> profiles_; std::string active_="si";
};

struct PanePluginDescriptor { std::string plugin_id,pane_id,title,provider; std::set<std::string> object_kinds; std::vector<std::string> context_actions; };
class TuiPluginWorkbenchRegistry {
public:
    bool register_pane(PanePluginDescriptor descriptor,std::string& error); bool unregister_plugin(std::string_view plugin_id);
    [[nodiscard]] std::vector<PanePluginDescriptor> panes() const; [[nodiscard]] std::vector<std::string> actions(std::string_view object_kind) const; [[nodiscard]] std::string report() const;
private: std::map<std::string,PanePluginDescriptor> panes_;
};

enum class ArtifactKind : unsigned char { text,json,csv,unknown };
struct ArtifactInspection { ArtifactKind kind=ArtifactKind::unknown; std::filesystem::path path; std::uintmax_t bytes=0; std::size_t rows=0,columns=0; std::vector<std::string> headings; std::string preview; };
class StructuredArtifactInspector {
public: [[nodiscard]] ArtifactInspection inspect(const std::filesystem::path& path,std::size_t preview_rows=20) const; [[nodiscard]] std::string report(const ArtifactInspection&) const;
};

struct TerminalProbeResult { std::string name; bool pass=false; std::string detail; };
struct TerminalQualification { std::vector<TerminalProbeResult> probes; std::string recommended_refresh,recommended_graphics,recommended_density; int estimated_latency_ms=0; };
class TerminalQualificationWizard {
public:
    [[nodiscard]] TerminalQualification qualify(bool tty,bool ssh,std::string_view term,std::string_view colorterm,int columns,int rows,bool utf8,bool sixel,bool kitty,bool mouse,bool sync_updates) const;
    [[nodiscard]] std::string report(const TerminalQualification&) const;
};

struct SemanticContextAction { std::string object_kind,label,command; int priority=0; };
class SemanticContextActions {
public:
    bool register_action(SemanticContextAction action,std::string& error); bool unregister_action(std::string_view kind,std::string_view command);
    [[nodiscard]] std::vector<SemanticContextAction> actions(std::string_view kind) const; [[nodiscard]] std::string report(std::string_view kind) const;
private: std::vector<SemanticContextAction> actions_;
};

struct WorkspaceRule { std::string id,metric,comparison,action; double threshold=0; bool enabled=true,edge_triggered=true; };
class WorkspaceAutomationRules {
public:
    bool add(WorkspaceRule rule,std::string& error); bool remove(std::string_view id); void clear();
    [[nodiscard]] std::vector<std::string> evaluate(const std::map<std::string,double>& metrics);
    [[nodiscard]] std::string report() const;
private: std::map<std::string,WorkspaceRule> rules_; std::map<std::string,bool> previous_truth_;
};


// Terminal engineering IDE orchestration. These classes own only presentation,
// authoring, or investigation state. Authoritative simulation/calibration/test/HIL
// state remains in the existing EngineeringUiSuite and backend services.
struct EngineeringGraphNode { std::string id,label,kind; std::map<std::string,std::string> attributes; };
struct EngineeringGraphEdge { std::string from,to,kind,label; double weight=1.0; };
class UnifiedEngineeringGraphExplorer {
public:
    void clear(); bool upsert(EngineeringGraphNode node,std::string& error); bool connect(EngineeringGraphEdge edge,std::string& error);
    [[nodiscard]] std::vector<std::string> shortest_path(std::string_view from,std::string_view to) const;
    [[nodiscard]] std::vector<std::string> neighborhood(std::string_view id,std::size_t depth=1) const;
    [[nodiscard]] std::string inspect(std::string_view id) const;
    [[nodiscard]] std::string render(std::string_view root={},std::size_t depth=3,std::size_t width=100) const;
    [[nodiscard]] std::size_t node_count() const noexcept { return nodes_.size(); }
    [[nodiscard]] std::size_t edge_count() const noexcept { return edges_.size(); }
private: std::map<std::string,EngineeringGraphNode> nodes_; std::vector<EngineeringGraphEdge> edges_;
};

struct CalibrationSelection { std::size_t x0=0,y0=0,x1=0,y1=0; bool active=false; };
class CalibrationEditorState {
public:
    bool select(std::size_t x0,std::size_t y0,std::size_t x1,std::size_t y1,std::string& error);
    void clear() noexcept { selection_={}; }
    [[nodiscard]] CalibrationSelection selection() const noexcept { return selection_; }
    [[nodiscard]] std::string report() const;
private: CalibrationSelection selection_{};
};

struct ExperimentVariable { std::string name,unit; std::vector<double> values; };
struct ExperimentConstraint { std::string variable,comparison; double value=0.0; };
struct ComposedExperiment { std::string id,scenario; std::uint64_t seed=1; std::map<std::string,double> parameters; };
class ScenarioExperimentComposer {
public:
    void reset(std::string scenario="scenario",std::uint64_t seed=1);
    bool variable(ExperimentVariable variable,std::string& error); bool constraint(ExperimentConstraint constraint,std::string& error);
    bool erase_variable(std::string_view name); void clear_constraints();
    [[nodiscard]] std::size_t combinations() const; [[nodiscard]] std::vector<ComposedExperiment> materialize(std::size_t limit=100000) const;
    [[nodiscard]] std::string report() const;
private: std::string scenario_="scenario"; std::uint64_t seed_=1; std::map<std::string,ExperimentVariable> variables_; std::vector<ExperimentConstraint> constraints_;
};

enum class SessionEventKind : unsigned char { command,selection,layout,plot,alarm,note,artifact,context_action };
struct RecordedSessionEvent { std::uint64_t sequence=0,elapsed_ms=0; SessionEventKind kind=SessionEventKind::command; std::string value,detail; };
class DeterministicTuiSessionRecorder {
public:
    bool start(std::string id,std::string& error); bool record(SessionEventKind kind,std::string value,std::string detail={});
    bool stop(std::string& error); void clear(); [[nodiscard]] bool recording() const noexcept { return recording_; }
    [[nodiscard]] std::vector<RecordedSessionEvent> events() const { return events_; }
    [[nodiscard]] std::vector<std::string> replay_commands() const;
    bool save(const std::filesystem::path& path,std::string& error) const; bool load(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] std::string report() const;
private: std::string id_; bool recording_=false; std::uint64_t next_=1,start_ms_=0; std::vector<RecordedSessionEvent> events_;
};

struct DistributedNodeObservation { std::string id,host,state="unknown"; int rank=-1; double cpu_percent=0,gpu_percent=0,memory_percent=0,events_per_second=0,rollback_percent=0,realtime_factor=0; };
struct PdesOperationSnapshot { double global_virtual_time_s=0,lag_s=0,network_mbps=0,partition_skew_percent=0; std::size_t checkpoints=0,rollbacks=0; };
class HpcDistributedOperationsCockpit {
public:
    bool upsert(DistributedNodeObservation observation,std::string& error); bool erase(std::string_view id); void clear();
    void pdes(PdesOperationSnapshot snapshot) noexcept { pdes_=snapshot; }
    [[nodiscard]] std::string report() const;
private: std::map<std::string,DistributedNodeObservation> nodes_; PdesOperationSnapshot pdes_{};
};

struct ScheduledFault { std::uint64_t id=0; std::string domain,target,mode,canonical_command; double start_s=0,duration_s=0,probability=1.0; bool enabled=true; };
struct FalsificationProgress { std::string property,algorithm; std::size_t evaluations=0,limit=0; double best_robustness=std::numeric_limits<double>::infinity(); std::map<std::string,double> best_parameters; };
class FaultFalsificationConsole {
public:
    std::uint64_t schedule(ScheduledFault fault,std::string& error); bool erase(std::uint64_t id); void clear();
    [[nodiscard]] std::vector<ScheduledFault> active(double time_s) const; [[nodiscard]] std::vector<std::string> commands(double time_s) const;
    void falsification(FalsificationProgress progress); [[nodiscard]] FalsificationProgress falsification() const { return falsification_; }
    [[nodiscard]] std::string report(double time_s=0) const;
private: std::map<std::uint64_t,ScheduledFault> faults_; std::uint64_t next_id_=1; FalsificationProgress falsification_{};
};

struct UniversalQueryRecord { std::string kind,id; std::map<std::string,std::string> text; std::map<std::string,double> numeric; };
struct UniversalQueryResult { std::vector<UniversalQueryRecord> records; std::string normalized; std::size_t scanned=0; };
class UniversalTelemetryEvidenceQueryWorkbench {
public:
    [[nodiscard]] UniversalQueryResult execute(std::string_view query,const std::vector<UniversalQueryRecord>& source) const;
    [[nodiscard]] std::string render(const UniversalQueryResult& result,std::size_t limit=100) const;
};

struct QualificationObservation { std::string name,state,detail; double seconds=0; std::uint64_t timestamp_ms=0; };
class TestQualificationOperationsCenter {
public:
    void ingest(std::vector<QualificationObservation> observations); void clear();
    [[nodiscard]] std::string report(bool failures_only=false) const; [[nodiscard]] std::vector<QualificationObservation> history(std::string_view name) const;
private: std::vector<QualificationObservation> history_;
};

struct TraceProfileSpan { std::string name,category; double begin_ms=0,end_ms=0; int rank=-1; };
class PerformanceCriticalPathExplorer {
public:
    void set(std::vector<TraceProfileSpan> spans); [[nodiscard]] std::string flamegraph(std::size_t width=80,std::size_t rows=16) const;
    [[nodiscard]] std::vector<TraceProfileSpan> critical_path() const;
private: std::vector<TraceProfileSpan> spans_;
};

struct CrossDomainEvent { std::uint64_t id=0; double time_s=0,duration_s=0; std::string domain,title,detail; };
class CrossDomainTimeline2 {
public:
    std::uint64_t add(CrossDomainEvent event); bool erase(std::uint64_t id); void clear();
    [[nodiscard]] std::vector<CrossDomainEvent> query(double begin_s,double end_s,std::string_view domain={}) const;
    [[nodiscard]] std::string render(double begin_s,double end_s,std::size_t width=100) const;
private: std::map<std::uint64_t,CrossDomainEvent> events_; std::uint64_t next_id_=1;
};

struct BuildDiagnostic { std::string severity,file,message,target; int line=0,column=0; };
struct BuildTargetTiming { std::string target; double seconds=0; };
class BuildCompilerDiagnosticsWorkbench {
public:
    void clear(); void ingest_line(std::string line); bool load_log(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] std::vector<BuildDiagnostic> diagnostics(std::string_view severity={}) const;
    [[nodiscard]] std::string report(std::size_t limit=80) const;
private: std::vector<BuildDiagnostic> diagnostics_; std::vector<BuildTargetTiming> timings_; std::size_t steps_done_=0,steps_total_=0;
};

struct HilInstrumentRecord { std::string id,transport,address,state="offline"; double latency_ms=0; std::uint64_t reads=0,writes=0,errors=0; bool safe=false; };
class HilInstrumentOperationsConsole {
public:
    bool upsert(HilInstrumentRecord record,std::string& error); bool erase(std::string_view id); void clear();
    bool set_state(std::string_view id,std::string state,double latency_ms,std::string& error); bool safe_state(std::string_view id,std::string& error);
    [[nodiscard]] std::string report() const;
private: std::map<std::string,HilInstrumentRecord> instruments_;
};

class SemanticAccessibilityMode {
public:
    void set_enabled(bool enabled) noexcept { enabled_=enabled; } [[nodiscard]] bool enabled() const noexcept { return enabled_; }
    [[nodiscard]] std::string linearize(std::string_view terminal_frame) const;
    [[nodiscard]] std::string metrics(const std::map<std::string,double>& values,const std::map<std::string,std::string>& states={}) const;
private: bool enabled_=false;
};

struct TerminalWorkstationPlatform {
    VirtualGrid grid; ScientificPlotSurface plot; AdaptiveRemoteRenderer remote;
    TriggeredInvestigationManager investigations; ProfessionalAlarmManager alarms;
    PresentationProfiles presentation; TuiPluginWorkbenchRegistry plugins; StructuredArtifactInspector artifact_inspector;
    TerminalQualificationWizard qualification;
    SemanticContextActions context_actions; WorkspaceAutomationRules automation;
    UnifiedEngineeringGraphExplorer graph; CalibrationEditorState calibration_editor; ScenarioExperimentComposer composer;
    DeterministicTuiSessionRecorder session_recorder; HpcDistributedOperationsCockpit hpc_cockpit; FaultFalsificationConsole fault_console;
    UniversalTelemetryEvidenceQueryWorkbench query; TestQualificationOperationsCenter qualification_center; PerformanceCriticalPathExplorer performance_trace;
    CrossDomainTimeline2 timeline2; BuildCompilerDiagnosticsWorkbench build_diagnostics; HilInstrumentOperationsConsole hil_console; SemanticAccessibilityMode accessibility;
    TerminalWorkstationPlatform();
    [[nodiscard]] std::string capability_report() const;
};

} // namespace sim::console::terminalws

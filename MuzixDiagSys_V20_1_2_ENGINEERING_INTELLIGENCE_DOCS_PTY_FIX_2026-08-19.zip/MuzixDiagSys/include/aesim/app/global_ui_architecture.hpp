#pragma once
#include "aesim/app/ui_experience.hpp"
#include <chrono>
#include <filesystem>
#include <deque>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>

namespace sim::console::globalui {

using PropertyBag = std::map<std::string, std::string>;

enum class RichParameterType : unsigned char {
    text, integer, real, boolean, enumeration, multi_select, path, directory,
    timestamp, duration, frequency, quantity, vector, matrix, range,
    object_reference, artifact_reference, expression, table, structured_object, secret
};
enum class ProvenanceKind : unsigned char { default_value, project, workspace, object, preset, dataset, live, derived, user, command_line };
enum class WorkflowNodeType : unsigned char { action, form, validation, decision, parallel_group, approval, wait_condition, review, artifact, subworkflow, checkpoint };
enum class JobState : unsigned char { queued, running, paused, blocked, completed, failed, cancelled };
enum class WidgetKind : unsigned char { numeric, status, gauge, sparkline, time_series, histogram, distribution, heatmap, matrix, table, progress, state_machine, timeline, map_summary, graph, flow, pareto, confidence, coverage, issues, artifacts, note, actions };
enum class SplitOrientation : unsigned char { horizontal, vertical };

struct ObjectId {
    std::string type;
    std::string id;
    [[nodiscard]] std::string uri() const;
    [[nodiscard]] static std::optional<ObjectId> parse(std::string_view uri);
    bool operator==(const ObjectId& other) const noexcept { return type == other.type && id == other.id; }
    bool operator<(const ObjectId& other) const noexcept { return type < other.type || (type == other.type && id < other.id); }
};

struct ContextNode {
    ObjectId object;
    std::string display_name;
    PropertyBag properties;
    std::map<std::string, double> metrics;
    std::set<std::string> capabilities;
    std::vector<ObjectId> children;
    std::vector<ObjectId> related;
    std::uint64_t revision = 0;
};

class ContextGraph {
public:
    bool upsert(ContextNode node);
    bool erase(const ObjectId& id);
    [[nodiscard]] const ContextNode* find(const ObjectId& id) const;
    [[nodiscard]] std::vector<ContextNode> children(const ObjectId& id) const;
    [[nodiscard]] std::vector<ContextNode> search(std::string_view query, std::size_t limit = 100) const;
    void select(std::optional<ObjectId> id);
    [[nodiscard]] std::optional<ObjectId> selection() const;
    [[nodiscard]] std::string explorer(bool collapsed = false) const;
    [[nodiscard]] std::string inspect(const ObjectId& id) const;
private:
    std::map<ObjectId, ContextNode> nodes_;
    std::optional<ObjectId> selection_;
};

struct ValueProvenance {
    ProvenanceKind kind = ProvenanceKind::default_value;
    std::string source_uri;
    std::string original_value;
    std::string transformation;
    std::uint64_t timestamp_ms = 0;
    double confidence = 1.0;
};

struct RichParameterMetadata {
    std::string name;
    std::string label;
    std::string description;
    RichParameterType type = RichParameterType::text;
    std::string canonical_unit;
    std::vector<std::string> display_units;
    std::string default_value;
    bool required = false;
    bool sensitive = false;
    std::optional<double> minimum;
    std::optional<double> maximum;
    std::vector<std::string> choices;
    std::string visible_when;
    std::string enabled_when;
    std::string required_when;
    std::string validation_expression;
    std::vector<std::string> dependencies;
    std::vector<std::string> conflicts_with;
};

struct RichFieldState {
    RichParameterMetadata metadata;
    std::string value;
    std::string display_unit;
    ValueProvenance provenance;
    bool visible = true;
    bool enabled = true;
    bool required = false;
    bool valid = true;
    std::string validation_message;
};

class UnitRegistry {
public:
    UnitRegistry();
    void register_unit(std::string symbol, std::string dimension, double scale, double offset = 0.0);
    [[nodiscard]] std::optional<double> convert(double value, std::string_view from, std::string_view to) const;
    [[nodiscard]] std::optional<std::pair<double,std::string>> parse_quantity(std::string_view value) const;
private:
    struct Unit { std::string dimension; double scale; double offset; };
    std::map<std::string, Unit> units_;
};

class RichForm {
public:
    RichForm(std::string command, std::vector<RichParameterMetadata> fields, const UnitRegistry* units = nullptr);
    bool set(std::string_view name, std::string value, ProvenanceKind source, std::string& error);
    void evaluate_conditions();
    [[nodiscard]] bool valid() const;
    [[nodiscard]] std::string command() const;
    [[nodiscard]] std::string report(bool include_hidden = false) const;
    [[nodiscard]] const std::vector<RichFieldState>& fields() const noexcept { return fields_; }
private:
    std::string command_;
    std::vector<RichFieldState> fields_;
    const UnitRegistry* units_;
    [[nodiscard]] bool expression_true(std::string_view expr) const;
    void validate(RichFieldState& field);
};

class UiDomainProvider {
public:
    virtual ~UiDomainProvider() = default;
    [[nodiscard]] virtual std::string id() const = 0;
    [[nodiscard]] virtual std::string title() const = 0;
    [[nodiscard]] virtual std::vector<ux::CommandMetadata> commands() const = 0;
    [[nodiscard]] virtual std::vector<ux::WorkflowDefinition> workflows() const = 0;
    [[nodiscard]] virtual std::vector<ux::CustomDashboard> dashboards() const = 0;
    [[nodiscard]] virtual std::vector<ux::ActionItem> contextual_actions(const ContextGraph&) const = 0;
    [[nodiscard]] virtual std::vector<ux::Issue> evaluate_issues(const ContextGraph&) const = 0;
};

class ProviderRegistry {
public:
    bool add(std::shared_ptr<UiDomainProvider> provider, std::string& error);
    bool remove(std::string_view id);
    [[nodiscard]] std::vector<std::shared_ptr<UiDomainProvider>> providers() const;
    [[nodiscard]] std::vector<ux::CommandMetadata> commands() const;
    [[nodiscard]] std::vector<ux::WorkflowDefinition> workflows() const;
private:
    mutable std::shared_mutex mutex_;
    std::map<std::string, std::shared_ptr<UiDomainProvider>> providers_;
};

struct WorkflowNode {
    std::string id;
    std::string title;
    WorkflowNodeType type = WorkflowNodeType::action;
    std::vector<std::string> commands;
    std::string entry_condition;
    std::string completion_condition;
    std::size_t retry_limit = 0;
    std::vector<std::string> parallel_children;
};
struct WorkflowEdge { std::string from; std::string to; std::string condition; };
struct WorkflowGraph { std::string id; std::string title; std::map<std::string, WorkflowNode> nodes; std::vector<WorkflowEdge> edges; std::string start; };

class WorkflowEngine {
public:
    bool register_graph(WorkflowGraph graph, std::string& error);
    bool start(std::string_view id, std::string& error);
    bool complete(std::string_view node, bool success, std::string& error);
    bool record_start(std::string name, std::string& error);
    void record_command(std::string canonical_command);
    std::optional<WorkflowGraph> record_stop(std::string& error);
    [[nodiscard]] std::vector<std::string> ready_nodes() const;
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string, WorkflowGraph> graphs_;
    std::optional<std::string> active_;
    std::set<std::string> completed_;
    std::set<std::string> failed_;
    std::optional<WorkflowGraph> recording_;
};

struct Job {
    std::uint64_t id = 0;
    std::string title;
    std::string command;
    JobState state = JobState::queued;
    double progress = 0.0;
    int priority = 0;
    std::uint64_t created_ms = 0;
    std::uint64_t started_ms = 0;
    std::uint64_t completed_ms = 0;
    std::size_t cpu_threads = 1;
    std::size_t memory_bytes = 0;
    std::vector<std::uint64_t> children;
    std::vector<ux::ArtifactReference> artifacts;
    std::string log;
};

class JobManager {
public:
    std::uint64_t submit(Job job);
    bool transition(std::uint64_t id, JobState state, std::string& error);
    bool update(std::uint64_t id, double progress, std::string append_log = {});
    bool cancel(std::uint64_t id, std::string& error);
    [[nodiscard]] std::optional<Job> get(std::uint64_t id) const;
    [[nodiscard]] std::vector<Job> list() const;
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_;
    std::map<std::uint64_t, Job> jobs_;
    std::uint64_t next_id_ = 1;
};

struct ActivityEvent { std::uint64_t id=0, timestamp_ms=0; std::string kind, title, detail, object_uri; };
class ActivityTimeline {
public:
    std::uint64_t append(ActivityEvent event);
    [[nodiscard]] std::vector<ActivityEvent> query(std::string_view term, std::size_t limit = 100) const;
    [[nodiscard]] std::string report(std::size_t limit = 50) const;
private:
    std::deque<ActivityEvent> events_;
    std::uint64_t next_id_ = 1;
};

struct TabState { std::string id, title, object_uri, dashboard; std::size_t scroll=0; bool pinned=false; };
struct SplitState { SplitOrientation orientation=SplitOrientation::horizontal; std::string first_tab, second_tab; double ratio=0.5; };
struct RestorableWorkspace {
    std::uint32_t schema_version = 3;
    std::string name;
    std::vector<TabState> tabs;
    std::optional<SplitState> split;
    std::string selected_object;
    std::set<std::string> expanded_objects;
    std::string inspector_section="Summary";
    std::string active_form;
    std::string active_workflow;
    std::string search_query;
    std::map<std::string,std::string> filters;
    std::string dashboard_time_window="live";
};

class WorkspacePersistence {
public:
    static constexpr std::uint32_t current_schema = 3;
    bool save(const std::string& path, const RestorableWorkspace& state, std::string& error) const;
    std::optional<RestorableWorkspace> load(const std::string& path, std::string& error) const;
    [[nodiscard]] RestorableWorkspace migrate(RestorableWorkspace state, std::uint32_t from) const;
};

struct LayoutCell { std::string widget_id; int row=0,col=0,width=1,height=1; int min_columns=20; };
struct RichWidget {
    std::string id,title;
    WidgetKind kind=WidgetKind::numeric;
    std::string data_source;
    std::string compact_kind="numeric";
    std::string drilldown_uri;
    int refresh_ms=1000;
    // Presentation-only metadata. These fields never alter solver state or the
    // canonical telemetry value; they control how an existing signal is shown.
    std::string display_unit;
    int precision=-1;
    std::string group;
    bool visible=true;
    std::optional<double> warning_threshold;
    std::optional<double> critical_threshold;
};
struct DashboardLayout { std::string id,title; int columns=12; std::vector<LayoutCell> cells; std::map<std::string,RichWidget> widgets; };

class DashboardEngine {
public:
    bool register_layout(DashboardLayout layout, std::string& error);
    bool link(std::string source_widget, std::string target_widget, std::string& error);
    void select(std::string widget, std::string key, std::string value);
    void clear_selection();
    [[nodiscard]] std::map<std::string,std::string> effective_filters(std::string_view widget) const;
    [[nodiscard]] std::string render(std::string_view id, const ContextGraph& graph, int columns) const;
private:
    std::map<std::string,DashboardLayout> layouts_;
    std::multimap<std::string,std::string> links_;
    std::map<std::string,std::string> selection_;
};

struct CompareDifference { std::string field, left, right, classification; };
[[nodiscard]] std::vector<CompareDifference> compare(const ContextNode& left, const ContextNode& right);

struct ImpactAnalysis {
    std::string command;
    std::vector<std::string> affected_objects;
    std::vector<std::string> invalidated_results;
    std::vector<std::string> stale_evidence;
    std::vector<std::string> hardware_actions;
    std::size_t estimated_memory_bytes=0;
    double estimated_seconds=0.0;
    bool reversible=true;
    [[nodiscard]] std::string report() const;
};

struct MergeResult { bool success=false; PropertyBag merged; std::vector<std::string> conflicts; };
[[nodiscard]] MergeResult three_way_merge(const PropertyBag& base, const PropertyBag& ours, const PropertyBag& theirs);
[[nodiscard]] bool selective_undo(PropertyBag& current, const PropertyBag& before, const PropertyBag& after, std::string_view field, std::string& error);

struct CellSpan { int row=0, column=0; std::string text; };
class CellSpanRenderer {
public:
    [[nodiscard]] std::vector<CellSpan> diff(const std::vector<std::string>& rows);
    [[nodiscard]] std::string ansi(const std::vector<CellSpan>& spans, int cursor_row, int cursor_col) const;
    void invalidate();
private:
    std::vector<std::string> previous_;
};

class VirtualizedRecordStore {
public:
    explicit VirtualizedRecordStore(std::size_t cache_rows=4096);
    std::uint64_t append(std::string record);
    [[nodiscard]] std::vector<std::pair<std::uint64_t,std::string>> page(std::size_t offset, std::size_t count, std::string_view filter={}) const;
    [[nodiscard]] std::size_t size() const noexcept;
private:
    std::deque<std::pair<std::uint64_t,std::string>> records_;
    std::size_t cache_rows_;
    std::uint64_t next_id_=1;
};

struct UiPerformanceSnapshot { double frame_p50_ms=0, frame_p99_ms=0, input_p99_ms=0; std::size_t dirty_spans=0,index_documents=0,records=0; double update_hz=0; std::size_t throttled_frames=0; [[nodiscard]] std::string report() const; };
class UiPerformanceMonitor {
public:
    void frame(double ms, std::size_t spans);
    void input(double ms);
    void set_counts(std::size_t index_docs, std::size_t records, double update_hz);
    [[nodiscard]] UiPerformanceSnapshot snapshot() const;
private:
    std::vector<double> frames_, inputs_; std::size_t spans_=0,index_=0,records_=0,throttled_=0; double hz_=0;
};



struct CrashRecoveryState {
    std::string workspace_name;
    bool dashboard_visible=true, lower_pane_visible=true, status_bar_visible=true;
    std::size_t dashboard_page=0, scroll_offset=0, command_cursor=0;
    bool stick_to_bottom=true, watch_panel_visible=false;
    std::string text_filter, field_filter_expression, search_query, active_dashboard, command_line;
    std::vector<std::string> watch_metrics, status_segments;
    std::optional<std::uint64_t> selected_record, inspector_record;
};

struct RecoveryJournalStatus {
    bool enabled=false, recovery_available=false;
    std::uint64_t last_timestamp_ms=0, valid_records=0, invalid_records=0;
    std::uintmax_t bytes=0;
    std::string path;
    [[nodiscard]] std::string report() const;
};

class CrashRecoveryJournal {
public:
    CrashRecoveryJournal() = default;
    explicit CrashRecoveryJournal(std::filesystem::path path, std::uintmax_t compact_bytes=4u*1024u*1024u);
    void configure(std::filesystem::path path, std::uintmax_t compact_bytes=4u*1024u*1024u);
    [[nodiscard]] bool enabled() const noexcept { return !path_.empty(); }
    [[nodiscard]] std::optional<CrashRecoveryState> begin_session(std::string& warning);
    bool checkpoint(const CrashRecoveryState& state, bool force, std::string& error);
    bool close_clean(const CrashRecoveryState& state, std::string& error);
    bool discard(std::string& error);
    [[nodiscard]] RecoveryJournalStatus status() const;
    [[nodiscard]] std::string inspect() const;
private:
    std::filesystem::path path_;
    std::uintmax_t compact_bytes_=4u*1024u*1024u;
    std::string last_payload_;
    std::uint64_t session_id_=0;
    std::chrono::steady_clock::time_point last_write_{};
};

enum class UiAvailability : unsigned char { available, permission_denied, capability_missing, state_blocked };
struct UiAccessDecision {
    UiAvailability availability=UiAvailability::available;
    std::string required_permission;
    std::vector<std::string> missing_capabilities;
    std::string reason;
    [[nodiscard]] bool allowed() const noexcept { return availability==UiAvailability::available; }
    [[nodiscard]] std::string report(std::string_view command) const;
};
class UiAccessPolicy {
public:
    void set_identity(std::string username, std::vector<std::string> roles, std::set<std::string> permissions);
    void set_capabilities(std::set<std::string> capabilities);
    [[nodiscard]] UiAccessDecision evaluate(std::string_view command, const ux::RuntimeContext& context) const;
    [[nodiscard]] std::string report() const;
private:
    std::string username_;
    std::vector<std::string> roles_;
    std::set<std::string> permissions_, capabilities_;
};

enum class SemanticSeverity : unsigned char { info, warning, error };
struct SemanticDiagnostic {
    SemanticSeverity severity = SemanticSeverity::info;
    std::string code;
    std::string message;
    std::string cause;
    std::string remediation;
    std::string example;
    std::size_t byte_offset = 0;
};
struct SemanticCommandAnalysis {
    std::string canonical_command;
    std::vector<std::string> tokens;
    std::vector<SemanticDiagnostic> diagnostics;
    UiAccessDecision access;
    [[nodiscard]] bool valid() const;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] std::string json() const;
};
class SemanticCliService {
public:
    SemanticCliService(const ux::ExperienceManager* experience, const UnitRegistry* units, const UiAccessPolicy* access)
        : experience_(experience), units_(units), access_(access) {}
    [[nodiscard]] SemanticCommandAnalysis analyze(std::string_view line, const ux::RuntimeContext& context) const;
private:
    const ux::ExperienceManager* experience_{};
    const UnitRegistry* units_{};
    const UiAccessPolicy* access_{};
};

struct UiGovernorBudget { double frame_p99_ms=33.0,input_p99_ms=30.0,bandwidth_kib_s=256.0,cpu_percent=6.0; };
struct UiGovernorObservation { double frame_ms=0,input_ms=0,bytes_per_second=0,cpu_percent=0; std::size_t queue_depth=0,dropped_frames=0; bool ssh=false; };
struct UiGovernorPolicy {
    int frame_interval_ms=100, telemetry_interval_ms=100, graphics_interval_ms=200, background_interval_ms=1000;
    std::size_t max_plot_points=1600;
    bool animations=true, constrained=false;
    std::string reason="within budget";
    [[nodiscard]] std::string report() const;
};
class UiResourceGovernor {
public:
    void observe(const UiGovernorObservation& observation);
    void set_budget(UiGovernorBudget budget);
    void set_enabled(bool enabled) noexcept { enabled_=enabled; }
    [[nodiscard]] bool enabled() const noexcept { return enabled_; }
    void reset();
    [[nodiscard]] const UiGovernorPolicy& policy() const noexcept { return policy_; }
    [[nodiscard]] UiGovernorBudget budget() const noexcept { return budget_; }
    [[nodiscard]] std::string report() const;
private:
    UiGovernorBudget budget_{};
    UiGovernorPolicy policy_{};
    bool enabled_=true;
    double ema_frame_=0,ema_input_=0,ema_bandwidth_=0,ema_cpu_=0;
    std::size_t pressure_ticks_=0,relief_ticks_=0;
};

enum class NarrationLevel : unsigned char { minimal, standard, detailed, diagnostic };
class AccessibilityNarrator {
public:
    void set_level(NarrationLevel level) noexcept { level_=level; }
    [[nodiscard]] std::string narrate_result(const ux::CommandResult& result) const;
    [[nodiscard]] std::string narrate_context_change(const ContextNode* before, const ContextNode* after) const;
private: NarrationLevel level_=NarrationLevel::standard;
};

class GlobalEngineeringIndex {
public:
    void rebuild(const ContextGraph& graph, const ProviderRegistry& providers,
                 const ActivityTimeline& timeline, const JobManager& jobs);
    [[nodiscard]] std::vector<ux::ActionItem> search(std::string_view query, std::size_t limit=25) const;
    [[nodiscard]] std::size_t size() const noexcept { return documents_.size(); }
private: std::vector<ux::ActionItem> documents_;
};

class GlobalUiArchitecture {
public:
    ContextGraph context;
    ProviderRegistry providers;
    UnitRegistry units;
    WorkflowEngine workflows;
    JobManager jobs;
    ActivityTimeline activity;
    WorkspacePersistence persistence;
    DashboardEngine dashboards;
    CellSpanRenderer renderer;
    VirtualizedRecordStore records;
    UiPerformanceMonitor performance;
    CrashRecoveryJournal recovery;
    UiAccessPolicy access;
    UiResourceGovernor governor;
    AccessibilityNarrator narrator;
    GlobalEngineeringIndex index;

    [[nodiscard]] std::string adaptive_home() const;
    [[nodiscard]] std::optional<std::string> suggested_workspace() const;
};

} // namespace sim::console::globalui

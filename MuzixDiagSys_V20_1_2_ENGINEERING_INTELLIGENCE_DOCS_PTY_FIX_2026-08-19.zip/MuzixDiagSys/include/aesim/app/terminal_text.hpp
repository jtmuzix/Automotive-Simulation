#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::terminal_text {

struct Utf8Codepoint {
    std::uint32_t value = 0xfffd;
    std::size_t bytes = 1;
    bool valid = false;
};

[[nodiscard]] Utf8Codepoint decode_utf8(std::string_view text, std::size_t pos) noexcept;
[[nodiscard]] std::size_t display_width(std::string_view text) noexcept;
[[nodiscard]] std::string strip_ansi(std::string_view text);
[[nodiscard]] std::string sanitize_for_terminal(std::string_view text);
[[nodiscard]] std::string truncate_columns(std::string_view text, std::size_t maximum_columns);
[[nodiscard]] std::vector<std::string> wrap_columns(const std::string& text, int width);

} // namespace sim::console::terminal_text

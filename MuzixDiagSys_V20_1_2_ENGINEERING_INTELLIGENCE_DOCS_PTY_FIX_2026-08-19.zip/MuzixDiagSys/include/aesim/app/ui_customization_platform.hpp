#pragma once

#include "aesim/app/global_ui_architecture.hpp"
#include "aesim/app/ui_experience.hpp"

#include <cstdint>
#include <filesystem>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::customui {

enum class DensityMode : unsigned char { automatic, full, compact, narrow, minimal };
enum class BorderMode : unsigned char { automatic, unicode, ascii };

[[nodiscard]] const char* density_name(DensityMode value) noexcept;
[[nodiscard]] std::optional<DensityMode> parse_density(std::string_view value);
[[nodiscard]] const char* border_name(BorderMode value) noexcept;
[[nodiscard]] std::optional<BorderMode> parse_border(std::string_view value);
[[nodiscard]] std::vector<std::string> default_status_segments();
[[nodiscard]] std::vector<std::string> default_watch_signals();

struct TerminalPresentation {
    DensityMode density = DensityMode::automatic;
    BorderMode borders = BorderMode::automatic;
    bool timestamps = false;
    bool animations = true;
    bool compact_spacing = false;
};

struct SignalPresentation {
    std::string alias;
    std::string display_unit;
    int precision = -1;
    std::string group;
    bool favorite = false;
    int refresh_ms = 0;
};

struct MonitorAssignment {
    std::string id;
    int x = 0;
    int y = 0;
    int width = 1920;
    int height = 1080;
    double scale = 1.0;
    bool primary = false;
    std::string workspace;
    std::string dashboard;
};

struct CustomTheme {
    std::string name;
    bool colors_enabled = true;
    int red = 203;
    int green = 78;
    int yellow = 221;
    int blue = 75;
    int magenta = 141;
    int cyan = 45;
};

struct UiProfile {
    std::string name;
    std::string description;
    std::string theme = "professional-dark";
    std::string discovery_profile = "professional";
    std::string accessibility_mode = "standard";
    std::string refresh_profile = "local";
    std::string workspace;
    std::string active_dashboard;
    std::string workflow;
    bool dashboard_visible = true;
    bool lower_pane_visible = true;
    bool status_bar_visible = true;
    bool watch_panel_visible = false;
    std::size_t watch_history = 32;
    std::vector<std::string> status_segments;
    std::vector<std::string> watch_metrics;
    TerminalPresentation terminal;
    globalui::UiGovernorBudget governor_budget{};
    bool governor_enabled = true;
    bool render_paused = false;
    std::vector<ux::KeyBinding> keybindings;
    std::map<std::string, SignalPresentation> signals;
    std::map<std::string, globalui::DashboardLayout> dashboards;
    std::map<std::string, MonitorAssignment> monitors;
    std::string active_monitor;
    std::set<std::string> favorite_actions;
};

class UiCustomizationPlatform {
public:
    UiCustomizationPlatform();

    [[nodiscard]] const UiProfile& active_profile() const;
    [[nodiscard]] const UiProfile* find_profile(std::string_view name) const noexcept;
    [[nodiscard]] std::vector<std::string> profile_names() const;
    bool store_profile(UiProfile profile, std::string& error);
    bool activate_profile(std::string_view name, std::string& error);
    bool delete_profile(std::string_view name, std::string& error);

    bool set_signal(std::string signal, SignalPresentation presentation, std::string& error);
    bool remove_signal(std::string_view signal);
    [[nodiscard]] const SignalPresentation* signal(std::string_view signal) const noexcept;
    [[nodiscard]] std::string signal_report() const;

    bool set_monitor(MonitorAssignment monitor, std::string& error);
    bool remove_monitor(std::string_view id);
    bool activate_monitor(std::string_view id, std::string& error);
    [[nodiscard]] const MonitorAssignment* active_monitor() const noexcept;
    [[nodiscard]] std::string monitor_report() const;

    bool store_theme(CustomTheme theme, std::string& error);
    bool delete_theme(std::string_view name, std::string& error);
    [[nodiscard]] const CustomTheme* find_theme(std::string_view name) const noexcept;
    [[nodiscard]] std::vector<std::string> theme_names() const;
    [[nodiscard]] std::string theme_report() const;

    bool favorite_action(std::string command, bool enabled, std::string& error);
    [[nodiscard]] bool is_favorite(std::string_view command) const noexcept;
    void record_action(std::string_view command);
    [[nodiscard]] int action_boost(std::string_view command) const noexcept;
    [[nodiscard]] std::string favorite_report() const;

    bool save(const std::filesystem::path& path, std::string& error) const;
    bool load(const std::filesystem::path& path, std::string& error);
    [[nodiscard]] std::string report() const;

private:
    struct RecentAction { std::uint64_t count = 0; std::uint64_t sequence = 0; };
    std::map<std::string, UiProfile> profiles_;
    std::map<std::string, CustomTheme> themes_;
    std::map<std::string, RecentAction> recent_actions_;
    std::string active_profile_ = "professional";
    std::uint64_t action_sequence_ = 0;

    void install_factory_profiles();
    [[nodiscard]] UiProfile* mutable_active_profile() noexcept;
    static bool validate_profile(const UiProfile& profile, std::string& error);
};

} // namespace sim::console::customui

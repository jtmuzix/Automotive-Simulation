#pragma once

#include "aesim/security/authentication.hpp"

#include <string>

namespace aesim::app {

struct UserCommandResult {
    bool handled = false;
    bool keep_running = true;
    std::string output;
};

[[nodiscard]] bool authenticate_console_session(int argc,
                                                char** argv,
                                                security::AuthenticationService& service,
                                                security::UserIdentity& identity,
                                                std::string& error);

[[nodiscard]] UserCommandResult handle_user_command(
    const std::string& command_line,
    security::AuthenticationService& service,
    security::UserIdentity& identity);

} // namespace aesim::app

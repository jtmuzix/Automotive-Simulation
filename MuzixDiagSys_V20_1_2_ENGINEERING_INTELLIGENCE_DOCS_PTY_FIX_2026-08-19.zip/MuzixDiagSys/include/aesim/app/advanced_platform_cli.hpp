#pragma once

#include <iosfwd>
#include <string>
#include <vector>

namespace aesim::advanced_cli {

// Shared dispatcher used by both the standalone advanced-platform executable
// and the primary MuzixDiagSys interactive console.
int run_advanced_platform_cli(int argc, char** argv);
int run_advanced_platform_cli(int argc, char** argv, std::ostream& output, std::ostream& error);

// Interactive-console integration helpers.  The command vector excludes the
// executable name and is routed through the exact standalone CLI dispatcher.
std::string run_advanced_platform_command(const std::vector<std::string>& arguments);
std::vector<std::string> advanced_platform_root_commands();
std::vector<std::string> advanced_api_command_names();
std::vector<std::string> advanced_api_command_operations(const std::string& command);
std::vector<std::string> motorsport_root_commands();
std::string advanced_platform_interactive_help();

} // namespace aesim::advanced_cli

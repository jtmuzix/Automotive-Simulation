#pragma once

#include "aesim/industrial/signals.hpp"
#include "aesim/high_fidelity/integrated_vehicle.hpp"
#include "aesim/high_fidelity/integrated_depth.hpp"
#include "aesim/high_fidelity/ecosystem.hpp"
#include "aesim/high_fidelity/lifecycle.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::electrification {

class AdvancedElectrifiedVehicle;

// -----------------------------------------------------------------------------
// Battery electrothermal and degradation model
// -----------------------------------------------------------------------------

struct LookupPoint {
    double x = 0.0;
    double y = 0.0;
};

struct BatteryCellParameters {
    double nominal_capacity_ah = 5.0;
    double nominal_voltage_v = 3.65;
    double minimum_voltage_v = 2.7;
    double maximum_voltage_v = 4.2;
    double maximum_charge_current_a = 15.0;
    double maximum_discharge_current_a = 30.0;
    double coulombic_efficiency_charge = 0.995;
    double coulombic_efficiency_discharge = 1.0;
    double r0_ohm = 0.0025;
    double r1_ohm = 0.0015;
    double c1_f = 2500.0;
    double r2_ohm = 0.0030;
    double c2_f = 12000.0;
    double core_heat_capacity_j_k = 850.0;
    double surface_heat_capacity_j_k = 220.0;
    double core_surface_conductance_w_k = 4.5;
    double surface_coolant_conductance_w_k = 2.0;
    double entropic_coefficient_v_k = 0.00012;
    double calendar_fade_per_sqrt_day = 1.5e-5;
    double cycle_fade_per_ah = 1.0e-7;
    double resistance_growth_per_ah = 2.0e-7;
    double activation_energy_j_mol = 24000.0;
    double reference_temperature_k = 298.15;
    std::vector<LookupPoint> ocv_curve{{0.0,3.0},{0.1,3.35},{0.2,3.48},{0.5,3.68},{0.8,3.92},{0.9,4.05},{1.0,4.2}};
};

struct BatteryPackConfiguration {
    std::size_t series_cells = 96;
    std::size_t parallel_cells = 2;
    BatteryCellParameters cell;
    double initial_soc = 0.80;
    double initial_temperature_k = 298.15;
    double balancing_current_a = 0.25;
    double minimum_soc = 0.02;
    double maximum_soc = 0.98;
    double thermal_derate_start_k = 318.15;
    double thermal_shutdown_k = 333.15;
    double cold_derate_start_k = 278.15;
    double cold_shutdown_k = 253.15;
};

struct BatteryCellState {
    double soc = 0.80;
    double polarization_1_v = 0.0;
    double polarization_2_v = 0.0;
    double core_temperature_k = 298.15;
    double surface_temperature_k = 298.15;
    double capacity_fraction = 1.0;
    double resistance_scale = 1.0;
    double charge_throughput_ah = 0.0;
    double calendar_age_s = 0.0;
    double plating_index = 0.0;
};

struct BatteryPackInput {
    double pack_current_a = 0.0; // Positive discharges the battery; negative charges it.
    double coolant_temperature_k = 298.15;
    double ambient_temperature_k = 298.15;
    bool balancing_enabled = false;
};

struct BatteryPackOutput {
    double pack_voltage_v = 0.0;
    double pack_current_a = 0.0;
    double pack_power_w = 0.0;
    double heat_generation_w = 0.0;
    double average_soc = 0.0;
    double minimum_soc = 0.0;
    double maximum_soc = 0.0;
    double average_core_temperature_k = 0.0;
    double maximum_core_temperature_k = 0.0;
    double available_discharge_power_w = 0.0;
    double available_charge_power_w = 0.0;
    double capacity_fraction = 1.0;
    double resistance_scale = 1.0;
    double energy_residual_w = 0.0;
    bool charge_allowed = true;
    bool discharge_allowed = true;
    bool contactors_closed = false;
    std::vector<double> cell_voltages_v;
};

class BatteryPack {
public:
    BatteryPack();
    explicit BatteryPack(BatteryPackConfiguration configuration);
    void configure(const BatteryPackConfiguration& configuration);
    void configure_file(const std::string& path);
    void reset(double soc = -1.0, double temperature_k = -1.0);
    [[nodiscard]] BatteryPackOutput step(const BatteryPackInput& input, double dt_s);
    [[nodiscard]] double current_for_power(double requested_pack_power_w,
                                           double coolant_temperature_k,
                                           double dt_s) const;
    [[nodiscard]] const BatteryPackConfiguration& configuration() const noexcept;
    [[nodiscard]] const std::vector<BatteryCellState>& states() const noexcept;
    [[nodiscard]] const BatteryPackOutput& output() const noexcept;
    [[nodiscard]] doc::Value state_document() const;
    void restore_state(const doc::Value& state);
    [[nodiscard]] std::string status() const;
private:
    BatteryPackConfiguration configuration_;
    std::vector<BatteryCellState> states_;
    BatteryPackOutput output_;
    double stored_energy_j_ = 0.0;
    double interpolate_ocv(double soc) const;
    double current_derate(const BatteryCellState& state, bool charging) const;
    void validate_configuration() const;
};

// -----------------------------------------------------------------------------
// Electric machine, inverter, and hybrid topology composition
// -----------------------------------------------------------------------------

struct ElectricMachineConfiguration {
    std::string name = "traction_motor";
    unsigned pole_pairs = 4;
    double maximum_torque_nm = 350.0;
    double maximum_regen_torque_nm = 220.0;
    double maximum_speed_rad_s = 1800.0;
    double phase_resistance_ohm = 0.012;
    double flux_linkage_wb = 0.085;
    double d_axis_inductance_h = 0.00018;
    double q_axis_inductance_h = 0.00024;
    double maximum_phase_current_a = 650.0;
    double iron_loss_coefficient = 0.0035;
    double mechanical_loss_coefficient = 0.00025;
    double stator_heat_capacity_j_k = 18000.0;
    double rotor_heat_capacity_j_k = 12000.0;
    double stator_coolant_conductance_w_k = 140.0;
    double rotor_stator_conductance_w_k = 35.0;
    double thermal_derate_start_k = 398.15;
    double thermal_shutdown_k = 443.15;
};

struct InverterConfiguration {
    double maximum_dc_current_a = 800.0;
    double switching_frequency_hz = 10000.0;
    double transistor_drop_v = 1.2;
    double transistor_resistance_ohm = 0.0012;
    double switching_loss_coefficient = 8.0e-8;
    double heat_capacity_j_k = 8000.0;
    double coolant_conductance_w_k = 110.0;
    double thermal_derate_start_k = 383.15;
    double thermal_shutdown_k = 423.15;
};

struct ElectricDriveInput {
    double requested_torque_nm = 0.0;
    double shaft_speed_rad_s = 0.0;
    double dc_voltage_v = 400.0;
    double coolant_temperature_k = 298.15;
};

struct ElectricDriveOutput {
    double delivered_torque_nm = 0.0;
    double mechanical_power_w = 0.0;
    double dc_power_w = 0.0;
    double dc_current_a = 0.0;
    double machine_loss_w = 0.0;
    double inverter_loss_w = 0.0;
    double efficiency = 0.0;
    double phase_current_a = 0.0;
    double voltage_utilization = 0.0;
    double stator_temperature_k = 298.15;
    double rotor_temperature_k = 298.15;
    double inverter_temperature_k = 298.15;
    bool torque_limited = false;
    bool thermal_shutdown = false;
};

class ElectricDrive {
public:
    ElectricDrive();
    ElectricDrive(ElectricMachineConfiguration machine, InverterConfiguration inverter);
    void configure(const ElectricMachineConfiguration& machine, const InverterConfiguration& inverter);
    void reset(double temperature_k = 298.15);
    [[nodiscard]] ElectricDriveOutput step(const ElectricDriveInput& input, double dt_s);
    [[nodiscard]] const ElectricDriveOutput& output() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    ElectricMachineConfiguration machine_;
    InverterConfiguration inverter_;
    ElectricDriveOutput output_;
};

enum class HybridOperatingMode { Electric, Engine, Blend, ChargeSustain, Regeneration, Fault };

struct HybridComponent {
    std::string id;
    std::string type; // engine, motor, clutch, gear, differential, wheel, battery, bus
    double ratio = 1.0;
    double efficiency = 1.0;
    bool enabled = true;
};

struct HybridConnection {
    std::string from;
    std::string to;
    std::string domain = "mechanical";
};

struct HybridTopology {
    std::string name = "P2";
    std::map<std::string, HybridComponent> components;
    std::vector<HybridConnection> connections;
    [[nodiscard]] static HybridTopology preset(const std::string& name);
    [[nodiscard]] static HybridTopology load_file(const std::string& path);
    void validate() const;
    [[nodiscard]] doc::Value to_document() const;
};

struct HybridControlInput {
    double requested_wheel_torque_nm = 0.0;
    double wheel_speed_rad_s = 0.0;
    double engine_available_torque_nm = 0.0;
    double brake_fraction = 0.0;
    double ambient_temperature_k = 298.15;
    double coolant_temperature_k = 298.15;
};

struct HybridPowertrainOutput {
    HybridOperatingMode mode = HybridOperatingMode::Electric;
    double engine_torque_request_nm = 0.0;
    double motor_torque_request_nm = 0.0;
    double wheel_torque_nm = 0.0;
    double battery_power_w = 0.0;
    double fuel_power_w = 0.0;
    double electrical_loss_w = 0.0;
    double mechanical_loss_w = 0.0;
    double equivalent_fuel_rate_kg_s = 0.0;
    BatteryPackOutput battery;
    ElectricDriveOutput drive;
};

class HybridPowertrain {
public:
    HybridPowertrain();
    void configure(const HybridTopology& topology,
                   const BatteryPackConfiguration& battery,
                   const ElectricMachineConfiguration& machine,
                   const InverterConfiguration& inverter);
    void configure_file(const std::string& path);
    void reset();
    [[nodiscard]] HybridPowertrainOutput step(const HybridControlInput& input, double dt_s);
    void set_target_soc(double value);
    void set_equivalence_factor(double value);
    [[nodiscard]] const HybridPowertrainOutput& output() const noexcept;
    [[nodiscard]] BatteryPack& battery() noexcept;
    [[nodiscard]] ElectricDrive& drive() noexcept;
    [[nodiscard]] std::string status() const;
private:
    HybridTopology topology_;
    BatteryPack battery_;
    ElectricDrive drive_;
    HybridPowertrainOutput output_;
    double target_soc_ = 0.60;
    double equivalence_factor_ = 2.8;
    double final_drive_ratio_ = 9.0;
    double mechanical_efficiency_ = 0.96;
};

// -----------------------------------------------------------------------------
// ISO 15118, Plug & Charge PKI, OCPP, and charging physics
// -----------------------------------------------------------------------------

class PlugAndChargePki {
public:
    void initialize(const std::string& directory);
    void create_root(const std::string& common_name, unsigned valid_days = 3650);
    void issue_contract_certificate(const std::string& emaid, unsigned valid_days = 365);
    void issue_evse_certificate(const std::string& evse_id, unsigned valid_days = 365);
    [[nodiscard]] bool verify_contract_certificate() const;
    [[nodiscard]] bool verify_evse_certificate() const;
    [[nodiscard]] std::vector<std::uint8_t> sign_contract_challenge(const std::vector<std::uint8_t>& challenge) const;
    [[nodiscard]] bool verify_contract_signature(const std::vector<std::uint8_t>& challenge,
                                                 const std::vector<std::uint8_t>& signature) const;
    [[nodiscard]] std::string status() const;
    [[nodiscard]] const std::string& directory() const noexcept;
private:
    std::string directory_;
};

enum class Iso15118State {
    Disconnected,
    SessionSetup,
    ServiceDiscovery,
    PaymentSelection,
    Authorization,
    ChargeParameterDiscovery,
    CableCheck,
    PreCharge,
    PowerDelivery,
    Charging,
    SessionStop,
    Complete,
    Failed
};

struct ChargingLimits {
    double maximum_voltage_v = 800.0;
    double maximum_current_a = 500.0;
    double maximum_power_w = 250000.0;
    double minimum_voltage_v = 50.0;
};

class Iso15118Session {
public:
    explicit Iso15118Session(PlugAndChargePki* pki = nullptr);
    void reset();
    void set_limits(ChargingLimits limits);
    [[nodiscard]] doc::Value process(const doc::Value& message);
    [[nodiscard]] Iso15118State state() const noexcept;
    [[nodiscard]] double requested_voltage_v() const noexcept;
    [[nodiscard]] double requested_current_a() const noexcept;
    [[nodiscard]] bool power_delivery_enabled() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    PlugAndChargePki* pki_ = nullptr;
    Iso15118State state_ = Iso15118State::Disconnected;
    ChargingLimits limits_;
    std::string session_id_;
    double requested_voltage_v_ = 0.0;
    double requested_current_a_ = 0.0;
    bool power_delivery_enabled_ = false;
    std::uint64_t message_counter_ = 0;
};

class OcppChargePoint {
public:
    explicit OcppChargePoint(std::string charge_point_id = "MUZIXDIAGSYS-EVSE-001");
    [[nodiscard]] doc::Value process_frame(const doc::Value& frame);
    [[nodiscard]] doc::Value make_call(const std::string& action, const doc::Value& payload);
    void set_connected(bool connected);
    void advance_time(double seconds);
    [[nodiscard]] double permitted_power_w() const noexcept;
    [[nodiscard]] bool transaction_active() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    std::string charge_point_id_;
    bool connected_ = true;
    bool boot_accepted_ = false;
    bool authorized_ = false;
    bool transaction_active_ = false;
    std::string transaction_id_;
    std::uint64_t sequence_ = 1;
    double elapsed_s_ = 0.0;
    double permitted_power_w_ = 22000.0;
    double meter_energy_wh_ = 0.0;
    std::map<std::string, doc::Value> pending_calls_;
};

struct ChargingStepOutput {
    double dc_voltage_v = 0.0;
    double dc_current_a = 0.0;
    double dc_power_w = 0.0;
    double grid_power_w = 0.0;
    double charger_loss_w = 0.0;
    double delivered_energy_wh = 0.0;
    BatteryPackOutput battery;
    bool active = false;
};

class ChargingSystem {
public:
    ChargingSystem();
    void attach_battery(BatteryPack* battery);
    void set_efficiency(double efficiency);
    void set_site_power_limit(double watts);
    [[nodiscard]] ChargingStepOutput step(Iso15118Session& session,
                                          OcppChargePoint& charge_point,
                                          double coolant_temperature_k,
                                          double dt_s);
    [[nodiscard]] const ChargingStepOutput& output() const noexcept;
private:
    BatteryPack* battery_ = nullptr;
    double efficiency_ = 0.95;
    double site_power_limit_w_ = 350000.0;
    ChargingStepOutput output_;
};

// -----------------------------------------------------------------------------
// Whole-vehicle thermal management, heat pump, and cabin HVAC
// -----------------------------------------------------------------------------

struct ThermalSystemConfiguration {
    double battery_thermal_mass_j_k = 350000.0;
    double motor_thermal_mass_j_k = 90000.0;
    double inverter_thermal_mass_j_k = 45000.0;
    double engine_thermal_mass_j_k = 180000.0;
    double coolant_thermal_mass_j_k = 120000.0;
    double cabin_air_thermal_mass_j_k = 65000.0;
    double cabin_interior_thermal_mass_j_k = 500000.0;
    double battery_coolant_ua_w_k = 450.0;
    double motor_coolant_ua_w_k = 650.0;
    double inverter_coolant_ua_w_k = 500.0;
    double engine_coolant_ua_w_k = 900.0;
    double radiator_ua_w_k = 1500.0;
    double cabin_ambient_ua_w_k = 180.0;
    double cabin_interior_ua_w_k = 320.0;
    double hvac_maximum_heat_w = 9000.0;
    double hvac_maximum_cooling_w = 8000.0;
    double pump_power_w = 180.0;
    double fan_power_w = 250.0;
};

struct ThermalSystemInput {
    double ambient_temperature_k = 298.15;
    double solar_load_w = 0.0;
    double passenger_heat_w = 0.0;
    double battery_heat_w = 0.0;
    double motor_heat_w = 0.0;
    double inverter_heat_w = 0.0;
    double engine_heat_w = 0.0;
    double vehicle_speed_m_s = 0.0;
    double cabin_setpoint_k = 295.15;
    double battery_setpoint_k = 298.15;
    bool cabin_hvac_enabled = true;
    bool battery_conditioning_enabled = true;
};

struct ThermalSystemOutput {
    double battery_temperature_k = 298.15;
    double motor_temperature_k = 298.15;
    double inverter_temperature_k = 298.15;
    double engine_temperature_k = 298.15;
    double coolant_temperature_k = 298.15;
    double cabin_air_temperature_k = 298.15;
    double cabin_interior_temperature_k = 298.15;
    double refrigerant_high_pressure_pa = 1.2e6;
    double refrigerant_low_pressure_pa = 3.0e5;
    double heat_pump_cop = 0.0;
    double hvac_thermal_power_w = 0.0;
    double hvac_electrical_power_w = 0.0;
    double pump_fan_power_w = 0.0;
    double radiator_heat_rejection_w = 0.0;
    double cabin_comfort_error_k = 0.0;
    double energy_residual_w = 0.0;
    bool heating_mode = false;
    bool cooling_mode = false;
};

class VehicleThermalSystem {
public:
    VehicleThermalSystem();
    explicit VehicleThermalSystem(ThermalSystemConfiguration configuration);
    void configure(const ThermalSystemConfiguration& configuration);
    void configure_file(const std::string& path);
    void reset(double temperature_k = 298.15);
    [[nodiscard]] ThermalSystemOutput step(const ThermalSystemInput& input, double dt_s);
    [[nodiscard]] const ThermalSystemOutput& output() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    ThermalSystemConfiguration configuration_;
    ThermalSystemOutput output_;
    double heat_pump_cop(double source_k, double sink_k, bool heating) const;
};

// -----------------------------------------------------------------------------
// Modelica operational subset and acausal DAE execution
// -----------------------------------------------------------------------------

struct ModelicaVariableInfo {
    std::string name;
    std::string causality = "local"; // parameter, input, output, local
    double value = 0.0;
    double start = 0.0;
    bool fixed = false;
    std::string unit = "1";
};

class ModelicaModel {
public:
    ModelicaModel();
    ~ModelicaModel();
    ModelicaModel(ModelicaModel&&) noexcept;
    ModelicaModel& operator=(ModelicaModel&&) noexcept;
    ModelicaModel(const ModelicaModel&) = delete;
    ModelicaModel& operator=(const ModelicaModel&) = delete;

    void load_text(const std::string& text, const std::string& source_name = "memory");
    void load_file(const std::string& path);
    void initialize(double tolerance = 1.0e-10, unsigned maximum_iterations = 50);
    void set(const std::string& name, double value);
    [[nodiscard]] double get(const std::string& name) const;
    [[nodiscard]] bool contains(const std::string& name) const;
    void step(double dt_s, double tolerance = 1.0e-9, unsigned maximum_iterations = 30);
    [[nodiscard]] double time_s() const noexcept;
    [[nodiscard]] const std::map<std::string, ModelicaVariableInfo>& variables() const;
    [[nodiscard]] doc::Value state_document() const;
    [[nodiscard]] std::string status() const;
private:
    struct Impl;
    std::unique_ptr<Impl> implementation_;
};

// -----------------------------------------------------------------------------
// ROS 2/DDS-oriented transport and ISO 23150 sensor fusion
// -----------------------------------------------------------------------------

struct DdsQos {
    bool reliable = true;
    bool transient_local = false;
    std::size_t history_depth = 32;
    double deadline_s = 0.0;
    double lifespan_s = 0.0;
};

struct DdsSample {
    std::string topic;
    std::string type_name;
    std::uint64_t sequence = 0;
    std::int64_t timestamp_ns = 0;
    std::vector<std::uint8_t> payload;
};

class DdsDomain {
public:
    using Callback = std::function<void(const DdsSample&)>;
    DdsDomain();
    ~DdsDomain();
    void open(std::uint16_t domain_id = 0, const std::string& multicast_address = "239.255.0.1");
    void close();
    [[nodiscard]] bool is_open() const noexcept;
    void publish(DdsSample sample, const DdsQos& qos = {});
    [[nodiscard]] std::uint64_t subscribe(const std::string& topic, Callback callback, DdsQos qos = {});
    void unsubscribe(std::uint64_t id);
    std::size_t poll(std::chrono::milliseconds timeout = std::chrono::milliseconds(0));
    [[nodiscard]] std::string status() const;
    [[nodiscard]] static std::vector<std::uint8_t> encode_rtps_data(const DdsSample& sample);
    [[nodiscard]] static DdsSample decode_rtps_data(const std::vector<std::uint8_t>& packet);
private:
    struct Impl;
    std::unique_ptr<Impl> implementation_;
};

struct RosClockMessage { std::int64_t nanoseconds = 0; };
struct RosVector3 { double x=0.0,y=0.0,z=0.0; };
struct RosQuaternion { double x=0.0,y=0.0,z=0.0,w=1.0; };
struct RosImuMessage {
    RosQuaternion orientation;
    std::array<double,9> orientation_covariance{};
    RosVector3 angular_velocity;
    std::array<double,9> angular_velocity_covariance{};
    RosVector3 linear_acceleration;
    std::array<double,9> linear_acceleration_covariance{};
};
struct RosOdometryMessage {
    RosVector3 position;
    RosQuaternion orientation;
    RosVector3 linear_velocity;
    RosVector3 angular_velocity;
    std::array<double,36> pose_covariance{};
    std::array<double,36> twist_covariance{};
};

class Ros2Bridge {
public:
    explicit Ros2Bridge(DdsDomain& domain);
    void publish_clock(const RosClockMessage& message);
    void publish_imu(const std::string& topic, const RosImuMessage& message);
    void publish_odometry(const std::string& topic, const RosOdometryMessage& message);
    [[nodiscard]] static std::vector<std::uint8_t> encode_clock(const RosClockMessage& message);
    [[nodiscard]] static RosClockMessage decode_clock(const std::vector<std::uint8_t>& data);
    [[nodiscard]] static std::vector<std::uint8_t> encode_imu(const RosImuMessage& message);
    [[nodiscard]] static RosImuMessage decode_imu(const std::vector<std::uint8_t>& data);
    [[nodiscard]] static std::vector<std::uint8_t> encode_odometry(const RosOdometryMessage& message);
    [[nodiscard]] static RosOdometryMessage decode_odometry(const std::vector<std::uint8_t>& data);
private:
    DdsDomain& domain_;
    std::uint64_t sequence_ = 1;
};

struct SensorMounting {
    double x_m=0.0,y_m=0.0,z_m=0.0;
    double roll_rad=0.0,pitch_rad=0.0,yaw_rad=0.0;
};

struct SensorDetection {
    std::string sensor_id;
    std::uint64_t detection_id = 0;
    std::int64_t timestamp_ns = 0;
    std::string classification = "unknown";
    double confidence = 1.0;
    double x_m=0.0,y_m=0.0,z_m=0.0;
    double vx_m_s=0.0,vy_m_s=0.0,vz_m_s=0.0;
    std::array<double,36> covariance{};
};

struct FusedObject {
    std::uint64_t track_id = 0;
    std::int64_t timestamp_ns = 0;
    std::string classification = "unknown";
    double confidence = 0.0;
    double x_m=0.0,y_m=0.0,z_m=0.0;
    double vx_m_s=0.0,vy_m_s=0.0,vz_m_s=0.0;
    std::array<double,36> covariance{};
    std::set<std::string> contributing_sensors;
    unsigned age = 0;
    unsigned missed_updates = 0;
};

class Iso23150Fusion {
public:
    void configure_sensor(const std::string& sensor_id, SensorMounting mounting);
    void ingest(const std::vector<SensorDetection>& detections);
    void predict(std::int64_t timestamp_ns);
    [[nodiscard]] const std::vector<FusedObject>& objects() const noexcept;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] std::string status() const;
private:
    std::map<std::string,SensorMounting> mountings_;
    std::vector<FusedObject> tracks_;
    std::uint64_t next_track_id_ = 1;
    double association_gate_m_ = 5.0;
};

// -----------------------------------------------------------------------------
// Heterogeneous compute acceleration
// -----------------------------------------------------------------------------

enum class ComputeOperation { Copy, Fill, Affine, ReduceSum };

struct ComputeRequest {
    ComputeOperation operation = ComputeOperation::Affine;
    std::vector<float> input;
    std::size_t element_count = 0;
    float scale = 1.0F;
    float bias = 0.0F;
    float fill_value = 0.0F;
};

struct ComputeResult {
    bool success = false;
    std::string backend;
    std::string device;
    std::string message;
    std::vector<float> output;
    double scalar = 0.0;
    double elapsed_ms = 0.0;
};

struct ComputeBackendInfo {
    std::string name;
    std::string device;
    bool available = false;
    std::set<ComputeOperation> operations;
    std::string diagnostic;
};

class ComputeBackend {
public:
    virtual ~ComputeBackend() = default;
    [[nodiscard]] virtual ComputeBackendInfo info() const = 0;
    [[nodiscard]] virtual ComputeResult execute(const ComputeRequest& request) = 0;
};

class HeterogeneousCompute {
public:
    HeterogeneousCompute();
    ~HeterogeneousCompute();
    [[nodiscard]] std::vector<ComputeBackendInfo> backends() const;
    [[nodiscard]] ComputeResult execute(const std::string& backend, const ComputeRequest& request);
    [[nodiscard]] ComputeResult execute_best(const ComputeRequest& request);
    [[nodiscard]] std::string status() const;
private:
    std::vector<std::unique_ptr<ComputeBackend>> backends_;
};

// -----------------------------------------------------------------------------
// ONNX protobuf execution, runtime safety envelopes, and AI assurance
// -----------------------------------------------------------------------------

struct Tensor {
    std::vector<std::int64_t> shape;
    std::vector<double> values;
    [[nodiscard]] std::size_t element_count() const;
};

struct SafetyRange {
    double minimum = -1.0e300;
    double maximum = 1.0e300;
};

struct AiSafetyEnvelope {
    std::map<std::string,SafetyRange> input_ranges;
    std::map<std::string,SafetyRange> output_ranges;
    std::map<std::string,double> maximum_output_rate_per_s;
    std::set<std::string> allowed_operations;
    std::map<std::string,Tensor> fallback_outputs;
    bool reject_nonfinite = true;
    bool fallback_on_violation = true;
    double maximum_inference_time_ms = 100.0;
};

struct AiInferenceReport {
    bool accepted = false;
    bool used_fallback = false;
    std::string model_hash;
    double inference_time_ms = 0.0;
    std::vector<std::string> violations;
    std::map<std::string,Tensor> outputs;
    doc::Value to_document() const;
};

class OnnxModel {
public:
    OnnxModel();
    ~OnnxModel();
    OnnxModel(OnnxModel&&) noexcept;
    OnnxModel& operator=(OnnxModel&&) noexcept;
    OnnxModel(const OnnxModel&) = delete;
    OnnxModel& operator=(const OnnxModel&) = delete;

    void load_file(const std::string& path);
    void load_bytes(const std::vector<std::uint8_t>& bytes, const std::string& source_name = "memory.onnx");
    [[nodiscard]] std::map<std::string,Tensor> run(const std::map<std::string,Tensor>& inputs) const;
    [[nodiscard]] const std::vector<std::string>& input_names() const;
    [[nodiscard]] const std::vector<std::string>& output_names() const;
    [[nodiscard]] const std::set<std::string>& operation_types() const;
    [[nodiscard]] const std::string& sha256() const;
    [[nodiscard]] doc::Value graph_document() const;
    [[nodiscard]] std::string status() const;
private:
    struct Impl;
    std::unique_ptr<Impl> implementation_;
};

class AiAssuranceRuntime {
public:
    void load_model(const std::string& path);
    void set_envelope(AiSafetyEnvelope envelope);
    void load_envelope_file(const std::string& path);
    [[nodiscard]] AiInferenceReport infer(const std::map<std::string,Tensor>& inputs, double time_s);
    [[nodiscard]] std::string assurance_report() const;
    [[nodiscard]] const OnnxModel& model() const;
private:
    OnnxModel model_;
    AiSafetyEnvelope envelope_;
    std::map<std::string,Tensor> previous_outputs_;
    double previous_time_s_ = -1.0;
    std::uint64_t inference_count_ = 0;
    std::uint64_t violation_count_ = 0;
    std::uint64_t fallback_count_ = 0;
};

// -----------------------------------------------------------------------------
// Integrated terminal/platform facade
// -----------------------------------------------------------------------------

class ElectrificationPlatform {
public:
    explicit ElectrificationPlatform(industrial::SignalRegistry& signals);
    ~ElectrificationPlatform();
    void update(double time_s, double step_s, double engine_rpm, double engine_torque_nm,
                double vehicle_speed_m_s, double ambient_temperature_k = 298.15);
    [[nodiscard]] std::string command(const std::vector<std::string>& arguments);
    [[nodiscard]] std::string status() const;

    // Single source of truth for electrification command aliases and nested
    // completion.  Dispatch resolves through the same registry, preventing a
    // valid command from becoming invisible to Tab completion.
    [[nodiscard]] static std::vector<std::string> completion_candidates(
        const std::vector<std::string>& arguments, bool ends_space);
    [[nodiscard]] static std::vector<std::string> command_aliases();
    [[nodiscard]] static std::string command_schema_report();
    [[nodiscard]] BatteryPack& battery() noexcept;
    [[nodiscard]] HybridPowertrain& hybrid() noexcept;
    [[nodiscard]] VehicleThermalSystem& thermal() noexcept;
    [[nodiscard]] Iso23150Fusion& fusion() noexcept;
    [[nodiscard]] HeterogeneousCompute& compute() noexcept;
    [[nodiscard]] AdvancedElectrifiedVehicle& advanced_vehicle() noexcept;
    [[nodiscard]] high_fidelity::IntegratedHighFidelityVehicle& high_fidelity_vehicle() noexcept;
    [[nodiscard]] high_fidelity::IntegratedVehicleDepthRuntime& depth_vehicle() noexcept;
    [[nodiscard]] high_fidelity::IntegratedVehicleEcosystemRuntime& ecosystem_vehicle() noexcept;
    [[nodiscard]] high_fidelity::IntegratedVehicleLifecycleRuntime& lifecycle_vehicle() noexcept;
private:
    industrial::SignalRegistry& signals_;
    BatteryPack battery_;
    ElectricDrive drive_;
    HybridPowertrain hybrid_;
    PlugAndChargePki pki_;
    Iso15118Session iso15118_;
    OcppChargePoint ocpp_;
    ChargingSystem charging_;
    VehicleThermalSystem thermal_;
    ModelicaModel modelica_;
    DdsDomain dds_;
    Ros2Bridge ros2_;
    Iso23150Fusion fusion_;
    HeterogeneousCompute compute_;
    AiAssuranceRuntime ai_;
    std::unique_ptr<AdvancedElectrifiedVehicle> advanced_vehicle_;
    std::unique_ptr<high_fidelity::IntegratedHighFidelityVehicle> high_fidelity_vehicle_;
    std::unique_ptr<high_fidelity::IntegratedVehicleDepthRuntime> depth_vehicle_;
    std::unique_ptr<high_fidelity::IntegratedVehicleEcosystemRuntime> ecosystem_vehicle_;
    std::unique_ptr<high_fidelity::IntegratedVehicleLifecycleRuntime> lifecycle_vehicle_;
    bool automatic_hybrid_ = false;
    bool automatic_thermal_ = false;
    bool automatic_advanced_vehicle_ = false;
    bool automatic_high_fidelity_ = false;
    bool automatic_depth_ = false;
    bool automatic_ecosystem_ = false;
    bool automatic_lifecycle_ = false;
    double time_s_ = 0.0;
    double previous_high_fidelity_speed_m_s_ = 0.0;
    bool high_fidelity_speed_initialized_ = false;
    double previous_depth_speed_m_s_ = 0.0;
    bool depth_speed_initialized_ = false;
    double previous_ecosystem_speed_m_s_ = 0.0;
    bool ecosystem_speed_initialized_ = false;
    double previous_lifecycle_speed_m_s_ = 0.0;
    bool lifecycle_speed_initialized_ = false;
    std::string last_error_;
    void register_signals();
    void publish_high_fidelity_signals();
    void publish_depth_signals();
    void publish_ecosystem_signals();
    void publish_lifecycle_signals();
};

[[nodiscard]] std::string to_string(HybridOperatingMode mode);
[[nodiscard]] std::string to_string(Iso15118State state);
[[nodiscard]] std::string to_string(ComputeOperation operation);

} // namespace aesim::electrification

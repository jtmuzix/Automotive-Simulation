#pragma once

#include "aesim/electrification/electrification.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <set>
#include <string>
#include <vector>

namespace aesim::electrification {

// Validated rectangular calibration map. Values are row-major with x varying
// fastest. Queries are clamped to the calibrated envelope and bilinearly
// interpolated.
class GridMap2D {
public:
    GridMap2D() = default;
    GridMap2D(std::vector<double> x_axis, std::vector<double> y_axis,
              std::vector<double> values);
    void set(std::vector<double> x_axis, std::vector<double> y_axis,
             std::vector<double> values);
    void load_csv(const std::string& path);
    [[nodiscard]] double evaluate(double x, double y) const;
    [[nodiscard]] bool empty() const noexcept { return values_.empty(); }
    [[nodiscard]] const std::vector<double>& x_axis() const noexcept { return x_axis_; }
    [[nodiscard]] const std::vector<double>& y_axis() const noexcept { return y_axis_; }
    [[nodiscard]] std::string status(const std::string& name) const;
private:
    std::vector<double> x_axis_;
    std::vector<double> y_axis_;
    std::vector<double> values_;
    void validate() const;
};

enum class ContactorState { Open, Precharge, Closed, WeldedFault };
enum class BmsFault : std::uint32_t {
    None = 0,
    CellUndervoltage = 1U << 0,
    CellOvervoltage = 1U << 1,
    Overtemperature = 1U << 2,
    Undertemperature = 1U << 3,
    Overcurrent = 1U << 4,
    Isolation = 1U << 5,
    Contactor = 1U << 6,
    CellImbalance = 1U << 7
};

struct BatteryManagementConfiguration {
    double precharge_resistance_ohm = 50.0;
    double dc_link_capacitance_f = 0.004;
    double precharge_completion_fraction = 0.92;
    double precharge_timeout_s = 5.0;
    double isolation_minimum_ohm_per_v = 500.0;
    double minimum_cell_voltage_v = 2.65;
    double maximum_cell_voltage_v = 4.25;
    double minimum_cell_temperature_k = 248.15;
    double maximum_cell_temperature_k = 335.15;
    double maximum_cell_delta_v = 0.080;
    double balancing_start_delta_v = 0.015;
    double balancing_temperature_limit_k = 318.15;
    double maximum_pack_current_a = 900.0;
    double current_filter_time_constant_s = 0.050;
    double fault_debounce_s = 0.050;
    bool latch_hazardous_faults = true;
};

struct BatteryManagementInput {
    bool key_on = false;
    bool charge_connector_present = false;
    bool service_disconnect_closed = true;
    bool crash_signal = false;
    bool clear_faults = false;
    bool main_contactor_feedback_valid = false;
    bool main_contactor_feedback_closed = false;
    double requested_pack_current_a = 0.0;
    double dc_link_voltage_v = 0.0;
    double isolation_resistance_ohm = 1.0e9;
};

struct BatteryManagementOutput {
    ContactorState contactor_state = ContactorState::Open;
    std::uint32_t active_fault_mask = 0;
    std::uint32_t latched_fault_mask = 0;
    double permitted_pack_current_a = 0.0;
    double discharge_power_limit_w = 0.0;
    double charge_power_limit_w = 0.0;
    double filtered_pack_current_a = 0.0;
    double estimated_dc_link_voltage_v = 0.0;
    double minimum_cell_voltage_v = 0.0;
    double maximum_cell_voltage_v = 0.0;
    double maximum_cell_temperature_k = 0.0;
    double cell_delta_v = 0.0;
    double precharge_elapsed_s = 0.0;
    bool balancing_enabled = false;
    bool torque_enable = false;
    bool charging_enable = false;
};

class BatteryManagementSystem {
public:
    BatteryManagementSystem();
    explicit BatteryManagementSystem(BatteryManagementConfiguration configuration);
    void configure(const BatteryManagementConfiguration& configuration);
    void reset();
    [[nodiscard]] BatteryManagementOutput step(const BatteryManagementInput& input,
                                               const BatteryPackOutput& pack,
                                               const std::vector<BatteryCellState>& cells,
                                               double dt_s);
    [[nodiscard]] const BatteryManagementOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    BatteryManagementConfiguration configuration_;
    BatteryManagementOutput output_;
    double fault_timer_s_ = 0.0;
};

struct EAxleConfiguration {
    ElectricMachineConfiguration left_machine;
    ElectricMachineConfiguration right_machine;
    InverterConfiguration left_inverter;
    InverterConfiguration right_inverter;
    double final_drive_ratio = 9.1;
    double gear_efficiency = 0.975;
    double maximum_wheel_torque_nm = 9000.0;
    double maximum_torque_vectoring_nm = 900.0;
    double half_track_m = 0.80;
    double rotational_inertia_kg_m2 = 0.34;
    GridMap2D motoring_efficiency_map;
    GridMap2D regeneration_efficiency_map;
    GridMap2D torque_limit_map;
};

struct EAxleInput {
    double requested_wheel_torque_nm = 0.0;
    double requested_yaw_moment_nm = 0.0;
    double left_wheel_speed_rad_s = 0.0;
    double right_wheel_speed_rad_s = 0.0;
    double dc_voltage_v = 400.0;
    double coolant_temperature_k = 298.15;
    double traction_limit_left_nm = 1.0e9;
    double traction_limit_right_nm = 1.0e9;
};

struct EAxleOutput {
    double left_wheel_torque_nm = 0.0;
    double right_wheel_torque_nm = 0.0;
    double delivered_wheel_torque_nm = 0.0;
    double delivered_yaw_moment_nm = 0.0;
    double dc_power_w = 0.0;
    double dc_current_a = 0.0;
    double mechanical_power_w = 0.0;
    double total_loss_w = 0.0;
    double map_efficiency = 0.0;
    double differential_speed_rad_s = 0.0;
    ElectricDriveOutput left_drive;
    ElectricDriveOutput right_drive;
    bool traction_limited = false;
    bool voltage_limited = false;
};

class ElectricEAxle {
public:
    ElectricEAxle();
    explicit ElectricEAxle(EAxleConfiguration configuration);
    void configure(EAxleConfiguration configuration);
    void reset(double temperature_k = 298.15);
    [[nodiscard]] EAxleOutput step(const EAxleInput& input, double dt_s);
    [[nodiscard]] const EAxleOutput& output() const noexcept { return output_; }
    [[nodiscard]] const EAxleConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] std::string status() const;
private:
    EAxleConfiguration configuration_;
    ElectricDrive left_drive_;
    ElectricDrive right_drive_;
    EAxleOutput output_;
};

struct FuelCellConfiguration {
    std::size_t cells = 400;
    double active_area_cm2 = 300.0;
    double open_circuit_voltage_per_cell_v = 1.03;
    double exchange_current_density_a_cm2 = 0.005;
    double limiting_current_density_a_cm2 = 1.8;
    double tafel_slope_v = 0.032;
    double area_specific_resistance_ohm_cm2 = 0.065;
    double nominal_stack_temperature_k = 353.15;
    double minimum_operating_temperature_k = 333.15;
    double maximum_stack_temperature_k = 373.15;
    double stack_heat_capacity_j_k = 210000.0;
    double coolant_conductance_w_k = 900.0;
    double compressor_power_per_kg_s = 80000.0;
    double coolant_pump_base_power_w = 350.0;
    double maximum_net_power_w = 150000.0;
    double hydrogen_tank_capacity_kg = 6.0;
    double initial_hydrogen_kg = 5.0;
    double hydrogen_lhv_j_kg = 120.0e6;
    double startup_heater_power_w = 5000.0;
};

struct FuelCellInput {
    double requested_net_power_w = 0.0;
    double coolant_temperature_k = 298.15;
    double ambient_temperature_k = 298.15;
    double ambient_pressure_pa = 101325.0;
    double relative_humidity = 0.5;
    bool enabled = false;
};

struct FuelCellOutput {
    double gross_power_w = 0.0;
    double net_power_w = 0.0;
    double parasitic_power_w = 0.0;
    double startup_heater_power_w = 0.0;
    double stack_voltage_v = 0.0;
    double stack_current_a = 0.0;
    double cell_voltage_v = 0.0;
    double hydrogen_flow_kg_s = 0.0;
    double hydrogen_remaining_kg = 0.0;
    double air_mass_flow_kg_s = 0.0;
    double oxygen_excess_ratio = 0.0;
    double water_generation_kg_s = 0.0;
    double waste_heat_w = 0.0;
    double stack_temperature_k = 298.15;
    double membrane_hydration = 0.7;
    double lhv_efficiency = 0.0;
    bool power_limited = false;
    bool cold_start_active = false;
};

class FuelCellSystem {
public:
    FuelCellSystem();
    explicit FuelCellSystem(FuelCellConfiguration configuration);
    void configure(const FuelCellConfiguration& configuration);
    void reset(double temperature_k = 298.15, double hydrogen_kg = -1.0);
    [[nodiscard]] FuelCellOutput step(const FuelCellInput& input, double dt_s);
    [[nodiscard]] const FuelCellOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    FuelCellConfiguration configuration_;
    FuelCellOutput output_;
    [[nodiscard]] double gross_power_for_current(double current_a) const;
};

enum class ElectrifiedArchitecture { Bev, SeriesHybrid, ParallelHybrid, PlugInHybrid, FuelCell };

struct ElectrifiedPowertrainConfiguration {
    ElectrifiedArchitecture architecture = ElectrifiedArchitecture::Bev;
    BatteryPackConfiguration battery = [] {
        BatteryPackConfiguration value;
        value.series_cells = 108;
        value.parallel_cells = 36;
        value.initial_soc = 0.80;
        return value;
    }();
    BatteryManagementConfiguration bms;
    EAxleConfiguration front_eaxle = [] {
        EAxleConfiguration value;
        value.left_machine.name = "front_left_traction_machine";
        value.right_machine.name = "front_right_traction_machine";
        value.left_machine.iron_loss_coefficient = 3.5e-4;
        value.right_machine.iron_loss_coefficient = 3.5e-4;
        return value;
    }();
    EAxleConfiguration rear_eaxle = [] {
        EAxleConfiguration value;
        value.left_machine.name = "rear_left_traction_machine";
        value.right_machine.name = "rear_right_traction_machine";
        value.left_machine.iron_loss_coefficient = 3.5e-4;
        value.right_machine.iron_loss_coefficient = 3.5e-4;
        return value;
    }();
    FuelCellConfiguration fuel_cell;
    bool front_eaxle_enabled = false;
    bool rear_eaxle_enabled = true;
    double engine_generator_efficiency = 0.90;
    double engine_peak_efficiency = 0.39;
    double fuel_lhv_j_kg = 42.7e6;
    double target_soc = 0.60;
    double soc_charge_sustain_band = 0.05;
    double dc_bus_capacitance_f = 0.010;
};

struct ElectrifiedPowertrainInput {
    bool key_on = true;
    bool charge_connector_present = false;
    bool crash_signal = false;
    double requested_wheel_torque_nm = 0.0;
    double requested_yaw_moment_nm = 0.0;
    std::array<double,4> wheel_speed_rad_s{};
    std::array<double,4> traction_torque_limit_nm{{1.0e9,1.0e9,1.0e9,1.0e9}};
    double engine_available_power_w = 0.0;
    double ambient_temperature_k = 298.15;
    double coolant_temperature_k = 298.15;
    double isolation_resistance_ohm = 1.0e9;
};

struct ElectrifiedPowertrainOutput {
    ElectrifiedArchitecture architecture = ElectrifiedArchitecture::Bev;
    std::array<double,4> wheel_torque_nm{};
    double delivered_wheel_torque_nm = 0.0;
    double requested_battery_power_w = 0.0;
    double battery_power_w = 0.0;
    double engine_power_request_w = 0.0;
    double fuel_cell_power_request_w = 0.0;
    double fuel_rate_kg_s = 0.0;
    double hydrogen_rate_kg_s = 0.0;
    double total_electrical_loss_w = 0.0;
    double dc_bus_voltage_v = 0.0;
    double dc_bus_energy_residual_w = 0.0;
    BatteryPackOutput battery;
    BatteryManagementOutput bms;
    EAxleOutput front_eaxle;
    EAxleOutput rear_eaxle;
    FuelCellOutput fuel_cell;
    bool propulsion_available = false;
    bool derated = false;
};

class ElectrifiedPowertrain {
public:
    ElectrifiedPowertrain();
    explicit ElectrifiedPowertrain(ElectrifiedPowertrainConfiguration configuration);
    void configure(ElectrifiedPowertrainConfiguration configuration);
    void reset();
    [[nodiscard]] ElectrifiedPowertrainOutput step(const ElectrifiedPowertrainInput& input,
                                                   double dt_s);
    [[nodiscard]] const ElectrifiedPowertrainOutput& output() const noexcept { return output_; }
    [[nodiscard]] BatteryPack& battery() noexcept { return battery_; }
    [[nodiscard]] BatteryManagementSystem& bms() noexcept { return bms_; }
    [[nodiscard]] std::string status() const;
private:
    ElectrifiedPowertrainConfiguration configuration_;
    BatteryPack battery_;
    BatteryManagementSystem bms_;
    ElectricEAxle front_eaxle_;
    ElectricEAxle rear_eaxle_;
    FuelCellSystem fuel_cell_;
    ElectrifiedPowertrainOutput output_;
    double dc_bus_voltage_v_ = 0.0;
};

struct BrakeByWireConfiguration {
    double master_cylinder_area_m2 = 4.9e-4;
    double front_caliper_area_m2 = 0.0042;
    double rear_caliper_area_m2 = 0.0028;
    double front_effective_radius_m = 0.165;
    double rear_effective_radius_m = 0.150;
    double pad_friction_coefficient = 0.40;
    double maximum_line_pressure_pa = 18.0e6;
    double pressure_rise_time_constant_s = 0.045;
    double pressure_fall_time_constant_s = 0.025;
    double pedal_force_max_n = 650.0;
    double booster_ratio = 7.0;
    double regenerative_fraction_target = 0.70;
    double minimum_regen_speed_m_s = 1.5;
    double abs_slip_threshold = 0.16;
    double abs_release_rate_per_s = 20.0;
    double abs_apply_rate_per_s = 8.0;
    double disc_heat_capacity_j_k = 42000.0;
    double disc_cooling_w_k = 45.0;
    double fade_start_temperature_k = 650.0;
    double fade_full_temperature_k = 950.0;
    double pad_wear_energy_j = 1.8e9;
};

struct BrakeByWireInput {
    double pedal_fraction = 0.0;
    double requested_deceleration_m_s2 = 0.0;
    double vehicle_speed_m_s = 0.0;
    std::array<double,4> wheel_speed_rad_s{};
    std::array<double,4> normal_load_n{};
    std::array<double,4> road_mu{{1.0,1.0,1.0,1.0}};
    double wheel_radius_m = 0.33;
    double available_regen_torque_nm = 0.0;
    double battery_charge_power_limit_w = 0.0;
    bool stability_control_request = false;
    double yaw_moment_request_nm = 0.0;
    double ambient_temperature_k = 298.15;
};

struct BrakeByWireOutput {
    std::array<double,4> wheel_friction_torque_nm{};
    std::array<double,4> line_pressure_pa{};
    std::array<double,4> disc_temperature_k{{298.15,298.15,298.15,298.15}};
    std::array<double,4> pad_wear_fraction{};
    std::array<bool,4> abs_active{};
    double demanded_total_torque_nm = 0.0;
    double regenerative_torque_nm = 0.0;
    double friction_torque_nm = 0.0;
    double recovered_power_w = 0.0;
    double hydraulic_power_w = 0.0;
    double blend_error_nm = 0.0;
    bool degraded = false;
};

class BrakeByWireSystem {
public:
    BrakeByWireSystem();
    explicit BrakeByWireSystem(BrakeByWireConfiguration configuration);
    void configure(const BrakeByWireConfiguration& configuration);
    void reset(double temperature_k = 298.15);
    [[nodiscard]] BrakeByWireOutput step(const BrakeByWireInput& input, double dt_s);
    [[nodiscard]] const BrakeByWireOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    BrakeByWireConfiguration configuration_;
    BrakeByWireOutput output_;
    std::array<double,4> abs_modulation_{{1.0,1.0,1.0,1.0}};
};

struct ActiveChassisConfiguration {
    double low_speed_rear_steer_gain = -0.30;
    double high_speed_rear_steer_gain = 0.12;
    double transition_speed_m_s = 15.0;
    double maximum_rear_steer_rad = 0.10;
    double rear_steer_rate_rad_s = 0.35;
    double roll_stiffness_gain_n_m_rad = 18000.0;
    double roll_damping_gain_n_m_s_rad = 3500.0;
    double heave_stiffness_gain_n_m = 12000.0;
    double heave_damping_gain_n_s_m = 1800.0;
    double sprung_mass_kg = 1500.0;
    double center_of_gravity_height_m = 0.55;
    double acceleration_feedforward_fraction = 0.65;
    double maximum_actuator_force_n = 5000.0;
    double yaw_rate_gain_n_m_s_rad = 4200.0;
    double sideslip_gain_n_m_rad = 6000.0;
    double maximum_yaw_moment_nm = 3500.0;
    double track_width_m = 1.60;
    double wheelbase_m = 2.80;
};

struct ActiveChassisInput {
    double speed_m_s = 0.0;
    double steering_rad = 0.0;
    double yaw_rate_rad_s = 0.0;
    double sideslip_rad = 0.0;
    double roll_rad = 0.0;
    double roll_rate_rad_s = 0.0;
    double pitch_rad = 0.0;
    double pitch_rate_rad_s = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    std::array<double,4> suspension_displacement_m{};
    std::array<double,4> suspension_velocity_m_s{};
};

struct ActiveChassisOutput {
    std::array<double,4> actuator_force_n{};
    std::array<double,4> damping_force_n{};
    double rear_steer_rad = 0.0;
    double desired_yaw_rate_rad_s = 0.0;
    double yaw_moment_request_nm = 0.0;
    double roll_moment_nm = 0.0;
    double pitch_moment_nm = 0.0;
    bool rear_steer_limited = false;
    bool suspension_saturated = false;
};

class ActiveChassisSystem {
public:
    ActiveChassisSystem();
    explicit ActiveChassisSystem(ActiveChassisConfiguration configuration);
    void configure(const ActiveChassisConfiguration& configuration);
    void reset();
    [[nodiscard]] ActiveChassisOutput step(const ActiveChassisInput& input, double dt_s);
    [[nodiscard]] const ActiveChassisOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    ActiveChassisConfiguration configuration_;
    ActiveChassisOutput output_;
};

struct PayloadItem {
    std::string id;
    double mass_kg = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
    double longitudinal_restraint_n = 0.0;
    double lateral_restraint_n = 0.0;
    double shift_compliance_m_n = 0.0;
};

struct TrailerConfiguration {
    double empty_mass_kg = 550.0;
    double yaw_inertia_kg_m2 = 2100.0;
    double hitch_to_axle_m = 3.2;
    double empty_cg_x_m = 1.9;
    double hitch_damping_n_m_s_rad = 2200.0;
    double tire_cornering_stiffness_n_rad = 70000.0;
    double tire_longitudinal_stiffness_n = 120000.0;
    double brake_force_max_n = 16000.0;
    double articulation_limit_rad = 1.25;
    double load_shift_time_constant_s = 0.30;
    double maximum_load_shift_m = 0.75;
};

struct TrailerPayloadInput {
    double tow_vehicle_speed_m_s = 0.0;
    double tow_longitudinal_acceleration_m_s2 = 0.0;
    double tow_lateral_acceleration_m_s2 = 0.0;
    double tow_yaw_rate_rad_s = 0.0;
    double hitch_longitudinal_displacement_m = 0.0;
    double trailer_brake_fraction = 0.0;
    double road_grade_rad = 0.0;
};

struct TrailerPayloadOutput {
    double payload_mass_kg = 0.0;
    double payload_cg_x_m = 0.0;
    double payload_cg_y_m = 0.0;
    double payload_cg_z_m = 0.0;
    double shifted_payload_cg_x_m = 0.0;
    double shifted_payload_cg_y_m = 0.0;
    double articulation_angle_rad = 0.0;
    double articulation_rate_rad_s = 0.0;
    double hitch_longitudinal_force_n = 0.0;
    double hitch_lateral_force_n = 0.0;
    double trailer_axle_load_n = 0.0;
    double tongue_load_n = 0.0;
    double jackknife_risk = 0.0;
    bool load_restraint_exceeded = false;
    bool articulation_limit_exceeded = false;
};

class TrailerPayloadDynamics {
public:
    TrailerPayloadDynamics();
    explicit TrailerPayloadDynamics(TrailerConfiguration configuration);
    void configure(const TrailerConfiguration& configuration);
    void set_payload(std::vector<PayloadItem> payload);
    void reset();
    [[nodiscard]] TrailerPayloadOutput step(const TrailerPayloadInput& input, double dt_s);
    [[nodiscard]] const TrailerPayloadOutput& output() const noexcept { return output_; }
    [[nodiscard]] const std::vector<PayloadItem>& payload() const noexcept { return payload_; }
    [[nodiscard]] std::string status() const;
private:
    TrailerConfiguration configuration_;
    std::vector<PayloadItem> payload_;
    TrailerPayloadOutput output_;
};

struct ExhaustSpecies {
    double co_g_s = 0.0;
    double hc_g_s = 0.0;
    double no_g_s = 0.0;
    double no2_g_s = 0.0;
    double nh3_g_s = 0.0;
    double pm_g_s = 0.0;
    double co2_g_s = 0.0;
};

struct AftertreatmentConfiguration {
    double doc_thermal_mass_j_k = 18000.0;
    double twc_thermal_mass_j_k = 21000.0;
    double dpf_thermal_mass_j_k = 26000.0;
    double scr_thermal_mass_j_k = 22000.0;
    double heat_loss_w_k = 35.0;
    double gas_heat_capacity_j_kg_k = 1100.0;
    double doc_lightoff_k = 470.0;
    double twc_lightoff_k = 520.0;
    double scr_lightoff_k = 470.0;
    double maximum_soot_kg = 0.012;
    double soot_burn_preexponential_s = 1.5e6;
    double soot_burn_activation_j_mol = 125000.0;
    double scr_ammonia_storage_capacity_g = 4.0;
    double nox_reduction_rate_s = 16.0;
    double scr_residence_time_s = 0.08;
    double ammonia_slip_rate_s = 1.8;
    double pressure_drop_base_pa = 2500.0;
};

struct AftertreatmentInput {
    ExhaustSpecies engine_out;
    double exhaust_mass_flow_kg_s = 0.0;
    double exhaust_temperature_k = 298.15;
    double ambient_temperature_k = 298.15;
    double equivalence_ratio = 1.0;
    double oxygen_fraction = 0.10;
    double urea_dosing_g_s = 0.0;
    bool forced_regeneration = false;
};

struct AftertreatmentOutput {
    ExhaustSpecies tailpipe;
    double doc_temperature_k = 298.15;
    double twc_temperature_k = 298.15;
    double dpf_temperature_k = 298.15;
    double scr_temperature_k = 298.15;
    double soot_mass_kg = 0.0;
    double ammonia_storage_g = 0.0;
    double pressure_drop_pa = 0.0;
    double co_conversion = 0.0;
    double hc_conversion = 0.0;
    double nox_conversion = 0.0;
    double pm_conversion = 0.0;
    bool dpf_regeneration_active = false;
    bool dpf_overloaded = false;
};

class ExhaustAftertreatmentSystem {
public:
    ExhaustAftertreatmentSystem();
    explicit ExhaustAftertreatmentSystem(AftertreatmentConfiguration configuration);
    void configure(const AftertreatmentConfiguration& configuration);
    void reset(double temperature_k = 298.15);
    [[nodiscard]] AftertreatmentOutput step(const AftertreatmentInput& input, double dt_s);
    [[nodiscard]] const AftertreatmentOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    AftertreatmentConfiguration configuration_;
    AftertreatmentOutput output_;
};

struct EthernetFrame {
    std::string source_ecu;
    std::string destination_ecu;
    std::uint8_t priority = 0;
    std::uint64_t enqueue_time_ns = 0;
    std::uint64_t deadline_ns = 0;
    std::uint16_t ether_type = 0x0800;
    std::vector<std::uint8_t> payload;
};

struct SomeIpMessage {
    std::uint16_t service_id = 0;
    std::uint16_t method_id = 0;
    std::uint16_t client_id = 0;
    std::uint16_t session_id = 0;
    std::uint8_t protocol_version = 1;
    std::uint8_t interface_version = 1;
    std::uint8_t message_type = 0;
    std::uint8_t return_code = 0;
    std::vector<std::uint8_t> payload;
};

struct DistributedEcuConfiguration {
    std::string id;
    double clock_offset_us = 0.0;
    double processing_latency_us = 50.0;
    std::size_t receive_queue_capacity = 128;
    std::set<std::uint16_t> provided_services;
};

struct NetworkStatistics {
    std::uint64_t transmitted_frames = 0;
    std::uint64_t delivered_frames = 0;
    std::uint64_t dropped_frames = 0;
    std::uint64_t deadline_misses = 0;
    double mean_latency_us = 0.0;
    double maximum_latency_us = 0.0;
    double utilization = 0.0;
};

class AutomotiveEthernetNetwork {
public:
    void configure(double bitrate_mbps = 1000.0, std::uint64_t cycle_time_ns = 1000000);
    void reset();
    void add_or_replace_ecu(DistributedEcuConfiguration ecu);
    void register_someip_service(std::uint16_t service_id, const std::string& provider_ecu);
    void set_gate_schedule(std::uint8_t priority, std::uint64_t open_ns,
                           std::uint64_t close_ns);
    void send_frame(EthernetFrame frame);
    void send_someip(const std::string& source_ecu, const std::string& destination_ecu,
                     const SomeIpMessage& message, std::uint8_t priority,
                     std::uint64_t deadline_ns);
    void advance(double dt_s);
    [[nodiscard]] std::vector<EthernetFrame> receive(const std::string& ecu_id);
    [[nodiscard]] std::uint64_t time_ns() const noexcept { return time_ns_; }
    [[nodiscard]] const NetworkStatistics& statistics() const noexcept { return statistics_; }
    [[nodiscard]] std::string status() const;
    [[nodiscard]] static std::vector<std::uint8_t> encode_someip(const SomeIpMessage& message);
    [[nodiscard]] static SomeIpMessage decode_someip(const std::vector<std::uint8_t>& bytes);
private:
    struct GateWindow { std::uint64_t open_ns=0; std::uint64_t close_ns=0; };
    double bitrate_bps_ = 1.0e9;
    std::uint64_t cycle_time_ns_ = 1000000;
    std::uint64_t time_ns_ = 0;
    double fractional_time_ns_ = 0.0;
    std::map<std::string,DistributedEcuConfiguration> ecus_;
    std::map<std::uint16_t,std::string> services_;
    std::map<std::uint8_t,GateWindow> gates_;
    std::array<std::deque<EthernetFrame>,8> transmit_queues_;
    std::map<std::string,std::deque<EthernetFrame>> receive_queues_;
    NetworkStatistics statistics_;
    double latency_sum_us_ = 0.0;
    [[nodiscard]] bool gate_open(std::uint8_t priority, std::uint64_t time_ns) const;
};

enum class SOVDSessionState { Disconnected, Connected, Authenticated, Programming };

struct SOVDFault {
    std::string code;
    std::string severity;
    std::string description;
    bool active = true;
    std::uint64_t occurrence_count = 0;
    double first_seen_s = 0.0;
    double last_seen_s = 0.0;
    std::map<std::string,double> environment_data;
};

class SOVDServer {
public:
    void register_entity(const std::string& id, std::map<std::string,std::string> metadata);
    void connect(const std::string& client_id);
    void authenticate(const std::string& bearer_token);
    void disconnect();
    void report_fault(const std::string& entity_id, SOVDFault fault);
    void register_operation(const std::string& entity_id, const std::string& operation,
                            std::function<doc::Value(const doc::Value&)> handler);
    [[nodiscard]] doc::Value request(const std::string& method, const std::string& path,
                                     const doc::Value& body = {});
    [[nodiscard]] SOVDSessionState state() const noexcept { return state_; }
    [[nodiscard]] std::string status() const;
private:
    struct Entity {
        std::map<std::string,std::string> metadata;
        std::map<std::string,SOVDFault> faults;
        std::map<std::string,std::function<doc::Value(const doc::Value&)>> operations;
    };
    std::map<std::string,Entity> entities_;
    SOVDSessionState state_ = SOVDSessionState::Disconnected;
    std::string client_id_;
};

enum class OtaLifecycleState {
    Idle, Downloading, Validating, Staged, Installing, Verifying, Active,
    RollingBack, Failed
};

struct OtaManifest {
    std::string campaign_id;
    std::string target_version;
    std::string payload_sha256;
    std::size_t payload_size = 0;
    bool signed_manifest_valid = false;
    double minimum_soc = 0.30;
    std::set<std::string> target_ecus;
};

struct OtaLifecycleOutput {
    OtaLifecycleState state = OtaLifecycleState::Idle;
    std::string active_version = "0.0.0";
    std::string staged_version;
    double progress = 0.0;
    std::string last_error;
    bool rollback_available = false;
};

class OtaLifecycleManager {
public:
    void reset(const std::string& active_version = "1.0.0");
    void begin(OtaManifest manifest);
    void provide_payload(std::vector<std::uint8_t> payload);
    void request_rollback();
    [[nodiscard]] OtaLifecycleOutput step(double dt_s, bool vehicle_stationary,
                                          double battery_soc, bool ecu_health_ok);
    [[nodiscard]] const OtaLifecycleOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    OtaManifest manifest_;
    std::vector<std::uint8_t> payload_;
    OtaLifecycleOutput output_;
    std::string previous_version_;
    bool rollback_requested_ = false;
};

struct SOTIFScenarioParameters {
    double ego_speed_m_s = 20.0;
    double target_speed_m_s = 0.0;
    double initial_range_m = 40.0;
    double sensor_latency_s = 0.10;
    double sensor_range_bias_m = 0.0;
    double road_friction = 0.8;
    double visibility = 1.0;
    double target_lateral_offset_m = 0.0;
};

struct SOTIFFalsificationConfiguration {
    std::size_t population = 64;
    std::size_t generations = 30;
    std::uint64_t seed = 1;
    double elite_fraction = 0.20;
    double mutation_scale = 0.20;
};

struct SOTIFFalsificationResult {
    SOTIFScenarioParameters scenario;
    double objective = 0.0;
    std::size_t evaluations = 0;
    std::vector<double> best_history;
};

class SOTIFFalsifier {
public:
    [[nodiscard]] SOTIFFalsificationResult search(
        const SOTIFFalsificationConfiguration& configuration,
        const std::function<double(const SOTIFScenarioParameters&)>& objective) const;
    [[nodiscard]] static double automatic_emergency_braking_margin(
        const SOTIFScenarioParameters& scenario);
};

struct RegulatoryDurabilityConfiguration {
    double nominal_battery_capacity_ah = 180.0;
    double battery_capacity_throughput_reference_ah = 1.2e6;
    double battery_resistance_throughput_reference_ah = 8.0e5;
    double brake_wear_energy_j = 2.5e9;
    double tire_wear_energy_j = 1.8e9;
    double battery_capacity_loss_limit = 0.20;
    double battery_resistance_growth_limit = 0.50;
    double brake_wear_limit = 1.0;
    double tire_wear_limit = 1.0;
    double required_distance_km = 160000.0;
    double required_battery_efc = 1000.0;
};

struct DurabilityInput {
    double battery_current_a = 0.0;
    double battery_temperature_k = 298.15;
    double battery_soc = 0.5;
    double brake_energy_w = 0.0;
    double brake_temperature_k = 298.15;
    double tire_longitudinal_force_n = 0.0;
    double tire_lateral_force_n = 0.0;
    double tire_temperature_k = 298.15;
    double vehicle_speed_m_s = 0.0;
};

struct DurabilityOutput {
    double distance_km = 0.0;
    double battery_charge_throughput_ah = 0.0;
    double battery_equivalent_full_cycles = 0.0;
    double battery_capacity_loss_fraction = 0.0;
    double battery_resistance_growth_fraction = 0.0;
    double brake_energy_mj = 0.0;
    double brake_wear_fraction = 0.0;
    double tire_slip_energy_mj = 0.0;
    double tire_wear_fraction = 0.0;
    double regulatory_severity_index = 0.0;
    bool battery_limit_exceeded = false;
    bool brake_limit_exceeded = false;
    bool tire_limit_exceeded = false;
    bool distance_exposure_complete = false;
    bool battery_exposure_complete = false;
    bool screening_pass = false;
};

class RegulatoryDurabilityMonitor {
public:
    RegulatoryDurabilityMonitor();
    explicit RegulatoryDurabilityMonitor(RegulatoryDurabilityConfiguration configuration);
    void configure(const RegulatoryDurabilityConfiguration& configuration);
    void reset();
    [[nodiscard]] DurabilityOutput step(const DurabilityInput& input, double dt_s);
    [[nodiscard]] const DurabilityOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    RegulatoryDurabilityConfiguration configuration_;
    DurabilityOutput output_;
};

struct DigitalTwinMeasurement {
    double longitudinal_acceleration_m_s2 = 0.0;
    double battery_voltage_v = 0.0;
    double battery_current_a = 0.0;
    double wheel_torque_nm = 0.0;
    double vehicle_speed_m_s = 0.0;
    double road_grade_rad = 0.0;
    double ambient_temperature_k = 298.15;
};

struct DigitalTwinPrediction {
    double longitudinal_acceleration_m_s2 = 0.0;
    double battery_voltage_v = 0.0;
};

struct DigitalTwinAssimilationOutput {
    double mass_scale = 1.0;
    double drag_scale = 1.0;
    double rolling_resistance_scale = 1.0;
    double battery_resistance_scale = 1.0;
    std::array<double,4> parameter_stddev{{1.0,1.0,1.0,1.0}};
    double acceleration_residual_m_s2 = 0.0;
    double voltage_residual_v = 0.0;
    double acceleration_model_uncertainty = 0.0;
    double voltage_model_uncertainty = 0.0;
    double normalized_innovation_squared = 0.0;
};

class OnlineDigitalTwinAssimilator {
public:
    OnlineDigitalTwinAssimilator();
    void reset();
    [[nodiscard]] DigitalTwinAssimilationOutput assimilate(
        const DigitalTwinMeasurement& measurement,
        const DigitalTwinPrediction& prediction, double dt_s);
    [[nodiscard]] const DigitalTwinAssimilationOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string status() const;
private:
    std::array<double,4> theta_{{1.0,1.0,1.0,1.0}};
    std::array<std::array<double,4>,4> covariance_{};
    DigitalTwinAssimilationOutput output_;
    double acceleration_variance_ = 0.25;
    double voltage_variance_ = 4.0;
};

struct AdvancedElectrifiedVehicleInput {
    ElectrifiedPowertrainInput powertrain;
    BrakeByWireInput braking;
    ActiveChassisInput chassis;
    TrailerPayloadInput trailer;
    AftertreatmentInput aftertreatment;
    DurabilityInput durability;
    DigitalTwinMeasurement digital_twin_measurement;
    DigitalTwinPrediction digital_twin_prediction;
};

struct AdvancedElectrifiedVehicleOutput {
    ElectrifiedPowertrainOutput powertrain;
    BrakeByWireOutput braking;
    ActiveChassisOutput chassis;
    TrailerPayloadOutput trailer;
    AftertreatmentOutput aftertreatment;
    DurabilityOutput durability;
    DigitalTwinAssimilationOutput digital_twin;
};

class AdvancedElectrifiedVehicle {
public:
    AdvancedElectrifiedVehicle();
    void reset();
    void set_architecture(ElectrifiedArchitecture architecture);
    void set_payload(std::vector<PayloadItem> payload);
    [[nodiscard]] AdvancedElectrifiedVehicleOutput step(
        const AdvancedElectrifiedVehicleInput& input, double dt_s);
    [[nodiscard]] const AdvancedElectrifiedVehicleOutput& output() const noexcept { return output_; }
    [[nodiscard]] ElectrifiedPowertrain& powertrain() noexcept { return powertrain_; }
    [[nodiscard]] AutomotiveEthernetNetwork& network() noexcept { return network_; }
    [[nodiscard]] SOVDServer& sovd() noexcept { return sovd_; }
    [[nodiscard]] OtaLifecycleManager& ota() noexcept { return ota_; }
    [[nodiscard]] SOTIFFalsifier& sotif() noexcept { return sotif_; }
    [[nodiscard]] std::string status() const;
private:
    ElectrifiedPowertrainConfiguration powertrain_configuration_;
    ElectrifiedPowertrain powertrain_;
    BrakeByWireSystem braking_;
    ActiveChassisSystem chassis_;
    TrailerPayloadDynamics trailer_;
    ExhaustAftertreatmentSystem aftertreatment_;
    AutomotiveEthernetNetwork network_;
    SOVDServer sovd_;
    OtaLifecycleManager ota_;
    SOTIFFalsifier sotif_;
    RegulatoryDurabilityMonitor durability_;
    OnlineDigitalTwinAssimilator digital_twin_;
    AdvancedElectrifiedVehicleOutput output_;
};

[[nodiscard]] std::string to_string(ContactorState state);
[[nodiscard]] std::string to_string(ElectrifiedArchitecture architecture);
[[nodiscard]] std::string to_string(OtaLifecycleState state);

} // namespace aesim::electrification

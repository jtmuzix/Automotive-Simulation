#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

struct FlashPartition {
    std::string name;
    std::size_t offset = 0;
    std::size_t size = 0;
    bool executable = false;
    bool writable = true;
};
struct FirmwareImage {
    std::string version;
    std::vector<std::uint8_t> payload;
    std::string expected_sha256;
    std::uint64_t rollback_counter = 0;
};
struct FlashOperationReport {
    bool accepted = false;
    bool programmed = false;
    bool verified = false;
    bool activated = false;
    bool recovery_required = false;
    std::size_t bytes_written = 0;
    double elapsed_s = 0.0;
    std::string digest;
    std::string failure;
};
class BootloaderFlashingLaboratory {
public:
    explicit BootloaderFlashingLaboratory(std::size_t flash_size_bytes = 1024 * 1024);
    void define_partition(FlashPartition partition);
    void set_supply_limits(double minimum_programming_voltage_v, double maximum_programming_voltage_v);
    [[nodiscard]] FlashOperationReport program(const std::string& partition,
                                               const FirmwareImage& image,
                                               double supply_voltage_v,
                                               double transport_rate_bytes_per_s,
                                               std::optional<std::size_t> interrupt_after_bytes = std::nullopt);
    [[nodiscard]] bool activate(const std::string& partition, std::string& error);
    [[nodiscard]] std::string active_partition() const;
    [[nodiscard]] std::vector<std::uint8_t> read_partition(const std::string& partition) const;
private:
    std::vector<std::uint8_t> flash_;
    std::map<std::string, FlashPartition> partitions_;
    std::map<std::string, std::uint64_t> rollback_counters_;
    std::string active_partition_;
    double minimum_voltage_v_ = 9.0;
    double maximum_voltage_v_ = 16.0;
};

enum class AutosarModuleKind { EcuM, BswM, ComM, CanSm, LinSm, EthSm, WdgM, Dem, NvM, Fls, Adc, Pwm, Spi, Dio, Gpt, Icu };
enum class AutosarModuleState { Uninitialized, Starting, Online, Sleep, Degraded, Failed };
struct AutosarModuleConfig {
    std::string id;
    AutosarModuleKind kind = AutosarModuleKind::EcuM;
    double period_s = 0.01;
    double execution_time_s = 0.001;
    double deadline_s = 0.01;
    std::vector<std::string> dependencies;
};
struct AutosarModuleReport {
    AutosarModuleState state = AutosarModuleState::Uninitialized;
    std::size_t activations = 0;
    std::size_t deadline_misses = 0;
    double utilization = 0.0;
    std::string diagnostic_event;
};
struct AutosarRuntimeReport {
    std::map<std::string, AutosarModuleReport> modules;
    double cpu_utilization = 0.0;
    bool watchdog_expired = false;
    bool communication_available = false;
    std::vector<std::string> mode_transitions;
};
class AutosarBswMcalRuntime {
public:
    void add_module(AutosarModuleConfig module);
    void initialize();
    void request_sleep(bool value);
    void inject_module_fault(const std::string& module_id, bool failed);
    [[nodiscard]] AutosarRuntimeReport advance(double dt_s, bool network_activity,
                                               bool watchdog_service,
                                               double supply_voltage_v);
private:
    std::map<std::string, AutosarModuleConfig> configs_;
    std::map<std::string, AutosarModuleReport> reports_;
    std::map<std::string, double> elapsed_;
    bool sleep_requested_ = false;
    double watchdog_elapsed_s_ = 0.0;
};

enum class RtlOperation { And, Or, Xor, Not, Add, Subtract, Multiply, CompareEqual, Register, SaturatingAdd };
struct RtlNode {
    std::string output;
    RtlOperation operation = RtlOperation::Register;
    std::vector<std::string> inputs;
    std::uint64_t constant = 0;
    unsigned width = 32;
};
struct RtlAssertion {
    std::string signal;
    std::uint64_t maximum_value = 0;
    std::uint64_t minimum_value = 0;
};
struct RtlCosimulationReport {
    std::map<std::string, std::uint64_t> signals;
    std::vector<std::string> assertion_failures;
    std::size_t cycles = 0;
    std::size_t transactions = 0;
    bool deterministic = true;
};
class RtlSystemCCosimulator {
public:
    void define_signal(std::string id, unsigned width, std::uint64_t initial_value = 0);
    void add_node(RtlNode node);
    void add_assertion(RtlAssertion assertion);
    void write_signal(const std::string& id, std::uint64_t value);
    [[nodiscard]] RtlCosimulationReport run(std::size_t cycles,
                                            const std::vector<std::map<std::string, std::uint64_t>>& transactions = {});
private:
    std::map<std::string, unsigned> widths_;
    std::map<std::string, std::uint64_t> signals_;
    std::vector<RtlNode> nodes_;
    std::vector<RtlAssertion> assertions_;
};

struct BistReport {
    bool passed = false;
    std::size_t tested_words = 0;
    std::size_t detected_faults = 0;
    std::vector<std::size_t> failing_addresses;
    std::uint64_t signature = 0;
    double diagnostic_coverage = 0.0;
};
class BuiltInSelfTestLaboratory {
public:
    [[nodiscard]] BistReport march_c_minus(std::vector<std::uint32_t> memory,
                                          const std::map<std::size_t, std::uint32_t>& stuck_at_masks = {}) const;
    [[nodiscard]] BistReport logic_bist(std::uint64_t seed, std::size_t patterns,
                                       const std::vector<std::uint64_t>& faulty_response_masks = {}) const;
};

enum class NvmTechnology { Eeprom, NorFlash, NandFlash, Fram, Mram };
struct NvmConfig {
    NvmTechnology technology = NvmTechnology::NorFlash;
    std::size_t bytes = 1024 * 1024;
    std::size_t page_size = 256;
    std::size_t erase_block_size = 4096;
    std::uint64_t endurance_cycles = 100000;
    double retention_years_at_25c = 20.0;
    unsigned ecc_correctable_bits = 1;
};
struct NvmReport {
    bool write_committed = false;
    bool recovered_after_power_loss = false;
    std::uint64_t maximum_wear_cycles = 0;
    double retention_error_probability = 0.0;
    std::size_t corrected_bits = 0;
    std::size_t uncorrectable_pages = 0;
    double remaining_life_fraction = 1.0;
};
class NvmReliabilityLaboratory {
public:
    explicit NvmReliabilityLaboratory(NvmConfig config = {});
    [[nodiscard]] NvmReport write(std::size_t address, const std::vector<std::uint8_t>& data,
                                  double temperature_k, bool power_loss_during_commit = false);
    [[nodiscard]] std::vector<std::uint8_t> read(std::size_t address, std::size_t count,
                                                 double elapsed_years, double temperature_k,
                                                 NvmReport& report) const;
private:
    NvmConfig config_;
    std::vector<std::uint8_t> data_;
    std::vector<std::uint64_t> wear_;
    std::vector<std::uint8_t> journal_;
    std::size_t journal_address_ = 0;
    bool journal_valid_ = false;
};

enum class AgingMechanism { BiasTemperatureInstability, HotCarrierInjection, TimeDependentDielectricBreakdown, Electromigration, PowerCycling, ThermalCycling, CosmicRaySoftError };
struct AgingMissionPoint { double duration_s = 0.0; double junction_temperature_k = 298.15; double voltage_v = 0.0; double current_density_a_per_m2 = 0.0; double temperature_swing_k = 0.0; };
struct AgingReport {
    std::map<AgingMechanism, double> accumulated_damage;
    double threshold_voltage_shift_v = 0.0;
    double resistance_growth_fraction = 0.0;
    double remaining_useful_life_h = 0.0;
    double failure_probability = 0.0;
    AgingMechanism dominant_mechanism = AgingMechanism::BiasTemperatureInstability;
};
class SemiconductorAgingLaboratory {
public: [[nodiscard]] AgingReport evaluate(const std::vector<AgingMissionPoint>& mission,
                                           double reference_life_h = 100000.0) const;
};

struct PcbaProcessConfig {
    double paste_volume_fraction = 1.0;
    double placement_error_mm = 0.0;
    double peak_reflow_temperature_k = 518.15;
    double time_above_liquidus_s = 60.0;
    double cooling_rate_k_per_s = 2.0;
    double moisture_exposure_h = 0.0;
    double cleanliness_ug_nacl_per_cm2 = 0.0;
    std::size_t solder_joints = 1000;
    std::size_t components = 100;
};
struct PcbaProductionReport {
    double first_pass_yield = 0.0;
    double expected_bridges = 0.0;
    double expected_opens = 0.0;
    double expected_voided_joints = 0.0;
    double expected_tombstones = 0.0;
    double ionic_contamination_risk = 0.0;
    double warpage_mm = 0.0;
    std::vector<std::string> process_recommendations;
};
class PcbaProductionDigitalTwin {
public: [[nodiscard]] PcbaProductionReport evaluate(const PcbaProcessConfig& config) const;
};

enum class InspectionMethod { Aoi, Axi, Ict, FlyingProbe, BoundaryScan, FunctionalTest };
enum class DefectType { MissingComponent, Polarity, Bridge, OpenJoint, Void, HeadInPillow, WrongValue, LatentIntermittent };
struct InspectionStage { InspectionMethod method = InspectionMethod::Aoi; double false_call_probability = 0.01; std::map<DefectType, double> detection_probability; double cycle_time_s = 1.0; };
struct InspectionReport {
    double escaped_defects_per_board = 0.0;
    double false_fail_probability = 0.0;
    double total_cycle_time_s = 0.0;
    double diagnostic_coverage = 0.0;
    std::map<DefectType, double> residual_defect_probability;
};
class ElectronicsInspectionLaboratory {
public: [[nodiscard]] InspectionReport evaluate(const std::map<DefectType, double>& incoming_defect_probability,
                                                const std::vector<InspectionStage>& stages) const;
};

enum class ProvisioningLifecycle { Blank, Manufacturing, Development, Field, Service, Return, Decommissioned };
struct ProvisionedIdentity {
    std::string device_id;
    std::string public_identity;
    std::string certificate_digest;
    std::uint64_t rollback_counter = 0;
    ProvisioningLifecycle lifecycle = ProvisioningLifecycle::Blank;
    bool debug_locked = false;
};
struct ProvisioningReport {
    bool accepted = false;
    ProvisionedIdentity identity;
    std::string audit_digest;
    std::string failure;
};
class SecureProvisioningLifecycle {
public:
    explicit SecureProvisioningLifecycle(std::string manufacturing_secret);
    [[nodiscard]] ProvisioningReport enroll(const std::string& device_id,
                                            const std::string& manufacturing_lot);
    [[nodiscard]] ProvisioningReport transition(const std::string& device_id,
                                                ProvisioningLifecycle target,
                                                const std::string& authorization_token);
    [[nodiscard]] std::string issue_authorization_token(const std::string& device_id,
                                                        ProvisioningLifecycle target) const;
    [[nodiscard]] std::optional<ProvisionedIdentity> identity(const std::string& device_id) const;
private:
    std::string secret_;
    std::map<std::string, ProvisionedIdentity> identities_;
};

enum class PhysicalAttackKind { SimplePowerAnalysis, DifferentialPowerAnalysis, ElectromagneticAnalysis, ClockGlitch, VoltageGlitch, ElectromagneticFaultInjection };
struct PhysicalAttackCampaign {
    PhysicalAttackKind kind = PhysicalAttackKind::DifferentialPowerAnalysis;
    std::size_t traces = 10000;
    double measurement_snr_db = 20.0;
    double glitch_width_s = 10e-9;
    double glitch_offset_s = 0.0;
    double fault_injection_amplitude = 1.0;
};
struct SecurityCountermeasures {
    bool masking = false;
    bool constant_time = false;
    bool random_delay = false;
    bool voltage_monitor = false;
    bool clock_monitor = false;
    bool redundant_computation = false;
    bool shielding = false;
};
struct PhysicalAttackReport {
    double key_recovery_probability = 0.0;
    double fault_success_probability = 0.0;
    double information_leakage_bits = 0.0;
    double detection_probability = 0.0;
    bool security_objective_met = false;
    std::vector<std::string> recommended_countermeasures;
};
class HardwarePhysicalSecurityLaboratory {
public: [[nodiscard]] PhysicalAttackReport evaluate(const PhysicalAttackCampaign& campaign,
                                                    const SecurityCountermeasures& countermeasures) const;
};

struct EmcInstrument {
    std::string id;
    double gain_db = 0.0;
    double loss_db = 0.0;
    double noise_floor_dbuv = -10.0;
    double linearity_limit_dbuv = 120.0;
    double uncertainty_db = 0.5;
};
struct EmcChamberConfig {
    double chamber_factor_db_per_m = 0.0;
    double field_uniformity_db = 3.0;
    double site_vswr = 1.5;
    double antenna_distance_m = 1.0;
    double amplifier_compression_db = 0.0;
};
struct EmcInstrumentationReport {
    double corrected_level_dbuv_per_m = 0.0;
    double expanded_uncertainty_db = 0.0;
    double dynamic_range_margin_db = 0.0;
    double field_uniformity_margin_db = 0.0;
    bool receiver_overload = false;
    bool noise_floor_limited = false;
    bool chamber_qualified = false;
};
class EmcChamberInstrumentationTwin {
public:
    void add_instrument(EmcInstrument instrument);
    void configure_chamber(EmcChamberConfig config);
    [[nodiscard]] EmcInstrumentationReport measure(double indicated_level_dbuv,
                                                   double antenna_factor_db_per_m,
                                                   double cable_loss_db,
                                                   double required_uniformity_db = 6.0) const;
private:
    std::vector<EmcInstrument> instruments_;
    EmcChamberConfig chamber_;
};

struct EmcMitigationCandidate {
    std::string id;
    double emission_reduction_db = 0.0;
    double immunity_improvement_db = 0.0;
    double efficiency_penalty_fraction = 0.0;
    double thermal_penalty_k = 0.0;
    double mass_kg = 0.0;
    double cost_score = 0.0;
    bool compatible = true;
};
struct EmcMitigationReport {
    std::vector<std::string> selected;
    double achieved_emission_margin_db = 0.0;
    double achieved_immunity_margin_db = 0.0;
    double efficiency_penalty_fraction = 0.0;
    double thermal_penalty_k = 0.0;
    double mass_kg = 0.0;
    double cost_score = 0.0;
    bool targets_met = false;
};
class AutomatedEmcMitigationOptimizer {
public: [[nodiscard]] EmcMitigationReport optimize(const std::vector<EmcMitigationCandidate>& candidates,
                                                   double initial_emission_margin_db,
                                                   double initial_immunity_margin_db,
                                                   double required_emission_margin_db,
                                                   double required_immunity_margin_db,
                                                   double maximum_efficiency_penalty_fraction,
                                                   double maximum_thermal_penalty_k,
                                                   double maximum_mass_kg) const;
};

}  // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

using ArchitectureVector = std::vector<double>;
using ArchitectureMatrix = std::vector<std::vector<double>>;
using OpticalComplex = std::array<double, 2>;

// Architecture-Level Multidisciplinary Design Optimization
struct ArchitectureComponentOption {
    std::string id;
    std::string category;
    double mass_kg = 0.0;
    double cost = 0.0;
    double embodied_co2_kg = 0.0;
    double efficiency = 1.0;
    double reliability = 1.0;
    double thermal_load_w = 0.0;
    double performance_contribution = 0.0;
    std::map<std::string, double> resource_demands;
    void validate() const;
};

struct ArchitectureContinuousVariable {
    std::string id;
    double lower_bound = 0.0;
    double upper_bound = 1.0;
    double initial_value = 0.5;
    void validate() const;
};

struct ArchitectureCoupling {
    std::string left_category;
    std::string right_category;
    double mass_multiplier = 0.0;
    double cost_multiplier = 0.0;
    double performance_multiplier = 0.0;
    double compatibility_limit = 1.0;
    void validate() const;
};

struct ArchitectureObjectiveWeights {
    double mass = 1.0;
    double cost = 1.0;
    double carbon = 0.25;
    double thermal = 0.1;
    double negative_performance = 1.0;
    double unreliability = 1.0;
    void validate() const;
};

struct ArchitectureMdoOptions {
    std::size_t maximum_architectures = 100000;
    std::size_t continuous_iterations = 80;
    double continuous_step = 0.08;
    double constraint_penalty = 1.0e6;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct ArchitectureCandidateResult {
    std::map<std::string, std::string> selected_component_by_category;
    std::map<std::string, double> continuous_variables;
    double total_mass_kg = 0.0;
    double total_cost = 0.0;
    double total_embodied_co2_kg = 0.0;
    double total_thermal_load_w = 0.0;
    double system_efficiency = 1.0;
    double system_reliability = 1.0;
    double performance = 0.0;
    double objective = 0.0;
    double constraint_violation = 0.0;
    bool feasible = false;
};

struct ArchitectureMdoResult {
    ArchitectureCandidateResult best;
    std::vector<ArchitectureCandidateResult> pareto_front;
    std::size_t architectures_evaluated = 0;
    std::size_t feasible_architectures = 0;
    bool globally_exhaustive = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_front = false) const;
};

class ArchitectureLevelMdoEngine {
public:
    [[nodiscard]] ArchitectureMdoResult optimize(
        const std::vector<ArchitectureComponentOption>& components,
        const std::vector<ArchitectureContinuousVariable>& variables,
        const std::vector<ArchitectureCoupling>& couplings,
        const std::map<std::string, double>& resource_limits,
        const ArchitectureObjectiveWeights& weights,
        const ArchitectureMdoOptions& options) const;
};

// Scientific Machine Learning and Physical-Law Discovery
struct ScientificLearningSample {
    ArchitectureVector state;
    ArchitectureVector derivative;
    ArchitectureVector inputs;
    void validate(std::size_t state_dimension) const;
};

struct ScientificLearningOptions {
    std::size_t polynomial_order = 3;
    double sparsity_threshold = 1.0e-4;
    double ridge_regularization = 1.0e-8;
    std::size_t threshold_iterations = 12;
    double validation_fraction = 0.2;
    bool enforce_energy_dissipation = false;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct DiscoveredLawTerm {
    std::string expression;
    double coefficient = 0.0;
    std::size_t output_index = 0;
};

struct ScientificLawDiscoveryResult {
    std::vector<DiscoveredLawTerm> active_terms;
    ArchitectureMatrix coefficient_matrix;
    std::vector<std::string> library_terms;
    double training_rmse = 0.0;
    double validation_rmse = 0.0;
    double conservation_residual = 0.0;
    double stability_margin = 0.0;
    bool dimensionally_consistent = false;
    bool stable_under_rollout = false;
    std::string symbolic_equations;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_coefficients = false) const;
};

class ScientificMachineLearningLaboratory {
public:
    [[nodiscard]] ScientificLawDiscoveryResult discover(
        const std::vector<ScientificLearningSample>& samples,
        const std::vector<std::string>& state_names,
        const std::vector<std::string>& input_names,
        const ScientificLearningOptions& options) const;

    [[nodiscard]] ArchitectureVector evaluate(
        const ScientificLawDiscoveryResult& model,
        const ArchitectureVector& state,
        const ArchitectureVector& inputs) const;
};

// PDE-Constrained Data Assimilation
struct PdeAssimilationGrid1D {
    std::size_t nodes = 51;
    double length_m = 1.0;
    double diffusion_m2_s = 0.01;
    double advection_m_s = 0.0;
    double time_step_s = 0.001;
    std::size_t steps = 100;
    void validate() const;
};

struct PdeObservation {
    std::size_t time_index = 0;
    std::size_t node_index = 0;
    double value = 0.0;
    double standard_deviation = 0.01;
    void validate(const PdeAssimilationGrid1D& grid) const;
};

struct PdeAssimilationOptions {
    std::size_t maximum_iterations = 80;
    double initial_step_size = 0.2;
    double background_weight = 1.0;
    double smoothness_weight = 1.0e-3;
    double convergence_tolerance = 1.0e-8;
    std::size_t ensemble_size = 32;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct PdeAssimilationResult {
    ArchitectureVector reconstructed_initial_field;
    ArchitectureMatrix reconstructed_trajectory;
    ArchitectureVector posterior_standard_deviation;
    ArchitectureVector observation_residuals;
    double initial_cost = 0.0;
    double final_cost = 0.0;
    double gradient_norm = 0.0;
    double innovation_rmse = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class PdeConstrainedDataAssimilationLaboratory {
public:
    [[nodiscard]] PdeAssimilationResult assimilate(
        const PdeAssimilationGrid1D& grid,
        const ArchitectureVector& background_initial_field,
        const ArchitectureVector& source_field,
        const std::vector<PdeObservation>& observations,
        const PdeAssimilationOptions& options) const;
};

// Electronics Packaging, PCB and Wiring-Harness Reliability
struct ElectronicsLayer {
    std::string id;
    double thickness_m = 1.0e-4;
    double area_m2 = 1.0e-4;
    double thermal_conductivity_w_m_k = 1.0;
    double elastic_modulus_pa = 1.0e9;
    double thermal_expansion_per_k = 1.0e-5;
    double yield_stress_pa = 1.0e8;
    double electrical_resistivity_ohm_m = 1.7e-8;
    void validate() const;
};

struct PcbInterconnect {
    std::string id;
    double length_m = 0.1;
    double cross_section_m2 = 1.0e-7;
    double contact_resistance_ohm = 0.001;
    double current_a = 1.0;
    double vibration_stress_pa = 1.0e6;
    double humidity_fraction = 0.5;
    void validate() const;
};

struct WiringHarnessSegment {
    std::string id;
    double length_m = 1.0;
    double conductor_area_m2 = 1.0e-6;
    double current_a = 1.0;
    double ambient_temperature_k = 300.0;
    double bundle_derating = 1.0;
    double bend_radius_m = 0.05;
    double minimum_bend_radius_m = 0.02;
    void validate() const;
};

struct ElectronicsReliabilityLoadCase {
    double duration_s = 3600.0;
    double ambient_temperature_k = 300.0;
    double dissipated_power_w = 1.0;
    double temperature_cycle_range_k = 40.0;
    double vibration_cycles = 1.0e5;
    double acceleration_rms_m_s2 = 10.0;
    void validate() const;
};

struct ElectronicsReliabilityResult {
    std::vector<double> layer_peak_temperature_k;
    std::vector<double> layer_thermal_stress_pa;
    std::vector<double> interconnect_resistance_ohm;
    std::vector<double> harness_temperature_k;
    std::vector<double> harness_voltage_drop_v;
    double solder_fatigue_damage = 0.0;
    double via_fatigue_damage = 0.0;
    double electromigration_damage = 0.0;
    double corrosion_damage = 0.0;
    double minimum_remaining_life_s = 0.0;
    bool electrical_limits_passed = false;
    bool thermal_limits_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_vectors = false) const;
};

class ElectronicsPackagingPcbHarnessReliabilityLaboratory {
public:
    [[nodiscard]] ElectronicsReliabilityResult analyze(
        const std::vector<ElectronicsLayer>& layers,
        const std::vector<PcbInterconnect>& interconnects,
        const std::vector<WiringHarnessSegment>& harness,
        const std::vector<ElectronicsReliabilityLoadCase>& load_cases) const;
};

// Photonics, Wave Optics and Metasurface Design
struct OpticalGrid2D {
    std::size_t width = 64;
    std::size_t height = 64;
    double spacing_m = 5.0e-6;
    double wavelength_m = 905.0e-9;
    void validate() const;
};

struct OpticalSurface {
    double focal_length_m = 0.05;
    double aperture_radius_m = 0.01;
    double transmission = 0.95;
    double spherical_aberration_m_inv3 = 0.0;
    double defocus_m_inv2 = 0.0;
    void validate() const;
};

struct MetasurfaceCell {
    std::size_t x = 0;
    std::size_t y = 0;
    double phase_delay_rad = 0.0;
    double amplitude_transmission = 1.0;
};

struct WaveOpticsOptions {
    double propagation_distance_m = 0.1;
    std::size_t optimization_iterations = 20;
    double optimization_step = 0.15;
    std::size_t target_x = 0;
    std::size_t target_y = 0;
    void validate(const OpticalGrid2D& grid) const;
};

struct WaveOpticsResult {
    std::vector<OpticalComplex> output_field;
    ArchitectureVector intensity;
    ArchitectureVector optimized_phase_rad;
    double transmitted_power_fraction = 0.0;
    double peak_intensity = 0.0;
    double encircled_energy_fraction = 0.0;
    double strehl_ratio = 0.0;
    double target_efficiency = 0.0;
    bool power_conservation_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_field = false) const;
};

class PhotonicsWaveOpticsDesignLaboratory {
public:
    [[nodiscard]] WaveOpticsResult propagate_and_optimize(
        const OpticalGrid2D& grid,
        const std::vector<OpticalComplex>& input_field,
        const std::vector<OpticalSurface>& surfaces,
        const std::vector<MetasurfaceCell>& cells,
        const WaveOpticsOptions& options) const;
};

// Cabin Microclimate, Air Quality and Human Thermoregulation
struct CabinZone {
    std::string id;
    double volume_m3 = 1.0;
    double initial_temperature_k = 295.0;
    double initial_relative_humidity = 0.5;
    double initial_co2_ppm = 420.0;
    double initial_pm25_ug_m3 = 5.0;
    double surface_area_m2 = 4.0;
    double thermal_mass_j_k = 5.0e4;
    void validate() const;
};

struct CabinFlowLink {
    std::size_t from_zone = 0;
    std::size_t to_zone = 0;
    double mass_flow_kg_s = 0.01;
    double filter_efficiency_pm25 = 0.0;
    void validate(std::size_t zones) const;
};

struct CabinOccupant {
    std::size_t zone = 0;
    double mass_kg = 75.0;
    double body_surface_area_m2 = 1.8;
    double metabolic_rate_w = 100.0;
    double clothing_insulation_clo = 0.7;
    double co2_generation_kg_s = 1.2e-5;
    double moisture_generation_kg_s = 2.0e-5;
    void validate(std::size_t zones) const;
};

struct CabinEnvironmentBoundary {
    double outdoor_temperature_k = 300.0;
    double outdoor_relative_humidity = 0.5;
    double outdoor_co2_ppm = 420.0;
    double outdoor_pm25_ug_m3 = 10.0;
    double solar_load_w = 0.0;
    double hvac_supply_temperature_k = 290.0;
    double hvac_mass_flow_kg_s = 0.1;
    double hvac_pm25_efficiency = 0.9;
    double duration_s = 1800.0;
    double time_step_s = 1.0;
    void validate() const;
};

struct CabinOccupantState {
    double core_temperature_k = 310.15;
    double skin_temperature_k = 306.15;
    double sweat_rate_kg_s = 0.0;
    double thermal_sensation = 0.0;
    double heat_strain_index = 0.0;
};

struct CabinMicroclimateResult {
    ArchitectureVector final_zone_temperature_k;
    ArchitectureVector final_zone_relative_humidity;
    ArchitectureVector final_zone_co2_ppm;
    ArchitectureVector final_zone_pm25_ug_m3;
    std::vector<CabinOccupantState> occupant_states;
    double hvac_energy_j = 0.0;
    double maximum_co2_ppm = 0.0;
    double maximum_pm25_ug_m3 = 0.0;
    double minimum_comfort_score = 0.0;
    bool air_quality_passed = false;
    bool thermal_comfort_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_zones = false) const;
};

class CabinMicroclimateThermoregulationLaboratory {
public:
    [[nodiscard]] CabinMicroclimateResult simulate(
        const std::vector<CabinZone>& zones,
        const std::vector<CabinFlowLink>& links,
        const std::vector<CabinOccupant>& occupants,
        const CabinEnvironmentBoundary& boundary) const;
};

// Fuel-Cell, Electrolyzer and Synthetic-Fuel Ecosystem
struct ElectrochemicalStackModel {
    std::size_t cells = 100;
    double active_area_m2 = 0.02;
    double exchange_current_density_a_m2 = 1.0;
    double membrane_resistance_ohm_m2 = 1.0e-4;
    double limiting_current_density_a_m2 = 2.0e4;
    double nominal_temperature_k = 353.15;
    double thermal_mass_j_k = 2.0e4;
    double degradation_rate_per_coulomb = 1.0e-12;
    void validate() const;
};

struct ElectrochemicalOperatingPoint {
    double current_a = 100.0;
    double inlet_hydrogen_kg_s = 0.002;
    double inlet_oxygen_kg_s = 0.02;
    double coolant_temperature_k = 333.15;
    double duration_s = 60.0;
    double renewable_power_w = 0.0;
    void validate() const;
};

struct SyntheticFuelProcess {
    double co2_feed_kg_s = 0.0;
    double hydrogen_feed_kg_s = 0.0;
    double conversion_fraction = 0.6;
    double selectivity = 0.8;
    double electricity_w = 0.0;
    double heat_w = 0.0;
    void validate() const;
};

struct EnergyConversionEcosystemResult {
    ArchitectureVector stack_voltage_v;
    ArchitectureVector stack_temperature_k;
    double fuel_cell_energy_j = 0.0;
    double electrolyzer_hydrogen_kg = 0.0;
    double electrolyzer_oxygen_kg = 0.0;
    double synthetic_fuel_kg = 0.0;
    double water_consumed_kg = 0.0;
    double co2_consumed_kg = 0.0;
    double electrical_efficiency = 0.0;
    double round_trip_efficiency = 0.0;
    double degradation_fraction = 0.0;
    double carbon_intensity_kg_co2_per_kg_fuel = 0.0;
    bool mass_balance_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class FuelCellElectrolyzerSyntheticFuelLaboratory {
public:
    [[nodiscard]] EnergyConversionEcosystemResult simulate(
        const ElectrochemicalStackModel& fuel_cell,
        const ElectrochemicalStackModel& electrolyzer,
        const std::vector<ElectrochemicalOperatingPoint>& operating_points,
        const SyntheticFuelProcess& synthetic_fuel) const;
};

// Smart Materials, Morphing Structures and Active Surfaces
struct SmartMaterialElement {
    std::string id;
    double length_m = 0.5;
    double area_m2 = 1.0e-4;
    double second_moment_m4 = 1.0e-8;
    double elastic_modulus_pa = 70.0e9;
    double density_kg_m3 = 2700.0;
    double piezoelectric_strain_per_v_m = 0.0;
    double sma_transformation_strain = 0.0;
    double sma_start_temperature_k = 320.0;
    double sma_finish_temperature_k = 350.0;
    double damping_ratio = 0.02;
    void validate() const;
};

struct SmartMaterialCommand {
    double time_s = 0.0;
    double voltage_v = 0.0;
    double magnetic_field_a_m = 0.0;
    double heater_power_w = 0.0;
    double external_force_n = 0.0;
};

struct MorphingSimulationOptions {
    double time_step_s = 0.001;
    double duration_s = 2.0;
    double ambient_temperature_k = 293.15;
    double convective_coefficient_w_k = 2.0;
    void validate() const;
};

struct MorphingStructureResult {
    ArchitectureVector time_s;
    ArchitectureVector tip_displacement_m;
    ArchitectureVector temperature_k;
    ArchitectureVector actuator_force_n;
    ArchitectureVector electrical_energy_j;
    double maximum_displacement_m = 0.0;
    double maximum_stress_pa = 0.0;
    double actuation_energy_j = 0.0;
    double recovered_energy_j = 0.0;
    double final_transformation_fraction = 0.0;
    bool structurally_safe = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class SmartMaterialsMorphingStructuresLaboratory {
public:
    [[nodiscard]] MorphingStructureResult simulate(
        const std::vector<SmartMaterialElement>& elements,
        const std::vector<SmartMaterialCommand>& commands,
        const MorphingSimulationOptions& options) const;
};

// Autonomous Maintenance, Repair and Remanufacturing
struct MaintenanceAsset {
    std::string id;
    double health_fraction = 1.0;
    double failure_probability = 0.0;
    double replacement_cost = 0.0;
    double replacement_carbon_kg = 0.0;
    double remanufactured_value = 0.0;
    std::vector<std::string> required_skills;
    void validate() const;
};

struct MaintenanceAction {
    std::string id;
    std::string asset_id;
    double duration_h = 1.0;
    double labor_cost = 0.0;
    double parts_cost = 0.0;
    double carbon_kg = 0.0;
    double health_restoration = 0.0;
    double failure_probability_reduction = 0.0;
    bool enables_remanufacturing = false;
    std::vector<std::string> required_skills;
    std::vector<std::string> predecessors;
    void validate() const;
};

struct MaintenanceResource {
    std::string id;
    std::vector<std::string> skills;
    double available_from_h = 0.0;
    double available_until_h = 24.0;
    double hourly_cost = 0.0;
    void validate() const;
};

struct MaintenancePlanningOptions {
    double downtime_cost_per_h = 100.0;
    double risk_cost = 10000.0;
    double carbon_cost_per_kg = 0.0;
    double planning_horizon_h = 168.0;
    void validate() const;
};

struct ScheduledMaintenanceAction {
    std::string action_id;
    std::string asset_id;
    std::string resource_id;
    double start_h = 0.0;
    double finish_h = 0.0;
    double total_cost = 0.0;
};

struct AutonomousMaintenanceResult {
    std::vector<ScheduledMaintenanceAction> schedule;
    std::map<std::string, double> final_asset_health;
    std::map<std::string, double> final_failure_probability;
    double total_cost = 0.0;
    double total_downtime_h = 0.0;
    double total_carbon_kg = 0.0;
    double remanufactured_value = 0.0;
    double avoided_risk_cost = 0.0;
    bool schedule_feasible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_schedule = false) const;
};

class AutonomousMaintenanceRemanufacturingLaboratory {
public:
    [[nodiscard]] AutonomousMaintenanceResult plan(
        const std::vector<MaintenanceAsset>& assets,
        const std::vector<MaintenanceAction>& actions,
        const std::vector<MaintenanceResource>& resources,
        const MaintenancePlanningOptions& options) const;
};

// Recycling-Process Physics and Closed-Loop Material Recovery
struct RecyclingMaterialStream {
    std::string id;
    std::map<std::string, double> component_mass_kg;
    double moisture_fraction = 0.0;
    double contamination_fraction = 0.0;
    double temperature_k = 298.15;
    void validate() const;
};

struct RecyclingUnitOperation {
    std::string id;
    std::string type;
    double throughput_kg_s = 1.0;
    double electricity_j_per_kg = 0.0;
    double heat_j_per_kg = 0.0;
    double direct_emissions_kg_co2_per_kg = 0.0;
    double water_kg_per_kg = 0.0;
    std::map<std::string, double> recovery_fraction_by_component;
    std::map<std::string, double> purity_factor_by_component;
    void validate() const;
};

struct RecyclingProcessOptions {
    double grid_carbon_kg_per_j = 1.0e-7;
    double heat_carbon_kg_per_j = 5.0e-8;
    double virgin_material_credit_kg_co2_per_kg = 2.0;
    double minimum_product_purity = 0.9;
    void validate() const;
};

struct RecyclingProcessResult {
    std::map<std::string, double> recovered_mass_kg;
    std::map<std::string, double> recovered_purity;
    std::map<std::string, double> residue_mass_kg;
    double electricity_j = 0.0;
    double heat_j = 0.0;
    double water_kg = 0.0;
    double gross_emissions_kg_co2 = 0.0;
    double avoided_virgin_emissions_kg_co2 = 0.0;
    double net_emissions_kg_co2 = 0.0;
    double overall_mass_recovery_fraction = 0.0;
    double closed_loop_eligible_fraction = 0.0;
    double mass_balance_error_kg = 0.0;
    bool mass_balance_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_streams = false) const;
};

class RecyclingProcessPhysicsLaboratory {
public:
    [[nodiscard]] RecyclingProcessResult simulate(
        const RecyclingMaterialStream& feed,
        const std::vector<RecyclingUnitOperation>& operations,
        const RecyclingProcessOptions& options) const;
};

} // namespace aesim::advanced

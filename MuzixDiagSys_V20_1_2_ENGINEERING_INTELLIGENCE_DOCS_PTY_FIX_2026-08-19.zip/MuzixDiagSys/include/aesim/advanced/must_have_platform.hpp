#pragma once

#include "aesim/advanced/integrated_frontier_platform.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Full-wave electromagnetic, antenna, and EMC laboratory.
// -----------------------------------------------------------------------------

enum class EmFieldComponent { Ex, Ey, Ez };

struct ElectromagneticMaterial {
    double relative_permittivity = 1.0;
    double relative_permeability = 1.0;
    double conductivity_s_m = 0.0;
};

struct FdtdVolume {
    std::size_t nx = 24;
    std::size_t ny = 24;
    std::size_t nz = 24;
    double cell_size_m = 0.01;
    double time_step_s = 0.0; // zero selects 0.95 of the Courant limit
    std::size_t steps = 300;
    std::size_t absorbing_cells = 4;
    double absorbing_conductivity_s_m = 2.0;
};

struct FdtdMaterialRegion {
    std::array<std::size_t, 3> minimum{};
    std::array<std::size_t, 3> maximum{}; // inclusive
    ElectromagneticMaterial material;
};

struct FdtdSource {
    std::array<std::size_t, 3> cell{};
    EmFieldComponent component = EmFieldComponent::Ez;
    double amplitude_v_m = 1.0;
    double frequency_hz = 1.0e9;
    double gaussian_delay_s = 1.0e-9;
    double gaussian_width_s = 0.35e-9;
    bool continuous_wave = false;
};

struct FdtdProbe {
    std::string id;
    std::array<std::size_t, 3> cell{};
    EmFieldComponent component = EmFieldComponent::Ez;
};

struct FdtdProbeTrace {
    std::string id;
    std::vector<double> time_s;
    std::vector<double> field_v_m;
    [[nodiscard]] std::complex<double> phasor(double frequency_hz) const;
    [[nodiscard]] doc::Value to_document(bool include_samples = false) const;
};

struct FullWaveResult {
    double time_step_s = 0.0;
    double simulated_time_s = 0.0;
    double peak_electric_field_v_m = 0.0;
    double peak_magnetic_field_a_m = 0.0;
    double final_stored_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
    std::vector<FdtdProbeTrace> probes;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_samples = false) const;
};

struct ThinWireDipoleConfiguration {
    double frequency_hz = 300.0e6;
    double length_m = 0.475;
    double radius_m = 0.001;
    std::size_t segments = 31;
    double feed_voltage_v = 1.0;
    double conductor_conductivity_s_m = 5.8e7;
    std::size_t pattern_samples = 181;
};

struct AntennaSolution {
    std::complex<double> input_impedance_ohm{};
    double accepted_power_w = 0.0;
    double radiation_resistance_ohm = 0.0;
    double efficiency = 0.0;
    double peak_directivity_linear = 0.0;
    std::vector<std::complex<double>> segment_current_a;
    std::vector<double> theta_rad;
    std::vector<double> normalized_power_pattern;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_currents = false) const;
};

struct EmcCouplingConfiguration {
    double frequency_hz = 100.0e6;
    double incident_field_v_m = 10.0;
    double exposed_length_m = 1.0;
    double orientation_cosine = 1.0;
    double shield_transfer_impedance_ohm_m = 0.01;
    double termination_ohm = 50.0;
};

struct EmcCouplingResult {
    double open_circuit_voltage_v = 0.0;
    double shield_current_a = 0.0;
    double load_voltage_v = 0.0;
    double coupled_power_w = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class FullWaveElectromagneticLaboratory {
public:
    void add_material_region(FdtdMaterialRegion region);
    void add_source(FdtdSource source);
    void add_probe(FdtdProbe probe);
    void clear();
    [[nodiscard]] FullWaveResult run(const FdtdVolume& volume) const;
    [[nodiscard]] AntennaSolution solve_thin_wire_dipole(
        const ThinWireDipoleConfiguration& configuration) const;
    [[nodiscard]] EmcCouplingResult evaluate_cable_coupling(
        const EmcCouplingConfiguration& configuration) const;
private:
    std::vector<FdtdMaterialRegion> regions_;
    std::vector<FdtdSource> sources_;
    std::vector<FdtdProbe> probes_;
};

// -----------------------------------------------------------------------------
// Native CPU/GPU/multi-GPU/HPC execution.
// -----------------------------------------------------------------------------

enum class HpcBackend { CpuThreads, CudaDriver };

struct HpcDeviceInfo {
    HpcBackend backend = HpcBackend::CpuThreads;
    int ordinal = 0;
    std::string name;
    std::uint64_t memory_bytes = 0;
    unsigned compute_major = 0;
    unsigned compute_minor = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct HpcExecutionOptions {
    HpcBackend preferred_backend = HpcBackend::CudaDriver;
    std::size_t cpu_threads = 0;
    bool permit_fallback = true;
    bool use_all_devices = true;
};

struct HpcExecutionReport {
    HpcBackend backend = HpcBackend::CpuThreads;
    std::vector<int> device_ordinals;
    std::size_t elements = 0;
    double elapsed_s = 0.0;
    double throughput_elements_s = 0.0;
    double checksum = 0.0;
    bool deterministic_match = true;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class NativeHpcExecutor {
public:
    NativeHpcExecutor();
    ~NativeHpcExecutor();
    NativeHpcExecutor(NativeHpcExecutor&&) noexcept;
    NativeHpcExecutor& operator=(NativeHpcExecutor&&) noexcept;
    NativeHpcExecutor(const NativeHpcExecutor&) = delete;
    NativeHpcExecutor& operator=(const NativeHpcExecutor&) = delete;
    [[nodiscard]] const std::vector<HpcDeviceInfo>& devices() const noexcept;
    [[nodiscard]] std::pair<std::vector<double>, HpcExecutionReport> axpy(
        double alpha, const std::vector<double>& x, const std::vector<double>& y,
        const HpcExecutionOptions& options = {}) const;
    [[nodiscard]] std::pair<double, HpcExecutionReport> deterministic_sum(
        const std::vector<double>& values, const HpcExecutionOptions& options = {}) const;
    [[nodiscard]] HpcExecutionReport parallel_for(
        std::size_t count, const std::function<void(std::size_t)>& task,
        const HpcExecutionOptions& options = {}) const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// -----------------------------------------------------------------------------
// Exact analytic CAD/CSG, volumetric meshing, and unstructured multiphysics.
// -----------------------------------------------------------------------------

enum class ExactPrimitiveKind { Box, Sphere, Cylinder };
enum class CsgOperation { Primitive, Union, Intersection, Difference };

struct ExactPrimitive {
    ExactPrimitiveKind kind = ExactPrimitiveKind::Box;
    Vector3 center_m{};
    Vector3 half_extents_m{0.5, 0.5, 0.5};
    double radius_m = 0.5;
    double half_height_m = 0.5;
};

struct ExactSolidBounds {
    Vector3 minimum_m{};
    Vector3 maximum_m{};
};

struct SurfaceTriangle3d {
    std::array<std::size_t, 3> nodes{};
};

struct Tetrahedron4 {
    std::array<std::size_t, 4> nodes{};
    std::string material_id;
};

struct UnstructuredVolumeMesh {
    std::vector<Vector3> nodes;
    std::vector<Tetrahedron4> tetrahedra;
    std::vector<SurfaceTriangle3d> boundary_triangles;
    double volume_m3 = 0.0;
    double minimum_quality = 0.0;
    [[nodiscard]] doc::Value to_document(bool include_mesh = false) const;
};

class ExactCadCsgModel {
public:
    using SolidId = std::size_t;
    SolidId add_primitive(ExactPrimitive primitive);
    SolidId combine(CsgOperation operation, SolidId left, SolidId right);
    [[nodiscard]] bool contains(SolidId solid, const Vector3& point_m) const;
    [[nodiscard]] double signed_distance(SolidId solid, const Vector3& point_m) const;
    [[nodiscard]] ExactSolidBounds bounds(SolidId solid) const;
    [[nodiscard]] UnstructuredVolumeMesh tetrahedralize(
        SolidId solid, double target_edge_m, std::string material_id = "default") const;
    [[nodiscard]] doc::Value to_document() const;
private:
    struct Node {
        CsgOperation operation = CsgOperation::Primitive;
        ExactPrimitive primitive;
        SolidId left = 0;
        SolidId right = 0;
    };
    std::vector<Node> nodes_;
};

struct TetraMaterial {
    double density_kg_m3 = 7800.0;
    double heat_capacity_j_kg_k = 500.0;
    double thermal_conductivity_w_m_k = 45.0;
    double youngs_modulus_pa = 210.0e9;
    double poisson_ratio = 0.3;
    double thermal_expansion_per_k = 12.0e-6;
    double yield_strength_pa = 250.0e6;
};

struct ThermalBoundaryCondition {
    std::map<std::size_t, double> fixed_temperature_k;
    std::map<std::size_t, double> nodal_heat_w;
    double uniform_volumetric_heat_w_m3 = 0.0;
};

struct ThermalFeaResult {
    std::vector<double> temperature_k;
    double minimum_temperature_k = 0.0;
    double maximum_temperature_k = 0.0;
    double residual_w = 0.0;
    [[nodiscard]] doc::Value to_document(bool include_field = false) const;
};

struct StructuralBoundaryCondition {
    std::map<std::size_t, std::array<bool, 3>> fixed_directions;
    std::map<std::size_t, Vector3> nodal_force_n;
    double reference_temperature_k = 293.15;
    std::vector<double> temperature_k;
};

struct StructuralFeaResult {
    std::vector<Vector3> displacement_m;
    std::vector<double> von_mises_stress_pa;
    double maximum_displacement_m = 0.0;
    double maximum_von_mises_pa = 0.0;
    double minimum_safety_factor = 0.0;
    double residual_n = 0.0;
    [[nodiscard]] doc::Value to_document(bool include_field = false) const;
};

class UnstructuredMultiphysicsSolver {
public:
    [[nodiscard]] ThermalFeaResult solve_steady_thermal(
        const UnstructuredVolumeMesh& mesh,
        const std::map<std::string, TetraMaterial>& materials,
        const ThermalBoundaryCondition& boundary) const;
    [[nodiscard]] StructuralFeaResult solve_linear_elasticity(
        const UnstructuredVolumeMesh& mesh,
        const std::map<std::string, TetraMaterial>& materials,
        const StructuralBoundaryCondition& boundary) const;
};

// -----------------------------------------------------------------------------
// Production-grade heterogeneous virtual ECU 2.0.
// -----------------------------------------------------------------------------

enum class MemoryPermission : std::uint8_t { Read = 1, Write = 2, Execute = 4 };

struct VirtualMemoryMapping {
    std::uint32_t virtual_base = 0;
    std::uint32_t physical_base = 0;
    std::uint32_t size_bytes = 4096;
    std::uint8_t permissions = 7;
};

struct ProductionCoreConfiguration {
    std::string id;
    double clock_hz = 400.0e6;
    std::size_t ram_bytes = 2 * 1024 * 1024;
    std::size_t l1_instruction_bytes = 32 * 1024;
    std::size_t l1_data_bytes = 32 * 1024;
    std::size_t cache_line_bytes = 64;
    std::string lockstep_peer;
};

struct CanFrame {
    std::uint32_t identifier = 0;
    bool extended = false;
    std::vector<std::uint8_t> payload;
    std::uint64_t timestamp_cycles = 0;
};

struct EthernetFrame {
    std::array<std::uint8_t, 6> destination{};
    std::array<std::uint8_t, 6> source{};
    std::uint16_t ether_type = 0x0800;
    std::vector<std::uint8_t> payload;
    std::uint64_t timestamp_cycles = 0;
};

struct VirtualEcuTelemetry {
    std::uint64_t reference_cycles = 0;
    std::map<std::string, std::uint64_t> instructions_by_core;
    std::map<std::string, std::uint64_t> cache_hits_by_core;
    std::map<std::string, std::uint64_t> cache_misses_by_core;
    std::uint64_t dma_bytes = 0;
    std::uint64_t can_frames = 0;
    std::uint64_t ethernet_frames = 0;
    std::uint64_t mmu_faults = 0;
    bool lockstep_mismatch = false;
    [[nodiscard]] doc::Value to_document() const;
};

class ProductionVirtualEcu2 {
public:
    explicit ProductionVirtualEcu2(std::size_t shared_memory_bytes = 1024 * 1024,
                                   std::uint32_t shared_base = 0x00100000U);
    ~ProductionVirtualEcu2();
    ProductionVirtualEcu2(ProductionVirtualEcu2&&) noexcept;
    ProductionVirtualEcu2& operator=(ProductionVirtualEcu2&&) noexcept;
    ProductionVirtualEcu2(const ProductionVirtualEcu2&) = delete;
    ProductionVirtualEcu2& operator=(const ProductionVirtualEcu2&) = delete;
    void add_core(ProductionCoreConfiguration configuration);
    void map_memory(const std::string& core_id, VirtualMemoryMapping mapping);
    void load_words(const std::string& core_id, std::uint32_t address,
                    const std::vector<std::uint32_t>& words);
    void load_elf32(const std::string& core_id, const std::vector<std::uint8_t>& elf_image);
    bool step_core(const std::string& core_id);
    void run_round_robin(std::size_t maximum_instructions_per_core);
    [[nodiscard]] std::uint32_t virtual_read32(const std::string& core_id,
                                               std::uint32_t virtual_address);
    void virtual_write32(const std::string& core_id, std::uint32_t virtual_address,
                         std::uint32_t value);
    void dma_copy(std::uint32_t source_physical, std::uint32_t destination_physical,
                  std::size_t bytes);
    void can_transmit(const std::string& controller_id, CanFrame frame);
    [[nodiscard]] std::optional<CanFrame> can_receive(const std::string& controller_id);
    void ethernet_transmit(const std::string& port_id, EthernetFrame frame);
    [[nodiscard]] std::optional<EthernetFrame> ethernet_receive(const std::string& port_id);
    [[nodiscard]] std::uint32_t register_value(const std::string& core_id, unsigned index) const;
    [[nodiscard]] VirtualEcuTelemetry telemetry() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// -----------------------------------------------------------------------------
// Advanced tire/road/terrain/adverse-weather physics.
// -----------------------------------------------------------------------------

enum class TerrainKind { Asphalt, Concrete, Gravel, Sand, Mud, Snow, Ice };

struct FlexibleTireConfiguration {
    double unloaded_radius_m = 0.335;
    double width_m = 0.245;
    double mass_kg = 12.0;
    double inflation_pressure_pa = 245000.0;
    double radial_stiffness_n_m = 280000.0;
    double belt_bending_stiffness_nm2 = 120.0;
    double radial_damping_n_s_m = 1800.0;
    double longitudinal_relaxation_m = 0.35;
    double lateral_relaxation_m = 0.45;
    double tread_depth_m = 0.008;
    double rubber_heat_capacity_j_k = 18000.0;
    double wear_coefficient_m_j = 2.0e-13;
    std::size_t ring_nodes = 48;
};

struct TerrainWeatherState {
    TerrainKind terrain = TerrainKind::Asphalt;
    double dry_friction = 1.05;
    double road_temperature_k = 293.15;
    double air_temperature_k = 293.15;
    double water_film_m = 0.0;
    double snow_depth_m = 0.0;
    double ice_fraction = 0.0;
    double loose_depth_m = 0.0;
    double bekker_kc = 20000.0;
    double bekker_kphi = 1200000.0;
    double bekker_exponent = 1.1;
    double janosi_shear_m = 0.02;
    double cohesion_pa = 1000.0;
    double internal_friction_rad = 0.5;
    std::vector<std::pair<double, double>> longitudinal_profile_m; // x, elevation
};

struct TireTerrainOperatingPoint {
    double time_step_s = 0.001;
    double longitudinal_position_m = 0.0;
    double normal_load_n = 4000.0;
    double hub_speed_m_s = 0.0;
    double lateral_speed_m_s = 0.0;
    double wheel_angular_speed_rad_s = 0.0;
    double camber_rad = 0.0;
    double steering_rate_rad_s = 0.0;
};

struct FlexibleTireState {
    std::vector<double> radial_deflection_m;
    std::vector<double> radial_velocity_m_s;
    double effective_slip_ratio = 0.0;
    double effective_slip_angle_rad = 0.0;
    double tread_temperature_k = 293.15;
    double tread_depth_m = 0.008;
    double sinkage_m = 0.0;
    double inflation_pressure_pa = 245000.0;
    bool punctured = false;
};

struct TireTerrainResult {
    FlexibleTireState state;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double vertical_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double rolling_resistance_n = 0.0;
    double friction_coefficient = 0.0;
    double hydroplaning_fraction = 0.0;
    double contact_length_m = 0.0;
    double contact_area_m2 = 0.0;
    double terrain_compaction_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
    [[nodiscard]] doc::Value to_document(bool include_ring = false) const;
};

class AdvancedTireTerrainLaboratory {
public:
    [[nodiscard]] FlexibleTireState initial_state(const FlexibleTireConfiguration& tire) const;
    [[nodiscard]] TireTerrainResult step(const FlexibleTireConfiguration& tire,
                                         const TerrainWeatherState& environment,
                                         const TireTerrainOperatingPoint& operating,
                                         const FlexibleTireState& previous) const;
};

// -----------------------------------------------------------------------------
// Learned-component robustness and neural safety verification.
// -----------------------------------------------------------------------------

enum class NeuralActivation { Linear, Relu, Tanh };

struct DenseNeuralLayer {
    std::size_t input_size = 0;
    std::size_t output_size = 0;
    std::vector<double> weights; // row-major output x input
    std::vector<double> bias;
    NeuralActivation activation = NeuralActivation::Linear;
};

struct NeuralNetworkModel {
    std::vector<DenseNeuralLayer> layers;
    [[nodiscard]] std::vector<double> evaluate(const std::vector<double>& input) const;
    [[nodiscard]] std::vector<double> input_gradient(const std::vector<double>& input,
                                                     std::size_t output_index) const;
    void validate() const;
};

struct IntervalVector {
    std::vector<double> lower;
    std::vector<double> upper;
};

struct NeuralIntervalResult {
    std::vector<IntervalVector> layer_bounds;
    IntervalVector output;
    [[nodiscard]] doc::Value to_document() const;
};

struct RobustnessVerificationResult {
    bool proved = false;
    bool counterexample_found = false;
    double certified_margin = 0.0;
    std::vector<double> counterexample;
    std::size_t explored_boxes = 0;
    std::size_t remaining_boxes = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct AdversarialAttackResult {
    std::vector<double> adversarial_input;
    std::vector<double> output;
    double perturbation_linf = 0.0;
    bool changed_classification = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct ConformalCalibrationResult {
    double quantile = 0.0;
    double requested_coverage = 0.0;
    double empirical_coverage = 0.0;
    std::vector<std::pair<double, double>> intervals;
    [[nodiscard]] doc::Value to_document() const;
};

struct LinearClosedLoopSystem {
    std::size_t state_size = 0;
    std::size_t control_size = 0;
    std::vector<double> state_matrix;
    std::vector<double> control_matrix;
    std::vector<double> process_uncertainty;
};

struct ClosedLoopReachabilityResult {
    std::vector<IntervalVector> reachable_states;
    bool safe = true;
    std::size_t first_unsafe_step = 0;
    [[nodiscard]] doc::Value to_document() const;
};

class NeuralSafetyVerifier {
public:
    [[nodiscard]] NeuralIntervalResult interval_propagate(
        const NeuralNetworkModel& network, const IntervalVector& input) const;
    [[nodiscard]] RobustnessVerificationResult verify_classification(
        const NeuralNetworkModel& network, const IntervalVector& input,
        std::size_t target_class, double required_margin = 0.0,
        std::size_t maximum_boxes = 10000) const;
    [[nodiscard]] AdversarialAttackResult projected_gradient_attack(
        const NeuralNetworkModel& network, const std::vector<double>& input,
        std::size_t target_class, double epsilon, double step_size,
        std::size_t iterations) const;
    [[nodiscard]] ConformalCalibrationResult calibrate_regression(
        const std::vector<double>& predictions, const std::vector<double>& targets,
        const std::vector<double>& future_predictions, double coverage) const;
    [[nodiscard]] ClosedLoopReachabilityResult verify_closed_loop(
        const NeuralNetworkModel& controller, const LinearClosedLoopSystem& plant,
        const IntervalVector& initial_state, const IntervalVector& safe_state,
        std::size_t steps) const;
};

} // namespace aesim::advanced

#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MUZIX_HW_PLUGIN_ABI_VERSION 1u
#define MUZIX_HW_FLAG_EXTENDED 0x0001u
#define MUZIX_HW_FLAG_FD       0x0002u
#define MUZIX_HW_FLAG_BRS      0x0004u
#define MUZIX_HW_FLAG_ERROR    0x0008u

typedef struct muzix_hw_channel_config_v1 {
    const char* channel;
    uint32_t bitrate;
    uint32_t data_bitrate;
    uint32_t flags;
} muzix_hw_channel_config_v1;

typedef struct muzix_hw_can_frame_v1 {
    uint32_t identifier;
    uint32_t flags;
    uint64_t timestamp_ns;
    uint8_t data[64];
    uint8_t size;
} muzix_hw_can_frame_v1;

uint32_t muzix_hw_plugin_abi_version(void);
void* muzix_hw_open_v1(const muzix_hw_channel_config_v1* config, char* error, size_t error_capacity);
int muzix_hw_send_v1(void* handle, const muzix_hw_can_frame_v1* frame, char* error, size_t error_capacity);
/* return 1 when a frame is received, 0 on timeout, -1 on error */
int muzix_hw_receive_v1(void* handle, muzix_hw_can_frame_v1* frame, uint32_t timeout_ms,
                        char* error, size_t error_capacity);
void muzix_hw_close_v1(void* handle);
const char* muzix_hw_status_v1(void* handle);

#ifdef __cplusplus
}
#endif

#pragma once

#include "aesim/advanced/scientific_fidelity_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

using ContinuumVector = std::vector<double>;
using ContinuumMatrix = std::vector<ContinuumVector>;

// -----------------------------------------------------------------------------
// Moving-boundary, free-surface, and multiphase CFD.
// -----------------------------------------------------------------------------

struct ImmersedCircularBody2D {
    std::string id;
    double center_x_m = 0.0;
    double center_y_m = 0.0;
    double radius_m = 0.1;
    double velocity_x_mps = 0.0;
    double velocity_y_mps = 0.0;
};

struct MultiphaseCfdConfiguration {
    std::size_t cells_x = 32;
    std::size_t cells_y = 16;
    double width_m = 2.0;
    double height_m = 1.0;
    double liquid_density_kg_m3 = 1000.0;
    double gas_density_kg_m3 = 1.2;
    double liquid_dynamic_viscosity_pa_s = 1.0e-3;
    double gas_dynamic_viscosity_pa_s = 1.8e-5;
    double liquid_heat_capacity_j_kg_k = 4180.0;
    double gas_heat_capacity_j_kg_k = 1005.0;
    double thermal_conductivity_w_m_k = 0.1;
    double surface_tension_n_m = 0.072;
    double gravity_x_mps2 = 0.0;
    double gravity_y_mps2 = -9.80665;
    double cfl = 0.25;
    double interface_compression = 0.5;
    double immersed_penalty = 2000.0;
    std::size_t pressure_iterations = 120;
    bool periodic_x = false;
};

struct MultiphaseCfdCell {
    double liquid_volume_fraction = 0.0;
    double pressure_pa = 0.0;
    double velocity_x_mps = 0.0;
    double velocity_y_mps = 0.0;
    double temperature_k = 293.15;
    double mixture_density_kg_m3 = 1.2;
    double mixture_viscosity_pa_s = 1.8e-5;
    double immersed_solid_fraction = 0.0;
};

struct MultiphaseCfdStepReport {
    double time_s = 0.0;
    double time_step_s = 0.0;
    double liquid_volume_m3 = 0.0;
    double liquid_volume_residual_m3 = 0.0;
    double maximum_divergence_per_s = 0.0;
    double kinetic_energy_j_per_m = 0.0;
    std::size_t interface_cells = 0;
    std::size_t pressure_iterations = 0;
};

class MovingBoundaryMultiphaseCfdSolver {
public:
    using InitialField = std::function<MultiphaseCfdCell(double, double)>;

    void configure(MultiphaseCfdConfiguration configuration,
                   InitialField initial_field);
    void set_immersed_bodies(std::vector<ImmersedCircularBody2D> bodies);
    [[nodiscard]] MultiphaseCfdStepReport advance(double final_time_s);
    [[nodiscard]] const std::vector<MultiphaseCfdCell>& cells() const noexcept;
    [[nodiscard]] const std::vector<ImmersedCircularBody2D>& bodies() const noexcept;
    [[nodiscard]] MultiphaseCfdCell sample(double x_m, double y_m) const;

private:
    MultiphaseCfdConfiguration configuration_;
    std::vector<MultiphaseCfdCell> cells_;
    std::vector<ImmersedCircularBody2D> bodies_;
    double time_s_ = 0.0;
    double initial_liquid_volume_m3_ = 0.0;

    [[nodiscard]] std::size_t index(std::size_t x, std::size_t y) const noexcept;
    void update_immersed_geometry(double dt_s);
    [[nodiscard]] MultiphaseCfdStepReport step(double dt_s);
};

// -----------------------------------------------------------------------------
// RANS-transition-LES-DES turbulence hierarchy.
// -----------------------------------------------------------------------------

enum class TurbulenceClosureModel {
    Laminar,
    SpalartAllmaras,
    KomegaSst,
    TransitionSst,
    SmagorinskyLes,
    WaleLes,
    DelayedDes
};

struct TurbulenceHierarchyConfiguration {
    std::size_t cells_x = 1;
    std::size_t cells_y = 1;
    double spacing_x_m = 1.0;
    double spacing_y_m = 1.0;
    double density_kg_m3 = 1.225;
    double molecular_viscosity_pa_s = 1.8e-5;
    double smagorinsky_constant = 0.17;
    double wale_constant = 0.325;
    double des_constant = 0.65;
    double transition_reynolds_number = 400.0;
    TurbulenceClosureModel model = TurbulenceClosureModel::KomegaSst;
};

struct TurbulenceCellState {
    double turbulent_kinetic_energy_m2_s2 = 1.0e-6;
    double specific_dissipation_per_s = 1.0;
    double modified_viscosity_m2_s = 1.0e-6;
    double intermittency = 1.0;
    double eddy_viscosity_pa_s = 0.0;
    double wall_distance_m = 1.0;
    double strain_rate_per_s = 0.0;
    double des_length_m = 0.0;
};

struct TurbulenceHierarchyReport {
    double maximum_eddy_viscosity_pa_s = 0.0;
    double mean_eddy_viscosity_pa_s = 0.0;
    double minimum_intermittency = 1.0;
    double maximum_turbulent_reynolds_number = 0.0;
    std::size_t limited_cells = 0;
};

class TurbulenceHierarchySolver {
public:
    void configure(TurbulenceHierarchyConfiguration configuration,
                   std::vector<double> wall_distance_m = {});
    [[nodiscard]] TurbulenceHierarchyReport advance(
        const std::vector<double>& velocity_x_mps,
        const std::vector<double>& velocity_y_mps,
        double time_step_s);
    [[nodiscard]] const std::vector<TurbulenceCellState>& cells() const noexcept;

private:
    TurbulenceHierarchyConfiguration configuration_;
    std::vector<TurbulenceCellState> cells_;
    [[nodiscard]] std::size_t index(std::size_t x, std::size_t y) const noexcept;
};

// -----------------------------------------------------------------------------
// Generalized electrochemical porous-electrode physics.
// -----------------------------------------------------------------------------

struct PorousElectrodeRegion {
    std::string id;
    std::size_t begin_cell = 0;
    std::size_t end_cell = 0;
    bool electronically_conductive = true;
    double porosity = 0.35;
    double specific_surface_area_m2_m3 = 2.0e5;
    double maximum_solid_concentration_mol_m3 = 30000.0;
    double solid_diffusivity_m2_s = 1.0e-14;
    double electrolyte_diffusivity_m2_s = 2.0e-10;
    double solid_conductivity_s_m = 100.0;
    double electrolyte_conductivity_s_m = 1.0;
    double exchange_current_density_a_m2 = 2.0;
    double open_circuit_reference_v = 3.7;
};

struct PorousElectrodeConfiguration {
    std::size_t cells = 30;
    double length_m = 150.0e-6;
    double area_m2 = 0.01;
    double initial_temperature_k = 298.15;
    double initial_electrolyte_concentration_mol_m3 = 1000.0;
    double thermal_mass_j_k = 500.0;
    double thermal_conductance_w_k = 2.0;
    double ambient_temperature_k = 298.15;
    double transference_number = 0.4;
    double double_layer_capacitance_f_m2 = 0.2;
};

struct ContinuumPorousElectrodeCellState {
    double solid_concentration_average_mol_m3 = 15000.0;
    double solid_concentration_surface_mol_m3 = 15000.0;
    double electrolyte_concentration_mol_m3 = 1000.0;
    double solid_potential_v = 0.0;
    double electrolyte_potential_v = 0.0;
    double reaction_current_density_a_m2 = 0.0;
    double overpotential_v = 0.0;
    double temperature_k = 298.15;
};

struct PorousElectrodeReport {
    double time_s = 0.0;
    double terminal_voltage_v = 0.0;
    double state_of_charge = 0.0;
    double average_temperature_k = 0.0;
    double heat_generation_w = 0.0;
    double lithium_inventory_mol = 0.0;
    double lithium_inventory_residual_mol = 0.0;
    double maximum_overpotential_v = 0.0;
};

class GeneralizedPorousElectrodeSolver {
public:
    void configure(PorousElectrodeConfiguration configuration,
                   std::vector<PorousElectrodeRegion> regions);
    [[nodiscard]] PorousElectrodeReport advance(double applied_current_a,
                                                double final_time_s);
    [[nodiscard]] const std::vector<ContinuumPorousElectrodeCellState>& cells() const noexcept;
    [[nodiscard]] const std::vector<PorousElectrodeRegion>& regions() const noexcept;

private:
    PorousElectrodeConfiguration configuration_;
    std::vector<PorousElectrodeRegion> regions_;
    std::vector<ContinuumPorousElectrodeCellState> cells_;
    double time_s_ = 0.0;
    double initial_lithium_inventory_mol_ = 0.0;
    [[nodiscard]] PorousElectrodeReport step(double applied_current_a, double dt_s);
};

// -----------------------------------------------------------------------------
// Boiling, condensation, cavitation, and two-fluid flow.
// -----------------------------------------------------------------------------

struct TwoFluidConfiguration {
    std::size_t cells = 20;
    double length_m = 1.0;
    double flow_area_m2 = 1.0e-3;
    double hydraulic_diameter_m = 0.02;
    double liquid_density_kg_m3 = 950.0;
    double vapor_density_kg_m3 = 5.0;
    double liquid_heat_capacity_j_kg_k = 4200.0;
    double vapor_heat_capacity_j_kg_k = 2100.0;
    double latent_heat_j_kg = 2.0e6;
    double liquid_viscosity_pa_s = 3.0e-4;
    double vapor_viscosity_pa_s = 1.5e-5;
    double reference_saturation_temperature_k = 373.15;
    double reference_saturation_pressure_pa = 101325.0;
    double cavitation_pressure_pa = 2500.0;
    double interphase_drag_coefficient = 0.5;
    double boiling_coefficient_kg_m2_s_k = 0.02;
    double condensation_coefficient_kg_m2_s_k = 0.03;
};

struct TwoFluidCellState {
    double pressure_pa = 101325.0;
    double liquid_temperature_k = 300.0;
    double vapor_temperature_k = 373.15;
    double vapor_volume_fraction = 0.0;
    double liquid_velocity_mps = 0.0;
    double vapor_velocity_mps = 0.0;
    double phase_change_rate_kg_m3_s = 0.0;
    double wall_heat_flux_w_m2 = 0.0;
};

struct TwoFluidReport {
    double time_s = 0.0;
    double vapor_mass_kg = 0.0;
    double liquid_mass_kg = 0.0;
    double maximum_vapor_fraction = 0.0;
    double maximum_phase_change_rate_kg_m3_s = 0.0;
    double pressure_drop_pa = 0.0;
    double mass_residual_kg = 0.0;
    double energy_residual_j = 0.0;
    bool cavitation_detected = false;
    bool critical_heat_flux_exceeded = false;
};

class TwoFluidPhaseChangeSolver {
public:
    using HeatFluxProfile = std::function<double(double, double)>;

    void configure(TwoFluidConfiguration configuration,
                   HeatFluxProfile heat_flux = {});
    [[nodiscard]] TwoFluidReport advance(double inlet_mass_flow_kg_s,
                                         double inlet_temperature_k,
                                         double outlet_pressure_pa,
                                         double final_time_s);
    [[nodiscard]] const std::vector<TwoFluidCellState>& cells() const noexcept;

private:
    TwoFluidConfiguration configuration_;
    HeatFluxProfile heat_flux_;
    std::vector<TwoFluidCellState> cells_;
    double time_s_ = 0.0;
    double initial_mass_kg_ = 0.0;
    double cumulative_inlet_mass_kg_ = 0.0;
    double cumulative_outlet_mass_kg_ = 0.0;
    double cumulative_heat_j_ = 0.0;
    [[nodiscard]] double saturation_temperature(double pressure_pa) const;
};

// -----------------------------------------------------------------------------
// Participating-media radiative transfer.
// -----------------------------------------------------------------------------

struct RadiationMediumCell {
    double temperature_k = 1000.0;
    double absorption_coefficient_per_m = 1.0;
    double scattering_coefficient_per_m = 0.0;
    double anisotropy_factor = 0.0;
};

struct RadiationBoundary {
    double temperature_k = 300.0;
    double emissivity = 1.0;
    double reflectivity = 0.0;
};

struct RadiationConfiguration {
    double length_m = 1.0;
    std::size_t ordinates = 8;
    std::size_t maximum_source_iterations = 500;
    double convergence_tolerance = 1.0e-9;
    double stefan_boltzmann_w_m2_k4 = 5.670374419e-8;
};

struct RadiationReport {
    bool converged = false;
    std::size_t iterations = 0;
    double left_heat_flux_w_m2 = 0.0;
    double right_heat_flux_w_m2 = 0.0;
    double emitted_power_w_m2 = 0.0;
    double absorbed_power_w_m2 = 0.0;
    double energy_residual_w_m2 = 0.0;
    std::vector<double> volumetric_source_w_m3;
    std::vector<double> scalar_intensity_w_m2;
};

class ParticipatingMediaRadiationSolver {
public:
    void configure(RadiationConfiguration configuration,
                   std::vector<RadiationMediumCell> medium,
                   RadiationBoundary left,
                   RadiationBoundary right);
    [[nodiscard]] RadiationReport solve();

private:
    RadiationConfiguration configuration_;
    std::vector<RadiationMediumCell> medium_;
    RadiationBoundary left_;
    RadiationBoundary right_;
};

// -----------------------------------------------------------------------------
// Three-dimensional field assimilation and inversion.
// -----------------------------------------------------------------------------

struct FieldGrid3D {
    std::size_t cells_x = 1;
    std::size_t cells_y = 1;
    std::size_t cells_z = 1;
    double spacing_x_m = 1.0;
    double spacing_y_m = 1.0;
    double spacing_z_m = 1.0;
};

struct FieldObservation3D {
    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
    double value = 0.0;
    double standard_deviation = 1.0;
    double localization_radius_m = 1.0e9;
};

struct FieldAssimilation3DReport {
    double prior_rmse = 0.0;
    double posterior_rmse = 0.0;
    double ensemble_spread_before = 0.0;
    double ensemble_spread_after = 0.0;
    std::size_t assimilated_observations = 0;
    std::vector<double> posterior_mean;
    std::vector<double> posterior_variance;
};

struct FieldInversion3DOptions {
    std::size_t maximum_iterations = 30;
    double finite_difference_step = 1.0e-5;
    double regularization = 1.0e-3;
    double tolerance = 1.0e-7;
    double minimum_line_search = 1.0e-5;
};

struct FieldInversion3DReport {
    bool converged = false;
    std::size_t iterations = 0;
    double initial_objective = 0.0;
    double final_objective = 0.0;
    std::vector<double> parameters;
    ContinuumMatrix parameter_covariance;
    std::vector<double> predicted_observations;
    std::string termination_reason;
};

class ThreeDimensionalFieldAssimilationAndInversion {
public:
    using ForwardOperator = std::function<std::vector<double>(const std::vector<double>&)>;

    void configure(FieldGrid3D grid, std::size_t ensemble_members,
                   std::uint64_t seed = 1);
    void set_ensemble(std::vector<std::vector<double>> ensemble);
    [[nodiscard]] FieldAssimilation3DReport assimilate(
        const std::vector<FieldObservation3D>& observations,
        double covariance_inflation = 1.0);
    [[nodiscard]] FieldInversion3DReport invert(
        const std::vector<double>& initial_parameters,
        const std::vector<double>& measurements,
        const std::vector<double>& measurement_standard_deviations,
        ForwardOperator forward,
        const FieldInversion3DOptions& options = {}) const;
    [[nodiscard]] const std::vector<std::vector<double>>& ensemble() const noexcept;

private:
    FieldGrid3D grid_;
    std::vector<std::vector<double>> ensemble_;
    std::mt19937_64 generator_{1};
    [[nodiscard]] std::size_t nearest_index(double x_m, double y_m, double z_m) const;
};

// -----------------------------------------------------------------------------
// Poromechanics and terrain interaction.
// -----------------------------------------------------------------------------

struct PoromechanicsConfiguration {
    std::size_t cells_x = 20;
    std::size_t cells_z = 10;
    double width_m = 10.0;
    double depth_m = 5.0;
    double permeability_m2 = 1.0e-12;
    double fluid_viscosity_pa_s = 1.0e-3;
    double fluid_compressibility_pa_inverse = 4.5e-10;
    double porosity = 0.35;
    double biot_coefficient = 0.9;
    double youngs_modulus_pa = 2.0e7;
    double poisson_ratio = 0.3;
    double soil_density_kg_m3 = 1800.0;
    double cohesion_pa = 5000.0;
    double friction_angle_rad = 0.55;
    double bekker_kc_n_m_nplus1 = 10000.0;
    double bekker_kphi_n_m_nplus2 = 1.0e6;
    double bekker_exponent = 1.0;
    double janosi_shear_deformation_m = 0.02;
};

struct PoromechanicsCellState {
    double pore_pressure_pa = 0.0;
    double vertical_displacement_m = 0.0;
    double effective_vertical_stress_pa = 0.0;
    double saturation = 1.0;
};

struct TerrainContactInput {
    double normal_load_n = 1000.0;
    double contact_width_m = 0.2;
    double contact_length_m = 0.3;
    double slip_ratio = 0.1;
    double travel_speed_mps = 1.0;
};

struct TerrainContactResult {
    double sinkage_m = 0.0;
    double mean_contact_pressure_pa = 0.0;
    double gross_traction_n = 0.0;
    double compaction_resistance_n = 0.0;
    double net_drawbar_pull_n = 0.0;
    double traction_efficiency = 0.0;
};

struct PoromechanicsReport {
    double time_s = 0.0;
    double maximum_pore_pressure_pa = 0.0;
    double maximum_settlement_m = 0.0;
    double fluid_mass_residual_kg_per_m = 0.0;
    double strain_energy_j_per_m = 0.0;
    bool bearing_capacity_exceeded = false;
};

class PoromechanicsTerrainSolver {
public:
    using SurfaceLoad = std::function<double(double, double)>;
    using Infiltration = std::function<double(double, double)>;

    void configure(PoromechanicsConfiguration configuration);
    [[nodiscard]] PoromechanicsReport advance(double final_time_s,
                                               SurfaceLoad surface_load,
                                               Infiltration infiltration = {});
    [[nodiscard]] TerrainContactResult evaluate_terrain_contact(
        const TerrainContactInput& input) const;
    [[nodiscard]] const std::vector<PoromechanicsCellState>& cells() const noexcept;

private:
    PoromechanicsConfiguration configuration_;
    std::vector<PoromechanicsCellState> cells_;
    double time_s_ = 0.0;
    double cumulative_infiltration_kg_per_m_ = 0.0;
    [[nodiscard]] std::size_t index(std::size_t x, std::size_t z) const noexcept;
};

// -----------------------------------------------------------------------------
// Aerosol and particulate population balances.
// -----------------------------------------------------------------------------

struct AerosolSection {
    double lower_diameter_m = 1.0e-9;
    double upper_diameter_m = 2.0e-9;
    double number_concentration_per_m3 = 0.0;
    double particle_density_kg_m3 = 1000.0;
    double deposited_number_per_m2 = 0.0;
};

struct AerosolPopulationConfiguration {
    double nucleation_rate_per_m3_s = 0.0;
    double nucleated_diameter_m = 1.0e-9;
    double condensation_growth_rate_m_s = 0.0;
    double coagulation_kernel_m3_s = 0.0;
    double fragmentation_rate_per_s = 0.0;
    double deposition_velocity_m_s = 0.0;
    double control_volume_height_m = 1.0;
};

struct AerosolPopulationReport {
    double time_s = 0.0;
    double total_number_concentration_per_m3 = 0.0;
    double total_suspended_mass_kg_m3 = 0.0;
    double total_deposited_mass_kg_m2 = 0.0;
    double number_mean_diameter_m = 0.0;
    double mass_mean_diameter_m = 0.0;
    double mass_residual_kg_m3 = 0.0;
};

class AerosolPopulationBalanceSolver {
public:
    void configure(AerosolPopulationConfiguration configuration,
                   std::vector<AerosolSection> sections);
    [[nodiscard]] AerosolPopulationReport advance(double final_time_s);
    [[nodiscard]] const std::vector<AerosolSection>& sections() const noexcept;

private:
    AerosolPopulationConfiguration configuration_;
    std::vector<AerosolSection> sections_;
    double time_s_ = 0.0;
    double initial_total_mass_kg_m3_ = 0.0;
    double cumulative_nucleated_mass_kg_m3_ = 0.0;
    [[nodiscard]] double section_particle_mass(const AerosolSection& section) const;
};

// -----------------------------------------------------------------------------
// Automatic manufactured-solution verification.
// -----------------------------------------------------------------------------

struct ManufacturedPdeConfiguration {
    double diffusion_x = 1.0;
    double diffusion_y = 1.0;
    double advection_x = 0.0;
    double advection_y = 0.0;
    double reaction = 0.0;
    double domain_width = 1.0;
    double domain_height = 1.0;
    std::size_t solver_iterations = 20000;
    double solver_tolerance = 1.0e-11;
    std::size_t formal_spatial_order = 2;
};

struct ManufacturedResolutionResult {
    std::size_t cells_x = 0;
    std::size_t cells_y = 0;
    double l1_error = 0.0;
    double l2_error = 0.0;
    double linfinity_error = 0.0;
    double residual_norm = 0.0;
    std::size_t iterations = 0;
};

struct ManufacturedVerificationReport {
    bool passed = false;
    double observed_l1_order = 0.0;
    double observed_l2_order = 0.0;
    double observed_linfinity_order = 0.0;
    std::vector<ManufacturedResolutionResult> resolutions;
    std::string conclusion;
};

class AutomaticManufacturedSolutionVerifier {
public:
    using ExactSolution = std::function<double(double, double)>;

    void configure(ManufacturedPdeConfiguration configuration,
                   ExactSolution exact_solution);
    [[nodiscard]] ManufacturedVerificationReport verify(
        const std::vector<std::size_t>& resolutions) const;

private:
    ManufacturedPdeConfiguration configuration_;
    ExactSolution exact_solution_;
    [[nodiscard]] double forcing(double x, double y, double step) const;
    [[nodiscard]] ManufacturedResolutionResult solve_resolution(std::size_t cells) const;
};

// -----------------------------------------------------------------------------
// Simulation-wide adaptive-resolution control.
// -----------------------------------------------------------------------------

enum class AdaptiveResolutionAction {
    None,
    RefineMesh,
    CoarsenMesh,
    IncreasePolynomialOrder,
    DecreasePolynomialOrder,
    ReduceTimeStep,
    IncreaseTimeStep,
    IncreasePhysicsFidelity,
    DecreasePhysicsFidelity,
    IncreaseParticles,
    DecreaseParticles,
    IncreasePrecision,
    DecreasePrecision
};

struct AdaptiveResolutionRegion {
    std::string id;
    double numerical_error = 0.0;
    double model_form_uncertainty = 0.0;
    double output_sensitivity = 1.0;
    double event_probability = 0.0;
    double calibration_distance = 0.0;
    double current_cost = 1.0;
    double mesh_scale = 1.0;
    std::size_t polynomial_order = 1;
    double time_step_s = 1.0e-3;
    std::size_t physics_fidelity = 0;
    std::size_t particle_count = 0;
    std::size_t precision_bits = 64;
};

struct AdaptiveResolutionConfiguration {
    double total_cost_budget = 100.0;
    double target_weighted_error = 1.0e-3;
    double refinement_cost_multiplier = 2.0;
    double coarsening_cost_multiplier = 0.55;
    std::size_t maximum_polynomial_order = 10;
    std::size_t maximum_physics_fidelity = 4;
    std::size_t maximum_precision_bits = 128;
    double minimum_time_step_s = 1.0e-8;
    double maximum_time_step_s = 1.0;
};

struct AdaptiveResolutionDecision {
    std::string region_id;
    AdaptiveResolutionAction action = AdaptiveResolutionAction::None;
    double priority = 0.0;
    double cost_before = 0.0;
    double cost_after = 0.0;
    double estimated_error_before = 0.0;
    double estimated_error_after = 0.0;
    std::string rationale;
};

struct AdaptiveResolutionReport {
    bool budget_satisfied = false;
    double total_cost = 0.0;
    double weighted_error_before = 0.0;
    double weighted_error_after = 0.0;
    std::vector<AdaptiveResolutionDecision> decisions;
    std::vector<AdaptiveResolutionRegion> updated_regions;
};

class SimulationWideAdaptiveResolutionController {
public:
    void configure(AdaptiveResolutionConfiguration configuration);
    [[nodiscard]] AdaptiveResolutionReport optimize(
        std::vector<AdaptiveResolutionRegion> regions) const;

private:
    AdaptiveResolutionConfiguration configuration_;
};

}  // namespace aesim::advanced

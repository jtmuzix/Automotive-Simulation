#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

struct Vector3 {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

struct Quaternion {
    double w = 1.0;
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

struct RigidBodyDefinition {
    std::string id;
    double mass_kg = 1.0;
    Vector3 inertia_diagonal_kg_m2{1.0, 1.0, 1.0};
    Vector3 position_m{};
    Quaternion orientation{};
    Vector3 linear_velocity_m_s{};
    Vector3 angular_velocity_rad_s{};
    bool dynamic = true;
    double linear_damping_per_s = 0.01;
    double angular_damping_per_s = 0.01;
};

struct RigidBodyState {
    std::string id;
    Vector3 position_m{};
    Quaternion orientation{};
    Vector3 linear_velocity_m_s{};
    Vector3 angular_velocity_rad_s{};
    Vector3 accumulated_force_n{};
    Vector3 accumulated_torque_nm{};
    double kinetic_energy_j = 0.0;
};

enum class CollisionShapeType { Sphere, Box, Plane };

struct CollisionShapeDefinition {
    std::string id;
    std::string body_id;
    CollisionShapeType type = CollisionShapeType::Sphere;
    Vector3 local_position_m{};
    Quaternion local_orientation{};
    double sphere_radius_m = 0.5;
    Vector3 box_half_extents_m{0.5, 0.5, 0.5};
    Vector3 plane_normal{0.0, 0.0, 1.0};
    double plane_offset_m = 0.0;
    double restitution = 0.0;
    double static_friction = 0.8;
    double dynamic_friction = 0.65;
    double rolling_friction = 0.01;
};

enum class JointType { Distance, Ball, Hinge, Fixed };

struct JointDefinition {
    std::string id;
    JointType type = JointType::Distance;
    std::string body_a;
    std::string body_b;
    Vector3 local_anchor_a_m{};
    Vector3 local_anchor_b_m{};
    Vector3 local_axis_a{1.0, 0.0, 0.0};
    Vector3 local_axis_b{1.0, 0.0, 0.0};
    double rest_length_m = -1.0;
    double minimum_position = -1.0e30;
    double maximum_position = 1.0e30;
    double stiffness_n_m = 0.0;
    double damping_n_s_m = 0.0;
    bool collisions_enabled = false;
};

struct ContactPoint {
    std::string shape_a;
    std::string shape_b;
    Vector3 position_m{};
    Vector3 normal_a_to_b{};
    double penetration_m = 0.0;
    double normal_impulse_n_s = 0.0;
    double friction_impulse_n_s = 0.0;
};

struct MultibodyEnergyAudit {
    double kinetic_energy_j = 0.0;
    double gravitational_potential_j = 0.0;
    double constraint_error_rms_m = 0.0;
    double maximum_penetration_m = 0.0;
    std::size_t contact_count = 0;
    std::size_t solver_iterations = 0;
};

class GeneralMultibodyWorld {
public:
    GeneralMultibodyWorld();
    ~GeneralMultibodyWorld();
    GeneralMultibodyWorld(GeneralMultibodyWorld&&) noexcept;
    GeneralMultibodyWorld& operator=(GeneralMultibodyWorld&&) noexcept;
    GeneralMultibodyWorld(const GeneralMultibodyWorld&) = delete;
    GeneralMultibodyWorld& operator=(const GeneralMultibodyWorld&) = delete;
    std::size_t add_body(RigidBodyDefinition definition);
    std::size_t add_shape(CollisionShapeDefinition definition);
    std::size_t add_joint(JointDefinition definition);
    void clear();
    void set_gravity(Vector3 gravity_m_s2);
    void apply_force(const std::string& body_id, Vector3 force_n, Vector3 world_point_m);
    void apply_torque(const std::string& body_id, Vector3 torque_nm);
    void set_body_state(const RigidBodyState& state);
    void step(double dt_s, unsigned substeps = 4, unsigned solver_iterations = 12);
    [[nodiscard]] const RigidBodyState& body(const std::string& id) const;
    [[nodiscard]] const std::vector<RigidBodyState>& bodies() const noexcept;
    [[nodiscard]] const std::vector<ContactPoint>& contacts() const noexcept;
    [[nodiscard]] MultibodyEnergyAudit audit() const;
    [[nodiscard]] doc::Value to_document() const;
private:
    struct BodyRuntime;
    struct ShapeRuntime;
    struct JointRuntime;
    std::vector<BodyRuntime> body_runtime_;
    std::vector<RigidBodyState> body_states_;
    std::vector<ShapeRuntime> shapes_;
    std::vector<JointRuntime> joints_;
    std::vector<ContactPoint> contacts_;
    Vector3 gravity_m_s2_{0.0, 0.0, -9.80665};
    MultibodyEnergyAudit last_audit_{};
};

struct CameraCalibrationSample {
    Vector3 target_in_camera_m{};
    double measured_u_px = 0.0;
    double measured_v_px = 0.0;
    double standard_uncertainty_px = 1.0;
};

struct CameraCalibrationResult {
    double focal_x_px = 1000.0;
    double focal_y_px = 1000.0;
    double principal_x_px = 0.0;
    double principal_y_px = 0.0;
    double radial_k1 = 0.0;
    double radial_k2 = 0.0;
    std::array<std::array<double, 6>, 6> covariance{};
    double rms_reprojection_error_px = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
    [[nodiscard]] std::array<double, 2> project(Vector3 target_in_camera_m) const;
    [[nodiscard]] doc::Value to_document() const;
};

struct RadarCalibrationSample {
    double true_range_m = 0.0;
    double measured_range_m = 0.0;
    double true_azimuth_rad = 0.0;
    double measured_azimuth_rad = 0.0;
    double true_range_rate_m_s = 0.0;
    double measured_range_rate_m_s = 0.0;
    double standard_uncertainty = 1.0;
};

struct AffineCalibrationAxis {
    double scale = 1.0;
    double bias = 0.0;
    double scale_standard_uncertainty = 0.0;
    double bias_standard_uncertainty = 0.0;
    double residual_rms = 0.0;
    [[nodiscard]] double correct(double measured) const;
};

struct RadarCalibrationResult {
    AffineCalibrationAxis range;
    AffineCalibrationAxis azimuth;
    AffineCalibrationAxis range_rate;
    [[nodiscard]] doc::Value to_document() const;
};

struct LidarCalibrationSample {
    double true_range_m = 0.0;
    double measured_range_m = 0.0;
    double true_azimuth_rad = 0.0;
    double measured_azimuth_rad = 0.0;
    double true_elevation_rad = 0.0;
    double measured_elevation_rad = 0.0;
    double standard_uncertainty = 1.0;
};

struct LidarCalibrationResult {
    AffineCalibrationAxis range;
    AffineCalibrationAxis azimuth;
    AffineCalibrationAxis elevation;
    [[nodiscard]] doc::Value to_document() const;
};

struct UncertaintyContribution {
    std::string name;
    double standard_uncertainty = 0.0;
    double sensitivity = 1.0;
    double degrees_of_freedom = 1.0e30;
};

struct UncertaintyBudgetResult {
    double combined_standard_uncertainty = 0.0;
    double effective_degrees_of_freedom = 1.0e30;
    double coverage_factor = 2.0;
    double expanded_uncertainty = 0.0;
    std::map<std::string, double> variance_fraction;
    [[nodiscard]] doc::Value to_document() const;
};

struct GaugeMeasurement {
    std::string part;
    std::string operator_id;
    double value = 0.0;
};

struct GaugeRrResult {
    double repeatability_variance = 0.0;
    double reproducibility_variance = 0.0;
    double part_to_part_variance = 0.0;
    double total_gauge_rr_standard_deviation = 0.0;
    double percent_gauge_rr = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class RawSensorMetrologyLaboratory {
public:
    [[nodiscard]] CameraCalibrationResult calibrate_camera(
        const std::vector<CameraCalibrationSample>& samples,
        CameraCalibrationResult initial = {},
        std::size_t maximum_iterations = 80,
        double tolerance = 1.0e-10) const;
    [[nodiscard]] RadarCalibrationResult calibrate_radar(
        const std::vector<RadarCalibrationSample>& samples) const;
    [[nodiscard]] LidarCalibrationResult calibrate_lidar(
        const std::vector<LidarCalibrationSample>& samples) const;
    [[nodiscard]] UncertaintyBudgetResult evaluate_uncertainty(
        const std::vector<UncertaintyContribution>& contributions,
        double coverage_factor = 2.0) const;
    [[nodiscard]] GaugeRrResult gauge_rr(const std::vector<GaugeMeasurement>& measurements) const;
};

struct AdsFleetObservation {
    std::string event_id;
    std::string vehicle_id;
    std::string software_version;
    double timestamp_s = 0.0;
    double exposure_s = 0.0;
    std::map<std::string, double> odd_features;
    double ego_speed_m_s = 0.0;
    double lead_range_m = 1.0e30;
    double closing_speed_m_s = 0.0;
    double planned_acceleration_m_s2 = 0.0;
    double actual_acceleration_m_s2 = 0.0;
    double planned_steering_rad = 0.0;
    double actual_steering_rad = 0.0;
    bool driver_intervention = false;
    bool minimum_risk_maneuver = false;
    bool collision = false;
};

struct AdsExtractedScenario {
    std::string id;
    std::string vehicle_id;
    std::string software_version;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    double minimum_ttc_s = 1.0e30;
    double maximum_control_discrepancy = 0.0;
    bool intervention = false;
    bool collision = false;
    std::vector<std::string> source_event_ids;
    std::map<std::string, double> representative_odd;
    [[nodiscard]] doc::Value to_document() const;
};

struct AdsCohortQualification {
    std::string software_version;
    double exposure_hours = 0.0;
    std::size_t interventions = 0;
    std::size_t minimum_risk_maneuvers = 0;
    std::size_t collisions = 0;
    double collision_rate_per_million_hours = 0.0;
    double collision_rate_upper_95_per_million_hours = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct AdsInUseQualificationReport {
    std::vector<AdsExtractedScenario> scenarios;
    std::vector<AdsCohortQualification> cohorts;
    std::map<std::string, double> population_stability_index;
    std::vector<std::string> shifted_odd_dimensions;
    std::vector<std::string> regression_campaigns;
    std::vector<std::string> safety_case_deltas;
    bool qualification_review_required = false;
    [[nodiscard]] doc::Value to_document() const;
};

class ContinuousAdsQualificationEngine {
public:
    void set_baseline(std::vector<AdsFleetObservation> observations);
    void ingest(AdsFleetObservation observation);
    void ingest(std::vector<AdsFleetObservation> observations);
    void clear_monitoring_data();
    [[nodiscard]] AdsInUseQualificationReport analyze(
        double ttc_trigger_s = 2.5,
        double control_discrepancy_trigger = 0.35,
        double scenario_gap_s = 2.0,
        double psi_review_threshold = 0.2) const;
private:
    std::vector<AdsFleetObservation> baseline_;
    std::vector<AdsFleetObservation> monitored_;
};

struct RiscVTraceEntry {
    std::uint64_t cycle = 0;
    std::uint32_t pc = 0;
    std::uint32_t instruction = 0;
    std::string mnemonic;
    std::optional<unsigned> destination_register;
    std::uint32_t destination_value = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct RiscVSoCConfiguration {
    std::size_t ram_bytes = 1024 * 1024;
    std::uint32_t reset_vector = 0;
    std::uint32_t trap_vector = 0x100;
    std::uint64_t cycles_per_timer_tick = 1;
    bool enable_m_extension = true;
    bool strict_alignment = true;
};

class InstructionAccurateRiscVSoC {
public:
    explicit InstructionAccurateRiscVSoC(RiscVSoCConfiguration configuration = {});
    void reset();
    void load_words(std::uint32_t address, const std::vector<std::uint32_t>& words);
    void load_bytes(std::uint32_t address, const std::vector<std::uint8_t>& bytes);
    std::size_t run(std::size_t maximum_instructions);
    bool step();
    void request_external_interrupt(bool pending = true);
    [[nodiscard]] std::uint32_t register_value(unsigned index) const;
    [[nodiscard]] std::uint32_t program_counter() const noexcept;
    [[nodiscard]] std::uint64_t cycles() const noexcept;
    [[nodiscard]] bool halted() const noexcept;
    [[nodiscard]] const std::string& uart_output() const noexcept;
    [[nodiscard]] const std::vector<RiscVTraceEntry>& trace() const noexcept;
    [[nodiscard]] std::uint8_t read8(std::uint32_t address) const;
    [[nodiscard]] std::uint16_t read16(std::uint32_t address) const;
    [[nodiscard]] std::uint32_t read32(std::uint32_t address) const;
    void write8(std::uint32_t address, std::uint8_t value);
    void write16(std::uint32_t address, std::uint16_t value);
    void write32(std::uint32_t address, std::uint32_t value);
    [[nodiscard]] doc::Value state_document() const;
private:
    RiscVSoCConfiguration configuration_;
    std::vector<std::uint8_t> memory_;
    std::array<std::uint32_t, 32> registers_{};
    std::uint32_t pc_ = 0;
    std::uint64_t cycles_ = 0;
    std::uint64_t timer_ = 0;
    std::uint64_t timer_compare_ = ~std::uint64_t{0};
    std::uint32_t gpio_ = 0;
    std::uint32_t mstatus_ = 0;
    std::uint32_t mie_ = 0;
    std::uint32_t mip_ = 0;
    std::uint32_t mtvec_ = 0;
    std::uint32_t mepc_ = 0;
    std::uint32_t mcause_ = 0;
    bool external_interrupt_pending_ = false;
    bool halted_ = false;
    std::string uart_output_;
    std::vector<RiscVTraceEntry> trace_;
    void trap(std::uint32_t cause, bool interrupt);
    [[nodiscard]] std::uint32_t read_csr(std::uint32_t csr) const;
    void write_csr(std::uint32_t csr, std::uint32_t value);
};

struct CoDesignVariable {
    std::string name;
    double initial_value = 0.0;
    double lower_bound = -1.0e30;
    double upper_bound = 1.0e30;
    double finite_difference_step = 1.0e-5;
    std::vector<double> discrete_values;
};

struct CoDesignScenario {
    std::string id;
    double weight = 1.0;
};

struct CoDesignEvaluation {
    std::map<std::string, double> objectives;
    std::map<std::string, double> constraints;
    std::map<std::string, std::map<std::string, double>> gradients;
};

struct CoDesignObjective {
    std::string name;
    double weight = 1.0;
    bool minimize = true;
};

struct CoDesignOptions {
    std::size_t maximum_iterations = 300;
    double learning_rate = 0.04;
    double gradient_tolerance = 1.0e-7;
    double constraint_penalty = 1000.0;
    double adam_beta1 = 0.9;
    double adam_beta2 = 0.999;
    double adam_epsilon = 1.0e-8;
    bool finite_difference_missing_gradients = true;
};

struct CoDesignIteration {
    std::size_t iteration = 0;
    double merit = 0.0;
    double maximum_constraint_violation = 0.0;
    std::map<std::string, double> variables;
};

struct CoDesignResult {
    bool feasible = false;
    bool converged = false;
    std::map<std::string, double> variables;
    std::map<std::string, double> objectives;
    std::map<std::string, double> constraints;
    double merit = 0.0;
    std::size_t iterations = 0;
    std::vector<CoDesignIteration> history;
    [[nodiscard]] doc::Value to_document() const;
};

class DifferentiableVehicleControllerCoDesigner {
public:
    using Evaluator = std::function<CoDesignEvaluation(
        const std::map<std::string, double>&, const CoDesignScenario&)>;
    [[nodiscard]] CoDesignResult optimize(
        const std::vector<CoDesignVariable>& variables,
        const std::vector<CoDesignObjective>& objectives,
        const std::vector<CoDesignScenario>& scenarios,
        const Evaluator& evaluator,
        const CoDesignOptions& options = {}) const;
};

} // namespace aesim::advanced

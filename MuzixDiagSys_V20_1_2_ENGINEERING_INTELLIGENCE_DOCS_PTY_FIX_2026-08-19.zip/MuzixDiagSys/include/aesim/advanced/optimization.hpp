#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace aesim::advanced {

struct DesignVariable {
    std::string name;
    double minimum = 0.0;
    double maximum = 1.0;
};

struct ObjectiveDefinition {
    std::string name;
    bool minimize = true;
    std::function<double(const std::vector<double>&)> evaluate;
};

struct ConstraintDefinition {
    std::string name;
    std::function<double(const std::vector<double>&)> violation;
};

struct OptimizationProblem {
    std::vector<DesignVariable> variables;
    std::vector<ObjectiveDefinition> objectives;
    std::vector<ConstraintDefinition> constraints;
    [[nodiscard]] static OptimizationProblem from_document(const doc::Value& value);
};

struct DesignCandidate {
    std::vector<double> variables;
    std::vector<double> objectives;
    double constraint_violation = 0.0;
    std::size_t rank = 0;
    double crowding_distance = 0.0;
    [[nodiscard]] doc::Value to_document(const OptimizationProblem& problem) const;
};

struct OptimizationResult {
    std::string algorithm;
    std::uint64_t seed = 0;
    std::size_t evaluations = 0;
    std::vector<DesignCandidate> population;
    std::vector<DesignCandidate> pareto_front;
    [[nodiscard]] doc::Value to_document(const OptimizationProblem& problem) const;
};

struct Nsga2Options {
    std::size_t population_size = 64;
    std::size_t generations = 80;
    double crossover_probability = 0.9;
    double mutation_probability = 0.0;
    double distribution_index = 20.0;
    std::uint64_t seed = 1;
};

struct BayesianOptimizationOptions {
    std::size_t initial_samples = 16;
    std::size_t iterations = 64;
    std::size_t acquisition_candidates = 2048;
    double length_scale = 0.25;
    double observation_noise = 1.0e-8;
    double exploration = 0.01;
    std::uint64_t seed = 1;
};

class MultiObjectiveOptimizer {
public:
    [[nodiscard]] OptimizationResult nsga2(const OptimizationProblem& problem,
                                            const Nsga2Options& options = {}) const;
    [[nodiscard]] OptimizationResult bayesian(const OptimizationProblem& problem,
                                               const BayesianOptimizationOptions& options = {}) const;

    [[nodiscard]] static bool dominates(const DesignCandidate& first,
                                        const DesignCandidate& second,
                                        const OptimizationProblem& problem);
    static void rank_and_crowding(std::vector<DesignCandidate>& population,
                                  const OptimizationProblem& problem);
};

} // namespace aesim::advanced

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::assured {

using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;

// ---------------------------------------------------------------------------
// Contract-driven co-simulation compiler and conservation governor
// ---------------------------------------------------------------------------

enum class PortDirection { Input, Output };
enum class PortCausality { Continuous, Sampled, Event };
enum class CouplingAction { Accept, RefineStep, Rollback, Abort };

struct UnitContract {
  std::string symbol;
  std::string dimension;
  double scale_to_si = 1.0;
  double offset_to_si = 0.0;
};

struct PortContract {
  std::string id;
  PortDirection direction = PortDirection::Input;
  PortCausality causality = PortCausality::Continuous;
  UnitContract unit;
  std::string frame;
  std::string conserved_quantity;
  double minimum = -1.0e300;
  double maximum = 1.0e300;
  double sample_period_s = 0.0;
  bool direct_feedthrough = false;
};

struct ComponentContract {
  std::string id;
  std::vector<PortContract> ports;
  double preferred_step_s = 1.0e-3;
  bool supports_rollback = true;
  bool supports_implicit_iteration = false;
  bool passive = true;
};

struct ContractConnection {
  std::string source_component;
  std::string source_port;
  std::string destination_component;
  std::string destination_port;
};

struct CompiledConnection {
  std::size_t source_component = 0;
  std::size_t source_port = 0;
  std::size_t destination_component = 0;
  std::size_t destination_port = 0;
  double scale = 1.0;
  double offset = 0.0;
  bool rate_transition = false;
};

struct CoSimulationPlan {
  std::vector<ComponentContract> components;
  std::vector<CompiledConnection> connections;
  std::vector<std::vector<std::size_t>> execution_stages;
  std::vector<std::vector<std::size_t>> algebraic_loops;
  double base_step_s = 0.0;
  bool rollback_safe = false;
  bool semantically_valid = false;
  std::string contract_digest;
};

struct ConservationSample {
  std::string quantity;
  double initial_storage = 0.0;
  double final_storage = 0.0;
  double integrated_inflow = 0.0;
  double integrated_outflow = 0.0;
  double modeled_generation = 0.0;
  double modeled_dissipation = 0.0;
  double absolute_tolerance = 1.0e-8;
  double relative_tolerance = 1.0e-6;
};

struct ConservationAudit {
  std::map<std::string, double> residuals;
  std::map<std::string, double> normalized_residuals;
  double worst_normalized_residual = 0.0;
  CouplingAction action = CouplingAction::Accept;
  bool conserved = true;
  std::string evidence_digest;
};

struct ConservationInterfaceSample {
  std::string interface_id;
  std::string quantity;
  double time_s = 0.0;
  double transferred_in = 0.0;
  double transferred_out = 0.0;
  double storage_change = 0.0;
  double modeled_generation = 0.0;
  double modeled_dissipation = 0.0;
  double absolute_tolerance = 1.0e-8;
  double relative_tolerance = 1.0e-6;
};

struct ConservationDiagnosticAudit {
  ConservationAudit aggregate;
  std::map<std::string, double> interface_residual;
  std::map<std::string, double> interface_normalized_residual;
  std::map<std::string, double> contribution_fraction;
  std::string dominant_interface;
  double dominant_time_s = 0.0;
  std::string evidence_digest;
};

struct DomainConservationSample {
  std::string domain;
  ConservationInterfaceSample sample;
};

struct CrossDomainConservationAudit {
  ConservationDiagnosticAudit aggregate;
  std::map<std::string, double> domain_absolute_residual;
  std::map<std::string, double> domain_normalized_residual;
  std::map<std::string, double> domain_contribution_fraction;
  std::string dominant_domain;
  bool cross_domain_conserved = true;
  std::vector<std::string> diagnostics;
  std::string evidence_digest;
};

class ContractDrivenCoSimulationCompiler {
 public:
  CoSimulationPlan compile(const std::vector<ComponentContract>& components,
                           const std::vector<ContractConnection>& connections) const;
  double convert_value(const CoSimulationPlan& plan,
                       std::size_t connection_index,
                       double source_value) const;
};

class ConservationGovernor {
 public:
  ConservationAudit audit(const std::vector<ConservationSample>& samples,
                          bool rollback_available,
                          double abort_multiple = 100.0) const;
  ConservationDiagnosticAudit audit_interfaces(
      const std::vector<ConservationInterfaceSample>& samples,
      bool rollback_available,
      double abort_multiple = 100.0) const;
  CrossDomainConservationAudit audit_domains(
      const std::vector<DomainConservationSample>& samples,
      bool rollback_available,
      double abort_multiple = 100.0) const;
};

// ---------------------------------------------------------------------------
// Certified probabilistic programming and Bayesian digital-twin runtime
// ---------------------------------------------------------------------------

struct GaussianBelief {
  Vector mean;
  Matrix covariance;
};

struct LinearGaussianModel {
  Matrix transition;
  Matrix control;
  Matrix process_covariance;
  Matrix observation;
  Matrix observation_covariance;
};

struct BayesianMeasurement {
  Vector value;
  Vector control;
};

struct BayesianTrajectory {
  std::vector<GaussianBelief> filtered;
  std::vector<GaussianBelief> smoothed;
  double log_evidence = 0.0;
  double minimum_covariance_eigen_bound = 0.0;
  bool numerically_certified = false;
  std::string evidence_digest;
};

struct ProbabilisticProgram {
  std::size_t dimension = 0;
  std::function<double(const Vector&)> log_prior;
  std::function<double(const Vector&)> log_likelihood;
  Vector initial;
  Vector proposal_scale;
};

struct PosteriorSummary {
  Vector mean;
  Matrix covariance;
  Vector lower_credible;
  Vector upper_credible;
  std::vector<Vector> samples;
  double acceptance_rate = 0.0;
  double effective_sample_size = 0.0;
  double split_rhat = 0.0;
  bool converged = false;
  std::string evidence_digest;
};

class CertifiedBayesianDigitalTwinRuntime {
 public:
  BayesianTrajectory infer_linear(const LinearGaussianModel& model,
                                  const GaussianBelief& prior,
                                  const std::vector<BayesianMeasurement>& measurements) const;

  PosteriorSummary sample_posterior(const ProbabilisticProgram& program,
                                    std::size_t chains,
                                    std::size_t burn_in,
                                    std::size_t retained_per_chain,
                                    std::uint64_t seed) const;
};

// ---------------------------------------------------------------------------
// Distributionally robust stochastic control and optimization
// ---------------------------------------------------------------------------

struct RobustLinearPlant {
  Matrix a;
  Matrix b;
  Matrix disturbance;
  Vector initial_state;
};

struct DisturbanceScenario {
  std::vector<Vector> disturbances;
  double probability = 1.0;
};

struct RobustControlProblem {
  RobustLinearPlant plant;
  std::vector<DisturbanceScenario> scenarios;
  Matrix state_cost;
  Matrix control_cost;
  Vector target_state;
  Vector control_min;
  Vector control_max;
  Vector state_abs_limit;
  std::size_t horizon = 1;
  double cvar_alpha = 0.95;
  double cvar_weight = 1.0;
  double chance_constraint = 0.05;
  double wasserstein_radius = 0.0;
  std::size_t maximum_iterations = 200;
};

struct RobustControlResult {
  std::vector<Vector> controls;
  double expected_cost = 0.0;
  double worst_case_cost = 0.0;
  double cvar_cost = 0.0;
  double robust_objective = 0.0;
  double violation_probability = 0.0;
  double gradient_norm = 0.0;
  std::size_t iterations = 0;
  bool feasible = false;
  bool converged = false;
  std::string evidence_digest;
};

class DistributionallyRobustControlOptimizer {
 public:
  RobustControlResult optimize(const RobustControlProblem& problem) const;
  std::vector<Vector> simulate(const RobustLinearPlant& plant,
                               const std::vector<Vector>& controls,
                               const std::vector<Vector>& disturbances) const;
};

// ---------------------------------------------------------------------------
// Verified software synthesis and proof-carrying code generation
// ---------------------------------------------------------------------------

struct SoftwareSignal {
  std::string name;
  double minimum = 0.0;
  double maximum = 0.0;
  std::string unit;
};

struct AffineControllerSpecification {
  std::string id;
  std::vector<SoftwareSignal> inputs;
  std::vector<SoftwareSignal> outputs;
  Matrix gains;
  Vector bias;
  Vector output_min;
  Vector output_max;
  std::vector<std::string> requirement_ids;
  std::uint32_t fixed_point_fraction_bits = 16;
  std::uint64_t wcet_budget_cycles = 10000;
};

struct ProofObligation {
  std::string id;
  std::string statement;
  bool discharged = false;
  double margin = 0.0;
};

struct SoftwareSignatureEvidence {
  std::string payload_sha256;
  std::string public_key_pem;
  std::string signature_base64;
  std::string algorithm = "Ed25519";
  std::int64_t timestamp_unix = 0;
};

struct ProofCarryingSoftwarePackage {
  std::string header;
  std::string source;
  std::string unit_test_source;
  std::vector<ProofObligation> obligations;
  std::map<std::string, std::string> requirement_trace;
  std::uint64_t estimated_wcet_cycles = 0;
  std::size_t estimated_stack_bytes = 0;
  std::string source_sha256;
  SoftwareSignatureEvidence signature;
  bool qualified = false;
};

class VerifiedAutomotiveSoftwareSynthesizer {
 public:
  ProofCarryingSoftwarePackage synthesize(const AffineControllerSpecification& specification) const;
  bool verify(const AffineControllerSpecification& specification,
              const ProofCarryingSoftwarePackage& package) const;
};

// ---------------------------------------------------------------------------
// Crystal plasticity, phase-field fracture, joining, and gigacasting twin
// ---------------------------------------------------------------------------

struct SlipSystem {
  Vector direction;
  Vector normal;
  double critical_shear_pa = 50.0e6;
  double hardening_pa = 100.0e6;
};

struct CrystalMaterial {
  double shear_modulus_pa = 26.0e9;
  double rate_exponent = 20.0;
  double reference_shear_rate_s = 1.0e-3;
  std::vector<SlipSystem> slip_systems;
};

struct CrystalLoadStep {
  Matrix stress_pa;
  double dt_s = 1.0e-3;
  double temperature_k = 298.15;
};

struct CrystalPlasticityResult {
  Vector accumulated_slip;
  Matrix plastic_strain;
  double plastic_work_j_m3 = 0.0;
  double maximum_resolved_shear_pa = 0.0;
  bool stable = false;
};

struct PhaseFieldMesh1D {
  std::vector<double> x_m;
  Vector displacement_m;
  Vector initial_damage;
  double youngs_modulus_pa = 70.0e9;
  double fracture_energy_j_m2 = 2700.0;
  double length_scale_m = 1.0e-3;
};

struct PhaseFieldFractureResult {
  Vector damage;
  Vector stress_pa;
  double elastic_energy_j_m2 = 0.0;
  double fracture_energy_j_m2 = 0.0;
  double crack_length_m = 0.0;
  std::size_t iterations = 0;
  bool converged = false;
};

struct JoiningProcess {
  enum class Type { ResistanceSpot, LaserWeld, Adhesive, Rivet, Hybrid };
  Type type = Type::ResistanceSpot;
  double diameter_m = 0.006;
  double penetration_fraction = 1.0;
  double porosity_fraction = 0.0;
  double adhesive_thickness_m = 0.001;
  double residual_stress_pa = 0.0;
};

struct JointQualification {
  double tensile_capacity_n = 0.0;
  double shear_capacity_n = 0.0;
  double fatigue_cycles = 0.0;
  double energy_absorption_j = 0.0;
  bool qualified = false;
};

struct GigacastingCell {
  double volume_m3 = 1.0e-5;
  double temperature_k = 950.0;
  double liquid_fraction = 1.0;
  double pressure_pa = 1.0e5;
  double oxide_fraction = 0.0;
};

struct GigacastingProcess {
  std::vector<GigacastingCell> cells;
  std::vector<std::pair<std::size_t, std::size_t>> neighbors;
  double die_temperature_k = 473.15;
  double heat_transfer_w_m2_k = 2000.0;
  double characteristic_area_m2 = 1.0e-3;
  double alloy_density_kg_m3 = 2700.0;
  double heat_capacity_j_kg_k = 1000.0;
  double latent_heat_j_kg = 390000.0;
  double solidus_k = 830.0;
  double liquidus_k = 890.0;
};

struct GigacastingResult {
  std::vector<GigacastingCell> cells;
  double solidification_time_s = 0.0;
  double shrinkage_porosity_fraction = 0.0;
  double oxide_entrainment_fraction = 0.0;
  double maximum_residual_stress_pa = 0.0;
  bool fully_solidified = false;
};

class ManufacturingStructureTwin {
 public:
  CrystalPlasticityResult integrate_crystal(const CrystalMaterial& material,
                                             const std::vector<CrystalLoadStep>& history) const;
  PhaseFieldFractureResult solve_fracture(const PhaseFieldMesh1D& mesh,
                                           std::size_t maximum_iterations,
                                           double tolerance) const;
  JointQualification qualify_joint(const JoiningProcess& process,
                                    double sheet_thickness_m,
                                    double base_ultimate_strength_pa,
                                    double cyclic_load_n) const;
  GigacastingResult simulate_gigacasting(const GigacastingProcess& process,
                                         double dt_s,
                                         std::size_t maximum_steps) const;
};

// ---------------------------------------------------------------------------
// Autonomous robotic proving-ground and test-cell orchestrator
// ---------------------------------------------------------------------------

struct Point3 { double x = 0.0; double y = 0.0; double z = 0.0; };
struct SafetyZone { Point3 minimum; Point3 maximum; std::string hazard; };

struct TestResource {
  std::string id;
  std::set<std::string> capabilities;
  double available_from_s = 0.0;
  double maximum_power_kw = 0.0;
  bool calibrated = true;
  bool safety_interlock_ok = true;
};

struct TestOperation {
  std::string id;
  double duration_s = 0.0;
  std::set<std::string> required_capabilities;
  std::vector<std::string> predecessors;
  std::vector<Point3> robot_path;
  double requested_power_kw = 0.0;
  double minimum_quality = 0.95;
  std::size_t maximum_retries = 1;
};

struct ScheduledOperation {
  std::string operation_id;
  std::string resource_id;
  double start_s = 0.0;
  double end_s = 0.0;
  std::size_t attempts = 0;
  double measured_quality = 0.0;
  bool completed = false;
};

struct TestCellExecutionReport {
  std::vector<ScheduledOperation> schedule;
  double makespan_s = 0.0;
  double total_energy_kwh = 0.0;
  std::vector<std::string> safety_events;
  bool all_completed = false;
  bool safe = false;
  std::string audit_digest;
};

class AutonomousTestCellOrchestrator {
 public:
  TestCellExecutionReport orchestrate(std::vector<TestResource> resources,
                                      const std::vector<TestOperation>& operations,
                                      const std::vector<SafetyZone>& exclusion_zones,
                                      std::uint64_t deterministic_seed) const;
};

// ---------------------------------------------------------------------------
// Post-crash rescue, toxic-plume, and emergency-response twin
// ---------------------------------------------------------------------------

struct RoadNode { std::string id; double x_m = 0.0; double y_m = 0.0; };
struct RoadEdge { std::size_t from = 0; std::size_t to = 0; double travel_time_s = 0.0; };

struct ToxicSpecies {
  std::string id;
  double generation_kg_s = 0.0;
  double decay_s_inv = 0.0;
  double immediately_dangerous_kg_m3 = 1.0e-3;
};

struct CrashHazardScenario {
  double compartment_volume_m3 = 30.0;
  double ventilation_m3_s = 0.1;
  double battery_heat_release_kw = 0.0;
  double fire_growth_s_inv = 0.01;
  double suppression_start_s = 1.0e9;
  double suppression_effectiveness = 0.0;
  std::vector<ToxicSpecies> species;
  double occupant_injury_severity = 0.0;
  double entrapment_complexity = 1.0;
  double simulation_duration_s = 1800.0;
  double dt_s = 1.0;
};

struct RescueResource {
  std::string id;
  std::size_t road_node = 0;
  double mobilization_s = 60.0;
  double extraction_rate = 1.0;
  double protection_factor = 1.0;
};

struct EmergencyResponseResult {
  double first_responder_arrival_s = 0.0;
  double extraction_complete_s = 0.0;
  double peak_heat_release_kw = 0.0;
  std::map<std::string, double> peak_concentration_kg_m3;
  std::map<std::string, double> responder_dose_kg_s_m3;
  double occupant_survival_probability = 0.0;
  double hazard_radius_m = 0.0;
  std::vector<std::string> recommended_actions;
  bool extraction_successful = false;
  std::string evidence_digest;
};

class PostCrashEmergencyResponseTwin {
 public:
  EmergencyResponseResult simulate(const CrashHazardScenario& scenario,
                                   const std::vector<RoadNode>& road_nodes,
                                   const std::vector<RoadEdge>& road_edges,
                                   std::size_t crash_node,
                                   const std::vector<RescueResource>& resources) const;
};

// ---------------------------------------------------------------------------
// Megawatt charging, battery swapping, and depot operations twin
// ---------------------------------------------------------------------------

struct DepotVehicle {
  std::string id;
  double arrival_s = 0.0;
  double departure_s = 0.0;
  double battery_kwh = 0.0;
  double initial_soc = 0.0;
  double required_soc = 1.0;
  double maximum_charge_kw = 0.0;
  bool swap_capable = false;
};

struct DepotCharger {
  std::string id;
  double maximum_power_kw = 0.0;
  double efficiency = 0.95;
  double cable_thermal_capacity_kj_k = 100.0;
  double cable_cooling_kw_k = 1.0;
  double connector_resistance_ohm = 5.0e-5;
};

struct SwapPack {
  std::string id;
  double capacity_kwh = 0.0;
  double soc = 0.0;
  double state_of_health = 1.0;
  bool quarantined = false;
};

struct TariffInterval {
  double start_s = 0.0;
  double end_s = 0.0;
  double energy_price_per_kwh = 0.0;
  double carbon_kg_per_kwh = 0.0;
};

struct DepotConfiguration {
  double transformer_limit_kw = 1000.0;
  double onsite_storage_kwh = 0.0;
  double onsite_storage_soc = 0.5;
  double onsite_storage_power_kw = 0.0;
  double demand_charge_per_kw = 0.0;
  double time_step_s = 300.0;
  double swap_duration_s = 300.0;
};

struct DepotDispatch {
  double start_s = 0.0;
  double end_s = 0.0;
  std::string vehicle_id;
  std::string asset_id;
  double grid_power_kw = 0.0;
  double delivered_energy_kwh = 0.0;
  bool battery_swap = false;
};

struct DepotOperationsResult {
  std::vector<DepotDispatch> dispatches;
  std::map<std::string, double> final_vehicle_soc;
  std::map<std::string, double> final_pack_soc;
  double energy_cost = 0.0;
  double demand_charge = 0.0;
  double carbon_kg = 0.0;
  double peak_grid_kw = 0.0;
  double degradation_cost_index = 0.0;
  std::size_t missed_departures = 0;
  bool transformer_qualified = false;
  std::string evidence_digest;
};

class MegawattDepotOperationsTwin {
 public:
  DepotOperationsResult optimize(const std::vector<DepotVehicle>& vehicles,
                                 std::vector<DepotCharger> chargers,
                                 std::vector<SwapPack> packs,
                                 const std::vector<TariffInterval>& tariffs,
                                 const DepotConfiguration& configuration) const;
};

// ---------------------------------------------------------------------------
// Privacy-preserving engineering data space and zero-knowledge evidence
// ---------------------------------------------------------------------------

struct DataPolicy {
  std::string dataset;
  std::set<std::string> allowed_purposes;
  std::set<std::string> allowed_columns;
  double epsilon_budget = 1.0;
};

struct EngineeringRecord {
  std::string owner;
  std::string dataset;
  std::map<std::string, double> numeric_fields;
};

struct PrivateAggregate {
  double noisy_sum = 0.0;
  std::size_t contributors = 0;
  double epsilon_spent = 0.0;
  bool policy_authorized = false;
  std::string audit_digest;
};

struct SchnorrEvidence {
  std::string curve = "prime256v1";
  std::string public_key_hex;
  std::string commitment_hex;
  std::string challenge_hex;
  std::string response_hex;
  std::string statement_digest;
};

class PrivacyPreservingEngineeringDataSpace {
 public:
  PrivateAggregate aggregate(const std::vector<EngineeringRecord>& records,
                             DataPolicy& policy,
                             const std::string& purpose,
                             const std::string& column,
                             double sensitivity,
                             double epsilon,
                             std::uint64_t seed) const;

  SchnorrEvidence prove_secret_knowledge(const std::string& statement,
                                         const std::string& secret_material,
                                         std::uint64_t nonce_seed) const;
  bool verify_secret_knowledge(const std::string& statement,
                               const SchnorrEvidence& evidence) const;
};

// ---------------------------------------------------------------------------
// Fleet causal root-cause and reliability-growth engine
// ---------------------------------------------------------------------------

struct FleetCausalRecord {
  std::string vehicle_id;
  std::string cohort;
  bool treated = false;
  double outcome = 0.0;
  double exposure = 1.0;
  Vector covariates;
  std::map<std::string, double> candidate_causes;
  double event_time = 0.0;
};

struct RootCauseScore {
  std::string cause;
  double standardized_effect = 0.0;
  double odds_ratio = 1.0;
  double confidence = 0.0;
};

struct FleetCausalReliabilityResult {
  double average_treatment_effect = 0.0;
  double ate_standard_error = 0.0;
  double treated_failure_rate = 0.0;
  double control_failure_rate = 0.0;
  double crow_amsaa_beta = 0.0;
  double crow_amsaa_lambda = 0.0;
  double projected_failure_rate = 0.0;
  std::vector<RootCauseScore> root_causes;
  double propensity_overlap = 0.0;
  bool causally_identifiable = false;
  bool reliability_improving = false;
  std::string evidence_digest;
};

class FleetCausalReliabilityGrowthEngine {
 public:
  FleetCausalReliabilityResult analyze(const std::vector<FleetCausalRecord>& records,
                                       double projection_time) const;
};

}  // namespace aesim::advanced::assured

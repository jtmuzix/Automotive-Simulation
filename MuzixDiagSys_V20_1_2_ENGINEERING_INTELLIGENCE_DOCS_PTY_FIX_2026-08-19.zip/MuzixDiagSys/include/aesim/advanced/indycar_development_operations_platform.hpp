#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::indydev {

class IndyCarDevelopmentLadderPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarFirestoneProductionMetrologyPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarPowerUnitSupplyHomologationPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarRenewableFuelLubricantLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarElectricalCyberPhysicalTwin {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarRaceEngineeringIntelligence {
public:
    [[nodiscard]] doc::Value optimize(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarDriverSimulatorQualificationLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarTeamFactoryLogisticsTwin {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarCircuitHomologationSafetyPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarMedicalOperationsBiomechanicsPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarDevelopmentOperationsPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::indydev

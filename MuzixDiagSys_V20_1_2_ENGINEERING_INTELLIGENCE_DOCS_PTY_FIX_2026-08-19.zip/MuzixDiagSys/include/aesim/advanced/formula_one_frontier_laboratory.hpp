#pragma once

#include "aesim/advanced/formula_one_design_qualification.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Minimum-lap-time optimal control and racing-line solver.
// -----------------------------------------------------------------------------
struct F1LapTrackNode {
    double distance_m = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double curvature_1_m = 0.0;
    double half_width_left_m = 5.0;
    double half_width_right_m = 5.0;
    double grip = 1.0;
    double gradient = 0.0;
    double speed_limit_m_s = 150.0;
    void validate() const;
};

struct F1LapVehicleModel {
    double mass_kg = 800.0;
    double wheelbase_m = 3.6;
    double max_power_w = 740000.0;
    double max_ers_power_w = 350000.0;
    double ers_energy_j = 8.5e6;
    double drag_area_m2 = 1.05;
    double downforce_area_m2 = 4.6;
    double rolling_resistance = 0.014;
    double max_brake_force_n = 40000.0;
    double tyre_mu = 1.9;
    double max_steer_rad = 0.42;
    std::vector<double> gear_ratios{2.9,2.25,1.8,1.5,1.28,1.12,1.0,0.9};
    double final_drive = 3.3;
    double tyre_radius_m = 0.365;
    void validate() const;
};

struct F1LapControlPoint {
    double distance_m = 0.0;
    double lateral_offset_m = 0.0;
    double speed_m_s = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    double steer_rad = 0.0;
    int gear = 1;
    double ers_power_w = 0.0;
    double ers_energy_j = 0.0;
    double lateral_accel_m_s2 = 0.0;
};

struct F1MinimumLapResult {
    double lap_time_s = 0.0;
    double energy_used_j = 0.0;
    double maximum_lateral_accel_m_s2 = 0.0;
    double maximum_brake_decel_m_s2 = 0.0;
    bool converged = false;
    std::size_t iterations = 0;
    std::vector<F1LapControlPoint> trajectory;
    std::vector<double> objective_history_s;
    std::string evidence_sha256;
};

class F1MinimumLapTimeSolver {
public:
    F1MinimumLapTimeSolver(std::vector<F1LapTrackNode> track, F1LapVehicleModel vehicle);
    [[nodiscard]] F1MinimumLapResult solve(std::size_t maximum_iterations = 40,
                                            double line_tolerance_m = 1.0e-3) const;
private:
    std::vector<F1LapTrackNode> track_;
    F1LapVehicleModel vehicle_;
};

// -----------------------------------------------------------------------------
// Unsteady CFD, moving ground, wheel wakes and aeroelastic FSI.
// -----------------------------------------------------------------------------
struct F1CFDWheel {
    double x_m = 0.0;
    double y_m = 0.0;
    double radius_m = 0.36;
    double angular_speed_rad_s = 0.0;
    double wake_strength = 1.0;
    void validate() const;
};

struct F1AeroelasticSurface {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    double area_m2 = 0.1;
    double lift_slope_per_rad = 4.5;
    double base_incidence_rad = 0.0;
    double mass_kg = 1.0;
    double stiffness_n_m = 10000.0;
    double damping_n_s_m = 50.0;
    double displacement_m = 0.0;
    double velocity_m_s = 0.0;
    void validate() const;
};

struct F1CFDConfiguration {
    std::size_t nx = 80;
    std::size_t ny = 36;
    double length_m = 12.0;
    double height_m = 3.0;
    double freestream_m_s = 60.0;
    double moving_ground_m_s = 60.0;
    double density_kg_m3 = 1.225;
    double kinematic_viscosity_m2_s = 1.5e-5;
    double time_step_s = 2.0e-4;
    std::size_t poisson_iterations = 80;
    double sor_relaxation = 1.65;
    void validate() const;
};

struct F1CFDTimeSample {
    double time_s = 0.0;
    double drag_n = 0.0;
    double downforce_n = 0.0;
    double front_balance = 0.5;
    double wake_deficit = 0.0;
    std::map<std::string,double> surface_deflection_m;
};

struct F1UnsteadyCFDResult {
    bool stable = false;
    double mean_drag_n = 0.0;
    double mean_downforce_n = 0.0;
    double mean_front_balance = 0.5;
    double maximum_vorticity_s = 0.0;
    double maximum_surface_deflection_m = 0.0;
    std::vector<double> velocity_u_m_s;
    std::vector<double> velocity_v_m_s;
    std::vector<double> vorticity_s;
    std::vector<F1CFDTimeSample> history;
    std::string evidence_sha256;
};

class F1UnsteadyAeroFSILaboratory {
public:
    F1UnsteadyAeroFSILaboratory(F1CFDConfiguration configuration,
                                std::vector<F1CFDWheel> wheels,
                                std::vector<F1AeroelasticSurface> surfaces);
    [[nodiscard]] F1UnsteadyCFDResult run(double duration_s, std::size_t sample_stride = 10) const;
private:
    F1CFDConfiguration configuration_;
    std::vector<F1CFDWheel> wheels_;
    std::vector<F1AeroelasticSurface> surfaces_;
};

// -----------------------------------------------------------------------------
// ATR, cost-cap and development-portfolio optimization.
// -----------------------------------------------------------------------------
struct F1DevelopmentProject {
    std::string id;
    std::string name;
    double expected_lap_gain_s = 0.0;
    double gain_std_s = 0.0;
    double success_probability = 1.0;
    double cost = 0.0;
    double cfd_units = 0.0;
    double tunnel_runs = 0.0;
    double wind_on_hours = 0.0;
    double engineering_hours = 0.0;
    int lead_weeks = 1;
    int latest_introduction_week = 52;
    std::vector<std::string> dependencies;
    std::vector<std::string> exclusions;
    void validate() const;
};

struct F1DevelopmentBudget {
    double cost_cap = 0.0;
    double cfd_units = 0.0;
    double tunnel_runs = 0.0;
    double wind_on_hours = 0.0;
    double engineering_hours = 0.0;
    int planning_weeks = 52;
    double risk_aversion = 1.0;
    void validate() const;
};

struct F1DevelopmentScheduleEntry {
    std::string project_id;
    int start_week = 0;
    int introduction_week = 0;
    double expected_gain_s = 0.0;
};

struct F1DevelopmentPortfolioResult {
    std::vector<std::string> selected_projects;
    std::vector<F1DevelopmentScheduleEntry> schedule;
    double expected_lap_gain_s = 0.0;
    double risk_adjusted_gain_s = 0.0;
    double cost_used = 0.0;
    double cfd_units_used = 0.0;
    double tunnel_runs_used = 0.0;
    double wind_on_hours_used = 0.0;
    double engineering_hours_used = 0.0;
    std::size_t explored_portfolios = 0;
    bool feasible = false;
    std::string evidence_sha256;
};

class F1DevelopmentPortfolioOptimizer {
public:
    [[nodiscard]] F1DevelopmentPortfolioResult optimize(
        const std::vector<F1DevelopmentProject>& projects,
        const F1DevelopmentBudget& budget) const;
};

// -----------------------------------------------------------------------------
// Composite survival cell and crash-homologation twin.
// -----------------------------------------------------------------------------
struct F1CompositeMaterial {
    std::string id;
    double e1_pa = 130.0e9;
    double e2_pa = 9.0e9;
    double g12_pa = 5.0e9;
    double nu12 = 0.3;
    double density_kg_m3 = 1600.0;
    double xt_pa = 1.5e9;
    double xc_pa = 1.0e9;
    double yt_pa = 50.0e6;
    double yc_pa = 180.0e6;
    double s12_pa = 80.0e6;
    double fracture_energy_j_m2 = 50000.0;
    void validate() const;
};

struct F1CompositePly {
    std::string material_id;
    double thickness_m = 0.00025;
    double angle_deg = 0.0;
};

struct F1SurvivalCellZone {
    std::string id;
    double area_m2 = 0.2;
    double length_m = 0.5;
    std::vector<F1CompositePly> plies;
    double core_thickness_m = 0.02;
    double core_crush_pa = 2.0e6;
    double bond_strength_pa = 20.0e6;
    void validate() const;
};

enum class F1HomologationLoadKind { FrontalImpact, RearImpact, SideImpact, HaloStatic, RollStatic, Squeeze };

struct F1HomologationLoadCase {
    std::string id;
    F1HomologationLoadKind kind = F1HomologationLoadKind::FrontalImpact;
    double impact_mass_kg = 800.0;
    double impact_speed_m_s = 14.0;
    double required_load_n = 0.0;
    double load_duration_s = 0.0;
    double maximum_intrusion_m = 0.15;
    double maximum_deceleration_g = 60.0;
    void validate() const;
};

struct F1HomologationCaseResult {
    std::string load_case_id;
    bool passed = false;
    double absorbed_energy_j = 0.0;
    double peak_force_n = 0.0;
    double peak_deceleration_g = 0.0;
    double intrusion_m = 0.0;
    double maximum_failure_index = 0.0;
    double delaminated_area_m2 = 0.0;
    std::vector<std::string> failed_zones;
};

struct F1SurvivalCellQualificationResult {
    bool homologated = false;
    std::vector<F1HomologationCaseResult> cases;
    double minimum_margin = 0.0;
    std::string evidence_sha256;
};

class F1CompositeSurvivalCellTwin {
public:
    void set_materials(std::vector<F1CompositeMaterial> materials);
    void set_zones(std::vector<F1SurvivalCellZone> zones);
    [[nodiscard]] F1SurvivalCellQualificationResult qualify(
        const std::vector<F1HomologationLoadCase>& cases,
        double time_step_s = 1.0e-5) const;
private:
    std::vector<F1CompositeMaterial> materials_;
    std::vector<F1SurvivalCellZone> zones_;
};

// -----------------------------------------------------------------------------
// Serialized tyre-set lifecycle and weekend allocation.
// -----------------------------------------------------------------------------
enum class F1WeekendSession { Practice1, Practice2, Practice3, SprintQualifying, Sprint, Qualifying, Race };

struct F1SerializedTyreSet {
    std::string serial;
    F1TyreCompound compound = F1TyreCompound::Medium;
    double tread_remaining = 1.0;
    double heat_cycles = 0.0;
    double total_laps = 0.0;
    double maximum_temperature_c = 20.0;
    double flat_spot_severity = 0.0;
    double pickup_mass_kg = 0.0;
    double structural_health = 1.0;
    double uncertainty_s = 0.05;
    bool returned = false;
    void validate() const;
};

struct F1TyreSessionDemand {
    std::string id;
    F1WeekendSession session = F1WeekendSession::Practice1;
    int laps = 1;
    std::vector<F1TyreCompound> allowed_compounds;
    double track_temperature_c = 30.0;
    double importance = 1.0;
    bool must_use_new_set = false;
    bool reserve_for_race = false;
    void validate() const;
};

struct F1TyreAllocationEntry {
    std::string demand_id;
    std::string tyre_serial;
    double predicted_loss_s = 0.0;
    double resulting_tread = 0.0;
    double resulting_heat_cycles = 0.0;
};

struct F1TyreWeekendAllocationResult {
    bool feasible = false;
    double weighted_time_loss_s = 0.0;
    std::vector<F1TyreAllocationEntry> allocations;
    std::vector<F1SerializedTyreSet> final_inventory;
    std::size_t explored_allocations = 0;
    std::string evidence_sha256;
};

class F1TyreWeekendAllocator {
public:
    [[nodiscard]] F1TyreWeekendAllocationResult optimize(
        const std::vector<F1SerializedTyreSet>& inventory,
        const std::vector<F1TyreSessionDemand>& demands) const;
};

// -----------------------------------------------------------------------------
// Qualifying release, preparation, traffic and tow optimization.
// -----------------------------------------------------------------------------
struct F1QualifyingTrafficCar {
    std::string car_id;
    double release_time_s = 0.0;
    double out_lap_time_s = 100.0;
    double push_lap_time_s = 90.0;
    double pace_uncertainty_s = 0.2;
    double tow_strength = 0.0;
};

struct F1QualifyingScenario {
    double session_start_s = 0.0;
    double session_end_s = 900.0;
    double base_lap_time_s = 90.0;
    double out_lap_time_s = 105.0;
    double preparation_lap_time_s = 105.0;
    double track_evolution_s_per_min = 0.02;
    double interruption_hazard_per_s = 0.0002;
    double tyre_optimum_temperature_c = 100.0;
    double initial_tyre_temperature_c = 70.0;
    double tyre_heating_per_prep_lap_c = 15.0;
    double fuel_penalty_s_per_lap = 0.03;
    std::vector<F1QualifyingTrafficCar> traffic;
    void validate() const;
};

struct F1QualifyingPlan {
    double release_time_s = 0.0;
    int preparation_laps = 0;
    int push_laps = 1;
    std::string tow_car_id;
    double target_gap_s = 0.0;
    double expected_best_lap_s = 0.0;
    double valid_lap_probability = 0.0;
    double expected_utility = 0.0;
    double final_tyre_temperature_c = 0.0;
};

struct F1QualifyingOptimizationResult {
    bool feasible = false;
    F1QualifyingPlan best_plan;
    std::vector<F1QualifyingPlan> evaluated_plans;
    std::string evidence_sha256;
};

class F1QualifyingOptimizer {
public:
    [[nodiscard]] F1QualifyingOptimizationResult optimize(
        const F1QualifyingScenario& scenario,
        double release_step_s = 5.0) const;
};

// -----------------------------------------------------------------------------
// Formation lap, grid start and launch procedure.
// -----------------------------------------------------------------------------
struct F1LaunchVehicle {
    double mass_kg = 800.0;
    double tyre_radius_m = 0.365;
    double first_gear_ratio = 2.9;
    double final_drive = 3.3;
    double engine_inertia_kg_m2 = 0.18;
    double max_engine_torque_nm = 650.0;
    double clutch_capacity_nm = 900.0;
    double tyre_mu = 1.8;
    double driven_weight_fraction = 0.55;
    double drag_area_m2 = 1.0;
    void validate() const;
};

struct F1LaunchProcedure {
    double formation_lap_duration_s = 180.0;
    double tyre_heating_effort = 0.7;
    double brake_heating_effort = 0.6;
    double initial_tyre_temperature_c = 60.0;
    double initial_clutch_temperature_c = 80.0;
    double clutch_bite_point = 0.45;
    double clutch_release_duration_s = 1.2;
    double target_engine_rpm = 10500.0;
    double reaction_mean_s = 0.22;
    double reaction_std_s = 0.035;
    double grid_grip = 1.0;
    double grid_gradient = 0.0;
    std::uint64_t seed = 1;
    void validate() const;
};

struct F1LaunchTracePoint {
    double time_s = 0.0;
    double distance_m = 0.0;
    double speed_m_s = 0.0;
    double engine_rpm = 0.0;
    double clutch_command = 0.0;
    double wheel_slip = 0.0;
    double acceleration_m_s2 = 0.0;
};

struct F1LaunchResult {
    double tyre_temperature_c = 0.0;
    double brake_temperature_c = 0.0;
    double clutch_temperature_c = 0.0;
    double reaction_time_s = 0.0;
    double zero_to_100_s = 0.0;
    double zero_to_200_s = 0.0;
    double distance_at_5s_m = 0.0;
    double stall_probability = 0.0;
    double excessive_wheelspin_probability = 0.0;
    double false_start_probability = 0.0;
    std::vector<F1LaunchTracePoint> trace;
    std::string evidence_sha256;
};

class F1GridStartLaboratory {
public:
    [[nodiscard]] F1LaunchResult simulate(const F1LaunchVehicle& vehicle,
                                           const F1LaunchProcedure& procedure,
                                           std::size_t monte_carlo_runs = 500) const;
};

// -----------------------------------------------------------------------------
// High-rate telemetry, DAQ and radio bandwidth architecture.
// -----------------------------------------------------------------------------
struct F1DAQChannel {
    std::string id;
    double sample_rate_hz = 100.0;
    int bits_per_sample = 16;
    double compression_ratio = 1.0;
    double engineering_value = 1.0;
    double safety_value = 0.0;
    double maximum_latency_s = 1.0;
    bool event_triggered = false;
    double event_probability_per_s = 0.0;
    double event_duration_s = 0.0;
    void validate() const;
};

struct F1TelemetryLink {
    double bandwidth_bits_s = 1.0e6;
    double packet_payload_bits = 8192.0;
    double packet_loss_probability = 0.01;
    double round_trip_latency_s = 0.05;
    double onboard_storage_bits = 1.0e9;
    std::uint64_t seed = 1;
    void validate() const;
};

struct F1ChannelTelemetryResult {
    std::string channel_id;
    double generated_bits = 0.0;
    double transmitted_bits = 0.0;
    double stored_bits = 0.0;
    double dropped_bits = 0.0;
    double mean_latency_s = 0.0;
    double information_retained = 0.0;
    bool latency_compliant = false;
};

struct F1TelemetryArchitectureResult {
    bool feasible = false;
    double total_generated_bits = 0.0;
    double total_transmitted_bits = 0.0;
    double peak_storage_bits = 0.0;
    double weighted_information_retained = 0.0;
    std::vector<F1ChannelTelemetryResult> channels;
    std::string evidence_sha256;
};

class F1TelemetryArchitectureTwin {
public:
    [[nodiscard]] F1TelemetryArchitectureResult simulate(
        const std::vector<F1DAQChannel>& channels,
        const F1TelemetryLink& link,
        double duration_s,
        double scheduling_step_s = 0.01) const;
};

// -----------------------------------------------------------------------------
// Predictive safety-car, red-flag and incident-probability engine.
// -----------------------------------------------------------------------------
struct F1IncidentSectorState {
    int sector = 0;
    double car_density = 0.0;
    double overtaking_intensity = 0.0;
    double barrier_proximity = 0.0;
    double runoff_quality = 1.0;
    double wetness = 0.0;
    double visibility = 1.0;
    double debris = 0.0;
    double recovery_difficulty = 0.0;
    void validate() const;
};

struct F1IncidentCarRisk {
    std::string car_id;
    double aggression = 0.5;
    double reliability_risk = 0.01;
    double damage = 0.0;
    double tyre_risk = 0.0;
    int sector = 0;
    void validate() const;
};

struct F1NeutralizationPrediction {
    double local_yellow_probability = 0.0;
    double virtual_safety_car_probability = 0.0;
    double safety_car_probability = 0.0;
    double red_flag_probability = 0.0;
    double no_incident_probability = 1.0;
    double expected_start_s = 0.0;
    double expected_duration_s = 0.0;
    std::map<int,double> sector_incident_probability;
    std::string most_likely_trigger;
    std::string evidence_sha256;
};

class F1IncidentProbabilityEngine {
public:
    [[nodiscard]] F1NeutralizationPrediction predict(
        const std::vector<F1IncidentSectorState>& sectors,
        const std::vector<F1IncidentCarRisk>& cars,
        double horizon_s) const;
};

// -----------------------------------------------------------------------------
// Microsector driver coaching and performance attribution.
// -----------------------------------------------------------------------------
struct F1MicrosectorSample {
    double distance_m = 0.0;
    double speed_m_s = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    double steering_rad = 0.0;
    int gear = 1;
    double ers_power_w = 0.0;
    double tyre_grip = 1.0;
    double fuel_mass_kg = 0.0;
    double wind_m_s = 0.0;
    double traffic_loss_s = 0.0;
    void validate() const;
};

struct F1CoachingLap {
    std::string id;
    std::vector<F1MicrosectorSample> samples;
    double lap_time_s = 0.0;
    double track_grip = 1.0;
    double track_temperature_c = 30.0;
    void validate() const;
};

struct F1MicrosectorAttribution {
    double start_distance_m = 0.0;
    double end_distance_m = 0.0;
    double total_time_delta_s = 0.0;
    double braking_delta_s = 0.0;
    double corner_speed_delta_s = 0.0;
    double throttle_delta_s = 0.0;
    double line_delta_s = 0.0;
    double gear_delta_s = 0.0;
    double ers_delta_s = 0.0;
    double car_condition_delta_s = 0.0;
    double traffic_weather_delta_s = 0.0;
    double unexplained_delta_s = 0.0;
    double confidence = 0.0;
    std::string recommendation;
};

struct F1DriverCoachingResult {
    double normalized_lap_delta_s = 0.0;
    double driver_attributable_delta_s = 0.0;
    double car_environment_delta_s = 0.0;
    std::vector<F1MicrosectorAttribution> microsectors;
    std::vector<std::string> priorities;
    std::string evidence_sha256;
};

class F1DriverCoachingEngine {
public:
    [[nodiscard]] F1DriverCoachingResult analyze(const F1CoachingLap& driver,
                                                  const F1CoachingLap& reference,
                                                  double microsector_length_m = 100.0) const;
};

} // namespace aesim::advanced

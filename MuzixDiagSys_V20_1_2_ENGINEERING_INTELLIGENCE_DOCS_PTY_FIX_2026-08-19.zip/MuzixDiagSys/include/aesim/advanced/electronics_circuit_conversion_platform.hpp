#pragma once

#include <complex>
#include <cstdint>
#include <cstddef>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

struct AnalogFrontEndConfig {
    double gain = 1.0;
    double offset_voltage_v = 0.0;
    double input_bias_current_a = 0.0;
    double input_resistance_ohm = 1e9;
    double bandwidth_hz = 1e6;
    double slew_rate_v_per_s = 1e6;
    double output_min_v = 0.0;
    double output_max_v = 5.0;
    double input_noise_density_v_per_sqrt_hz = 10e-9;
    double common_mode_rejection_db = 100.0;
    double power_supply_rejection_db = 90.0;
};

struct AnalogFrontEndInput {
    double differential_input_v = 0.0;
    double common_mode_input_v = 0.0;
    double supply_ripple_v = 0.0;
    double source_resistance_ohm = 0.0;
    double temperature_k = 298.15;
};

struct AnalogFrontEndReport {
    double ideal_output_v = 0.0;
    double output_v = 0.0;
    double rms_noise_v = 0.0;
    double settling_error_v = 0.0;
    bool clipped = false;
    bool slew_limited = false;
};

class AnalogMixedSignalLaboratory {
public:
    explicit AnalogMixedSignalLaboratory(AnalogFrontEndConfig config = {});
    void reset(double output_v = 0.0);
    [[nodiscard]] AnalogFrontEndReport advance(const AnalogFrontEndInput& input, double dt_s);
private:
    AnalogFrontEndConfig config_;
    double output_v_ = 0.0;
};

struct AdcConfig {
    unsigned bits = 12;
    double reference_low_v = 0.0;
    double reference_high_v = 5.0;
    double integral_nonlinearity_lsb = 0.0;
    double differential_nonlinearity_lsb = 0.0;
    double aperture_jitter_s = 0.0;
    double rms_input_noise_v = 0.0;
    double offset_lsb = 0.0;
    double gain_error_fraction = 0.0;
};

struct AdcSample {
    std::uint32_t code = 0;
    double reconstructed_voltage_v = 0.0;
    double quantization_error_v = 0.0;
    double signal_to_noise_and_distortion_db = 0.0;
    double effective_number_of_bits = 0.0;
    bool saturated = false;
};

struct DacConfig {
    unsigned bits = 12;
    double reference_low_v = 0.0;
    double reference_high_v = 5.0;
    double settling_time_s = 10e-6;
    double slew_rate_v_per_s = 1e6;
    double glitch_impulse_v_s = 0.0;
    double integral_nonlinearity_lsb = 0.0;
};

struct DacSample {
    double target_voltage_v = 0.0;
    double output_voltage_v = 0.0;
    double settling_error_v = 0.0;
    double glitch_voltage_v = 0.0;
    bool settled = false;
};

class DataConverterLaboratory {
public:
    explicit DataConverterLaboratory(DacConfig dac_config = {});
    [[nodiscard]] AdcSample sample_adc(const AdcConfig& config, double input_voltage_v,
                                       double input_slope_v_per_s = 0.0,
                                       std::uint64_t deterministic_sample_index = 0) const;
    [[nodiscard]] DacSample advance_dac(std::uint32_t code, double dt_s);
    void reset_dac(double voltage_v = 0.0);
private:
    DacConfig dac_config_;
    double dac_output_v_ = 0.0;
    std::uint32_t prior_dac_code_ = 0;
};

struct PcbTransmissionLine {
    std::string id;
    double characteristic_impedance_ohm = 100.0;
    double propagation_delay_s = 1e-9;
    double attenuation_db = 0.1;
    double coupling_coefficient = 0.0;
    double load_impedance_ohm = 100.0;
    double source_impedance_ohm = 50.0;
};

struct SignalIntegrityReport {
    std::map<std::string, double> insertion_loss_db;
    std::map<std::string, double> return_loss_db;
    std::map<std::string, double> near_end_crosstalk_db;
    double eye_height_v = 0.0;
    double eye_width_s = 0.0;
    double deterministic_jitter_s = 0.0;
    double estimated_ber = 0.0;
    double tdr_impedance_min_ohm = 0.0;
    double tdr_impedance_max_ohm = 0.0;
};

struct PdnElement {
    std::string id;
    double capacitance_f = 0.0;
    double inductance_h = 0.0;
    double resistance_ohm = 0.0;
};

struct PowerIntegrityReport {
    std::vector<double> frequency_hz;
    std::vector<double> impedance_ohm;
    double peak_impedance_ohm = 0.0;
    double peak_frequency_hz = 0.0;
    double transient_droop_v = 0.0;
    bool target_impedance_met = false;
};

class PcbSignalPowerIntegrityPlatform {
public:
    void add_line(PcbTransmissionLine line);
    void add_pdn_element(PdnElement element);
    [[nodiscard]] SignalIntegrityReport analyze_channel(double bit_rate_bps, double signal_swing_v,
                                                        double random_jitter_rms_s,
                                                        std::size_t aggressor_count = 1) const;
    [[nodiscard]] PowerIntegrityReport analyze_pdn(double frequency_start_hz,
                                                   double frequency_stop_hz,
                                                   std::size_t points,
                                                   double target_impedance_ohm,
                                                   double load_step_a,
                                                   double regulator_response_s) const;
private:
    std::vector<PcbTransmissionLine> lines_;
    std::vector<PdnElement> pdn_;
};

enum class EcadFormat { AutoDetect, SpiceNetlist, KicadSExpression, CsvConnectivity };
struct EcadComponent { std::string reference; std::string value; std::string footprint; std::map<std::string, std::string> attributes; };
struct EcadNet { std::string name; std::vector<std::string> pins; };
struct EcadDesign {
    std::vector<EcadComponent> components;
    std::vector<EcadNet> nets;
    std::vector<std::string> warnings;
    std::string canonical_digest;
};
class EcadImporter {
public:
    [[nodiscard]] EcadDesign parse(const std::string& text, EcadFormat format = EcadFormat::AutoDetect) const;
    [[nodiscard]] EcadDesign parse_file(const std::string& path, EcadFormat format = EcadFormat::AutoDetect) const;
};

struct GroundBondPath {
    std::string id;
    std::string from;
    std::string to;
    double dc_resistance_ohm = 0.001;
    double inductance_h = 10e-9;
    double shield_transfer_impedance_ohm_per_m = 0.01;
    double shield_length_m = 1.0;
};
struct GroundingShieldingReport {
    std::map<std::string, double> node_potential_v;
    std::map<std::string, double> path_current_a;
    double maximum_ground_offset_v = 0.0;
    double common_mode_emission_dbuv = 0.0;
    double shielding_effectiveness_db = 0.0;
    std::string recommended_bond;
};
class GroundingShieldingOptimizer {
public:
    void add_path(GroundBondPath path);
    [[nodiscard]] GroundingShieldingReport analyze(const std::map<std::string, double>& injected_current_a,
                                                   double frequency_hz,
                                                   double incident_field_v_per_m) const;
private:
    std::vector<GroundBondPath> paths_;
};

enum class PowerSemiconductorType { SiliconMosfet, SiliconCarbideMosfet, GalliumNitrideHemt, Igbt };
struct PowerSemiconductorConfig {
    PowerSemiconductorType type = PowerSemiconductorType::SiliconCarbideMosfet;
    double voltage_rating_v = 1200.0;
    double current_rating_a = 200.0;
    double on_resistance_ohm = 0.01;
    double saturation_voltage_v = 1.8;
    double gate_charge_c = 300e-9;
    double output_capacitance_f = 1e-9;
    double reverse_recovery_charge_c = 100e-9;
    double thermal_resistance_k_per_w = 0.2;
    double maximum_junction_temperature_k = 448.15;
    double avalanche_energy_rating_j = 1.0;
};
struct SemiconductorOperatingPoint {
    double bus_voltage_v = 400.0;
    double current_a = 100.0;
    double switching_frequency_hz = 10000.0;
    double duty_cycle = 0.5;
    double gate_voltage_v = 15.0;
    double gate_resistance_ohm = 5.0;
    double junction_temperature_k = 373.15;
    double dead_time_s = 200e-9;
};
struct SemiconductorLossReport {
    double conduction_loss_w = 0.0;
    double turn_on_loss_w = 0.0;
    double turn_off_loss_w = 0.0;
    double reverse_recovery_loss_w = 0.0;
    double gate_drive_loss_w = 0.0;
    double total_loss_w = 0.0;
    double predicted_junction_temperature_k = 0.0;
    double voltage_overshoot_v = 0.0;
    double current_overshoot_a = 0.0;
    double safe_operating_area_margin = 0.0;
};
class PowerSemiconductorModel {
public:
    explicit PowerSemiconductorModel(PowerSemiconductorConfig config = {});
    [[nodiscard]] SemiconductorLossReport evaluate(const SemiconductorOperatingPoint& point,
                                                   double coolant_temperature_k,
                                                   double stray_inductance_h) const;
private: PowerSemiconductorConfig config_;
};

struct GateDriverConfig {
    double source_resistance_ohm = 5.0;
    double sink_resistance_ohm = 2.0;
    double positive_gate_voltage_v = 15.0;
    double negative_gate_voltage_v = -3.0;
    double propagation_delay_s = 100e-9;
    double desaturation_threshold_v = 7.0;
    double undervoltage_lockout_v = 11.0;
    double common_mode_transient_immunity_v_per_s = 100e9;
    double miller_clamp_resistance_ohm = 0.5;
};
struct GateDriverReport {
    double turn_on_time_s = 0.0;
    double turn_off_time_s = 0.0;
    double gate_peak_current_a = 0.0;
    double false_turn_on_probability = 0.0;
    double dead_time_s = 0.0;
    bool desaturation_trip = false;
    bool undervoltage_lockout = false;
    bool soft_shutdown = false;
};
class GateDriverLaboratory {
public:
    explicit GateDriverLaboratory(GateDriverConfig config = {});
    [[nodiscard]] GateDriverReport evaluate(double gate_charge_c, double driver_supply_v,
                                            double switch_vce_v, double dv_dt_v_per_s,
                                            double requested_dead_time_s) const;
private: GateDriverConfig config_;
};

struct DoublePulseRequest {
    PowerSemiconductorConfig device;
    double dc_bus_voltage_v = 400.0;
    double load_inductance_h = 200e-6;
    double first_pulse_s = 20e-6;
    double off_time_s = 5e-6;
    double second_pulse_s = 5e-6;
    double gate_resistance_ohm = 5.0;
    double stray_inductance_h = 20e-9;
    double coolant_temperature_k = 298.15;
};
struct DoublePulseReport {
    double peak_current_a = 0.0;
    double peak_voltage_v = 0.0;
    double turn_on_energy_j = 0.0;
    double turn_off_energy_j = 0.0;
    double reverse_recovery_energy_j = 0.0;
    double avalanche_energy_j = 0.0;
    double junction_temperature_rise_k = 0.0;
    bool passed = false;
};
class DoublePulseQualificationLaboratory {
public: [[nodiscard]] DoublePulseReport run(const DoublePulseRequest& request) const;
};

enum class ChargerTopology { InterleavedBoostPfcLlc, TotemPolePfcCllc, ViennaDualActiveBridge };
struct OnboardChargerConfig {
    ChargerTopology topology = ChargerTopology::TotemPolePfcCllc;
    double rated_power_w = 11000.0;
    double switching_frequency_hz = 100000.0;
    double transformer_turns_ratio = 1.0;
    double pfc_inductance_h = 300e-6;
    double dc_link_capacitance_f = 1000e-6;
    double thermal_resistance_k_per_w = 0.3;
};
struct PowerConversionReport {
    double input_power_w = 0.0;
    double output_power_w = 0.0;
    double efficiency = 0.0;
    double input_power_factor = 0.0;
    double current_thd = 0.0;
    double common_mode_leakage_a = 0.0;
    double semiconductor_loss_w = 0.0;
    double magnetics_loss_w = 0.0;
    double junction_temperature_k = 0.0;
    bool derated = false;
};
class OnboardChargerLaboratory {
public:
    explicit OnboardChargerLaboratory(OnboardChargerConfig config = {});
    [[nodiscard]] PowerConversionReport evaluate(double ac_rms_voltage_v, double dc_output_voltage_v,
                                                 double requested_power_w, double coolant_temperature_k,
                                                 bool bidirectional) const;
private: OnboardChargerConfig config_;
};

struct IsolatedDcDcConfig {
    double rated_power_w = 3000.0;
    double turns_ratio = 8.0;
    double leakage_inductance_h = 1e-6;
    double switching_frequency_hz = 100000.0;
    double synchronous_resistance_ohm = 0.01;
    double core_loss_coefficient = 1e-13;
};
class IsolatedDcDcLaboratory {
public:
    explicit IsolatedDcDcLaboratory(IsolatedDcDcConfig config = {});
    [[nodiscard]] PowerConversionReport evaluate(double input_voltage_v, double output_voltage_v,
                                                 double requested_power_w, double phase_shift_rad,
                                                 double coolant_temperature_k) const;
private: IsolatedDcDcConfig config_;
};

struct WirelessChargingConfig {
    double primary_inductance_h = 200e-6;
    double secondary_inductance_h = 200e-6;
    double coupling_at_alignment = 0.25;
    double operating_frequency_hz = 85000.0;
    double primary_resistance_ohm = 0.1;
    double secondary_resistance_ohm = 0.1;
    double compensation_capacitance_f = 20e-9;
    double maximum_stray_field_a_per_m = 21.0;
};
struct WirelessChargingReport {
    double mutual_inductance_h = 0.0;
    double delivered_power_w = 0.0;
    double efficiency = 0.0;
    double reflected_impedance_ohm = 0.0;
    double coil_current_a = 0.0;
    double stray_field_a_per_m = 0.0;
    bool foreign_object_risk = false;
    bool field_limit_met = false;
};
class WirelessChargingLaboratory {
public:
    explicit WirelessChargingLaboratory(WirelessChargingConfig config = {});
    [[nodiscard]] WirelessChargingReport evaluate(double inverter_voltage_rms_v,
                                                  double load_resistance_ohm,
                                                  double lateral_misalignment_m,
                                                  double vertical_gap_m,
                                                  double foreign_object_loss_w) const;
private: WirelessChargingConfig config_;
};

struct CanPhysicalConfig {
    double cable_impedance_ohm = 120.0;
    double termination_ohm = 60.0;
    double cable_length_m = 20.0;
    double propagation_speed_m_per_s = 2e8;
    double driver_differential_voltage_v = 2.0;
    double receiver_threshold_v = 0.9;
    double common_mode_choke_h = 100e-6;
};
struct PhysicalLayerReport {
    double eye_height_v = 0.0;
    double eye_width_s = 0.0;
    double reflection_coefficient = 0.0;
    double common_mode_voltage_v = 0.0;
    double estimated_ber = 0.0;
    double link_margin_db = 0.0;
    bool link_up = false;
};
class AutomotiveCommunicationPhysicalLayer {
public:
    [[nodiscard]] PhysicalLayerReport analyze_can(const CanPhysicalConfig& config,
                                                  double bit_rate_bps, double stub_length_m,
                                                  double ground_offset_v, double noise_rms_v) const;
    [[nodiscard]] PhysicalLayerReport analyze_lin(double battery_voltage_v, double pullup_ohm,
                                                  double bus_capacitance_f, double bit_rate_bps,
                                                  double ground_offset_v, double noise_rms_v) const;
    [[nodiscard]] PhysicalLayerReport analyze_ethernet_t1(double insertion_loss_db,
                                                          double return_loss_db,
                                                          double mode_conversion_db,
                                                          double pam_symbol_rate,
                                                          double transmitter_snr_db,
                                                          double impulse_noise_probability) const;
};

}  // namespace aesim::advanced

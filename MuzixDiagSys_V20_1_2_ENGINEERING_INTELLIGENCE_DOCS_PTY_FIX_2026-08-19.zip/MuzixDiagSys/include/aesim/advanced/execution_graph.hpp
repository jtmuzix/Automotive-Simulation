#pragma once

#include "aesim/electrification/electrification.hpp"
#include "aesim/professional/document.hpp"

#include <cstddef>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class GraphOperation { Copy, Fill, Affine, ReduceSum };

struct ExecutionGraphNode {
    std::string id;
    std::vector<std::string> dependencies;
    std::string backend = "auto";
    GraphOperation operation = GraphOperation::Affine;
    std::string input_buffer;
    std::string output_buffer;
    std::size_t element_count = 0;
    float scale = 1.0F;
    float bias = 0.0F;
    float fill_value = 0.0F;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static ExecutionGraphNode from_document(const doc::Value& value);
};

struct ExecutionGraphNodeTrace {
    std::string id;
    std::string backend;
    std::string device;
    std::size_t layer = 0;
    double elapsed_ms = 0.0;
    std::string output_sha256;
    double scalar = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct ExecutionGraphResult {
    bool deterministic = true;
    std::vector<ExecutionGraphNodeTrace> trace;
    std::map<std::string, std::vector<float>> buffers;
    std::string graph_sha256;
    [[nodiscard]] doc::Value to_document(bool include_buffers = false) const;
};

class DeterministicExecutionGraph {
public:
    void set_buffer(const std::string& name, std::vector<float> values);
    [[nodiscard]] const std::vector<float>& buffer(const std::string& name) const;
    void add_node(ExecutionGraphNode node);
    void clear_nodes();
    void compile();
    [[nodiscard]] ExecutionGraphResult execute();
    [[nodiscard]] doc::Value definition() const;
    void load_definition(const doc::Value& value);

private:
    std::map<std::string, std::vector<float>> buffers_;
    std::map<std::string, ExecutionGraphNode> nodes_;
    std::vector<std::vector<std::string>> layers_;
    bool compiled_ = false;
    aesim::electrification::HeterogeneousCompute compute_;
};

} // namespace aesim::advanced

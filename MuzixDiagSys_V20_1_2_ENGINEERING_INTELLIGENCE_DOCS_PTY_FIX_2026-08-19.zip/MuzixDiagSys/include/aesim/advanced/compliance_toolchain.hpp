#pragma once

#include "aesim/professional/document.hpp"

#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class ComplianceVerdict { Satisfied, Partial, Unsatisfied, NotApplicable, Stale };

struct ComplianceClause {
    std::string id;
    std::string framework;
    std::string title;
    std::string applicability_expression;
    std::set<std::string> required_evidence_types;
    std::set<std::string> accepted_methods;
    std::size_t minimum_independent_reviews = 0;
    bool physical_confirmation_required = false;
    double maximum_evidence_age_days = 0.0;
};

struct CertificationEvidence {
    std::string id;
    std::string type;
    std::string method;
    std::string artifact_sha256;
    std::string tool_id;
    std::string configuration_sha256;
    std::string created_utc;
    std::set<std::string> satisfies_clauses;
    std::set<std::string> reviewers;
    bool independent_review = false;
    bool physical_evidence = false;
    bool approved = false;
    std::map<std::string, std::string> trace_links;
    [[nodiscard]] doc::Value to_document() const;
};

struct ClauseAssessment {
    std::string clause_id;
    ComplianceVerdict verdict = ComplianceVerdict::Unsatisfied;
    std::vector<std::string> evidence_ids;
    std::vector<std::string> deficiencies;
    [[nodiscard]] doc::Value to_document() const;
};

struct ComplianceAssessment {
    std::vector<ClauseAssessment> clauses;
    std::map<std::string, std::size_t> counts;
    std::vector<std::string> stale_evidence;
    std::vector<std::string> physical_confirmation_required;
    bool release_ready = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ComplianceEvidenceEngine {
public:
    void set_context(std::map<std::string, std::string> context);
    void add_clause(ComplianceClause clause);
    void add_evidence(CertificationEvidence evidence);
    void revoke_evidence(const std::string& evidence_id, const std::string& reason);
    [[nodiscard]] ComplianceAssessment assess(const std::string& evaluation_utc) const;
    [[nodiscard]] std::vector<std::string> impacted_clauses(
        const std::set<std::string>& changed_trace_targets) const;
    [[nodiscard]] doc::Value audit_package(const std::string& evaluation_utc) const;

private:
    std::map<std::string, std::string> context_;
    std::map<std::string, ComplianceClause> clauses_;
    std::map<std::string, CertificationEvidence> evidence_;
    std::map<std::string, std::string> revocations_;
};

struct QualificationVector {
    std::string id;
    doc::Value input;
    doc::Value expected;
    double numeric_tolerance = 0.0;
};

struct ToolQualificationRecord {
    std::string tool_id;
    std::string version;
    std::string intended_use;
    std::string source_sha256;
    std::string binary_sha256;
    std::set<std::string> qualified_platforms;
    std::vector<std::string> limitations;
    std::vector<QualificationVector> vectors;
    [[nodiscard]] doc::Value to_document() const;
};

struct ToolQualificationResult {
    std::string tool_id;
    bool hashes_valid = false;
    std::size_t vectors_passed = 0;
    std::size_t vectors_failed = 0;
    std::vector<std::string> diagnostics;
    bool qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ToolQualificationEngine {
public:
    using Executor = std::function<doc::Value(const doc::Value&)>;
    [[nodiscard]] ToolQualificationResult qualify(
        const ToolQualificationRecord& record,
        const std::string& source_path,
        const std::string& binary_path,
        const std::string& platform,
        const Executor& executor) const;
    [[nodiscard]] static bool equivalent(const doc::Value& actual,
                                         const doc::Value& expected,
                                         double numeric_tolerance,
                                         std::string& diagnostic);
};

struct TrustedArtifact {
    std::string path;
    std::string role;
    std::string sha256;
    std::uint64_t size_bytes = 0;
};

struct TrustedComputationManifest {
    std::string build_id;
    std::string compiler_identity;
    std::string platform_identity;
    std::vector<std::string> command_line;
    std::map<std::string, std::string> environment;
    std::vector<TrustedArtifact> inputs;
    std::vector<TrustedArtifact> outputs;
    std::string previous_manifest_sha256;
    std::string manifest_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class TrustedComputationChain {
public:
    [[nodiscard]] static TrustedArtifact inspect(const std::string& path, const std::string& role);
    [[nodiscard]] static TrustedComputationManifest create(
        std::string build_id,
        std::string compiler_identity,
        std::string platform_identity,
        std::vector<std::string> command_line,
        std::map<std::string, std::string> environment,
        std::vector<TrustedArtifact> inputs,
        std::vector<TrustedArtifact> outputs,
        std::string previous_manifest_sha256 = {});
    [[nodiscard]] static bool verify(const TrustedComputationManifest& manifest,
                                     std::string& diagnostic);
};

} // namespace aesim::advanced

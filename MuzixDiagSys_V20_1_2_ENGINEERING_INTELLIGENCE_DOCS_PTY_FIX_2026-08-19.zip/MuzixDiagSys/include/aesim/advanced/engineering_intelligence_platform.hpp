#pragma once

#include "aesim/advanced/assured_engineering_operations_platform.hpp"
#include "aesim/advanced/electrical_battery_architecture.hpp"
#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced::intelligence {

// -----------------------------------------------------------------------------
// Shared engineering dependency graph used by consequence and causal analysis.
// -----------------------------------------------------------------------------

enum class EngineeringDependencyKind {
    Physical,
    Software,
    Signal,
    Calibration,
    Network,
    Power,
    Thermal,
    Requirement,
    Human,
    Manufacturing
};

struct EngineeringDependencyNode {
    std::string id;
    std::string domain;
    std::string quantity;
    std::string unit;
    double baseline_value = 0.0;
    double criticality = 1.0;
    std::map<std::string, std::string> metadata;
};

struct EngineeringDependencyEdge {
    std::string id;
    std::string from;
    std::string to;
    EngineeringDependencyKind kind = EngineeringDependencyKind::Physical;
    double local_gain = 1.0;
    double delay_s = 0.0;
    double confidence = 1.0;
    std::string rationale;
};

struct EngineeringGraphValidation {
    bool valid = false;
    bool acyclic = false;
    std::vector<std::string> diagnostics;
    std::string graph_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EngineeringDependencyGraph {
public:
    void clear();
    void add_node(EngineeringDependencyNode node);
    void add_edge(EngineeringDependencyEdge edge);
    [[nodiscard]] EngineeringGraphValidation validate() const;
    [[nodiscard]] std::vector<std::string> downstream(const std::string& node_id,
                                                      std::size_t maximum_depth = 64) const;
    [[nodiscard]] std::vector<std::string> upstream(const std::string& node_id,
                                                    std::size_t maximum_depth = 64) const;
    [[nodiscard]] const std::map<std::string, EngineeringDependencyNode>& nodes() const noexcept { return nodes_; }
    [[nodiscard]] const std::vector<EngineeringDependencyEdge>& edges() const noexcept { return edges_; }
    [[nodiscard]] doc::Value to_document() const;

private:
    std::map<std::string, EngineeringDependencyNode> nodes_;
    std::vector<EngineeringDependencyEdge> edges_;
};

// -----------------------------------------------------------------------------
// 1. Whole-Vehicle Consequence Engine
// -----------------------------------------------------------------------------

struct EngineeringChange {
    std::string node_id;
    double delta = 0.0;
    bool relative = false;
};

struct ConsequenceImpact {
    std::string node_id;
    std::string domain;
    double baseline_value = 0.0;
    double absolute_delta = 0.0;
    double relative_delta = 0.0;
    double confidence = 0.0;
    double accumulated_delay_s = 0.0;
    std::size_t depth = 0;
    std::vector<std::string> causal_path;
    [[nodiscard]] doc::Value to_document() const;
};

struct ConsequenceAnalysisOptions {
    std::size_t maximum_depth = 16;
    std::size_t maximum_visits_per_node = 4;
    double minimum_effect_magnitude = 1.0e-12;
    double minimum_confidence = 1.0e-6;
};

struct ConsequenceAnalysisResult {
    std::vector<ConsequenceImpact> impacts;
    std::map<std::string, double> domain_absolute_effect;
    std::vector<std::string> diagnostics;
    bool truncated = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class WholeVehicleConsequenceEngine {
public:
    explicit WholeVehicleConsequenceEngine(EngineeringDependencyGraph graph = {});
    void set_graph(EngineeringDependencyGraph graph);
    [[nodiscard]] const EngineeringDependencyGraph& graph() const noexcept { return graph_; }
    [[nodiscard]] ConsequenceAnalysisResult analyze(
        const std::vector<EngineeringChange>& changes,
        const ConsequenceAnalysisOptions& options = {}) const;

private:
    EngineeringDependencyGraph graph_;
};

// -----------------------------------------------------------------------------
// 3. Vehicle Software Service-Graph Simulator
// -----------------------------------------------------------------------------

struct VehicleServiceDefinition {
    std::string id;
    std::string host;
    double execution_time_ms = 0.0;
    double memory_mb = 0.0;
    double maximum_end_to_end_latency_ms = 1.0e9;
    double restart_time_ms = 0.0;
    std::size_t queue_capacity = 1024;
    unsigned priority = 0;
};

struct VehicleServiceLink {
    std::string id;
    std::string from_service;
    std::string to_service;
    double propagation_latency_ms = 0.0;
    double bandwidth_mbps = 1000.0;
    double fixed_overhead_ms = 0.0;
};

enum class VehicleServiceFaultKind { Crash, Recover, Throttle, ClearThrottle, Partition, HealPartition };

struct VehicleServiceFault {
    double time_s = 0.0;
    VehicleServiceFaultKind kind = VehicleServiceFaultKind::Crash;
    std::string target_id;
    double factor = 1.0;
};

struct VehicleServiceRequest {
    std::string id;
    double release_time_s = 0.0;
    std::string source_service;
    std::string target_service;
    double payload_kb = 0.0;
};

struct VehicleServiceRequestResult {
    std::string id;
    bool completed = false;
    double completion_time_s = 0.0;
    double latency_ms = 0.0;
    std::vector<std::string> service_path;
    std::string failure_reason;
    [[nodiscard]] doc::Value to_document() const;
};

struct VehicleServiceSimulationResult {
    std::vector<VehicleServiceRequestResult> requests;
    std::map<std::string, double> service_busy_fraction;
    std::map<std::string, std::size_t> service_completed_requests;
    std::map<std::string, std::size_t> service_dropped_requests;
    std::size_t completed = 0;
    std::size_t failed = 0;
    std::size_t deadline_misses = 0;
    double maximum_latency_ms = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class VehicleSoftwareServiceGraphSimulator {
public:
    void clear();
    void add_service(VehicleServiceDefinition service);
    void add_link(VehicleServiceLink link);
    void add_fault(VehicleServiceFault fault);
    [[nodiscard]] VehicleServiceSimulationResult simulate(
        std::vector<VehicleServiceRequest> requests) const;
    [[nodiscard]] doc::Value topology_document() const;

private:
    std::map<std::string, VehicleServiceDefinition> services_;
    std::vector<VehicleServiceLink> links_;
    std::vector<VehicleServiceFault> faults_;
};

// -----------------------------------------------------------------------------
// 4. End-to-End Timebase Laboratory
// -----------------------------------------------------------------------------

struct VehicleClockDefinition {
    std::string id;
    double initial_offset_s = 0.0;
    double drift_ppm = 0.0;
    double quantization_s = 0.0;
    double jitter_standard_deviation_s = 0.0;
};

struct ClockSynchronizationObservation {
    std::string clock_id;
    double local_timestamp_s = 0.0;
    double reference_timestamp_s = 0.0;
    double forward_path_delay_s = 0.0;
    double reverse_path_delay_s = 0.0;
    double weight = 1.0;
    double object_speed_m_s = 0.0;
};

struct ClockEstimate {
    std::string clock_id;
    double correction_scale = 1.0;
    double correction_offset_s = 0.0;
    double estimated_drift_ppm = 0.0;
    double rms_error_s = 0.0;
    double maximum_error_s = 0.0;
    double maximum_spatial_error_m = 0.0;
    std::size_t observations = 0;
    [[nodiscard]] double correct(double local_timestamp_s) const noexcept;
    [[nodiscard]] doc::Value to_document() const;
};

struct TimebaseLaboratoryResult {
    std::map<std::string, ClockEstimate> estimates;
    double worst_rms_error_s = 0.0;
    double worst_absolute_error_s = 0.0;
    double worst_spatial_registration_error_m = 0.0;
    std::vector<std::string> diagnostics;
    bool synchronized = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EndToEndTimebaseLaboratory {
public:
    [[nodiscard]] std::vector<ClockSynchronizationObservation> synthesize_observations(
        const std::vector<VehicleClockDefinition>& clocks,
        const std::vector<double>& reference_times_s,
        std::uint64_t seed,
        double object_speed_m_s = 0.0) const;
    [[nodiscard]] TimebaseLaboratoryResult estimate(
        const std::vector<ClockSynchronizationObservation>& observations,
        double synchronization_tolerance_s = 1.0e-3) const;
};

// -----------------------------------------------------------------------------
// 6. Parameter Identifiability & Sloppiness Laboratory
// -----------------------------------------------------------------------------

struct ParameterIdentifiabilityProblem {
    std::vector<std::string> parameter_names;
    std::vector<double> nominal_parameters;
    std::vector<double> parameter_scales;
    std::vector<double> observation_standard_deviations;
    std::function<std::vector<double>(const std::vector<double>&)> model;
};

struct ParameterSloppinessResult {
    std::size_t parameter_count = 0;
    std::size_t observation_count = 0;
    std::size_t numerical_rank = 0;
    bool identifiable = false;
    double condition_number = 0.0;
    double sloppiness_ratio = 0.0;
    bool condition_number_unbounded = false;
    bool sloppiness_unbounded = false;
    std::vector<double> singular_values;
    std::vector<double> normalized_information_eigenvalues;
    std::vector<std::vector<double>> parameter_correlation;
    std::vector<std::string> weak_parameters;
    std::vector<std::string> strongly_correlated_parameter_pairs;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ParameterIdentifiabilitySloppinessLaboratory {
public:
    [[nodiscard]] ParameterSloppinessResult analyze(
        const ParameterIdentifiabilityProblem& problem,
        double singular_value_tolerance = 1.0e-8,
        double maximum_condition_number = 1.0e8) const;
    [[nodiscard]] ParameterSloppinessResult analyze_linearized(
        const std::vector<std::string>& parameter_names,
        const std::vector<std::vector<double>>& sensitivity_matrix,
        const std::vector<double>& observation_standard_deviations = {},
        double singular_value_tolerance = 1.0e-8,
        double maximum_condition_number = 1.0e8) const;
};

// -----------------------------------------------------------------------------
// 7. Signal-Lineage / Calibration Provenance
// -----------------------------------------------------------------------------

enum class SignalProvenanceKind { Sensor, Signal, Transform, Calibration, Software, Network, Estimator, Controller, Actuator };

struct SignalProvenanceNode {
    std::string id;
    SignalProvenanceKind kind = SignalProvenanceKind::Signal;
    std::string version;
    std::string unit;
    std::string artifact_sha256;
    std::map<std::string, std::string> metadata;
};

struct SignalProvenanceEdge {
    std::string id;
    std::string from;
    std::string to;
    std::string operation;
    double scale = 1.0;
    double offset = 0.0;
    double delay_s = 0.0;
};

struct CalibrationProvenanceRecord {
    std::string calibration_id;
    std::string node_id;
    std::string version;
    std::string parameter_set_sha256;
    std::string source;
    std::string timestamp_utc;
    std::map<std::string, double> parameters;
};

struct SignalLineageReport {
    bool valid = false;
    std::vector<std::string> lineage;
    std::vector<CalibrationProvenanceRecord> calibrations;
    std::vector<std::string> diagnostics;
    double cumulative_scale = 1.0;
    double cumulative_delay_s = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SignalLineageCalibrationProvenance {
public:
    void clear();
    void add_node(SignalProvenanceNode node);
    void add_edge(SignalProvenanceEdge edge);
    void add_calibration(CalibrationProvenanceRecord record);
    [[nodiscard]] SignalLineageReport trace_upstream(const std::string& signal_id,
                                                     std::size_t maximum_depth = 64) const;
    [[nodiscard]] std::vector<std::string> impacted_signals(const std::string& source_id,
                                                            std::size_t maximum_depth = 64) const;
    [[nodiscard]] doc::Value to_document() const;

private:
    std::map<std::string, SignalProvenanceNode> nodes_;
    std::vector<SignalProvenanceEdge> edges_;
    std::vector<CalibrationProvenanceRecord> calibrations_;
};

// -----------------------------------------------------------------------------
// 8. Simulation Causality Microscope
// -----------------------------------------------------------------------------

struct CausalRootCandidate {
    std::string node_id;
    std::string domain;
    double score = 0.0;
    double path_gain = 0.0;
    double confidence = 0.0;
    double accumulated_delay_s = 0.0;
    std::vector<std::string> path;
    [[nodiscard]] doc::Value to_document() const;
};

struct CausalityMicroscopeResult {
    std::string observed_node;
    double observed_delta = 0.0;
    std::vector<CausalRootCandidate> ranked_causes;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SimulationCausalityMicroscope {
public:
    explicit SimulationCausalityMicroscope(EngineeringDependencyGraph graph = {});
    void set_graph(EngineeringDependencyGraph graph);
    [[nodiscard]] CausalityMicroscopeResult inspect(
        const std::string& observed_node,
        double observed_delta,
        std::size_t maximum_depth = 16,
        std::size_t maximum_candidates = 16) const;

private:
    EngineeringDependencyGraph graph_;
};

// -----------------------------------------------------------------------------
// 9. Computational Reproducibility Capsules
// -----------------------------------------------------------------------------

struct ReproducibilityArtifact {
    std::string path;
    std::string role;
    bool required = true;
};

struct ReproducibilityCapsuleSpecification {
    std::string name;
    std::string source_revision;
    std::string model_version;
    std::string command_line;
    std::uint64_t random_seed = 0;
    doc::Value configuration;
    std::vector<ReproducibilityArtifact> artifacts;
    std::vector<std::string> environment_whitelist;
    std::map<std::string, std::string> tags;
};

struct ReproducibilityCapsuleResult {
    std::string capsule_directory;
    std::string manifest_path;
    std::string manifest_sha256;
    std::string replay_script_path;
    std::size_t artifact_count = 0;
    bool verified = false;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

class ComputationalReproducibilityCapsuleBuilder {
public:
    [[nodiscard]] ReproducibilityCapsuleResult create(
        const ReproducibilityCapsuleSpecification& specification,
        const std::string& root_directory) const;
    [[nodiscard]] ReproducibilityCapsuleResult verify(const std::string& capsule_directory) const;
};

// -----------------------------------------------------------------------------
// 10. Cross-Layer Requirement Propagation
// -----------------------------------------------------------------------------

enum class RequirementBudgetDirection { Maximum, Minimum };

struct RequirementBudgetNode {
    std::string id;
    std::string statement;
    std::string metric;
    std::string unit;
    RequirementBudgetDirection direction = RequirementBudgetDirection::Maximum;
    double limit = 0.0;
    std::optional<double> measured_value;
    std::string layer;
};

struct RequirementAllocationEdge {
    std::string parent_requirement;
    std::string child_requirement;
    double allocated_budget = 0.0;
    double interface_overhead = 0.0;
};

struct RequirementEvaluation {
    std::string requirement_id;
    double effective_value = 0.0;
    double limit = 0.0;
    double committed_child_budget = 0.0;
    double margin = 0.0;
    bool passed = false;
    std::vector<std::string> violation_chain;
    [[nodiscard]] doc::Value to_document() const;
};

struct RequirementPropagationResult {
    bool passed = false;
    std::map<std::string, RequirementEvaluation> evaluations;
    std::vector<std::string> violated_requirements;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CrossLayerRequirementPropagationEngine {
public:
    void clear();
    void add_requirement(RequirementBudgetNode requirement);
    void add_allocation(RequirementAllocationEdge allocation);
    [[nodiscard]] RequirementPropagationResult evaluate() const;
    [[nodiscard]] RequirementPropagationResult evaluate_change(const std::string& requirement_id,
                                                                double measured_delta) const;
    [[nodiscard]] doc::Value to_document() const;

private:
    std::map<std::string, RequirementBudgetNode> requirements_;
    std::vector<RequirementAllocationEdge> allocations_;
};

// Unified command/API facade for all ten capabilities. The zonal E/E and
// cross-domain conservation domains call the canonical existing engines rather
// than carrying competing implementations.
class EngineeringIntelligencePlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

} // namespace aesim::advanced::intelligence

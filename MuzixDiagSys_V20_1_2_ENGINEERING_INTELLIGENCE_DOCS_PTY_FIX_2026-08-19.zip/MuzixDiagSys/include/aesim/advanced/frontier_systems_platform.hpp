#pragma once

#include "aesim/professional/document.hpp"

#include <complex>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace aesim::advanced::systems {

using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;

struct ScientificArray {
    std::string name;
    std::string unit;
    std::vector<std::size_t> shape;
    Vector values;
};

struct ScientificDataSet {
    std::string title;
    std::vector<ScientificArray> arrays;
};

struct MeshCell {
    std::string type;
    std::vector<std::size_t> nodes;
};

struct MeshField {
    std::string name;
    std::string association;
    std::string unit;
    std::size_t components = 1;
    Vector values;
};

struct MeshDataSet {
    std::vector<Vector> points;
    std::vector<MeshCell> cells;
    std::vector<MeshField> fields;
};

struct StateSpaceModel {
    Matrix A;
    Matrix B;
    Matrix C;
    Matrix D;
};

struct EventCameraConfig {
    double positive_threshold = 0.18;
    double negative_threshold = 0.18;
    double threshold_sigma = 0.0;
    double refractory_s = 0.0;
    double leak_rate_hz = 0.0;
    double background_rate_hz = 0.0;
    double max_events_per_second = 1.0e7;
    std::uint64_t seed = 1;
};

struct EventCameraEvent {
    double time_s = 0.0;
    std::size_t x = 0;
    std::size_t y = 0;
    int polarity = 1;
};

struct RadarTarget {
    double range_m = 0.0;
    double radial_velocity_mps = 0.0;
    double amplitude = 1.0;
    double azimuth_rad = 0.0;
    double phase_rad = 0.0;
};

struct PhysicsContract {
    std::string quantity;
    std::string unit;
    std::string frame;
    std::string time_basis;
    std::string causality;
    std::string conservation_group;
    std::string differentiability = "continuous";
    std::string interpolation = "linear";
    std::string extrapolation = "forbid";
    double minimum = -1.0e300;
    double maximum = 1.0e300;
    double uncertainty_sigma = 0.0;
    double numerical_abs_error = 0.0;
    double numerical_rel_error = 0.0;
};

class AutomotiveTsnProfileConformanceLaboratory {
public:
    [[nodiscard]] aesim::doc::Value analyze(const aesim::doc::Value& request) const;
};

class NativeScientificDataInterchangePlatform {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request,
                                            const std::string& working_directory = {}) const;
};

class MeshFieldInterchangeVisualizationPlatform {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request,
                                            const std::string& working_directory = {}) const;
};

class ExternalCaeSolverFederation {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request,
                                            const std::string& working_directory = {}) const;
};

class PortableHeterogeneousKernelRuntime {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request) const;
};

class GpuDirectPgasCommunicationRuntime {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request) const;
};

class CertifiedRobustControlSynthesisLaboratory {
public:
    [[nodiscard]] aesim::doc::Value synthesize(const aesim::doc::Value& request) const;
};

class SafetyCriticalMpcEstimationPlatform {
public:
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request) const;
};

class CompilerNativeAutomaticDifferentiationRuntime {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value differentiate(const aesim::doc::Value& request,
                                                   const std::string& working_directory = {}) const;
};

class EventCameraNeuromorphicVisionPlatform {
public:
    [[nodiscard]] aesim::doc::Value simulate(const aesim::doc::Value& request) const;
};

class RawRadarRfAdcSignalChainLaboratory {
public:
    [[nodiscard]] aesim::doc::Value simulate(const aesim::doc::Value& request) const;
};

class SemanticPhysicsContractSystem {
public:
    [[nodiscard]] aesim::doc::Value execute(const aesim::doc::Value& request) const;
};

class FrontierSystemsPlatform {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value execute(const std::string& domain,
                                            const aesim::doc::Value& request,
                                            const std::string& working_directory = {}) const;
    [[nodiscard]] aesim::doc::Value self_test(const std::string& working_directory) const;
};

} // namespace aesim::advanced::systems

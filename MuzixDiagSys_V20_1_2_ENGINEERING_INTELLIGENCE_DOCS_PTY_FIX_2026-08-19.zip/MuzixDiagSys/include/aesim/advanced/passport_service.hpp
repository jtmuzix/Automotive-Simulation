#pragma once

#include "aesim/advanced/cyber_security.hpp"
#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Vehicle/component digital-product-passport data space with signed manifests,
// custody history, role/purpose access, selective disclosure, and revocation.
// -----------------------------------------------------------------------------

struct PassportParticipant {
    std::string id;
    std::set<std::string> roles;
    std::set<std::string> purposes;
};

struct ProductPassport {
    std::string id;
    std::string product_type;
    std::string manufacturer;
    std::string model;
    std::string serial_number;
    std::string manufacture_date;
    std::map<std::string, std::string> identifiers;
    std::map<std::string, double> material_mass_kg;
    std::map<std::string, double> sustainability_metrics;
    std::map<std::string, std::string> software_versions;
    std::map<std::string, std::string> genealogy;
    std::vector<std::string> parent_passports;
    std::vector<std::string> evidence_sha256;
    std::uint64_t revision = 1;
    [[nodiscard]] doc::Value to_document() const;
};

struct PassportCustodyEvent {
    std::uint64_t sequence = 0;
    double timestamp_s = 0.0;
    std::string passport_id;
    std::string from_participant;
    std::string to_participant;
    std::string purpose;
    std::string previous_event_sha256;
    std::string event_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct SignedProductPassport {
    ProductPassport passport;
    std::string issuer_id;
    std::string signer_key_id;
    std::string claims_merkle_root;
    std::vector<std::uint8_t> signature;
    std::string credential_sha256;
    [[nodiscard]] doc::Value to_document(bool include_signature = true) const;
};

struct SelectiveDisclosureClaim {
    std::string path;
    doc::Value value;
    std::vector<std::string> merkle_proof;
    std::vector<bool> sibling_on_left;
    [[nodiscard]] doc::Value to_document() const;
};

struct SelectiveDisclosureCredential {
    std::string passport_id;
    std::string issuer_id;
    std::string claims_merkle_root;
    std::vector<SelectiveDisclosureClaim> claims;
    std::vector<std::uint8_t> issuer_signature;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class DigitalProductPassportDataSpace {
public:
    explicit DigitalProductPassportDataSpace(HardwareSecurityModule& hsm);
    void register_participant(PassportParticipant participant);
    [[nodiscard]] SignedProductPassport issue(
        ProductPassport passport,
        const std::string& issuer_id,
        const std::string& signer_key_id);
    [[nodiscard]] bool verify(const SignedProductPassport& credential,
                              std::string& diagnostic) const;
    void transfer(const std::string& passport_id,
                  const std::string& from_participant,
                  const std::string& to_participant,
                  const std::string& purpose,
                  double timestamp_s);
    void revoke(const std::string& passport_id, const std::string& reason);
    [[nodiscard]] SelectiveDisclosureCredential disclose(
        const std::string& passport_id,
        const std::string& requester_id,
        const std::string& purpose,
        const std::vector<std::string>& claim_paths) const;
    [[nodiscard]] bool verify_disclosure(const SelectiveDisclosureCredential& credential,
                                         std::string& diagnostic) const;
    [[nodiscard]] doc::Value status() const;

private:
    HardwareSecurityModule& hsm_;
    std::map<std::string, PassportParticipant> participants_;
    std::map<std::string, SignedProductPassport> passports_;
    std::vector<PassportCustodyEvent> custody_;
    std::map<std::string, std::string> revocations_;
};

// -----------------------------------------------------------------------------
// Service, repair, remanufacturing, and autonomous diagnostic-planning twin.
// -----------------------------------------------------------------------------

struct DiagnosticHypothesis {
    std::string id;
    double prior_probability = 0.0;
    double safety_severity = 0.0;
    std::map<std::string, double> symptom_likelihood;
};

struct DiagnosticTestDefinition {
    std::string id;
    double cost = 0.0;
    double duration_h = 0.0;
    std::map<std::string, double> positive_probability_by_hypothesis;
};

struct RepairOption {
    std::string id;
    std::set<std::string> addresses_hypotheses;
    double direct_cost = 0.0;
    double duration_h = 0.0;
    double success_probability = 1.0;
    double embodied_carbon_kg = 0.0;
    bool remanufactured = false;
    bool remote_capable = false;
    double remanufacturing_yield = 1.0;
    double recovered_material_fraction = 0.0;
};

struct DiagnosticBelief {
    std::map<std::string, double> posterior_probability;
    double entropy_bits = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct DiagnosticTestRecommendation {
    std::string test_id;
    double expected_information_gain_bits = 0.0;
    double expected_cost = 0.0;
    double expected_duration_h = 0.0;
    double utility = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct RepairCounterfactual {
    std::string repair_id;
    double fault_resolution_probability = 0.0;
    double expected_total_cost = 0.0;
    double expected_downtime_h = 0.0;
    double residual_safety_risk = 0.0;
    double circularity_credit_kg = 0.0;
    double carbon_kg = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct ServicePlan {
    DiagnosticBelief belief;
    std::vector<DiagnosticTestRecommendation> ranked_tests;
    std::vector<RepairCounterfactual> ranked_repairs;
    std::string recommended_test;
    std::string recommended_repair;
    bool remote_repair_possible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ServiceRemanufacturingDigitalTwin {
public:
    void set_hypotheses(std::vector<DiagnosticHypothesis> hypotheses);
    void set_tests(std::vector<DiagnosticTestDefinition> tests);
    void set_repairs(std::vector<RepairOption> repairs);
    [[nodiscard]] DiagnosticBelief infer(
        const std::map<std::string, bool>& observed_symptoms,
        const std::map<std::string, bool>& completed_tests = {}) const;
    [[nodiscard]] ServicePlan plan(
        const std::map<std::string, bool>& observed_symptoms,
        const std::map<std::string, bool>& completed_tests,
        double downtime_cost_per_h,
        double unresolved_risk_cost,
        double information_value_per_bit = 100.0) const;
    [[nodiscard]] DiagnosticBelief apply_repair(
        const DiagnosticBelief& belief,
        const std::string& repair_id,
        bool repair_succeeded) const;

private:
    std::map<std::string, DiagnosticHypothesis> hypotheses_;
    std::map<std::string, DiagnosticTestDefinition> tests_;
    std::map<std::string, RepairOption> repairs_;
};

} // namespace aesim::advanced

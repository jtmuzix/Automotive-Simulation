#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::indyassure {

class IndyCarRegulationDigitalThread {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarDynamicCompliance {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarNextGenerationCertification {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarProspectiveManufacturerProgram {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarTimingObservationFusion {
public:
    [[nodiscard]] doc::Value fuse(const doc::Value& request,
                                  const std::string& working_directory = {}) const;
};

class IndyCarOfficiatingPolicyLab {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarContactDamageRaceability {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarCrashSaferFiniteElementTwin {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarFireRescueHazards {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarDebrisRecovery {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarCompositeManufacturing {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarFleetReliability {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarTestDesignCalibration {
public:
    [[nodiscard]] doc::Value optimize(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarTireMaterialDigitalThread {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarEngineeringAssurancePlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::indyassure

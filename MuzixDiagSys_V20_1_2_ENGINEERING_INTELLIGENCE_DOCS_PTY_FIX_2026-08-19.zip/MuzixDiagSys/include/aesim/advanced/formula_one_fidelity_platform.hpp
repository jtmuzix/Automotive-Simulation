#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// High-fidelity Formula One vehicle, tyre, telemetry, estimation, validation,
// uncertainty, and identifiability facilities. All quantities use SI units.

enum class F1FidelityWheel : std::size_t { FrontLeft = 0, FrontRight = 1, RearLeft = 2, RearRight = 3 };

struct F1FidelityVector3 {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

// -----------------------------------------------------------------------------
// Advanced transient tyre and wet-contact model.
// -----------------------------------------------------------------------------

struct F1TransientTyreConfiguration {
    double unloaded_radius_m = 0.355;
    double width_m = 0.305;
    double vertical_stiffness_n_m = 300000.0;
    double vertical_damping_n_s_m = 2500.0;
    double longitudinal_stiffness_n = 125000.0;
    double cornering_stiffness_n_rad = 155000.0;
    double camber_stiffness_n_rad = 18000.0;
    double nominal_load_n = 3600.0;
    double dry_peak_friction = 1.92;
    double dry_sliding_friction = 1.62;
    double load_sensitivity = 0.10;
    double pressure_sensitivity = 0.08;
    double optimal_pressure_pa = 145000.0;
    double longitudinal_relaxation_length_m = 0.30;
    double lateral_relaxation_length_m = 0.42;
    double pneumatic_trail_m = 0.045;
    double rolling_resistance_coefficient = 0.013;
    double tread_depth_m = 0.0030;
    double groove_void_fraction = 0.18;
    double water_drainage_coefficient_m_s = 0.34;
    double aquaplaning_speed_coefficient = 9.0;
    double surface_heat_capacity_j_k = 24000.0;
    double carcass_heat_capacity_j_k = 52000.0;
    double gas_heat_capacity_j_k = 9000.0;
    double surface_to_carcass_w_k = 640.0;
    double carcass_to_gas_w_k = 170.0;
    double surface_to_track_w_k = 460.0;
    double carcass_to_air_w_k = 95.0;
    double optimal_surface_temperature_k = 373.15;
    double temperature_window_k = 32.0;
    double wear_energy_scale_j = 1.45e8;
    double minimum_tread_depth_m = 0.00025;
    double inflation_pressure_pa = 135000.0;
    double gas_reference_temperature_k = 293.15;
    double wheel_inertia_kg_m2 = 1.30;

    void validate() const;
};

struct F1TransientTyreState {
    double effective_slip_ratio = 0.0;
    double effective_slip_angle_rad = 0.0;
    double surface_temperature_k = 343.15;
    double carcass_temperature_k = 338.15;
    double gas_temperature_k = 338.15;
    double pressure_pa = 155000.0;
    double tread_depth_m = 0.0030;
    double wear_fraction = 0.0;
    double accumulated_slip_energy_j = 0.0;
    double water_saturation = 0.0;
    double flat_spot_severity = 0.0;
    double angular_speed_rad_s = 0.0;
    double vertical_deflection_m = 0.012;
};

struct F1TransientTyreInput {
    double time_step_s = 0.001;
    double normal_load_n = 3500.0;
    double wheel_center_longitudinal_speed_m_s = 50.0;
    double wheel_center_lateral_speed_m_s = 0.0;
    double wheel_angular_speed_rad_s = 140.0;
    double camber_angle_rad = 0.0;
    double inflation_pressure_pa = 0.0; // zero selects the state pressure
    double track_temperature_k = 313.15;
    double ambient_temperature_k = 298.15;
    double water_film_depth_m = 0.0;
    double surface_rubber_fraction = 0.6;
    double surface_roughness_scale = 1.0;
    double brake_heat_input_w = 0.0;
    double applied_wheel_torque_nm = 0.0;
};

struct F1TransientTyreResult {
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double normal_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double rolling_resistance_force_n = 0.0;
    double instantaneous_slip_ratio = 0.0;
    double instantaneous_slip_angle_rad = 0.0;
    double effective_friction = 0.0;
    double dry_friction = 0.0;
    double wet_friction_scale = 1.0;
    double aquaplaning_fraction = 0.0;
    double contact_patch_length_m = 0.0;
    double contact_patch_area_m2 = 0.0;
    double generated_heat_w = 0.0;
    double drained_water_depth_m = 0.0;
    bool contact_lost = false;
    F1TransientTyreState state;
};

class F1AdvancedTransientTyreModel {
public:
    explicit F1AdvancedTransientTyreModel(F1TransientTyreConfiguration configuration = {});
    [[nodiscard]] const F1TransientTyreConfiguration& configuration() const noexcept;
    [[nodiscard]] F1TransientTyreResult step(const F1TransientTyreInput& input,
                                             const F1TransientTyreState& state) const;

private:
    F1TransientTyreConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Fully coupled full-car dynamics kernel.
// -----------------------------------------------------------------------------

struct F1CoupledCarConfiguration {
    double mass_kg = 798.0;
    double yaw_inertia_kg_m2 = 920.0;
    double pitch_inertia_kg_m2 = 1280.0;
    double roll_inertia_kg_m2 = 430.0;
    double wheelbase_m = 3.60;
    double front_track_m = 1.62;
    double rear_track_m = 1.60;
    double cg_to_front_axle_m = 1.78;
    double cg_height_m = 0.31;
    double nominal_ride_height_m = 0.045;
    double front_spring_rate_n_m = 260000.0;
    double rear_spring_rate_n_m = 235000.0;
    double front_damper_rate_n_s_m = 12500.0;
    double rear_damper_rate_n_s_m = 11200.0;
    double front_antiroll_rate_nm_rad = 72000.0;
    double rear_antiroll_rate_nm_rad = 58000.0;
    double heave_bump_stop_rate_n_m = 900000.0;
    double minimum_ride_height_m = 0.010;
    double frontal_area_m2 = 1.50;
    double drag_coefficient = 0.90;
    double lift_coefficient = -3.80;
    double aero_balance_front = 0.46;
    double aero_pitch_sensitivity_per_rad = 2.6;
    double aero_ride_height_sensitivity_per_m = 5.0;
    double maximum_drive_torque_nm = 980.0;
    double maximum_brake_torque_front_nm = 2500.0;
    double maximum_brake_torque_rear_nm = 1700.0;
    double final_drive_ratio = 9.2;
    double drivetrain_efficiency = 0.965;
    double rolling_radius_m = 0.335;
    double fuel_mass_kg = 110.0;
    double fuel_burn_rate_kg_j = 7.8e-9;
    double maximum_internal_step_s = 0.002;
    std::array<F1TransientTyreConfiguration, 4> tyres{};

    void validate() const;
};

struct F1CoupledCarEnvironment {
    double air_density_kg_m3 = 1.18;
    double gravity_m_s2 = 9.80665;
    double track_temperature_k = 313.15;
    double ambient_temperature_k = 298.15;
    double road_grade_rad = 0.0;
    double road_bank_rad = 0.0;
    F1FidelityVector3 wind_world_m_s{};
    std::array<double, 4> road_height_m{};
    std::array<double, 4> water_film_depth_m{};
    std::array<double, 4> surface_rubber_fraction{{0.65, 0.65, 0.65, 0.65}};
    std::array<double, 4> surface_roughness_scale{{1.0, 1.0, 1.0, 1.0}};

    void validate() const;
};

struct F1CoupledCarControl {
    double throttle = 0.0;
    double brake = 0.0;
    double steering_wheel_angle_rad = 0.0;
    double steering_ratio = 12.0;
    double brake_balance_front = 0.57;
    double differential_lock_fraction = 0.35;
    double active_aero_fraction = 0.0;
    double engine_braking_fraction = 0.10;

    void validate() const;
};

struct F1CoupledCarState {
    double time_s = 0.0;
    F1FidelityVector3 position_world_m{};
    F1FidelityVector3 velocity_body_m_s{};
    F1FidelityVector3 euler_angle_rad{};       // roll, pitch, yaw
    F1FidelityVector3 angular_velocity_rad_s{}; // roll, pitch, yaw rates
    F1FidelityVector3 acceleration_body_m_s2{};
    std::array<double, 4> suspension_compression_m{};
    std::array<double, 4> suspension_velocity_m_s{};
    std::array<F1TransientTyreState, 4> tyre_states{};
    double fuel_mass_kg = 110.0;
    double cumulative_fuel_energy_j = 0.0;
    double cumulative_tyre_dissipation_j = 0.0;
    double cumulative_aero_dissipation_j = 0.0;
};

struct F1CoupledCarStepResult {
    F1CoupledCarState state;
    std::array<F1TransientTyreResult, 4> tyre_results{};
    std::array<double, 4> wheel_normal_load_n{};
    double aerodynamic_drag_n = 0.0;
    double aerodynamic_downforce_n = 0.0;
    double total_longitudinal_force_n = 0.0;
    double total_lateral_force_n = 0.0;
    double yaw_moment_nm = 0.0;
    double roll_moment_nm = 0.0;
    double pitch_moment_nm = 0.0;
    double mechanical_energy_j = 0.0;
    double external_work_j = 0.0;
    double energy_residual_j = 0.0;
    bool finite = true;
};

class F1FullyCoupledCarDynamicsKernel {
public:
    explicit F1FullyCoupledCarDynamicsKernel(F1CoupledCarConfiguration configuration = {});
    [[nodiscard]] const F1CoupledCarConfiguration& configuration() const noexcept;
    [[nodiscard]] F1CoupledCarState make_initial_state(double forward_speed_m_s = 0.0) const;
    [[nodiscard]] F1CoupledCarStepResult step(double time_step_s,
                                               const F1CoupledCarControl& control,
                                               const F1CoupledCarEnvironment& environment,
                                               const F1CoupledCarState& state) const;

private:
    F1CoupledCarConfiguration configuration_;
    std::array<F1AdvancedTransientTyreModel, 4> tyre_models_;
};

// -----------------------------------------------------------------------------
// Sensor, DAQ, latency, and synchronization realism.
// -----------------------------------------------------------------------------

struct F1SensorChannelConfiguration {
    std::string id;
    double sample_rate_hz = 100.0;
    double scale_factor = 1.0;
    double static_bias = 0.0;
    double white_noise_standard_deviation = 0.0;
    double bias_random_walk_standard_deviation_per_sqrt_s = 0.0;
    double temperature_coefficient_per_k = 0.0;
    double reference_temperature_k = 293.15;
    double quantization_step = 0.0;
    double minimum_value = -1.0e12;
    double maximum_value = 1.0e12;
    double low_pass_cutoff_hz = 0.0;
    double latency_mean_s = 0.0;
    double latency_jitter_standard_deviation_s = 0.0;
    double dropout_probability = 0.0;
    double clock_offset_s = 0.0;
    double clock_drift_ppm = 0.0;
    std::uint64_t random_seed = 1;

    void validate() const;
};

struct F1SensorChannelState {
    double next_sample_true_time_s = 0.0;
    double bias_random_walk = 0.0;
    double filtered_value = 0.0;
    bool filter_initialized = false;
    std::uint64_t sequence = 0;
    std::uint64_t random_state = 1;
};

struct F1DaqPacket {
    std::string channel_id;
    std::uint64_t sequence = 0;
    double source_timestamp_s = 0.0;
    double true_sample_time_s = 0.0;
    double arrival_time_s = 0.0;
    double value = 0.0;
    bool saturated = false;
};

class F1SensorDaqPipeline {
public:
    F1SensorDaqPipeline() = default;
    explicit F1SensorDaqPipeline(std::vector<F1SensorChannelConfiguration> channels);
    void add_channel(F1SensorChannelConfiguration configuration);
    void reset(double true_time_s = 0.0);
    void sample_until(double true_time_s, const std::map<std::string, double>& physical_values,
                      double sensor_temperature_k = 293.15);
    [[nodiscard]] std::vector<F1DaqPacket> receive_until(double true_time_s);
    [[nodiscard]] std::size_t queued_packet_count() const noexcept;
    [[nodiscard]] const std::vector<F1SensorChannelConfiguration>& channels() const noexcept;

private:
    std::vector<F1SensorChannelConfiguration> channels_;
    std::vector<F1SensorChannelState> states_;
    std::deque<F1DaqPacket> queue_;
};

struct F1ClockSynchronizationObservation {
    double source_timestamp_s = 0.0;
    double reference_timestamp_s = 0.0;
    double weight = 1.0;
};

struct F1ClockSynchronizationResult {
    bool valid = false;
    double source_to_reference_scale = 1.0;
    double source_to_reference_offset_s = 0.0;
    double rms_residual_s = 0.0;
    double maximum_residual_s = 0.0;
    std::size_t observations_used = 0;

    [[nodiscard]] double correct(double source_timestamp_s) const;
};

class F1ClockSynchronizationEstimator {
public:
    [[nodiscard]] F1ClockSynchronizationResult estimate(
        const std::vector<F1ClockSynchronizationObservation>& observations) const;
};

// -----------------------------------------------------------------------------
// Telemetry-driven state and parameter estimation.
// -----------------------------------------------------------------------------

enum class F1TelemetryMeasurementType {
    LongitudinalSpeed,
    WheelSpeed,
    YawRate,
    LateralAcceleration,
    LongitudinalAcceleration,
    RollAngle,
    PitchAngle,
    FrontRideHeight,
    RearRideHeight
};

struct F1TelemetryMeasurement {
    F1TelemetryMeasurementType type = F1TelemetryMeasurementType::LongitudinalSpeed;
    double value = 0.0;
    double standard_deviation = 1.0;
    double timestamp_s = 0.0;
};

struct F1EstimatorProcessInput {
    double steering_angle_rad = 0.0;
    double drive_force_n = 0.0;
    double brake_force_n = 0.0;
    double aerodynamic_drag_n = 0.0;
    double aerodynamic_downforce_n = 0.0;
};

struct F1EstimatedVehicleState {
    double longitudinal_speed_m_s = 0.0;
    double lateral_speed_m_s = 0.0;
    double yaw_rate_rad_s = 0.0;
    double roll_angle_rad = 0.0;
    double pitch_angle_rad = 0.0;
    double longitudinal_accel_bias_m_s2 = 0.0;
    double lateral_accel_bias_m_s2 = 0.0;
    double yaw_rate_bias_rad_s = 0.0;
    double wheel_speed_scale = 1.0;
    double tyre_friction_scale = 1.0;
    double aerodynamic_scale = 1.0;
    double mass_scale = 1.0;
};

struct F1EstimatorConfiguration {
    double nominal_mass_kg = 798.0;
    double yaw_inertia_kg_m2 = 920.0;
    double wheelbase_m = 3.60;
    double cg_to_front_axle_m = 1.78;
    double front_cornering_stiffness_n_rad = 155000.0;
    double rear_cornering_stiffness_n_rad = 170000.0;
    double roll_time_constant_s = 0.18;
    double pitch_time_constant_s = 0.16;
    double cg_height_m = 0.31;
    double nominal_ride_height_m = 0.045;
    std::array<double, 12> process_noise_variance_per_s{{
        0.08, 0.12, 0.006, 0.0008, 0.0008, 0.00002,
        0.00002, 0.000002, 0.0000005, 0.00001, 0.00001, 0.000005}};
    double finite_difference_step = 1.0e-5;

    void validate() const;
};

struct F1EstimatorUpdateResult {
    F1EstimatedVehicleState estimate;
    std::array<double, 12> standard_deviation{};
    std::vector<double> normalized_innovations;
    std::size_t accepted_measurements = 0;
    std::size_t rejected_measurements = 0;
};

class F1TelemetryStateParameterEstimator {
public:
    explicit F1TelemetryStateParameterEstimator(F1EstimatorConfiguration configuration = {});
    void initialize(const F1EstimatedVehicleState& state,
                    const std::array<double, 12>& standard_deviation);
    void predict(double time_step_s, const F1EstimatorProcessInput& input);
    [[nodiscard]] F1EstimatorUpdateResult update(
        const std::vector<F1TelemetryMeasurement>& measurements,
        const F1EstimatorProcessInput& input);
    [[nodiscard]] F1EstimatorUpdateResult current() const;

private:
    F1EstimatorConfiguration configuration_;
    std::array<double, 12> state_{};
    std::array<std::array<double, 12>, 12> covariance_{};
    bool initialized_ = false;
};

// -----------------------------------------------------------------------------
// Validation, uncertainty quantification, and identifiability.
// -----------------------------------------------------------------------------

struct F1ValidationSeries {
    std::string channel;
    std::vector<double> reference;
    std::vector<double> prediction;
    std::vector<double> lower_prediction_interval;
    std::vector<double> upper_prediction_interval;
    double normalization_scale = 0.0;
    double rmse_limit = 0.0;
    double correlation_minimum = -1.0;
};

struct F1ValidationMetrics {
    std::string channel;
    std::size_t sample_count = 0;
    double mean_error = 0.0;
    double mean_absolute_error = 0.0;
    double root_mean_square_error = 0.0;
    double normalized_root_mean_square_error = 0.0;
    double maximum_absolute_error = 0.0;
    double correlation_coefficient = 0.0;
    double residual_lag_one_autocorrelation = 0.0;
    double prediction_interval_coverage = 0.0;
    bool interval_available = false;
    bool passed = false;
};

class F1ValidationFramework {
public:
    [[nodiscard]] F1ValidationMetrics evaluate(const F1ValidationSeries& series) const;
    [[nodiscard]] std::vector<F1ValidationMetrics> evaluate_all(
        const std::vector<F1ValidationSeries>& series) const;
};

enum class F1ProbabilityDistribution { Uniform, Normal, Triangular };

struct F1UncertainParameter {
    std::string name;
    F1ProbabilityDistribution distribution = F1ProbabilityDistribution::Uniform;
    double minimum = 0.0;
    double maximum = 1.0;
    double mean = 0.5;
    double standard_deviation = 0.1;
    double mode = 0.5;

    void validate() const;
};

struct F1UncertaintyConfiguration {
    std::size_t samples = 1024;
    double confidence_level = 0.95;
    std::uint64_t random_seed = 0x9e3779b97f4a7c15ULL;
    bool latin_hypercube = true;

    void validate() const;
};

struct F1UncertaintyResult {
    std::size_t samples = 0;
    double mean = 0.0;
    double standard_deviation = 0.0;
    double minimum = 0.0;
    double maximum = 0.0;
    double lower_confidence_bound = 0.0;
    double median = 0.0;
    double upper_confidence_bound = 0.0;
    std::map<std::string, double> pearson_sensitivity;
    std::map<std::string, double> standardized_regression_coefficient;
    std::vector<double> outputs;
};

class F1UncertaintyQuantificationFramework {
public:
    using ScalarModel = std::function<double(const std::vector<double>&)>;

    [[nodiscard]] F1UncertaintyResult propagate(
        const std::vector<F1UncertainParameter>& parameters,
        const ScalarModel& model,
        const F1UncertaintyConfiguration& configuration = {}) const;
};

struct F1IdentifiabilityConfiguration {
    double relative_step = 1.0e-4;
    double absolute_step = 1.0e-7;
    double singular_value_tolerance = 1.0e-8;
    double maximum_condition_number = 1.0e8;

    void validate() const;
};

struct F1IdentifiabilityResult {
    std::size_t parameter_count = 0;
    std::size_t observation_count = 0;
    std::size_t numerical_rank = 0;
    double condition_number = 0.0;
    bool identifiable = false;
    std::vector<double> singular_values;
    std::vector<std::vector<double>> normalized_sensitivity;
    std::vector<std::vector<double>> parameter_correlation;
    std::vector<std::string> weak_parameter_names;
};

class F1IdentifiabilityFramework {
public:
    using VectorModel = std::function<std::vector<double>(const std::vector<double>&)>;

    [[nodiscard]] F1IdentifiabilityResult analyze(
        const std::vector<std::string>& parameter_names,
        const std::vector<double>& nominal_parameters,
        const std::vector<double>& parameter_scales,
        const std::vector<double>& observation_standard_deviations,
        const VectorModel& model,
        const F1IdentifiabilityConfiguration& configuration = {}) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/advanced/formula_one_race_engineering.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Gearbox, differential, clutch, and launch-performance laboratory.
// -----------------------------------------------------------------------------

struct F1GearboxConfiguration {
    std::vector<double> gear_ratios{3.10, 2.40, 1.92, 1.58, 1.34, 1.16, 1.02, 0.90};
    double final_drive_ratio = 3.25;
    double driveline_efficiency = 0.975;
    double input_inertia_kg_m2 = 0.22;
    double output_inertia_kg_m2 = 0.35;
    double torsional_stiffness_nm_rad = 18000.0;
    double torsional_damping_nm_s_rad = 95.0;
    double nominal_shift_time_s = 0.035;
    double hydraulic_shift_time_constant_s = 0.012;
    double maximum_input_torque_nm = 620.0;
    double lubricant_thermal_capacity_j_k = 52000.0;
    double lubricant_cooling_w_k = 280.0;
    double ambient_temperature_k = 303.15;
    void validate() const;
};

struct F1DifferentialConfiguration {
    double preload_nm = 80.0;
    double power_lock_fraction = 0.55;
    double coast_lock_fraction = 0.30;
    double maximum_bias_ratio = 3.0;
    double response_time_s = 0.018;
    double thermal_capacity_j_k = 22000.0;
    double cooling_w_k = 170.0;
    void validate() const;
};

struct F1ClutchConfiguration {
    double effective_radius_m = 0.090;
    double clamp_force_n = 14500.0;
    double friction_coefficient_cold = 0.32;
    double friction_coefficient_hot = 0.24;
    double hot_temperature_k = 850.0;
    double thermal_capacity_j_k = 18000.0;
    double cooling_w_k = 90.0;
    double wear_energy_j_per_mm = 8.5e7;
    double maximum_wear_mm = 2.5;
    void validate() const;
};

struct F1DrivelineConfiguration {
    F1GearboxConfiguration gearbox;
    F1DifferentialConfiguration differential;
    F1ClutchConfiguration clutch;
    double rear_wheel_radius_m = 0.355;
    double vehicle_mass_kg = 798.0;
    double longitudinal_drag_coefficient = 0.95;
    double frontal_area_m2 = 1.50;
    double rolling_resistance_coefficient = 0.014;
    void validate() const;
};

struct F1DrivelineState {
    std::size_t gear = 1;
    std::size_t target_gear = 1;
    double shift_progress = 1.0;
    double gearbox_input_speed_rad_s = 0.0;
    double gearbox_output_speed_rad_s = 0.0;
    double torsional_twist_rad = 0.0;
    double differential_lock_fraction = 0.0;
    double clutch_engagement = 0.0;
    double clutch_temperature_k = 330.0;
    double clutch_wear_mm = 0.0;
    double gearbox_oil_temperature_k = 340.0;
    double differential_temperature_k = 335.0;
    double vehicle_speed_m_s = 0.0;
    double launch_distance_m = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1DrivelineInput {
    double time_step_s = 0.001;
    double engine_torque_nm = 0.0;
    double engine_speed_rad_s = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    std::optional<std::size_t> requested_gear;
    double clutch_command = 1.0;
    double left_wheel_speed_rad_s = 0.0;
    double right_wheel_speed_rad_s = 0.0;
    double left_normal_load_n = 3500.0;
    double right_normal_load_n = 3500.0;
    double left_friction = 1.8;
    double right_friction = 1.8;
    double differential_command = 0.5;
    bool anti_stall_enabled = true;
};

struct F1DrivelineStepResult {
    F1DrivelineState state;
    double transmitted_input_torque_nm = 0.0;
    double left_wheel_torque_nm = 0.0;
    double right_wheel_torque_nm = 0.0;
    double clutch_slip_power_kw = 0.0;
    double shift_torque_interruption_fraction = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    bool shift_active = false;
    bool wheelspin = false;
    bool anti_stall_active = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1LaunchControlCandidate {
    double launch_rpm = 8500.0;
    double initial_clutch_command = 0.25;
    double clutch_ramp_s = 1.2;
    double differential_command = 0.55;
    double throttle_ramp_s = 0.35;
};

struct F1LaunchPerformance {
    F1LaunchControlCandidate candidate;
    double time_to_100_kph_s = 0.0;
    double time_to_200_kph_s = 0.0;
    double distance_at_100_kph_m = 0.0;
    double peak_wheel_slip = 0.0;
    double clutch_energy_kj = 0.0;
    double final_clutch_temperature_k = 0.0;
    double objective = 0.0;
    bool feasible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1DrivelineLaboratory {
public:
    explicit F1DrivelineLaboratory(F1DrivelineConfiguration configuration = {});
    [[nodiscard]] const F1DrivelineConfiguration& configuration() const noexcept;
    [[nodiscard]] F1DrivelineStepResult step(const F1DrivelineInput& input,
                                             const F1DrivelineState& previous) const;
    [[nodiscard]] F1LaunchPerformance simulate_launch(const F1LaunchControlCandidate& candidate,
                                                      double track_friction = 1.8,
                                                      double duration_s = 8.0) const;
    [[nodiscard]] F1LaunchPerformance optimize_launch(
        const std::vector<F1LaunchControlCandidate>& candidates,
        double track_friction = 1.8,
        double duration_s = 8.0) const;
private:
    F1DrivelineConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Wind-tunnel, CFD, and track-correlation laboratory.
// -----------------------------------------------------------------------------

enum class F1AeroDataSource { Cfd, WindTunnel, Track };

struct F1AeroOperatingPoint {
    std::string id;
    F1AeroDataSource source = F1AeroDataSource::Cfd;
    double speed_m_s = 60.0;
    double yaw_rad = 0.0;
    double steer_rad = 0.0;
    double front_ride_height_m = 0.030;
    double rear_ride_height_m = 0.050;
    double front_flap = 0.0;
    double rear_flap = 0.0;
    double air_density_kg_m3 = 1.18;
    double lift_coefficient = -3.5;
    double drag_coefficient = 0.85;
    double front_balance = 0.45;
    std::map<std::string, double> pressure_coefficients;
    double measurement_sigma = 0.01;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1WindTunnelConfiguration {
    double model_scale = 0.60;
    double blockage_fraction = 0.025;
    double support_drag_coefficient = 0.015;
    double moving_ground_speed_ratio = 1.0;
    double boundary_layer_displacement_m = 0.002;
    double force_balance_sigma = 0.003;
    void validate() const;
};

struct F1AeroCorrelationParameters {
    double lift_scale = 1.0;
    double lift_bias = 0.0;
    double drag_scale = 1.0;
    double drag_bias = 0.0;
    double balance_scale = 1.0;
    double balance_bias = 0.0;
    double ride_height_sensitivity = 0.0;
    double yaw_sensitivity = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1AeroCorrelationReport {
    F1AeroCorrelationParameters parameters;
    double lift_rmse = 0.0;
    double drag_rmse = 0.0;
    double balance_rmse = 0.0;
    double normalized_chi_square = 0.0;
    double correlation_score = 0.0;
    std::size_t cfd_points = 0;
    std::size_t tunnel_points = 0;
    std::size_t track_points = 0;
    std::vector<std::string> outlier_ids;
    std::map<std::string, double> pressure_rmse;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1AeroCorrelationLaboratory {
public:
    explicit F1AeroCorrelationLaboratory(F1WindTunnelConfiguration tunnel = {});
    void add(F1AeroOperatingPoint point);
    void clear();
    [[nodiscard]] std::size_t size() const noexcept;
    [[nodiscard]] F1AeroOperatingPoint correct_wind_tunnel(const F1AeroOperatingPoint& raw) const;
    [[nodiscard]] F1AeroCorrelationReport correlate(double ridge = 1.0e-8,
                                                    double outlier_sigma = 3.5) const;
    [[nodiscard]] F1AeroOperatingPoint predict_track(const F1AeroOperatingPoint& cfd,
                                                     const F1AeroCorrelationParameters& parameters) const;
private:
    F1WindTunnelConfiguration tunnel_;
    std::vector<F1AeroOperatingPoint> points_;
};

// -----------------------------------------------------------------------------
// Driver model, biomechanics, and driver-in-the-loop simulation.
// -----------------------------------------------------------------------------

struct F1DriverProfile {
    double preview_time_s = 0.55;
    double steering_gain = 1.8;
    double steering_rate_limit_rad_s = 5.0;
    double brake_gain = 1.0;
    double throttle_gain = 1.0;
    double trail_brake_fraction = 0.35;
    double oversteer_tolerance_rad_s = 0.45;
    double understeer_tolerance_rad = 0.06;
    double reaction_delay_s = 0.16;
    double risk_tolerance = 0.65;
    double tyre_management = 0.80;
    double wet_skill = 0.80;
    double consistency = 0.97;
    double neck_strength_n = 750.0;
    double heat_tolerance_k = 312.0;
    void validate() const;
};

struct F1DriverState {
    double steering_command_rad = 0.0;
    double throttle_command = 0.0;
    double brake_command = 0.0;
    double cognitive_load = 0.0;
    double fatigue = 0.0;
    double core_temperature_k = 310.0;
    double hydration_fraction = 1.0;
    double neck_load_n = 0.0;
    double reaction_time_s = 0.16;
    double accumulated_error = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1DriverObservation {
    double time_step_s = 0.01;
    double vehicle_speed_m_s = 0.0;
    double lateral_error_m = 0.0;
    double heading_error_rad = 0.0;
    double target_curvature_m_inv = 0.0;
    double yaw_rate_rad_s = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    double tyre_grip_fraction = 1.0;
    double water_film_mm = 0.0;
    double cockpit_temperature_k = 308.0;
    double steering_torque_nm = 0.0;
    double pedal_force_n = 0.0;
    double visual_occlusion = 0.0;
    double simulator_latency_s = 0.0;
    bool radio_message_active = false;
};

struct F1DriverControlResult {
    F1DriverState state;
    double steering_command_rad = 0.0;
    double throttle_command = 0.0;
    double brake_command = 0.0;
    double target_speed_m_s = 0.0;
    double mistake_probability = 0.0;
    bool performance_limited = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1DriverSessionReport {
    double duration_s = 0.0;
    double mean_lateral_error_m = 0.0;
    double rms_lateral_error_m = 0.0;
    double maximum_fatigue = 0.0;
    double maximum_core_temperature_k = 0.0;
    double maximum_neck_load_n = 0.0;
    double mean_reaction_time_s = 0.0;
    double control_smoothness = 0.0;
    std::size_t performance_limited_steps = 0;
    F1DriverState final_state;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1DriverInLoopLaboratory {
public:
    explicit F1DriverInLoopLaboratory(F1DriverProfile profile = {}, std::uint64_t seed = 1);
    [[nodiscard]] F1DriverControlResult step(const F1DriverObservation& observation,
                                             const F1DriverState& previous) const;
    [[nodiscard]] F1DriverSessionReport run_session(const std::vector<F1DriverObservation>& observations,
                                                    F1DriverState initial = {}) const;
private:
    F1DriverProfile profile_;
    std::uint64_t seed_;
};

// -----------------------------------------------------------------------------
// Cooling, packaging, mass, and ballast co-optimization.
// -----------------------------------------------------------------------------

enum class F1ThermalComponentKind { Ice, Turbo, ChargeAir, EnergyStore, Inverter, Gearbox, Hydraulics, Driver };

struct F1ThermalComponent {
    std::string id;
    F1ThermalComponentKind kind = F1ThermalComponentKind::Ice;
    double heat_generation_kw = 0.0;
    double thermal_capacity_j_k = 100000.0;
    double maximum_temperature_k = 400.0;
    double initial_temperature_k = 320.0;
    double mass_kg = 10.0;
    Vector3 position_m{};
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CoolingCircuit {
    std::string id;
    std::vector<std::string> component_ids;
    double radiator_area_m2 = 0.20;
    double mass_flow_kg_s = 1.5;
    double coolant_heat_capacity_j_kg_k = 3700.0;
    double radiator_effectiveness = 0.75;
    double pump_power_kw = 0.8;
    double inlet_drag_coefficient = 0.02;
    Vector3 radiator_position_m{};
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PackageItem {
    std::string id;
    double mass_kg = 0.0;
    Vector3 position_m{};
    Vector3 half_extent_m{0.1, 0.1, 0.1};
    bool movable = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CoolingPackageCandidate {
    std::map<std::string, double> radiator_area_scale;
    std::map<std::string, double> mass_flow_scale;
    std::map<std::string, Vector3> movable_positions_m;
    double ballast_mass_kg = 0.0;
    Vector3 ballast_position_m{};
};

struct F1ThermalDutyPoint {
    double duration_s = 1.0;
    double ambient_temperature_k = 303.15;
    double vehicle_speed_m_s = 60.0;
    double heat_scale = 1.0;
};

struct F1CoolingPackageEvaluation {
    F1CoolingPackageCandidate candidate;
    std::map<std::string, double> peak_component_temperature_k;
    double total_mass_kg = 0.0;
    Vector3 center_of_gravity_m{};
    double yaw_inertia_kg_m2 = 0.0;
    double cooling_drag_coefficient = 0.0;
    double pump_energy_mj = 0.0;
    double packaging_overlap_m3 = 0.0;
    double objective = 0.0;
    bool thermally_feasible = false;
    bool packaging_feasible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1CoolingPackagingOptimizer {
public:
    void add_component(F1ThermalComponent component);
    void add_circuit(F1CoolingCircuit circuit);
    void add_package_item(F1PackageItem item);
    [[nodiscard]] F1CoolingPackageEvaluation evaluate(const F1CoolingPackageCandidate& candidate,
                                                      const std::vector<F1ThermalDutyPoint>& duty) const;
    [[nodiscard]] F1CoolingPackageEvaluation optimize(
        const std::vector<F1CoolingPackageCandidate>& candidates,
        const std::vector<F1ThermalDutyPoint>& duty) const;
private:
    std::map<std::string, F1ThermalComponent> components_;
    std::vector<F1CoolingCircuit> circuits_;
    std::map<std::string, F1PackageItem> items_;
};

// -----------------------------------------------------------------------------
// Cylinder-resolved sustainable-fuel combustion and turbo physics.
// -----------------------------------------------------------------------------

struct F1SustainableFuelProperties {
    std::string name = "sustainable-reference";
    double lower_heating_value_j_kg = 43.0e6;
    double stoichiometric_air_fuel_ratio = 14.4;
    double research_octane_number = 102.0;
    double motor_octane_number = 90.0;
    double laminar_flame_speed_m_s = 0.42;
    double latent_heat_j_kg = 350000.0;
    double density_kg_m3 = 745.0;
    double renewable_carbon_fraction = 1.0;
    void validate() const;
};

struct F1CylinderConfiguration {
    double bore_m = 0.080;
    double stroke_m = 0.053;
    double connecting_rod_m = 0.105;
    double compression_ratio = 18.0;
    double wall_temperature_k = 520.0;
    double wiebe_a = 5.0;
    double wiebe_m = 2.0;
    double combustion_duration_deg = 48.0;
    double ignition_angle_deg_btdc = 20.0;
    void validate() const;
};

struct F1TurboConfiguration {
    double shaft_inertia_kg_m2 = 1.8e-4;
    double compressor_efficiency = 0.74;
    double turbine_efficiency = 0.72;
    double mechanical_efficiency = 0.96;
    double maximum_speed_rad_s = 14500.0;
    double wastegate_time_constant_s = 0.05;
    double compressor_flow_coefficient = 0.11;
    double turbine_flow_coefficient = 0.13;
    void validate() const;
};

struct F1CombustionConfiguration {
    std::size_t cylinders = 6;
    F1CylinderConfiguration cylinder;
    F1TurboConfiguration turbo;
    F1SustainableFuelProperties fuel;
    double displacement_m3 = 1.6e-3;
    double intake_volume_m3 = 0.004;
    double exhaust_volume_m3 = 0.005;
    double intake_temperature_k = 315.0;
    double exhaust_temperature_k = 1050.0;
    double friction_mean_effective_pressure_pa = 2.2e5;
    double maximum_fuel_flow_kg_s = 0.028;
    void validate() const;
};

struct F1CylinderState {
    double pressure_pa = 1.0e5;
    double temperature_k = 600.0;
    double trapped_mass_kg = 0.0005;
    double burned_fraction = 0.0;
    double knock_index = 0.0;
    double cumulative_work_j = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CombustionState {
    std::vector<F1CylinderState> cylinders;
    double crank_angle_deg = 0.0;
    double turbo_speed_rad_s = 4000.0;
    double intake_manifold_pressure_pa = 1.2e5;
    double exhaust_manifold_pressure_pa = 1.1e5;
    double intake_manifold_temperature_k = 315.0;
    double exhaust_manifold_temperature_k = 900.0;
    double wastegate_position = 0.5;
    double cumulative_fuel_kg = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CombustionInput {
    double time_step_s = 0.0001;
    double engine_speed_rpm = 10000.0;
    double throttle = 1.0;
    double fuel_command_kg_s = 0.02;
    double lambda = 1.0;
    double ignition_correction_deg = 0.0;
    double wastegate_command = 0.5;
    double ambient_pressure_pa = 101325.0;
    double ambient_temperature_k = 298.15;
};

struct F1CombustionStepResult {
    F1CombustionState state;
    std::vector<double> cylinder_torque_nm;
    double indicated_torque_nm = 0.0;
    double brake_torque_nm = 0.0;
    double brake_power_kw = 0.0;
    double fuel_flow_kg_s = 0.0;
    double brake_thermal_efficiency = 0.0;
    double compressor_pressure_ratio = 1.0;
    double compressor_power_kw = 0.0;
    double turbine_power_kw = 0.0;
    double knock_margin = 0.0;
    bool knock_limited = false;
    bool turbo_overspeed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1CylinderResolvedPowerUnit {
public:
    explicit F1CylinderResolvedPowerUnit(F1CombustionConfiguration configuration = {});
    [[nodiscard]] const F1CombustionConfiguration& configuration() const noexcept;
    [[nodiscard]] F1CombustionState initial_state() const;
    [[nodiscard]] F1CombustionStepResult step(const F1CombustionInput& input,
                                              const F1CombustionState& previous) const;
    [[nodiscard]] std::vector<F1CombustionStepResult> simulate_cycle(
        const F1CombustionInput& input,
        F1CombustionState initial,
        std::size_t steps) const;
private:
    F1CombustionConfiguration configuration_;
};

} // namespace aesim::advanced

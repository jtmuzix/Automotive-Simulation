#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class MeasurementDataType : std::uint8_t { Float64 = 1, Float32 = 2, Int64 = 3, UInt64 = 4, Int32 = 5, UInt32 = 6 };

struct MeasurementChannel {
    std::string name;
    std::string unit;
    MeasurementDataType data_type = MeasurementDataType::Float64;
    double factor = 1.0;
    double offset = 0.0;
    std::string comment;
};

struct MeasurementSeries {
    MeasurementChannel channel;
    std::vector<double> timestamps_s;
    std::vector<double> physical_values;
};

struct MeasurementFile {
    std::string author;
    std::string project;
    std::string start_time_utc;
    std::vector<MeasurementSeries> series;
    std::map<std::string, std::string> metadata;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_samples = true) const;
};

class Mdf4File {
public:
    static void write(const std::string& path, const MeasurementFile& file);
    [[nodiscard]] static MeasurementFile read(const std::string& path);
    [[nodiscard]] static bool verify(const std::string& path, std::string& diagnostic);
};

struct A2lObject {
    std::string kind;
    std::string name;
    std::string description;
    std::string data_type;
    std::uint64_t address = 0;
    std::string conversion;
    std::string unit;
    double lower_limit = 0.0;
    double upper_limit = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct A2lDatabase {
    std::string project_name;
    std::string module_name;
    std::map<std::string, A2lObject> objects;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

class A2lParser {
public:
    [[nodiscard]] A2lDatabase parse(const std::string& text) const;
    [[nodiscard]] std::string emit(const A2lDatabase& database) const;
};

class XcpMemoryImage {
public:
    explicit XcpMemoryImage(std::size_t size_bytes, std::size_t pages = 2);
    void connect();
    void disconnect();
    void set_page(std::size_t page);
    [[nodiscard]] std::size_t page() const noexcept;
    void download(std::uint64_t address, const std::vector<std::uint8_t>& bytes);
    [[nodiscard]] std::vector<std::uint8_t> upload(std::uint64_t address, std::size_t size) const;
    [[nodiscard]] bool connected() const noexcept;
    [[nodiscard]] doc::Value status() const;
private:
    bool connected_ = false;
    std::size_t page_ = 0;
    std::vector<std::vector<std::uint8_t>> pages_;
};

struct ClockAlignment {
    double offset_s = 0.0;
    double scale = 1.0;
    double drift_ppm = 0.0;
    double rms_residual_s = 0.0;
    double maximum_residual_s = 0.0;
    std::size_t inliers = 0;
    std::string evidence_sha256;
    [[nodiscard]] double map(double source_time_s) const noexcept;
    [[nodiscard]] doc::Value to_document() const;
};

class ClockAligner {
public:
    [[nodiscard]] ClockAlignment fit(const std::vector<double>& source_times_s,
                                     const std::vector<double>& reference_times_s,
                                     double outlier_threshold_s = 0.01,
                                     std::size_t iterations = 3) const;
};

struct DebugEvent {
    std::uint64_t sequence = 0;
    double time_s = 0.0;
    std::string category;
    std::string component;
    std::string message;
    std::map<std::string, double> state_delta;
    std::set<std::uint64_t> causal_predecessors;
    std::string event_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct DebugSnapshot {
    std::uint64_t sequence = 0;
    double time_s = 0.0;
    std::map<std::string, double> state;
    std::string state_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class TimeTravelDebugger {
public:
    void initialize(std::map<std::string, double> initial_state);
    std::uint64_t record(double time_s, std::string category, std::string component,
                         std::string message, std::map<std::string, double> delta,
                         std::set<std::uint64_t> predecessors = {});
    [[nodiscard]] DebugSnapshot current() const;
    [[nodiscard]] DebugSnapshot seek(std::uint64_t sequence) const;
    [[nodiscard]] DebugSnapshot reverse_step() const;
    [[nodiscard]] std::vector<DebugEvent> causal_slice(std::uint64_t sequence) const;
    [[nodiscard]] TimeTravelDebugger fork(std::uint64_t sequence) const;
    [[nodiscard]] std::optional<std::uint64_t> first_divergence(const TimeTravelDebugger& other,
                                                                double tolerance = 0.0) const;
    [[nodiscard]] doc::Value report() const;
private:
    std::map<std::string, double> initial_state_;
    std::vector<DebugEvent> events_;
};

struct RegressionArtifact {
    std::string id;
    std::string kind;
    std::string sha256;
    std::set<std::string> dependencies;
    std::set<std::string> validates;
};

struct NumericRegressionSeries {
    std::string id;
    std::vector<double> baseline;
    std::vector<double> candidate;
    double absolute_tolerance = 0.0;
    double relative_tolerance = 0.0;
};

struct RegressionImpactReport {
    std::set<std::string> changed_artifacts;
    std::set<std::string> impacted_artifacts;
    std::set<std::string> invalidated_evidence;
    std::set<std::string> required_tests;
    std::map<std::string, double> numeric_drift;
    std::vector<std::string> diagnostics;
    bool gate_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RegressionIntelligenceEngine {
public:
    void set_baseline(std::vector<RegressionArtifact> artifacts);
    [[nodiscard]] RegressionImpactReport analyze(
        const std::vector<RegressionArtifact>& candidate,
        const std::vector<NumericRegressionSeries>& numeric_series,
        const std::map<std::string, std::vector<bool>>& test_history = {}) const;
    [[nodiscard]] static double flakiness(const std::vector<bool>& outcomes);
private:
    std::map<std::string, RegressionArtifact> baseline_;
};

} // namespace aesim::advanced

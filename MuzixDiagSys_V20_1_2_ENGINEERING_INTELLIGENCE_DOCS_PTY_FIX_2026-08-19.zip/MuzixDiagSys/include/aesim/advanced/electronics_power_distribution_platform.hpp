#pragma once

#include <cstddef>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class ElectricalLoadModel { Resistive, ConstantPower, ConstantCurrent };

struct ElectricalNode {
    std::string id;
    double nominal_voltage_v = 12.0;
    double brownout_voltage_v = 9.0;
};

struct ElectricalBranch {
    std::string id;
    std::string from_node;
    std::string to_node;
    double resistance_ohm = 0.01;
    double inductance_h = 0.0;
    double thermal_capacity_j_per_k = 20.0;
    double thermal_resistance_k_per_w = 5.0;
    double max_temperature_k = 423.15;
};

struct ElectricalSource {
    std::string id;
    std::string node;
    double open_circuit_voltage_v = 12.6;
    double internal_resistance_ohm = 0.02;
    double maximum_current_a = 1000.0;
    bool enabled = true;
};

struct ElectricalLoad {
    std::string id;
    std::string node;
    ElectricalLoadModel model = ElectricalLoadModel::ConstantPower;
    double demand = 0.0;
    bool enabled = true;
    int priority = 0;
};

struct SmartFuseConfig {
    std::string id;
    std::string branch_id;
    double rated_current_a = 20.0;
    double instantaneous_trip_multiple = 6.0;
    double i2t_limit_a2s = 800.0;
    double reset_temperature_k = 333.15;
    bool automatic_reset = false;
};

struct SmartFuseState {
    bool closed = true;
    bool latched = false;
    double accumulated_i2t_a2s = 0.0;
    double junction_temperature_k = 298.15;
    std::size_t trip_count = 0;
};

struct PowerNetworkReport {
    bool converged = false;
    std::size_t iterations = 0;
    std::map<std::string, double> node_voltage_v;
    std::map<std::string, double> branch_current_a;
    std::map<std::string, double> branch_temperature_k;
    std::map<std::string, SmartFuseState> fuse_states;
    std::vector<std::string> brownout_nodes;
    std::vector<std::string> shed_loads;
    double source_power_w = 0.0;
    double delivered_power_w = 0.0;
    double resistive_loss_w = 0.0;
    double ground_offset_v = 0.0;
};

class LowVoltagePowerNetwork {
public:
    void clear();
    void add_node(ElectricalNode node);
    void add_branch(ElectricalBranch branch);
    void add_source(ElectricalSource source);
    void add_load(ElectricalLoad load);
    void add_smart_fuse(SmartFuseConfig fuse);
    void set_load_enabled(const std::string& id, bool enabled);
    void reset_fuse(const std::string& id);
    [[nodiscard]] PowerNetworkReport solve(double dt_s, double ambient_temperature_k = 298.15,
                                           std::size_t maximum_iterations = 80,
                                           double voltage_tolerance_v = 1e-7);

private:
    std::vector<ElectricalNode> nodes_;
    std::vector<ElectricalBranch> branches_;
    std::vector<ElectricalSource> sources_;
    std::vector<ElectricalLoad> loads_;
    std::vector<SmartFuseConfig> fuse_configs_;
    std::map<std::string, SmartFuseState> fuse_states_;
    std::map<std::string, double> branch_temperature_k_;
};

enum class VehiclePowerMode { Off, Transport, Accessory, Ignition, Crank, Run, PostRun, Standby, DeepSleep };
enum class WakeSource { Timer, Rtc, Can, Lin, Ethernet, Discrete, Keyless, Telematics, Diagnostic, Safety };

struct EcuPowerProfile {
    std::string id;
    double run_current_a = 1.0;
    double standby_current_a = 0.05;
    double sleep_current_a = 0.001;
    double startup_time_s = 0.05;
    double shutdown_delay_s = 1.0;
    double minimum_voltage_v = 7.0;
    std::vector<WakeSource> accepted_wake_sources;
    std::vector<std::string> wake_dependents;
};

struct EcuPowerState {
    bool awake = false;
    bool starting = false;
    bool shutdown_pending = false;
    double transition_time_s = 0.0;
    double current_a = 0.0;
    std::size_t wake_count = 0;
    std::string last_wake_reason;
};

struct WakeEvent {
    WakeSource source = WakeSource::Timer;
    std::optional<std::string> target_ecu;
    double duration_s = 0.1;
};

struct SleepWakeReport {
    VehiclePowerMode mode = VehiclePowerMode::Off;
    std::map<std::string, EcuPowerState> ecu_states;
    double total_current_a = 0.0;
    double settled_sleep_current_a = 0.0;
    double battery_time_to_no_start_h = 0.0;
    std::vector<std::string> unexpected_awake_ecus;
    std::vector<std::string> wake_causal_chain;
};

class SleepWakePowerManager {
public:
    void register_ecu(EcuPowerProfile profile);
    void set_mode(VehiclePowerMode mode);
    void request_wake(WakeEvent event);
    void request_sleep(const std::string& ecu_id);
    [[nodiscard]] SleepWakeReport advance(double dt_s, double supply_voltage_v,
                                          double battery_capacity_ah,
                                          double no_start_state_of_charge = 0.2);

private:
    VehiclePowerMode mode_ = VehiclePowerMode::Off;
    std::map<std::string, EcuPowerProfile> profiles_;
    std::map<std::string, EcuPowerState> states_;
    std::vector<WakeEvent> pending_wakes_;
};

struct PmicRailConfig {
    std::string id;
    double target_voltage_v = 5.0;
    double current_limit_a = 1.0;
    double efficiency = 0.9;
    double startup_delay_s = 0.001;
    double output_capacitance_f = 100e-6;
    std::vector<std::string> dependencies;
};

struct PmicRailState {
    double voltage_v = 0.0;
    double current_a = 0.0;
    bool enabled = false;
    bool power_good = false;
    bool current_limited = false;
};

struct PmicInput {
    double supply_voltage_v = 12.0;
    double ambient_temperature_k = 298.15;
    std::map<std::string, double> requested_current_a;
    std::map<std::string, bool> enable_request;
    bool watchdog_service = true;
};

struct PmicReport {
    std::map<std::string, PmicRailState> rails;
    bool undervoltage_lockout = false;
    bool thermal_shutdown = false;
    bool watchdog_reset = false;
    bool reset_asserted = false;
    double input_current_a = 0.0;
    double junction_temperature_k = 298.15;
    double dissipated_power_w = 0.0;
};

class PmicSystemBasisChip {
public:
    void configure(double uvlo_v, double overtemperature_k, double watchdog_window_s,
                   double thermal_resistance_k_per_w, double thermal_capacity_j_per_k);
    void add_rail(PmicRailConfig rail);
    void reset();
    [[nodiscard]] PmicReport advance(const PmicInput& input, double dt_s);

private:
    double uvlo_v_ = 5.5;
    double overtemperature_k_ = 423.15;
    double watchdog_window_s_ = 0.1;
    double thermal_resistance_k_per_w_ = 20.0;
    double thermal_capacity_j_per_k_ = 10.0;
    double junction_temperature_k_ = 298.15;
    double watchdog_elapsed_s_ = 0.0;
    std::map<std::string, PmicRailConfig> configs_;
    std::map<std::string, PmicRailState> states_;
    std::map<std::string, double> startup_elapsed_s_;
};

enum class HvDisconnectState { Open, NegativeClosed, Precharging, Ready, Energized, Fault, CrashIsolated };

struct HvDisconnectConfig {
    double pack_voltage_v = 400.0;
    double precharge_resistance_ohm = 50.0;
    double dc_link_capacitance_f = 0.002;
    double main_contactor_resistance_ohm = 0.0002;
    double precharge_completion_ratio = 0.95;
    double precharge_timeout_s = 3.0;
    double isolation_threshold_ohm_per_v = 500.0;
    double residual_safe_voltage_v = 60.0;
    double discharge_resistance_ohm = 1000.0;
};

struct HvDisconnectCommand {
    bool request_energize = false;
    bool request_shutdown = false;
    bool crash_event = false;
    bool service_disconnect_open = false;
    double isolation_resistance_ohm = 1e9;
    double load_current_a = 0.0;
    bool positive_welded = false;
    bool negative_welded = false;
    bool precharge_welded = false;
};

struct HvDisconnectReport {
    HvDisconnectState state = HvDisconnectState::Open;
    double dc_link_voltage_v = 0.0;
    double precharge_current_a = 0.0;
    double contactor_loss_w = 0.0;
    double interruption_arc_energy_j = 0.0;
    double precharge_elapsed_s = 0.0;
    bool positive_closed = false;
    bool negative_closed = false;
    bool precharge_closed = false;
    bool pyrofuse_fired = false;
    bool isolation_fault = false;
    bool weld_fault = false;
    bool safe_to_service = true;
    std::string fault_reason;
};

class HvPrechargeDisconnectUnit {
public:
    explicit HvPrechargeDisconnectUnit(HvDisconnectConfig config = {});
    void reset(double initial_dc_link_voltage_v = 0.0);
    [[nodiscard]] HvDisconnectReport advance(const HvDisconnectCommand& command, double dt_s);

private:
    HvDisconnectConfig config_;
    HvDisconnectReport state_;
};

}  // namespace aesim::advanced

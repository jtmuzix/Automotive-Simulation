#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// COVESA/Eclipse SDV service and workload runtime
// -----------------------------------------------------------------------------

struct VehicleSignalDefinition {
    std::string path;
    std::string type = "double";
    std::string unit = "1";
    bool writable = false;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
};

struct SdvServiceManifest {
    std::string id;
    std::string version = "1.0.0";
    std::vector<std::string> dependencies;
    std::set<std::string> provides;
    std::set<std::string> consumes;
    std::size_t cpu_millicores = 100;
    std::size_t memory_mb = 64;
    std::size_t gpu_millipercent = 0;
    std::uint64_t period_us = 10'000;
    std::uint64_t deadline_us = 10'000;
    unsigned criticality = 0;
    bool restartable = true;
    [[nodiscard]] static SdvServiceManifest from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

enum class SdvServiceState { Stopped, Starting, Running, Degraded, Failed, Updating };

struct SdvServiceStatus {
    SdvServiceManifest manifest;
    SdvServiceState state = SdvServiceState::Stopped;
    std::uint64_t releases = 0;
    std::uint64_t deadline_misses = 0;
    std::uint64_t restarts = 0;
    std::uint64_t last_start_us = 0;
    std::uint64_t last_finish_us = 0;
    std::string diagnostic;
    [[nodiscard]] doc::Value to_document() const;
};

struct SdvRuntimeCapacity {
    std::size_t cpu_millicores = 4000;
    std::size_t memory_mb = 8192;
    std::size_t gpu_millipercent = 100000;
};

class SdvWorkloadRuntime {
public:
    explicit SdvWorkloadRuntime(SdvRuntimeCapacity capacity = {});
    void register_signal(VehicleSignalDefinition definition);
    void write_signal(const std::string& path, double value, const std::string& writer);
    [[nodiscard]] double read_signal(const std::string& path, const std::string& reader) const;
    void install(SdvServiceManifest manifest);
    void start(const std::string& service_id);
    void stop(const std::string& service_id);
    void fail(const std::string& service_id, const std::string& reason);
    void rolling_update(const std::string& service_id, SdvServiceManifest replacement,
                        std::size_t healthy_ticks_required = 2);
    void tick(std::uint64_t elapsed_us,
              const std::map<std::string, std::uint64_t>& execution_time_us = {});
    [[nodiscard]] std::vector<std::string> startup_order() const;
    [[nodiscard]] doc::Value report() const;
private:
    struct Impl;
    std::shared_ptr<Impl> implementation_;
};

// -----------------------------------------------------------------------------
// Post-quantum crypto agility and HSM attack simulation
// -----------------------------------------------------------------------------

enum class PqcAlgorithmKind { Kem, Signature };

struct PqcAlgorithmInfo {
    std::string name;
    PqcAlgorithmKind kind = PqcAlgorithmKind::Kem;
    std::size_t public_key_bytes = 0;
    std::size_t private_key_bytes = 0;
    std::size_t ciphertext_or_signature_bytes = 0;
    std::size_t shared_secret_bytes = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct PqcKemExchange {
    std::vector<std::uint8_t> ciphertext;
    std::vector<std::uint8_t> shared_secret;
};

class PostQuantumCryptoProvider {
public:
    PostQuantumCryptoProvider();
    ~PostQuantumCryptoProvider();
    PostQuantumCryptoProvider(PostQuantumCryptoProvider&&) noexcept;
    PostQuantumCryptoProvider& operator=(PostQuantumCryptoProvider&&) noexcept;
    PostQuantumCryptoProvider(const PostQuantumCryptoProvider&) = delete;
    PostQuantumCryptoProvider& operator=(const PostQuantumCryptoProvider&) = delete;

    void generate_key(const std::string& key_id, const std::string& algorithm);
    [[nodiscard]] std::vector<std::uint8_t> public_key_der(const std::string& key_id) const;
    [[nodiscard]] PqcKemExchange encapsulate(const std::string& key_id) const;
    [[nodiscard]] std::vector<std::uint8_t> decapsulate(
        const std::string& key_id, const std::vector<std::uint8_t>& ciphertext) const;
    [[nodiscard]] std::vector<std::uint8_t> sign(
        const std::string& key_id, const std::vector<std::uint8_t>& message) const;
    [[nodiscard]] bool verify(const std::string& key_id,
                              const std::vector<std::uint8_t>& message,
                              const std::vector<std::uint8_t>& signature) const;
    [[nodiscard]] PqcAlgorithmInfo info(const std::string& key_id) const;
    [[nodiscard]] std::vector<std::string> available_algorithms() const;
private:
    struct Impl;
    std::unique_ptr<Impl> implementation_;
};

enum class HsmAttackType {
    VoltageGlitch,
    ClockGlitch,
    EntropyDegradation,
    TimingSideChannel,
    PowerSideChannel,
    CounterRollback,
    DebugPortExtraction,
    KeySlotExhaustion
};

struct HsmSecurityProfile {
    bool voltage_monitors = true;
    bool clock_monitors = true;
    bool health_tested_rng = true;
    bool constant_time_crypto = true;
    bool masked_implementation = true;
    bool monotonic_counter_protection = true;
    bool debug_locked = true;
    std::size_t key_slots = 32;
    unsigned tamper_response_level = 2;
};

struct HsmAttackCampaignResult {
    std::size_t trials = 0;
    std::size_t successful_attacks = 0;
    std::size_t detected_attacks = 0;
    double estimated_success_probability = 0.0;
    double detection_probability = 0.0;
    std::map<std::string, std::size_t> outcomes;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class HsmAttackSimulator {
public:
    [[nodiscard]] HsmAttackCampaignResult run(HsmAttackType attack,
                                              const HsmSecurityProfile& profile,
                                              std::size_t trials,
                                              std::uint64_t seed) const;
};

// -----------------------------------------------------------------------------
// NR-V2X, NTN, and edge-compute co-simulation
// -----------------------------------------------------------------------------

struct NrV2xLinkConfiguration {
    double carrier_frequency_hz = 5.9e9;
    double bandwidth_hz = 20.0e6;
    double transmit_power_dbm = 23.0;
    double antenna_gain_dbi = 3.0;
    double noise_figure_db = 7.0;
    double distance_m = 100.0;
    double relative_speed_m_s = 0.0;
    double shadowing_db = 0.0;
    double interference_dbm = -110.0;
    std::size_t resource_blocks = 50;
};

struct NrV2xPacket {
    std::string id;
    std::size_t bytes = 0;
    unsigned priority = 0;
    std::uint64_t deadline_us = 100000;
    unsigned maximum_harq_retransmissions = 2;
};

struct NrV2xPacketResult {
    bool delivered = false;
    unsigned retransmissions = 0;
    double sinr_db = 0.0;
    double block_error_probability = 1.0;
    std::uint64_t latency_us = 0;
    std::size_t allocated_resource_blocks = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct NtnOrbitConfiguration {
    double altitude_m = 600000.0;
    double inclination_deg = 53.0;
    double elevation_deg = 45.0;
    double carrier_frequency_hz = 2.0e9;
    double satellite_speed_m_s = 7500.0;
};

struct NtnLinkResult {
    double slant_range_m = 0.0;
    double propagation_delay_ms = 0.0;
    double doppler_hz = 0.0;
    double free_space_path_loss_db = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct EdgeTask {
    std::string id;
    std::uint64_t input_bytes = 0;
    std::uint64_t output_bytes = 0;
    double compute_giga_operations = 0.0;
    std::uint64_t deadline_us = 100000;
    unsigned priority = 0;
};

struct EdgeTaskResult {
    bool completed = false;
    bool deadline_met = false;
    std::uint64_t uplink_us = 0;
    std::uint64_t queue_us = 0;
    std::uint64_t compute_us = 0;
    std::uint64_t downlink_us = 0;
    std::uint64_t total_us = 0;
    [[nodiscard]] doc::Value to_document() const;
};

class ConnectedVehicleNetworkSimulator {
public:
    explicit ConnectedVehicleNetworkSimulator(std::uint64_t seed = 1);
    [[nodiscard]] NrV2xPacketResult transmit(const NrV2xLinkConfiguration& link,
                                             const NrV2xPacket& packet);
    [[nodiscard]] static NtnLinkResult evaluate_ntn(const NtnOrbitConfiguration& orbit);
    void configure_edge(double giga_operations_per_second,
                        double uplink_mbps,
                        double downlink_mbps,
                        std::uint64_t base_network_latency_us);
    [[nodiscard]] std::vector<EdgeTaskResult> execute_edge_batch(
        const std::vector<EdgeTask>& tasks);
private:
    std::uint64_t random_state_ = 1;
    double edge_gops_s_ = 1000.0;
    double uplink_mbps_ = 100.0;
    double downlink_mbps_ = 100.0;
    std::uint64_t base_latency_us_ = 1000;
    [[nodiscard]] double uniform();
};

} // namespace aesim::advanced

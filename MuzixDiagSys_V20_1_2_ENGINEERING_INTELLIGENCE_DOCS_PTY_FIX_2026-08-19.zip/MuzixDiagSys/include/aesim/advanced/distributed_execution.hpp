#pragma once

#include "aesim/professional/document.hpp"

#include <chrono>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

struct DistributedJob {
    std::string name;
    std::vector<std::string> command;
    std::string working_directory;
    std::map<std::string, std::string> environment;
    unsigned cpu_cores = 1;
    unsigned gpu_count = 0;
    std::uint64_t memory_mb = 1024;
    std::chrono::seconds wall_time{3600};
    std::string queue;
    std::string container_image;
    unsigned retries = 0;
    [[nodiscard]] static DistributedJob from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct SchedulerJobStatus {
    std::string backend;
    std::string job_id;
    std::string phase;
    std::string detail;
    bool terminal = false;
    bool successful = false;
    [[nodiscard]] doc::Value to_document() const;
};

class SlurmExecutor {
public:
    explicit SlurmExecutor(std::string sbatch = "sbatch", std::string squeue = "squeue",
                           std::string sacct = "sacct", std::string scancel = "scancel");
    void write_script(const DistributedJob& job, const std::string& path) const;
    [[nodiscard]] std::string submit(const std::string& script_path) const;
    [[nodiscard]] SchedulerJobStatus query(const std::string& job_id) const;
    void cancel(const std::string& job_id) const;
private:
    std::string sbatch_, squeue_, sacct_, scancel_;
};

class KubernetesExecutor {
public:
    explicit KubernetesExecutor(std::string kubectl = "kubectl", std::string name_space = "default");
    void write_manifest(const DistributedJob& job, const std::string& path) const;
    [[nodiscard]] std::string apply(const std::string& manifest_path) const;
    [[nodiscard]] SchedulerJobStatus query(const std::string& job_name) const;
    void remove(const std::string& job_name) const;
private:
    std::string kubectl_, namespace_;
};

} // namespace aesim::advanced

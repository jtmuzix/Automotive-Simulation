#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::nextfrontier {

class FrontierNextPlatform {
public:
    [[nodiscard]] aesim::doc::Value capabilities() const;
    [[nodiscard]] aesim::doc::Value domain_capabilities(const std::string& domain) const;
    [[nodiscard]] aesim::doc::Value execute(const std::string& domain,
                                            const aesim::doc::Value& request,
                                            const std::string& working_directory = {}) const;
    [[nodiscard]] aesim::doc::Value self_test(const std::string& working_directory) const;
    [[nodiscard]] aesim::doc::Value domain_self_test(const std::string& domain,
                                                     const std::string& working_directory) const;
};

} // namespace aesim::advanced::nextfrontier

#pragma once
#include "aesim/advanced/qualification_science_platform.hpp"
#include "aesim/core/provenance.hpp"
#include "aesim/professional/document.hpp"
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>
namespace aesim::advanced {
struct LineageExperimentRecord { std::string experiment_id; std::vector<std::string> parent_experiment_ids; std::string name,source_revision,model_version,scenario_sha256,configuration_sha256,calibration_sha256,build_sha256,compiler_identity,platform_identity; std::uint64_t random_seed=0; std::string started_utc,qualification_state; std::map<std::string,std::string> tags; };
struct LineageArtifactRecord { std::string artifact_id,experiment_id,role,path,sha256; std::uint64_t size_bytes=0; std::string media_type; std::vector<std::string> parent_artifact_ids; std::string producer; std::map<std::string,std::string> metadata; };
struct LineageQuery { std::optional<std::string> experiment_id,parent_experiment_id,role,media_type; std::map<std::string,std::string> required_tags; };
struct LineageVerificationReport { bool acyclic=false,references_resolved=false,artifact_hashes_valid=false; std::vector<std::string> findings; std::string graph_sha256; [[nodiscard]] doc::Value to_document() const; };
class ScientificDataLineageGraph { public: void clear(); void add_experiment(LineageExperimentRecord); [[nodiscard]] std::string add_artifact(LineageArtifactRecord,bool hash_file_if_present=true); [[nodiscard]] std::string register_existing_run(const core::ExperimentStatus&,const core::ExperimentMetadata&,std::vector<std::string> parent_experiment_ids={}); [[nodiscard]] std::vector<LineageExperimentRecord> query_experiments(const LineageQuery&) const; [[nodiscard]] std::vector<LineageArtifactRecord> query_artifacts(const LineageQuery&) const; [[nodiscard]] std::vector<std::string> experiment_ancestors(const std::string&) const; [[nodiscard]] std::vector<std::string> artifact_ancestors(const std::string&) const; [[nodiscard]] std::vector<std::string> artifact_descendants(const std::string&) const; [[nodiscard]] LineageVerificationReport verify(bool=false) const; [[nodiscard]] doc::Value to_document() const; void save_json(const std::string&) const; [[nodiscard]] static ScientificDataLineageGraph load_json(const std::string&); private: std::map<std::string,LineageExperimentRecord> experiments_; std::map<std::string,LineageArtifactRecord> artifacts_; };
enum class CausalDiscoveryMethod { Pc,Fci,Ges,Notears,Pcmci }; enum class CausalEndpoint { Tail,Arrow,Circle };
struct CausalDiscoveryDataset { std::vector<std::string> variables; std::vector<std::vector<double>> samples; double sample_period_s=0.0; void validate() const; };
struct CausalDiscoveryOptions { CausalDiscoveryMethod method=CausalDiscoveryMethod::Pc; double significance_level=0.01; std::size_t maximum_conditioning_set=3; double edge_threshold=0.05,bic_penalty=1.0; std::size_t maximum_iterations=500; double notears_l1=0.01,notears_learning_rate=0.01,notears_acyclicity_tolerance=1e-8; std::size_t maximum_lag=5; };
struct DiscoveredCausalEdge { std::string from,to; CausalEndpoint from_endpoint=CausalEndpoint::Tail,to_endpoint=CausalEndpoint::Arrow; std::size_t lag_samples=0; double strength=0.0,p_value=1.0; };
struct CausalDiscoveryMetrics { std::size_t structural_hamming_distance=0; double precision=0.0,recall=0.0,f1=0.0,orientation_accuracy=0.0; };
struct CausalDiscoveryResult { CausalDiscoveryMethod method=CausalDiscoveryMethod::Pc; std::vector<DiscoveredCausalEdge> edges; std::vector<std::string> topological_order; std::map<std::string,std::vector<std::string>> separating_sets; std::optional<CausalDiscoveryMetrics> metrics; double score=0.0; bool acyclic=false; std::string evidence_sha256; [[nodiscard]] std::vector<CausalEdgeDefinition> to_counterfactual_graph() const; [[nodiscard]] doc::Value to_document() const; };
class CausalDiscoveryEngine { public: [[nodiscard]] CausalDiscoveryResult discover(const CausalDiscoveryDataset&,const CausalDiscoveryOptions& = {}, const std::vector<CausalEdgeDefinition>& = {}) const; };
} // namespace aesim::advanced

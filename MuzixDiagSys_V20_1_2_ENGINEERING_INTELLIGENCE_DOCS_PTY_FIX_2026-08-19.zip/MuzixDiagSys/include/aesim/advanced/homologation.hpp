#pragma once

#include "aesim/professional/document.hpp"

#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

struct HomologationSample {
    double time_s = 0.0;
    std::map<std::string, double> signals;
};

struct HomologationVerdict {
    std::string id;
    std::string description;
    std::string metric;
    std::string signal;
    double measured = 0.0;
    double lower_limit = 0.0;
    double upper_limit = 0.0;
    bool passed = false;
    std::string reason;
};

struct HomologationReport {
    std::string pack_id;
    std::string pack_version;
    std::string vehicle_class;
    std::string trace_sha256;
    bool passed = false;
    std::vector<HomologationVerdict> verdicts;
    [[nodiscard]] doc::Value to_document() const;
};

class DigitalHomologationRunner {
public:
    [[nodiscard]] HomologationReport run(const doc::Value& pack,
                                         const std::vector<HomologationSample>& samples,
                                         const std::string& trace_artifact = {}) const;
    [[nodiscard]] static std::vector<HomologationSample> load_csv(const std::string& path);
    [[nodiscard]] static doc::Value validate_pack(const doc::Value& pack);
private:
    [[nodiscard]] static double metric(const std::string& metric_name,
                                       const std::string& signal,
                                       const std::vector<HomologationSample>& samples,
                                       double start_s, double end_s,
                                       const doc::Value& requirement);
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

struct AdsActorState {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    double speed_mps = 0.0;
    double heading_rad = 0.0;
    double length_m = 4.5;
    double width_m = 1.8;
};

struct AdsFrame {
    double time_s = 0.0;
    AdsActorState ego;
    std::vector<AdsActorState> actors;
    double lane_center_y_m = 0.0;
    double speed_limit_mps = 0.0;
    double commanded_acceleration_mps2 = 0.0;
    double commanded_steering_rad = 0.0;
    bool localization_valid = true;
    bool map_valid = true;
    bool minimum_risk_active = false;
};

struct AdsRequirement {
    std::string id;
    std::string metric;
    std::string comparison;
    double threshold = 0.0;
};

struct AdsQualificationReport {
    double minimum_ttc_s = 0.0;
    double minimum_distance_m = 0.0;
    double maximum_lane_error_m = 0.0;
    double maximum_jerk_mps3 = 0.0;
    std::size_t collisions = 0;
    std::size_t speed_violations = 0;
    std::size_t localization_failures = 0;
    std::size_t map_failures = 0;
    std::size_t mrm_activations = 0;
    std::map<std::string, bool> requirement_verdicts;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AdsQualificationLaboratory {
public:
    [[nodiscard]] AdsQualificationReport evaluate(const std::vector<AdsFrame>& frames,
                                                  const std::vector<AdsRequirement>& requirements) const;
};

struct CadVertex { double x = 0.0; double y = 0.0; double z = 0.0; };
struct CadTriangle { std::array<std::size_t, 3> vertices{}; std::string material; };

struct CadMesh {
    std::vector<CadVertex> vertices;
    std::vector<CadTriangle> triangles;
    std::map<std::string, std::string> metadata;
    [[nodiscard]] doc::Value to_document() const;
};

struct MeshQualityReport {
    double surface_area_m2 = 0.0;
    double signed_volume_m3 = 0.0;
    double minimum_angle_deg = 0.0;
    double maximum_aspect_ratio = 0.0;
    std::size_t boundary_edges = 0;
    std::size_t non_manifold_edges = 0;
    std::size_t degenerate_triangles = 0;
    bool watertight = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CadMeshingPipeline {
public:
    [[nodiscard]] CadMesh import_obj(const std::string& text) const;
    [[nodiscard]] CadMesh import_ascii_stl(const std::string& text) const;
    [[nodiscard]] CadMesh import_step_ap242_faceted(const std::string& text) const;
    [[nodiscard]] std::string export_obj(const CadMesh& mesh) const;
    [[nodiscard]] std::string export_ascii_stl(const CadMesh& mesh, const std::string& name) const;
    [[nodiscard]] CadMesh heal(const CadMesh& mesh, double merge_tolerance_m = 1.0e-9) const;
    [[nodiscard]] CadMesh refine(const CadMesh& mesh, double maximum_edge_m) const;
    [[nodiscard]] MeshQualityReport quality(const CadMesh& mesh) const;
    [[nodiscard]] static CadMesh make_box(double length_m, double width_m, double height_m);
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Crash, occupant, restraint, and injury biomechanics
// -----------------------------------------------------------------------------

struct CrashPulseSample {
    double time_s = 0.0;
    double vehicle_acceleration_m_s2 = 0.0;
};

struct OccupantBiomechanicsConfiguration {
    double pelvis_mass_kg = 20.0;
    double chest_mass_kg = 25.0;
    double head_mass_kg = 4.5;
    double pelvis_chest_stiffness_n_m = 45000.0;
    double pelvis_chest_damping_n_s_m = 1800.0;
    double neck_stiffness_n_m = 18000.0;
    double neck_damping_n_s_m = 600.0;
    double belt_slack_m = 0.03;
    double belt_stiffness_n_m = 80000.0;
    double belt_damping_n_s_m = 1600.0;
    double belt_load_limiter_n = 4500.0;
    double pretensioner_time_s = 0.015;
    double pretensioner_retraction_m = 0.04;
    double airbag_contact_distance_m = 0.25;
    double airbag_stiffness_n_m = 25000.0;
    double airbag_damping_n_s_m = 900.0;
    double airbag_vent_coefficient = 0.2;
    double femur_effective_area_m2 = 0.003;
};

struct OccupantTimeHistory {
    std::vector<double> time_s;
    std::vector<double> pelvis_displacement_m;
    std::vector<double> chest_displacement_m;
    std::vector<double> head_displacement_m;
    std::vector<double> pelvis_acceleration_m_s2;
    std::vector<double> chest_acceleration_m_s2;
    std::vector<double> head_acceleration_m_s2;
    std::vector<double> belt_force_n;
    std::vector<double> neck_force_n;
};

struct InjuryMetrics {
    double hic15 = 0.0;
    double hic36 = 0.0;
    double nij = 0.0;
    double maximum_chest_deflection_m = 0.0;
    double maximum_chest_acceleration_g = 0.0;
    double maximum_femur_force_n = 0.0;
    double maximum_belt_force_n = 0.0;
    double head_injury_probability_ais3 = 0.0;
    double chest_injury_probability_ais3 = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct CrashBiomechanicsResult {
    OccupantTimeHistory history;
    InjuryMetrics injuries;
    bool numerically_stable = true;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = true) const;
};

class CrashOccupantBiomechanicsSimulator {
public:
    [[nodiscard]] CrashBiomechanicsResult simulate(
        const std::vector<CrashPulseSample>& pulse,
        const OccupantBiomechanicsConfiguration& configuration,
        double integration_step_s = 0.0001) const;
};

enum class VruRoadUserType { Pedestrian, Cyclist, Motorcyclist };

struct VruActiveSafetyState {
    double initial_vehicle_speed_m_s = 13.89;
    double time_to_collision_s = 0.8;
    double braking_delay_s = 0.15;
    double commanded_deceleration_m_s2 = 8.0;
    double minimum_vehicle_speed_m_s = 0.0;
    [[nodiscard]] double impact_speed_m_s() const;
};

struct VruBiomechanicsConfiguration {
    VruRoadUserType road_user_type = VruRoadUserType::Pedestrian;
    double height_m = 1.75;
    double mass_kg = 75.0;
    double lower_body_mass_fraction = 0.34;
    double pelvis_mass_fraction = 0.18;
    double chest_mass_fraction = 0.42;
    double head_mass_fraction = 0.06;
    double leg_torso_stiffness_n_m = 45000.0;
    double leg_torso_damping_n_s_m = 1300.0;
    double torso_neck_stiffness_n_m = 22000.0;
    double torso_neck_damping_n_s_m = 650.0;
    double bumper_height_m = 0.48;
    double hood_height_m = 0.82;
    double windshield_base_height_m = 1.05;
    double bumper_contact_stiffness_n_m = 180000.0;
    double hood_contact_stiffness_n_m = 120000.0;
    double windshield_contact_stiffness_n_m = 90000.0;
    double contact_damping_n_s_m = 2600.0;
    double ground_stiffness_n_m = 300000.0;
    double ground_damping_n_s_m = 3500.0;
    double helmet_absorption_fraction = 0.0;
    double cycle_mass_kg = 12.0;
    double motorcycle_mass_kg = 180.0;
};

struct VruTimeHistory {
    std::vector<double> time_s;
    std::vector<double> vehicle_front_position_m;
    std::vector<double> lower_body_position_m;
    std::vector<double> pelvis_position_m;
    std::vector<double> chest_position_m;
    std::vector<double> head_position_m;
    std::vector<double> head_acceleration_m_s2;
    std::vector<double> head_angular_velocity_rad_s;
    std::vector<double> contact_force_n;
};

struct VruInjuryMetrics {
    double impact_speed_m_s = 0.0;
    double hic15 = 0.0;
    double bric = 0.0;
    double maximum_head_acceleration_g = 0.0;
    double maximum_chest_acceleration_g = 0.0;
    double maximum_pelvis_force_n = 0.0;
    double maximum_femur_force_n = 0.0;
    double maximum_tibia_acceleration_g = 0.0;
    double maximum_knee_moment_nm = 0.0;
    double head_injury_probability_ais3 = 0.0;
    double lower_extremity_injury_probability_ais2 = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct VruCrashBiomechanicsResult {
    VruTimeHistory history;
    VruInjuryMetrics injuries;
    bool numerically_stable = true;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = true) const;
};

class VruCrashBiomechanicsSimulator {
public:
    [[nodiscard]] VruCrashBiomechanicsResult simulate(
        const VruActiveSafetyState& active_safety,
        const VruBiomechanicsConfiguration& configuration,
        double duration_s = 0.45,
        double integration_step_s = 0.00005) const;
};

// -----------------------------------------------------------------------------
// Lifecycle sustainability and circular-economy analysis
// -----------------------------------------------------------------------------

struct LifecycleMaterial {
    std::string name;
    double mass_kg = 0.0;
    double recycled_content_fraction = 0.0;
    double virgin_carbon_kg_co2e_per_kg = 0.0;
    double recycled_carbon_kg_co2e_per_kg = 0.0;
    double embodied_energy_mj_per_kg = 0.0;
    double water_l_per_kg = 0.0;
    double cost_per_kg = 0.0;
    double criticality_score = 0.0;
    double recyclable_fraction = 0.0;
    double reusable_fraction = 0.0;
    double remanufacturable_fraction = 0.0;
};

struct LifecycleComponent {
    std::string id;
    std::string supplier;
    std::vector<LifecycleMaterial> materials;
    double manufacturing_energy_kwh = 0.0;
    double manufacturing_scrap_fraction = 0.0;
    double expected_life_km = 200000.0;
    double replacement_count = 0.0;
    bool battery_passport_required = false;
};

struct LifecycleUsePhase {
    double lifetime_km = 200000.0;
    double electricity_kwh_per_100km = 18.0;
    double fuel_l_per_100km = 0.0;
    double electricity_carbon_kg_co2e_per_kwh = 0.35;
    double electricity_primary_energy_mj_per_kwh = 7.2;
    double fuel_carbon_kg_co2e_per_l = 2.31;
    double fuel_primary_energy_mj_per_l = 34.2;
    double maintenance_carbon_kg_co2e = 0.0;
    double maintenance_cost = 0.0;
};

struct EndOfLifeScenario {
    double collection_fraction = 0.95;
    double recycling_efficiency = 0.85;
    double reuse_efficiency = 0.9;
    double remanufacturing_efficiency = 0.85;
    double landfill_carbon_kg_co2e_per_kg = 0.05;
    double recycling_credit_kg_co2e_per_kg = 0.5;
};

struct LifecycleResult {
    double vehicle_mass_kg = 0.0;
    double production_carbon_kg_co2e = 0.0;
    double use_phase_carbon_kg_co2e = 0.0;
    double end_of_life_carbon_kg_co2e = 0.0;
    double total_carbon_kg_co2e = 0.0;
    double total_primary_energy_mj = 0.0;
    double total_water_l = 0.0;
    double total_cost = 0.0;
    double recovered_mass_kg = 0.0;
    double landfill_mass_kg = 0.0;
    double material_circularity_indicator = 0.0;
    double critical_material_risk = 0.0;
    std::map<std::string, double> material_mass_kg;
    doc::Value battery_passport;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class LifecycleCircularEconomyAnalyzer {
public:
    [[nodiscard]] LifecycleResult analyze(
        const std::vector<LifecycleComponent>& components,
        const LifecycleUsePhase& use_phase,
        const EndOfLifeScenario& end_of_life) const;
    [[nodiscard]] static doc::Value compare_scenarios(
        const LifecycleResult& baseline,
        const LifecycleResult& alternative);
};

} // namespace aesim::advanced

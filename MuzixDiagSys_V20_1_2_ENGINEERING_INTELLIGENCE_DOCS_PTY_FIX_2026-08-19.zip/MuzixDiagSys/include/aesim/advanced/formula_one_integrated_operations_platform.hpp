#pragma once

#include "aesim/advanced/formula_one_realism_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// All physical quantities use SI units unless explicitly stated otherwise.
// Stochastic services are deterministic for identical configurations, inputs,
// and seeds.

// -----------------------------------------------------------------------------
// Spatial pit-crew and garage-operations twin.
// -----------------------------------------------------------------------------

struct F1PitCrewMemberConfiguration {
    std::string id;
    std::string role;
    F1FidelityVector3 initial_position_m{};
    double maximum_speed_m_s = 4.5;
    double acceleration_m_s2 = 6.0;
    double reach_m = 1.0;
    double nominal_task_time_s = 1.0;
    double task_time_sigma_s = 0.05;
    double fatigue_rate_per_s = 0.001;
    double recovery_rate_per_s = 0.003;
    double error_probability = 0.001;

    void validate() const;
};

struct F1PitTaskConfiguration {
    std::string id;
    std::string required_role;
    F1FidelityVector3 target_position_m{};
    std::vector<std::string> dependencies;
    double work_time_s = 1.0;
    double tool_cycle_time_s = 0.0;
    double alignment_tolerance_m = 0.03;
    double failure_probability = 0.0;
    double retry_time_s = 0.3;
    bool release_critical = false;

    void validate() const;
};

struct F1PitStopConfiguration {
    std::vector<F1PitCrewMemberConfiguration> crew;
    std::vector<F1PitTaskConfiguration> tasks;
    F1FidelityVector3 nominal_car_stop_m{};
    double car_stop_sigma_m = 0.025;
    double minimum_separation_m = 0.55;
    double collision_delay_s = 0.08;
    double release_observation_time_s = 0.18;
    std::uint64_t seed = 1;

    void validate() const;
};

struct F1PitCrewMemberState {
    F1FidelityVector3 position_m{};
    double fatigue = 0.0;
    double available_time_s = 0.0;
    std::size_t completed_tasks = 0;
};

struct F1PitTaskExecution {
    std::string task_id;
    std::string crew_id;
    double start_time_s = 0.0;
    double finish_time_s = 0.0;
    double travel_time_s = 0.0;
    double work_time_s = 0.0;
    std::size_t attempts = 0;
    bool succeeded = false;
};

struct F1SpatialPitStopResult {
    double total_time_s = 0.0;
    double car_stop_error_m = 0.0;
    double collision_delay_s = 0.0;
    double unsafe_release_probability = 0.0;
    std::vector<F1PitTaskExecution> tasks;
    std::map<std::string, F1PitCrewMemberState> crew_states;
    bool all_tasks_succeeded = false;
    bool finite = true;
};

struct F1GarageTaskConfiguration {
    std::string id;
    std::string required_role;
    std::vector<std::string> dependencies;
    double nominal_duration_s = 60.0;
    std::size_t required_people = 1;
    bool parc_ferme_sensitive = false;
    double rework_probability = 0.0;

    void validate() const;
};

struct F1GarageTurnaroundInput {
    std::vector<F1GarageTaskConfiguration> tasks;
    std::map<std::string, std::size_t> available_people_by_role;
    double session_deadline_s = 3600.0;
    bool parc_ferme_active = false;
};

struct F1GarageTaskResult {
    std::string id;
    double start_time_s = 0.0;
    double finish_time_s = 0.0;
    bool reworked = false;
    bool legal = true;
};

struct F1GarageTurnaroundResult {
    double completion_time_s = 0.0;
    double deadline_margin_s = 0.0;
    std::vector<F1GarageTaskResult> tasks;
    bool completed = false;
    bool legal = true;
};

class F1PitCrewGarageOperationsTwin {
public:
    explicit F1PitCrewGarageOperationsTwin(F1PitStopConfiguration configuration);
    [[nodiscard]] const F1PitStopConfiguration& configuration() const noexcept;
    [[nodiscard]] F1SpatialPitStopResult simulate_pit_stop(double traffic_gap_s = 5.0) const;
    [[nodiscard]] F1GarageTurnaroundResult simulate_garage_turnaround(
        const F1GarageTurnaroundInput& input,
        std::uint64_t seed = 1) const;

private:
    F1PitStopConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// F1 occupant, helmet, HANS, restraint, and egress biomechanics.
// -----------------------------------------------------------------------------

struct F1OccupantBiomechanicsConfiguration {
    double head_mass_kg = 6.5;
    double torso_mass_kg = 42.0;
    double pelvis_mass_kg = 18.0;
    double helmet_mass_kg = 1.6;
    double neck_stiffness_n_m = 18000.0;
    double neck_damping_n_s_m = 1100.0;
    double hans_tether_stiffness_n_m = 42000.0;
    double hans_tether_slack_m = 0.018;
    double shoulder_belt_stiffness_n_m = 95000.0;
    double lap_belt_stiffness_n_m = 120000.0;
    double belt_damping_n_s_m = 2600.0;
    double seat_stiffness_n_m = 180000.0;
    double seat_damping_n_s_m = 5000.0;
    double headrest_stiffness_n_m = 240000.0;
    double headrest_gap_m = 0.035;
    double cockpit_clearance_m = 0.12;
    double maximum_egress_strength_loss = 0.65;

    void validate() const;
};

struct F1CrashPulseSample {
    double time_s = 0.0;
    F1FidelityVector3 vehicle_acceleration_m_s2{};
    F1FidelityVector3 vehicle_angular_acceleration_rad_s2{};
};

struct F1OccupantBiomechanicsState {
    F1FidelityVector3 head_displacement_m{};
    F1FidelityVector3 head_velocity_m_s{};
    F1FidelityVector3 torso_displacement_m{};
    F1FidelityVector3 torso_velocity_m_s{};
    F1FidelityVector3 pelvis_displacement_m{};
    F1FidelityVector3 pelvis_velocity_m_s{};
};

struct F1OccupantBiomechanicsResult {
    std::vector<F1OccupantBiomechanicsState> trajectory;
    double hic15 = 0.0;
    double maximum_head_acceleration_g = 0.0;
    double maximum_head_angular_acceleration_rad_s2 = 0.0;
    double maximum_neck_tension_n = 0.0;
    double maximum_neck_compression_n = 0.0;
    double maximum_hans_tether_load_n = 0.0;
    double maximum_shoulder_belt_load_n = 0.0;
    double maximum_lap_belt_load_n = 0.0;
    double nij = 0.0;
    double consciousness_probability = 1.0;
    double self_egress_probability = 1.0;
    double estimated_egress_time_s = 7.0;
    bool survivable = true;
    bool finite = true;
};

class F1OccupantHansEgressBiomechanics {
public:
    explicit F1OccupantHansEgressBiomechanics(F1OccupantBiomechanicsConfiguration configuration = {});
    [[nodiscard]] const F1OccupantBiomechanicsConfiguration& configuration() const noexcept;
    [[nodiscard]] F1OccupantBiomechanicsResult simulate(
        const std::vector<F1CrashPulseSample>& pulse,
        double driver_fatigue = 0.0,
        double cockpit_temperature_k = 300.0) const;

private:
    F1OccupantBiomechanicsConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Team-radio audio, semantics, and comprehension model.
// -----------------------------------------------------------------------------

struct F1RadioParticipantConfiguration {
    std::string id;
    double language_fluency = 1.0;
    double hearing_quality = 1.0;
    double stress_sensitivity = 0.25;
    double working_memory = 1.0;

    void validate() const;
};

struct F1RadioMessage {
    std::string id;
    std::string sender_id;
    std::string receiver_id;
    std::string text;
    double requested_transmit_time_s = 0.0;
    double urgency = 0.5;
    double channel_snr_db = 20.0;
    double clipping_fraction = 0.0;
    double background_noise_db = 85.0;
    double receiver_workload = 0.0;
    double receiver_stress = 0.0;
    bool acknowledgement_required = true;
};

struct F1RadioMessageResult {
    std::string message_id;
    double transmit_start_s = 0.0;
    double transmit_end_s = 0.0;
    double received_fraction = 0.0;
    double comprehension_probability = 0.0;
    double action_probability = 0.0;
    double action_delay_s = 0.0;
    std::vector<std::string> extracted_actions;
    std::vector<std::string> misunderstood_tokens;
    bool received = false;
    bool understood = false;
    bool acknowledged = false;
    bool executed = false;
};

struct F1TeamRadioSessionResult {
    std::vector<F1RadioMessageResult> messages;
    double channel_utilization = 0.0;
    std::size_t misunderstood_messages = 0;
    std::size_t unacknowledged_messages = 0;
    double final_channel_time_s = 0.0;
};

class F1TeamRadioSemanticComprehensionModel {
public:
    explicit F1TeamRadioSemanticComprehensionModel(
        std::vector<F1RadioParticipantConfiguration> participants,
        std::uint64_t seed = 1);
    [[nodiscard]] F1TeamRadioSessionResult simulate(
        const std::vector<F1RadioMessage>& messages) const;

private:
    std::vector<F1RadioParticipantConfiguration> participants_;
    std::uint64_t seed_ = 1;
};

// -----------------------------------------------------------------------------
// Dynamic trackside recovery, marshal, medical, and barrier operations.
// -----------------------------------------------------------------------------

struct F1RecoveryNetworkNode {
    std::string id;
    F1FidelityVector3 position_m{};
};

struct F1RecoveryNetworkEdge {
    std::string from;
    std::string to;
    double length_m = 0.0;
    double speed_limit_m_s = 10.0;
    bool track_crossing = false;
    bool available = true;

    void validate() const;
};

struct F1RecoveryResourceConfiguration {
    std::string id;
    std::string type;
    std::string initial_node;
    double maximum_speed_m_s = 12.0;
    double setup_time_s = 10.0;
    std::map<std::string, double> consumables;

    void validate() const;
};

struct F1RecoveryTaskConfiguration {
    std::string id;
    std::string location_node;
    std::string required_resource_type;
    std::vector<std::string> dependencies;
    double work_time_s = 30.0;
    double consumable_required = 0.0;
    std::string consumable_id;
    bool requires_track_crossing = false;

    void validate() const;
};

struct F1RecoveryTaskResult {
    std::string task_id;
    std::string resource_id;
    double dispatch_time_s = 0.0;
    double arrival_time_s = 0.0;
    double completion_time_s = 0.0;
    double route_distance_m = 0.0;
    bool completed = false;
};

struct F1TracksideRecoveryResult {
    std::vector<F1RecoveryTaskResult> tasks;
    double neutralization_duration_s = 0.0;
    double restart_readiness_time_s = 0.0;
    bool red_flag_recommended = false;
    bool all_tasks_completed = false;
};

class F1DynamicTracksideRecoveryOperations {
public:
    F1DynamicTracksideRecoveryOperations(
        std::vector<F1RecoveryNetworkNode> nodes,
        std::vector<F1RecoveryNetworkEdge> edges,
        std::vector<F1RecoveryResourceConfiguration> resources);
    [[nodiscard]] F1TracksideRecoveryResult execute(
        const std::vector<F1RecoveryTaskConfiguration>& tasks,
        bool cars_circulating,
        double race_control_latency_s = 1.0) const;

private:
    std::vector<F1RecoveryNetworkNode> nodes_;
    std::vector<F1RecoveryNetworkEdge> edges_;
    std::vector<F1RecoveryResourceConfiguration> resources_;
};

// -----------------------------------------------------------------------------
// Spray optics and wet-visibility physics.
// -----------------------------------------------------------------------------

struct F1SprayDropletBin {
    double diameter_m = 50.0e-6;
    double number_concentration_m3 = 0.0;
    F1FidelityVector3 velocity_m_s{};
    double temperature_k = 293.15;

    void validate() const;
};

struct F1SprayOpticsConfiguration {
    std::vector<F1SprayDropletBin> initial_bins;
    double path_length_m = 100.0;
    double wavelength_m = 550.0e-9;
    double water_refractive_index = 1.333;
    double evaporation_coefficient_m2_s = 1.0e-10;
    double coalescence_coefficient_m3_s = 2.0e-12;
    double deposition_velocity_m_s = 0.02;
    double wake_mixing_rate_s = 0.5;
    double camera_exposure_s = 0.005;
    double rain_light_intensity_cd = 20.0;

    void validate() const;
};

struct F1SprayOpticsInput {
    double time_step_s = 0.02;
    double vehicle_speed_m_s = 60.0;
    double following_distance_m = 25.0;
    double water_film_depth_m = 0.002;
    double tyre_displaced_water_kg_s = 4.0;
    double relative_humidity = 0.9;
    F1FidelityVector3 ambient_wind_m_s{};
    double wake_turbulence = 0.4;
    double ambient_light_lux = 1000.0;
};

struct F1SprayOpticsState {
    double time_s = 0.0;
    std::vector<F1SprayDropletBin> bins;
    double deposited_water_kg_m2 = 0.0;
};

struct F1SprayVisibilityResult {
    F1SprayOpticsState state;
    double extinction_coefficient_m_inv = 0.0;
    double optical_depth = 0.0;
    double meteorological_visibility_m = 10000.0;
    double contrast_transmission = 1.0;
    double rain_light_detection_probability = 1.0;
    double camera_detection_probability = 1.0;
    double closing_speed_uncertainty_m_s = 0.0;
    double suspended_water_kg_m3 = 0.0;
    bool finite = true;
};

class F1SprayOpticsVisibilityPhysics {
public:
    explicit F1SprayOpticsVisibilityPhysics(F1SprayOpticsConfiguration configuration = {});
    [[nodiscard]] F1SprayOpticsState make_initial_state() const;
    [[nodiscard]] F1SprayVisibilityResult step(
        const F1SprayOpticsInput& input,
        const F1SprayOpticsState& state) const;

private:
    F1SprayOpticsConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Carbon-brake tribology and three-dimensional thermomechanics.
// -----------------------------------------------------------------------------

struct F1CarbonBrakeConfiguration {
    std::size_t radial_segments = 8;
    std::size_t axial_layers = 3;
    double inner_radius_m = 0.14;
    double outer_radius_m = 0.165;
    double disc_thickness_m = 0.032;
    double disc_density_kg_m3 = 1800.0;
    double disc_heat_capacity_j_kg_k = 900.0;
    double radial_conductivity_w_m_k = 35.0;
    double axial_conductivity_w_m_k = 12.0;
    double convection_w_m2_k = 180.0;
    double emissivity = 0.82;
    double cold_friction = 0.35;
    double hot_friction = 0.58;
    double optimum_temperature_k = 950.0;
    double transfer_layer_rate_s = 0.15;
    double glazing_temperature_k = 1250.0;
    double oxidation_activation_k = 9000.0;
    double wear_energy_j_m3 = 5.0e10;
    double elastic_modulus_pa = 35.0e9;
    double thermal_expansion_k_inv = 2.0e-6;
    double piston_area_m2 = 0.0032;
    double pad_area_m2 = 0.011;

    void validate() const;
};

struct F1CarbonBrakeState {
    double time_s = 0.0;
    std::vector<double> temperature_k;
    std::vector<double> wear_depth_m;
    std::vector<double> transfer_layer_fraction;
    double disc_coning_rad = 0.0;
    double disc_runout_m = 0.0;
    double pad_knockback_m = 0.0;
    double oxidation_damage = 0.0;
};

struct F1CarbonBrakeInput {
    double time_step_s = 0.001;
    double hydraulic_pressure_pa = 0.0;
    double wheel_speed_rad_s = 0.0;
    double vehicle_speed_m_s = 0.0;
    double ambient_temperature_k = 300.0;
    double cooling_air_speed_m_s = 20.0;
    double water_mass_flow_kg_s = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
};

struct F1CarbonBrakeResult {
    F1CarbonBrakeState state;
    double brake_torque_nm = 0.0;
    double friction_coefficient = 0.0;
    double heat_generation_w = 0.0;
    double maximum_temperature_k = 0.0;
    double average_temperature_k = 0.0;
    double maximum_wear_depth_m = 0.0;
    double judder_amplitude_nm = 0.0;
    double fluid_displacement_m3 = 0.0;
    double crack_risk = 0.0;
    bool finite = true;
};

class F1CarbonBrakeTribologyThermomechanics {
public:
    explicit F1CarbonBrakeTribologyThermomechanics(F1CarbonBrakeConfiguration configuration = {});
    [[nodiscard]] F1CarbonBrakeState make_initial_state(double temperature_k = 300.0) const;
    [[nodiscard]] F1CarbonBrakeResult step(
        const F1CarbonBrakeInput& input,
        const F1CarbonBrakeState& state) const;

private:
    F1CarbonBrakeConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Active-aero mechatronics and nonlinear ground-effect stability.
// -----------------------------------------------------------------------------

enum class F1ActiveAeroFault {
    None,
    SensorDisagreement,
    ActuatorJam,
    MotorOvertemperature,
    RunawayCommand,
    PositionSensorFailure
};

struct F1ActiveAeroMechatronicsConfiguration {
    double minimum_angle_rad = 0.0;
    double maximum_angle_rad = 0.35;
    double maximum_rate_rad_s = 3.0;
    double actuator_inertia_kg_m2 = 0.025;
    double motor_torque_constant_nm_a = 0.11;
    double motor_resistance_ohm = 0.18;
    double linkage_stiffness_nm_rad = 1600.0;
    double linkage_damping_nm_s_rad = 12.0;
    double hinge_friction_nm = 2.0;
    double thermal_capacity_j_k = 850.0;
    double cooling_w_k = 10.0;
    double maximum_temperature_k = 410.0;
    double safe_angle_rad = 0.0;
    double controller_kp = 120.0;
    double controller_kd = 10.0;

    void validate() const;
};

struct F1GroundEffectStabilityConfiguration {
    double reference_ride_height_m = 0.045;
    double minimum_ride_height_m = 0.018;
    double base_downforce_n = 12000.0;
    double ride_height_sensitivity_per_m = 18.0;
    double pitch_sensitivity_per_rad = 2.5;
    double stall_ride_height_m = 0.022;
    double recovery_ride_height_m = 0.030;
    double stall_time_constant_s = 0.025;
    double recovery_time_constant_s = 0.060;
    double aerodynamic_lag_s = 0.018;
    double floor_modal_stiffness_n_m = 1.8e6;
    double floor_modal_damping_n_s_m = 8000.0;
    double floor_modal_mass_kg = 25.0;
    double bump_stop_stiffness_n_m = 2.5e6;

    void validate() const;
};

struct F1ActiveAeroGroundEffectState {
    double time_s = 0.0;
    double actuator_angle_rad = 0.0;
    double actuator_rate_rad_s = 0.0;
    double motor_temperature_k = 300.0;
    double stall_fraction = 0.0;
    double aerodynamic_force_n = 0.0;
    double floor_displacement_m = 0.0;
    double floor_velocity_m_s = 0.0;
    double oscillation_energy_j = 0.0;
};

struct F1ActiveAeroGroundEffectInput {
    double time_step_s = 0.001;
    double requested_angle_rad = 0.0;
    std::array<double, 3> angle_sensor_rad{};
    double vehicle_speed_m_s = 60.0;
    double front_ride_height_m = 0.04;
    double rear_ride_height_m = 0.05;
    double pitch_rad = 0.0;
    double heave_velocity_m_s = 0.0;
    double aerodynamic_hinge_moment_nm = 0.0;
    double ambient_temperature_k = 300.0;
    F1ActiveAeroFault injected_fault = F1ActiveAeroFault::None;
};

struct F1ActiveAeroGroundEffectResult {
    F1ActiveAeroGroundEffectState state;
    double commanded_angle_rad = 0.0;
    double motor_current_a = 0.0;
    double actuator_power_w = 0.0;
    double downforce_n = 0.0;
    double drag_delta_n = 0.0;
    double stall_fraction = 0.0;
    double porpoising_risk = 0.0;
    double sensor_disagreement_rad = 0.0;
    bool degraded_mode = false;
    bool safe_state_active = false;
    bool finite = true;
};

class F1ActiveAeroGroundEffectTwin {
public:
    F1ActiveAeroGroundEffectTwin(
        F1ActiveAeroMechatronicsConfiguration aero_configuration = {},
        F1GroundEffectStabilityConfiguration ground_configuration = {});
    [[nodiscard]] F1ActiveAeroGroundEffectState make_initial_state() const;
    [[nodiscard]] F1ActiveAeroGroundEffectResult step(
        const F1ActiveAeroGroundEffectInput& input,
        const F1ActiveAeroGroundEffectState& state) const;

private:
    F1ActiveAeroMechatronicsConfiguration aero_configuration_;
    F1GroundEffectStabilityConfiguration ground_configuration_;
};

// -----------------------------------------------------------------------------
// Sustainable-fuel spray, pre-chamber combustion, and turbo rotordynamics.
// -----------------------------------------------------------------------------

struct F1SustainableFuelConfiguration {
    double lower_heating_value_j_kg = 42.0e6;
    double stoichiometric_air_fuel_ratio = 14.2;
    double latent_heat_j_kg = 350000.0;
    double density_kg_m3 = 760.0;
    double laminar_flame_speed_m_s = 0.45;
    double octane_index = 102.0;
    double aromatic_fraction = 0.15;
    double oxygen_mass_fraction = 0.03;

    void validate() const;
};

struct F1TurboRotordynamicsConfiguration {
    double rotor_inertia_kg_m2 = 1.2e-4;
    double shaft_stiffness_nm_rad = 1200.0;
    double shaft_damping_nm_s_rad = 0.8;
    double bearing_stiffness_n_m = 2.5e6;
    double bearing_damping_n_s_m = 1200.0;
    double imbalance_kg_m = 2.0e-7;
    double critical_speed_rad_s = 10500.0;
    double maximum_speed_rad_s = 13000.0;
    double compressor_efficiency = 0.72;
    double turbine_efficiency = 0.75;

    void validate() const;
};

struct F1SustainablePowerUnitState {
    double time_s = 0.0;
    double liquid_fuel_mass_kg = 0.0;
    double vapor_fuel_mass_kg = 0.0;
    double prechamber_pressure_pa = 200000.0;
    double prechamber_temperature_k = 700.0;
    double burn_fraction = 0.0;
    double cylinder_temperature_k = 700.0;
    double cylinder_pressure_pa = 200000.0;
    double turbo_speed_rad_s = 5000.0;
    double turbo_twist_rad = 0.0;
    double turbo_twist_rate_rad_s = 0.0;
    double rotor_x_m = 0.0;
    double rotor_y_m = 0.0;
    double rotor_vx_m_s = 0.0;
    double rotor_vy_m_s = 0.0;
    double bearing_temperature_k = 340.0;
};

struct F1SustainablePowerUnitInput {
    double time_step_s = 0.0001;
    double engine_speed_rad_s = 1000.0;
    double injected_fuel_kg_s = 0.002;
    double air_mass_flow_kg_s = 0.12;
    double manifold_pressure_pa = 250000.0;
    double manifold_temperature_k = 330.0;
    double exhaust_pressure_pa = 350000.0;
    double exhaust_temperature_k = 1050.0;
    double spark_timing_rad_btdc = 0.25;
    double throttle_fraction = 1.0;
    double wastegate_fraction = 0.2;
    double oil_pressure_pa = 400000.0;
    double oil_temperature_k = 390.0;
};

struct F1SustainablePowerUnitResult {
    F1SustainablePowerUnitState state;
    double indicated_torque_nm = 0.0;
    double brake_torque_nm = 0.0;
    double combustion_efficiency = 0.0;
    double lambda = 1.0;
    double evaporation_rate_kg_s = 0.0;
    double prechamber_jet_energy_j = 0.0;
    double knock_probability = 0.0;
    double particulate_mass_rate_kg_s = 0.0;
    double nox_mass_rate_kg_s = 0.0;
    double compressor_pressure_ratio = 1.0;
    double turbo_bearing_load_n = 0.0;
    double turbo_vibration_m = 0.0;
    double turbo_failure_risk = 0.0;
    bool finite = true;
};

class F1SustainableFuelCombustionTurboTwin {
public:
    F1SustainableFuelCombustionTurboTwin(
        F1SustainableFuelConfiguration fuel_configuration = {},
        F1TurboRotordynamicsConfiguration turbo_configuration = {});
    [[nodiscard]] F1SustainablePowerUnitState make_initial_state() const;
    [[nodiscard]] F1SustainablePowerUnitResult step(
        const F1SustainablePowerUnitInput& input,
        const F1SustainablePowerUnitState& state) const;

private:
    F1SustainableFuelConfiguration fuel_configuration_;
    F1TurboRotordynamicsConfiguration turbo_configuration_;
};

// -----------------------------------------------------------------------------
// Switching-level ERS, MGU-K, inverter, and EMC.
// -----------------------------------------------------------------------------

struct F1SwitchingErsConfiguration {
    double dc_bus_voltage_v = 800.0;
    double dc_link_capacitance_f = 0.004;
    double phase_resistance_ohm = 0.012;
    double phase_inductance_h = 0.00018;
    double flux_linkage_wb = 0.075;
    std::size_t pole_pairs = 4;
    double rotor_inertia_kg_m2 = 0.015;
    double switching_frequency_hz = 20000.0;
    double dead_time_s = 1.0e-6;
    double transistor_on_resistance_ohm = 0.002;
    double switching_energy_j = 0.004;
    double inverter_thermal_capacity_j_k = 1200.0;
    double inverter_cooling_w_k = 80.0;
    double common_mode_capacitance_f = 2.0e-9;
    double harness_transfer_db = -35.0;

    void validate() const;
};

struct F1SwitchingErsState {
    double time_s = 0.0;
    std::array<double, 3> phase_current_a{};
    double rotor_speed_rad_s = 0.0;
    double rotor_angle_rad = 0.0;
    double dc_bus_voltage_v = 800.0;
    double inverter_temperature_k = 320.0;
    double cumulative_switching_energy_j = 0.0;
};

struct F1SwitchingErsInput {
    double time_step_s = 2.0e-6;
    double torque_command_nm = 0.0;
    double mechanical_load_torque_nm = 0.0;
    double battery_current_limit_a = 500.0;
    double coolant_temperature_k = 310.0;
    double sensor_frequency_hz = 1000.0;
    double telemetry_frequency_hz = 2.4e9;
};

struct F1SwitchingErsResult {
    F1SwitchingErsState state;
    std::array<double, 3> gate_duty{};
    double electromagnetic_torque_nm = 0.0;
    double dc_current_a = 0.0;
    double electrical_power_w = 0.0;
    double mechanical_power_w = 0.0;
    double conduction_loss_w = 0.0;
    double switching_loss_w = 0.0;
    double common_mode_voltage_v = 0.0;
    double common_mode_current_a = 0.0;
    double sensor_interference_v_rms = 0.0;
    double telemetry_interference_dbm = -200.0;
    double bearing_current_a = 0.0;
    bool current_limited = false;
    bool thermal_derated = false;
    bool finite = true;
};

class F1SwitchingLevelErsEmcTwin {
public:
    explicit F1SwitchingLevelErsEmcTwin(F1SwitchingErsConfiguration configuration = {});
    [[nodiscard]] F1SwitchingErsState make_initial_state() const;
    [[nodiscard]] F1SwitchingErsResult step(
        const F1SwitchingErsInput& input,
        const F1SwitchingErsState& state) const;

private:
    F1SwitchingErsConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Bayesian CFD-tunnel-track aerodynamic field fusion.
// -----------------------------------------------------------------------------

enum class F1AeroEvidenceSource {
    Cfd,
    WindTunnel,
    Track
};

struct F1AeroFieldBasisPoint {
    F1FidelityVector3 position_m{};
    double prior_mean = 0.0;
    double prior_standard_deviation = 0.1;
};

struct F1AeroEvidenceObservation {
    std::string id;
    F1AeroEvidenceSource source = F1AeroEvidenceSource::Cfd;
    double value = 0.0;
    double standard_deviation = 0.01;
    std::vector<double> sensitivity;
    double operating_speed_m_s = 0.0;
    double ride_height_m = 0.0;
    double yaw_rad = 0.0;

    void validate(std::size_t field_size) const;
};

struct F1AeroCandidateTest {
    std::string id;
    F1AeroEvidenceSource source = F1AeroEvidenceSource::WindTunnel;
    double expected_standard_deviation = 0.01;
    double cost = 1.0;
    std::vector<double> sensitivity;

    void validate(std::size_t field_size) const;
};

struct F1AeroFusionConfiguration {
    std::vector<F1AeroFieldBasisPoint> field_basis;
    double spatial_correlation_length_m = 0.5;
    double cfd_bias_standard_deviation = 0.08;
    double tunnel_bias_standard_deviation = 0.04;
    double track_bias_standard_deviation = 0.06;
    double covariance_jitter = 1.0e-10;

    void validate() const;
};

struct F1AeroFusionResult {
    std::vector<double> posterior_mean;
    std::vector<double> posterior_covariance;
    std::map<F1AeroEvidenceSource, double> source_bias_mean;
    std::map<F1AeroEvidenceSource, double> source_bias_standard_deviation;
    std::vector<double> predicted_observations;
    std::vector<double> normalized_residuals;
    double prior_log_likelihood = 0.0;
    double posterior_log_likelihood = 0.0;
    double effective_information_gain = 0.0;
    std::string recommended_test_id;
    double recommended_test_information_per_cost = 0.0;
    bool finite = true;
};

class F1BayesianAeroFieldFusion {
public:
    explicit F1BayesianAeroFieldFusion(F1AeroFusionConfiguration configuration);
    [[nodiscard]] const F1AeroFusionConfiguration& configuration() const noexcept;
    [[nodiscard]] F1AeroFusionResult fuse(
        const std::vector<F1AeroEvidenceObservation>& observations,
        const std::vector<F1AeroCandidateTest>& candidate_tests = {}) const;

private:
    F1AeroFusionConfiguration configuration_;
};

}  // namespace aesim::advanced

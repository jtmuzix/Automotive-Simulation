#pragma once

#include "aesim/advanced/formula_one_frontier_laboratory.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Fuel, lubrication, scavenge, and mass migration.
// -----------------------------------------------------------------------------
struct F1FuelCellGeometry {
    double length_m = 1.2;
    double width_m = 0.55;
    double height_m = 0.38;
    double collector_capacity_kg = 2.5;
    double pickup_x_m = -0.35;
    double pickup_y_m = 0.0;
    double baffle_time_constant_s = 0.35;
    void validate() const;
};

struct F1DrySumpConfiguration {
    double oil_mass_kg = 7.0;
    double tank_capacity_kg = 9.0;
    double pressure_pump_flow_kg_s = 0.42;
    double scavenge_flow_kg_s = 0.55;
    double relief_pressure_pa = 650000.0;
    double gallery_resistance_pa_s_kg = 900000.0;
    double minimum_safe_pressure_pa = 250000.0;
    double oil_heat_capacity_j_kg_k = 2000.0;
    double cooling_w_k = 220.0;
    void validate() const;
};

struct F1FuelLubricationSample {
    double time_s = 0.0;
    double longitudinal_accel_m_s2 = 0.0;
    double lateral_accel_m_s2 = 0.0;
    double vertical_accel_m_s2 = 9.80665;
    double engine_fuel_flow_kg_s = 0.0;
    double engine_speed_rad_s = 0.0;
    double oil_heat_w = 0.0;
    double ambient_temperature_k = 300.0;
    void validate() const;
};

struct F1FuelLubricationState {
    double time_s = 0.0;
    double fuel_mass_kg = 0.0;
    double collector_mass_kg = 0.0;
    double fuel_centroid_x_m = 0.0;
    double fuel_centroid_y_m = 0.0;
    double pickup_coverage = 1.0;
    double fuel_supply_pressure_pa = 0.0;
    double oil_gallery_pressure_pa = 0.0;
    double oil_temperature_k = 0.0;
    double oil_aeration_fraction = 0.0;
    double longitudinal_cg_shift_m = 0.0;
    double lateral_cg_shift_m = 0.0;
    double yaw_inertia_kg_m2 = 0.0;
    bool fuel_starvation = false;
    bool oil_starvation = false;
};

struct F1FuelLubricationResult {
    std::vector<F1FuelLubricationState> history;
    double fuel_consumed_kg = 0.0;
    double minimum_pickup_coverage = 1.0;
    double minimum_oil_pressure_pa = 0.0;
    double maximum_oil_temperature_k = 0.0;
    double maximum_cg_shift_m = 0.0;
    bool qualified = false;
    std::string evidence_sha256;
};

class F1FuelLubricationMassMigrationTwin {
public:
    F1FuelLubricationResult simulate(const F1FuelCellGeometry& fuel_cell,
                                     const F1DrySumpConfiguration& dry_sump,
                                     double initial_fuel_mass_kg,
                                     double initial_oil_temperature_k,
                                     double dry_vehicle_mass_kg,
                                     double dry_vehicle_yaw_inertia_kg_m2,
                                     const std::vector<F1FuelLubricationSample>& samples) const;
};

// -----------------------------------------------------------------------------
// Tyre construction, carcass, rim thermal, and contact patch.
// -----------------------------------------------------------------------------
enum class F1TyreLayerKind { Tread, Belt, Carcass, Sidewall, InnerLiner, Bead };

struct F1TyreLayer {
    F1TyreLayerKind kind = F1TyreLayerKind::Tread;
    double thickness_m = 0.005;
    double elastic_modulus_pa = 8.0e6;
    double loss_factor = 0.08;
    double density_kg_m3 = 1100.0;
    double cord_angle_deg = 0.0;
    double thermal_conductivity_w_m_k = 0.2;
    double heat_capacity_j_kg_k = 1800.0;
    void validate() const;
};

struct F1TyreConstruction {
    double unloaded_radius_m = 0.36;
    double section_width_m = 0.405;
    double rim_radius_m = 0.23;
    double inflation_pressure_pa = 145000.0;
    double gas_mass_kg = 0.12;
    std::vector<F1TyreLayer> layers;
    void validate() const;
};

struct F1TyreStructuralOperatingPoint {
    double vertical_load_n = 3500.0;
    double speed_m_s = 60.0;
    double slip_ratio = 0.0;
    double slip_angle_rad = 0.0;
    double camber_rad = 0.0;
    double road_temperature_k = 303.0;
    double rim_temperature_k = 333.0;
    double brake_radiation_w = 0.0;
    double water_depth_m = 0.0;
    double time_step_s = 0.01;
    void validate() const;
};

struct F1TyreContactResult {
    double loaded_radius_m = 0.0;
    double contact_length_m = 0.0;
    double contact_width_m = 0.0;
    double peak_contact_pressure_pa = 0.0;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double camber_thrust_n = 0.0;
    double rolling_resistance_n = 0.0;
    double carcass_temperature_k = 0.0;
    double tread_temperature_k = 0.0;
    double rim_temperature_k = 0.0;
    double gas_pressure_pa = 0.0;
    double hysteresis_power_w = 0.0;
    double aquaplaning_margin_m_s = 0.0;
    double structural_damage_increment = 0.0;
    bool contact_converged = false;
    bool structurally_qualified = false;
    std::string evidence_sha256;
};

class F1TyreConstructionLaboratory {
public:
    F1TyreContactResult evaluate(const F1TyreConstruction& tyre,
                                 const F1TyreStructuralOperatingPoint& operating,
                                 double initial_tread_temperature_k,
                                 double initial_carcass_temperature_k) const;
};

// -----------------------------------------------------------------------------
// Hydraulic and pneumatic actuation network.
// -----------------------------------------------------------------------------
enum class F1FluidNodeKind { Reservoir, Pump, Accumulator, Manifold, Actuator };

struct F1FluidNode {
    std::string id;
    F1FluidNodeKind kind = F1FluidNodeKind::Manifold;
    double volume_m3 = 1.0e-4;
    double initial_pressure_pa = 101325.0;
    double bulk_modulus_pa = 1.4e9;
    double pump_flow_m3_s = 0.0;
    double relief_pressure_pa = 1.0e7;
    double accumulator_precharge_pa = 0.0;
    double actuator_area_m2 = 0.0;
    double actuator_mass_kg = 0.0;
    double actuator_stroke_m = 0.0;
    void validate() const;
};

struct F1FluidEdge {
    std::string id;
    std::string from;
    std::string to;
    double flow_coefficient_m3_s_sqrt_pa = 1.0e-8;
    double leakage_m3_s_pa = 0.0;
    double valve_command = 1.0;
    bool check_valve = false;
    void validate() const;
};

struct F1ActuationDemand {
    double time_s = 0.0;
    std::string actuator_node;
    double target_position_m = 0.0;
    double external_force_n = 0.0;
    void validate() const;
};

struct F1FluidNetworkSample {
    double time_s = 0.0;
    std::map<std::string, double> pressure_pa;
    std::map<std::string, double> flow_m3_s;
    std::map<std::string, double> actuator_position_m;
    std::map<std::string, double> actuator_velocity_m_s;
    double pump_power_w = 0.0;
    double leaked_volume_m3 = 0.0;
};

struct F1FluidNetworkResult {
    std::vector<F1FluidNetworkSample> history;
    double minimum_actuator_pressure_pa = 0.0;
    double total_pump_energy_j = 0.0;
    double total_leaked_volume_m3 = 0.0;
    bool cavitation_detected = false;
    bool demands_met = false;
    std::string evidence_sha256;
};

class F1HydraulicPneumaticNetworkLaboratory {
public:
    F1FluidNetworkResult simulate(const std::vector<F1FluidNode>& nodes,
                                  const std::vector<F1FluidEdge>& edges,
                                  const std::vector<F1ActuationDemand>& demands,
                                  double duration_s,
                                  double time_step_s,
                                  double fluid_density_kg_m3,
                                  double fluid_viscosity_pa_s) const;
};

// -----------------------------------------------------------------------------
// Laser-scanned track, kerb, plank, and contact events.
// -----------------------------------------------------------------------------
struct F1TrackHeightField {
    std::size_t nx = 0;
    std::size_t ny = 0;
    double origin_x_m = 0.0;
    double origin_y_m = 0.0;
    double spacing_x_m = 0.1;
    double spacing_y_m = 0.1;
    std::vector<double> heights_m;
    std::vector<double> friction;
    void validate() const;
    double height(double x_m, double y_m) const;
    double local_friction(double x_m, double y_m) const;
};

struct F1TrackVehicleSample {
    double time_s = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double yaw_rad = 0.0;
    double speed_m_s = 0.0;
    double heave_m = 0.0;
    double roll_rad = 0.0;
    double pitch_rad = 0.0;
    void validate() const;
};

enum class F1TrackContactKind { WheelImpact, WheelUnload, PlankStrike, FloorStrike, KerbStrike };

struct F1TrackContactEvent {
    double time_s = 0.0;
    F1TrackContactKind kind = F1TrackContactKind::WheelImpact;
    std::string location;
    double penetration_m = 0.0;
    double normal_velocity_m_s = 0.0;
    double impulse_n_s = 0.0;
    double damage_increment = 0.0;
};

struct F1TrackContactResult {
    std::vector<F1TrackContactEvent> events;
    double plank_wear_mm = 0.0;
    double floor_damage = 0.0;
    double maximum_wheel_vertical_accel_m_s2 = 0.0;
    double minimum_wheel_load_fraction = 1.0;
    double cumulative_contact_energy_j = 0.0;
    bool plank_legal = true;
    std::string evidence_sha256;
};

class F1LaserScannedTrackContactTwin {
public:
    F1TrackContactResult simulate(const F1TrackHeightField& track,
                                  const std::vector<F1TrackVehicleSample>& trajectory,
                                  double wheelbase_m,
                                  double front_track_m,
                                  double rear_track_m,
                                  double nominal_ride_height_m,
                                  double plank_thickness_mm,
                                  double corner_unsprung_mass_kg,
                                  double tyre_vertical_stiffness_n_m) const;
};

// -----------------------------------------------------------------------------
// Parc-ferme configuration, seals, and setup provenance.
// -----------------------------------------------------------------------------
enum class F1ParcFermePhase { FreePractice, Qualifying, ParcFerme, Sprint, Race, PostRace };
enum class F1ConfigurationChangeReason { Setup, Weather, DamageRepair, LikeForLike, Safety, Software, Inspection };

struct F1ConfigurationItem {
    std::string key;
    std::string value;
    std::string serial;
    bool sealed = false;
    bool safety_critical = false;
    void validate() const;
};

struct F1ConfigurationTransition {
    double time_s = 0.0;
    F1ParcFermePhase phase = F1ParcFermePhase::FreePractice;
    std::string item_key;
    std::string new_value;
    std::string new_serial;
    F1ConfigurationChangeReason reason = F1ConfigurationChangeReason::Setup;
    std::string operator_id;
    std::string approval_id;
    std::string measured_hash;
    void validate() const;
};

struct F1ConfigurationAuditEntry {
    double time_s = 0.0;
    std::string item_key;
    std::string old_value;
    std::string new_value;
    bool legal = false;
    std::string reason;
    std::string chain_hash;
};

struct F1ParcFermeAuditResult {
    std::map<std::string, F1ConfigurationItem> final_configuration;
    std::vector<F1ConfigurationAuditEntry> audit;
    std::vector<std::string> violations;
    bool configuration_consistent = false;
    std::string evidence_sha256;
};

class F1ParcFermeProvenanceEngine {
public:
    F1ParcFermeAuditResult audit(const std::vector<F1ConfigurationItem>& initial,
                                 const std::vector<F1ConfigurationTransition>& transitions,
                                 const std::set<std::string>& approved_authorities) const;
};

// -----------------------------------------------------------------------------
// Season-long component, penalty, spare, and logistics optimization.
// -----------------------------------------------------------------------------
struct F1SeasonEvent {
    std::string id;
    int round = 0;
    double championship_value = 1.0;
    double freight_distance_km = 0.0;
    bool sprint = false;
    void validate() const;
};

struct F1SeasonComponent {
    std::string serial;
    std::string family;
    int maximum_events = 1;
    int used_events = 0;
    double failure_probability_per_event = 0.01;
    double performance_delta_s = 0.0;
    double repair_days = 0.0;
    double manufacturing_days = 0.0;
    double mass_kg = 0.0;
    double freight_cost_per_km_kg = 0.0;
    bool available = true;
    void validate() const;
};

struct F1PenaltyRule {
    std::string family;
    int free_allocation = 1;
    double grid_penalty_positions = 10.0;
    double expected_points_cost_per_position = 0.25;
    void validate() const;
};

struct F1SeasonAssignment {
    std::string event_id;
    std::string family;
    std::string serial;
    bool new_allocation = false;
    double expected_failure_probability = 0.0;
    double expected_points_delta = 0.0;
    double freight_cost = 0.0;
};

struct F1SeasonOptimizationResult {
    std::vector<F1SeasonAssignment> assignments;
    double expected_championship_points = 0.0;
    double expected_penalty_cost_points = 0.0;
    double expected_failure_cost_points = 0.0;
    double freight_cost = 0.0;
    std::map<std::string, int> new_allocations;
    bool feasible = false;
    std::string evidence_sha256;
};

class F1SeasonComponentLogisticsOptimizer {
public:
    F1SeasonOptimizationResult optimize(const std::vector<F1SeasonEvent>& events,
                                        const std::vector<F1SeasonComponent>& components,
                                        const std::vector<F1PenaltyRule>& penalties,
                                        double baseline_points_per_event,
                                        double failure_points_cost,
                                        std::size_t beam_width = 2000) const;
};

// -----------------------------------------------------------------------------
// Composite manufacturing, cure, NDT, and repair qualification.
// -----------------------------------------------------------------------------
struct F1CompositeCureCyclePoint {
    double time_s = 0.0;
    double autoclave_temperature_k = 293.15;
    double pressure_pa = 101325.0;
    void validate() const;
};

struct F1CompositeManufacturingInput {
    double laminate_thickness_m = 0.004;
    double resin_fraction = 0.35;
    double activation_energy_j_mol = 65000.0;
    double pre_exponential_1_s = 2.0e7;
    double reaction_order = 1.2;
    double exotherm_j_kg = 250000.0;
    double heat_capacity_j_kg_k = 1200.0;
    double tool_heat_transfer_w_m2_k = 60.0;
    double initial_void_fraction = 0.04;
    double wrinkle_angle_deg = 0.0;
    std::vector<F1CompositeCureCyclePoint> cycle;
    void validate() const;
};

enum class F1NDTMethod { Ultrasonic, Thermography, Shearography, ComputedTomography };

struct F1NDTInspection {
    F1NDTMethod method = F1NDTMethod::Ultrasonic;
    double sensitivity_m = 0.001;
    double false_positive_probability = 0.01;
    void validate() const;
};

struct F1CompositeDefect {
    std::string id;
    double depth_m = 0.0;
    double area_m2 = 0.0;
    double severity = 0.0;
    bool detected = false;
};

struct F1CompositeRepairPlan {
    double removed_area_m2 = 0.0;
    double scarf_ratio = 30.0;
    double patch_thickness_m = 0.0;
    double adhesive_strength_pa = 25e6;
    double cure_quality = 1.0;
    void validate() const;
};

struct F1CompositeManufacturingResult {
    double final_degree_of_cure = 0.0;
    double peak_temperature_k = 0.0;
    double final_void_fraction = 0.0;
    double residual_stress_pa = 0.0;
    double stiffness_retention = 0.0;
    double strength_retention = 0.0;
    std::vector<F1CompositeDefect> defects;
    double probability_of_detection = 0.0;
    double repaired_strength_retention = 0.0;
    bool cure_qualified = false;
    bool inspection_qualified = false;
    bool repair_qualified = false;
    std::string evidence_sha256;
};

class F1CompositeManufacturingLaboratory {
public:
    F1CompositeManufacturingResult manufacture_inspect_repair(
        const F1CompositeManufacturingInput& input,
        const F1NDTInspection& inspection,
        const std::optional<F1CompositeRepairPlan>& repair,
        std::uint64_t seed = 1) const;
};

// -----------------------------------------------------------------------------
// Trackside weather nowcasting and wet-line prediction.
// -----------------------------------------------------------------------------
struct F1WeatherObservation {
    double time_s = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double rain_rate_mm_h = 0.0;
    double air_temperature_k = 293.15;
    double track_temperature_k = 293.15;
    double wind_x_m_s = 0.0;
    double wind_y_m_s = 0.0;
    double humidity = 0.5;
    double quality = 1.0;
    void validate() const;
};

struct F1WeatherTrackCell {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    double drainage_mm_h = 5.0;
    double evaporation_mm_h = 1.0;
    double initial_water_mm = 0.0;
    double dry_grip = 1.0;
    void validate() const;
};

struct F1WeatherCellForecast {
    std::string id;
    std::vector<double> rain_rate_mm_h;
    std::vector<double> water_depth_mm;
    std::vector<double> grip;
    std::vector<double> spray_index;
};

struct F1WeatherNowcastResult {
    double time_step_s = 0.0;
    std::vector<double> forecast_times_s;
    std::vector<F1WeatherCellForecast> cells;
    double earliest_rain_arrival_s = 0.0;
    double intermediate_crossover_s = 0.0;
    double wet_crossover_s = 0.0;
    double slick_crossover_s = 0.0;
    double confidence = 0.0;
    std::string evidence_sha256;
};

class F1TracksideWeatherNowcaster {
public:
    F1WeatherNowcastResult forecast(const std::vector<F1WeatherObservation>& observations,
                                    const std::vector<F1WeatherTrackCell>& cells,
                                    double start_time_s,
                                    double horizon_s,
                                    double time_step_s,
                                    double spatial_scale_m) const;
};

// -----------------------------------------------------------------------------
// Pit-wall organization, radio, and human decision twin.
// -----------------------------------------------------------------------------
struct F1PitWallRole {
    std::string id;
    std::set<std::string> competencies;
    double processing_rate_per_s = 1.0;
    double fatigue = 0.0;
    double stress = 0.0;
    double authority = 0.5;
    void validate() const;
};

struct F1PitWallMessage {
    double time_s = 0.0;
    std::string sender;
    std::string recipient;
    std::string topic;
    double priority = 0.5;
    double complexity = 0.5;
    double ambiguity = 0.0;
    double validity_window_s = 10.0;
    bool requires_acknowledgement = false;
    void validate() const;
};

struct F1PitWallDecisionRequest {
    double time_s = 0.0;
    std::string topic;
    std::set<std::string> required_competencies;
    double deadline_s = 10.0;
    double strategic_value = 1.0;
    void validate() const;
};

struct F1PitWallDecisionOutcome {
    std::string topic;
    double request_time_s = 0.0;
    double decision_time_s = 0.0;
    double confidence = 0.0;
    double expected_value_retained = 0.0;
    bool deadline_met = false;
    std::vector<std::string> consulted_roles;
};

struct F1PitWallSimulationResult {
    std::vector<F1PitWallDecisionOutcome> decisions;
    std::map<std::string, double> final_workload;
    std::size_t delivered_messages = 0;
    std::size_t lost_messages = 0;
    std::size_t ambiguous_messages = 0;
    double mean_decision_latency_s = 0.0;
    double total_strategic_value_retained = 0.0;
    bool operationally_resilient = false;
    std::string evidence_sha256;
};

class F1PitWallHumanDecisionTwin {
public:
    F1PitWallSimulationResult simulate(const std::vector<F1PitWallRole>& roles,
                                       const std::vector<F1PitWallMessage>& messages,
                                       const std::vector<F1PitWallDecisionRequest>& decisions,
                                       double radio_loss_probability,
                                       double base_radio_latency_s,
                                       std::uint64_t seed = 1) const;
};

// -----------------------------------------------------------------------------
// Wheel-corner structure, bearing, fastener, and wheel-nut twin.
// -----------------------------------------------------------------------------
struct F1WheelCornerConfiguration {
    double wheel_mass_kg = 12.0;
    double upright_mass_kg = 8.0;
    double rim_radial_stiffness_n_m = 2.5e7;
    double upright_stiffness_n_m = 5.0e7;
    double bearing_preload_n = 2500.0;
    double bearing_dynamic_capacity_n = 45000.0;
    double bearing_friction_coefficient = 0.002;
    double bearing_thermal_capacity_j_k = 7000.0;
    double bearing_cooling_w_k = 80.0;
    double wheel_nut_thread_pitch_m = 0.002;
    double wheel_nut_friction = 0.12;
    double wheel_nut_clamp_target_n = 80000.0;
    double wheel_nut_clamp_minimum_n = 60000.0;
    double fastener_fatigue_limit_n = 120000.0;
    void validate() const;
};

struct F1WheelCornerLoadSample {
    double time_s = 0.0;
    double radial_load_n = 0.0;
    double lateral_load_n = 0.0;
    double longitudinal_load_n = 0.0;
    double brake_torque_n_m = 0.0;
    double wheel_speed_rad_s = 0.0;
    double kerb_impulse_n_s = 0.0;
    double brake_heat_w = 0.0;
    double ambient_temperature_k = 300.0;
    void validate() const;
};

struct F1WheelNutOperation {
    double gun_torque_n_m = 0.0;
    int impacts = 0;
    double seating_gap_m = 0.0;
    double misalignment_rad = 0.0;
    double thread_damage = 0.0;
    void validate() const;
};

struct F1WheelCornerResult {
    double maximum_rim_deflection_m = 0.0;
    double maximum_upright_deflection_m = 0.0;
    double maximum_bearing_temperature_k = 0.0;
    double bearing_l10_revolutions = 0.0;
    double accumulated_fastener_damage = 0.0;
    double wheel_nut_clamp_n = 0.0;
    double wheel_nut_seating_confidence = 0.0;
    double unsafe_release_probability = 0.0;
    bool bearing_qualified = false;
    bool fastener_qualified = false;
    bool wheel_nut_qualified = false;
    std::string evidence_sha256;
};

class F1WheelCornerStructuralLaboratory {
public:
    F1WheelCornerResult evaluate(const F1WheelCornerConfiguration& configuration,
                                 const std::vector<F1WheelCornerLoadSample>& loads,
                                 const F1WheelNutOperation& wheel_nut) const;
};

} // namespace aesim::advanced

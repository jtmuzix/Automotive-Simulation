#pragma once

#include "aesim/advanced/indycar_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// 1. Fuel allotment, gravity refueling, and pit-stop safety
// -----------------------------------------------------------------------------

struct IndyCarFuelAllotmentRule {
  std::string event_id;
  IndyCarCircuitClass circuit = IndyCarCircuitClass::RoadStreet;
  double scheduled_distance_miles = 200.0;
  double regulatory_miles_per_gallon = 3.0;
  double reserve_gallons = 0.0;
  double ambient_temperature_k = 298.15;
  double maximum_fuel_cooling_below_ambient_k = 5.0;
  void validate() const;
  double maximum_event_fuel_gallons() const;
};

struct IndyCarRefuelingSystemConfiguration {
  double onboard_capacity_gallons = 18.5;
  double pit_tank_capacity_gallons = 152.0;
  double gravity_head_m = 2.15;
  double hose_length_m = 3.66;
  double hose_inside_diameter_m = 0.0381;
  double discharge_coefficient = 0.76;
  double dry_break_effective_area_m2 = 0.00105;
  double vent_effective_area_m2 = 0.00082;
  double fuel_density_kg_m3 = 789.0;
  double fuel_dynamic_viscosity_pa_s = 0.0012;
  double minimum_probe_engagement = 0.97;
  double static_grounding_resistance_ohm = 8.0;
  double maximum_grounding_resistance_ohm = 10.0;
  double maximum_safe_spill_l = 0.02;
  void validate() const;
};

struct IndyCarPitStopRequest {
  double arrival_fuel_gallons = 2.0;
  double target_departure_fuel_gallons = 18.0;
  double pit_tank_fuel_gallons = 80.0;
  double ambient_temperature_k = 298.15;
  double fuel_temperature_k = 296.15;
  double car_box_error_m = 0.0;
  double air_jack_raise_s = 0.30;
  double air_jack_lower_s = 0.28;
  double tyre_service_s = 6.5;
  double aeroscreen_service_s = 2.0;
  double fuel_probe_engagement = 1.0;
  double vent_engagement = 1.0;
  double grounding_resistance_ohm = 5.0;
  bool engine_running = true;
  bool fire_extinguisher_ready = true;
  bool fueler_dedicated = true;
  bool fuel_hose_clear_of_tyres = true;
  bool release_command_before_disconnect = false;
  bool emergency_shutoff_functional = true;
  void validate() const;
};

struct IndyCarRefuelingTracePoint {
  double time_s = 0.0;
  double onboard_fuel_gallons = 0.0;
  double pit_tank_fuel_gallons = 0.0;
  double flow_l_s = 0.0;
  double line_pressure_pa = 0.0;
  double cumulative_spill_l = 0.0;
  bool probe_connected = false;
  bool vent_connected = false;
};

struct IndyCarPitStopFuelResult {
  bool compliant = false;
  bool safe_release = false;
  double maximum_event_fuel_gallons = 0.0;
  double transferred_gallons = 0.0;
  double final_onboard_fuel_gallons = 0.0;
  double final_pit_tank_fuel_gallons = 0.0;
  double refueling_time_s = 0.0;
  double total_stop_time_s = 0.0;
  double maximum_flow_l_s = 0.0;
  double spill_l = 0.0;
  double fire_probability = 0.0;
  std::vector<std::string> violations;
  std::vector<IndyCarRefuelingTracePoint> trace;
  std::string evidence_sha256;
};

class IndyCarFuelPitSafetyTwin {
 public:
  IndyCarPitStopFuelResult simulate(const IndyCarFuelAllotmentRule& rule,
                                    const IndyCarRefuelingSystemConfiguration& system,
                                    const IndyCarPitStopRequest& request,
                                    double previously_consumed_event_fuel_gallons,
                                    double integration_step_s = 0.01) const;
};

// -----------------------------------------------------------------------------
// 2. Twin-turbo V6 renewable-ethanol power-unit and durability laboratory
// -----------------------------------------------------------------------------

struct IndyCarTurbochargerConfiguration {
  double compressor_inertia_kg_m2 = 1.8e-5;
  double turbine_inertia_kg_m2 = 1.4e-5;
  double compressor_efficiency_peak = 0.74;
  double turbine_efficiency_peak = 0.72;
  double maximum_shaft_speed_rpm = 155000.0;
  double wastegate_flow_coefficient = 0.68;
  double bearing_friction_coefficient = 1.8e-7;
  void validate() const;
};

struct IndyCarV6EngineConfiguration {
  double displacement_l = 2.2;
  std::size_t cylinders = 6;
  double compression_ratio = 12.5;
  double maximum_speed_rpm = 12000.0;
  double fuel_lower_heating_value_j_kg = 26.8e6;
  double stoichiometric_air_fuel_ratio = 9.0;
  double direct_injection_pressure_pa = 30.0e6;
  double mechanical_efficiency = 0.88;
  double coolant_mass_kg = 12.0;
  double oil_mass_kg = 7.0;
  double coolant_heat_capacity_j_kg_k = 3700.0;
  double oil_heat_capacity_j_kg_k = 2050.0;
  double radiator_ua_w_k = 1650.0;
  double oil_cooler_ua_w_k = 680.0;
  double maximum_coolant_temperature_k = 397.0;
  double maximum_oil_temperature_k = 408.0;
  double maximum_exhaust_temperature_k = 1275.0;
  double maximum_knock_index = 1.0;
  IndyCarTurbochargerConfiguration left_turbo;
  IndyCarTurbochargerConfiguration right_turbo;
  void validate() const;
};

struct IndyCarEngineOperatingSegment {
  double duration_s = 1.0;
  double engine_speed_rpm = 8000.0;
  double throttle_fraction = 0.7;
  double requested_boost_mbar_gauge = 1500.0;
  double vehicle_speed_m_s = 60.0;
  double ambient_temperature_k = 300.0;
  double ambient_pressure_pa = 101325.0;
  double relative_humidity = 0.40;
  double cooling_flow_fraction = 1.0;
  double hybrid_crank_power_w = 0.0;
  void validate() const;
};

struct IndyCarEngineState {
  double time_s = 0.0;
  double crank_power_w = 0.0;
  double crank_torque_n_m = 0.0;
  double fuel_flow_kg_s = 0.0;
  double lambda = 1.0;
  double manifold_pressure_pa = 0.0;
  double left_turbo_speed_rpm = 0.0;
  double right_turbo_speed_rpm = 0.0;
  double coolant_temperature_k = 0.0;
  double oil_temperature_k = 0.0;
  double exhaust_temperature_k = 0.0;
  double knock_index = 0.0;
  double cumulative_fuel_kg = 0.0;
  double cumulative_damage = 0.0;
};

struct IndyCarEngineDurabilityResult {
  bool qualified = false;
  double delivered_energy_j = 0.0;
  double consumed_fuel_kg = 0.0;
  double peak_power_w = 0.0;
  double peak_torque_n_m = 0.0;
  double peak_turbo_speed_rpm = 0.0;
  double peak_coolant_temperature_k = 0.0;
  double peak_oil_temperature_k = 0.0;
  double peak_exhaust_temperature_k = 0.0;
  double knock_damage = 0.0;
  double turbo_damage = 0.0;
  double thermal_damage = 0.0;
  double remaining_life_fraction = 1.0;
  std::vector<std::string> violations;
  std::vector<IndyCarEngineState> history;
  std::string evidence_sha256;
};

class IndyCarTwinTurboV6Laboratory {
 public:
  IndyCarEngineDurabilityResult simulate(const IndyCarV6EngineConfiguration& configuration,
                                         const std::vector<IndyCarEngineOperatingSegment>& segments,
                                         double initial_coolant_temperature_k,
                                         double initial_oil_temperature_k,
                                         double initial_turbo_speed_rpm = 45000.0,
                                         double integration_step_s = 0.002) const;
};

// -----------------------------------------------------------------------------
// 3. Aeroscreen, visibility, cockpit cooling, and debris-impact laboratory
// -----------------------------------------------------------------------------

struct IndyCarAeroscreenConfiguration {
  double projected_area_m2 = 0.42;
  double polycarbonate_thickness_m = 0.012;
  double polycarbonate_density_kg_m3 = 1200.0;
  double optical_refractive_index = 1.586;
  double visible_transmittance = 0.88;
  double haze_fraction = 0.015;
  double titanium_frame_yield_strength_pa = 880.0e6;
  double frame_effective_area_m2 = 0.0018;
  double upper_inlet_area_m2 = 0.0032;
  double lower_inlet_area_m2 = 0.0024;
  double helmet_duct_area_m2 = 0.0012;
  double cockpit_exit_area_m2 = 0.0055;
  double anti_fog_heater_power_w = 0.0;
  void validate() const;
};

struct IndyCarAeroscreenEnvironmentSegment {
  double duration_s = 1.0;
  double vehicle_speed_m_s = 50.0;
  double ambient_temperature_k = 300.0;
  double cockpit_radiant_temperature_k = 322.0;
  double relative_humidity = 0.50;
  double rain_rate_mm_h = 0.0;
  double spray_water_flux_g_m2_s = 0.0;
  double oil_contamination_rate = 0.0;
  double rubber_contamination_rate = 0.0;
  double solar_irradiance_w_m2 = 600.0;
  bool tear_off_removed = false;
  bool wet_condition_inlets_closed = false;
  void validate() const;
};

struct IndyCarDebrisImpact {
  double time_s = 0.0;
  double mass_kg = 0.0;
  double relative_speed_m_s = 0.0;
  double impact_angle_rad = 0.0;
  double contact_diameter_m = 0.01;
  void validate() const;
};

struct IndyCarAeroscreenState {
  double time_s = 0.0;
  double cockpit_air_temperature_k = 0.0;
  double helmet_airflow_kg_s = 0.0;
  double screen_temperature_k = 0.0;
  double water_film_thickness_m = 0.0;
  double contamination_fraction = 0.0;
  double fog_fraction = 0.0;
  double visibility_fraction = 1.0;
  double cumulative_driver_heat_strain = 0.0;
};

struct IndyCarAeroscreenResult {
  bool impact_qualified = false;
  bool visibility_qualified = false;
  bool thermal_qualified = false;
  double minimum_visibility_fraction = 1.0;
  double peak_cockpit_temperature_k = 0.0;
  double minimum_helmet_airflow_kg_s = 0.0;
  double maximum_polycarbonate_stress_pa = 0.0;
  double maximum_frame_stress_pa = 0.0;
  double penetration_margin_j = 0.0;
  double driver_heat_strain_index = 0.0;
  std::vector<std::string> recommendations;
  std::vector<IndyCarAeroscreenState> history;
  std::string evidence_sha256;
};

class IndyCarAeroscreenLaboratory {
 public:
  IndyCarAeroscreenResult simulate(const IndyCarAeroscreenConfiguration& configuration,
                                   const std::vector<IndyCarAeroscreenEnvironmentSegment>& environment,
                                   const std::vector<IndyCarDebrisImpact>& impacts,
                                   double initial_cockpit_temperature_k,
                                   double initial_screen_temperature_k,
                                   double integration_step_s = 0.05) const;
};

// -----------------------------------------------------------------------------
// 4. Spotter, radio, and oval situational awareness
// -----------------------------------------------------------------------------

enum class IndyCarSpotterCall {
  None,
  Inside,
  Outside,
  StillThere,
  Clear,
  ThreeWide,
  CheckUp,
  WreckAhead,
  PitOpen,
  PitClosed,
  BlendTraffic
};

struct IndyCarSpotterConfiguration {
  double visual_range_m = 1800.0;
  double angular_resolution_rad = 0.0025;
  double reaction_time_s = 0.22;
  double fatigue = 0.05;
  double experience = 0.90;
  double radio_base_latency_s = 0.08;
  double radio_loss_probability = 0.005;
  double false_clear_base_probability = 0.002;
  void validate() const;
};

struct IndyCarTrafficObservation {
  double time_s = 0.0;
  double subject_speed_m_s = 80.0;
  double inside_longitudinal_gap_m = 100.0;
  double outside_longitudinal_gap_m = 100.0;
  double inside_overlap_fraction = 0.0;
  double outside_overlap_fraction = 0.0;
  double closing_speed_inside_m_s = 0.0;
  double closing_speed_outside_m_s = 0.0;
  double visibility_fraction = 1.0;
  double radio_interference_fraction = 0.0;
  bool wreck_ahead = false;
  bool rapid_check_up = false;
  bool pit_lane_open = true;
  bool approaching_blend_traffic = false;
  void validate() const;
};

struct IndyCarSpotterMessage {
  double observation_time_s = 0.0;
  double delivery_time_s = 0.0;
  IndyCarSpotterCall call = IndyCarSpotterCall::None;
  double confidence = 0.0;
  bool delivered = false;
  bool correct = false;
};

struct IndyCarSpotterResult {
  bool qualified = false;
  double mean_latency_s = 0.0;
  double missed_hazard_probability = 0.0;
  double false_clear_probability = 0.0;
  double avoided_contact_probability = 0.0;
  double maximum_workload = 0.0;
  std::size_t delivered_messages = 0;
  std::size_t lost_messages = 0;
  std::vector<IndyCarSpotterMessage> messages;
  std::vector<std::string> violations;
  std::string evidence_sha256;
};

class IndyCarSpotterAwarenessTwin {
 public:
  IndyCarSpotterResult evaluate(const IndyCarSpotterConfiguration& configuration,
                                const std::vector<IndyCarTrafficObservation>& observations,
                                std::uint64_t deterministic_seed) const;
};

// -----------------------------------------------------------------------------
// 5. Technical inspection, aero metrology, and approved-part compliance
// -----------------------------------------------------------------------------

enum class IndyCarMeasurementComparator { Minimum, Maximum, Range, NominalTolerance };

struct IndyCarInspectionInstrument {
  std::string instrument_id;
  double standard_uncertainty = 0.0;
  std::string calibration_due_date;
  bool calibration_valid = true;
  void validate() const;
};

struct IndyCarTechnicalMeasurement {
  std::string rule_id;
  std::string name;
  double measured_value = 0.0;
  double lower_limit = 0.0;
  double upper_limit = 0.0;
  IndyCarMeasurementComparator comparator = IndyCarMeasurementComparator::Range;
  std::string instrument_id;
  double repeatability_standard_deviation = 0.0;
  double environmental_correction = 0.0;
  void validate() const;
};

struct IndyCarAeroDeflectionTest {
  std::string rule_id;
  std::string component;
  double applied_load_n = 0.0;
  double measured_deflection_m = 0.0;
  double maximum_deflection_m = 0.0;
  double permanent_set_m = 0.0;
  double maximum_permanent_set_m = 0.0;
  double temperature_k = 298.15;
  void validate() const;
};

struct IndyCarApprovedComponentRecord {
  std::string category;
  std::string serial;
  std::string approved_part_number;
  std::string fitted_part_number;
  bool seal_required = false;
  bool seal_intact = true;
  std::string seal_id;
  void validate() const;
};

struct IndyCarInspectionFinding {
  std::string rule_id;
  std::string item;
  bool pass = false;
  double corrected_value = 0.0;
  double expanded_uncertainty = 0.0;
  double compliance_margin = 0.0;
  std::string explanation;
};

struct IndyCarTechnicalInspectionResult {
  bool legal = false;
  double minimum_compliance_margin = 0.0;
  std::vector<IndyCarInspectionFinding> findings;
  std::vector<std::string> violations;
  std::string inspection_sha256;
};

class IndyCarTechnicalInspectionLaboratory {
 public:
  IndyCarTechnicalInspectionResult inspect(const std::vector<IndyCarInspectionInstrument>& instruments,
                                            const std::vector<IndyCarTechnicalMeasurement>& measurements,
                                            const std::vector<IndyCarAeroDeflectionTest>& deflection_tests,
                                            const std::vector<IndyCarApprovedComponentRecord>& components,
                                            double coverage_factor = 2.0) const;
};

// -----------------------------------------------------------------------------
// 6. Telemetry, locked calibration, and mandatory-channel compliance
// -----------------------------------------------------------------------------

struct IndyCarCalibrationParameter {
  std::string name;
  double value = 0.0;
  double approved_value = 0.0;
  double tolerance = 0.0;
  bool locked = true;
  std::string owner = "INDYCAR";
  void validate() const;
};

struct IndyCarMandatoryTelemetryChannel {
  std::string name;
  std::string unit;
  double minimum_sample_rate_hz = 1.0;
  double minimum_resolution = 0.0;
  bool safety_critical = false;
  bool continuous_required = true;
  void validate() const;
};

struct IndyCarTelemetrySample {
  std::string channel;
  double timestamp_s = 0.0;
  double value = 0.0;
  std::uint64_t sequence = 0;
  void validate() const;
};

struct IndyCarTelemetryManifest {
  std::string ecu_software_version;
  std::string ecu_software_sha256;
  std::string calibration_version;
  std::string calibration_sha256;
  std::string logger_configuration_sha256;
  std::vector<IndyCarCalibrationParameter> parameters;
  void validate() const;
};

struct IndyCarTelemetryComplianceResult {
  bool compliant = false;
  double dataset_completeness = 0.0;
  double minimum_observed_sample_rate_hz = 0.0;
  std::size_t sequence_gaps = 0;
  std::size_t duplicate_samples = 0;
  std::size_t locked_parameter_violations = 0;
  std::vector<std::string> missing_channels;
  std::vector<std::string> violations;
  std::string dataset_sha256;
  std::string evidence_sha256;
};

class IndyCarTelemetryComplianceLaboratory {
 public:
  IndyCarTelemetryComplianceResult verify(const IndyCarTelemetryManifest& manifest,
                                           const std::vector<IndyCarMandatoryTelemetryChannel>& required_channels,
                                           const std::vector<IndyCarTelemetrySample>& samples,
                                           double session_start_s,
                                           double session_end_s,
                                           double allowed_gap_factor = 1.5) const;
};

// -----------------------------------------------------------------------------
// 7. Approved testing, ROP/refresher, and development allocation
// -----------------------------------------------------------------------------

enum class IndyCarTestType {
  Team,
  Open,
  Manufacturer,
  Firestone,
  StraightLine,
  WindTunnel,
  Rookie,
  Evaluation,
  Refresher
};

struct IndyCarDriverEligibility {
  std::string driver_id;
  bool rookie = false;
  bool refresher_required = false;
  double oval_experience_score = 0.0;
  double road_experience_score = 0.0;
  std::vector<double> rop_phase_speeds_m_s;
  void validate() const;
};

struct IndyCarTestOpportunity {
  std::string test_id;
  IndyCarTestType type = IndyCarTestType::Team;
  std::string venue;
  std::string date;
  double test_days = 1.0;
  double cost = 0.0;
  double tyre_sets = 1.0;
  double fuel_gallons = 20.0;
  double component_miles = 100.0;
  double expected_lap_time_gain_s = 0.0;
  double expected_reliability_gain = 0.0;
  double driver_learning_gain = 0.0;
  double weather_success_probability = 1.0;
  bool approved = true;
  bool blackout = false;
  std::vector<std::string> eligible_drivers;
  void validate() const;
};

struct IndyCarTestingConstraints {
  double maximum_team_equivalent_days = 3.0;
  double maximum_cost = 1.0e6;
  double maximum_tyre_sets = 20.0;
  double maximum_fuel_gallons = 500.0;
  double maximum_component_miles = 2500.0;
  std::size_t maximum_selected_tests = 8;
  void validate() const;
};

struct IndyCarSelectedTest {
  std::string test_id;
  std::string assigned_driver;
  double expected_value = 0.0;
};

struct IndyCarTestingPlanResult {
  bool feasible = false;
  bool rookie_orientation_complete = false;
  bool refresher_complete = false;
  double total_test_days = 0.0;
  double total_cost = 0.0;
  double total_tyres = 0.0;
  double total_fuel_gallons = 0.0;
  double total_component_miles = 0.0;
  double expected_lap_time_gain_s = 0.0;
  double expected_reliability_gain = 0.0;
  double expected_driver_learning_gain = 0.0;
  std::vector<IndyCarSelectedTest> selected;
  std::vector<std::string> violations;
  std::string evidence_sha256;
};

class IndyCarTestingAllocationOptimizer {
 public:
  IndyCarTestingPlanResult optimize(const std::vector<IndyCarDriverEligibility>& drivers,
                                    const std::vector<IndyCarTestOpportunity>& opportunities,
                                    const IndyCarTestingConstraints& constraints,
                                    const std::string& focus_driver_id) const;
};

// -----------------------------------------------------------------------------
// 8. Backup-car, crash repair, and return-to-competition manager
// -----------------------------------------------------------------------------

enum class IndyCarDamageZone {
  FrontWing,
  Underwing,
  Suspension,
  Upright,
  Wheel,
  Monocoque,
  Aeroscreen,
  Engine,
  Hybrid,
  Gearbox,
  Wiring,
  FuelCell
};

enum class IndyCarRecoveryDecision {
  RepairPrimary,
  ReplaceCorner,
  ReplaceFloor,
  ChangeEngine,
  ChangeHybrid,
  SubstituteBackup,
  Retire
};

struct IndyCarDamageAssessment {
  IndyCarDamageZone zone = IndyCarDamageZone::Suspension;
  double severity = 0.0;
  double repair_hours = 0.0;
  double part_cost = 0.0;
  bool safety_critical = false;
  bool repairable_trackside = true;
  void validate() const;
};

struct IndyCarChassisReadiness {
  std::string chassis_serial;
  bool primary = true;
  bool unloaded = true;
  bool engine_installed = true;
  bool hybrid_installed = true;
  bool inspected = true;
  bool driver_fit_complete = true;
  bool calibration_compatible = true;
  double setup_completion_fraction = 1.0;
  void validate() const;
};

struct IndyCarRecoveryContext {
  IndyCarCircuitClass circuit = IndyCarCircuitClass::RoadStreet;
  bool after_qualifying = false;
  bool under_impound = false;
  bool approval_available = true;
  double hours_until_next_session = 4.0;
  std::size_t remaining_race_laps = 100;
  double remaining_race_time_s = 3600.0;
  double available_repair_labor_hours = 40.0;
  double maximum_repair_cost = 250000.0;
  void validate() const;
};

struct IndyCarRecoveryResult {
  bool can_return = false;
  IndyCarRecoveryDecision decision = IndyCarRecoveryDecision::Retire;
  double expected_repair_time_h = 0.0;
  double expected_cost = 0.0;
  bool starting_position_retained = false;
  bool reinspection_required = false;
  bool rear_of_field_start = false;
  std::vector<std::string> required_actions;
  std::vector<std::string> violations;
  std::string evidence_sha256;
};

class IndyCarCrashRecoveryManager {
 public:
  IndyCarRecoveryResult decide(const IndyCarChassisReadiness& primary,
                               const IndyCarChassisReadiness& backup,
                               const std::vector<IndyCarDamageAssessment>& damage,
                               const IndyCarRecoveryContext& context) const;
};

// -----------------------------------------------------------------------------
// 9. IndyCar pit crew, wheel gun, refueling, and human reliability
// -----------------------------------------------------------------------------

enum class IndyCarPitCrewRole {
  FrontLeft,
  FrontRight,
  RearLeft,
  RearRight,
  AirJack,
  Fueler,
  AeroscreenAttendant
};

struct IndyCarPitCrewMember {
  std::string member_id;
  IndyCarPitCrewRole role = IndyCarPitCrewRole::FrontLeft;
  double reaction_time_s = 0.18;
  double skill = 0.90;
  double fatigue = 0.05;
  double error_probability = 0.005;
  void validate() const;
};

struct IndyCarWheelGunConfiguration {
  double free_speed_rpm = 7000.0;
  double stall_torque_n_m = 850.0;
  double impact_frequency_hz = 35.0;
  double socket_engagement_tolerance_rad = 0.08;
  double target_clamp_force_n = 95000.0;
  double nut_pitch_m = 0.003;
  double thread_friction = 0.12;
  void validate() const;
};

struct IndyCarPitStopEnvironment {
  double car_box_error_m = 0.0;
  double pit_lane_traffic_density = 0.0;
  double neighboring_box_interference = 0.0;
  bool double_stack = false;
  bool caution_bunching = false;
  double target_fuel_gallons = 12.0;
  double initial_fuel_gallons = 3.0;
  double refueling_flow_l_s = 2.8;
  bool aeroscreen_service_requested = true;
  void validate() const;
};

struct IndyCarWheelServiceResult {
  IndyCarPitCrewRole role = IndyCarPitCrewRole::FrontLeft;
  double completion_time_s = 0.0;
  double clamp_force_n = 0.0;
  double seating_confidence = 0.0;
  bool cross_threaded = false;
  bool complete = false;
};

struct IndyCarPitCrewResult {
  bool completed = false;
  bool safe_release = false;
  double stop_time_s = 0.0;
  double fuel_delivered_gallons = 0.0;
  double unsafe_release_probability = 0.0;
  double crew_injury_probability = 0.0;
  double equipment_failure_probability = 0.0;
  std::vector<IndyCarWheelServiceResult> wheel_services;
  std::vector<std::string> incidents;
  std::string evidence_sha256;
};

class IndyCarPitCrewLaboratory {
 public:
  IndyCarPitCrewResult simulate(const std::vector<IndyCarPitCrewMember>& crew,
                                const IndyCarWheelGunConfiguration& wheel_gun,
                                const IndyCarPitStopEnvironment& environment,
                                std::uint64_t deterministic_seed) const;
};

// -----------------------------------------------------------------------------
// 10. Street-circuit bump, wall, steering-kickback, and brake-duty twin
// -----------------------------------------------------------------------------

struct IndyCarStreetCircuitSegment {
  double length_m = 50.0;
  double curvature_1_m = 0.0;
  double camber_rad = 0.0;
  double surface_friction = 1.0;
  double bump_height_m = 0.0;
  double bump_length_m = 1.0;
  double concrete_fraction = 0.0;
  double painted_surface_fraction = 0.0;
  double standing_water_m = 0.0;
  double left_wall_clearance_m = 5.0;
  double right_wall_clearance_m = 5.0;
  double brake_zone_fraction = 0.0;
  void validate() const;
};

struct IndyCarStreetCarConfiguration {
  double mass_kg = 880.0;
  double speed_m_s = 55.0;
  double wheelbase_m = 3.02;
  double track_width_m = 1.70;
  double steering_ratio = 12.0;
  double steering_compliance_rad_n_m = 1.2e-4;
  double wheel_unsprung_mass_kg = 19.0;
  double suspension_stiffness_n_m = 180000.0;
  double suspension_damping_n_s_m = 9000.0;
  double tyre_vertical_stiffness_n_m = 260000.0;
  double brake_disc_mass_kg = 2.2;
  double brake_disc_heat_capacity_j_kg_k = 710.0;
  double brake_cooling_ua_w_k = 250.0;
  double maximum_brake_temperature_k = 1273.0;
  double maximum_steering_torque_n_m = 32.0;
  double minimum_floor_clearance_m = 0.018;
  void validate() const;
};

struct IndyCarStreetState {
  double distance_m = 0.0;
  double speed_m_s = 0.0;
  double steering_torque_n_m = 0.0;
  double rack_load_n = 0.0;
  double wheel_vertical_acceleration_m_s2 = 0.0;
  double brake_temperature_k = 0.0;
  double floor_clearance_m = 0.0;
  double wall_contact_energy_j = 0.0;
  double grip_fraction = 0.0;
};

struct IndyCarStreetCircuitResult {
  bool qualified = false;
  double traversal_time_s = 0.0;
  double maximum_steering_torque_n_m = 0.0;
  double maximum_rack_load_n = 0.0;
  double maximum_wheel_vertical_acceleration_m_s2 = 0.0;
  double peak_brake_temperature_k = 0.0;
  double minimum_floor_clearance_m = 0.0;
  double cumulative_wall_contact_energy_j = 0.0;
  double brake_fade_fraction = 0.0;
  std::vector<std::string> failures;
  std::vector<IndyCarStreetState> history;
  std::string evidence_sha256;
};

class IndyCarStreetCircuitLaboratory {
 public:
  IndyCarStreetCircuitResult simulate(const std::vector<IndyCarStreetCircuitSegment>& track,
                                      const IndyCarStreetCarConfiguration& car,
                                      double initial_brake_temperature_k,
                                      double driver_lateral_error_m = 0.0,
                                      double integration_step_s = 0.002) const;
};

}  // namespace aesim::advanced

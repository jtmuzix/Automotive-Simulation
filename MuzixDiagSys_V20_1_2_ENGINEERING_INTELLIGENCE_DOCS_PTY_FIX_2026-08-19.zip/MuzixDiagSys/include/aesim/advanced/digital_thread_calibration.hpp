#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// SysML v2 and digital-thread integration
// -----------------------------------------------------------------------------

enum class SysmlElementKind {
    Package,
    PartDefinition,
    PartUsage,
    RequirementDefinition,
    RequirementUsage,
    InterfaceDefinition,
    PortUsage,
    ActionDefinition,
    StateDefinition,
    ConstraintDefinition,
    TestCase,
    Hazard,
    Evidence,
    Artifact
};

enum class SysmlRelationshipKind {
    Containment,
    Satisfy,
    Verify,
    Refine,
    Trace,
    Allocate,
    Interface,
    Derive,
    Mitigate
};

struct SysmlElement {
    std::string id;
    std::string name;
    std::string qualified_name;
    SysmlElementKind kind = SysmlElementKind::Artifact;
    std::string version = "1.0.0";
    std::map<std::string, std::string> attributes;
    std::string artifact_sha256;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SysmlElement from_document(const doc::Value& value);
};

struct SysmlRelationship {
    std::string id;
    SysmlRelationshipKind kind = SysmlRelationshipKind::Trace;
    std::string source_id;
    std::string target_id;
    std::map<std::string, std::string> attributes;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SysmlRelationship from_document(const doc::Value& value);
};

struct DigitalThreadValidation {
    bool valid = true;
    std::vector<std::string> diagnostics;
    std::map<std::string, double> coverage;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct DigitalThreadBaseline {
    std::string label;
    std::string created_utc;
    doc::Value model;
    std::string model_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct DigitalThreadDelta {
    std::vector<std::string> added_elements;
    std::vector<std::string> removed_elements;
    std::vector<std::string> modified_elements;
    std::vector<std::string> added_relationships;
    std::vector<std::string> removed_relationships;
    std::vector<std::string> impacted_elements;
    [[nodiscard]] doc::Value to_document() const;
};

class SysmlV2DigitalThread {
public:
    void add_element(SysmlElement element);
    void add_relationship(SysmlRelationship relationship);
    void remove_element(const std::string& id);
    void remove_relationship(const std::string& id);
    void import_sysml_v2_json(const doc::Value& document);
    [[nodiscard]] doc::Value export_sysml_v2_json() const;
    [[nodiscard]] std::string export_sysml_v2_text() const;
    [[nodiscard]] DigitalThreadValidation validate() const;
    [[nodiscard]] std::vector<std::string> trace(
        const std::string& start_id,
        const std::set<SysmlRelationshipKind>& relationship_kinds = {},
        bool downstream = true) const;
    [[nodiscard]] std::vector<std::string> impact_analysis(
        const std::vector<std::string>& changed_element_ids) const;
    [[nodiscard]] DigitalThreadBaseline create_baseline(const std::string& label) const;
    [[nodiscard]] static DigitalThreadDelta compare(
        const DigitalThreadBaseline& before,
        const DigitalThreadBaseline& after);
    [[nodiscard]] const std::map<std::string, SysmlElement>& elements() const noexcept {
        return elements_;
    }
    [[nodiscard]] const std::map<std::string, SysmlRelationship>& relationships() const noexcept {
        return relationships_;
    }
private:
    std::map<std::string, SysmlElement> elements_;
    std::map<std::string, SysmlRelationship> relationships_;
};

// -----------------------------------------------------------------------------
// Automated calibration and system identification
// -----------------------------------------------------------------------------

struct IdentificationDataSet {
    std::vector<double> time_s;
    std::vector<std::vector<double>> inputs;
    std::vector<std::vector<double>> outputs;
    void validate() const;
    [[nodiscard]] std::size_t samples() const noexcept { return time_s.size(); }
};

struct ArxModelSpecification {
    std::size_t output_order = 1;
    std::size_t input_order = 1;
    std::size_t input_delay = 0;
    double ridge = 1.0e-9;
};

struct IdentifiedArxModel {
    ArxModelSpecification specification;
    std::size_t input_channels = 0;
    std::size_t output_channels = 0;
    // One coefficient vector per output. Ordering: intercept, output lags,
    // then input-channel lags.
    std::vector<std::vector<double>> coefficients;
    std::vector<double> rmse;
    std::vector<double> r_squared;
    std::vector<std::vector<double>> covariance_diagonal;
    std::string evidence_sha256;
    [[nodiscard]] std::vector<std::vector<double>> predict(
        const IdentificationDataSet& data) const;
    [[nodiscard]] doc::Value to_document() const;
};

struct CalibrationParameter {
    std::string name;
    double initial = 0.0;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
    double scale = 1.0;
};

using CalibrationResidualFunction =
    std::function<std::vector<double>(const std::vector<double>&)>;

struct CalibrationOptions {
    std::size_t maximum_iterations = 100;
    double gradient_tolerance = 1.0e-9;
    double step_tolerance = 1.0e-10;
    double initial_damping = 1.0e-3;
    double finite_difference_relative_step = 1.0e-6;
    std::size_t bootstrap_samples = 0;
    std::uint64_t seed = 1;
};

struct CalibrationResult {
    bool converged = false;
    std::size_t iterations = 0;
    std::map<std::string, double> parameters;
    std::map<std::string, double> standard_errors;
    double objective = 0.0;
    double rmse = 0.0;
    double gradient_norm = 0.0;
    std::vector<double> residuals;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AutomatedCalibrationEngine {
public:
    [[nodiscard]] IdentifiedArxModel identify_arx(
        const IdentificationDataSet& data,
        const ArxModelSpecification& specification) const;
    [[nodiscard]] CalibrationResult calibrate(
        const std::vector<CalibrationParameter>& parameters,
        const CalibrationResidualFunction& residual_function,
        const CalibrationOptions& options = {}) const;
};

} // namespace aesim::advanced

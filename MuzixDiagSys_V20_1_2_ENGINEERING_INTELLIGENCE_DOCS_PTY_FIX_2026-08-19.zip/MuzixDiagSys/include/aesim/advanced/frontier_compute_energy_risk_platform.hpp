#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

using FrontierVector = std::vector<double>;
using FrontierMatrix = std::vector<std::vector<double>>;
using FrontierPoint2 = std::array<double, 2>;
using FrontierPoint3 = std::array<double, 3>;
using FrontierComplex = std::complex<double>;

// 3D-IC/UCIe Chiplet Physical Design
struct PhysicalChipletDie {
    std::string id;
    double width_m = 0.01;
    double height_m = 0.01;
    double thickness_m = 0.0001;
    double power_w = 10.0;
    double thermal_resistance_k_w = 0.5;
    double defect_density_m2 = 100.0;
    double maximum_temperature_k = 398.15;
    FrontierPoint3 position_m{0.0, 0.0, 0.0};
    void validate() const;
};

struct UciePhysicalLink {
    std::string source_die;
    std::string destination_die;
    std::size_t lanes = 16;
    double lane_rate_bit_s = 16.0e9;
    double energy_pj_bit = 0.5;
    double insertion_loss_db_m = 50.0;
    double crosstalk_db = -35.0;
    double target_ber = 1.0e-15;
    std::size_t spare_lanes = 2;
    void validate() const;
};

struct ChipletPackageOptions {
    double interposer_thermal_conductivity_w_mk = 120.0;
    double cooling_temperature_k = 298.15;
    double package_supply_voltage_v = 0.8;
    double power_delivery_resistance_ohm = 0.001;
    double decoupling_capacitance_f = 2.0e-3;
    double package_defect_density_m2 = 30.0;
    double maximum_voltage_droop_fraction = 0.08;
    double maximum_warpage_m = 50.0e-6;
    std::size_t placement_iterations = 80;
    void validate() const;
};

struct ChipletLinkAssessment {
    std::string source_die;
    std::string destination_die;
    double length_m = 0.0;
    double latency_s = 0.0;
    double bit_error_rate = 0.0;
    double power_w = 0.0;
    std::size_t usable_lanes = 0;
    bool qualified = false;
};

struct ChipletPhysicalDesignResult {
    std::vector<PhysicalChipletDie> dies;
    std::vector<ChipletLinkAssessment> links;
    std::map<std::string, double> junction_temperature_k;
    double maximum_voltage_droop_v = 0.0;
    double package_warpage_m = 0.0;
    double compound_yield = 0.0;
    double total_link_power_w = 0.0;
    bool thermal_qualified = false;
    bool power_integrity_qualified = false;
    bool link_qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_layout = false) const;
};

class Chiplet3dIcUciePhysicalDesignLaboratory {
public:
    [[nodiscard]] ChipletPhysicalDesignResult design(
        const std::vector<PhysicalChipletDie>& dies,
        const std::vector<UciePhysicalLink>& links,
        const ChipletPackageOptions& options) const;
};

// Analog In-Memory and Photonic AI Accelerators
enum class AcceleratorTileTechnology { SramComputeInMemory, ReramCrossbar, PhaseChangeMemory, PhotonicMzi, PhotonicRing };

struct AnalogAcceleratorTile {
    std::string id;
    AcceleratorTileTechnology technology = AcceleratorTileTechnology::SramComputeInMemory;
    std::size_t rows = 128;
    std::size_t columns = 128;
    std::size_t bit_precision = 8;
    double clock_hz = 500.0e6;
    double device_variation_fraction = 0.01;
    double drift_per_hour_fraction = 1.0e-5;
    double endurance_cycles = 1.0e9;
    double insertion_loss_db = 0.0;
    double laser_efficiency = 0.25;
    double thermal_tuning_w = 0.0;
    void validate() const;
};

struct AiAcceleratorLayer {
    std::string id;
    std::size_t input_dimension = 1;
    std::size_t output_dimension = 1;
    std::size_t batch = 1;
    double operations = 1.0;
    double required_accuracy_fraction = 0.9;
    void validate() const;
};

struct AcceleratorLayerAssignment {
    std::string layer_id;
    std::string tile_id;
    double latency_s = 0.0;
    double energy_j = 0.0;
    double estimated_accuracy_fraction = 0.0;
    double lifetime_fraction_consumed = 0.0;
    bool accuracy_met = false;
};

struct AnalogPhotonicAcceleratorResult {
    std::vector<AcceleratorLayerAssignment> assignments;
    double total_latency_s = 0.0;
    double total_energy_j = 0.0;
    double throughput_top_s = 0.0;
    double minimum_accuracy_fraction = 0.0;
    double maximum_temperature_k = 0.0;
    double remaining_life_fraction = 0.0;
    bool all_layers_qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_assignments = false) const;
};

class AnalogInMemoryPhotonicAiAcceleratorLaboratory {
public:
    [[nodiscard]] AnalogPhotonicAcceleratorResult map_and_simulate(
        const std::vector<AnalogAcceleratorTile>& tiles,
        const std::vector<AiAcceleratorLayer>& layers,
        double ambient_temperature_k,
        double operating_hours) const;
};

// Dynamic Wireless Charging and Electrified Roads
struct WirelessRoadSegment {
    std::string id;
    double start_m = 0.0;
    double end_m = 1.0;
    double transmitter_inductance_h = 100.0e-6;
    double transmitter_resistance_ohm = 0.1;
    double resonant_frequency_hz = 85.0e3;
    double maximum_power_w = 11000.0;
    double grid_limit_w = 11000.0;
    double energy_price_per_kwh = 0.15;
    double carbon_kg_per_kwh = 0.3;
    void validate() const;
};

struct WirelessChargingVehicle {
    double speed_m_s = 20.0;
    double receiver_inductance_h = 100.0e-6;
    double receiver_resistance_ohm = 0.1;
    double nominal_gap_m = 0.15;
    double lateral_offset_m = 0.0;
    double pitch_rad = 0.0;
    double battery_capacity_j = 2.0e8;
    double initial_energy_j = 1.0e8;
    double maximum_charge_power_w = 150000.0;
    void validate() const;
};

struct WirelessChargingSegmentResult {
    std::string segment_id;
    double dwell_time_s = 0.0;
    double coupling_coefficient = 0.0;
    double efficiency = 0.0;
    double delivered_energy_j = 0.0;
    double transmitter_temperature_k = 0.0;
    double magnetic_field_t = 0.0;
    bool foreign_object_protection_triggered = false;
};

struct DynamicWirelessChargingResult {
    std::vector<WirelessChargingSegmentResult> segments;
    double final_vehicle_energy_j = 0.0;
    double total_grid_energy_j = 0.0;
    double total_cost = 0.0;
    double total_carbon_kg = 0.0;
    double peak_grid_power_w = 0.0;
    double average_efficiency = 0.0;
    bool exposure_qualified = false;
    bool thermal_qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_segments = false) const;
};

class DynamicWirelessChargingElectrifiedRoadLaboratory {
public:
    [[nodiscard]] DynamicWirelessChargingResult simulate(
        const std::vector<WirelessRoadSegment>& road,
        const WirelessChargingVehicle& vehicle,
        double ambient_temperature_k,
        double magnetic_exposure_limit_t,
        const std::vector<std::string>& foreign_object_segments = {}) const;
};

// Plasma, Arc and High-Voltage Breakdown
struct HighVoltageGap {
    std::string id;
    double gap_m = 0.001;
    double area_m2 = 1.0e-4;
    double pressure_pa = 101325.0;
    double temperature_k = 298.15;
    double relative_humidity = 0.5;
    double contamination_factor = 1.0;
    double dielectric_strength_v_m = 3.0e6;
    double electrode_melting_energy_j_kg = 3.0e5;
    void validate() const;
};

struct HighVoltageTransient {
    double applied_voltage_v = 400.0;
    double source_resistance_ohm = 0.1;
    double source_inductance_h = 1.0e-6;
    double source_capacitance_f = 1.0e-3;
    double duration_s = 0.01;
    double protection_trip_current_a = 1000.0;
    double protection_delay_s = 0.001;
    void validate() const;
};

struct ArcGapResult {
    std::string gap_id;
    double breakdown_voltage_v = 0.0;
    double peak_arc_current_a = 0.0;
    double arc_energy_j = 0.0;
    double electrode_erosion_kg = 0.0;
    double peak_temperature_k = 0.0;
    double incident_energy_j_cm2 = 0.0;
    bool breakdown_occurred = false;
    bool protection_cleared = false;
    bool ignition_risk = false;
};

struct HighVoltageBreakdownResult {
    std::vector<ArcGapResult> gaps;
    double total_arc_energy_j = 0.0;
    double maximum_incident_energy_j_cm2 = 0.0;
    double emitted_interference_index = 0.0;
    bool insulation_qualified = false;
    bool protection_coordinated = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_gaps = false) const;
};

class PlasmaArcHighVoltageBreakdownLaboratory {
public:
    [[nodiscard]] HighVoltageBreakdownResult simulate(
        const std::vector<HighVoltageGap>& gaps,
        const HighVoltageTransient& transient,
        double ignition_energy_threshold_j) const;
};

// Quantum Computing and Tensor Networks
struct QuantumGateOperation {
    std::string gate;
    std::size_t target = 0;
    std::size_t control = 0;
    double parameter_rad = 0.0;
    void validate(std::size_t qubits) const;
};

struct QuantumNoiseModel {
    double depolarizing_probability = 0.0;
    double amplitude_damping_probability = 0.0;
    double measurement_error_probability = 0.0;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct QuantumObservableTerm {
    double coefficient = 1.0;
    std::string pauli_string;
    void validate(std::size_t qubits) const;
};

struct QuantumSimulationResult {
    std::size_t qubits = 0;
    std::vector<FrontierComplex> statevector;
    FrontierVector measurement_probabilities;
    double observable_expectation = 0.0;
    double state_norm = 0.0;
    double entanglement_entropy = 0.0;
    double estimated_logical_qubits = 0.0;
    double estimated_physical_qubits = 0.0;
    double tensor_truncation_error = 0.0;
    bool normalization_qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_state = false) const;
};

class QuantumComputingTensorNetworkLaboratory {
public:
    [[nodiscard]] QuantumSimulationResult simulate(
        std::size_t qubits,
        const std::vector<QuantumGateOperation>& circuit,
        const std::vector<QuantumObservableTerm>& observable,
        const QuantumNoiseModel& noise,
        std::size_t maximum_bond_dimension = 64) const;
};

// Multi-Technology Energy Storage

enum class HybridStorageTechnology { Battery, Supercapacitor, Flywheel, HydraulicAccumulator, Pneumatic, ThermalPhaseChange, ReversibleFuelCell };

struct HybridStorageUnit {
    std::string id;
    HybridStorageTechnology technology = HybridStorageTechnology::Battery;
    double usable_energy_j = 1.0e6;
    double initial_energy_j = 5.0e5;
    double maximum_charge_power_w = 1.0e5;
    double maximum_discharge_power_w = 1.0e5;
    double charge_efficiency = 0.95;
    double discharge_efficiency = 0.95;
    double self_discharge_per_s = 0.0;
    double response_time_s = 0.01;
    double mass_kg = 10.0;
    double cost = 1000.0;
    double cycle_life = 10000.0;
    void validate() const;
};

struct StoragePowerRequest {
    double duration_s = 1.0;
    double power_w = 0.0; // positive discharge, negative regenerative charge
    void validate() const;
};

struct HybridStorageDispatchSample {
    double time_s = 0.0;
    double requested_power_w = 0.0;
    double delivered_power_w = 0.0;
    std::map<std::string, double> unit_power_w;
    std::map<std::string, double> unit_energy_j;
};

struct MultiTechnologyStorageResult {
    std::vector<HybridStorageDispatchSample> history;
    std::map<std::string, double> final_energy_j;
    std::map<std::string, double> life_consumed_fraction;
    double unmet_energy_j = 0.0;
    double recovered_energy_j = 0.0;
    double round_trip_efficiency = 0.0;
    double total_mass_kg = 0.0;
    double total_cost = 0.0;
    bool power_requirements_met = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class MultiTechnologyEnergyStorageHybridizationLaboratory {
public:
    [[nodiscard]] MultiTechnologyStorageResult dispatch(
        const std::vector<HybridStorageUnit>& units,
        const std::vector<StoragePowerRequest>& profile) const;
};

// Embodied Robotics and Contact-Rich Manipulation
struct RobotJointDefinition {
    std::string id;
    double link_length_m = 0.1;
    double lower_limit_rad = -3.141592653589793;
    double upper_limit_rad = 3.141592653589793;
    double maximum_velocity_rad_s = 2.0;
    double maximum_torque_nm = 20.0;
    double viscous_friction_nm_s_rad = 0.05;
    void validate() const;
};

struct ManipulationObject {
    std::string id;
    FrontierPoint2 position_m{0.0, 0.0};
    double mass_kg = 1.0;
    double radius_m = 0.05;
    double friction_coefficient = 0.5;
    void validate() const;
};

struct ManipulationTask {
    std::string object_id;
    FrontierPoint2 grasp_position_m{0.0, 0.0};
    FrontierPoint2 target_position_m{0.0, 0.0};
    double required_grip_force_n = 10.0;
    double position_tolerance_m = 0.01;
    void validate() const;
};

struct RobotTrajectorySample {
    double time_s = 0.0;
    FrontierVector joint_position_rad;
    FrontierVector joint_velocity_rad_s;
    FrontierPoint2 end_effector_position_m{0.0, 0.0};
    double contact_force_n = 0.0;
};

struct EmbodiedRoboticsResult {
    std::vector<RobotTrajectorySample> trajectory;
    FrontierVector final_joint_position_rad;
    FrontierPoint2 final_object_position_m{0.0, 0.0};
    double final_position_error_m = 0.0;
    double peak_joint_torque_nm = 0.0;
    double mechanical_energy_j = 0.0;
    double grasp_margin = 0.0;
    bool grasp_stable = false;
    bool task_completed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_trajectory = false) const;
};

class EmbodiedRoboticsContactManipulationLaboratory {
public:
    [[nodiscard]] EmbodiedRoboticsResult execute(
        const std::vector<RobotJointDefinition>& joints,
        const ManipulationObject& object,
        const ManipulationTask& task,
        double time_step_s = 0.002,
        double maximum_duration_s = 10.0) const;
};

// Agent-Based Mobility, Logistics and Energy Markets
struct MobilityZone {
    std::string id;
    double population = 0.0;
    double jobs = 0.0;
    double electricity_price_per_kwh = 0.15;
    double grid_carbon_kg_per_kwh = 0.3;
    double charging_capacity_w = 1.0e6;
    void validate() const;
};

struct MobilityNetworkEdge {
    std::string source_zone;
    std::string destination_zone;
    double free_flow_time_s = 60.0;
    double capacity_vehicles_h = 1000.0;
    double distance_m = 1000.0;
    double toll = 0.0;
    void validate() const;
};

struct MobilityAgent {
    std::string id;
    std::string origin_zone;
    std::string destination_zone;
    std::string mode = "car";
    double departure_time_s = 0.0;
    double value_of_time_per_h = 20.0;
    double energy_consumption_j_m = 500.0;
    double battery_energy_j = 1.0e8;
    double required_arrival_energy_j = 1.0e7;
    void validate() const;
};

struct EnergyMarketInterval {
    double start_time_s = 0.0;
    double end_time_s = 3600.0;
    double wholesale_price_per_kwh = 0.1;
    double renewable_power_w = 0.0;
    double system_load_w = 0.0;
    void validate() const;
};

struct MobilityAgentOutcome {
    std::string agent_id;
    FrontierVector route_edge_indices;
    double travel_time_s = 0.0;
    double generalized_cost = 0.0;
    double energy_j = 0.0;
    double charging_delay_s = 0.0;
    double carbon_kg = 0.0;
    bool completed = false;
};

struct MobilityEnergyMarketResult {
    std::vector<MobilityAgentOutcome> agents;
    std::map<std::string, double> edge_flow_vehicles_h;
    std::map<std::string, double> charging_energy_j;
    double mean_travel_time_s = 0.0;
    double total_system_cost = 0.0;
    double total_carbon_kg = 0.0;
    double unserved_trips = 0.0;
    double peak_grid_demand_w = 0.0;
    bool network_stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_agents = false) const;
};

class AgentBasedMobilityLogisticsEnergyMarketLaboratory {
public:
    [[nodiscard]] MobilityEnergyMarketResult simulate(
        const std::vector<MobilityZone>& zones,
        const std::vector<MobilityNetworkEdge>& edges,
        const std::vector<MobilityAgent>& agents,
        const std::vector<EnergyMarketInterval>& market,
        std::size_t assignment_iterations = 12) const;
};

// Proof-Carrying Numerical Runtime
enum class CertifiedOpcode { Input, Constant, Add, Subtract, Multiply, Divide, Sqrt, Exp, Sin, Sum };

struct CertifiedInterval {
    double lower = 0.0;
    double upper = 0.0;
    void validate() const;
};

struct CertifiedKernelNode {
    CertifiedOpcode opcode = CertifiedOpcode::Input;
    std::vector<std::size_t> arguments;
    double constant = 0.0;
    std::size_t input_index = 0;
    void validate(std::size_t node_index, std::size_t input_count) const;
};

struct ProofCarryingKernel {
    std::string id;
    std::size_t input_count = 0;
    std::vector<CertifiedKernelNode> nodes;
    std::vector<std::size_t> outputs;
    void validate() const;
};

struct NumericalProofCertificate {
    std::string kernel_id;
    std::vector<CertifiedInterval> input_intervals;
    std::vector<CertifiedInterval> output_intervals;
    double maximum_roundoff_bound = 0.0;
    bool domain_safe = false;
    bool finite = false;
    std::string kernel_sha256;
    std::string certificate_sha256;
};

struct ProofCarryingExecutionResult {
    FrontierVector outputs;
    NumericalProofCertificate certificate;
    bool certificate_verified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_intervals = false) const;
};

class ProofCarryingNumericalRuntime {
public:
    [[nodiscard]] ProofCarryingExecutionResult execute(
        const ProofCarryingKernel& kernel,
        const FrontierVector& inputs,
        const std::vector<CertifiedInterval>& input_intervals) const;
    [[nodiscard]] bool verify(const ProofCarryingKernel& kernel,
                              const NumericalProofCertificate& certificate) const;
};

// Warranty, Insurance and Reliability Economics
struct ReliabilityEconomicComponent {
    std::string id;
    std::size_t population = 1;
    double weibull_shape = 2.0;
    double weibull_scale_h = 10000.0;
    double repair_cost_mean = 1000.0;
    double repair_cost_sigma = 200.0;
    double labor_hours = 1.0;
    double downtime_h = 2.0;
    double catastrophic_probability_given_failure = 0.0;
    double catastrophic_cost = 0.0;
    double preventive_maintenance_cost = 100.0;
    double preventive_maintenance_effectiveness = 0.5;
    void validate() const;
};

struct WarrantyInsuranceScenario {
    double horizon_h = 5000.0;
    double warranty_limit_h = 3000.0;
    double labor_rate_per_h = 100.0;
    double downtime_cost_per_h = 50.0;
    double insurance_deductible = 500.0;
    double supplier_recovery_fraction = 0.0;
    double annual_discount_rate = 0.05;
    std::size_t monte_carlo_samples = 10000;
    double confidence_level = 0.95;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct ComponentEconomicRisk {
    std::string component_id;
    double expected_failures = 0.0;
    double expected_warranty_cost = 0.0;
    double expected_insured_loss = 0.0;
    double optimal_maintenance_interval_h = 0.0;
    double lifecycle_cost = 0.0;
};

struct WarrantyInsuranceEconomicsResult {
    std::vector<ComponentEconomicRisk> components;
    double expected_total_cost = 0.0;
    double warranty_reserve = 0.0;
    double insurance_premium_indication = 0.0;
    double value_at_risk = 0.0;
    double conditional_value_at_risk = 0.0;
    double supplier_recovery = 0.0;
    double optimized_maintenance_cost = 0.0;
    bool reserve_adequate = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_components = false) const;
};

class WarrantyInsuranceReliabilityEconomicsLaboratory {
public:
    [[nodiscard]] WarrantyInsuranceEconomicsResult evaluate(
        const std::vector<ReliabilityEconomicComponent>& components,
        const WarrantyInsuranceScenario& scenario,
        double proposed_warranty_reserve,
        double risk_loading_fraction = 0.2) const;
};

} // namespace aesim::advanced

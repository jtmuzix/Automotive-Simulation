#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Simulation quality qualification and model-credibility contracts.
// -----------------------------------------------------------------------------

enum class SimulationQualityStatus {
    Qualified,
    ConditionallyQualified,
    Extrapolated,
    Exploratory,
    NumericallySuspect,
    Invalid
};

struct QualityParameterLimit {
    std::string name;
    double minimum = 0.0;
    double maximum = 0.0;
    bool inclusive = true;
};

struct QualityEvidenceItem {
    std::string id;
    std::string category;
    double score = 0.0;
    double weight = 1.0;
    double standard_uncertainty = 0.0;
    std::string provenance_sha256;
    bool independently_reviewed = false;
    void validate() const;
};

struct SimulationQualityRequest {
    std::string model_id;
    std::string model_version;
    std::string intended_use;
    std::map<std::string, double> operating_point;
    std::vector<QualityParameterLimit> validity_limits;
    std::vector<QualityEvidenceItem> evidence;
    double numerical_residual = 0.0;
    double numerical_tolerance = 1.0e-8;
    double conservation_error = 0.0;
    double maximum_conservation_error = 1.0e-6;
    double requested_confidence = 0.95;
    bool certification_use = false;
};

struct QualityDimensionScore {
    std::string name;
    double score = 0.0;
    double uncertainty = 0.0;
    std::vector<std::string> findings;
};

struct SimulationQualityContract {
    SimulationQualityStatus status = SimulationQualityStatus::Invalid;
    double aggregate_score = 0.0;
    double lower_confidence_score = 0.0;
    double extrapolation_distance = 0.0;
    std::vector<QualityDimensionScore> dimensions;
    std::vector<std::string> restrictions;
    std::vector<std::string> required_actions;
    std::string evidence_sha256;
    [[nodiscard]] bool permits_certification() const noexcept;
    [[nodiscard]] doc::Value to_document() const;
};

class SimulationQualityQualificationEngine {
public:
    [[nodiscard]] SimulationQualityContract qualify(const SimulationQualityRequest& request) const;
};

// -----------------------------------------------------------------------------
// Standards-based vehicle-dynamics validation laboratory.
// -----------------------------------------------------------------------------

enum class VehicleDynamicsManeuver {
    SteadyStateCircle,
    OnCentreWeave,
    SlowlyIncreasingSteer,
    SineWithDwell,
    StepSteer,
    PulseSteer,
    Fishhook,
    BrakeInTurn,
    SplitMuBraking,
    FrequencySweep
};

struct ValidationSignal {
    std::string name;
    std::string unit;
    std::vector<double> time_s;
    std::vector<double> measured;
    std::vector<double> simulated;
    double allowed_nrmse = 0.10;
    double allowed_gain_error = 0.10;
    double allowed_phase_error_s = 0.05;
    double minimum_coherence = 0.80;
    void validate() const;
};

struct VehicleDynamicsValidationConfig {
    VehicleDynamicsManeuver maneuver = VehicleDynamicsManeuver::StepSteer;
    std::string standard_reference;
    std::vector<ValidationSignal> signals;
    double resample_period_s = 0.0;
    double maximum_alignment_shift_s = 0.25;
    double low_pass_cutoff_hz = 0.0;
    double required_pass_fraction = 1.0;
    bool estimate_time_alignment = true;
    bool remove_bias = true;
};

struct SignalValidationResult {
    std::string name;
    double time_shift_s = 0.0;
    double bias = 0.0;
    double rmse = 0.0;
    double nrmse = 0.0;
    double maximum_absolute_error = 0.0;
    double coefficient_of_determination = 0.0;
    double gain_error = 0.0;
    double phase_error_s = 0.0;
    double coherence = 0.0;
    bool residual_whiteness_passed = false;
    bool passed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct VehicleDynamicsValidationReport {
    VehicleDynamicsManeuver maneuver = VehicleDynamicsManeuver::StepSteer;
    std::string standard_reference;
    std::vector<SignalValidationResult> signals;
    double pass_fraction = 0.0;
    bool passed = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class StandardsVehicleDynamicsValidationLab {
public:
    [[nodiscard]] VehicleDynamicsValidationReport validate(
        const VehicleDynamicsValidationConfig& config) const;
};

// -----------------------------------------------------------------------------
// Regulation-as-code compiler, evaluator and semantic rule differ.
// -----------------------------------------------------------------------------

enum class RegulationSeverity { Advisory, Operational, Technical, SafetyCritical };

enum class RuleChangeKind { Added, Removed, LogicChanged, ThresholdChanged, MetadataChanged, Unchanged };

struct RegulationRuleSource {
    std::string id;
    std::string title;
    std::string expression;
    std::string issue;
    std::string effective_date;
    RegulationSeverity severity = RegulationSeverity::Technical;
    std::vector<std::string> affected_artifacts;
    std::string remediation;
};

struct CompiledRegulationRule {
    RegulationRuleSource source;
    std::string canonical_expression;
    std::vector<std::string> referenced_variables;
    std::string semantic_sha256;
};

struct RegulationEvaluation {
    std::string rule_id;
    bool passed = false;
    double margin = 0.0;
    std::string explanation;
    std::vector<std::string> affected_artifacts;
    [[nodiscard]] doc::Value to_document() const;
};

struct RegulationRuleChange {
    std::string rule_id;
    RuleChangeKind kind = RuleChangeKind::Unchanged;
    std::vector<std::string> changed_variables;
    std::vector<std::string> impacted_artifacts;
    std::string explanation;
    [[nodiscard]] doc::Value to_document() const;
};

struct RegulationSemanticDiff {
    std::vector<RegulationRuleChange> changes;
    std::set<std::string> impacted_artifacts;
    std::set<std::string> impacted_variables;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RegulationAsCodeEngine {
public:
    [[nodiscard]] CompiledRegulationRule compile(const RegulationRuleSource& source) const;
    [[nodiscard]] RegulationEvaluation evaluate(
        const CompiledRegulationRule& rule,
        const std::map<std::string, double>& variables) const;
    [[nodiscard]] RegulationSemanticDiff semantic_diff(
        const std::vector<CompiledRegulationRule>& old_rules,
        const std::vector<CompiledRegulationRule>& new_rules,
        const std::map<std::string, std::vector<std::string>>& dependency_graph = {}) const;
};

// -----------------------------------------------------------------------------
// Composite laminate and progressive-damage solver.
// -----------------------------------------------------------------------------

enum class CompositeFailureCriterion { MaximumStress, TsaiHill, TsaiWu, Hashin };

struct OrthotropicLaminaMaterial {
    std::string id;
    double e1_pa = 0.0;
    double e2_pa = 0.0;
    double g12_pa = 0.0;
    double nu12 = 0.0;
    double density_kg_m3 = 0.0;
    double alpha1_per_k = 0.0;
    double alpha2_per_k = 0.0;
    double xt_pa = 0.0;
    double xc_pa = 0.0;
    double yt_pa = 0.0;
    double yc_pa = 0.0;
    double s12_pa = 0.0;
    void validate() const;
};

struct CompositePly {
    OrthotropicLaminaMaterial material;
    double thickness_m = 0.0;
    double angle_deg = 0.0;
    double fiber_damage = 0.0;
    double matrix_damage = 0.0;
    double shear_damage = 0.0;
    void validate() const;
};

struct LaminateLoad {
    // Membrane resultants [Nx, Ny, Nxy] N/m and moments [Mx, My, Mxy] N.
    std::vector<double> mechanical{0,0,0,0,0,0};
    double delta_temperature_k = 0.0;
};

struct PlyFailureState {
    std::size_t ply_index = 0;
    double z_mid_m = 0.0;
    std::vector<double> local_stress_pa;
    std::vector<double> local_strain;
    double failure_index = 0.0;
    double fiber_index = 0.0;
    double matrix_index = 0.0;
    double shear_index = 0.0;
    bool failed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct CompositeLaminateResult {
    std::vector<double> midplane_strain;
    std::vector<double> curvature_per_m;
    std::vector<std::vector<double>> abd_matrix;
    std::vector<PlyFailureState> ply_states;
    std::vector<CompositePly> damaged_plies;
    std::size_t damage_iterations = 0;
    double reserve_factor = 0.0;
    double mass_per_area_kg_m2 = 0.0;
    bool converged = false;
    bool laminate_failed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct CompositeProgressiveDamageOptions {
    CompositeFailureCriterion criterion = CompositeFailureCriterion::Hashin;
    std::size_t maximum_iterations = 30;
    double fiber_stiffness_retention = 0.05;
    double matrix_stiffness_retention = 0.20;
    double shear_stiffness_retention = 0.15;
    double failure_tolerance = 1.0e-8;
};

class CompositeLaminateProgressiveDamageSolver {
public:
    [[nodiscard]] CompositeLaminateResult solve(
        const std::vector<CompositePly>& plies,
        const LaminateLoad& load,
        const CompositeProgressiveDamageOptions& options = {}) const;
};

// -----------------------------------------------------------------------------
// Monolithic modal aeroelasticity and flexible-body dynamics.
// -----------------------------------------------------------------------------

struct AeroelasticMode {
    std::string id;
    double modal_mass_kg = 1.0;
    double stiffness_n_m = 1.0;
    double damping_n_s_m = 0.0;
    double cubic_stiffness_n_m3 = 0.0;
    double generalized_force_scale = 1.0;
    void validate() const;
};

struct AeroelasticModel {
    std::vector<AeroelasticMode> modes;
    std::vector<std::vector<double>> aerodynamic_stiffness_per_pa;
    std::vector<std::vector<double>> aerodynamic_damping_per_pa_s;
    std::vector<double> external_generalized_force_n;
    double reference_area_m2 = 1.0;
    double air_density_kg_m3 = 1.225;
};

struct AeroelasticSimulationConfig {
    double airspeed_m_s = 0.0;
    double time_step_s = 0.001;
    double duration_s = 1.0;
    std::vector<double> initial_displacement_m;
    std::vector<double> initial_velocity_m_s;
    std::size_t newton_iterations = 12;
    double nonlinear_tolerance = 1.0e-10;
};

struct AeroelasticSample {
    double time_s = 0.0;
    std::vector<double> displacement_m;
    std::vector<double> velocity_m_s;
    double structural_energy_j = 0.0;
    double aerodynamic_work_j = 0.0;
};

struct AeroelasticResult {
    std::vector<AeroelasticSample> samples;
    double dynamic_pressure_pa = 0.0;
    double maximum_displacement_m = 0.0;
    double energy_growth_rate_per_s = 0.0;
    double estimated_divergence_speed_m_s = 0.0;
    double estimated_flutter_speed_m_s = 0.0;
    bool converged = false;
    bool unstable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_samples = true) const;
};

class MonolithicAeroelasticSolver {
public:
    [[nodiscard]] AeroelasticResult simulate(
        const AeroelasticModel& model,
        const AeroelasticSimulationConfig& config) const;
    [[nodiscard]] std::pair<double, double> estimate_instability_speeds(
        const AeroelasticModel& model,
        double maximum_speed_m_s,
        double speed_tolerance_m_s = 0.1) const;
};

// -----------------------------------------------------------------------------
// Physics-based tire compound laboratory.
// -----------------------------------------------------------------------------

struct PronyTerm {
    double modulus_fraction = 0.0;
    double relaxation_time_s = 1.0;
};

struct TireCompoundDefinition {
    std::string id;
    double reference_temperature_k = 293.15;
    double glass_transition_temperature_k = 240.0;
    double wlf_c1 = 17.44;
    double wlf_c2_k = 51.6;
    double shear_modulus_pa = 1.0e6;
    double bulk_modulus_pa = 2.0e9;
    double mooney_c10_pa = 2.5e5;
    double mooney_c01_pa = 1.0e5;
    double thermal_conductivity_w_m_k = 0.2;
    double heat_capacity_j_kg_k = 1800.0;
    double density_kg_m3 = 1100.0;
    double base_adhesion_friction = 1.0;
    double hysteresis_friction_scale = 0.5;
    double abrasion_coefficient = 1.0e-10;
    std::vector<PronyTerm> prony_terms;
    void validate() const;
};

struct TireCompoundState {
    double temperature_k = 293.15;
    double wear_depth_m = 0.0;
    double accumulated_dissipation_j_m3 = 0.0;
    double aging_fraction = 0.0;
};

struct TireCompoundOperatingPoint {
    double normal_pressure_pa = 300000.0;
    double slip_speed_m_s = 0.0;
    double strain_amplitude = 0.1;
    double excitation_frequency_hz = 10.0;
    double ambient_temperature_k = 293.15;
    double contact_time_s = 0.01;
};

struct TireCompoundResponse {
    double shift_factor = 1.0;
    double storage_modulus_pa = 0.0;
    double loss_modulus_pa = 0.0;
    double loss_tangent = 0.0;
    double hyperelastic_stress_pa = 0.0;
    double adhesion_friction = 0.0;
    double hysteresis_friction = 0.0;
    double total_friction = 0.0;
    double heat_generation_w_m2 = 0.0;
    double wear_rate_m_s = 0.0;
    TireCompoundState next_state;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class PhysicsBasedTireCompoundLaboratory {
public:
    [[nodiscard]] TireCompoundResponse evaluate(
        const TireCompoundDefinition& compound,
        const TireCompoundState& state,
        const TireCompoundOperatingPoint& operating_point) const;
    [[nodiscard]] std::vector<TireCompoundResponse> sweep_temperature(
        const TireCompoundDefinition& compound,
        const TireCompoundOperatingPoint& operating_point,
        double minimum_temperature_k,
        double maximum_temperature_k,
        std::size_t points) const;
};

// -----------------------------------------------------------------------------
// Thermo-elastohydrodynamic tribology laboratory.
// -----------------------------------------------------------------------------

enum class LubricationRegime { Boundary, Mixed, Elastohydrodynamic, Hydrodynamic };

struct TribologyContact {
    std::string id;
    double load_n = 0.0;
    double entrainment_speed_m_s = 0.0;
    double sliding_speed_m_s = 0.0;
    double effective_radius_m = 0.0;
    double reduced_modulus_pa = 0.0;
    double surface_rms_roughness_m = 0.0;
    double lubricant_viscosity_pa_s = 0.0;
    double pressure_viscosity_coefficient_pa_inv = 0.0;
    double lubricant_density_kg_m3 = 850.0;
    double lubricant_heat_capacity_j_kg_k = 2000.0;
    double lubricant_thermal_conductivity_w_m_k = 0.13;
    double hardness_pa = 1.0e9;
    double wear_coefficient = 1.0e-8;
    double boundary_friction = 0.10;
    double ehl_shear_coefficient = 0.02;
    double inlet_temperature_k = 313.15;
    void validate() const;
};

struct TribologyState {
    double wear_depth_m = 0.0;
    double lubricant_temperature_k = 313.15;
    double debris_concentration = 0.0;
};

struct TribologyResult {
    double minimum_film_thickness_m = 0.0;
    double lambda_ratio = 0.0;
    LubricationRegime regime = LubricationRegime::Boundary;
    double friction_coefficient = 0.0;
    double friction_power_w = 0.0;
    double flash_temperature_k = 0.0;
    double contact_pressure_pa = 0.0;
    double wear_rate_m_s = 0.0;
    double scuffing_risk = 0.0;
    TribologyState next_state;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ThermoElastohydrodynamicTribologyLab {
public:
    [[nodiscard]] TribologyResult evaluate(
        const TribologyContact& contact,
        const TribologyState& state,
        double duration_s) const;
};

// -----------------------------------------------------------------------------
// Certified surrogate model and adaptive-fidelity controller.
// -----------------------------------------------------------------------------

struct SurrogateTrainingSample {
    std::vector<double> inputs;
    std::vector<double> outputs;
};

struct SurrogateDomain {
    std::vector<double> minimum;
    std::vector<double> maximum;
};

struct CertifiedSurrogateModel {
    std::size_t input_dimension = 0;
    std::size_t output_dimension = 0;
    SurrogateDomain domain;
    std::vector<std::vector<double>> coefficients;
    std::vector<double> residual_scale;
    double conformal_quantile = 0.0;
    double validation_rmse = 0.0;
    double maximum_validation_error = 0.0;
    double coverage = 0.0;
    double condition_number_estimate = 0.0;
    bool certified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct SurrogatePrediction {
    std::vector<double> mean;
    std::vector<double> lower;
    std::vector<double> upper;
    double normalized_extrapolation = 0.0;
    double estimated_error = 0.0;
    bool within_certified_domain = false;
    bool accepted = false;
    std::string source;
};

struct AdaptiveFidelityPolicy {
    double maximum_accepted_error = 0.05;
    double maximum_extrapolation = 0.05;
    double high_fidelity_cost = 100.0;
    double surrogate_cost = 1.0;
    bool update_surrogate_online = true;
};

struct AdaptiveFidelityDecision {
    SurrogatePrediction prediction;
    bool high_fidelity_executed = false;
    double estimated_cost = 0.0;
    std::string reason;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

using HighFidelityEvaluator = std::function<std::vector<double>(const std::vector<double>&)>;

class CertifiedSurrogateAdaptiveFidelityController {
public:
    [[nodiscard]] CertifiedSurrogateModel train(
        const std::vector<SurrogateTrainingSample>& samples,
        const SurrogateDomain& domain,
        double ridge = 1.0e-10,
        double required_coverage = 0.90) const;
    [[nodiscard]] SurrogatePrediction predict(
        const CertifiedSurrogateModel& model,
        const std::vector<double>& input,
        double maximum_error) const;
    [[nodiscard]] AdaptiveFidelityDecision evaluate(
        CertifiedSurrogateModel& model,
        const std::vector<double>& input,
        const AdaptiveFidelityPolicy& policy,
        const HighFidelityEvaluator& high_fidelity) const;
};

// -----------------------------------------------------------------------------
// Causal telemetry analysis and counterfactual replay.
// -----------------------------------------------------------------------------

struct TelemetryFrame {
    double time_s = 0.0;
    std::map<std::string, double> signals;
};

struct CausalEdgeDefinition {
    std::string cause;
    std::string effect;
    std::size_t lag_samples = 0;
};

struct FittedCausalEquation {
    std::string effect;
    std::vector<std::string> causes;
    std::vector<std::size_t> lags;
    std::vector<double> coefficients;
    double intercept = 0.0;
    double residual_std = 0.0;
    double coefficient_of_determination = 0.0;
};

struct CausalTelemetryModel {
    std::vector<FittedCausalEquation> equations;
    std::vector<std::string> topological_order;
    double sample_period_s = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct CounterfactualIntervention {
    std::string signal;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    std::optional<double> fixed_value;
    double additive_delta = 0.0;
};

struct CausalContribution {
    std::string signal;
    double contribution = 0.0;
    double normalized_contribution = 0.0;
};

struct CounterfactualReplayResult {
    std::vector<TelemetryFrame> counterfactual;
    std::map<std::string, double> endpoint_delta;
    std::vector<CausalContribution> root_causes;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_frames = false) const;
};

class CausalTelemetryCounterfactualEngine {
public:
    [[nodiscard]] CausalTelemetryModel fit(
        const std::vector<TelemetryFrame>& telemetry,
        const std::vector<CausalEdgeDefinition>& graph,
        double ridge = 1.0e-8) const;
    [[nodiscard]] CounterfactualReplayResult replay(
        const CausalTelemetryModel& model,
        const std::vector<TelemetryFrame>& factual,
        const std::vector<CounterfactualIntervention>& interventions,
        const std::vector<std::string>& outcome_signals = {}) const;
};

// -----------------------------------------------------------------------------
// Autonomous physical-test experiment planner.
// -----------------------------------------------------------------------------

struct PhysicalTestCandidate {
    std::string id;
    std::vector<double> parameter_sensitivities;
    double measurement_noise_variance = 1.0;
    double cost = 1.0;
    double duration_s = 1.0;
    double risk = 0.0;
    double rig_load_fraction = 0.0;
    std::vector<std::string> required_resources;
    std::map<std::string, double> control_setpoints;
    void validate(std::size_t parameter_count) const;
};

struct ExperimentPlanningConstraints {
    double maximum_total_cost = 1.0e18;
    double maximum_total_duration_s = 1.0e18;
    double maximum_test_risk = 1.0;
    double maximum_rig_load_fraction = 1.0;
    std::size_t maximum_tests = 1;
    std::set<std::string> available_resources;
};

struct PlannedPhysicalTest {
    std::string id;
    double expected_information_gain = 0.0;
    double utility = 0.0;
    double cumulative_cost = 0.0;
    double cumulative_duration_s = 0.0;
    std::map<std::string, double> control_setpoints;
    std::vector<std::string> safety_checks;
};

struct AutonomousExperimentPlan {
    std::vector<PlannedPhysicalTest> tests;
    std::vector<std::vector<double>> posterior_covariance;
    double total_information_gain = 0.0;
    double total_cost = 0.0;
    double total_duration_s = 0.0;
    std::vector<std::string> rejected_candidates;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AutonomousPhysicalTestPlanner {
public:
    [[nodiscard]] AutonomousExperimentPlan plan(
        const std::vector<std::vector<double>>& prior_covariance,
        const std::vector<PhysicalTestCandidate>& candidates,
        const ExperimentPlanningConstraints& constraints) const;
    [[nodiscard]] std::vector<std::vector<double>> assimilate_measurement(
        const std::vector<std::vector<double>>& prior_covariance,
        const PhysicalTestCandidate& test,
        double innovation,
        std::vector<double>& parameter_mean) const;
};

} // namespace aesim::advanced

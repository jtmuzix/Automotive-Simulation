#pragma once

#include "aesim/advanced/learning_environment.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced::expansion {

struct SafeRlConfig {
    std::size_t population = 32;
    std::size_t elite_count = 8;
    std::size_t generations = 24;
    std::size_t evaluation_episodes = 4;
    double exploration_std = 0.45;
    double minimum_std = 0.03;
    double smoothing = 0.25;
    double safety_cost_limit = 0.05;
    double safety_penalty = 250.0;
    std::uint64_t seed = 1;
    [[nodiscard]] static SafeRlConfig from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct SafeLinearPolicy {
    std::array<std::array<double, 6>, 3> weights{};
    std::array<double, 3> bias{};
    [[nodiscard]] VehicleAction action(const VehicleObservation& observation, bool shield = true) const;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SafeLinearPolicy from_document(const doc::Value& value);
};

struct SafeRlTrainingResult {
    SafeLinearPolicy policy;
    double mean_return = 0.0;
    double mean_safety_cost = 0.0;
    double lane_departure_rate = 0.0;
    double collision_rate = 0.0;
    std::size_t generations = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SafeReinforcementLearningLaboratory {
public:
    [[nodiscard]] static SafeRlTrainingResult train(const EnvironmentConfig& environment,
                                                    const SafeRlConfig& config);
    [[nodiscard]] static SafeRlTrainingResult evaluate(const EnvironmentConfig& environment,
                                                       const SafeLinearPolicy& policy,
                                                       std::size_t episodes,
                                                       std::uint64_t seed);
};

struct CmpRecord {
    std::uint16_t capture_module_id = 0;
    std::uint16_t data_sink_id = 0;
    std::uint16_t source_interface_id = 0;
    std::uint16_t message_type = 1;
    std::uint32_t sequence = 0;
    std::uint64_t timestamp_ns = 0;
    std::vector<std::uint8_t> payload;
    [[nodiscard]] std::vector<std::uint8_t> encode() const;
    [[nodiscard]] static CmpRecord decode(const std::vector<std::uint8_t>& frame);
    [[nodiscard]] doc::Value to_document(bool include_payload = true) const;
    [[nodiscard]] static CmpRecord from_document(const doc::Value& value);
};

struct CmpCaptureStatistics {
    std::uint64_t accepted = 0;
    std::uint64_t duplicate = 0;
    std::uint64_t reordered = 0;
    std::uint64_t missing = 0;
    std::uint64_t crc_failures = 0;
    std::uint64_t first_timestamp_ns = 0;
    std::uint64_t last_timestamp_ns = 0;
    [[nodiscard]] doc::Value to_document() const;
};

class AsamCmpCapturePlatform {
public:
    void ingest(const std::vector<std::uint8_t>& frame);
    [[nodiscard]] const std::vector<CmpRecord>& records() const noexcept { return records_; }
    [[nodiscard]] CmpCaptureStatistics statistics() const noexcept { return stats_; }
    void save_capture(const std::string& path) const;
    [[nodiscard]] static AsamCmpCapturePlatform load_capture(const std::string& path);
private:
    std::vector<CmpRecord> records_;
    CmpCaptureStatistics stats_;
    std::map<std::uint32_t, bool> seen_sequences_;
    std::optional<std::uint32_t> highest_sequence_;
};

enum class TrafficParticipantKind { PassengerCar, Truck, Bus, Motorcycle, Bicycle, Pedestrian, Trailer, EmergencyVehicle, Other };

struct TrafficParticipant {
    std::string id;
    TrafficParticipantKind kind = TrafficParticipantKind::PassengerCar;
    double length_m = 4.5;
    double width_m = 1.8;
    double height_m = 1.5;
    double mass_kg = 1500.0;
    double maximum_speed_mps = 55.0;
    double maximum_acceleration_mps2 = 4.0;
    double maximum_deceleration_mps2 = 9.0;
    double maximum_lateral_acceleration_mps2 = 8.0;
    std::map<std::string, std::string> classifications;
    std::vector<std::string> articulated_children;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static TrafficParticipant from_document(const doc::Value& value);
};

struct TrafficParticipantValidation {
    bool valid = false;
    std::vector<std::string> errors;
    std::vector<std::string> warnings;
    [[nodiscard]] doc::Value to_document() const;
};

class AsamTrafficParticipantsPlatform {
public:
    [[nodiscard]] static TrafficParticipantValidation validate(const TrafficParticipant& participant);
    [[nodiscard]] static doc::Value to_open_scenario_catalog(const TrafficParticipant& participant);
    [[nodiscard]] static doc::Value to_osi_object(const TrafficParticipant& participant);
    [[nodiscard]] static doc::Value canonicalize_catalog(const doc::Value& request);
};

struct SysmlChange {
    enum class Operation { Upsert, Erase } operation = Operation::Upsert;
    std::string element_id;
    doc::Value element;
};

struct SysmlCommitResult {
    std::string commit_id;
    std::string parent_commit_id;
    std::string branch;
    std::size_t element_count = 0;
    std::string tree_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SysmlV2Repository {
public:
    explicit SysmlV2Repository(std::string root_directory);
    void initialize();
    [[nodiscard]] SysmlCommitResult commit(const std::string& branch,
                                           const std::vector<SysmlChange>& changes,
                                           const std::string& message,
                                           const std::string& author);
    [[nodiscard]] doc::Value query(const std::string& branch,
                                   const std::string& type_filter = {},
                                   const std::string& text_filter = {}) const;
    [[nodiscard]] doc::Value diff(const std::string& commit_a, const std::string& commit_b) const;
    [[nodiscard]] doc::Value head(const std::string& branch) const;
private:
    std::string root_;
    [[nodiscard]] doc::Value load_refs() const;
    void store_refs(const doc::Value& refs) const;
    [[nodiscard]] doc::Value load_commit(const std::string& commit_id) const;
};

struct ScientificVariable {
    std::string name;
    std::string unit;
    std::vector<double> values;
};

struct ScientificRecord {
    std::uint64_t step = 0;
    double simulation_time_s = 0.0;
    std::vector<ScientificVariable> variables;
    [[nodiscard]] doc::Value to_document() const;
};

class ScientificStreamWriter {
public:
    ScientificStreamWriter(std::string path, bool append = false);
    void write(const ScientificRecord& record);
    void close();
    ~ScientificStreamWriter();
private:
    std::string path_;
    bool append_ = false;
    bool closed_ = false;
};

class ScientificStreamReader {
public:
    [[nodiscard]] static std::vector<ScientificRecord> read_all(const std::string& path,
                                                                const std::string& variable_filter = {});
    [[nodiscard]] static doc::Value inspect(const std::string& path);
};

struct MpiRuntimeCapabilities {
    bool mpi_available = false;
    int mpi_major = 0;
    int mpi_minor = 0;
    bool sessions = false;
    bool partitioned_communication = false;
    bool persistent_collectives = false;
    bool ulfm = false;
    int world_size = 1;
    int rank = 0;
    [[nodiscard]] doc::Value to_document() const;
};

class ModernMpiTransportRuntime {
public:
    [[nodiscard]] static MpiRuntimeCapabilities capabilities();
    [[nodiscard]] static std::vector<std::size_t> balanced_partition(std::size_t work_items, int ranks);
    [[nodiscard]] static double deterministic_sum(const std::vector<double>& values);
    [[nodiscard]] static double persistent_allreduce_sum(double local_value);
    [[nodiscard]] static int session_world_size();
};

struct LinearSystem {
    std::size_t n = 0;
    std::vector<double> matrix;
    std::vector<double> rhs;
    [[nodiscard]] static LinearSystem from_document(const doc::Value& value);
};

struct SolverResult {
    std::string backend;
    std::vector<double> solution;
    std::size_t iterations = 0;
    double residual_l2 = 0.0;
    bool converged = false;
    std::string detail;
    [[nodiscard]] doc::Value to_document() const;
};

class QualifiedSolverBackends {
public:
    [[nodiscard]] static SolverResult dense_lu(const LinearSystem& system);
    [[nodiscard]] static SolverResult conjugate_gradient(const LinearSystem& system,
                                                         std::size_t maximum_iterations = 1000,
                                                         double tolerance = 1e-10);
    [[nodiscard]] static SolverResult bicgstab(const LinearSystem& system,
                                               std::size_t maximum_iterations = 1000,
                                               double tolerance = 1e-10);
    [[nodiscard]] static SolverResult external_process(const LinearSystem& system,
                                                       const std::vector<std::string>& command,
                                                       const std::string& working_directory,
                                                       int timeout_seconds = 30);
    [[nodiscard]] static doc::Value consensus(const LinearSystem& system,
                                              double residual_tolerance = 1e-8,
                                              double disagreement_tolerance = 1e-7);
};

enum class SensorBusProtocol { Sent, Psi5, Dsi3, Cxpi };

struct SensorBusFrame {
    SensorBusProtocol protocol = SensorBusProtocol::Sent;
    std::uint16_t identifier = 0;
    std::vector<std::uint8_t> payload;
    double tick_period_s = 3.0e-6;
    std::uint64_t seed = 1;
};

struct SensorBusWaveform {
    std::vector<double> edge_times_s;
    std::vector<int> levels;
    std::vector<std::uint8_t> decoded_payload;
    std::uint64_t checksum = 0;
    bool checksum_valid = false;
    double measured_bitrate_hz = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class AutomotiveSensorBusPhysicalLayer {
public:
    [[nodiscard]] static SensorBusWaveform encode(const SensorBusFrame& frame,
                                                  double jitter_fraction = 0.0,
                                                  double edge_drop_probability = 0.0);
    [[nodiscard]] static SensorBusWaveform decode(SensorBusProtocol protocol,
                                                  const std::vector<double>& edge_times_s,
                                                  const std::vector<int>& levels,
                                                  double tick_period_s);
};

struct PbrMaterial {
    std::string name;
    std::array<double, 4> base_color{0.8, 0.8, 0.8, 1.0};
    double metallic = 0.0;
    double roughness = 0.5;
    std::array<double, 3> emissive{0.0, 0.0, 0.0};
    double ior = 1.5;
    double transmission = 0.0;
    double lidar_reflectivity = 0.5;
    double radar_permittivity_real = 2.5;
    double radar_loss_tangent = 0.02;
    [[nodiscard]] doc::Value to_document() const;
};

class MaterialAssetPipeline {
public:
    [[nodiscard]] static std::vector<PbrMaterial> import_gltf(const std::string& path);
    static void export_gltf(const std::string& path, const std::vector<PbrMaterial>& materials);
    [[nodiscard]] static std::vector<PbrMaterial> import_materialx(const std::string& path);
    static void export_materialx(const std::string& path, const std::vector<PbrMaterial>& materials);
    [[nodiscard]] static doc::Value compare_roundtrip(const std::vector<PbrMaterial>& materials,
                                                      const std::string& working_directory);
};

struct Particle {
    std::array<double, 3> position_m{0.0, 0.0, 0.0};
    std::array<double, 3> velocity_mps{0.0, 0.0, 0.0};
    double mass_kg = 1.0;
    double density_kg_m3 = 1000.0;
    double pressure_pa = 0.0;
    double radius_m = 0.01;
};

struct ParticleStepConfig {
    double dt_s = 1.0e-4;
    double smoothing_length_m = 0.03;
    double rest_density_kg_m3 = 1000.0;
    double stiffness_pa = 2.0e5;
    double viscosity_pa_s = 0.001;
    double dem_stiffness_n_m = 1.0e5;
    double dem_damping_n_s_m = 50.0;
    std::array<double, 3> gravity_mps2{0.0, 0.0, -9.80665};
};

struct ParticleRuntimeResult {
    std::vector<Particle> particles;
    std::string backend;
    std::size_t neighbor_pairs = 0;
    double total_kinetic_energy_j = 0.0;
    bool finite = false;
    [[nodiscard]] doc::Value to_document() const;
};

class GpuParticleMultiphysicsRuntime {
public:
    [[nodiscard]] static bool native_gpu_available() noexcept;
    [[nodiscard]] static ParticleRuntimeResult sph_step(const std::vector<Particle>& particles,
                                                        const ParticleStepConfig& config,
                                                        bool prefer_gpu = true);
    [[nodiscard]] static ParticleRuntimeResult dem_step(const std::vector<Particle>& particles,
                                                        const ParticleStepConfig& config,
                                                        bool prefer_gpu = true);
};

struct LubricantState {
    double oxidation_fraction = 0.0;
    double nitration_fraction = 0.0;
    double additive_fraction = 1.0;
    double soot_mass_fraction = 0.0;
    double water_ppm = 0.0;
    double fuel_dilution_fraction = 0.0;
    double tan_mg_koh_g = 1.0;
    double tbn_mg_koh_g = 8.0;
    double viscosity_100c_cst = 12.0;
    double wear_metal_ppm = 0.0;
    double varnish_index = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct LubricantOperatingPoint {
    double temperature_c = 100.0;
    double load_fraction = 0.5;
    double oxygen_fraction = 0.21;
    double blowby_fraction = 0.0;
    double water_ingress_ppm_h = 0.0;
    double fuel_ingress_fraction_h = 0.0;
    double soot_ingress_fraction_h = 0.0;
};

class LubricantChemistryConditionMonitoring {
public:
    [[nodiscard]] static LubricantState advance(LubricantState state,
                                                const LubricantOperatingPoint& operating,
                                                double duration_hours,
                                                double maximum_step_hours = 0.1);
    [[nodiscard]] static doc::Value condition_report(const LubricantState& state);
};

struct TireAcousticInput {
    double speed_mps = 30.0;
    double effective_radius_m = 0.32;
    double cavity_sound_speed_mps = 343.0;
    double tread_pitch_m = 0.035;
    double radial_force_variation_n = 50.0;
    double lateral_force_variation_n = 30.0;
    double conicity_n = 20.0;
    double ply_steer_n = 10.0;
    double imbalance_kg_m = 0.001;
    double flat_spot_depth_m = 0.0;
};

struct TireAcousticResult {
    std::vector<double> frequencies_hz;
    std::vector<double> relative_db;
    double cavity_mode_hz = 0.0;
    double tread_pass_hz = 0.0;
    double rotation_hz = 0.0;
    double steering_pull_n = 0.0;
    double imbalance_force_n = 0.0;
    double uniformity_score = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class TireAcousticUniformityLaboratory {
public:
    [[nodiscard]] static TireAcousticResult analyze(const TireAcousticInput& input);
};

struct Barrier {
    std::string id;
    std::string name;
    double demand_failure_probability = 0.01;
    double availability = 1.0;
    double common_cause_beta = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct BowTieScenario {
    std::string hazard;
    double initiating_frequency_per_hour = 1.0e-6;
    std::vector<std::string> causes;
    std::vector<std::string> consequences;
    std::vector<Barrier> prevention_barriers;
    std::vector<Barrier> mitigation_barriers;
};

class HazopBowTieBarrierAssurance {
public:
    [[nodiscard]] static doc::Value hazop(const doc::Value& process_definition);
    [[nodiscard]] static doc::Value bowtie(const BowTieScenario& scenario);
    [[nodiscard]] static BowTieScenario from_document(const doc::Value& value);
};

class SoftwareSupplyChainEvidencePlatform {
public:
    [[nodiscard]] static doc::Value analyze(const doc::Value& request,
                                            const std::string& working_directory = {});
    [[nodiscard]] static doc::Value compare_builds(const std::string& first_path,
                                                   const std::string& second_path);
};

class FrontierExpansionPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain, const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

} // namespace aesim::advanced::expansion

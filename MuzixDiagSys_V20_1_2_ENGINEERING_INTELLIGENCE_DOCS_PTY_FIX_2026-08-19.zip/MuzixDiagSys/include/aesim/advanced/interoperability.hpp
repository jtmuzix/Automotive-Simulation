#pragma once

#include "aesim/professional/document.hpp"

#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

struct sqlite3;

namespace aesim::advanced {

struct CanonicalVehicleFrame {
    std::int64_t timestamp_ns = 0;
    std::string frame_id = "map";
    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
    double roll_rad = 0.0;
    double pitch_rad = 0.0;
    double yaw_rad = 0.0;
    double vx_m_s = 0.0;
    double vy_m_s = 0.0;
    double vz_m_s = 0.0;
    double ax_m_s2 = 0.0;
    double ay_m_s2 = 0.0;
    double az_m_s2 = 0.0;
    double steering_rad = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    std::map<std::string, double> numeric_extensions;
    std::map<std::string, std::string> text_extensions;

    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static CanonicalVehicleFrame from_document(const doc::Value& value);
};

class InteroperabilityTranslator {
public:
    [[nodiscard]] static doc::Value to_carla(const CanonicalVehicleFrame& frame);
    [[nodiscard]] static CanonicalVehicleFrame from_carla(const doc::Value& value);
    [[nodiscard]] static doc::Value to_autoware(const CanonicalVehicleFrame& frame);
    [[nodiscard]] static CanonicalVehicleFrame from_autoware(const doc::Value& value);
    [[nodiscard]] static doc::Value to_apollo(const CanonicalVehicleFrame& frame);
    [[nodiscard]] static CanonicalVehicleFrame from_apollo(const doc::Value& value);
};

struct RosbagTopic {
    std::int64_t id = 0;
    std::string name;
    std::string type;
    std::string serialization_format = "cdr";
    std::string offered_qos_profiles;
};

struct RosbagMessage {
    std::int64_t id = 0;
    std::int64_t topic_id = 0;
    std::int64_t timestamp_ns = 0;
    std::vector<std::uint8_t> data;
};

class Rosbag2Storage {
public:
    Rosbag2Storage() = default;
    ~Rosbag2Storage();
    Rosbag2Storage(const Rosbag2Storage&) = delete;
    Rosbag2Storage& operator=(const Rosbag2Storage&) = delete;

    void create(const std::string& database_path, const std::string& storage_identifier = "sqlite3");
    void open_read_only(const std::string& database_path);
    void close();
    [[nodiscard]] bool is_open() const noexcept { return database_ != nullptr; }
    [[nodiscard]] std::int64_t register_topic(const RosbagTopic& topic);
    void write_message(std::int64_t topic_id, std::int64_t timestamp_ns,
                       const std::vector<std::uint8_t>& data);
    [[nodiscard]] std::vector<RosbagTopic> topics() const;
    [[nodiscard]] std::vector<RosbagMessage> read_messages(
        std::optional<std::int64_t> topic_id = std::nullopt,
        std::optional<std::int64_t> start_ns = std::nullopt,
        std::optional<std::int64_t> end_ns = std::nullopt) const;
    void write_metadata_yaml(const std::string& path, const std::string& relative_database_name) const;
    [[nodiscard]] doc::Value summary() const;

private:
    sqlite3* database_ = nullptr;
    std::string path_;
    bool writable_ = false;
    std::string storage_identifier_ = "sqlite3";
    void execute(const std::string& sql) const;
};

struct RuntimeIntegrationStatus {
    std::string integration;
    bool available = false;
    std::string executable;
    std::string detail;
};

class RuntimeIntegrationProbe {
public:
    [[nodiscard]] static std::vector<RuntimeIntegrationStatus> probe_all();
    [[nodiscard]] static doc::Value to_document(const std::vector<RuntimeIntegrationStatus>& statuses);
};

} // namespace aesim::advanced

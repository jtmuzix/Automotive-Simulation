#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// OpenSCENARIO 2.x-inspired compiler, executable scenario IR, and coverage
// closure. The parser implements a deterministic, typed textual subset intended
// for production scenario authoring and generated regression assets.
// -----------------------------------------------------------------------------

enum class Osc2ValueType { Number, Boolean, String };

enum class Osc2InstructionKind {
    Set,
    Add,
    Multiply,
    Assert,
    Emit
};

struct Osc2Parameter {
    std::string name;
    Osc2ValueType type = Osc2ValueType::Number;
    doc::Value default_value;
    std::optional<double> minimum;
    std::optional<double> maximum;
    std::vector<doc::Value> choices;
};

struct Osc2Actor {
    std::string name;
    std::string type;
    std::map<std::string, doc::Value> initial_state;
};

struct Osc2Instruction {
    std::string id;
    double timestamp_s = 0.0;
    Osc2InstructionKind kind = Osc2InstructionKind::Set;
    std::string target;
    std::string expression;
};

struct Osc2CoverageGoal {
    std::string id;
    std::string expression;
    double weight = 1.0;
};

struct Osc2ScenarioProgram {
    std::string name;
    std::map<std::string, Osc2Parameter> parameters;
    std::map<std::string, Osc2Actor> actors;
    std::vector<Osc2Instruction> instructions;
    std::vector<Osc2CoverageGoal> coverage_goals;
    std::map<std::string, std::string> metadata;
    std::string source_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct Osc2CompileResult {
    bool valid = false;
    Osc2ScenarioProgram program;
    std::vector<std::string> diagnostics;
    std::string ir_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct Osc2ExecutionResult {
    bool passed = true;
    std::map<std::string, doc::Value> parameters;
    std::map<std::string, std::map<std::string, doc::Value>> actor_state;
    std::map<std::string, bool> coverage;
    std::vector<std::string> emitted_events;
    std::vector<std::string> assertion_failures;
    std::string trace_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct Osc2CoverageCase {
    std::string id;
    std::map<std::string, doc::Value> bindings;
    std::set<std::string> covered_goals;
    std::string case_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct Osc2CoverageClosureResult {
    std::vector<Osc2CoverageCase> selected_cases;
    std::set<std::string> covered_goals;
    std::set<std::string> uncovered_goals;
    double weighted_coverage = 0.0;
    std::size_t candidate_count = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class OpenScenario2Compiler {
public:
    [[nodiscard]] Osc2CompileResult compile(const std::string& source) const;
    [[nodiscard]] Osc2ExecutionResult execute(
        const Osc2ScenarioProgram& program,
        const std::map<std::string, doc::Value>& bindings = {}) const;
    [[nodiscard]] Osc2CoverageClosureResult close_coverage(
        const Osc2ScenarioProgram& program,
        std::size_t maximum_cases = 64,
        std::size_t maximum_candidates = 4096) const;
    [[nodiscard]] std::string emit_canonical_source(const Osc2ScenarioProgram& program) const;
};

// -----------------------------------------------------------------------------
// Localization, navigation integrity, and HD-map lifecycle assurance.
// -----------------------------------------------------------------------------

struct LocalizationState {
    double timestamp_s = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double vx_m_s = 0.0;
    double vy_m_s = 0.0;
    double yaw_rad = 0.0;
    double gyro_bias_rad_s = 0.0;
    double accel_bias_m_s2 = 0.0;
    std::array<double, 64> covariance{}; // row-major 8x8 covariance
    [[nodiscard]] doc::Value to_document() const;
};

struct ImuMeasurement {
    double timestamp_s = 0.0;
    double longitudinal_accel_m_s2 = 0.0;
    double lateral_accel_m_s2 = 0.0;
    double yaw_rate_rad_s = 0.0;
    double acceleration_sigma_m_s2 = 0.05;
    double yaw_rate_sigma_rad_s = 0.002;
};

struct GnssMeasurement {
    double timestamp_s = 0.0;
    double x_m = 0.0;
    double y_m = 0.0;
    double sigma_m = 1.0;
    unsigned satellites = 8;
    double hdop = 1.0;
    bool correction_valid = false;
};

struct WheelOdometryMeasurement {
    double timestamp_s = 0.0;
    double speed_m_s = 0.0;
    double sigma_m_s = 0.1;
};

struct HdMapLane {
    std::string id;
    std::vector<std::array<double, 2>> centerline_m;
    double half_width_m = 1.75;
    double confidence = 1.0;
    std::string version;
};

struct LaneObservation {
    double timestamp_s = 0.0;
    std::string lane_id;
    double lateral_offset_m = 0.0;
    double heading_error_rad = 0.0;
    double sigma_offset_m = 0.15;
    double sigma_heading_rad = 0.02;
    double confidence = 1.0;
};

struct MapLandmark {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    std::string semantic_class;
    double confidence = 1.0;
};

struct LandmarkObservation {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    std::string semantic_class;
    double sigma_m = 0.25;
};

struct LocalizationIntegrityResult {
    LocalizationState state;
    double horizontal_protection_level_m = 0.0;
    double innovation_chi_square = 0.0;
    double integrity_risk = 0.0;
    bool gnss_fault_detected = false;
    bool map_confident = true;
    bool within_safety_envelope = true;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct HdMapChange {
    std::string landmark_id;
    std::string change_type; // added, removed, moved, semantic-change
    double displacement_m = 0.0;
    double confidence = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct HdMapAssuranceReport {
    std::vector<HdMapChange> changes;
    double map_confidence = 1.0;
    bool update_required = false;
    std::string current_map_sha256;
    std::string proposed_map_sha256;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class LocalizationAndMapAssurance {
public:
    explicit LocalizationAndMapAssurance(LocalizationState initial = {});
    void set_lanes(std::vector<HdMapLane> lanes);
    void set_landmarks(std::vector<MapLandmark> landmarks);
    void predict(const ImuMeasurement& measurement);
    void update_gnss(const GnssMeasurement& measurement);
    void update_wheel_odometry(const WheelOdometryMeasurement& measurement);
    void update_lane(const LaneObservation& observation);
    [[nodiscard]] LocalizationIntegrityResult assess(
        double alert_limit_m,
        double maximum_integrity_risk = 1.0e-5) const;
    [[nodiscard]] HdMapAssuranceReport assess_map(
        const std::vector<LandmarkObservation>& observations,
        double movement_threshold_m = 1.0,
        double missing_confidence_threshold = 0.6) const;
    [[nodiscard]] const LocalizationState& state() const noexcept { return state_; }

private:
    LocalizationState state_;
    std::map<std::string, HdMapLane> lanes_;
    std::map<std::string, MapLandmark> landmarks_;
    double last_gnss_chi_square_ = 0.0;
    bool gnss_fault_detected_ = false;
    double map_confidence_ = 1.0;
};

} // namespace aesim::advanced

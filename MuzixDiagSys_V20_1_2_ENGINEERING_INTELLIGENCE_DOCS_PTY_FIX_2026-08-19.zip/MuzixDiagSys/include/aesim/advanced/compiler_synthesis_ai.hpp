#pragma once

#include "aesim/electrification/electrification.hpp"
#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Simulation domain-specific IR and MLIR-compatible compiler pipeline
// -----------------------------------------------------------------------------

enum class SimulationIrOpcode {
    Input,
    Constant,
    Copy,
    Affine,
    Add,
    Subtract,
    Multiply,
    Divide,
    Clamp,
    IntegrateEuler,
    ReduceSum,
    AssertRange,
    Output
};

struct SimulationIrTensorType {
    std::vector<std::size_t> shape;
    std::string unit = "1";
    std::string precision = "f64";
    [[nodiscard]] std::size_t element_count() const;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SimulationIrTensorType from_document(const doc::Value& value);
};

struct SimulationIrOperation {
    std::string id;
    SimulationIrOpcode opcode = SimulationIrOpcode::Copy;
    std::vector<std::string> inputs;
    std::string output;
    SimulationIrTensorType type;
    std::map<std::string, double> numeric_attributes;
    std::map<std::string, std::string> string_attributes;
    std::vector<double> literal;
    std::string backend = "auto";
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SimulationIrOperation from_document(const doc::Value& value);
};

struct SimulationIrModule {
    std::string name = "simulation";
    std::vector<SimulationIrOperation> operations;
    std::vector<std::string> outputs;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static SimulationIrModule from_document(const doc::Value& value);
};

struct SimulationCompilerOptions {
    bool constant_folding = true;
    bool common_subexpression_elimination = true;
    bool dead_operation_elimination = true;
    bool fuse_affine_operations = true;
    bool validate_dimensions = true;
    bool deterministic = true;
    std::string default_backend = "auto";
};

struct SimulationCompilationStatistics {
    std::size_t input_operations = 0;
    std::size_t output_operations = 0;
    std::size_t constants_folded = 0;
    std::size_t common_subexpressions_removed = 0;
    std::size_t dead_operations_removed = 0;
    std::size_t affine_operations_fused = 0;
    std::size_t estimated_bytes = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct SimulationExecutionResult {
    bool passed = true;
    std::map<std::string, std::vector<double>> values;
    std::vector<std::string> assertions;
    std::string deterministic_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CompiledSimulationModule {
public:
    CompiledSimulationModule() = default;
    [[nodiscard]] const SimulationIrModule& optimized_module() const noexcept;
    [[nodiscard]] const std::string& mlir_text() const noexcept;
    [[nodiscard]] const SimulationCompilationStatistics& statistics() const noexcept;
    [[nodiscard]] const std::vector<std::string>& diagnostics() const noexcept;
    [[nodiscard]] SimulationExecutionResult execute(
        const std::map<std::string, std::vector<double>>& inputs,
        double time_step_s = 0.001) const;
    [[nodiscard]] doc::Value to_document() const;
private:
    friend class SimulationMlirCompiler;
    SimulationIrModule module_;
    std::string mlir_text_;
    SimulationCompilationStatistics statistics_;
    std::vector<std::string> diagnostics_;
};

class SimulationMlirCompiler {
public:
    [[nodiscard]] CompiledSimulationModule compile(
        const SimulationIrModule& module,
        const SimulationCompilerOptions& options = {}) const;
    [[nodiscard]] static std::string emit_mlir(const SimulationIrModule& module);
    [[nodiscard]] static doc::Value validate(const SimulationIrModule& module);
};

// -----------------------------------------------------------------------------
// Formal controller synthesis and safety architecture synthesis
// -----------------------------------------------------------------------------

struct SafetyGameTransition {
    std::string state;
    std::string action;
    std::string successor;
    bool environment_choice = false;
};

struct SafetyGameSpecification {
    std::set<std::string> states;
    std::set<std::string> initial_states;
    std::set<std::string> unsafe_states;
    std::set<std::string> actions;
    std::vector<SafetyGameTransition> transitions;
    [[nodiscard]] static SafetyGameSpecification from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct SynthesizedController {
    bool realizable = false;
    std::set<std::string> winning_region;
    std::map<std::string, std::string> strategy;
    std::vector<std::string> losing_initial_states;
    std::string proof_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class FormalControllerSynthesizer {
public:
    [[nodiscard]] SynthesizedController synthesize(const SafetyGameSpecification& specification) const;
    [[nodiscard]] bool verify_strategy(const SafetyGameSpecification& specification,
                                       const SynthesizedController& controller,
                                       std::string& diagnostic) const;
};

struct SafetyArchitectureCandidate {
    std::string id;
    std::set<std::string> mitigated_hazards;
    std::string independence_group;
    double cost = 0.0;
    double mass_kg = 0.0;
    double power_w = 0.0;
    double diagnostic_coverage = 0.0;
    double availability = 1.0;
    [[nodiscard]] static SafetyArchitectureCandidate from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct SafetyArchitectureRequirement {
    std::string hazard;
    double minimum_coverage = 0.9;
    std::size_t minimum_independent_channels = 1;
};

struct SafetyArchitectureSynthesisResult {
    bool feasible = false;
    std::vector<SafetyArchitectureCandidate> selected;
    double total_cost = 0.0;
    double total_mass_kg = 0.0;
    double total_power_w = 0.0;
    std::map<std::string, double> achieved_coverage;
    std::map<std::string, std::size_t> independent_channels;
    std::string certificate_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SafetyArchitectureSynthesizer {
public:
    [[nodiscard]] SafetyArchitectureSynthesisResult synthesize(
        const std::vector<SafetyArchitectureCandidate>& candidates,
        const std::vector<SafetyArchitectureRequirement>& requirements,
        double cost_weight = 1.0,
        double mass_weight = 0.1,
        double power_weight = 0.01) const;
};

// -----------------------------------------------------------------------------
// ONNX verification and deployment-equivalence laboratory
// -----------------------------------------------------------------------------

struct IntervalTensor {
    std::vector<std::int64_t> shape;
    std::vector<double> lower;
    std::vector<double> upper;
    [[nodiscard]] std::size_t element_count() const;
    [[nodiscard]] doc::Value to_document() const;
};

struct OnnxOutputProperty {
    std::string output;
    std::size_t index = 0;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
};

struct OnnxVerificationResult {
    bool verified = false;
    bool conclusive = true;
    std::map<std::string, IntervalTensor> output_bounds;
    std::vector<std::string> violations;
    std::vector<std::string> diagnostics;
    std::string model_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct DeploymentEquivalenceSample {
    std::map<std::string, electrification::Tensor> inputs;
};

struct DeploymentEquivalenceResult {
    bool equivalent = true;
    std::string deployment_mode;
    std::size_t samples = 0;
    double maximum_absolute_error = 0.0;
    double maximum_relative_error = 0.0;
    std::size_t mismatches = 0;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

class OnnxVerificationLaboratory {
public:
    void load_model(const std::string& path);
    void load_model_bytes(const std::vector<std::uint8_t>& bytes,
                          const std::string& source_name = "memory.onnx");
    [[nodiscard]] OnnxVerificationResult verify_intervals(
        const std::map<std::string, IntervalTensor>& input_bounds,
        const std::vector<OnnxOutputProperty>& properties) const;
    [[nodiscard]] DeploymentEquivalenceResult verify_deployment_equivalence(
        const std::vector<DeploymentEquivalenceSample>& samples,
        const std::string& mode,
        double absolute_tolerance,
        double relative_tolerance) const;
    [[nodiscard]] const electrification::OnnxModel& model() const noexcept;
private:
    electrification::OnnxModel model_;
};

} // namespace aesim::advanced

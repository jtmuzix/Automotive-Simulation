#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::nascarint {

class NascarIntegratedCoSimulationRuntime {
public:
    [[nodiscard]] doc::Value run(const doc::Value& request,
                                 const std::string& working_directory = {}) const;
};

class NascarTelemetryAssimilationCalibration {
public:
    [[nodiscard]] doc::Value assimilate(const doc::Value& request,
                                        const std::string& working_directory = {}) const;
};

class NascarUnifiedUncertaintyModelValidityFramework {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarFlexibleMultibodyVehicle {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarDetailedTireConstructionContactModel {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarUnsteadyAeroelasticWakeModel {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarClosedLoopEcuDrivelineController {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarCranktrainLubricationFuelThermalTwin {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarPitRoadDiscreteEventTwin {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarOccupantBiomechanicsHeatEgress {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarPavementMechanicsScannedTrackTwin {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarSprayPlumeOpticalVisibilityPhysics {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarIntegratedFidelityPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::nascarint

#pragma once

#include "aesim/advanced/deep_engineering_platform.hpp"
#include "aesim/advanced/formula_one_fidelity_platform.hpp"
#include "aesim/advanced/formula_one_multiphysics_platform.hpp"
#include "aesim/advanced/formula_one_realism_platform.hpp"
#include "aesim/advanced/formula_one_integrated_operations_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Versioned FIA Formula One technical-regulation compliance.
// -----------------------------------------------------------------------------

enum class F1RuleSeverity { Information, Warning, NonCompliant, SafetyCritical };
enum class F1RuleComparison { Minimum, Maximum, ClosedRange, Exact, RequiredTrue, RequiredFalse };
enum class F1TechnicalDomain {
    GeneralDimensions,
    Mass,
    Bodywork,
    ActiveAerodynamics,
    WheelsAndTyres,
    PowerUnit,
    EnergyRecovery,
    Fuel,
    Electrical,
    Safety
};

struct F1RegulationRule {
    std::string id;
    std::string article_reference;
    std::string field;
    F1TechnicalDomain domain = F1TechnicalDomain::GeneralDimensions;
    F1RuleComparison comparison = F1RuleComparison::Maximum;
    double minimum = 0.0;
    double maximum = 0.0;
    double target = 0.0;
    double tolerance = 0.0;
    std::string unit;
    F1RuleSeverity severity = F1RuleSeverity::NonCompliant;
    std::string description;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RegulationIssue {
    int season = 2026;
    std::string section = "C";
    int issue = 0;
    std::string publication_date;
    std::string source_title;
    std::string source_locator;
    std::vector<F1RegulationRule> rules;
    [[nodiscard]] std::string identifier() const;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static F1RegulationIssue from_document(const doc::Value& value);
};

struct F1CarTechnicalSubmission {
    std::string design_id;
    std::map<std::string, double> numeric_fields;
    std::map<std::string, bool> boolean_fields;
    std::vector<Vector3> body_reference_points_m;
    Vector3 legal_volume_min_m{-1.0, -0.95, 0.0};
    Vector3 legal_volume_max_m{4.5, 0.95, 1.2};
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RuleEvaluation {
    std::string rule_id;
    std::string article_reference;
    F1RuleSeverity severity = F1RuleSeverity::NonCompliant;
    bool passed = false;
    bool field_present = false;
    double measured_value = 0.0;
    double margin = 0.0;
    std::string unit;
    std::string diagnostic;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1ComplianceReport {
    std::string design_id;
    std::string regulation_identifier;
    bool compliant = false;
    std::size_t passed_rules = 0;
    std::size_t failed_rules = 0;
    std::size_t safety_critical_failures = 0;
    std::vector<F1RuleEvaluation> evaluations;
    std::vector<std::size_t> body_points_outside_legal_volume;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RegulationDifference {
    std::vector<std::string> added_rule_ids;
    std::vector<std::string> removed_rule_ids;
    std::vector<std::string> changed_rule_ids;
    [[nodiscard]] doc::Value to_document() const;
};

class F1RegulationRepository {
public:
    F1RegulationRepository();
    void add(F1RegulationIssue issue);
    [[nodiscard]] const F1RegulationIssue& get(int season, const std::string& section,
                                               int issue) const;
    [[nodiscard]] std::vector<std::string> identifiers() const;
    [[nodiscard]] F1RegulationDifference compare(const F1RegulationIssue& older,
                                                 const F1RegulationIssue& newer) const;
    [[nodiscard]] static F1RegulationIssue fia_2026_section_c_issue_18();
    [[nodiscard]] static F1RegulationIssue fia_2026_section_c_issue_19();
private:
    std::map<std::string, F1RegulationIssue> issues_;
};

class F1TechnicalComplianceEngine {
public:
    [[nodiscard]] F1ComplianceReport evaluate(const F1RegulationIssue& issue,
                                              const F1CarTechnicalSubmission& submission) const;
};

// -----------------------------------------------------------------------------
// 2026 Formula One power-unit and energy-management laboratory.
// -----------------------------------------------------------------------------

struct F1PowerUnit2026Configuration {
    double maximum_ice_power_kw = 400.0;
    double maximum_mguk_power_kw = 350.0;
    double non_acceleration_zone_mguk_limit_kw = 250.0;
    double maximum_recoverable_energy_mj_per_lap = 8.5;
    double energy_store_capacity_mj = 4.0;
    double minimum_state_of_charge = 0.10;
    double maximum_state_of_charge = 0.95;
    double initial_state_of_charge = 0.65;
    double maximum_energy_store_temperature_k = 343.15;
    double initial_energy_store_temperature_k = 313.15;
    double ice_peak_efficiency = 0.50;
    double mguk_motoring_efficiency = 0.96;
    double mguk_generating_efficiency = 0.94;
    double inverter_efficiency = 0.975;
    double battery_internal_resistance_ohm = 0.012;
    double battery_nominal_voltage_v = 800.0;
    double battery_thermal_capacity_j_k = 180000.0;
    double battery_cooling_w_k = 900.0;
    double ambient_temperature_k = 298.15;
    double turbo_time_constant_s = 0.18;
    double fuel_lower_heating_value_mj_kg = 43.0;
    void validate() const;
};

struct F1PowerUnitState {
    double state_of_charge = 0.65;
    double energy_store_temperature_k = 313.15;
    double turbo_speed_fraction = 0.0;
    double cumulative_fuel_kg = 0.0;
    double cumulative_deployed_energy_mj = 0.0;
    double cumulative_recovered_energy_mj = 0.0;
    double cumulative_electrical_loss_mj = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PowerUnitControl {
    double throttle = 0.0;
    double brake = 0.0;
    double engine_speed_rpm = 10000.0;
    double requested_tractive_power_kw = 0.0;
    double requested_recovery_power_kw = 0.0;
    bool acceleration_zone = true;
    bool overtaking_override = false;
    double vehicle_speed_m_s = 0.0;
};

struct F1PowerUnitStepResult {
    double ice_power_kw = 0.0;
    double mguk_power_kw = 0.0; // positive deployment, negative recovery
    double wheel_power_kw = 0.0;
    double fuel_flow_kg_s = 0.0;
    double battery_current_a = 0.0;
    double battery_loss_kw = 0.0;
    bool deployment_limited = false;
    bool recovery_limited = false;
    bool thermal_derating = false;
    F1PowerUnitState state;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1LapEnergySegment {
    std::string id;
    double duration_s = 1.0;
    double speed_m_s = 50.0;
    double demanded_wheel_power_kw = 0.0;
    double available_braking_power_kw = 0.0;
    bool acceleration_zone = true;
    bool overtaking_zone = false;
};

struct F1EnergyStrategyOptions {
    std::size_t state_of_charge_bins = 81;
    std::size_t deployment_levels = 8;
    double initial_state_of_charge = 0.65;
    double minimum_final_state_of_charge = 0.50;
    double fuel_weight = 1.0;
    double unmet_power_weight = 120.0;
    double terminal_state_of_charge_weight = 2000.0;
};

struct F1EnergySegmentDecision {
    std::string segment_id;
    double state_of_charge_before = 0.0;
    double state_of_charge_after = 0.0;
    double ice_power_kw = 0.0;
    double mguk_power_kw = 0.0;
    double recovered_energy_mj = 0.0;
    double deployed_energy_mj = 0.0;
    double fuel_kg = 0.0;
    double unmet_power_kw = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1EnergyStrategyResult {
    bool feasible = false;
    double objective = 0.0;
    double final_state_of_charge = 0.0;
    double total_fuel_kg = 0.0;
    double total_deployed_energy_mj = 0.0;
    double total_recovered_energy_mj = 0.0;
    std::vector<F1EnergySegmentDecision> decisions;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1PowerUnit2026Laboratory {
public:
    explicit F1PowerUnit2026Laboratory(F1PowerUnit2026Configuration configuration = {});
    [[nodiscard]] const F1PowerUnit2026Configuration& configuration() const noexcept;
    [[nodiscard]] F1PowerUnitStepResult step(double time_step_s,
                                             const F1PowerUnitControl& control,
                                             const F1PowerUnitState& previous) const;
    [[nodiscard]] F1EnergyStrategyResult optimize_lap_energy(
        const std::vector<F1LapEnergySegment>& segments,
        const F1EnergyStrategyOptions& options = {}) const;
private:
    F1PowerUnit2026Configuration configuration_;
};

// -----------------------------------------------------------------------------
// Active-aerodynamics, ground-effect, and aeroelastic simulation.
// -----------------------------------------------------------------------------

enum class F1AeroMode { Corner, Straight, Transition, FailSafe };

struct F1ActiveAeroConfiguration {
    double reference_area_m2 = 1.45;
    double air_density_kg_m3 = 1.225;
    double base_drag_coefficient = 0.72;
    double base_lift_coefficient = -3.4;
    double front_balance_fraction = 0.44;
    double straight_mode_drag_reduction = 0.28;
    double straight_mode_downforce_reduction = 0.42;
    double front_flap_max_angle_deg = 25.0;
    double rear_flap_max_angle_deg = 35.0;
    double actuator_rate_deg_s = 120.0;
    double optimum_front_ride_height_m = 0.035;
    double optimum_rear_ride_height_m = 0.060;
    double ground_effect_width_m = 0.035;
    double stall_front_ride_height_m = 0.012;
    double floor_stiffness_n_m = 2.5e6;
    double front_wing_stiffness_n_m = 1.2e6;
    double rear_wing_stiffness_n_m = 1.6e6;
    double aeroelastic_sensitivity_per_rad = 0.35;
    double porpoising_frequency_hz = 7.5;
    double porpoising_damping_ratio = 0.18;
    void validate() const;
};

struct F1AeroState {
    F1AeroMode mode = F1AeroMode::Corner;
    double front_flap_angle_deg = 0.0;
    double rear_flap_angle_deg = 0.0;
    double front_wing_deflection_m = 0.0;
    double rear_wing_deflection_m = 0.0;
    double floor_deflection_m = 0.0;
    double porpoising_displacement_m = 0.0;
    double porpoising_velocity_m_s = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1AeroInput {
    double vehicle_speed_m_s = 0.0;
    double crosswind_m_s = 0.0;
    double yaw_rad = 0.0;
    double pitch_rad = 0.0;
    double roll_rad = 0.0;
    double front_ride_height_m = 0.035;
    double rear_ride_height_m = 0.060;
    double steering_angle_rad = 0.0;
    F1AeroMode commanded_mode = F1AeroMode::Corner;
    bool actuator_fault = false;
    bool asymmetric_fault = false;
};

struct F1AeroStepResult {
    F1AeroState state;
    double downforce_n = 0.0;
    double drag_n = 0.0;
    double front_downforce_n = 0.0;
    double rear_downforce_n = 0.0;
    double lateral_force_n = 0.0;
    double center_of_pressure_fraction = 0.0;
    double effective_drag_coefficient = 0.0;
    double effective_lift_coefficient = 0.0;
    double ground_effect_factor = 0.0;
    bool floor_stalled = false;
    bool actuator_rate_limited = false;
    bool legal_state = true;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1ActiveAeroGroundEffectLaboratory {
public:
    explicit F1ActiveAeroGroundEffectLaboratory(F1ActiveAeroConfiguration configuration = {});
    [[nodiscard]] F1AeroStepResult step(double time_step_s, const F1AeroInput& input,
                                        const F1AeroState& previous) const;
private:
    F1ActiveAeroConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// F1 tyre, pressure, wear, and track-evolution physics.
// -----------------------------------------------------------------------------

enum class F1TyreCompound { Soft, Medium, Hard, Intermediate, Wet };

struct F1TyreConfiguration {
    F1TyreCompound compound = F1TyreCompound::Medium;
    double unloaded_radius_m = 0.36;
    double tread_mass_kg = 5.0;
    double carcass_thermal_capacity_j_k = 16000.0;
    double tread_thermal_capacity_j_k = 6500.0;
    double rim_thermal_capacity_j_k = 18000.0;
    double cold_pressure_pa = 135000.0;
    double reference_temperature_k = 293.15;
    double optimum_surface_temperature_k = 368.15;
    double optimum_core_temperature_k = 363.15;
    double base_friction = 1.75;
    double wear_energy_j_per_fraction = 2.2e8;
    double puncture_leak_rate_pa_s = 3500.0;
    void validate() const;
};

struct F1TyreState {
    double surface_temperature_k = 353.15;
    double core_temperature_k = 348.15;
    double carcass_temperature_k = 343.15;
    double rim_temperature_k = 333.15;
    double pressure_pa = 155000.0;
    double wear_fraction = 0.0;
    double graining_fraction = 0.0;
    double blistering_fraction = 0.0;
    double pickup_fraction = 0.0;
    double flat_spot_fraction = 0.0;
    bool punctured = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TrackCellState {
    std::string id;
    double length_m = 100.0;
    double surface_temperature_k = 313.15;
    double rubber_fraction = 0.20;
    double marbles_fraction = 0.0;
    double water_film_m = 0.0;
    double dust_fraction = 0.0;
    double base_friction = 1.0;
    double drainage_per_s = 0.02;
    double solar_absorptivity = 0.85;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TrackWeather {
    double ambient_temperature_k = 298.15;
    double solar_flux_w_m2 = 500.0;
    double wind_speed_m_s = 3.0;
    double rainfall_m_s = 0.0;
    double humidity_fraction = 0.50;
};

struct F1TyreOperatingPoint {
    double time_step_s = 0.01;
    double vertical_load_n = 4000.0;
    double longitudinal_slip = 0.0;
    double slip_angle_rad = 0.0;
    double camber_rad = 0.0;
    double vehicle_speed_m_s = 50.0;
    double wheel_angular_speed_rad_s = 140.0;
    double brake_heat_w = 0.0;
    double line_fraction = 1.0; // 1 racing line, 0 fully offline
};

struct F1TyreTrackStepResult {
    F1TyreState tyre;
    F1TrackCellState track;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double effective_friction = 0.0;
    double slip_energy_j = 0.0;
    double aquaplaning_fraction = 0.0;
    double thermal_grip_factor = 0.0;
    double compound_surface_factor = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1TyreTrackEvolutionLaboratory {
public:
    explicit F1TyreTrackEvolutionLaboratory(F1TyreConfiguration configuration = {});
    [[nodiscard]] F1TyreState blanket_condition(double blanket_temperature_k,
                                                 double duration_s,
                                                 const F1TyreState& initial) const;
    [[nodiscard]] F1TyreTrackStepResult step(const F1TyreOperatingPoint& operating_point,
                                             const F1TrackWeather& weather,
                                             const F1TyreState& previous_tyre,
                                             const F1TrackCellState& previous_track) const;
private:
    F1TyreConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Full race-weekend and pit-wall strategy simulation.
// -----------------------------------------------------------------------------

enum class F1SessionType { Practice, SprintQualifying, Sprint, Qualifying, Race };
enum class F1RaceControlState { Green, VirtualSafetyCar, SafetyCar, RedFlag };

struct F1RaceWeekendConfiguration {
    std::size_t race_laps = 57;
    double base_lap_time_s = 90.0;
    double pit_lane_loss_s = 21.0;
    double safety_car_pit_loss_factor = 0.55;
    double virtual_safety_car_pit_loss_factor = 0.72;
    double pit_stop_sigma_s = 0.35;
    bool require_two_dry_compounds = true;
    std::uint64_t random_seed = 2026;
};

struct F1LapForecast {
    std::size_t lap = 1;
    double rain_probability = 0.0;
    double expected_water_film_m = 0.0;
    double track_temperature_k = 313.15;
    double safety_car_probability = 0.0;
    double virtual_safety_car_probability = 0.0;
    double traffic_loss_s = 0.0;
};

struct F1StrategyStint {
    std::size_t start_lap = 1;
    std::size_t end_lap = 1;
    F1TyreCompound compound = F1TyreCompound::Medium;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RaceStrategyPlan {
    std::vector<F1StrategyStint> stints;
    double expected_race_time_s = 0.0;
    double expected_pit_loss_s = 0.0;
    double expected_tyre_loss_s = 0.0;
    double expected_weather_loss_s = 0.0;
    bool sporting_constraints_satisfied = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RaceSimulationStatistics {
    std::size_t simulations = 0;
    double mean_race_time_s = 0.0;
    double standard_deviation_s = 0.0;
    double percentile_10_s = 0.0;
    double percentile_50_s = 0.0;
    double percentile_90_s = 0.0;
    double probability_of_sporting_compliance = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PitWallState {
    std::size_t current_lap = 1;
    F1TyreCompound current_compound = F1TyreCompound::Medium;
    std::size_t tyre_age_laps = 0;
    double tyre_wear_fraction = 0.0;
    double gap_ahead_s = 0.0;
    double gap_behind_s = 0.0;
    double estimated_pit_loss_s = 21.0;
    F1RaceControlState race_control = F1RaceControlState::Green;
};

struct F1PitWallDecision {
    bool pit_now = false;
    F1TyreCompound recommended_compound = F1TyreCompound::Medium;
    double stay_out_cost_s = 0.0;
    double pit_now_cost_s = 0.0;
    double decision_margin_s = 0.0;
    std::string rationale;
    [[nodiscard]] doc::Value to_document() const;
};

class F1RaceWeekendStrategySimulator {
public:
    explicit F1RaceWeekendStrategySimulator(F1RaceWeekendConfiguration configuration = {});
    [[nodiscard]] F1RaceStrategyPlan optimize_race_strategy(
        const std::vector<F1LapForecast>& forecast,
        const std::vector<F1TyreCompound>& available_compounds = {
            F1TyreCompound::Soft, F1TyreCompound::Medium, F1TyreCompound::Hard,
            F1TyreCompound::Intermediate, F1TyreCompound::Wet}) const;
    [[nodiscard]] F1RaceSimulationStatistics simulate_monte_carlo(
        const F1RaceStrategyPlan& plan, const std::vector<F1LapForecast>& forecast,
        std::size_t simulations = 1000) const;
    [[nodiscard]] F1PitWallDecision decide(const F1PitWallState& state,
                                           const std::vector<F1LapForecast>& forecast) const;
private:
    F1RaceWeekendConfiguration configuration_;
};

[[nodiscard]] std::string to_string(F1TyreCompound compound);
[[nodiscard]] std::string to_string(F1AeroMode mode);

} // namespace aesim::advanced

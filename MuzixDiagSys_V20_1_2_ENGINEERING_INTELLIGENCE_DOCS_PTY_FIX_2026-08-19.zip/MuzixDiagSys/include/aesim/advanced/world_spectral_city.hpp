#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Distributed shared-world execution
// -----------------------------------------------------------------------------

enum class SharedWorldSynchronizationMode { Conservative, Optimistic };
enum class SharedWorldEventKind { Spawn, UpdatePose, UpdateVelocity, Migrate, Despawn };

struct SharedWorldEntity {
    std::string id;
    std::string type;
    std::array<double, 3> position_m{{0.0, 0.0, 0.0}};
    std::array<double, 3> velocity_m_s{{0.0, 0.0, 0.0}};
    std::map<std::string, double> attributes;
    [[nodiscard]] doc::Value to_document() const;
};

struct SharedWorldPartition {
    std::string id;
    std::array<double, 2> minimum_xy_m{{0.0, 0.0}};
    std::array<double, 2> maximum_xy_m{{0.0, 0.0}};
    double lookahead_s = 0.001;
};

struct SharedWorldEvent {
    std::uint64_t id = 0;
    double timestamp_s = 0.0;
    std::uint64_t delivery_sequence = 0;
    std::string source_partition;
    std::string target_partition;
    SharedWorldEventKind kind = SharedWorldEventKind::UpdatePose;
    SharedWorldEntity entity;
};

struct SharedWorldExecutionOptions {
    SharedWorldSynchronizationMode mode = SharedWorldSynchronizationMode::Conservative;
    double end_time_s = 1.0;
    std::size_t checkpoint_interval_events = 32;
    std::size_t fossil_collection_interval_events = 128;
    std::size_t maximum_rollback_events = 100000;
    bool enforce_partition_lookahead = true;
};

struct SharedWorldExecutionResult {
    std::map<std::string, std::vector<SharedWorldEntity>> partition_entities;
    std::map<std::string, double> logical_time_s;
    std::size_t processed_events = 0;
    std::size_t rollbacks = 0;
    std::size_t anti_messages = 0;
    std::size_t straggler_events = 0;
    std::size_t checkpoints_saved = 0;
    std::size_t fossil_collections = 0;
    std::size_t maximum_rollback_depth = 0;
    double global_virtual_time_s = 0.0;
    std::string state_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class DistributedSharedWorldExecutor {
public:
    void add_partition(SharedWorldPartition partition);
    void schedule(SharedWorldEvent event);
    [[nodiscard]] SharedWorldExecutionResult execute(
        const SharedWorldExecutionOptions& options) const;
    [[nodiscard]] SharedWorldExecutionResult execute_pdes(
        const SharedWorldExecutionOptions& options) const;
private:
    std::map<std::string, SharedWorldPartition> partitions_;
    std::vector<SharedWorldEvent> events_;
};

// -----------------------------------------------------------------------------
// Spectral synthetic-data generation
// -----------------------------------------------------------------------------

struct SpectralCurve {
    std::vector<double> wavelength_nm;
    std::vector<double> value;
    [[nodiscard]] double sample(double wavelength) const;
    void validate(const std::string& name) const;
};

struct SpectralMaterial {
    std::string name;
    SpectralCurve reflectance;
    double roughness = 0.5;
    std::uint32_t semantic_id = 0;
};

struct SpectralBoxObject {
    std::string id;
    std::string material;
    std::array<double, 3> center_m{{0.0, 0.0, 0.0}};
    std::array<double, 3> size_m{{1.0, 1.0, 1.0}};
    std::uint32_t instance_id = 0;
};

struct SpectralCamera {
    std::size_t width = 64;
    std::size_t height = 48;
    double horizontal_fov_deg = 70.0;
    std::array<double, 3> position_m{{0.0, 0.0, 1.5}};
    double yaw_rad = 0.0;
    double pitch_rad = 0.0;
    SpectralCurve red_response;
    SpectralCurve green_response;
    SpectralCurve blue_response;
    double read_noise_electrons = 1.0;
    double quantum_efficiency = 0.6;
    double exposure_s = 0.005;
};

struct SpectralIlluminant {
    SpectralCurve irradiance_w_m2_nm;
    std::array<double, 3> direction{{-0.5, 0.0, -0.866025403784}};
    double atmospheric_extinction_per_m = 0.0001;
};

struct SpectralImageResult {
    std::size_t width = 0;
    std::size_t height = 0;
    std::vector<double> wavelengths_nm;
    std::vector<float> spectral_radiance;
    std::vector<std::uint8_t> rgb8;
    std::vector<float> depth_m;
    std::vector<std::uint32_t> semantic;
    std::vector<std::uint32_t> instance;
    std::string frame_sha256;
    [[nodiscard]] doc::Value to_document(bool include_pixels = false) const;
};

class SpectralSyntheticDataGenerator {
public:
    void add_material(SpectralMaterial material);
    void add_box(SpectralBoxObject object);
    void set_camera(SpectralCamera camera);
    void set_illuminant(SpectralIlluminant illuminant);
    void set_wavelengths(std::vector<double> wavelengths_nm);
    [[nodiscard]] SpectralImageResult render(std::uint64_t seed) const;
    void write_dataset(const std::string& directory,
                       std::size_t frame_count,
                       std::uint64_t seed) const;
private:
    std::map<std::string, SpectralMaterial> materials_;
    std::vector<SpectralBoxObject> objects_;
    SpectralCamera camera_;
    SpectralIlluminant illuminant_;
    std::vector<double> wavelengths_nm_;
};

// -----------------------------------------------------------------------------
// City-scale infrastructure simulation
// -----------------------------------------------------------------------------

struct CityNode {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
};

struct CityRoadLink {
    std::string id;
    std::string from_node;
    std::string to_node;
    double length_m = 0.0;
    double free_speed_m_s = 13.89;
    double capacity_vehicles_per_hour = 1800.0;
    unsigned lanes = 1;
    double energy_wh_per_vehicle_km = 180.0;
    std::string signal_id;
};

struct CityTrafficSignal {
    std::string id;
    double cycle_s = 60.0;
    double green_start_s = 0.0;
    double green_duration_s = 30.0;
    double offset_s = 0.0;
};

struct CityChargingStation {
    std::string id;
    std::string node_id;
    unsigned chargers = 4;
    double power_kw_per_charger = 150.0;
    double grid_limit_kw = 500.0;
};

struct CityTrip {
    std::string id;
    std::string origin_node;
    std::string destination_node;
    double departure_time_s = 0.0;
    double initial_energy_kwh = 60.0;
    double minimum_reserve_kwh = 5.0;
};

struct CitySimulationOptions {
    double duration_s = 3600.0;
    double time_step_s = 1.0;
    double bpr_alpha = 0.15;
    double bpr_beta = 4.0;
};

struct CityTripResult {
    std::string id;
    bool completed = false;
    bool stranded = false;
    double arrival_time_s = 0.0;
    double travel_time_s = 0.0;
    double energy_used_kwh = 0.0;
    std::vector<std::string> route;
    [[nodiscard]] doc::Value to_document() const;
};

struct CitySimulationResult {
    std::vector<CityTripResult> trips;
    std::map<std::string, double> maximum_link_queue;
    std::map<std::string, double> average_link_speed_m_s;
    std::map<std::string, double> charging_energy_kwh;
    std::map<std::string, double> peak_grid_power_kw;
    double completed_fraction = 0.0;
    double mean_travel_time_s = 0.0;
    double total_energy_kwh = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CityScaleInfrastructureSimulator {
public:
    void add_node(CityNode node);
    void add_road(CityRoadLink road);
    void add_signal(CityTrafficSignal signal);
    void add_charging_station(CityChargingStation station);
    void add_trip(CityTrip trip);
    [[nodiscard]] CitySimulationResult run(const CitySimulationOptions& options) const;
private:
    std::map<std::string, CityNode> nodes_;
    std::map<std::string, CityRoadLink> roads_;
    std::map<std::string, CityTrafficSignal> signals_;
    std::map<std::string, CityChargingStation> charging_stations_;
    std::vector<CityTrip> trips_;
};

} // namespace aesim::advanced

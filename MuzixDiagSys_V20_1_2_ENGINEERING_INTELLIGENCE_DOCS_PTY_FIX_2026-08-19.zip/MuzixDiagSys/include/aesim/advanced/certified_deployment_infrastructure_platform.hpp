#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {
using DenseVector=std::vector<double>; using DenseMatrix=std::vector<DenseVector>;

struct SurrogateSample{DenseVector input; DenseVector output;};
struct CertifiedSurrogateModel{DenseMatrix weights; DenseVector bias,input_min,input_max,error_bound; double ridge=0; std::string digest;};
class CertifiedNeuralOperatorCompiler{public: CertifiedSurrogateModel compile(const std::vector<SurrogateSample>&,double ridge=1e-8) const; DenseVector infer(const CertifiedSurrogateModel&,const DenseVector&,bool require_domain=true) const; bool certify(const CertifiedSurrogateModel&,const std::vector<SurrogateSample>&,double tolerance) const; std::string export_cxx(const CertifiedSurrogateModel&,const std::string&) const;};

struct DifferentiableComponent{std::string id; DenseMatrix a,b; DenseVector bias,state;};
struct DifferentiableTrajectory{std::vector<DenseVector> states; DenseVector final_output; DenseMatrix doutput_dparameters; double objective=0; DenseVector gradient;};
class DifferentiableCoSimulationRuntime{public: DifferentiableTrajectory simulate(const std::vector<DifferentiableComponent>&,const std::vector<DenseVector>& inputs,const DenseVector& target) const;};

struct AiAssuranceSample{DenseVector features; int label=0;};
struct AiAssuranceResult{double accuracy=0,brier_score=0,expected_calibration_error=0,ood_auroc=0,coverage=0,risk=0; std::vector<bool> abstain; bool qualified=false; std::string digest;};
class AutomotiveAiAssuranceLaboratory{public: AiAssuranceResult evaluate(const std::vector<AiAssuranceSample>& reference,const std::vector<AiAssuranceSample>& operational,double ood_quantile,double abstention_quantile) const;};

struct SwitchingDevice{double r_on_ohm=.01,q_rr_c=1e-6,c_oss_f=1e-9,thermal_r_k_w=.5,thermal_c_j_k=100,max_junction_k=423.15;};
struct EmtScenario{double dc_voltage_v=800,load_current_a=100,switching_hz=10000,duty=.5,dead_time_s=1e-6,stray_l_h=100e-9,duration_s=.1,ambient_k=298.15; std::size_t steps=1000;};
struct EmtResult{double conduction_loss_w=0,switching_loss_w=0,peak_overshoot_v=0,ripple_a=0,junction_k=0,emi_index=0; bool qualified=false;};
class ElectromagneticTransientPowerElectronicsLaboratory{public: EmtResult simulate(const SwitchingDevice&,const EmtScenario&) const;};

struct FluidNode{std::string id; double volume_m3=.01,pressure_pa=101325,temperature_k=298.15,liquid_fraction=1,mass_kg=1;};
struct FluidConnection{std::size_t from=0,to=0; double conductance_kg_s_pa=1e-8,heat_transfer_w_k=10,elevation_m=0;};
struct SloshInput{double ax_m_s2=0,ay_m_s2=0,roll_rad=0,pitch_rad=0;};
struct ThermalFluidResult{std::vector<FluidNode> nodes; double total_mass_kg=0,total_energy_j=0,max_pressure_pa=0,slosh_load_n=0,vapor_fraction=0; bool conserved=false;};
class MultiphaseThermalFluidSloshPlatform{public: ThermalFluidResult simulate(std::vector<FluidNode>,const std::vector<FluidConnection>&,const SloshInput&,double dt_s,std::size_t steps) const;};

enum class SocFault{None,CpuTransient,SramBitFlip,BusStuck,DmaCorruption,ClockDrift};
struct SocArchitecture{std::size_t cores=2; bool lockstep=true,ecc=true,watchdog=true; double diagnostic_coverage=.95,clock_hz=1e9,watchdog_s=.01;};
struct SocSafetyResult{double spfm=0,lfm=0,detection_latency_s=0,safe_state_latency_s=0,residual_failure_rate_fit=0; bool detected=false,safe_state=false,qualified=false;};
class FunctionalSafetySocLaboratory{public: SocSafetyResult inject(const SocArchitecture&,SocFault,double fault_rate_fit,double workload_cycles) const;};

struct AccidentObservation{double time_s=0,x_m=0,y_m=0,speed_m_s=0,heading_rad=0,sigma_position_m=1,sigma_speed_m_s=1;};
struct AccidentHypothesis{double friction=.8,impact_restitution=.1,vehicle_mass_kg=1500;};
struct AccidentReconstruction{DenseVector state_mean; DenseMatrix covariance; double impact_speed_m_s=0,energy_j=0,log_likelihood=0; std::vector<double> normalized_hypothesis_weights; std::string digest;};
class ProbabilisticAccidentReconstructionLaboratory{public: AccidentReconstruction reconstruct(const std::vector<AccidentObservation>&,const std::vector<AccidentHypothesis>&) const;};

struct SignedEvidence{std::string payload_sha256,public_key_pem,signature_base64,algorithm="Ed25519"; std::int64_t timestamp_unix=0;};
class SignedProofAttestationService{public: SignedEvidence sign(const std::string& payload) const; bool verify(const std::string& payload,const SignedEvidence&) const;};

struct FleetMetric{std::string vehicle_id; bool candidate=false; double safety_events=0,exposure_hours=1,kpi=0;};
struct CanaryDecision{double incumbent_rate=0,candidate_rate=0,rate_ratio=0,kpi_lift=0,posterior_harm_probability=0; std::string action; bool guardrails_passed=false;};
class FleetShadowCanaryDeploymentEngine{public: CanaryDecision evaluate(const std::vector<FleetMetric>&,double maximum_rate_ratio,double minimum_exposure_h) const;};

struct GridBus{std::string id; double base_voltage_v=400,p_kw=0,q_kvar=0,voltage_pu=1;};
struct GridBranch{std::size_t from=0,to=0; double r_ohm=.01,x_ohm=.01,ampacity_a=200;};
struct ChargerDemand{std::size_t bus=0; double power_kw=0,power_factor=.98;};
struct GridProtectionResult{std::vector<double> bus_voltage_pu,branch_current_a; double losses_kw=0,minimum_voltage_pu=1,maximum_loading_fraction=0,transformer_hotspot_k=0; bool voltage_qualified=false,protection_qualified=false;};
class GridChargingInfrastructureProtectionTwin{public: GridProtectionResult solve(const std::vector<GridBus>&,const std::vector<GridBranch>&,const std::vector<ChargerDemand>&,double ambient_k) const;};
}

#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::nascarassure {

class NascarRegulationDigitalThread {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarDynamicCompliance {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarProspectiveOemProgram {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarTimingObservationFusion {
public:
    [[nodiscard]] doc::Value fuse(const doc::Value& request,
                                  const std::string& working_directory = {}) const;
};

class NascarOfficiatingPolicyLab {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarContactDamageRaceability {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarCrashSaferFiniteElementTwin {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarFireRescueHazards {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarDebrisRecovery {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarCompositeManufacturing {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarFleetReliability {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarTestDesignCalibration {
public:
    [[nodiscard]] doc::Value optimize(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class NascarEngineeringAssurancePlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::nascarassure

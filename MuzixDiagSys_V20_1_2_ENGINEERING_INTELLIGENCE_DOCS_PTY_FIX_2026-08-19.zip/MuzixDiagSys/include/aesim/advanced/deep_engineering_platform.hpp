#pragma once

#include "aesim/advanced/must_have_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Unified sparse nonlinear solver and adaptive-mesh runtime.
// -----------------------------------------------------------------------------

struct SparseTriplet {
    std::size_t row = 0;
    std::size_t column = 0;
    double value = 0.0;
};

class SparseMatrixCsr {
public:
    SparseMatrixCsr() = default;
    SparseMatrixCsr(std::size_t rows, std::size_t columns,
                    std::vector<std::size_t> row_offsets,
                    std::vector<std::size_t> column_indices,
                    std::vector<double> values);
    [[nodiscard]] static SparseMatrixCsr from_triplets(
        std::size_t rows, std::size_t columns,
        const std::vector<SparseTriplet>& triplets,
        double drop_tolerance = 0.0);
    [[nodiscard]] std::size_t rows() const noexcept { return rows_; }
    [[nodiscard]] std::size_t columns() const noexcept { return columns_; }
    [[nodiscard]] std::size_t nonzeros() const noexcept { return values_.size(); }
    [[nodiscard]] const std::vector<std::size_t>& row_offsets() const noexcept { return row_offsets_; }
    [[nodiscard]] const std::vector<std::size_t>& column_indices() const noexcept { return column_indices_; }
    [[nodiscard]] const std::vector<double>& values() const noexcept { return values_; }
    [[nodiscard]] std::vector<double> multiply(const std::vector<double>& x) const;
    [[nodiscard]] std::vector<double> diagonal() const;
    [[nodiscard]] double at(std::size_t row, std::size_t column) const;
    [[nodiscard]] SparseMatrixCsr add_scaled_identity(double scale) const;
    [[nodiscard]] doc::Value to_document(bool include_coefficients = false) const;
private:
    std::size_t rows_ = 0;
    std::size_t columns_ = 0;
    std::vector<std::size_t> row_offsets_;
    std::vector<std::size_t> column_indices_;
    std::vector<double> values_;
};

enum class SparseIterativeMethod { ConjugateGradient, Gmres, BiCgStab };
enum class SparsePreconditioner { None, Jacobi, Ilu0, BlockJacobi, AdditiveSchwarz, AlgebraicMultigrid };
enum class MixedPrecisionMode { Disabled, Float32IterativeRefinement };

struct SparseSolveOptions {
    SparseIterativeMethod method = SparseIterativeMethod::Gmres;
    SparsePreconditioner preconditioner = SparsePreconditioner::Ilu0;
    std::size_t maximum_iterations = 1000;
    std::size_t gmres_restart = 40;
    double relative_tolerance = 1.0e-9;
    double absolute_tolerance = 1.0e-12;
    bool record_history = true;
    // Block/domain controls.  A zero block size selects a deterministic size
    // from the system dimension.
    std::size_t block_size = 0;
    std::size_t schwarz_overlap = 1;
    // Self-contained aggregation AMG controls.
    std::size_t amg_max_levels = 8;
    std::size_t amg_min_coarse_size = 16;
    std::size_t amg_pre_smoothing = 2;
    std::size_t amg_post_smoothing = 2;
    double amg_jacobi_omega = 0.7;
    // Error-controlled lower-precision correction solve followed by binary64
    // residual evaluation and iterative refinement.
    MixedPrecisionMode mixed_precision = MixedPrecisionMode::Disabled;
    std::size_t mixed_precision_refinement_steps = 4;
    double mixed_precision_acceptance_factor = 2.0;
};

struct SparseReuseStatistics {
    std::uint64_t symbolic_builds = 0;
    std::uint64_t symbolic_reuses = 0;
    std::uint64_t numeric_builds = 0;
    std::uint64_t numeric_reuses = 0;
};

class SparseSolveWorkspace {
public:
    struct Impl;
    SparseSolveWorkspace();
    ~SparseSolveWorkspace();
    SparseSolveWorkspace(SparseSolveWorkspace&&) noexcept;
    SparseSolveWorkspace& operator=(SparseSolveWorkspace&&) noexcept;
    SparseSolveWorkspace(const SparseSolveWorkspace&) = delete;
    SparseSolveWorkspace& operator=(const SparseSolveWorkspace&) = delete;
    void clear();
    [[nodiscard]] SparseReuseStatistics statistics() const noexcept;
private:
    std::unique_ptr<Impl> impl_;
    friend class UnifiedSparseNonlinearRuntime;
};

struct SparseSolveResult {
    std::vector<double> solution;
    bool converged = false;
    std::size_t iterations = 0;
    double initial_residual_norm = 0.0;
    double residual_norm = 0.0;
    double relative_residual = 0.0;
    std::vector<double> residual_history;
    SparseReuseStatistics reuse_statistics;
    bool used_mixed_precision = false;
    std::size_t mixed_precision_refinements = 0;
    bool promoted_to_binary64 = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_solution = false) const;
};

enum class NonlinearLinearization { ExplicitJacobian, JacobianFreeNewtonKrylov };

struct NonlinearSolveOptions {
    std::size_t maximum_iterations = 50;
    double residual_tolerance = 1.0e-10;
    double step_tolerance = 1.0e-11;
    double finite_difference_step = 1.0e-7;
    double minimum_line_search = 1.0e-6;
    SparseSolveOptions linear_options;
    NonlinearLinearization linearization = NonlinearLinearization::ExplicitJacobian;
    double jfnk_relative_step = 1.0e-7;
    std::size_t jfnk_preconditioner_refresh = 3;
    bool reuse_jacobian = true;
    std::size_t maximum_jacobian_age = 2;
    // Reuse is allowed while the residual reduction remains at least this
    // fraction; poor progress forces a refresh.
    double jacobian_reuse_residual_ratio = 0.8;
};

struct NonlinearSolveResult {
    std::vector<double> solution;
    bool converged = false;
    bool used_jfnk = false;
    std::size_t nonlinear_iterations = 0;
    std::size_t linear_iterations = 0;
    std::size_t residual_evaluations = 0;
    std::size_t jacobian_builds = 0;
    std::size_t jacobian_reuses = 0;
    std::size_t jvp_evaluations = 0;
    double residual_norm = 0.0;
    std::vector<double> residual_history;
    SparseReuseStatistics reuse_statistics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_solution = false) const;
};

class NonlinearSolveWorkspace {
public:
    struct Impl;
    NonlinearSolveWorkspace();
    ~NonlinearSolveWorkspace();
    NonlinearSolveWorkspace(NonlinearSolveWorkspace&&) noexcept;
    NonlinearSolveWorkspace& operator=(NonlinearSolveWorkspace&&) noexcept;
    NonlinearSolveWorkspace(const NonlinearSolveWorkspace&) = delete;
    NonlinearSolveWorkspace& operator=(const NonlinearSolveWorkspace&) = delete;
    void clear();
private:
    std::unique_ptr<Impl> impl_;
    friend class UnifiedSparseNonlinearRuntime;
};

struct ImplicitIntegrationOptions {
    enum class Method { BackwardEuler, Bdf2 };
    Method method = Method::Bdf2;
    double time_step_s = 0.01;
    std::size_t steps = 100;
    NonlinearSolveOptions nonlinear_options;
};

struct ImplicitIntegrationResult {
    std::vector<double> time_s;
    std::vector<std::vector<double>> states;
    bool converged = false;
    std::size_t failed_step = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_states = false) const;
};

struct AdaptiveMeshOptions {
    double mark_fraction = 0.3;
    std::size_t maximum_cycles = 1;
    std::size_t maximum_tetrahedra = 1000000;
};

struct AdaptiveMeshResult {
    UnstructuredVolumeMesh mesh;
    std::vector<std::size_t> parent_tetrahedron;
    std::vector<double> transferred_nodal_field;
    std::size_t refined_tetrahedra = 0;
    double original_error = 0.0;
    double estimated_error = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_mesh = false) const;
};

class UnifiedSparseNonlinearRuntime {
public:
    using ResidualFunction = std::function<std::vector<double>(const std::vector<double>&)>;
    using JacobianFunction = std::function<SparseMatrixCsr(const std::vector<double>&)>;
    using OdeFunction = std::function<std::vector<double>(double, const std::vector<double>&)>;
    using OdeJacobianFunction = std::function<SparseMatrixCsr(double, const std::vector<double>&)>;

    [[nodiscard]] SparseSolveResult solve_linear(
        const SparseMatrixCsr& matrix, const std::vector<double>& rhs,
        const SparseSolveOptions& options = {},
        const std::vector<double>& initial_guess = {},
        SparseSolveWorkspace* workspace = nullptr) const;
    [[nodiscard]] NonlinearSolveResult solve_nonlinear(
        const ResidualFunction& residual, const std::vector<double>& initial_guess,
        const NonlinearSolveOptions& options = {},
        const JacobianFunction& jacobian = {},
        NonlinearSolveWorkspace* workspace = nullptr) const;
    [[nodiscard]] ImplicitIntegrationResult integrate_implicit(
        const OdeFunction& derivative, double initial_time_s,
        const std::vector<double>& initial_state,
        const ImplicitIntegrationOptions& options = {},
        const OdeJacobianFunction& jacobian = {}) const;
    [[nodiscard]] AdaptiveMeshResult refine_tetrahedral_mesh(
        const UnstructuredVolumeMesh& mesh,
        const std::vector<double>& element_error,
        const std::vector<double>& nodal_field = {},
        const AdaptiveMeshOptions& options = {}) const;
};

// -----------------------------------------------------------------------------
// Industrial B-rep/NURBS CAD and production meshing.
// -----------------------------------------------------------------------------

struct NurbsCurve3d {
    unsigned degree = 1;
    std::vector<double> knots;
    std::vector<Vector3> control_points;
    std::vector<double> weights;
    [[nodiscard]] Vector3 evaluate(double parameter) const;
    [[nodiscard]] Vector3 derivative(double parameter) const;
    void validate() const;
};

struct NurbsSurface3d {
    unsigned degree_u = 1;
    unsigned degree_v = 1;
    std::size_t control_count_u = 0;
    std::size_t control_count_v = 0;
    std::vector<double> knots_u;
    std::vector<double> knots_v;
    std::vector<Vector3> control_points; // row-major v * control_count_u + u
    std::vector<double> weights;
    [[nodiscard]] Vector3 evaluate(double u, double v) const;
    [[nodiscard]] Vector3 normal(double u, double v) const;
    void validate() const;
};

struct BRepVertex {
    Vector3 point_m{};
    double tolerance_m = 1.0e-8;
};

struct BRepEdge {
    std::size_t first_vertex = 0;
    std::size_t second_vertex = 0;
    std::optional<NurbsCurve3d> curve;
};

struct OrientedBRepEdge {
    std::size_t edge = 0;
    bool reversed = false;
};

struct BRepLoop {
    std::vector<OrientedBRepEdge> edges;
};

struct BRepFace {
    NurbsSurface3d surface;
    BRepLoop outer;
    std::vector<BRepLoop> inner;
    double u_min = 0.0;
    double u_max = 1.0;
    double v_min = 0.0;
    double v_max = 1.0;
    bool reversed = false;
    std::string name;
    std::string material_id = "default";
};

struct IndustrialBRepSolid {
    std::vector<BRepVertex> vertices;
    std::vector<BRepEdge> edges;
    std::vector<BRepFace> faces;
    [[nodiscard]] doc::Value to_document(bool include_geometry = false) const;
};

struct BRepValidationReport {
    bool valid = false;
    bool closed = false;
    bool consistently_oriented = false;
    std::size_t nonmanifold_edges = 0;
    std::size_t open_edges = 0;
    std::size_t degenerate_edges = 0;
    std::size_t degenerate_faces = 0;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

struct ProductionSurfaceMesh {
    std::vector<Vector3> nodes;
    std::vector<SurfaceTriangle3d> triangles;
    std::vector<std::size_t> source_face;
    std::vector<Vector3> normals;
    double minimum_quality = 0.0;
    [[nodiscard]] doc::Value to_document(bool include_mesh = false) const;
};

class IndustrialBRepCadKernel {
public:
    [[nodiscard]] IndustrialBRepSolid make_box(const Vector3& minimum_m,
                                               const Vector3& maximum_m,
                                               const std::string& material_id = "default") const;
    [[nodiscard]] BRepValidationReport validate(const IndustrialBRepSolid& solid,
                                                double tolerance_m = 1.0e-8) const;
    [[nodiscard]] IndustrialBRepSolid heal(const IndustrialBRepSolid& solid,
                                           double tolerance_m = 1.0e-7) const;
    [[nodiscard]] ProductionSurfaceMesh tessellate(const IndustrialBRepSolid& solid,
                                                   std::size_t subdivisions_u = 8,
                                                   std::size_t subdivisions_v = 8) const;
    [[nodiscard]] UnstructuredVolumeMesh tetrahedralize(
        const IndustrialBRepSolid& solid, double target_edge_m,
        const std::string& material_id = "default") const;
    [[nodiscard]] std::string export_step_ap242_polyhedral(
        const IndustrialBRepSolid& solid) const;
    [[nodiscard]] IndustrialBRepSolid import_step_polyhedral(
        const std::string& step_text, const std::string& material_id = "default") const;
};

// -----------------------------------------------------------------------------
// Full unstructured CFD, CHT, and partitioned FSI.
// -----------------------------------------------------------------------------

enum class CfdRegionKind { Fluid, Solid };
enum class CfdBoundaryKind { VelocityInlet, PressureOutlet, NoSlipWall, SlipWall,
                             FixedTemperature, HeatFlux };

struct CfdRegionMaterial {
    CfdRegionKind kind = CfdRegionKind::Fluid;
    double density_kg_m3 = 1.225;
    double dynamic_viscosity_pa_s = 1.8e-5;
    double thermal_conductivity_w_m_k = 0.026;
    double heat_capacity_j_kg_k = 1005.0;
    double youngs_modulus_pa = 0.0;
    double poisson_ratio = 0.3;
    double thermal_expansion_per_k = 0.0;
    double yield_strength_pa = 1.0e30;
};

struct CfdBoundaryPatch {
    std::string name;
    CfdBoundaryKind kind = CfdBoundaryKind::NoSlipWall;
    std::vector<std::size_t> boundary_triangles;
    Vector3 velocity_m_s{};
    double pressure_pa = 0.0;
    double temperature_k = 300.0;
    double heat_flux_w_m2 = 0.0;
};

struct UnstructuredFlowInitialState {
    std::vector<Vector3> cell_velocity_m_s;
    std::vector<double> cell_pressure_pa;
    std::vector<double> cell_temperature_k;
};

struct UnstructuredCfdOptions {
    double time_step_s = 1.0e-3;
    std::size_t steps = 100;
    std::size_t pressure_iterations = 200;
    std::size_t fsi_coupling_iterations = 3;
    double pressure_tolerance = 1.0e-8;
    double momentum_relaxation = 0.7;
    double pressure_relaxation = 0.3;
    double thermal_relaxation = 0.8;
    double fsi_relaxation = 0.5;
    Vector3 body_acceleration_m_s2{};
};

struct UnstructuredCfdChtFsiResult {
    std::vector<Vector3> cell_velocity_m_s;
    std::vector<double> cell_pressure_pa;
    std::vector<double> cell_temperature_k;
    std::vector<Vector3> nodal_displacement_m;
    double maximum_velocity_m_s = 0.0;
    double minimum_pressure_pa = 0.0;
    double maximum_pressure_pa = 0.0;
    double minimum_temperature_k = 0.0;
    double maximum_temperature_k = 0.0;
    double mass_imbalance_kg_s = 0.0;
    double energy_imbalance_w = 0.0;
    double maximum_interface_displacement_m = 0.0;
    bool converged = false;
    std::size_t completed_steps = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class FullUnstructuredCfdChtFsiSolver {
public:
    [[nodiscard]] UnstructuredCfdChtFsiResult solve(
        const UnstructuredVolumeMesh& mesh,
        const std::map<std::string, CfdRegionMaterial>& materials,
        const std::vector<CfdBoundaryPatch>& boundaries,
        const UnstructuredCfdOptions& options = {},
        const UnstructuredFlowInitialState& initial = {},
        const StructuralBoundaryCondition& structural_boundary = {}) const;
};

// -----------------------------------------------------------------------------
// Full-system heterogeneous SoC and virtual ECU 3.0.
// -----------------------------------------------------------------------------

enum class FullSystemCoreKind { Rv32Instruction, SafetyLockstep, FullSystemRealTimeTask, Dsp, Gpu, Npu };
enum class CriticalityLevel { QualityManaged, AutomotiveSafetyB, AutomotiveSafetyD };
enum class PeripheralKind { CanFd, Lin, FlexRay, EthernetTsn, Spi, I2c, Adc, Pwm, Watchdog, Timer };

struct FullSystemCoreConfiguration {
    std::string id;
    FullSystemCoreKind kind = FullSystemCoreKind::Rv32Instruction;
    double clock_hz = 400.0e6;
    std::size_t l1_instruction_bytes = 32 * 1024;
    std::size_t l1_data_bytes = 32 * 1024;
    std::string partition;
    std::string lockstep_peer;
    double thermal_resistance_k_w = 8.0;
    double thermal_capacitance_j_k = 20.0;
    double leakage_power_w = 0.15;
    double dynamic_power_w = 1.5;
};

struct HypervisorPartition {
    std::string id;
    CriticalityLevel criticality = CriticalityLevel::QualityManaged;
    std::uint64_t budget_cycles = 0;
    std::uint64_t period_cycles = 0;
    std::vector<std::string> allowed_peripherals;
};

struct FullSystemRealTimeTask {
    std::string id;
    std::string partition;
    std::string preferred_core;
    std::uint64_t period_cycles = 100000;
    std::uint64_t deadline_cycles = 100000;
    std::uint64_t execution_cycles = 1000;
    unsigned priority = 1;
    CriticalityLevel criticality = CriticalityLevel::QualityManaged;
};

struct FullSystemPeripheral {
    std::string id;
    PeripheralKind kind = PeripheralKind::Timer;
    std::uint64_t service_latency_cycles = 100;
    std::size_t queue_capacity = 64;
};

struct FirmwareMeasurement {
    std::string core_id;
    std::string sha256;
    bool signature_valid = false;
    bool rollback_allowed = false;
};

struct FullSystemFault {
    enum class Kind { CorrectableEcc, UncorrectableEcc, WatchdogTimeout,
                      LockstepDivergence, PeripheralDrop, ThermalOverlimit };
    Kind kind = Kind::CorrectableEcc;
    std::string target;
    std::uint64_t activation_cycle = 0;
};

struct TaskExecutionRecord {
    std::string task_id;
    std::string core_id;
    std::uint64_t release_cycle = 0;
    std::uint64_t start_cycle = 0;
    std::uint64_t finish_cycle = 0;
    std::uint64_t response_cycles = 0;
    bool deadline_missed = false;
};

struct FullSystemSocReport {
    std::uint64_t elapsed_cycles = 0;
    std::vector<TaskExecutionRecord> task_records;
    std::map<std::string, double> core_utilization;
    std::map<std::string, double> core_temperature_k;
    std::map<std::string, std::uint64_t> l1_hits;
    std::map<std::string, std::uint64_t> l1_misses;
    std::uint64_t l2_hits = 0;
    std::uint64_t l2_misses = 0;
    std::uint64_t ddr_transactions = 0;
    std::uint64_t coherence_transactions = 0;
    std::uint64_t correctable_ecc = 0;
    std::uint64_t uncorrectable_ecc = 0;
    std::uint64_t dropped_peripheral_messages = 0;
    std::size_t deadline_misses = 0;
    bool secure_boot_valid = false;
    bool lockstep_mismatch = false;
    bool safe_state_entered = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class FullSystemVirtualEcu3 {
public:
    FullSystemVirtualEcu3(std::size_t shared_memory_bytes = 4 * 1024 * 1024,
                          std::uint32_t shared_base = 0x00100000U,
                          double reference_clock_hz = 400.0e6);
    ~FullSystemVirtualEcu3();
    FullSystemVirtualEcu3(FullSystemVirtualEcu3&&) noexcept;
    FullSystemVirtualEcu3& operator=(FullSystemVirtualEcu3&&) noexcept;
    FullSystemVirtualEcu3(const FullSystemVirtualEcu3&) = delete;
    FullSystemVirtualEcu3& operator=(const FullSystemVirtualEcu3&) = delete;
    void add_core(FullSystemCoreConfiguration configuration);
    void add_partition(HypervisorPartition partition);
    void add_task(FullSystemRealTimeTask task);
    void add_peripheral(FullSystemPeripheral peripheral);
    void load_rv32_words(const std::string& core_id, std::uint32_t address,
                         const std::vector<std::uint32_t>& words);
    void install_firmware_measurement(FirmwareMeasurement measurement);
    void set_trusted_firmware_hash(const std::string& core_id, std::string sha256);
    void inject_fault(FullSystemFault fault);
    void enqueue_peripheral_message(const std::string& peripheral_id,
                                    std::vector<std::uint8_t> payload);
    [[nodiscard]] std::optional<std::vector<std::uint8_t>>
    dequeue_peripheral_message(const std::string& peripheral_id);
    void run(std::uint64_t reference_cycles);
    [[nodiscard]] FullSystemSocReport report() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// -----------------------------------------------------------------------------
// Solver credibility, UQ, and digital-twin assimilation.
// -----------------------------------------------------------------------------

struct MeshConvergenceStudy {
    std::vector<double> characteristic_spacing;
    std::vector<double> quantity;
    double observed_order = 0.0;
    double extrapolated_value = 0.0;
    double fine_grid_gci_percent = 0.0;
    bool asymptotic_range = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct VerificationBenchmarkResult {
    double l1_error = 0.0;
    double l2_error = 0.0;
    double linf_error = 0.0;
    double conservation_residual = 0.0;
    bool passed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct UncertaintyParameter {
    std::string name;
    double minimum = 0.0;
    double maximum = 1.0;
};

struct UncertaintyPropagationResult {
    std::vector<std::string> parameter_names;
    std::vector<double> mean;
    std::vector<double> standard_deviation;
    std::vector<double> percentile_05;
    std::vector<double> percentile_50;
    std::vector<double> percentile_95;
    std::vector<std::vector<double>> first_order_sobol;
    std::size_t samples = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct BayesianCalibrationResult {
    std::vector<double> posterior_mean;
    std::vector<double> posterior_standard_deviation;
    std::vector<double> map_parameters;
    double map_log_posterior = 0.0;
    double acceptance_rate = 0.0;
    std::vector<std::vector<double>> retained_samples;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_samples = false) const;
};

struct EnsembleAssimilationOptions {
    std::size_t ensemble_size = 64;
    double inflation = 1.02;
    std::uint64_t seed = 0x5a17U;
};

struct EnsembleAssimilationResult {
    std::vector<double> posterior_mean;
    std::vector<double> posterior_standard_deviation;
    std::vector<std::vector<double>> posterior_ensemble;
    double innovation_norm = 0.0;
    double normalized_innovation_squared = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_ensemble = false) const;
};

struct SolverCredibilityRecord {
    MeshConvergenceStudy mesh_convergence;
    VerificationBenchmarkResult verification;
    double numerical_uncertainty = 0.0;
    double input_uncertainty = 0.0;
    double validation_error = 0.0;
    double credibility_score = 0.0;
    std::vector<std::string> limitations;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct ModelValidationDomain {
    std::map<std::string, std::pair<double, double>> validated_ranges;
};

struct ModelValidationAssessment {
    double rmse = 0.0;
    double nrmse = 0.0;
    double r_squared = 0.0;
    double validation_coverage = 0.0;
    double maximum_extrapolation_distance = 0.0;
    double mean_extrapolation_distance = 0.0;
    double uncertainty_ratio = 0.0;
    double credibility_score = 0.0;
    bool inside_validated_domain = false;
    std::vector<std::string> warnings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SolverCredibilityAndDigitalTwinLaboratory {
public:
    using ModelFunction = std::function<std::vector<double>(const std::vector<double>&)>;
    using LogPosteriorFunction = std::function<double(const std::vector<double>&)>;
    using StateTransitionFunction = std::function<std::vector<double>(const std::vector<double>&)>;
    using ObservationFunction = std::function<std::vector<double>(const std::vector<double>&)>;

    [[nodiscard]] MeshConvergenceStudy assess_mesh_convergence(
        const std::vector<double>& characteristic_spacing,
        const std::vector<double>& quantity,
        double safety_factor = 1.25) const;
    [[nodiscard]] VerificationBenchmarkResult verify_against_reference(
        const std::vector<double>& numerical,
        const std::vector<double>& reference,
        const std::vector<double>& weights = {},
        double tolerance = 1.0e-6) const;
    [[nodiscard]] UncertaintyPropagationResult propagate_uncertainty(
        const std::vector<UncertaintyParameter>& parameters,
        const ModelFunction& model,
        std::size_t samples,
        std::uint64_t seed = 0x12345678U) const;
    [[nodiscard]] BayesianCalibrationResult calibrate_bayesian(
        const LogPosteriorFunction& log_posterior,
        const std::vector<double>& initial_parameters,
        const std::vector<double>& proposal_standard_deviation,
        std::size_t iterations,
        std::size_t burn_in,
        std::uint64_t seed = 0x31415926U) const;
    [[nodiscard]] EnsembleAssimilationResult assimilate_ensemble_kalman(
        const std::vector<std::vector<double>>& prior_ensemble,
        const StateTransitionFunction& transition,
        const ObservationFunction& observation_model,
        const std::vector<double>& observation,
        const std::vector<double>& observation_variance,
        const EnsembleAssimilationOptions& options = {}) const;
    [[nodiscard]] SolverCredibilityRecord build_credibility_record(
        MeshConvergenceStudy mesh_convergence,
        VerificationBenchmarkResult verification,
        double input_uncertainty,
        double validation_error,
        std::vector<std::string> limitations = {}) const;
    [[nodiscard]] ModelValidationAssessment assess_validation_domain(
        const ModelValidationDomain& domain,
        const std::vector<std::map<std::string, double>>& operating_points,
        const std::vector<double>& measured,
        const std::vector<double>& predicted,
        const std::vector<double>& measurement_standard_uncertainty = {}) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Finite-volume CFD, linear finite-element analysis, and POD reduced-order
// multiphysics.
// -----------------------------------------------------------------------------

struct CfdGrid2d {
    std::size_t nx = 32;
    std::size_t ny = 32;
    double width_m = 1.0;
    double height_m = 1.0;
    double density_kg_m3 = 1.225;
    double dynamic_viscosity_pa_s = 1.81e-5;
    double thermal_diffusivity_m2_s = 2.2e-5;
    double left_temperature_k = 293.15;
    double right_temperature_k = 293.15;
    double bottom_temperature_k = 293.15;
    double top_temperature_k = 313.15;
    double lid_velocity_m_s = 1.0;
};

struct CfdSolverOptions {
    double time_step_s = 0.001;
    std::size_t steps = 1000;
    std::size_t pressure_iterations = 100;
    double pressure_tolerance = 1.0e-7;
    double relaxation = 1.0;
};

struct CfdSolution2d {
    CfdGrid2d grid;
    std::vector<double> u_m_s;
    std::vector<double> v_m_s;
    std::vector<double> pressure_pa;
    std::vector<double> temperature_k;
    double maximum_divergence_s_inv = 0.0;
    double kinetic_energy_j = 0.0;
    double heat_transfer_w = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

struct FeaNode2d {
    std::string id;
    double x_m = 0.0;
    double y_m = 0.0;
    bool fixed_x = false;
    bool fixed_y = false;
    double load_x_n = 0.0;
    double load_y_n = 0.0;
};

struct FeaTrussElement2d {
    std::string id;
    std::size_t node_a = 0;
    std::size_t node_b = 0;
    double area_m2 = 1.0e-4;
    double youngs_modulus_pa = 210.0e9;
    double thermal_expansion_per_k = 12.0e-6;
    double temperature_change_k = 0.0;
    double density_kg_m3 = 7850.0;
};

struct FeaSolution2d {
    std::vector<std::array<double, 2>> displacement_m;
    std::vector<double> axial_force_n;
    std::vector<double> stress_pa;
    std::vector<double> safety_factor;
    double strain_energy_j = 0.0;
    double total_mass_kg = 0.0;
    double maximum_residual_n = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct PodReducedOrderModel {
    std::vector<double> mean;
    std::vector<std::vector<double>> basis; // mode-major
    std::vector<double> singular_values;
    double retained_energy_fraction = 0.0;
    std::string model_sha256;
    [[nodiscard]] std::vector<double> project(const std::vector<double>& state) const;
    [[nodiscard]] std::vector<double> reconstruct(const std::vector<double>& coordinates) const;
    [[nodiscard]] doc::Value to_document(bool include_basis = false) const;
};

struct CoupledMultiphysicsResult {
    CfdSolution2d cfd;
    FeaSolution2d fea;
    PodReducedOrderModel reduced_order_model;
    double mapped_pressure_force_n = 0.0;
    double mapped_average_temperature_k = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class MultiphysicsWorkbench {
public:
    [[nodiscard]] CfdSolution2d solve_cfd(const CfdGrid2d& grid,
                                           const CfdSolverOptions& options = {}) const;
    [[nodiscard]] FeaSolution2d solve_truss(
        const std::vector<FeaNode2d>& nodes,
        const std::vector<FeaTrussElement2d>& elements,
        double material_yield_strength_pa = 250.0e6) const;
    [[nodiscard]] PodReducedOrderModel build_pod(
        const std::vector<std::vector<double>>& snapshots,
        std::size_t maximum_modes,
        double target_energy_fraction = 0.999) const;
    [[nodiscard]] CoupledMultiphysicsResult solve_coupled(
        const CfdGrid2d& grid,
        const CfdSolverOptions& cfd_options,
        std::vector<FeaNode2d> nodes,
        const std::vector<FeaTrussElement2d>& elements,
        const std::vector<std::vector<double>>& snapshots,
        std::size_t pressure_loaded_node,
        std::size_t maximum_modes = 8) const;
};

// -----------------------------------------------------------------------------
// Tire, road, weather, and non-exhaust-emissions laboratory.
// -----------------------------------------------------------------------------

struct TireDefinition {
    double unloaded_radius_m = 0.32;
    double width_m = 0.225;
    double inflation_pressure_pa = 240000.0;
    double vertical_stiffness_n_m = 220000.0;
    double longitudinal_stiffness_n = 90000.0;
    double cornering_stiffness_n_rad = 80000.0;
    double longitudinal_relaxation_length_m = 0.35;
    double lateral_relaxation_length_m = 0.45;
    double tread_depth_m = 0.008;
    double tread_mass_kg = 2.5;
    double thermal_capacity_j_k = 18000.0;
    double thermal_conductance_w_k = 80.0;
    double wear_coefficient_kg_j = 2.0e-12;
};

struct TireRoadEnvironment {
    double dry_friction = 1.0;
    double road_temperature_k = 293.15;
    double air_temperature_k = 293.15;
    double water_depth_m = 0.0;
    double snow_depth_m = 0.0;
    double ice_fraction = 0.0;
    double macrotexture_m = 0.001;
    double roughness_rms_m = 0.0002;
    double road_speed_m_s = 0.0;
};

struct TireOperatingPoint {
    double time_s = 0.0;
    double time_step_s = 0.001;
    double normal_load_n = 4000.0;
    double wheel_angular_speed_rad_s = 0.0;
    double hub_longitudinal_speed_m_s = 0.0;
    double hub_lateral_speed_m_s = 0.0;
    double camber_rad = 0.0;
    double brake_torque_nm = 0.0;
};

struct TireState {
    double effective_longitudinal_slip = 0.0;
    double effective_slip_angle_rad = 0.0;
    double tread_temperature_k = 293.15;
    double carcass_temperature_k = 293.15;
    double tread_depth_m = 0.008;
    double cumulative_wear_mass_kg = 0.0;
    double cumulative_brake_particle_mass_kg = 0.0;
};

struct TireStepResult {
    TireState state;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double rolling_resistance_n = 0.0;
    double friction_coefficient = 0.0;
    double contact_patch_area_m2 = 0.0;
    double aquaplaning_fraction = 0.0;
    double tire_particle_rate_kg_s = 0.0;
    double brake_particle_rate_kg_s = 0.0;
    double radiated_noise_db = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct TireLaboratoryResult {
    std::vector<double> time_s;
    std::vector<TireStepResult> samples;
    double peak_longitudinal_force_n = 0.0;
    double peak_lateral_force_n = 0.0;
    double total_tire_particles_kg = 0.0;
    double total_brake_particles_kg = 0.0;
    double minimum_friction_coefficient = 0.0;
    bool aquaplaning_detected = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_samples = false) const;
};

class TireRoadWeatherLaboratory {
public:
    [[nodiscard]] TireStepResult step(const TireDefinition& tire,
                                      const TireRoadEnvironment& environment,
                                      const TireOperatingPoint& operating_point,
                                      const TireState& previous_state) const;
    [[nodiscard]] TireLaboratoryResult run(
        const TireDefinition& tire,
        const TireRoadEnvironment& environment,
        const std::vector<TireOperatingPoint>& operating_points,
        TireState initial_state = {}) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/advanced/formula_one_fidelity_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// All quantities use SI units. The platform is deterministic for identical
// configurations, states, inputs, random seeds, and integration step sizes.

// -----------------------------------------------------------------------------
// Flexible-body vehicle dynamics.
// -----------------------------------------------------------------------------

struct F1StructuralModeConfiguration {
    std::string id;
    double modal_mass_kg = 1.0;
    double natural_frequency_hz = 20.0;
    double damping_ratio = 0.08;
    double front_left_shape = 0.0;
    double front_right_shape = 0.0;
    double rear_left_shape = 0.0;
    double rear_right_shape = 0.0;
    double aero_front_shape = 0.0;
    double aero_rear_shape = 0.0;
    double steering_shape_rad_m = 0.0;
    double stress_per_modal_m_pa = 0.0;
    double fatigue_strength_pa = 4.0e8;
    double fatigue_exponent = 5.0;

    void validate() const;
};

struct F1FlexibleBodyConfiguration {
    std::vector<F1StructuralModeConfiguration> modes;
    double newmark_beta = 0.25;
    double newmark_gamma = 0.50;
    double maximum_modal_displacement_m = 0.050;
    double aero_deflection_feedback_per_m = 4.0;

    void validate() const;
};

struct F1FlexibleBodyState {
    double time_s = 0.0;
    std::vector<double> modal_displacement_m;
    std::vector<double> modal_velocity_m_s;
    std::vector<double> modal_acceleration_m_s2;
    std::vector<double> cumulative_fatigue_damage;
};

struct F1FlexibleBodyInput {
    double time_step_s = 0.001;
    std::array<double, 4> suspension_force_n{};
    double front_aerodynamic_load_n = 0.0;
    double rear_aerodynamic_load_n = 0.0;
    double steering_rack_force_n = 0.0;
    double temperature_scale = 1.0;
};

struct F1FlexibleBodyResult {
    F1FlexibleBodyState state;
    std::array<double, 4> corner_deflection_m{};
    double front_aero_deflection_m = 0.0;
    double rear_aero_deflection_m = 0.0;
    double steering_compliance_rad = 0.0;
    double aerodynamic_load_scale = 1.0;
    double modal_kinetic_energy_j = 0.0;
    double modal_strain_energy_j = 0.0;
    double peak_modal_stress_pa = 0.0;
    bool finite = true;
};

class F1FlexibleBodyVehicleDynamics {
public:
    explicit F1FlexibleBodyVehicleDynamics(F1FlexibleBodyConfiguration configuration = {});
    [[nodiscard]] const F1FlexibleBodyConfiguration& configuration() const noexcept;
    [[nodiscard]] F1FlexibleBodyState make_initial_state() const;
    [[nodiscard]] F1FlexibleBodyResult step(const F1FlexibleBodyInput& input,
                                             const F1FlexibleBodyState& state) const;

private:
    F1FlexibleBodyConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Persistent multi-car wake field.
// -----------------------------------------------------------------------------

struct F1WakeCarState {
    std::string id;
    F1FidelityVector3 position_m{};
    F1FidelityVector3 velocity_m_s{};
    double yaw_rad = 0.0;
    double downforce_n = 0.0;
    double drag_n = 0.0;
    double characteristic_width_m = 2.0;
    double characteristic_height_m = 1.0;
    double spray_generation_kg_s = 0.0;
};

struct F1WakeElement {
    std::uint64_t id = 0;
    std::string source_car_id;
    F1FidelityVector3 position_m{};
    F1FidelityVector3 velocity_deficit_m_s{};
    F1FidelityVector3 vorticity_s{};
    double turbulence_intensity = 0.0;
    double temperature_excess_k = 0.0;
    double moisture_kg_m3 = 0.0;
    double radius_m = 1.0;
    double age_s = 0.0;
};

struct F1PersistentWakeConfiguration {
    double emission_period_s = 0.05;
    double circulation_scale = 0.0025;
    double velocity_deficit_scale = 0.16;
    double initial_turbulence_intensity = 0.20;
    double initial_radius_m = 0.85;
    double turbulent_diffusivity_m2_s = 1.8;
    double velocity_decay_time_s = 3.0;
    double vorticity_decay_time_s = 4.0;
    double moisture_decay_time_s = 2.2;
    double maximum_age_s = 12.0;
    double minimum_car_speed_m_s = 5.0;
    std::size_t maximum_elements = 20000;

    void validate() const;
};

struct F1WakeEffect {
    std::string car_id;
    F1FidelityVector3 induced_velocity_m_s{};
    double turbulence_intensity = 0.0;
    double front_downforce_scale = 1.0;
    double rear_downforce_scale = 1.0;
    double drag_scale = 1.0;
    double cooling_scale = 1.0;
    double visibility_scale = 1.0;
    double moisture_kg_m3 = 0.0;
};

struct F1WakeFieldResult {
    double time_s = 0.0;
    std::vector<F1WakeElement> elements;
    std::map<std::string, F1WakeEffect> effects;
    std::size_t emitted_elements = 0;
    std::size_t removed_elements = 0;
};

class F1PersistentMultiCarWakeField {
public:
    explicit F1PersistentMultiCarWakeField(F1PersistentWakeConfiguration configuration = {});
    void reset(double time_s = 0.0);
    [[nodiscard]] F1WakeFieldResult step(double time_step_s,
                                         const std::vector<F1WakeCarState>& cars,
                                         const F1FidelityVector3& ambient_wind_m_s = {});
    [[nodiscard]] const std::vector<F1WakeElement>& elements() const noexcept;

private:
    F1PersistentWakeConfiguration configuration_;
    std::vector<F1WakeElement> elements_;
    std::map<std::string, double> emission_accumulator_s_;
    double time_s_ = 0.0;
    std::uint64_t next_id_ = 1;
};

// -----------------------------------------------------------------------------
// Integrated thermal-fluid network.
// -----------------------------------------------------------------------------

enum class F1ThermalFluidNodeType { Reservoir, Junction, Component, Radiator, Ambient };

enum class F1ThermalFluidEdgeType { Pipe, Pump, Valve, HeatExchanger, Leak };

struct F1ThermalFluidProperties {
    double density_kg_m3 = 1000.0;
    double specific_heat_j_kg_k = 4000.0;
    double dynamic_viscosity_pa_s = 0.001;
    double bulk_modulus_pa = 2.0e9;
    double vapor_pressure_pa = 3000.0;

    void validate() const;
};

struct F1ThermalFluidNodeConfiguration {
    std::string id;
    F1ThermalFluidNodeType type = F1ThermalFluidNodeType::Component;
    double volume_m3 = 0.002;
    double initial_temperature_k = 330.0;
    double initial_pressure_pa = 200000.0;
    double thermal_mass_j_k = 10000.0;
    double heat_input_w = 0.0;
    double ambient_conductance_w_k = 0.0;
    double minimum_pressure_pa = 1000.0;
    double maximum_pressure_pa = 2.0e7;
};

struct F1ThermalFluidEdgeConfiguration {
    std::string id;
    std::string from_node;
    std::string to_node;
    F1ThermalFluidEdgeType type = F1ThermalFluidEdgeType::Pipe;
    double hydraulic_resistance_pa_s2_kg2 = 2.0e6;
    double pump_pressure_rise_pa = 0.0;
    double valve_open_fraction = 1.0;
    double heat_transfer_w_k = 0.0;
    double external_temperature_k = 300.0;
    double maximum_mass_flow_kg_s = 10.0;
};

struct F1ThermalFluidNetworkConfiguration {
    F1ThermalFluidProperties fluid;
    std::vector<F1ThermalFluidNodeConfiguration> nodes;
    std::vector<F1ThermalFluidEdgeConfiguration> edges;
    std::size_t pressure_iterations = 16;
    double pressure_relaxation = 0.35;

    void validate() const;
};

struct F1ThermalFluidNodeState {
    double pressure_pa = 200000.0;
    double temperature_k = 330.0;
    double fluid_mass_kg = 1.0;
    double vapor_fraction = 0.0;
};

struct F1ThermalFluidNetworkState {
    double time_s = 0.0;
    std::map<std::string, F1ThermalFluidNodeState> nodes;
};

struct F1ThermalFluidEdgeResult {
    std::string id;
    double mass_flow_kg_s = 0.0;
    double transferred_heat_w = 0.0;
    bool cavitating = false;
};

struct F1ThermalFluidNetworkResult {
    F1ThermalFluidNetworkState state;
    std::vector<F1ThermalFluidEdgeResult> edges;
    double total_heat_input_w = 0.0;
    double total_heat_rejected_w = 0.0;
    double mass_conservation_error_kg = 0.0;
    double energy_conservation_error_j = 0.0;
    bool finite = true;
};

class F1IntegratedThermalFluidNetwork {
public:
    explicit F1IntegratedThermalFluidNetwork(F1ThermalFluidNetworkConfiguration configuration);
    [[nodiscard]] const F1ThermalFluidNetworkConfiguration& configuration() const noexcept;
    [[nodiscard]] F1ThermalFluidNetworkState make_initial_state() const;
    [[nodiscard]] F1ThermalFluidNetworkResult step(
        double time_step_s,
        const F1ThermalFluidNetworkState& state,
        const std::map<std::string, double>& node_heat_input_w = {},
        const std::map<std::string, double>& valve_open_fraction = {}) const;

private:
    F1ThermalFluidNetworkConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Physics-of-failure lifing.
// -----------------------------------------------------------------------------

enum class F1FailureMechanism { Fatigue, CrackGrowth, BearingContact, ThermalCycle, Creep };

struct F1ComponentLifingConfiguration {
    std::string id;
    double ultimate_strength_pa = 1.0e9;
    double fatigue_strength_coefficient_pa = 7.0e8;
    double fatigue_exponent = 5.0;
    double mean_stress_sensitivity = 1.0;
    double initial_crack_m = 1.0e-5;
    double critical_crack_m = 0.002;
    double paris_c_m_per_cycle = 1.0e-12;
    double paris_m = 3.0;
    double geometry_factor = 1.12;
    double bearing_dynamic_capacity_n = 50000.0;
    double bearing_life_exponent = 3.0;
    double thermal_cycle_reference_k = 80.0;
    double thermal_cycle_life = 10000.0;
    double creep_reference_temperature_k = 650.0;
    double creep_activation_k = 12000.0;
    double creep_life_s = 1.0e7;

    void validate() const;
};

struct F1LoadHistorySample {
    double time_s = 0.0;
    double stress_pa = 0.0;
    double temperature_k = 300.0;
    double bearing_load_n = 0.0;
};

struct F1ComponentLifingState {
    double cumulative_fatigue_damage = 0.0;
    double crack_length_m = 1.0e-5;
    double bearing_damage = 0.0;
    double thermal_cycle_damage = 0.0;
    double creep_damage = 0.0;
    double previous_temperature_k = 300.0;
    double elapsed_time_s = 0.0;
};

struct F1ComponentLifingResult {
    F1ComponentLifingState state;
    std::size_t counted_cycles = 0;
    double combined_damage = 0.0;
    double survival_probability = 1.0;
    double remaining_useful_life_fraction = 1.0;
    double estimated_remaining_time_s = 0.0;
    F1FailureMechanism dominant_mechanism = F1FailureMechanism::Fatigue;
    bool failed = false;
};

class F1PhysicsOfFailureLifing {
public:
    explicit F1PhysicsOfFailureLifing(F1ComponentLifingConfiguration configuration);
    [[nodiscard]] F1ComponentLifingState make_initial_state() const;
    [[nodiscard]] F1ComponentLifingResult evaluate(
        const std::vector<F1LoadHistorySample>& history,
        const F1ComponentLifingState& state) const;

private:
    F1ComponentLifingConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Optimal experiment design.
// -----------------------------------------------------------------------------

enum class F1ExperimentDesignCriterion { DOptimal, AOptimal, EOptimal };

struct F1ExperimentCandidate {
    std::string id;
    std::vector<std::vector<double>> normalized_sensitivity;
    double cost = 1.0;
    std::map<std::string, double> settings;
};

struct F1ExperimentDesignConfiguration {
    F1ExperimentDesignCriterion criterion = F1ExperimentDesignCriterion::DOptimal;
    std::size_t maximum_experiments = 1;
    double maximum_total_cost = 1.0e12;
    double ridge_regularization = 1.0e-9;

    void validate() const;
};

struct F1ExperimentDesignResult {
    std::vector<std::string> selected_ids;
    std::vector<std::map<std::string, double>> selected_settings;
    std::vector<std::vector<double>> fisher_information;
    std::vector<std::vector<double>> parameter_covariance;
    double criterion_value = 0.0;
    double total_cost = 0.0;
    std::size_t numerical_rank = 0;
    bool full_rank = false;
};

class F1OptimalExperimentDesigner {
public:
    [[nodiscard]] F1ExperimentDesignResult select(
        const std::vector<F1ExperimentCandidate>& candidates,
        std::size_t parameter_count,
        const F1ExperimentDesignConfiguration& configuration = {}) const;
};

// -----------------------------------------------------------------------------
// Advanced Bayesian estimation: unscented filter and particle filter.
// -----------------------------------------------------------------------------

enum class F1BayesianEstimatorMode { UnscentedKalman, ParticleFilter };

struct F1BayesianEstimatorConfiguration {
    F1BayesianEstimatorMode mode = F1BayesianEstimatorMode::UnscentedKalman;
    std::size_t state_dimension = 1;
    std::size_t particle_count = 512;
    double ukf_alpha = 0.2;
    double ukf_beta = 2.0;
    double ukf_kappa = 0.0;
    double resample_effective_fraction = 0.50;
    std::uint64_t random_seed = 1;

    void validate() const;
};

struct F1BayesianEstimate {
    std::vector<double> mean;
    std::vector<std::vector<double>> covariance;
    double log_likelihood = 0.0;
    double effective_sample_size = 0.0;
    std::size_t accepted_measurements = 0;
};

class F1AdvancedBayesianEstimator {
public:
    using TransitionModel = std::function<std::vector<double>(const std::vector<double>&,
                                                               const std::vector<double>&,
                                                               double)>;
    using ObservationModel = std::function<std::vector<double>(const std::vector<double>&)>;

    explicit F1AdvancedBayesianEstimator(F1BayesianEstimatorConfiguration configuration);
    void initialize(const std::vector<double>& mean,
                    const std::vector<std::vector<double>>& covariance);
    void predict(const TransitionModel& transition,
                 const std::vector<double>& control,
                 double time_step_s,
                 const std::vector<std::vector<double>>& process_covariance);
    [[nodiscard]] F1BayesianEstimate update(
        const ObservationModel& observation,
        const std::vector<double>& measurement,
        const std::vector<std::vector<double>>& measurement_covariance);
    [[nodiscard]] F1BayesianEstimate current() const;

private:
    F1BayesianEstimatorConfiguration configuration_;
    std::vector<double> mean_;
    std::vector<std::vector<double>> covariance_;
    std::vector<std::vector<double>> particles_;
    std::vector<double> weights_;
    std::uint64_t random_state_ = 1;
    double log_likelihood_ = 0.0;
    std::size_t accepted_measurements_ = 0;
    bool initialized_ = false;
};

// -----------------------------------------------------------------------------
// Adaptive multifidelity manager.
// -----------------------------------------------------------------------------

struct F1FidelityRequest {
    double maximum_error = 0.01;
    double maximum_runtime_s = 1.0;
    bool gradients_required = false;
    bool uncertainty_required = false;
};

struct F1FidelityModelDescriptor {
    std::string id;
    int fidelity_level = 0;
    double nominal_error = 0.1;
    double nominal_runtime_s = 0.001;
    bool supplies_gradients = false;
    bool supplies_uncertainty = false;
    std::vector<double> domain_center;
    std::vector<double> domain_scale;
    std::function<double(const std::vector<double>&)> scalar_model;
};

struct F1FidelityEvaluation {
    std::string model_id;
    int fidelity_level = 0;
    double value = 0.0;
    double estimated_error = 0.0;
    double estimated_runtime_s = 0.0;
    double extrapolation_distance = 0.0;
    bool request_satisfied = false;
};

class F1AdaptiveMultifidelityManager {
public:
    void register_model(F1FidelityModelDescriptor model);
    void record_validation(const std::string& model_id, double absolute_error,
                           double runtime_s);
    [[nodiscard]] F1FidelityEvaluation evaluate(const std::vector<double>& input,
                                                const F1FidelityRequest& request) const;
    [[nodiscard]] std::vector<std::string> model_ids() const;

private:
    struct ModelStatistics {
        F1FidelityModelDescriptor descriptor;
        std::size_t validation_count = 0;
        double mean_absolute_error = 0.0;
        double mean_runtime_s = 0.0;
    };
    std::map<std::string, ModelStatistics> models_;
};

// -----------------------------------------------------------------------------
// Differentiable Formula One runtime using second-order forward AD.
// -----------------------------------------------------------------------------

class F1DifferentiableScalar {
public:
    F1DifferentiableScalar() = default;
    F1DifferentiableScalar(double value, std::size_t dimension = 0);
    static F1DifferentiableScalar variable(double value, std::size_t index,
                                            std::size_t dimension);

    [[nodiscard]] double value() const noexcept;
    [[nodiscard]] const std::vector<double>& gradient() const noexcept;
    [[nodiscard]] const std::vector<std::vector<double>>& hessian() const noexcept;

    F1DifferentiableScalar& operator+=(const F1DifferentiableScalar& other);
    F1DifferentiableScalar& operator-=(const F1DifferentiableScalar& other);
    F1DifferentiableScalar& operator*=(const F1DifferentiableScalar& other);
    F1DifferentiableScalar& operator/=(const F1DifferentiableScalar& other);

private:
    double value_ = 0.0;
    std::vector<double> gradient_;
    std::vector<std::vector<double>> hessian_;

    static F1DifferentiableScalar unary_transform(
        const F1DifferentiableScalar& value,
        const std::function<double(double)>& function,
        const std::function<double(double)>& first_derivative,
        const std::function<double(double)>& second_derivative);

    friend F1DifferentiableScalar operator+(F1DifferentiableScalar left,
                                             const F1DifferentiableScalar& right);
    friend F1DifferentiableScalar operator-(F1DifferentiableScalar left,
                                             const F1DifferentiableScalar& right);
    friend F1DifferentiableScalar operator*(F1DifferentiableScalar left,
                                             const F1DifferentiableScalar& right);
    friend F1DifferentiableScalar operator/(F1DifferentiableScalar left,
                                             const F1DifferentiableScalar& right);
    friend F1DifferentiableScalar operator-(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar exp(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar log(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar sqrt(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar sin(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar cos(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar tanh(const F1DifferentiableScalar& value);
    friend F1DifferentiableScalar pow(const F1DifferentiableScalar& value, double exponent);
};

F1DifferentiableScalar operator+(F1DifferentiableScalar left,
                                 const F1DifferentiableScalar& right);
F1DifferentiableScalar operator-(F1DifferentiableScalar left,
                                 const F1DifferentiableScalar& right);
F1DifferentiableScalar operator*(F1DifferentiableScalar left,
                                 const F1DifferentiableScalar& right);
F1DifferentiableScalar operator/(F1DifferentiableScalar left,
                                 const F1DifferentiableScalar& right);
F1DifferentiableScalar operator-(const F1DifferentiableScalar& value);
F1DifferentiableScalar exp(const F1DifferentiableScalar& value);
F1DifferentiableScalar log(const F1DifferentiableScalar& value);
F1DifferentiableScalar sqrt(const F1DifferentiableScalar& value);
F1DifferentiableScalar sin(const F1DifferentiableScalar& value);
F1DifferentiableScalar cos(const F1DifferentiableScalar& value);
F1DifferentiableScalar tanh(const F1DifferentiableScalar& value);
F1DifferentiableScalar pow(const F1DifferentiableScalar& value, double exponent);

struct F1DifferentiableResult {
    double value = 0.0;
    std::vector<double> gradient;
    std::vector<std::vector<double>> hessian;
};

class F1DifferentiableFormulaOneRuntime {
public:
    using Model = std::function<F1DifferentiableScalar(
        const std::vector<F1DifferentiableScalar>&)>;

    [[nodiscard]] F1DifferentiableResult evaluate(const std::vector<double>& parameters,
                                                  const Model& model) const;
};

// -----------------------------------------------------------------------------
// Compressible power-unit gas dynamics.
// -----------------------------------------------------------------------------

struct F1GasCellState {
    double pressure_pa = 101325.0;
    double temperature_k = 300.0;
    double velocity_m_s = 0.0;
    double fuel_mass_fraction = 0.0;
};

struct F1GasDuctConfiguration {
    std::string id;
    double length_m = 0.5;
    double area_m2 = 0.002;
    double hydraulic_diameter_m = 0.05;
    double wall_temperature_k = 350.0;
    double wall_heat_transfer_w_m2_k = 80.0;
    double friction_factor = 0.02;
    std::size_t cells = 16;

    void validate() const;
};

struct F1CompressiblePowerUnitConfiguration {
    F1GasDuctConfiguration intake{"intake", 0.8, 0.0030, 0.060, 330.0, 70.0, 0.018, 24};
    F1GasDuctConfiguration exhaust{"exhaust", 1.0, 0.0025, 0.052, 850.0, 110.0, 0.022, 24};
    double displacement_m3 = 0.0016;
    std::size_t cylinders = 6;
    double compression_ratio = 18.0;
    double volumetric_efficiency = 1.15;
    double combustion_efficiency = 0.97;
    double fuel_lower_heating_value_j_kg = 43.0e6;
    double stoichiometric_air_fuel_ratio = 14.7;
    double turbo_inertia_kg_m2 = 1.8e-4;
    double compressor_efficiency = 0.72;
    double turbine_efficiency = 0.74;
    double turbo_mechanical_efficiency = 0.97;
    double maximum_turbo_speed_rad_s = 130000.0;
    double maximum_boost_pressure_pa = 400000.0;
    double crank_friction_mean_effective_pressure_pa = 1.4e5;
    double gas_gamma = 1.36;
    double gas_constant_j_kg_k = 287.0;
    double maximum_internal_step_s = 2.0e-5;

    void validate() const;
};

struct F1CompressiblePowerUnitState {
    double time_s = 0.0;
    std::vector<F1GasCellState> intake_cells;
    std::vector<F1GasCellState> exhaust_cells;
    double intake_plenum_pressure_pa = 120000.0;
    double intake_plenum_temperature_k = 330.0;
    double exhaust_manifold_pressure_pa = 160000.0;
    double exhaust_manifold_temperature_k = 900.0;
    double turbo_speed_rad_s = 40000.0;
    double cumulative_fuel_kg = 0.0;
};

struct F1CompressiblePowerUnitInput {
    double time_step_s = 0.001;
    double engine_speed_rad_s = 1000.0;
    double throttle = 1.0;
    double fuel_flow_command_kg_s = 0.020;
    double ambient_pressure_pa = 101325.0;
    double ambient_temperature_k = 298.15;
    double wastegate_fraction = 0.0;
};

struct F1CompressiblePowerUnitResult {
    F1CompressiblePowerUnitState state;
    double air_mass_flow_kg_s = 0.0;
    double fuel_mass_flow_kg_s = 0.0;
    double indicated_torque_nm = 0.0;
    double brake_torque_nm = 0.0;
    double brake_power_w = 0.0;
    double compressor_power_w = 0.0;
    double turbine_power_w = 0.0;
    double lambda = 1.0;
    double boost_pressure_pa = 0.0;
    double exhaust_temperature_k = 0.0;
    double mass_conservation_error_kg = 0.0;
    bool finite = true;
};

class F1CompressiblePowerUnitGasDynamics {
public:
    explicit F1CompressiblePowerUnitGasDynamics(
        F1CompressiblePowerUnitConfiguration configuration = {});
    [[nodiscard]] F1CompressiblePowerUnitState make_initial_state(
        double ambient_pressure_pa = 101325.0,
        double ambient_temperature_k = 298.15) const;
    [[nodiscard]] F1CompressiblePowerUnitResult step(
        const F1CompressiblePowerUnitInput& input,
        const F1CompressiblePowerUnitState& state) const;

private:
    F1CompressiblePowerUnitConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Real-time ECU and HIL integration.
// -----------------------------------------------------------------------------

enum class F1EcuTaskPriority : int { Background = 0, Low = 1, Normal = 2, High = 3, Critical = 4 };

enum class F1HilFaultType { None, Drop, Delay, Corrupt, StuckValue };

struct F1EcuTaskConfiguration {
    std::string id;
    double period_s = 0.001;
    double phase_s = 0.0;
    double deadline_s = 0.001;
    double worst_case_execution_s = 0.0002;
    F1EcuTaskPriority priority = F1EcuTaskPriority::Normal;
    std::function<void(double, std::map<std::string, double>&)> callback;

    void validate() const;
};

struct F1CanMessage {
    std::uint32_t identifier = 0;
    std::vector<std::uint8_t> payload;
    double release_time_s = 0.0;
    double arrival_time_s = 0.0;
    std::string source;
};

struct F1HilFaultInjection {
    F1HilFaultType type = F1HilFaultType::None;
    std::string signal_or_bus;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    double magnitude = 0.0;
};

struct F1RealtimeHilConfiguration {
    double scheduler_tick_s = 0.0001;
    double can_bitrate_bits_s = 2.0e6;
    double ethernet_bitrate_bits_s = 100.0e6;
    double transport_latency_s = 0.0002;
    bool wall_clock_pacing = false;
    double maximum_lag_s = 0.010;

    void validate() const;
};

struct F1EcuTaskExecution {
    std::string id;
    double release_time_s = 0.0;
    double start_time_s = 0.0;
    double finish_time_s = 0.0;
    double response_time_s = 0.0;
    bool deadline_missed = false;
};

struct F1RealtimeHilResult {
    double simulated_time_s = 0.0;
    std::vector<F1EcuTaskExecution> task_executions;
    std::vector<F1CanMessage> delivered_messages;
    std::map<std::string, double> signals;
    std::size_t deadline_misses = 0;
    std::size_t dropped_messages = 0;
    double scheduler_utilization = 0.0;
    double wall_clock_lag_s = 0.0;
};

class F1RealtimeEcuHilIntegration {
public:
    explicit F1RealtimeEcuHilIntegration(F1RealtimeHilConfiguration configuration = {});
    void add_task(F1EcuTaskConfiguration task);
    void schedule_can_message(F1CanMessage message);
    void add_fault(F1HilFaultInjection fault);
    void set_signal(const std::string& id, double value);
    [[nodiscard]] F1RealtimeHilResult run_until(double target_time_s);
    void reset(double time_s = 0.0);

private:
    struct TaskState {
        F1EcuTaskConfiguration configuration;
        double next_release_s = 0.0;
    };
    F1RealtimeHilConfiguration configuration_;
    std::vector<TaskState> tasks_;
    std::deque<F1CanMessage> can_queue_;
    std::vector<F1HilFaultInjection> faults_;
    std::map<std::string, double> signals_;
    double time_s_ = 0.0;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/advanced/formula_one_team_competition.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// Full-car multidisciplinary design optimization.
enum class F1MdoVariableKind { Continuous, Discrete };

struct F1MdoVariable {
    std::string name;
    F1MdoVariableKind kind = F1MdoVariableKind::Continuous;
    double lower = 0.0;
    double upper = 1.0;
    double initial = 0.5;
    std::vector<double> discrete_values;
    void validate() const;
};

struct F1MdoScenario {
    std::string name;
    double weight = 1.0;
    double ambient_temperature_k = 298.15;
    double track_grip_multiplier = 1.0;
    double air_density_kg_m3 = 1.225;
    double manufacturing_sigma = 0.0;
    std::map<std::string, double> modifiers;
    void validate() const;
};

struct F1MdoMetrics {
    double lap_time_s = 0.0;
    double drag_coefficient = 0.0;
    double downforce_n = 0.0;
    double mass_kg = 0.0;
    double peak_temperature_k = 0.0;
    double reliability = 1.0;
    double compliance_margin = 0.0;
    double correlation_confidence = 1.0;
    double cost = 0.0;
    double resource_units = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1MdoConstraints {
    double maximum_mass_kg = 1.0e9;
    double maximum_temperature_k = 1.0e9;
    double minimum_reliability = 0.0;
    double minimum_compliance_margin = -1.0e9;
    double minimum_correlation_confidence = 0.0;
    double maximum_cost = 1.0e18;
    double maximum_resource_units = 1.0e18;
};

struct F1MdoObjectiveWeights {
    double lap_time = 1.0;
    double drag = 0.0;
    double mass = 0.0;
    double temperature = 0.0;
    double unreliability = 0.0;
    double cost = 0.0;
    double resource = 0.0;
    double robustness = 0.0;
};

using F1MdoEvaluator = std::function<F1MdoMetrics(
    const std::map<std::string, double>& design,
    const F1MdoScenario& scenario)>;

struct F1MdoCandidate {
    std::map<std::string, double> design;
    std::vector<F1MdoMetrics> scenario_metrics;
    F1MdoMetrics robust_metrics;
    std::vector<double> objective_vector;
    double scalar_objective = 0.0;
    double maximum_constraint_violation = 0.0;
    bool feasible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1MdoConfig {
    std::vector<F1MdoVariable> variables;
    std::vector<F1MdoScenario> scenarios;
    F1MdoConstraints constraints;
    F1MdoObjectiveWeights objective_weights;
    std::size_t population_size = 48;
    std::size_t generations = 24;
    std::size_t local_iterations = 30;
    double initial_trust_fraction = 0.20;
    std::uint64_t random_seed = 1;
};

struct F1MdoResult {
    F1MdoCandidate best;
    std::vector<F1MdoCandidate> pareto_front;
    std::size_t evaluations = 0;
    std::size_t feasible_evaluations = 0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1FullCarMdoOptimizer {
public:
    [[nodiscard]] F1MdoResult optimize(const F1MdoConfig& config,
                                       const F1MdoEvaluator& evaluator) const;
};

// Formula One physical rig and HIL laboratory.
enum class F1RigKind {
    SevenPost,
    FourPost,
    KinematicsCompliance,
    BrakeDynamometer,
    GearboxDynamometer,
    PowerUnitDynamometer,
    ActiveAero,
    TireMachine
};

enum class F1RigFaultKind { Bias, Noise, Dropout, Stuck, Delay, ActuatorLoss };

struct F1RigAxis {
    std::string name;
    double mass_kg = 1.0;
    double stiffness_n_m = 1.0;
    double damping_n_s_m = 0.0;
    double travel_limit_m = 1.0;
    double actuator_force_limit_n = 1.0e9;
    double actuator_rate_limit_n_s = 1.0e12;
    double sensor_noise_std = 0.0;
    void validate() const;
};

struct F1RigCommandSample {
    double time_s = 0.0;
    std::map<std::string, double> force_command_n;
};

struct F1RigFault {
    F1RigFaultKind kind = F1RigFaultKind::Bias;
    std::string axis;
    double start_s = 0.0;
    double end_s = 0.0;
    double magnitude = 0.0;
};

struct F1RigConfig {
    F1RigKind kind = F1RigKind::SevenPost;
    std::vector<F1RigAxis> axes;
    double sample_period_s = 0.001;
    double duration_s = 1.0;
    double real_time_deadline_s = 0.001;
    std::uint64_t random_seed = 1;
};

struct F1RigSample {
    double time_s = 0.0;
    std::map<std::string, double> commanded_force_n;
    std::map<std::string, double> actuator_force_n;
    std::map<std::string, double> displacement_m;
    std::map<std::string, double> velocity_m_s;
    std::map<std::string, double> measured_displacement_m;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RigFrequencyResponse {
    std::string axis;
    double frequency_hz = 0.0;
    double magnitude_m_n = 0.0;
    double phase_rad = 0.0;
    double coherence = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1RigResult {
    std::vector<F1RigSample> samples;
    std::vector<F1RigFrequencyResponse> frequency_response;
    double rms_tracking_error_n = 0.0;
    double actuator_energy_j = 0.0;
    double maximum_travel_fraction = 0.0;
    bool travel_limit_exceeded = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1HilControlOutput {
    std::map<std::string, double> actuator_commands_n;
    double declared_execution_time_s = 0.0;
    bool request_safe_state = false;
};

using F1HilController = std::function<F1HilControlOutput(
    double time_s,
    const std::map<std::string, double>& measurements)>;

struct F1HilResult {
    F1RigResult rig;
    std::size_t deadline_misses = 0;
    double worst_execution_time_s = 0.0;
    bool safe_state_reached = false;
    std::vector<std::string> events;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1PhysicalRigHilLaboratory {
public:
    [[nodiscard]] F1RigResult simulate(const F1RigConfig& config,
                                       const std::vector<F1RigCommandSample>& commands,
                                       const std::vector<F1RigFault>& faults = {}) const;
    [[nodiscard]] F1HilResult run_hil(const F1RigConfig& config,
                                     const F1HilController& controller,
                                     const std::vector<F1RigFault>& faults = {}) const;
};

// Digital scrutineering and measurement tolerance.
struct F1ScanPoint {
    std::array<double, 3> position_m{0.0, 0.0, 0.0};
    double standard_uncertainty_m = 0.0;
};

struct F1DatumCorrespondence {
    std::array<double, 3> nominal_m{0.0, 0.0, 0.0};
    F1ScanPoint measured;
};

struct F1RigidAlignment {
    std::array<double, 9> rotation{1.0,0.0,0.0,0.0,1.0,0.0,0.0,1.0};
    std::array<double, 3> translation_m{0.0,0.0,0.0};
    double rms_residual_m = 0.0;
    double standard_uncertainty_m = 0.0;
    [[nodiscard]] std::array<double, 3> transform(const std::array<double, 3>& point) const;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1MeasuredScalar {
    double value = 0.0;
    double standard_uncertainty = 0.0;
};

enum class F1ScrutineeringRuleKind {
    Minimum,
    Maximum,
    Range,
    BooleanRequired,
    DeflectionMaximum,
    Envelope,
    SoftwareHash
};

struct F1ScrutineeringRule {
    std::string id;
    F1ScrutineeringRuleKind kind = F1ScrutineeringRuleKind::Maximum;
    std::string measurement_key;
    double minimum = 0.0;
    double maximum = 0.0;
    double guard_band_sigma = 2.0;
    std::array<double, 3> envelope_min_m{0.0,0.0,0.0};
    std::array<double, 3> envelope_max_m{0.0,0.0,0.0};
    std::string expected_hash;
    bool safety_critical = false;
    std::string rationale;
};

struct F1ScrutineeringSubmission {
    std::vector<F1DatumCorrespondence> datums;
    std::map<std::string, F1MeasuredScalar> scalar_measurements;
    std::map<std::string, bool> boolean_measurements;
    std::map<std::string, std::vector<F1ScanPoint>> scanned_entities;
    std::map<std::string, std::string> software_hashes;
    std::uint64_t monte_carlo_seed = 1;
};

struct F1ScrutineeringCheck {
    std::string rule_id;
    bool passed = false;
    double measured_value = 0.0;
    double nominal_margin = 0.0;
    double guard_banded_margin = 0.0;
    double standard_uncertainty = 0.0;
    double probability_of_conformance = 0.0;
    std::string reasoning;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1ScrutineeringReport {
    F1RigidAlignment alignment;
    std::vector<F1ScrutineeringCheck> checks;
    bool compliant = false;
    double minimum_probability_of_conformance = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1DigitalScrutineeringEngine {
public:
    explicit F1DigitalScrutineeringEngine(std::vector<F1ScrutineeringRule> rules);
    [[nodiscard]] F1RigidAlignment align(const std::vector<F1DatumCorrespondence>& datums) const;
    [[nodiscard]] F1ScrutineeringReport inspect(const F1ScrutineeringSubmission& submission) const;
private:
    std::vector<F1ScrutineeringRule> rules_;
};

// Tire parameter identification and virtual tire testing.
struct F1TireIdentificationParameters {
    double friction_coefficient = 1.8;
    double load_sensitivity = 0.10;
    double longitudinal_stiffness_n = 180000.0;
    double cornering_stiffness_n_rad = 160000.0;
    double camber_stiffness_n_rad = 18000.0;
    double longitudinal_relaxation_m = 0.35;
    double lateral_relaxation_m = 0.45;
    double optimum_temperature_k = 363.15;
    double temperature_width_k = 25.0;
    double optimum_pressure_pa = 145000.0;
    double pressure_sensitivity = 0.18;
    double wear_sensitivity = 0.35;
    double rolling_resistance = 0.012;
    void validate() const;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1VirtualTireInput {
    double normal_load_n = 4000.0;
    double slip_ratio = 0.0;
    double slip_angle_rad = 0.0;
    double camber_rad = 0.0;
    double speed_m_s = 50.0;
    double temperature_k = 363.15;
    double pressure_pa = 145000.0;
    double wear_fraction = 0.0;
    double time_step_s = 0.01;
};

struct F1VirtualTireOutput {
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double aligning_moment_n_m = 0.0;
    double rolling_resistance_n = 0.0;
    double effective_friction = 0.0;
    double relaxed_slip_ratio = 0.0;
    double relaxed_slip_angle_rad = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TireObservation {
    F1VirtualTireInput input;
    double measured_fx_n = 0.0;
    double measured_fy_n = 0.0;
    double measured_mz_n_m = 0.0;
    double uncertainty_fx_n = 1.0;
    double uncertainty_fy_n = 1.0;
    double uncertainty_mz_n_m = 1.0;
};

struct F1TireIdentificationConfig {
    F1TireIdentificationParameters initial;
    std::vector<std::string> fitted_parameters;
    std::map<std::string, std::pair<double, double>> bounds;
    std::size_t maximum_iterations = 60;
    double initial_damping = 1.0e-2;
    double huber_threshold = 2.5;
};

struct F1TireIdentificationResult {
    F1TireIdentificationParameters parameters;
    std::vector<std::vector<double>> covariance;
    double weighted_rms = 0.0;
    double condition_estimate = 0.0;
    double identifiability_score = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
    std::vector<double> normalized_residuals;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1VirtualTireTestLaboratory {
public:
    [[nodiscard]] F1VirtualTireOutput steady_state(
        const F1TireIdentificationParameters& parameters,
        const F1VirtualTireInput& input) const;
    [[nodiscard]] std::vector<F1VirtualTireOutput> transient_test(
        const F1TireIdentificationParameters& parameters,
        const std::vector<F1VirtualTireInput>& inputs) const;
    [[nodiscard]] F1TireIdentificationResult identify(
        const std::vector<F1TireObservation>& observations,
        const F1TireIdentificationConfig& config) const;
};

// Formula One control-software qualification and safety.
enum class F1ControlDomain {
    ActiveAero,
    EnergyManagement,
    BrakeByWire,
    Differential,
    ClutchAntiStall,
    Gearshift,
    Cooling,
    HighVoltageSafety
};

enum class F1ControlFaultKind {
    SensorBias,
    SensorDropout,
    SensorStuck,
    ActuatorStuck,
    CommunicationLoss,
    ControllerReset,
    CalibrationCorruption,
    TimingOverrun
};

enum class F1ControlRequirementKind {
    OutputRange,
    OutputRate,
    Deadline,
    TemporalResponse,
    SafeState,
    Equivalence,
    Invariant
};

struct F1ControllerBuild {
    std::string name;
    F1ControlDomain domain = F1ControlDomain::ActiveAero;
    std::string binary_sha256;
    std::string calibration_sha256;
    double period_s = 0.001;
    double deadline_s = 0.001;
    void validate() const;
};

struct F1ControlFault {
    F1ControlFaultKind kind = F1ControlFaultKind::SensorBias;
    std::string signal;
    double start_s = 0.0;
    double end_s = 0.0;
    double magnitude = 0.0;
};

struct F1ControlRequirement {
    std::string id;
    F1ControlRequirementKind kind = F1ControlRequirementKind::OutputRange;
    std::string signal;
    double lower = -1.0e300;
    double upper = 1.0e300;
    double tolerance = 0.0;
    double response_time_s = 0.0;
    bool safety_critical = false;
};

struct F1ControlStepOutput {
    std::map<std::string, double> outputs;
    std::map<std::string, double> internal_state;
    double execution_time_s = 0.0;
    bool safe_state = false;
};

using F1ControlFunction = std::function<F1ControlStepOutput(
    double time_s,
    const std::map<std::string, double>& sensors,
    const std::map<std::string, double>& previous_internal_state)>;

using F1ControlPlant = std::function<std::map<std::string, double>(
    double time_step_s,
    const std::map<std::string, double>& state,
    const std::map<std::string, double>& actuator_outputs)>;

struct F1ControlScenario {
    std::string name;
    double duration_s = 1.0;
    std::map<std::string, double> initial_state;
    std::map<std::string, double> initial_sensors;
    std::vector<F1ControlFault> faults;
};

struct F1ControlRequirementResult {
    std::string requirement_id;
    bool passed = false;
    double observed = 0.0;
    double margin = 0.0;
    std::string diagnostic;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1ControlTraceSample {
    double time_s = 0.0;
    std::map<std::string, double> sensors;
    std::map<std::string, double> mil_outputs;
    std::map<std::string, double> sil_outputs;
    bool safe_state = false;
};

struct F1ControlQualificationResult {
    std::vector<F1ControlTraceSample> trace;
    std::vector<F1ControlRequirementResult> requirements;
    std::size_t deadline_misses = 0;
    double worst_execution_time_s = 0.0;
    double maximum_mil_sil_error = 0.0;
    bool safe_state_reached = false;
    bool passed = false;
    std::vector<std::string> events;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1ControlTransition {
    std::string from;
    std::string to;
    std::string guard_signal;
    double guard_minimum = -1.0e300;
    double guard_maximum = 1.0e300;
    bool fault_transition = false;
};

struct F1ControlStateMachine {
    std::vector<std::string> states;
    std::string initial_state;
    std::string safe_state;
    std::vector<F1ControlTransition> transitions;
};

struct F1ControlStateMachineReport {
    bool initial_reachable = false;
    bool safe_state_reachable = false;
    std::vector<std::string> unreachable_states;
    std::vector<std::string> deadlock_states;
    bool passed = false;
    std::string evidence_sha256;
};

class F1ControlSoftwareQualificationLaboratory {
public:
    [[nodiscard]] F1ControlQualificationResult qualify(
        const F1ControllerBuild& build,
        const F1ControlScenario& scenario,
        const std::vector<F1ControlRequirement>& requirements,
        const F1ControlFunction& model_in_loop,
        const F1ControlFunction& software_in_loop,
        const F1ControlPlant& plant) const;
    [[nodiscard]] F1ControlStateMachineReport verify_state_machine(
        const F1ControlStateMachine& machine) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

using FrontierVector3 = std::array<double, 3>;
using FrontierMatrix = std::vector<std::vector<double>>;

// Atomistic, Molecular and Quantum Materials Laboratory
struct AtomisticSpecies {
    std::string id;
    double mass_kg = 1.0e-26;
    double epsilon_j = 1.0e-21;
    double sigma_m = 3.0e-10;
    double charge_c = 0.0;
    double orbital_energy_ev = 0.0;
    double hopping_ev = -1.0;
    void validate() const;
};
struct AtomisticParticle {
    std::string species_id;
    FrontierVector3 position_m{};
    FrontierVector3 velocity_m_s{};
};
struct AtomisticCell {
    FrontierVector3 lengths_m{3.0e-9, 3.0e-9, 3.0e-9};
    bool periodic = true;
    void validate() const;
};
struct AtomisticSimulationOptions {
    double time_step_s = 1.0e-15;
    std::size_t steps = 1000;
    double target_temperature_k = 300.0;
    double thermostat_relaxation_s = 1.0e-13;
    double cutoff_m = 1.2e-9;
    std::size_t radial_distribution_bins = 64;
    std::size_t density_of_states_bins = 64;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};
struct AtomisticQuantumResult {
    std::vector<AtomisticParticle> final_particles;
    std::vector<double> time_s;
    std::vector<double> temperature_k;
    std::vector<double> potential_energy_j;
    std::vector<double> kinetic_energy_j;
    std::vector<double> radial_distribution_r_m;
    std::vector<double> radial_distribution_g;
    std::vector<double> eigenvalues_ev;
    std::vector<double> density_of_states_energy_ev;
    std::vector<double> density_of_states;
    double diffusion_coefficient_m2_s = 0.0;
    double cohesive_energy_j_per_atom = 0.0;
    double bulk_modulus_pa = 0.0;
    double band_gap_ev = 0.0;
    double total_energy_drift_fraction = 0.0;
    bool quantum_solution_converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_histories = false) const;
};
class AtomisticMolecularQuantumLaboratory {
public:
    [[nodiscard]] AtomisticQuantumResult simulate(
        const AtomisticCell&, const std::map<std::string, AtomisticSpecies>&,
        const std::vector<AtomisticParticle>&, const AtomisticSimulationOptions&) const;
};

// Semiconductor TCAD and Device Reliability
struct TcadMaterial {
    double relative_permittivity = 11.7;
    double electron_mobility_m2_v_s = 0.135;
    double hole_mobility_m2_v_s = 0.048;
    double intrinsic_concentration_m3 = 1.0e16;
    double band_gap_ev = 1.12;
    double saturation_velocity_m_s = 1.0e5;
    void validate() const;
};
struct TcadDevice1D {
    double length_m = 1.0e-6;
    std::size_t nodes = 101;
    std::vector<double> donor_density_m3;
    std::vector<double> acceptor_density_m3;
    double area_m2 = 1.0e-10;
    double temperature_k = 300.0;
    void validate() const;
};
struct TcadBiasPoint {
    double left_voltage_v = 0.0;
    double right_voltage_v = 0.0;
};
struct TcadReliabilityStress {
    double duration_s = 3600.0;
    double gate_field_v_m = 1.0e8;
    double drain_field_v_m = 1.0e7;
    double radiation_dose_gy = 0.0;
    double duty_cycle = 1.0;
    void validate() const;
};
struct TcadSolverOptions {
    std::size_t maximum_gummel_iterations = 500;
    double convergence_tolerance = 1.0e-8;
    double damping = 0.35;
    void validate() const;
};
struct TcadBiasResult {
    TcadBiasPoint bias;
    std::vector<double> position_m;
    std::vector<double> electrostatic_potential_v;
    std::vector<double> electron_density_m3;
    std::vector<double> hole_density_m3;
    std::vector<double> electric_field_v_m;
    double terminal_current_a = 0.0;
    double maximum_field_v_m = 0.0;
    double poisson_residual = 0.0;
    bool converged = false;
};
struct TcadReliabilityResult {
    double threshold_shift_v = 0.0;
    double mobility_degradation_fraction = 0.0;
    double oxide_breakdown_probability = 0.0;
    double hot_carrier_damage = 0.0;
    double radiation_failure_probability = 0.0;
    double estimated_remaining_life_s = 0.0;
};
struct SemiconductorTcadResult {
    std::vector<TcadBiasResult> bias_results;
    TcadReliabilityResult reliability;
    bool all_bias_points_converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};
class SemiconductorTcadReliabilityLaboratory {
public:
    [[nodiscard]] SemiconductorTcadResult solve(
        const TcadMaterial&, const TcadDevice1D&, const std::vector<TcadBiasPoint>&,
        const TcadReliabilityStress&, const TcadSolverOptions& = {}) const;
};

// High-Order Adaptive PDE and Mesh Platform
struct AdaptivePdeCell1D {
    double left_m = 0.0;
    double right_m = 0.0;
    unsigned polynomial_order = 2;
    std::vector<double> modal_coefficients;
};
struct AdaptivePdeProblem1D {
    double domain_length_m = 1.0;
    double advection_speed_m_s = 1.0;
    double diffusion_m2_s = 0.0;
    double reaction_rate_s = 0.0;
    double final_time_s = 1.0;
    std::size_t initial_cells = 16;
    unsigned polynomial_order = 2;
    bool periodic = true;
    void validate() const;
};
struct AdaptivePdeOptions {
    double cfl = 0.2;
    double refinement_tolerance = 0.02;
    double coarsening_tolerance = 0.002;
    std::size_t maximum_cells = 4096;
    std::size_t adaptation_interval_steps = 10;
    void validate() const;
};
struct AdaptiveTriangleNode { FrontierVector3 position_m{}; };
struct AdaptiveTriangleElement { std::array<std::size_t, 3> nodes{}; unsigned level = 0; };
struct AdaptiveMesh2D {
    std::vector<AdaptiveTriangleNode> nodes;
    std::vector<AdaptiveTriangleElement> elements;
};
struct AdaptivePdeResult {
    std::vector<AdaptivePdeCell1D> cells;
    AdaptiveMesh2D refined_mesh;
    double final_time_s = 0.0;
    double conserved_mass_initial = 0.0;
    double conserved_mass_final = 0.0;
    double mass_error_fraction = 0.0;
    double maximum_indicator = 0.0;
    std::size_t refinement_events = 0;
    std::size_t coarsening_events = 0;
    bool stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_cells = false) const;
};
class HighOrderAdaptivePdeMeshPlatform {
public:
    [[nodiscard]] AdaptivePdeResult solve_scalar_transport(
        const AdaptivePdeProblem1D&, const AdaptivePdeOptions&,
        const std::vector<double>& initial_cell_averages,
        const AdaptiveMesh2D& seed_mesh = {}) const;
};

// Full 3D Explicit Crash and Human-Body FE
struct ExplicitFeNode3D {
    FrontierVector3 position_m{};
    FrontierVector3 velocity_m_s{};
    double lumped_mass_kg = 0.0;
    bool fixed = false;
    std::string anatomical_region;
    void validate() const;
};
struct ExplicitFeTetrahedron {
    std::array<std::size_t, 4> nodes{};
    double young_modulus_pa = 1.0e9;
    double poisson_ratio = 0.3;
    double density_kg_m3 = 1000.0;
    double yield_stress_pa = 1.0e8;
    double failure_strain = 0.5;
    double hardening_pa = 0.0;
    void validate() const;
};
struct ExplicitFeContactPlane {
    FrontierVector3 point_m{};
    FrontierVector3 normal{1.0, 0.0, 0.0};
    double stiffness_n_m = 1.0e9;
    double damping_n_s_m = 1.0e5;
    double friction = 0.2;
    void validate() const;
};
struct ExplicitCrashOptions {
    double time_step_s = 1.0e-6;
    double duration_s = 0.02;
    double mass_scaling_limit = 5.0;
    std::size_t history_stride = 20;
    void validate() const;
};
struct ExplicitCrashFrame {
    double time_s = 0.0;
    double kinetic_energy_j = 0.0;
    double internal_energy_j = 0.0;
    double contact_energy_j = 0.0;
    double maximum_displacement_m = 0.0;
    std::size_t failed_elements = 0;
};
struct HumanBodyInjuryMetrics {
    double head_injury_criterion = 0.0;
    double brain_rotational_criterion = 0.0;
    double neck_injury_index = 0.0;
    double chest_deflection_m = 0.0;
    double femur_force_n = 0.0;
    std::map<std::string, double> regional_peak_acceleration_g;
};
struct ExplicitCrashHumanResult {
    std::vector<ExplicitFeNode3D> final_nodes;
    std::vector<double> element_damage;
    std::vector<ExplicitCrashFrame> history;
    HumanBodyInjuryMetrics injury;
    double energy_balance_error_fraction = 0.0;
    double maximum_penetration_m = 0.0;
    bool numerically_stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};
class ExplicitCrashHumanBodyFeLaboratory {
public:
    [[nodiscard]] ExplicitCrashHumanResult simulate(
        const std::vector<ExplicitFeNode3D>&, const std::vector<ExplicitFeTetrahedron>&,
        const std::vector<ExplicitFeContactPlane>&, const ExplicitCrashOptions&) const;
};

// Fire, Smoke, Explosion and Suppression
struct FireGrid2D {
    std::size_t width = 32;
    std::size_t height = 24;
    double cell_size_m = 0.1;
    std::vector<double> fuel_kg_m3;
    std::vector<double> temperature_k;
    std::vector<double> oxygen_mass_fraction;
    void validate() const;
};
struct FireMaterialModel {
    double pre_exponential_s = 2.0e5;
    double activation_energy_j_mol = 8.0e4;
    double heat_release_j_kg = 4.0e7;
    double soot_yield = 0.08;
    double smoke_yield = 0.15;
    double ignition_temperature_k = 550.0;
    double thermal_diffusivity_m2_s = 2.0e-5;
    void validate() const;
};
struct SuppressionSource2D {
    std::size_t x = 0;
    std::size_t y = 0;
    double start_time_s = 0.0;
    double flow_kg_s = 0.0;
    double radius_m = 0.5;
    double cooling_j_kg = 2.6e6;
    double oxygen_displacement_kg_per_kg = 0.0;
    void validate() const;
};
struct FireSimulationOptions {
    double time_step_s = 0.001;
    double duration_s = 5.0;
    FrontierVector3 wind_m_s{};
    double enclosure_volume_m3 = 100.0;
    double vent_area_m2 = 1.0;
    void validate() const;
};
struct FireFrame2D {
    double time_s = 0.0;
    double total_heat_release_w = 0.0;
    double maximum_temperature_k = 0.0;
    double smoke_mass_kg = 0.0;
    double toxic_mass_kg = 0.0;
    double overpressure_pa = 0.0;
    double remaining_fuel_kg = 0.0;
};
struct FireSmokeExplosionResult {
    FireGrid2D final_grid;
    std::vector<FireFrame2D> history;
    double peak_heat_release_w = 0.0;
    double peak_temperature_k = 0.0;
    double peak_overpressure_pa = 0.0;
    double total_fuel_consumed_kg = 0.0;
    double total_suppression_agent_kg = 0.0;
    double maximum_smoke_optical_density_m_inv = 0.0;
    bool extinguished = false;
    bool deflagration_risk = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};
class FireSmokeExplosionSuppressionLaboratory {
public:
    [[nodiscard]] FireSmokeExplosionResult simulate(
        const FireGrid2D&, const FireMaterialModel&, const std::vector<SuppressionSource2D>&,
        const FireSimulationOptions&) const;
};

// Full-Field Vibroacoustics and Computational Aeroacoustics
struct VibroacousticStructuralModel {
    FrontierMatrix mass;
    FrontierMatrix damping;
    FrontierMatrix stiffness;
    FrontierMatrix acoustic_coupling;
    void validate() const;
};
struct AcousticCavityModel {
    FrontierMatrix mass;
    FrontierMatrix damping;
    FrontierMatrix stiffness;
    std::vector<double> microphone_projection;
    double reference_pressure_pa = 2.0e-5;
    void validate() const;
};
struct AeroacousticSource {
    FrontierVector3 position_m{};
    FrontierVector3 force_n{};
    double frequency_hz = 100.0;
    double phase_rad = 0.0;
    void validate() const;
};
struct VibroacousticSweepOptions {
    double minimum_frequency_hz = 10.0;
    double maximum_frequency_hz = 2000.0;
    std::size_t points = 128;
    FrontierVector3 observer_position_m{10.0, 0.0, 0.0};
    double sound_speed_m_s = 343.0;
    double air_density_kg_m3 = 1.225;
    void validate() const;
};
struct VibroacousticFrequencyPoint {
    double frequency_hz = 0.0;
    double structural_response_rms = 0.0;
    double cavity_pressure_pa = 0.0;
    double far_field_pressure_pa = 0.0;
    double sound_pressure_level_db = 0.0;
};
struct VibroacousticResult {
    std::vector<double> structural_natural_frequencies_hz;
    std::vector<double> acoustic_natural_frequencies_hz;
    std::vector<VibroacousticFrequencyPoint> sweep;
    double peak_spl_db = 0.0;
    double peak_frequency_hz = 0.0;
    double loudness_sone = 0.0;
    double sharpness_acum = 0.0;
    bool finite_solution = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_sweep = false) const;
};
class FullFieldVibroacousticAeroacousticLaboratory {
public:
    [[nodiscard]] VibroacousticResult solve(
        const VibroacousticStructuralModel&, const AcousticCavityModel&,
        const std::vector<double>& structural_force,
        const std::vector<AeroacousticSource>&,
        const VibroacousticSweepOptions&) const;
};

// Road, Pavement, Bridge and Infrastructure Digital Twin
struct PavementLayerModel {
    double thickness_m = 0.1;
    double elastic_modulus_pa = 3.0e9;
    double poisson_ratio = 0.35;
    double viscosity_pa_s = 1.0e12;
    double fatigue_coefficient = 1.0e-10;
    double rutting_coefficient = 1.0e-12;
    void validate() const;
};
struct MovingAxleLoad {
    double load_n = 40000.0;
    double speed_m_s = 20.0;
    double entry_time_s = 0.0;
    double lateral_offset_m = 0.0;
    void validate() const;
};
struct BridgeBeamModel {
    double span_m = 30.0;
    double mass_per_length_kg_m = 20000.0;
    double flexural_rigidity_nm2 = 5.0e11;
    double damping_ratio = 0.02;
    std::size_t modes = 4;
    void validate() const;
};
struct RoadEnvironmentSample {
    double duration_s = 3600.0;
    double air_temperature_k = 293.15;
    double precipitation_mm_h = 0.0;
    double solar_flux_w_m2 = 0.0;
    double salt_application_kg_m2 = 0.0;
    void validate() const;
};
struct InfrastructureDigitalTwinResult {
    std::vector<double> layer_peak_strain;
    std::vector<double> layer_fatigue_damage;
    double accumulated_rut_depth_m = 0.0;
    double surface_temperature_k = 0.0;
    double water_film_depth_m = 0.0;
    double ice_fraction = 0.0;
    double friction_coefficient = 0.0;
    double bridge_peak_displacement_m = 0.0;
    double bridge_peak_acceleration_m_s2 = 0.0;
    double bridge_fatigue_damage = 0.0;
    bool serviceability_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
class RoadPavementBridgeInfrastructureTwin {
public:
    [[nodiscard]] InfrastructureDigitalTwinResult simulate(
        const std::vector<PavementLayerModel>&, const BridgeBeamModel&,
        const std::vector<MovingAxleLoad>&, const std::vector<RoadEnvironmentSample>&,
        double tire_contact_radius_m = 0.12) const;
};

// Non-Destructive Evaluation and Metrology
struct NdeVoxelField2D {
    std::size_t width = 64;
    std::size_t height = 64;
    double pixel_size_m = 1.0e-3;
    std::vector<double> attenuation_m_inv;
    std::vector<double> acoustic_impedance_rayl;
    void validate() const;
};
struct NdeCtOptions {
    std::size_t projection_angles = 180;
    std::size_t detector_bins = 96;
    double photon_count = 1.0e6;
    double regularization = 0.02;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};
struct NdeUltrasonicOptions {
    double center_frequency_hz = 5.0e6;
    double sound_speed_m_s = 5900.0;
    double attenuation_db_m_hz = 1.0e-7;
    std::size_t scan_lines = 64;
    double detection_threshold = 0.05;
    void validate() const;
};
struct NdeDefectIndication {
    FrontierVector3 location_m{};
    double equivalent_radius_m = 0.0;
    double confidence = 0.0;
    std::string modality;
};
struct NdeMetrologyResult {
    std::vector<double> sinogram;
    std::vector<double> reconstructed_attenuation_m_inv;
    std::vector<double> ultrasonic_bscan;
    std::vector<NdeDefectIndication> indications;
    double reconstruction_rmse = 0.0;
    double dimensional_bias_m = 0.0;
    double probability_of_detection = 0.0;
    double false_call_probability = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_images = false) const;
};
class NonDestructiveEvaluationMetrologyLaboratory {
public:
    [[nodiscard]] NdeMetrologyResult inspect(
        const NdeVoxelField2D&, const NdeCtOptions&, const NdeUltrasonicOptions&) const;
};

// RTL-to-Binary Hardware/Software Co-Verification

enum class RtlLogicOp { Input, Constant, Not, And, Or, Xor, Mux, Add, Less, Register };
struct RtlLogicNode {
    std::string id;
    RtlLogicOp op = RtlLogicOp::Input;
    std::vector<std::string> inputs;
    std::uint64_t constant_value = 0;
    unsigned width_bits = 1;
    void validate() const;
};
enum class BinaryOpcode { LoadInput, LoadImmediate, Move, Not, And, Or, Xor, Add, Less, Select, StoreOutput, BranchIfZero, Halt };
struct BinaryInstructionModel {
    BinaryOpcode opcode = BinaryOpcode::Halt;
    unsigned destination = 0;
    unsigned source_a = 0;
    unsigned source_b = 0;
    std::uint64_t immediate = 0;
    std::size_t branch_target = 0;
};
struct HardwareSoftwareVerificationOptions {
    unsigned input_bits = 4;
    std::size_t bounded_cycles = 8;
    std::size_t maximum_binary_steps = 1000;
    std::size_t random_fault_campaigns = 100;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};
struct HardwareSoftwareCounterexample {
    std::map<std::string, std::uint64_t> inputs;
    std::uint64_t rtl_output = 0;
    std::uint64_t binary_output = 0;
    std::size_t cycle = 0;
};
struct HardwareSoftwareVerificationResult {
    std::size_t exhaustive_cases = 0;
    std::size_t equivalent_cases = 0;
    std::size_t binary_worst_case_steps = 0;
    std::size_t detected_faults = 0;
    std::size_t injected_faults = 0;
    bool combinationally_equivalent = false;
    bool bounded_sequentially_equivalent = false;
    bool memory_safe = false;
    std::vector<HardwareSoftwareCounterexample> counterexamples;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_counterexamples = true) const;
};
class RtlBinaryHardwareSoftwareCoVerification {
public:
    [[nodiscard]] HardwareSoftwareVerificationResult verify(
        const std::vector<RtlLogicNode>&, const std::string& rtl_output_id,
        const std::vector<BinaryInstructionModel>&,
        const HardwareSoftwareVerificationOptions&) const;
};

// Remote Assistance and Teleoperation Control Center
struct TeleoperationNetworkProfile {
    double uplink_latency_mean_s = 0.03;
    double downlink_latency_mean_s = 0.03;
    double jitter_std_s = 0.005;
    double packet_loss_probability = 0.001;
    double bandwidth_mbps = 20.0;
    double handover_probability_s = 0.001;
    double outage_probability_s = 0.0001;
    void validate() const;
};
struct TeleoperationVehicleRequest {
    std::string vehicle_id;
    double request_time_s = 0.0;
    double hazard_level = 0.0;
    double distance_to_obstacle_m = 50.0;
    double speed_m_s = 0.0;
    double requested_steering_rad = 0.0;
    double requested_acceleration_m_s2 = 0.0;
    void validate() const;
};
struct TeleoperationOperatorModel {
    std::string operator_id;
    double base_reaction_time_s = 0.6;
    double service_time_mean_s = 15.0;
    double maximum_workload = 1.0;
    std::size_t maximum_concurrent_vehicles = 1;
    void validate() const;
};
struct TeleoperationControlOptions {
    double simulation_duration_s = 120.0;
    double control_period_s = 0.05;
    double maximum_safe_latency_s = 0.25;
    double minimum_time_to_collision_s = 2.0;
    double maximum_steering_rate_rad_s = 0.5;
    double maximum_acceleration_m_s2 = 3.0;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};
struct TeleoperationEventRecord {
    std::string vehicle_id;
    std::string operator_id;
    double request_time_s = 0.0;
    double assignment_time_s = 0.0;
    double command_arrival_time_s = 0.0;
    double round_trip_latency_s = 0.0;
    double operator_workload = 0.0;
    bool packet_lost = false;
    bool safety_envelope_modified = false;
    bool minimal_risk_maneuver = false;
};
struct TeleoperationControlCenterResult {
    std::vector<TeleoperationEventRecord> events;
    double mean_round_trip_latency_s = 0.0;
    double percentile95_latency_s = 0.0;
    double maximum_queue_delay_s = 0.0;
    double operator_utilization = 0.0;
    std::size_t completed_requests = 0;
    std::size_t minimal_risk_maneuvers = 0;
    std::size_t dropped_or_lost_requests = 0;
    bool service_level_met = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_events = true) const;
};
class RemoteAssistanceTeleoperationControlCenter {
public:
    [[nodiscard]] TeleoperationControlCenterResult simulate(
        const TeleoperationNetworkProfile&, const std::vector<TeleoperationOperatorModel>&,
        const std::vector<TeleoperationVehicleRequest>&, const TeleoperationControlOptions&) const;
};

} // namespace aesim::advanced

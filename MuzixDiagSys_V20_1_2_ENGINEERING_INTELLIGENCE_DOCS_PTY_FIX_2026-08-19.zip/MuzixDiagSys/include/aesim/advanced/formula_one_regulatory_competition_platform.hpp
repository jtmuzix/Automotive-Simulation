#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::f1reg {

class F12026ErsElectrothermalLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1FullFieldCompetitionEngine {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1ChampionshipGovernancePlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1PowerUnitHomologationPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1OperationalRestrictionsPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1RemoteRaceControlFusionCenter {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1PitLaneVisionOfficiatingPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1RegulatoryCaseLawCompiler {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1AccidentReconstructionLaboratory {
public:
    [[nodiscard]] doc::Value reconstruct(const doc::Value& request,
                                         const std::string& working_directory = {}) const;
};

class F1CircuitHomologationPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class FormulaOneRegulatoryCompetitionPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::f1reg

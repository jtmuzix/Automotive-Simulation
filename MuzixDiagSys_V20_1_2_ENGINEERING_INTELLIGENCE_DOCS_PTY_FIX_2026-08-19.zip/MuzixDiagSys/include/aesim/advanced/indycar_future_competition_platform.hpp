#pragma once

#include "aesim/advanced/indycar_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class IndyCarVehicleGeneration { IR18, NextGeneration2028 };

struct IndyCarGenerationDesign {
  std::string design_id;
  IndyCarVehicleGeneration generation = IndyCarVehicleGeneration::IR18;
  double dry_mass_kg = 790.0;
  double wheelbase_m = 3.02;
  double front_track_m = 1.70;
  double rear_track_m = 1.66;
  double cg_height_m = 0.31;
  double front_mass_fraction = 0.43;
  double engine_displacement_l = 2.2;
  double engine_peak_power_w = 522000.0;
  double hybrid_peak_power_w = 111855.0;
  double hybrid_usable_energy_j = 2.5e6;
  double gearbox_mass_kg = 47.0;
  double lift_coefficient = -2.7;
  double drag_coefficient_area_m2 = 0.86;
  double wake_recovery_length_m = 45.0;
  double cockpit_width_m = 0.52;
  double roll_hoop_peak_load_n = 140000.0;
  bool integrated_aeroscreen = false;
  void validate() const;
};

struct IndyCarHomologationLoadCase {
  std::string case_id;
  double applied_energy_j = 0.0;
  double absorbed_energy_j = 0.0;
  double peak_force_n = 0.0;
  double allowable_peak_force_n = 1.0;
  double intrusion_m = 0.0;
  double allowable_intrusion_m = 1.0;
  double peak_deceleration_g = 0.0;
  double allowable_deceleration_g = 1.0;
  bool electrical_isolation_maintained = true;
  void validate() const;
};

struct IndyCarTransitionConstraints {
  std::size_t teams = 12;
  std::size_t cars_per_team = 3;
  std::size_t prototype_cars = 4;
  double chassis_per_month = 10.0;
  double engines_per_month = 12.0;
  double gearboxes_per_month = 14.0;
  double team_training_hours_per_car = 140.0;
  double available_training_hours_per_month = 4200.0;
  double conversion_cost_per_car = 1.8e6;
  double programme_budget = 120.0e6;
  void validate() const;
};

struct IndyCarTransitionMilestone {
  std::size_t month = 0;
  std::size_t cumulative_chassis = 0;
  std::size_t cumulative_engines = 0;
  std::size_t cumulative_gearboxes = 0;
  double cumulative_training_hours = 0.0;
};

struct IndyCarNextGenerationResult {
  bool homologated = false;
  bool transition_feasible = false;
  double mass_reduction_kg = 0.0;
  double estimated_road_lap_time_delta_s = 0.0;
  double estimated_speedway_lap_time_delta_s = 0.0;
  double following_car_downforce_loss_change = 0.0;
  double minimum_homologation_margin = 0.0;
  std::size_t transition_months = 0;
  double transition_cost = 0.0;
  std::vector<IndyCarTransitionMilestone> schedule;
  std::vector<std::string> violations;
  std::string evidence_sha256;
};

class IndyCarNextGenerationLaboratory {
 public:
  IndyCarNextGenerationResult evaluate(const IndyCarGenerationDesign& current,
                                       const IndyCarGenerationDesign& candidate,
                                       const std::vector<IndyCarHomologationLoadCase>& load_cases,
                                       const IndyCarTransitionConstraints& constraints) const;
};

struct IndyCarCharterRecord {
  std::string charter_id;
  std::string entry_id;
  std::string owner;
  bool active = true;
  bool leaders_circle_eligible = true;
  double acquisition_cost = 0.0;
  double annual_amortization = 0.0;
  void validate() const;
};

struct IndyCarEntrantEconomics {
  std::string entry_id;
  std::string driver_id;
  std::string manufacturer;
  double season_budget = 12.0e6;
  double fixed_cost = 8.0e6;
  double crash_cost_rate = 400000.0;
  double sponsor_value_per_point = 45000.0;
  double leaders_circle_payment = 1.0e6;
  double risk_tolerance = 0.5;
  bool chartered = true;
  void validate() const;
};

struct IndyCarChampionshipEvent {
  std::string event_id;
  bool indianapolis_500 = false;
  double maximum_driver_points = 50.0;
  double baseline_expected_points = 18.0;
  double prize_money = 250000.0;
  double development_cost = 0.0;
  double base_crash_probability = 0.05;
  double manufacturer_points_factor = 1.0;
  void validate() const;
};

struct IndyCarEventEconomicDecision {
  std::string event_id;
  double risk_level = 0.0;
  double expected_points = 0.0;
  double expected_variable_cost = 0.0;
  double expected_net_value = 0.0;
};

struct IndyCarEntrySeasonResult {
  std::string entry_id;
  double driver_points = 0.0;
  double entrant_points = 0.0;
  double manufacturer_points = 0.0;
  double expected_revenue = 0.0;
  double expected_cost = 0.0;
  double expected_profit = 0.0;
  bool leaders_circle_qualified = false;
  std::vector<IndyCarEventEconomicDecision> decisions;
};

struct IndyCarChampionshipEconomicsResult {
  bool feasible = false;
  std::vector<IndyCarEntrySeasonResult> entries;
  std::map<std::string, double> manufacturer_points;
  std::vector<std::string> leaders_circle_entries;
  double total_charter_value = 0.0;
  double total_expected_profit = 0.0;
  std::string evidence_sha256;
};

class IndyCarChampionshipEconomicsPlatform {
 public:
  IndyCarChampionshipEconomicsResult optimize(const std::vector<IndyCarEntrantEconomics>& entrants,
                                               const std::vector<IndyCarCharterRecord>& charters,
                                               const std::vector<IndyCarChampionshipEvent>& events,
                                               std::size_t leaders_circle_places = 22) const;
};

enum class IndyCarTimingLoop { StartFinish, Sector1, Sector2, PitEntry, PitExit };

enum class IndyCarStewardIncidentType {
  AvoidableContact,
  Blocking,
  RestartViolation,
  PitLaneViolation,
  LocalYellowViolation,
  QualificationInterference,
  UnsafeRelease
};

enum class IndyCarPenaltyType { None, Warning, Time, Position, DriveThrough, StopAndHold, Disqualification };

struct IndyCarTimingHit {
  std::string car_id;
  IndyCarTimingLoop loop = IndyCarTimingLoop::StartFinish;
  double timestamp_s = 0.0;
  std::uint64_t sequence = 0;
  double signal_quality = 1.0;
  void validate() const;
};

struct IndyCarPhotoFinishObservation {
  std::string car_id;
  double crossing_timestamp_s = 0.0;
  double nose_position_px = 0.0;
  double calibration_uncertainty_s = 0.0;
  double confidence = 1.0;
  void validate() const;
};

struct IndyCarStewardIncident {
  std::string incident_id;
  IndyCarStewardIncidentType type = IndyCarStewardIncidentType::AvoidableContact;
  std::string subject_car;
  std::string affected_car;
  double timestamp_s = 0.0;
  double severity = 0.0;
  double responsibility = 0.0;
  bool mitigating_circumstances = false;
  std::string evidence_reference;
  void validate() const;
};

struct IndyCarStewardDecision {
  std::string incident_id;
  std::string car_id;
  IndyCarPenaltyType penalty = IndyCarPenaltyType::None;
  double time_penalty_s = 0.0;
  std::size_t position_penalty = 0;
  std::string rationale;
};

struct IndyCarOfficialClassification {
  std::string car_id;
  std::size_t completed_laps = 0;
  double last_crossing_s = 0.0;
  double adjusted_time_s = 0.0;
  std::size_t position = 0;
  bool classified = true;
};

struct IndyCarTimingStewardingResult {
  bool timing_integrity = false;
  bool photo_finish_used = false;
  std::string winner_car_id;
  std::size_t duplicate_hits = 0;
  std::size_t rejected_hits = 0;
  std::vector<IndyCarStewardDecision> decisions;
  std::vector<IndyCarOfficialClassification> classification;
  std::string evidence_sha256;
};

class IndyCarOfficialTimingStewardingEngine {
 public:
  IndyCarTimingStewardingResult adjudicate(const std::vector<IndyCarTimingHit>& hits,
                                           const std::vector<IndyCarPhotoFinishObservation>& photo_finish,
                                           const std::vector<IndyCarStewardIncident>& incidents,
                                           double duplicate_window_s = 0.002,
                                           double photo_finish_threshold_s = 0.01) const;
};

struct IndyCarTyreStructuralLayer {
  std::string name;
  double thickness_m = 0.001;
  double elastic_modulus_pa = 1.0e7;
  double density_kg_m3 = 1000.0;
  double thermal_conductivity_w_m_k = 0.2;
  double heat_capacity_j_kg_k = 1500.0;
  double fatigue_strength_pa = 1.0e6;
  double loss_factor = 0.1;
  void validate() const;
};

struct IndyCarStructuralTyreConfiguration {
  std::string specification_id;
  double unloaded_radius_m = 0.33;
  double width_m = 0.36;
  double internal_volume_m3 = 0.025;
  double inflation_pressure_kpa = 170.0;
  double gas_temperature_k = 295.0;
  double belt_angle_rad = 0.35;
  double camber_rad = -0.03;
  std::vector<IndyCarTyreStructuralLayer> layers;
  void validate() const;
};

struct IndyCarTyreStructuralSegment {
  double duration_s = 1.0;
  double speed_m_s = 70.0;
  double vertical_load_n = 4500.0;
  double lateral_force_n = 3000.0;
  double longitudinal_force_n = 0.0;
  double track_temperature_k = 315.0;
  double air_temperature_k = 300.0;
  double seam_impact_energy_j = 0.0;
  double wake_cooling_fraction = 1.0;
  void validate() const;
};

struct IndyCarTyreStructuralState {
  double time_s = 0.0;
  double pressure_kpa = 0.0;
  double tread_temperature_k = 0.0;
  double carcass_temperature_k = 0.0;
  double shoulder_temperature_k = 0.0;
  double belt_edge_stress_pa = 0.0;
  double radial_deflection_m = 0.0;
  double cumulative_fatigue_damage = 0.0;
  double separation_probability = 0.0;
};

struct IndyCarStructuralTyreResult {
  bool safe = false;
  double maximum_pressure_kpa = 0.0;
  double maximum_shoulder_temperature_k = 0.0;
  double maximum_belt_edge_stress_pa = 0.0;
  double cumulative_fatigue_damage = 0.0;
  double belt_separation_probability = 0.0;
  double recommended_minimum_cold_pressure_kpa = 0.0;
  double maximum_safe_stint_s = 0.0;
  std::vector<IndyCarTyreStructuralState> history;
  std::string evidence_sha256;
};

class IndyCarStructuralTyreLaboratory {
 public:
  IndyCarStructuralTyreResult simulate(const IndyCarStructuralTyreConfiguration& configuration,
                                       const std::vector<IndyCarTyreStructuralSegment>& segments,
                                       double time_step_s = 0.02) const;
};

struct IndyCarFuelCellConfiguration {
  double capacity_l = 70.03;
  double length_m = 0.75;
  double width_m = 0.48;
  double height_m = 0.28;
  double collector_capacity_l = 3.0;
  double collector_initial_l = 2.5;
  double baffle_time_constant_s = 0.45;
  double lift_pump_flow_l_s = 0.12;
  double high_pressure_pump_flow_l_s = 0.09;
  double minimum_supply_pressure_kpa = 250.0;
  double nominal_supply_pressure_kpa = 500.0;
  double vehicle_reference_mass_kg = 790.0;
  double vehicle_reference_yaw_inertia_kg_m2 = 850.0;
  void validate() const;
};

struct IndyCarFuelCellSegment {
  double duration_s = 1.0;
  double longitudinal_acceleration_m_s2 = 0.0;
  double lateral_acceleration_m_s2 = 0.0;
  double vertical_acceleration_m_s2 = 9.80665;
  double engine_consumption_l_s = 0.04;
  double fuel_temperature_k = 300.0;
  bool lift_pump_available = true;
  bool high_pressure_pump_available = true;
  void validate() const;
};

struct IndyCarFuelCellState {
  double time_s = 0.0;
  double main_fuel_l = 0.0;
  double collector_fuel_l = 0.0;
  double fuel_centroid_x_m = 0.0;
  double fuel_centroid_y_m = 0.0;
  double pickup_coverage = 0.0;
  double supply_pressure_kpa = 0.0;
  double vehicle_cg_x_shift_m = 0.0;
  double vehicle_cg_y_shift_m = 0.0;
  double vehicle_yaw_inertia_kg_m2 = 0.0;
  bool starvation = false;
};

struct IndyCarFuelCellResult {
  bool supply_qualified = false;
  double consumed_fuel_l = 0.0;
  double unusable_fuel_l = 0.0;
  double minimum_supply_pressure_kpa = 0.0;
  double maximum_cg_shift_m = 0.0;
  double starvation_probability = 0.0;
  double recommended_reserve_l = 0.0;
  std::vector<IndyCarFuelCellState> history;
  std::string evidence_sha256;
};

class IndyCarFuelCellSloshLaboratory {
 public:
  IndyCarFuelCellResult simulate(const IndyCarFuelCellConfiguration& configuration,
                                 double initial_main_fuel_l,
                                 const std::vector<IndyCarFuelCellSegment>& segments,
                                 double time_step_s = 0.01) const;
};

enum class IndyCarSafetyResourceType { SafetyTruck, FireUnit, Ambulance, Extrication, Recovery, BarrierCrew, MedicalHelicopter };

struct IndyCarSafetyResource {
  std::string resource_id;
  IndyCarSafetyResourceType type = IndyCarSafetyResourceType::SafetyTruck;
  double distance_to_incident_m = 0.0;
  double travel_speed_m_s = 10.0;
  double mobilization_s = 5.0;
  double setup_s = 5.0;
  double capability = 1.0;
  bool available = true;
  void validate() const;
};

struct IndyCarTracksideIncident {
  std::string incident_id;
  double track_blockage_fraction = 0.0;
  double fire_severity = 0.0;
  double fuel_spill_l = 0.0;
  double hybrid_residual_energy_j = 0.0;
  double driver_injury_severity = 0.0;
  double entrapment_severity = 0.0;
  double debris_area_m2 = 0.0;
  double barrier_damage_m = 0.0;
  double surface_damage_m2 = 0.0;
  bool aeroscreen_access_obstructed = false;
  void validate() const;
};

struct IndyCarSafetyAction {
  std::string action;
  std::string resource_id;
  double start_time_s = 0.0;
  double completion_time_s = 0.0;
};

struct IndyCarTracksideSafetyResult {
  bool driver_stabilized = false;
  bool track_restored = false;
  bool restart_ready = false;
  bool red_flag_required = false;
  double first_response_s = 0.0;
  double extraction_complete_s = 0.0;
  double medical_clearance_s = 0.0;
  double track_restoration_s = 0.0;
  double earliest_restart_s = 0.0;
  double residual_risk = 1.0;
  std::vector<IndyCarSafetyAction> actions;
  std::vector<std::string> deficiencies;
  std::string evidence_sha256;
};

class IndyCarTracksideSafetyTwin {
 public:
  IndyCarTracksideSafetyResult respond(const IndyCarTracksideIncident& incident,
                                       const std::vector<IndyCarSafetyResource>& resources) const;
};

enum class IndyCarRuleOperator { Minimum, Maximum, Equal, Prohibited, Required };
enum class IndyCarRuleSeverity { Advisory, Sporting, Technical };

struct IndyCarRuleSourceDocument {
  std::string document_id;
  std::string effective_date;
  int priority = 0;
  std::string text;
  void validate() const;
};

struct IndyCarCompiledRule {
  std::string rule_id;
  std::string scope;
  std::string parameter;
  IndyCarRuleOperator operation = IndyCarRuleOperator::Equal;
  double value = 0.0;
  std::string unit;
  IndyCarRuleSeverity severity = IndyCarRuleSeverity::Technical;
  std::string effective_date;
  std::string source_document;
  bool active = true;
};

struct IndyCarRuleChange {
  std::string rule_id;
  std::string change_type;
  std::string description;
  std::vector<std::string> affected_modules;
};

struct IndyCarRuleCompilationResult {
  bool successful = false;
  std::vector<IndyCarCompiledRule> rules;
  std::vector<IndyCarRuleChange> changes;
  std::vector<std::string> diagnostics;
  std::string generated_profile_id;
  std::string evidence_sha256;
};

class IndyCarIRISRuleCompiler {
 public:
  IndyCarRuleCompilationResult compile(const std::vector<IndyCarRuleSourceDocument>& documents,
                                       const std::vector<IndyCarCompiledRule>& prior_rules = {}) const;
};

struct IndyCarSuspensionGeometry {
  double wheelbase_m = 3.02;
  double front_track_m = 1.70;
  double rear_track_m = 1.66;
  double front_motion_ratio = 0.82;
  double rear_motion_ratio = 0.88;
  double front_camber_gain_rad_m = -1.1;
  double rear_camber_gain_rad_m = -0.8;
  double front_toe_gain_rad_m = 0.20;
  double rear_toe_gain_rad_m = 0.12;
  double front_bump_steer_rad_m = 0.08;
  double steering_ratio = 12.0;
  double front_spring_rate_n_m = 180000.0;
  double rear_spring_rate_n_m = 160000.0;
  double chassis_heave_mass_kg = 790.0;
  double pitch_inertia_kg_m2 = 950.0;
  void validate() const;
};

struct IndyCarDamperModel {
  std::string damper_id;
  std::vector<double> velocity_m_s;
  std::vector<double> compression_force_n;
  std::vector<double> rebound_force_n;
  double gas_force_n = 250.0;
  double seal_friction_n = 40.0;
  double temperature_k = 300.0;
  double cavitation_pressure_kpa = 80.0;
  void validate() const;
};

struct IndyCarSevenPostSample {
  double time_s = 0.0;
  double left_front_road_m = 0.0;
  double right_front_road_m = 0.0;
  double left_rear_road_m = 0.0;
  double right_rear_road_m = 0.0;
  double front_aero_force_n = 0.0;
  double rear_aero_force_n = 0.0;
  double steering_rack_displacement_m = 0.0;
  double measured_heave_m = 0.0;
  double measured_pitch_rad = 0.0;
  void validate() const;
};

struct IndyCarKinematicState {
  double time_s = 0.0;
  double heave_m = 0.0;
  double pitch_rad = 0.0;
  double front_camber_rad = 0.0;
  double rear_camber_rad = 0.0;
  double front_toe_rad = 0.0;
  double rear_toe_rad = 0.0;
  double steering_torque_n_m = 0.0;
  double front_damper_force_n = 0.0;
  double rear_damper_force_n = 0.0;
};

struct IndyCarSuspensionCorrelationResult {
  bool stable = false;
  double heave_rmse_m = 0.0;
  double pitch_rmse_rad = 0.0;
  double peak_steering_torque_n_m = 0.0;
  double maximum_damper_force_n = 0.0;
  double identified_front_compliance = 0.0;
  double identified_rear_compliance = 0.0;
  std::vector<IndyCarKinematicState> history;
  std::string evidence_sha256;
};

class IndyCarSuspensionRigLaboratory {
 public:
  IndyCarSuspensionCorrelationResult simulate(const IndyCarSuspensionGeometry& geometry,
                                              const IndyCarDamperModel& front_damper,
                                              const IndyCarDamperModel& rear_damper,
                                              const std::vector<IndyCarSevenPostSample>& samples) const;
};

struct IndyCarTeamCarState {
  std::string car_id;
  std::string driver_id;
  double baseline_pace_s = 60.0;
  double fuel_l = 50.0;
  double tyre_life_laps = 30.0;
  double hybrid_energy_j = 2.0e6;
  double push_to_pass_s = 100.0;
  double damage_risk = 0.02;
  double championship_weight = 1.0;
  void validate() const;
};

struct IndyCarStrategyCandidate {
  std::string strategy_id;
  std::vector<std::size_t> pit_laps;
  double fuel_save_fraction = 0.0;
  double aggression = 0.5;
  double hybrid_reserve_fraction = 0.2;
  double push_to_pass_reserve_s = 20.0;
  double expected_pit_loss_s = 25.0;
  void validate() const;
};

struct IndyCarRaceScenario {
  std::size_t race_laps = 100;
  double caution_probability_per_lap = 0.03;
  double traffic_density = 0.5;
  double tow_benefit_s_per_lap = 0.10;
  double crash_cost = 500000.0;
  double pit_box_minimum_separation_s = 4.0;
  std::size_t monte_carlo_samples = 256;
  std::uint64_t random_seed = 1;
  void validate() const;
};

struct IndyCarSelectedStrategy {
  std::string car_id;
  std::string strategy_id;
  double expected_finish_time_s = 0.0;
  double expected_points = 0.0;
  double crash_probability = 0.0;
};

struct IndyCarTeamStrategyResult {
  bool feasible = false;
  double expected_team_points = 0.0;
  double expected_team_cost = 0.0;
  double win_probability = 0.0;
  double double_stack_probability = 0.0;
  std::vector<IndyCarSelectedStrategy> selections;
  std::string evidence_sha256;
};

class IndyCarMultiCarStrategyEngine {
 public:
  IndyCarTeamStrategyResult optimize(const std::vector<IndyCarTeamCarState>& cars,
                                     const std::map<std::string, std::vector<IndyCarStrategyCandidate>>& candidates,
                                     const IndyCarRaceScenario& scenario) const;
};

enum class IndyCarAeroTestType { WindTunnel, StraightLine };

struct IndyCarAeroVariant {
  std::string variant_id;
  IndyCarCircuitClass circuit = IndyCarCircuitClass::RoadStreet;
  double predicted_lift_coefficient = -2.7;
  double predicted_drag_area_m2 = 0.86;
  double predicted_front_balance = 0.43;
  double uncertainty = 0.08;
  bool approved_parts_only = true;
  void validate() const;
};

struct IndyCarAeroTestOpportunity {
  std::string test_id;
  IndyCarAeroTestType type = IndyCarAeroTestType::WindTunnel;
  std::string variant_id;
  double test_day_fraction = 1.0;
  double wind_on_hours = 0.0;
  double cost = 0.0;
  double reynolds_scale = 1.0;
  double blockage_fraction = 0.0;
  double measurement_uncertainty = 0.02;
  double expected_information_gain = 0.0;
  bool approved = true;
  bool blackout = false;
  void validate() const;
};

struct IndyCarAeroDevelopmentConstraints {
  double maximum_test_day_equivalents = 3.0;
  double maximum_wind_on_hours = 12.0;
  double maximum_cost = 1.0e6;
  std::size_t maximum_tests = 6;
  void validate() const;
};

struct IndyCarAeroDevelopmentDecision {
  std::string test_id;
  std::string variant_id;
  double corrected_lift_coefficient = 0.0;
  double corrected_drag_area_m2 = 0.0;
  double corrected_front_balance = 0.0;
  double posterior_uncertainty = 0.0;
};

struct IndyCarAeroDevelopmentResult {
  bool feasible = false;
  double total_test_days = 0.0;
  double total_wind_on_hours = 0.0;
  double total_cost = 0.0;
  double total_information_gain = 0.0;
  std::string recommended_variant_id;
  std::vector<IndyCarAeroDevelopmentDecision> selected_tests;
  std::string evidence_sha256;
};

class IndyCarAeroDevelopmentLaboratory {
 public:
  IndyCarAeroDevelopmentResult optimize(const std::vector<IndyCarAeroVariant>& variants,
                                        const std::vector<IndyCarAeroTestOpportunity>& opportunities,
                                        const IndyCarAeroDevelopmentConstraints& constraints) const;
};

}  // namespace aesim::advanced

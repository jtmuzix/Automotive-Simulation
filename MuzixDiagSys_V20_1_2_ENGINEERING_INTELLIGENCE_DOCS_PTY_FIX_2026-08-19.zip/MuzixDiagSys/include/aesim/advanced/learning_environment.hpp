#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <random>
#include <string>
#include <vector>

namespace aesim::advanced {

struct VehicleObservation {
    double x_m = 0.0;
    double y_m = 0.0;
    double heading_rad = 0.0;
    double speed_m_s = 0.0;
    double yaw_rate_rad_s = 0.0;
    double lateral_error_m = 0.0;
    double heading_error_rad = 0.0;
    double target_speed_m_s = 20.0;
    double nearest_vehicle_distance_m = 1000.0;
    double elapsed_s = 0.0;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static VehicleObservation from_document(const doc::Value& value);
};

struct VehicleAction {
    double steering = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static VehicleAction from_document(const doc::Value& value);
};

struct EnvironmentConfig {
    std::size_t environments = 1;
    std::size_t agents_per_environment = 1;
    double dt_s = 0.05;
    double horizon_s = 60.0;
    double target_speed_m_s = 20.0;
    double lane_half_width_m = 1.8;
    double wheelbase_m = 2.75;
    double maximum_steering_rad = 0.55;
    double maximum_acceleration_m_s2 = 4.0;
    double maximum_braking_m_s2 = 9.0;
    double drag_coefficient = 0.012;
    double collision_distance_m = 2.5;
    std::uint64_t seed = 1;

    [[nodiscard]] static EnvironmentConfig from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct EnvironmentStepResult {
    std::vector<VehicleObservation> observations;
    std::vector<double> rewards;
    std::vector<bool> terminated;
    std::vector<bool> truncated;
    std::vector<std::string> reasons;
    [[nodiscard]] doc::Value to_document() const;
};

class VectorVehicleEnvironment {
public:
    explicit VectorVehicleEnvironment(EnvironmentConfig config = {});
    [[nodiscard]] EnvironmentStepResult reset(std::optional<std::uint64_t> seed = std::nullopt);
    [[nodiscard]] EnvironmentStepResult step(const std::vector<VehicleAction>& actions);
    [[nodiscard]] const std::vector<VehicleObservation>& observations() const noexcept { return observations_; }
    [[nodiscard]] const EnvironmentConfig& config() const noexcept { return config_; }
    [[nodiscard]] doc::Value snapshot() const;
    void restore(const doc::Value& snapshot);

private:
    EnvironmentConfig config_;
    std::vector<VehicleObservation> observations_;
    std::vector<bool> terminal_;
    std::vector<std::string> terminal_reason_;
    std::mt19937_64 random_;
    std::size_t index(std::size_t environment, std::size_t agent) const noexcept;
    void update_nearest_distances();
};

} // namespace aesim::advanced

#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::operational {

using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;

// ---------------------------------------------------------------------------
// Live digital-twin streaming and semantic telemetry fabric
// ---------------------------------------------------------------------------

enum class SignalQuality { Good, Suspect, Invalid };
enum class ClockQuality { Synchronized, Holdover, Unsynchronized };

struct SemanticSignal {
  std::string id;
  std::string unit;
  std::string dimension;
  std::string frame;
  double minimum = -1.0e300;
  double maximum = 1.0e300;
  double nominal_period_s = 0.0;
  bool safety_relevant = false;
  std::string privacy_classification;
  std::uint32_t schema_version = 1;
};

struct TelemetryEvent {
  std::string signal_id;
  std::string source_id;
  std::uint64_t sequence = 0;
  double source_time_s = 0.0;
  double reception_time_s = 0.0;
  double value = 0.0;
  SignalQuality quality = SignalQuality::Good;
  ClockQuality clock_quality = ClockQuality::Synchronized;
};

struct StreamPolicy {
  double allowed_lateness_s = 0.25;
  double gap_factor = 4.0;
  std::size_t maximum_buffered_events = 100000;
  bool reject_out_of_range = true;
};

struct StreamStatistics {
  std::uint64_t accepted = 0;
  std::uint64_t duplicates = 0;
  std::uint64_t late = 0;
  std::uint64_t gaps = 0;
  std::uint64_t invalid = 0;
  double watermark_s = 0.0;
  std::string evidence_digest;
};

struct TwinEstimate {
  std::string twin_id;
  Vector state;
  Matrix covariance;
  double event_time_s = 0.0;
  double normalized_innovation = 0.0;
  bool diverged = false;
  std::string evidence_digest;
};

struct LinearTwinBinding {
  std::string twin_id;
  std::vector<std::string> signal_ids;
  Matrix observation;
  Matrix observation_covariance;
  Vector initial_state;
  Matrix initial_covariance;
  double divergence_threshold = 9.0;
};

class LiveDigitalTwinTelemetryFabric {
 public:
  explicit LiveDigitalTwinTelemetryFabric(StreamPolicy policy = {});
  void register_signal(const SemanticSignal& signal);
  void bind_twin(const LinearTwinBinding& binding);
  bool ingest(const TelemetryEvent& event);
  std::vector<TelemetryEvent> drain_ready();
  TwinEstimate assimilate(const std::string& twin_id,
                          const std::vector<TelemetryEvent>& observations);
  std::vector<TelemetryEvent> replay(double begin_s, double end_s) const;
  StreamStatistics statistics() const;

 private:
  StreamPolicy policy_;
  std::map<std::string, SemanticSignal> signals_;
  std::map<std::string, LinearTwinBinding> bindings_;
  std::map<std::string, TwinEstimate> twins_;
  std::vector<TelemetryEvent> pending_;
  std::vector<TelemetryEvent> history_;
  std::set<std::pair<std::string, std::uint64_t>> seen_;
  std::map<std::string, std::uint64_t> last_sequence_;
  double maximum_source_time_s_ = 0.0;
  StreamStatistics statistics_;
};

// ---------------------------------------------------------------------------
// Formal refinement, symbolic execution, and binary/RTL equivalence
// ---------------------------------------------------------------------------

enum class FormalOpcode {
  LoadInput,
  LoadConstant,
  Add,
  Subtract,
  Multiply,
  Saturate,
  CompareGreater,
  Select,
  StoreOutput
};

struct FormalInstruction {
  FormalOpcode opcode = FormalOpcode::LoadConstant;
  std::int64_t immediate = 0;
  std::size_t argument_a = 0;
  std::size_t argument_b = 0;
  std::size_t argument_c = 0;
};

struct FormalProgram {
  std::string id;
  std::size_t input_count = 0;
  std::size_t output_count = 0;
  std::vector<FormalInstruction> instructions;
};

struct InputDomain {
  std::vector<std::int64_t> minimum;
  std::vector<std::int64_t> maximum;
};

struct SafetyProperty {
  std::size_t output_index = 0;
  std::int64_t minimum = 0;
  std::int64_t maximum = 0;
};

struct FormalCounterexample {
  std::vector<std::int64_t> inputs;
  std::vector<std::int64_t> reference_outputs;
  std::vector<std::int64_t> implementation_outputs;
  std::string reason;
};

struct RefinementCertificate {
  bool source_binary_equivalent = false;
  bool binary_rtl_equivalent = false;
  bool properties_hold = false;
  bool overflow_free = false;
  std::uint64_t explored_inputs = 0;
  std::vector<FormalCounterexample> counterexamples;
  std::string reference_digest;
  std::string binary_digest;
  std::string rtl_digest;
  std::string certificate_digest;
};

class FormalRefinementEquivalencePlatform {
 public:
  std::vector<std::int64_t> execute(const FormalProgram& program,
                                    const std::vector<std::int64_t>& inputs) const;
  RefinementCertificate verify(const FormalProgram& reference,
                               const FormalProgram& binary_model,
                               const FormalProgram& rtl_model,
                               const InputDomain& domain,
                               const std::vector<SafetyProperty>& properties,
                               std::uint64_t maximum_exhaustive_inputs = 1000000) const;
};

// ---------------------------------------------------------------------------
// Electromagnetic machine and passive-magnetics finite-element laboratory
// ---------------------------------------------------------------------------

struct MagneticMaterial {
  std::string id;
  double relative_permeability = 1.0;
  double saturation_t = 2.0;
  double conductivity_s_m = 0.0;
  double core_loss_coefficient = 0.0;
  double core_loss_exponent = 2.0;
};

struct MagneticNode2D { double x_m = 0.0; double y_m = 0.0; };

struct MagneticElement2D {
  std::size_t n0 = 0;
  std::size_t n1 = 0;
  std::size_t n2 = 0;
  std::string material_id;
  double source_current_density_a_m2 = 0.0;
  double permanent_magnet_coercivity_a_m = 0.0;
  double magnetization_angle_rad = 0.0;
};

struct MagneticBoundary {
  std::size_t node = 0;
  double vector_potential_wb_m = 0.0;
};

struct MagneticMesh2D {
  std::vector<MagneticNode2D> nodes;
  std::vector<MagneticElement2D> elements;
  std::vector<MagneticBoundary> boundaries;
  std::vector<MagneticMaterial> materials;
  double stack_length_m = 0.1;
};

struct MagneticFieldResult {
  Vector vector_potential_wb_m;
  Vector flux_density_t;
  double magnetic_energy_j = 0.0;
  double flux_linkage_wb_turn = 0.0;
  double inductance_h = 0.0;
  double torque_nm = 0.0;
  double copper_loss_w = 0.0;
  double core_loss_w = 0.0;
  double maximum_flux_density_t = 0.0;
  std::size_t nonlinear_iterations = 0;
  bool converged = false;
  std::string evidence_digest;
};

struct WindingExcitation {
  double current_a = 0.0;
  double turns = 1.0;
  double resistance_ohm = 0.0;
  double electrical_frequency_hz = 0.0;
  double rotor_angle_rad = 0.0;
};

class ElectromagneticMachineFiniteElementLaboratory {
 public:
  MagneticFieldResult solve(const MagneticMesh2D& mesh,
                            const WindingExcitation& excitation,
                            std::size_t maximum_iterations = 40,
                            double tolerance = 1.0e-8) const;
};

// ---------------------------------------------------------------------------
// Whole-fleet OTA configuration compatibility and rollback qualification
// ---------------------------------------------------------------------------

struct SoftwarePackage {
  std::string id;
  std::string version;
  std::set<std::string> provides;
  std::set<std::string> requires_capabilities;
  std::set<std::string> conflicts;
  std::vector<std::string> dependencies;
  std::size_t size_mb = 0;
  std::uint64_t minimum_storage_mb = 0;
  bool safety_critical = false;
  bool anti_rollback = false;
};

struct VehicleConfiguration {
  std::string vehicle_id;
  std::set<std::string> capabilities;
  std::map<std::string, std::string> installed_versions;
  std::uint64_t free_storage_mb = 0;
  bool dual_bank = true;
  double battery_soc = 1.0;
};

struct UpdateCampaign {
  std::vector<SoftwarePackage> packages;
  double minimum_soc = 0.3;
  double bandwidth_mbps = 20.0;
  bool require_rollback = true;
};

struct VehicleUpdatePlan {
  std::string vehicle_id;
  std::vector<std::string> installation_order;
  std::vector<std::string> rollback_order;
  double download_time_s = 0.0;
  bool compatible = false;
  bool rollback_qualified = false;
  std::vector<std::string> reasons;
};

struct FleetUpdateQualification {
  std::vector<VehicleUpdatePlan> vehicles;
  std::size_t compatible_vehicles = 0;
  std::size_t incompatible_vehicles = 0;
  bool campaign_qualified = false;
  std::string evidence_digest;
};

class WholeFleetOtaQualificationEngine {
 public:
  FleetUpdateQualification qualify(const std::vector<VehicleConfiguration>& fleet,
                                    const UpdateCampaign& campaign) const;
};

// ---------------------------------------------------------------------------
// Cloud-edge SDV service mesh and mixed-criticality runtime
// ---------------------------------------------------------------------------

enum class CriticalityLevel { QualityManaged, Mission, Safety };

struct ComputeNode {
  std::string id;
  double cpu_capacity = 1.0;
  double memory_mb = 0.0;
  double accelerator_tops = 0.0;
  double thermal_limit_w = 0.0;
  std::set<std::string> capabilities;
  bool available = true;
};

struct ServiceDefinition {
  std::string id;
  double cpu_demand = 0.0;
  double memory_mb = 0.0;
  double accelerator_tops = 0.0;
  double deadline_ms = 1000.0;
  double period_ms = 1000.0;
  CriticalityLevel criticality = CriticalityLevel::QualityManaged;
  std::set<std::string> required_capabilities;
  std::size_t replicas = 1;
  std::vector<std::string> dependencies;
  bool stateful = false;
};

struct ServiceLink {
  std::string from;
  std::string to;
  double latency_ms = 0.0;
  double bandwidth_mbps = 0.0;
  bool encrypted = true;
};

struct ServicePlacement {
  std::string service_id;
  std::size_t replica = 0;
  std::string node_id;
  double utilization = 0.0;
  double response_time_ms = 0.0;
  bool deadline_met = false;
};

struct ServiceMeshReport {
  std::vector<ServicePlacement> placements;
  std::vector<std::string> unplaced_services;
  std::vector<std::string> degraded_services;
  double worst_response_time_ms = 0.0;
  bool safety_services_available = false;
  bool freedom_from_interference = false;
  std::string evidence_digest;
};

class MixedCriticalityServiceMeshRuntime {
 public:
  ServiceMeshReport deploy(const std::vector<ComputeNode>& nodes,
                           const std::vector<ServiceDefinition>& services,
                           const std::vector<ServiceLink>& links) const;
  ServiceMeshReport failover(const std::vector<ComputeNode>& nodes,
                             const std::vector<ServiceDefinition>& services,
                             const std::vector<ServiceLink>& links,
                             const std::set<std::string>& failed_nodes) const;
};

// ---------------------------------------------------------------------------
// Space-weather, radiation, and single-event-effect reliability twin
// ---------------------------------------------------------------------------

enum class SingleEventEffect { Upset, Transient, Latchup, FunctionalInterrupt, Burnout };

struct RadiationEnvironment {
  double neutron_flux_cm2_s = 0.0;
  double proton_flux_cm2_s = 0.0;
  double heavy_ion_flux_cm2_s = 0.0;
  double total_ionizing_dose_rad_s = 0.0;
  double geomagnetic_severity = 0.0;
  double ionospheric_scintillation = 0.0;
};

struct RadiationDevice {
  std::string id;
  double sensitive_area_cm2 = 0.0;
  std::map<SingleEventEffect, double> cross_section_cm2;
  double ecc_coverage = 0.0;
  double lockstep_coverage = 0.0;
  double watchdog_coverage = 0.0;
  double latchup_protection_coverage = 0.0;
  bool safety_critical = false;
  double total_ionizing_dose_tolerance_rad = 1.0e6;
  double dose_failure_exponent = 4.0;
};

struct MissionSegment {
  double duration_s = 0.0;
  RadiationEnvironment environment;
};

struct RadiationDeviceResult {
  std::string id;
  std::map<SingleEventEffect, double> expected_raw_events;
  double residual_failures = 0.0;
  double failure_probability = 0.0;
};

struct RadiationReliabilityReport {
  std::vector<RadiationDeviceResult> devices;
  double fleet_correlated_failure_probability = 0.0;
  double gnss_error_inflation_m = 0.0;
  bool safety_target_met = false;
  std::string evidence_digest;
};

class SpaceWeatherRadiationReliabilityTwin {
 public:
  RadiationReliabilityReport evaluate(const std::vector<RadiationDevice>& devices,
                                       const std::vector<MissionSegment>& mission,
                                       double maximum_safety_failure_probability) const;
};

// ---------------------------------------------------------------------------
// Neuromusculoskeletal digital human and ergonomics laboratory
// ---------------------------------------------------------------------------

struct MuscleTendonUnit {
  std::string id;
  std::size_t joint = 0;
  double maximum_isometric_force_n = 0.0;
  double optimal_length_m = 0.0;
  double tendon_slack_length_m = 0.0;
  double moment_arm_m = 0.0;
  double activation_time_constant_s = 0.02;
  double fatigue_rate_s_inv = 0.001;
  double recovery_rate_s_inv = 0.0002;
};

struct HumanJoint {
  std::string id;
  double inertia_kg_m2 = 1.0;
  double damping_nms_rad = 0.0;
  double stiffness_nm_rad = 0.0;
  double neutral_angle_rad = 0.0;
  double minimum_angle_rad = -3.14;
  double maximum_angle_rad = 3.14;
};

struct HumanControlSample {
  double time_s = 0.0;
  Vector desired_angles_rad;
  Vector external_torque_nm;
};

struct HumanStateSample {
  double time_s = 0.0;
  Vector joint_angles_rad;
  Vector joint_velocities_rad_s;
  Vector muscle_activations;
  Vector muscle_fatigue;
};

struct HumanErgonomicsReport {
  std::vector<HumanStateSample> trajectory;
  double peak_joint_load_nm = 0.0;
  double metabolic_energy_j = 0.0;
  double maximum_fatigue = 0.0;
  double posture_discomfort_index = 0.0;
  double takeover_time_s = 0.0;
  bool task_completed = false;
  bool joint_limits_respected = false;
  std::string evidence_digest;
};

class NeuromusculoskeletalHumanLaboratory {
 public:
  HumanErgonomicsReport simulate(const std::vector<HumanJoint>& joints,
                                 const std::vector<MuscleTendonUnit>& muscles,
                                 const std::vector<HumanControlSample>& controls,
                                 double dt_s) const;
};

// ---------------------------------------------------------------------------
// Hydrogen materials integrity and cryogenic transfer safety twin
// ---------------------------------------------------------------------------

struct HydrogenMaterial {
  std::string id;
  double diffusion_m2_s = 0.0;
  double solubility_mol_m3_pa_sqrt = 0.0;
  double base_fracture_toughness_mpa_sqrt_m = 0.0;
  double embrittlement_coefficient = 0.0;
  double fatigue_coefficient = 1.0e-12;
};

struct HydrogenVessel {
  double inner_radius_m = 0.0;
  double wall_thickness_m = 0.0;
  double length_m = 0.0;
  double pressure_pa = 0.0;
  double temperature_k = 300.0;
  double initial_crack_m = 1.0e-6;
  double allowable_crack_m = 1.0e-3;
  HydrogenMaterial material;
};

struct CryogenicTransfer {
  double tank_liquid_mass_kg = 0.0;
  double tank_vapor_mass_kg = 0.0;
  double tank_temperature_k = 20.0;
  double tank_volume_m3 = 0.0;
  double inlet_mass_flow_kg_s = 0.0;
  double outlet_mass_flow_kg_s = 0.0;
  double heat_leak_w = 0.0;
  double vent_pressure_pa = 0.0;
  double transfer_duration_s = 0.0;
  double dt_s = 0.1;
};

struct HydrogenIntegrityReport {
  double dissolved_concentration_mol_m3 = 0.0;
  double effective_fracture_toughness_mpa_sqrt_m = 0.0;
  double crack_length_m = 0.0;
  double fatigue_cycles_to_limit = 0.0;
  double final_pressure_pa = 0.0;
  double boiloff_mass_kg = 0.0;
  double vented_mass_kg = 0.0;
  double leak_hazard_radius_m = 0.0;
  bool vessel_qualified = false;
  bool transfer_qualified = false;
  std::string evidence_digest;
};

class HydrogenMaterialsCryogenicSafetyTwin {
 public:
  HydrogenIntegrityReport evaluate(const HydrogenVessel& vessel,
                                    const CryogenicTransfer& transfer,
                                    std::size_t pressure_cycles,
                                    double ambient_pressure_pa = 101325.0) const;
};

// ---------------------------------------------------------------------------
// 6G integrated sensing and communications laboratory
// ---------------------------------------------------------------------------

struct IsacChannel {
  double carrier_hz = 28.0e9;
  double bandwidth_hz = 100.0e6;
  double range_m = 100.0;
  double path_loss_exponent = 2.0;
  double rain_attenuation_db_km = 0.0;
  double blockage_loss_db = 0.0;
  double doppler_m_s = 0.0;
  double noise_figure_db = 5.0;
};

struct RisConfiguration {
  std::size_t elements = 0;
  std::size_t phase_bits = 2;
  double reflection_efficiency = 0.8;
  double additional_path_m = 0.0;
};

struct IsacWaveform {
  double transmit_power_w = 1.0;
  std::size_t subcarriers = 256;
  double communication_fraction = 0.5;
  double coherent_processing_s = 0.01;
  std::size_t transmit_antennas = 1;
  std::size_t receive_antennas = 1;
};

struct IsacResult {
  double snr_db = 0.0;
  double throughput_mbps = 0.0;
  double latency_ms = 0.0;
  double range_resolution_m = 0.0;
  double velocity_resolution_m_s = 0.0;
  double detection_probability = 0.0;
  double positioning_error_m = 0.0;
  double optimized_communication_fraction = 0.0;
  bool requirements_met = false;
  std::string evidence_digest;
};

class IntegratedSensingCommunicationsLaboratory {
 public:
  IsacResult optimize(const IsacChannel& channel,
                      const RisConfiguration& ris,
                      const IsacWaveform& waveform,
                      double minimum_throughput_mbps,
                      double minimum_detection_probability,
                      double maximum_positioning_error_m) const;
};

// ---------------------------------------------------------------------------
// Multi-infrastructure cascading-failure and disaster-resilience twin
// ---------------------------------------------------------------------------

enum class InfrastructureKind { Power, Communications, Road, Water, Hospital, Charging, Fuel, Logistics };

struct InfrastructureAsset {
  std::string id;
  InfrastructureKind kind = InfrastructureKind::Power;
  double capacity = 1.0;
  double demand = 0.0;
  double repair_time_h = 1.0;
  double criticality = 1.0;
  bool initially_available = true;
};

struct InfrastructureDependency {
  std::string supplier;
  std::string consumer;
  double required_fraction = 0.5;
};

struct InfrastructureConnection {
  std::string from;
  std::string to;
  double capacity = 1.0;
  double travel_time_h = 0.0;
};

struct DisasterImpact {
  std::string asset_id;
  double failure_probability = 0.0;
  double capacity_multiplier = 1.0;
};

struct RestorationResource {
  std::string id;
  std::set<InfrastructureKind> capabilities;
  double start_time_h = 0.0;
};

struct RestorationAction {
  std::string asset_id;
  std::string resource_id;
  double start_h = 0.0;
  double finish_h = 0.0;
  double restored_capacity = 0.0;
};

struct DisasterResilienceReport {
  std::map<std::string, double> served_fraction;
  std::vector<std::string> failed_assets;
  std::vector<RestorationAction> restoration_plan;
  double weighted_unserved_demand_h = 0.0;
  double time_to_restore_critical_h = 0.0;
  bool critical_services_restored = false;
  std::string evidence_digest;
};

class CascadingInfrastructureDisasterTwin {
 public:
  DisasterResilienceReport simulate(const std::vector<InfrastructureAsset>& assets,
                                    const std::vector<InfrastructureDependency>& dependencies,
                                    const std::vector<InfrastructureConnection>& connections,
                                    const std::vector<DisasterImpact>& impacts,
                                    const std::vector<RestorationResource>& resources,
                                    std::uint64_t seed) const;
};

}  // namespace aesim::advanced::operational

#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

class HardwareSecurityModule {
public:
    void initialize(const std::string& storage_directory);
    void generate_ed25519_key(const std::string& key_id, bool exportable = false);
    [[nodiscard]] bool has_key(const std::string& key_id) const;
    [[nodiscard]] std::vector<std::uint8_t> sign(const std::string& key_id,
                                                 const std::vector<std::uint8_t>& message) const;
    [[nodiscard]] bool verify(const std::string& key_id,
                              const std::vector<std::uint8_t>& message,
                              const std::vector<std::uint8_t>& signature) const;
    [[nodiscard]] std::string public_key_pem(const std::string& key_id) const;
    [[nodiscard]] std::uint64_t increment_monotonic_counter(const std::string& counter_id);
    [[nodiscard]] std::uint64_t monotonic_counter(const std::string& counter_id) const;
    void seal(const std::string& object_id, const std::vector<std::uint8_t>& plaintext,
              const std::map<std::string, std::string>& policy);
    [[nodiscard]] std::vector<std::uint8_t> unseal(
        const std::string& object_id, const std::map<std::string, std::string>& current_state) const;
    [[nodiscard]] doc::Value status() const;

private:
    struct KeyMetadata { bool exportable = false; std::string private_path; std::string public_path; };
    std::string directory_;
    std::map<std::string, KeyMetadata> keys_;
    std::map<std::string, std::uint64_t> counters_;
    void load_metadata();
    void save_metadata() const;
};

struct BootStage {
    std::string name;
    std::string artifact;
    std::string expected_sha256;
    std::string signer_key_id;
    std::vector<std::uint8_t> signature;
};

struct SecureBootResult {
    bool trusted = false;
    std::vector<std::string> verified_stages;
    std::string failure;
    std::array<std::uint8_t, 32> measurement{};
    [[nodiscard]] doc::Value to_document() const;
};

class SecureBootChain {
public:
    explicit SecureBootChain(const HardwareSecurityModule& hsm) : hsm_(hsm) {}
    [[nodiscard]] SecureBootResult verify(const std::vector<BootStage>& stages) const;
private:
    const HardwareSecurityModule& hsm_;
};

struct SecOcPacket {
    std::string data_id;
    std::uint64_t freshness = 0;
    std::vector<std::uint8_t> payload;
    std::vector<std::uint8_t> authenticator;
};

class SecOcEngine {
public:
    explicit SecOcEngine(std::vector<std::uint8_t> key, std::size_t tag_bytes = 12,
                         std::uint64_t acceptance_window = 0);
    [[nodiscard]] SecOcPacket protect(const std::string& data_id, std::uint64_t freshness,
                                      const std::vector<std::uint8_t>& payload) const;
    [[nodiscard]] bool verify(const SecOcPacket& packet, const std::string& receiver,
                              std::string& error);
    void reset_receiver(const std::string& receiver);
private:
    std::vector<std::uint8_t> key_;
    std::size_t tag_bytes_ = 12;
    std::uint64_t acceptance_window_ = 0;
    std::map<std::pair<std::string, std::string>, std::uint64_t> latest_freshness_;
    [[nodiscard]] std::vector<std::uint8_t> authenticate(const std::string& data_id,
                                                         std::uint64_t freshness,
                                                         const std::vector<std::uint8_t>& payload) const;
};


struct OtaManifest {
    std::string campaign_id;
    std::string target_version;
    std::string payload_sha256;
    std::uint64_t payload_size = 0;
    std::uint64_t rollback_counter = 0;
    std::string device_class;
    std::string signer_key_id;
    std::vector<std::uint8_t> signature;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] static OtaManifest from_document(const doc::Value& value);
};

class SecureOtaManager {
public:
    void initialize(const std::string& storage_directory, HardwareSecurityModule& hsm,
                    std::string device_class);
    [[nodiscard]] OtaManifest create_manifest(const std::string& campaign_id,
                                              const std::string& target_version,
                                              const std::string& payload_path,
                                              std::uint64_t rollback_counter,
                                              const std::string& signer_key_id) const;
    void verify_and_stage(const OtaManifest& manifest, const std::string& payload_path);
    void activate_staged();
    void report_boot_health(bool healthy, const std::string& diagnostic = {});
    [[nodiscard]] doc::Value status() const;
private:
    struct Slot { std::string name; std::string version = "0"; std::string payload_sha256; bool bootable = true; bool healthy = true; };
    std::string directory_;
    std::string device_class_;
    HardwareSecurityModule* hsm_ = nullptr;
    std::array<Slot, 2> slots_{{Slot{"A", "0", {}, true, true}, Slot{"B", "0", {}, true, true}}};
    unsigned active_slot_ = 0;
    std::optional<unsigned> pending_slot_;
    std::optional<std::uint64_t> pending_rollback_counter_;
    std::string last_error_;
    void load_state();
    void save_state() const;
};

struct AttestationQuote {
    std::string device_id;
    std::string key_id;
    std::string nonce_hex;
    std::uint64_t counter = 0;
    std::map<unsigned, std::string> pcr_sha256;
    std::vector<std::uint8_t> signature;
    [[nodiscard]] doc::Value to_document() const;
};

class RemoteAttestationEngine {
public:
    RemoteAttestationEngine(HardwareSecurityModule& hsm, std::string device_id,
                            std::string attestation_key_id);
    void reset_pcr(unsigned index);
    void extend_pcr(unsigned index, const std::vector<std::uint8_t>& measurement);
    [[nodiscard]] AttestationQuote quote(const std::vector<std::uint8_t>& nonce,
                                         const std::set<unsigned>& selected_pcrs);
    [[nodiscard]] bool verify(const AttestationQuote& quote,
                              const std::vector<std::uint8_t>& expected_nonce,
                              const std::map<unsigned, std::string>& expected_pcrs,
                              std::string& error) const;
private:
    HardwareSecurityModule& hsm_;
    std::string device_id_;
    std::string key_id_;
    std::map<unsigned, std::array<std::uint8_t, 32>> pcrs_;
};

enum class AutomotiveProtocol { Can, IsoTp, Uds, DoIp, SomeIp };

struct FuzzMessage {
    AutomotiveProtocol protocol = AutomotiveProtocol::Uds;
    std::string state;
    std::vector<std::uint8_t> bytes;
    std::uint64_t delay_us = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct FuzzResponse {
    bool accepted = false;
    bool crashed = false;
    bool timed_out = false;
    std::vector<std::uint8_t> bytes;
    std::set<std::uint64_t> coverage_edges;
    std::string diagnostic;
};

struct FuzzFinding {
    std::string id;
    AutomotiveProtocol protocol = AutomotiveProtocol::Uds;
    std::string severity;
    std::string category;
    std::string diagnostic;
    std::vector<FuzzMessage> reproducer;
    [[nodiscard]] doc::Value to_document() const;
};

struct FuzzCampaignResult {
    std::uint64_t seed = 0;
    std::size_t executions = 0;
    std::size_t unique_edges = 0;
    std::size_t accepted_messages = 0;
    std::vector<FuzzFinding> findings;
    [[nodiscard]] doc::Value to_document() const;
};

struct FuzzCampaignOptions {
    AutomotiveProtocol protocol = AutomotiveProtocol::Uds;
    std::size_t iterations = 1000;
    std::size_t maximum_sequence_length = 16;
    std::size_t maximum_payload_bytes = 4096;
    std::uint64_t seed = 1;
};

class StatefulAutomotiveFuzzer {
public:
    using Target = std::function<FuzzResponse(const FuzzMessage&)>;
    [[nodiscard]] FuzzCampaignResult run(const FuzzCampaignOptions& options,
                                         const Target& target) const;
    [[nodiscard]] static std::vector<FuzzMessage> seed_corpus(AutomotiveProtocol protocol);
};

class VirtualEcuCyberRange {
public:
    VirtualEcuCyberRange();
    [[nodiscard]] FuzzResponse execute(const FuzzMessage& message);
    void reset();
    [[nodiscard]] doc::Value status() const;
private:
    enum class DiagnosticSession { Default, Extended, Programming };
    DiagnosticSession session_ = DiagnosticSession::Default;
    bool security_unlocked_ = false;
    bool download_active_ = false;
    std::size_t transferred_bytes_ = 0;
    std::uint32_t seed_ = 0x13579BDFu;
    std::set<std::uint64_t> coverage_;
    [[nodiscard]] FuzzResponse execute_uds(const FuzzMessage& message);
    [[nodiscard]] FuzzResponse execute_doip(const FuzzMessage& message);
    [[nodiscard]] FuzzResponse execute_someip(const FuzzMessage& message);
    [[nodiscard]] FuzzResponse execute_isotp(const FuzzMessage& message);
    [[nodiscard]] FuzzResponse execute_can(const FuzzMessage& message);
};

} // namespace aesim::advanced

#pragma once

#include "aesim/advanced/continuum_reality_platform.hpp"

#include <array>
#include <cstddef>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

using FundamentalVector = std::vector<double>;
using FundamentalMatrix = std::vector<FundamentalVector>;

struct ThermodynamicPortState {
    double mass_flow_kg_s = 0.0;
    double heat_flow_w = 0.0;
    double shaft_power_w = 0.0;
    double specific_enthalpy_j_kg = 0.0;
    double specific_entropy_j_kg_k = 0.0;
    double temperature_k = 298.15;
    std::vector<double> species_mass_fractions;
    std::vector<double> chemical_potential_j_mol;
};

struct ThermodynamicAudit {
    double mass_residual_kg_s = 0.0;
    double energy_residual_w = 0.0;
    double entropy_production_w_k = 0.0;
    double exergy_destruction_w = 0.0;
    bool first_law_satisfied = false;
    bool second_law_satisfied = false;
};

class EntropyConsistentCoupling {
public:
    void set_environment(double t0_k, double p0_pa);
    void set_ports(std::vector<ThermodynamicPortState> ports);
    void add_internal_entropy_source(double w_k);
    [[nodiscard]] ThermodynamicAudit audit(
        double mass_tol = 1.0e-9,
        double energy_tol = 1.0e-6) const;

private:
    double t0_ = 298.15;
    double p0_ = 101325.0;
    double source_ = 0.0;
    std::vector<ThermodynamicPortState> ports_;
};

struct NonlinearNode3D {
    std::array<double, 3> x{};
    std::array<double, 3> u{};
    std::array<double, 3> v{};
    double mass_kg = 1.0;
    bool fixed = false;
};

struct GeometricallyExactElement {
    enum class Kind { Beam, Shell, Cable, Membrane };

    Kind kind = Kind::Beam;
    std::vector<std::size_t> nodes;
    double young_pa = 70.0e9;
    double area_m2 = 1.0e-4;
    double second_moment_m4 = 1.0e-8;
    double thickness_m = 1.0e-3;
    double pretension_n = 0.0;
    double density_kg_m3 = 2700.0;
};

struct NonlinearStructureReport {
    bool converged = false;
    std::size_t iterations = 0;
    double residual_norm_n = 0.0;
    double strain_energy_j = 0.0;
    double minimum_tangent_eigenvalue = 0.0;
    std::vector<NonlinearNode3D> nodes;
};

class GeometricallyExactStructureSolver {
public:
    void configure(
        std::vector<NonlinearNode3D> nodes,
        std::vector<GeometricallyExactElement> elements);
    [[nodiscard]] NonlinearStructureReport solve(
        const std::vector<std::array<double, 3>>& nodal_forces,
        double tolerance = 1.0e-7,
        std::size_t max_iterations = 80);

private:
    std::vector<NonlinearNode3D> nodes_;
    std::vector<GeometricallyExactElement> elements_;
    bool configured_ = false;
};

struct SurfaceSpecies {
    std::string name;
    double coverage = 0.0;
};

struct SurfaceReaction {
    std::map<std::string, double> reactants;
    std::map<std::string, double> products;
    double pre_exponential = 1.0;
    double activation_j_mol = 0.0;
    double heat_j_mol = 0.0;
};

struct SurfaceChemistryReport {
    std::vector<SurfaceSpecies> species;
    double heat_release_w_m2 = 0.0;
    double rate_mol_m2_s = 0.0;
    double site_balance_error = 0.0;
};

class ReactiveSurfaceChemistry {
public:
    void configure(
        double site_density_mol_m2,
        std::vector<SurfaceSpecies> species,
        std::vector<SurfaceReaction> reactions);
    [[nodiscard]] SurfaceChemistryReport advance(
        double temperature_k,
        const std::map<std::string, double>& activities,
        double dt_s);

private:
    double sites_ = 1.0;
    std::vector<SurfaceSpecies> species_;
    std::vector<SurfaceReaction> reactions_;
    bool configured_ = false;
};

struct RarefiedGasConfig {
    std::size_t cells = 64;
    std::size_t particles = 20000;
    double length_m = 1.0;
    double molecular_mass_kg = 4.65e-26;
    double diameter_m = 3.7e-10;
    double wall_temperature_k = 300.0;
    unsigned seed = 1;
};

struct RarefiedGasReport {
    double knudsen_number = 0.0;
    double mass_flow_kg_s = 0.0;
    double heat_flux_w_m2 = 0.0;
    double slip_velocity_m_s = 0.0;
    double temperature_jump_k = 0.0;
    std::vector<double> density_kg_m3;
    std::vector<double> velocity_m_s;
    std::vector<double> temperature_k;
};

class RarefiedGasTransportSolver {
public:
    void configure(
        RarefiedGasConfig config,
        double pressure_pa,
        double temperature_k);
    [[nodiscard]] RarefiedGasReport solve(
        double inlet_velocity_m_s,
        double dt_s,
        std::size_t steps);

private:
    RarefiedGasConfig c_;
    double p_ = 101325.0;
    double t_ = 300.0;
    bool configured_ = false;
};

struct PhaseFieldConfig {
    std::size_t nx = 32;
    std::size_t ny = 32;
    double dx_m = 1.0e-6;
    double mobility = 1.0e-14;
    double gradient_energy_j_m = 1.0e-10;
    double double_well_j_m3 = 1.0e6;
};

struct PhaseFieldReport {
    double free_energy_j = 0.0;
    double mass = 0.0;
    double interface_measure = 0.0;
    std::vector<double> order_parameter;
};

class GeneralizedPhaseFieldSolver {
public:
    void configure(
        PhaseFieldConfig config,
        std::function<double(double, double)> initial);
    [[nodiscard]] PhaseFieldReport advance(
        double dt_s,
        std::size_t steps,
        bool conserved = true);

private:
    PhaseFieldConfig c_;
    std::vector<double> phi_;
    bool configured_ = false;
};

struct CoupledWaveConfig {
    std::size_t fluid_cells = 80;
    std::size_t structure_nodes = 40;
    double length_m = 1.0;
    double fluid_density = 1.2;
    double sound_speed = 343.0;
    double structure_density = 7800.0;
    double young_pa = 200.0e9;
    double area_m2 = 1.0e-4;
    double coupling_area_m2 = 1.0e-3;
};

struct CoupledWaveReport {
    double acoustic_energy_j = 0.0;
    double structural_energy_j = 0.0;
    double interface_power_w = 0.0;
    double max_pressure_pa = 0.0;
    double max_displacement_m = 0.0;
    std::vector<double> pressure_pa;
    std::vector<double> displacement_m;
};

class FluidStructureAcousticWaveSolver {
public:
    void configure(CoupledWaveConfig config);
    [[nodiscard]] CoupledWaveReport advance(
        double dt_s,
        std::size_t steps,
        std::function<double(double)> source_pa);

private:
    CoupledWaveConfig c_;
    std::vector<double> p_;
    std::vector<double> pv_;
    std::vector<double> u_;
    std::vector<double> uv_;
    double time_s_ = 0.0;
    bool configured_ = false;
};

struct ReducedBasisModel {
    FundamentalMatrix basis;
    FundamentalMatrix reduced_operator;
    FundamentalVector reduced_state;
    FundamentalVector mean;
    double residual_bound = 0.0;
};

struct ReducedOrderReport {
    FundamentalVector reconstructed_state;
    double residual_norm = 0.0;
    double error_bound = 0.0;
    double energy_fraction = 0.0;
    bool certified = false;
};

class CertifiedReducedOrderModel {
public:
    void train(const FundamentalMatrix& snapshots, std::size_t rank);
    void set_full_operator(FundamentalMatrix a);
    [[nodiscard]] ReducedOrderReport advance(
        double dt_s,
        const FundamentalVector& forcing);
    [[nodiscard]] const ReducedBasisModel& model() const noexcept;

private:
    ReducedBasisModel m_;
    FundamentalMatrix a_;
    FundamentalVector reduced_mean_drift_;
    double retained_energy_fraction_ = 0.0;
    bool trained_ = false;
    bool operator_configured_ = false;
};

struct ValiditySignals {
    double calibration_distance = 0.0;
    double residual_mean = 0.0;
    double residual_autocorrelation = 0.0;
    double conservation_drift = 0.0;
    double numerical_error = 0.0;
    double model_disagreement = 0.0;
    double sensor_innovation = 0.0;
};

struct ValidityAssessment {
    double credibility = 1.0;
    double inadequacy_probability = 0.0;
    std::vector<std::string> actions;
    std::vector<std::string> reasons;
    bool valid = true;
};

class ModelValiditySupervisor {
public:
    void set_thresholds(ValiditySignals thresholds);
    [[nodiscard]] ValidityAssessment assess(const ValiditySignals& signals);

private:
    ValiditySignals t_{1.0, 1.0, 0.3, 1.0e-4, 1.0e-3, 1.0, 3.0};
};

struct SensorCandidate {
    std::string id;
    FundamentalVector sensitivity;
    double variance = 1.0;
    double cost = 1.0;
};

struct SensorPlacementResult {
    std::vector<std::string> selected;
    double log_determinant_gain = 0.0;
    double total_cost = 0.0;
    double condition_number = 0.0;
    FundamentalMatrix information;
};

class OptimalSensorPlacement {
public:
    [[nodiscard]] SensorPlacementResult select(
        std::size_t parameters,
        const std::vector<SensorCandidate>& candidates,
        std::size_t max_sensors,
        double max_cost) const;
};

struct CausalNodeEvidence {
    std::string id;
    std::vector<std::string> parents;
    double residual = 0.0;
    double sensitivity = 0.0;
    double uncertainty = 1.0;
};

struct CausalDiscrepancyResult {
    std::string first_divergent_node;
    std::vector<std::pair<std::string, double>> ranked_causes;
    std::vector<std::string> causal_path;
    std::string recommended_measurement;
    double explained_fraction = 0.0;
};

class CausalDiscrepancyLocalizer {
public:
    void set_graph(std::vector<CausalNodeEvidence> nodes);
    [[nodiscard]] CausalDiscrepancyResult localize(
        double significance_threshold = 2.0) const;

private:
    std::vector<CausalNodeEvidence> nodes_;
};

}  // namespace aesim::advanced

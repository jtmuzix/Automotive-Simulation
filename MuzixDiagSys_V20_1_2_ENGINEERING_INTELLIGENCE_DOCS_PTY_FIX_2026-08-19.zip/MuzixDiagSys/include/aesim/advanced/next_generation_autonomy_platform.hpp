#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

using NextGenVector = std::vector<double>;
using NextGenMatrix = std::vector<std::vector<double>>;
using NextGenPoint2 = std::array<double, 2>;
using NextGenPoint3 = std::array<double, 3>;

// Multimodal Driving Foundation Model and World Model
struct FoundationSensorFrame {
    double timestamp_s = 0.0;
    std::map<std::string, NextGenVector> modality_features;
    NextGenVector ego_state;
    NextGenVector action;
    NextGenVector target_scene_state;
    void validate(std::size_t ego_dimension, std::size_t action_dimension,
                  std::size_t scene_dimension) const;
};

struct FoundationWorldModelOptions {
    std::size_t latent_dimension = 16;
    std::size_t attention_heads = 4;
    std::size_t rollout_horizon = 10;
    std::size_t candidate_actions = 64;
    double ridge_regularization = 1.0e-6;
    double uncertainty_floor = 1.0e-4;
    double action_smoothness_weight = 0.1;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct FoundationWorldModel {
    std::vector<std::string> modalities;
    std::map<std::string, NextGenMatrix> modality_projection;
    NextGenMatrix fusion_projection;
    NextGenMatrix latent_transition;
    NextGenMatrix action_transition;
    NextGenMatrix scene_decoder;
    NextGenVector latent_bias;
    NextGenVector scene_bias;
    NextGenVector residual_variance;
    NextGenVector latent_mean;
    NextGenVector latent_standard_deviation;
    std::size_t ego_dimension = 0;
    std::size_t action_dimension = 0;
    std::size_t scene_dimension = 0;
};

struct FoundationInferenceResult {
    NextGenVector latent_state;
    NextGenVector predicted_scene_state;
    NextGenVector predictive_standard_deviation;
    double out_of_distribution_score = 0.0;
    bool within_trained_domain = false;
};

struct FoundationPlanResult {
    std::vector<NextGenVector> actions;
    std::vector<NextGenVector> predicted_scene_trajectory;
    double objective = 0.0;
    double maximum_uncertainty = 0.0;
    bool safety_envelope_satisfied = false;
};

struct FoundationTrainingResult {
    FoundationWorldModel model;
    double one_step_rmse = 0.0;
    double rollout_rmse = 0.0;
    double latent_spectral_radius = 0.0;
    double calibration_error = 0.0;
    bool stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_model = false) const;
};

class MultimodalDrivingFoundationWorldModelLaboratory {
public:
    [[nodiscard]] FoundationTrainingResult train(
        const std::vector<FoundationSensorFrame>& sequence,
        const FoundationWorldModelOptions& options) const;
    [[nodiscard]] FoundationInferenceResult infer(
        const FoundationWorldModel& model,
        const FoundationSensorFrame& frame) const;
    [[nodiscard]] FoundationPlanResult plan(
        const FoundationWorldModel& model,
        const FoundationSensorFrame& initial_frame,
        const std::vector<NextGenVector>& action_library,
        const NextGenVector& target_scene,
        const NextGenVector& lower_safety_bounds,
        const NextGenVector& upper_safety_bounds,
        const FoundationWorldModelOptions& options) const;
};

// Cooperative Perception and V2X Edge-Cloud Autonomy
struct CooperativeDetection {
    std::string source_id;
    std::string object_class;
    double timestamp_s = 0.0;
    NextGenVector state;
    NextGenMatrix covariance;
    double confidence = 1.0;
    void validate(std::size_t state_dimension) const;
};

struct V2xCommunicationLink {
    std::string source_id;
    std::string destination_id;
    double latency_s = 0.0;
    double jitter_s = 0.0;
    double packet_loss_fraction = 0.0;
    double bandwidth_bit_s = 1.0e6;
    double trust = 1.0;
    bool compromised = false;
    void validate() const;
};

struct EdgeComputeNode {
    std::string id;
    double compute_top_s = 1.0;
    double memory_gb = 1.0;
    double current_load_fraction = 0.0;
    double power_w = 10.0;
    void validate() const;
};

struct CooperativeInferenceTask {
    std::string id;
    double operations_top = 0.01;
    double memory_gb = 0.1;
    std::size_t payload_bits = 1000;
    double deadline_s = 0.1;
    void validate() const;
};

struct CooperativeFusedTrack {
    std::string object_class;
    NextGenVector state;
    NextGenMatrix covariance;
    double confidence = 0.0;
    double age_of_information_s = 0.0;
    std::vector<std::string> contributing_sources;
};

struct EdgeTaskAssignment {
    std::string task_id;
    std::string node_id;
    double completion_time_s = 0.0;
    double communication_time_s = 0.0;
    double energy_j = 0.0;
    bool deadline_met = false;
};

struct CooperativeAutonomyResult {
    std::vector<CooperativeFusedTrack> fused_tracks;
    std::vector<EdgeTaskAssignment> assignments;
    std::map<std::string, double> source_trust;
    std::vector<std::string> rejected_sources;
    double mean_age_of_information_s = 0.0;
    double perception_confidence_gain = 0.0;
    double deadline_success_fraction = 0.0;
    bool byzantine_resilient = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_tracks = false) const;
};

class CooperativePerceptionV2xEdgeCloudLaboratory {
public:
    [[nodiscard]] CooperativeAutonomyResult execute(
        const std::vector<CooperativeDetection>& detections,
        const std::vector<V2xCommunicationLink>& links,
        const std::vector<EdgeComputeNode>& nodes,
        const std::vector<CooperativeInferenceTask>& tasks,
        double fusion_timestamp_s,
        double byzantine_threshold) const;
};

// Neuromorphic Sensing and Computing
struct EventCameraConfiguration {
    std::size_t width = 64;
    std::size_t height = 48;
    double positive_log_threshold = 0.15;
    double negative_log_threshold = 0.15;
    double refractory_period_s = 1.0e-5;
    double background_event_rate_hz = 0.0;
    double timestamp_quantization_s = 1.0e-6;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct EventCameraFrame {
    double timestamp_s = 0.0;
    NextGenVector intensity;
    void validate(std::size_t pixels) const;
};

struct NeuromorphicEvent {
    double timestamp_s = 0.0;
    std::size_t x = 0;
    std::size_t y = 0;
    int polarity = 1;
};

struct SpikingNeuron {
    double membrane_time_constant_s = 0.02;
    double threshold = 1.0;
    double reset_potential = 0.0;
    double refractory_period_s = 0.001;
    void validate() const;
};

struct SpikingSynapse {
    std::size_t source = 0;
    std::size_t destination = 0;
    double weight = 0.1;
    double delay_s = 0.0;
    bool plastic = false;
    void validate(std::size_t neurons) const;
};

struct NeuromorphicResult {
    std::vector<NeuromorphicEvent> events;
    std::vector<std::size_t> spike_counts;
    std::vector<double> final_membrane_potential;
    NextGenPoint2 estimated_optical_flow_px_s{0.0, 0.0};
    double event_rate_hz = 0.0;
    double estimated_energy_j = 0.0;
    double sparsity_fraction = 0.0;
    bool bandwidth_saturated = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_events = false) const;
};

class NeuromorphicSensingComputingLaboratory {
public:
    [[nodiscard]] NeuromorphicResult simulate(
        const EventCameraConfiguration& camera,
        const std::vector<EventCameraFrame>& frames,
        const std::vector<SpikingNeuron>& neurons,
        const std::vector<SpikingSynapse>& synapses,
        double maximum_event_rate_hz,
        bool apply_stdp) const;
};

// Post-Quantum and Confidential Vehicle Security
struct PostQuantumAlgorithmProfile {
    std::string name;
    std::string category;
    std::size_t public_key_bytes = 0;
    std::size_t private_key_bytes = 0;
    std::size_t ciphertext_or_signature_bytes = 0;
    unsigned security_category = 1;
    double keygen_time_ms = 0.0;
    double operation_time_ms = 0.0;
    void validate() const;
};

struct ConfidentialWorkload {
    std::string id;
    std::string measurement_sha256;
    std::size_t plaintext_bytes = 0;
    double compute_ms = 0.0;
    double enclave_memory_mb = 1.0;
    double privacy_epsilon = 1.0;
    bool requires_remote_attestation = true;
    void validate() const;
};

struct CryptoMigrationAsset {
    std::string id;
    std::string current_algorithm;
    unsigned confidentiality_years = 1;
    double update_bandwidth_bit_s = 1.0e6;
    std::size_t certificate_chain_depth = 1;
    bool hardware_accelerated = false;
    void validate() const;
};

struct SecurityQualificationResult {
    std::map<std::string, std::string> selected_algorithm_by_asset;
    std::map<std::string, double> migration_time_s;
    std::map<std::string, bool> attestation_passed;
    std::map<std::string, double> differential_privacy_noise_stddev;
    double total_handshake_latency_ms = 0.0;
    std::size_t total_credential_bytes = 0;
    double harvest_now_decrypt_later_risk = 0.0;
    bool crypto_agile = false;
    bool confidential_execution_qualified = false;
    std::string transcript_sha256;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_assets = false) const;
};

class PostQuantumConfidentialVehicleSecurityLaboratory {
public:
    [[nodiscard]] SecurityQualificationResult qualify(
        const std::vector<PostQuantumAlgorithmProfile>& algorithms,
        const std::vector<CryptoMigrationAsset>& assets,
        const std::vector<ConfidentialWorkload>& workloads,
        const std::map<std::string, std::string>& trusted_measurements,
        double network_round_trip_ms,
        unsigned migration_horizon_years) const;
};

// Beyond-Lithium-Ion Battery Chemistry
enum class AdvancedBatteryChemistry {
    SolidStateLithiumMetal,
    SodiumIon,
    LithiumSulfur,
    MetalAir,
    RedoxFlow
};

struct AdvancedBatteryCellModel {
    AdvancedBatteryChemistry chemistry = AdvancedBatteryChemistry::SolidStateLithiumMetal;
    double nominal_capacity_ah = 1.0;
    double nominal_voltage_v = 3.7;
    double internal_resistance_ohm = 0.01;
    double diffusion_time_constant_s = 100.0;
    double thermal_mass_j_k = 500.0;
    double cooling_w_k = 2.0;
    double interfacial_area_m2 = 0.1;
    double solid_electrolyte_conductivity_s_m = 0.1;
    double electrolyte_thickness_m = 1.0e-4;
    double stack_pressure_pa = 1.0e6;
    double maximum_temperature_k = 350.0;
    double minimum_soc = 0.0;
    double maximum_soc = 1.0;
    void validate() const;
};

struct AdvancedBatteryOperatingPoint {
    double duration_s = 1.0;
    double current_a = 0.0;
    double ambient_temperature_k = 298.15;
    double external_pressure_pa = 1.0e6;
    void validate() const;
};

struct AdvancedBatteryResult {
    NextGenVector time_s;
    NextGenVector voltage_v;
    NextGenVector temperature_k;
    NextGenVector state_of_charge;
    NextGenVector capacity_fraction;
    NextGenVector interfacial_resistance_ohm;
    double delivered_energy_j = 0.0;
    double round_trip_efficiency = 0.0;
    double dendrite_risk = 0.0;
    double polysulfide_shuttle_loss_fraction = 0.0;
    double mechanical_contact_loss_fraction = 0.0;
    double oxygen_transport_limit_fraction = 0.0;
    double final_capacity_fraction = 1.0;
    bool thermal_limit_respected = true;
    bool mass_charge_balance_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class BeyondLithiumIonBatteryChemistryLaboratory {
public:
    [[nodiscard]] AdvancedBatteryResult simulate(
        const AdvancedBatteryCellModel& cell,
        const std::vector<AdvancedBatteryOperatingPoint>& profile,
        double initial_soc,
        double time_step_s,
        std::uint64_t deterministic_seed) const;
};

// Resilient PNT and Quantum Navigation
struct NavigationTruthSample {
    double timestamp_s = 0.0;
    NextGenVector state;
    void validate(std::size_t state_dimension) const;
};

struct NavigationMeasurement {
    std::string sensor_id;
    std::string sensor_type;
    double timestamp_s = 0.0;
    NextGenVector values;
    NextGenMatrix covariance;
    bool jammed = false;
    bool spoofed = false;
    void validate() const;
};

struct NavigationFilterOptions {
    double process_noise = 1.0e-3;
    double innovation_gate_sigma = 4.0;
    double integrity_risk_limit = 1.0e-5;
    double quantum_accel_bias_stability_m_s2 = 1.0e-7;
    double quantum_gyro_bias_stability_rad_s = 1.0e-8;
    void validate() const;
};

struct ResilientNavigationResult {
    std::vector<double> timestamp_s;
    std::vector<NextGenVector> estimated_state;
    std::vector<NextGenVector> standard_deviation;
    std::vector<double> horizontal_protection_level_m;
    std::vector<std::string> excluded_measurements;
    double position_rmse_m = 0.0;
    double maximum_protection_level_m = 0.0;
    double spoof_detection_rate = 0.0;
    double continuity_fraction = 0.0;
    bool integrity_requirement_met = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_trajectory = false) const;
};

class ResilientPntQuantumNavigationLaboratory {
public:
    [[nodiscard]] ResilientNavigationResult estimate(
        const std::vector<NavigationTruthSample>& truth,
        const std::vector<NavigationMeasurement>& measurements,
        const NavigationFilterOptions& options) const;
};

// Climate and Extreme-Weather Resilience
struct ClimateGrid {
    std::size_t width = 32;
    std::size_t height = 32;
    double cell_size_m = 10.0;
    NextGenVector elevation_m;
    NextGenVector drainage_m_s;
    NextGenVector vegetation_fraction;
    NextGenVector initial_water_depth_m;
    void validate() const;
};

struct ExtremeWeatherForcing {
    double duration_s = 3600.0;
    double time_step_s = 1.0;
    double rainfall_m_s = 0.0;
    double storm_surge_m = 0.0;
    double ambient_temperature_k = 300.0;
    double wind_speed_m_s = 0.0;
    double wind_direction_rad = 0.0;
    double wildfire_ignition_x = -1.0;
    double wildfire_ignition_y = -1.0;
    double snow_rate_m_s = 0.0;
    double freezing_rain_rate_m_s = 0.0;
    void validate() const;
};

struct ClimateAsset {
    std::string id;
    std::size_t x = 0;
    std::size_t y = 0;
    double flood_tolerance_m = 0.2;
    double heat_tolerance_k = 330.0;
    double wind_tolerance_m_s = 30.0;
    double fire_tolerance = 0.5;
    void validate(const ClimateGrid& grid) const;
};

struct ClimateResilienceResult {
    NextGenVector final_water_depth_m;
    NextGenVector wildfire_intensity;
    NextGenVector road_friction;
    NextGenVector heat_index_k;
    std::map<std::string, double> asset_risk;
    std::map<std::string, bool> asset_operational;
    double flooded_area_fraction = 0.0;
    double burned_area_fraction = 0.0;
    double impassable_road_fraction = 0.0;
    double maximum_water_depth_m = 0.0;
    bool mass_balance_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class ClimateExtremeWeatherResilienceLaboratory {
public:
    [[nodiscard]] ClimateResilienceResult simulate(
        const ClimateGrid& grid,
        const ExtremeWeatherForcing& forcing,
        const std::vector<ClimateAsset>& assets) const;
};

// Differentiable Generative CAD
struct CadDesignRequirement {
    std::string id;
    std::string metric;
    double lower_bound = -1.0e30;
    double upper_bound = 1.0e30;
    double weight = 1.0;
    void validate() const;
};

struct CadPrimitive {
    std::string id;
    std::string type;
    std::string operation = "union";
    NextGenPoint3 center{0.0, 0.0, 0.0};
    NextGenPoint3 dimensions{1.0, 1.0, 1.0};
    double radius = 0.5;
    double parameter_lower_scale = 0.5;
    double parameter_upper_scale = 2.0;
    void validate() const;
};

struct GenerativeCadOptions {
    std::size_t voxel_resolution = 24;
    std::size_t optimization_iterations = 50;
    double learning_rate = 0.05;
    double finite_difference_step = 1.0e-3;
    double target_volume_m3 = 1.0;
    double minimum_thickness_m = 0.01;
    void validate() const;
};

struct GenerativeCadResult {
    std::vector<CadPrimitive> optimized_primitives;
    std::vector<NextGenPoint3> vertices;
    std::vector<std::array<std::size_t, 3>> triangles;
    NextGenVector signed_distance_field;
    double volume_m3 = 0.0;
    double surface_area_m2 = 0.0;
    double minimum_thickness_m = 0.0;
    double objective = 0.0;
    double maximum_requirement_violation = 0.0;
    bool watertight = false;
    bool manufacturable = false;
    std::string editable_feature_tree;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_mesh = false) const;
};

class DifferentiableGenerativeCadLaboratory {
public:
    [[nodiscard]] GenerativeCadResult generate(
        const std::vector<CadPrimitive>& seed_primitives,
        const std::vector<CadDesignRequirement>& requirements,
        const GenerativeCadOptions& options) const;
};

// Autonomous Engineering Agent and Continuous Evidence Factory
struct EngineeringRequirement {
    std::string id;
    std::string statement;
    std::string verification_method;
    double priority = 1.0;
    bool safety_critical = false;
    void validate() const;
};

struct EngineeringAgentDefinition {
    std::string id;
    std::string role;
    std::vector<std::string> capabilities;
    double hourly_cost = 1.0;
    double reliability = 1.0;
    void validate() const;
};

struct EngineeringWorkItem {
    std::string id;
    std::string capability;
    std::vector<std::string> requirement_ids;
    std::vector<std::string> predecessors;
    double estimated_hours = 1.0;
    double compute_cost = 0.0;
    bool human_approval_required = false;
    void validate() const;
};

struct EngineeringEvidenceRecord {
    std::string work_item_id;
    std::string agent_id;
    std::string status;
    std::string artifact_sha256;
    double start_h = 0.0;
    double finish_h = 0.0;
    double confidence = 0.0;
    std::vector<std::string> requirement_ids;
};

struct EngineeringEvidenceFactoryResult {
    std::vector<EngineeringEvidenceRecord> records;
    std::map<std::string, std::string> requirement_status;
    std::vector<std::string> contradictions;
    std::vector<std::string> approval_gates;
    double project_finish_h = 0.0;
    double total_cost = 0.0;
    double weighted_evidence_confidence = 0.0;
    bool dependency_graph_valid = false;
    bool all_safety_requirements_verified = false;
    std::string evidence_manifest_sha256;
    [[nodiscard]] doc::Value to_document(bool include_records = false) const;
};

class AutonomousEngineeringAgentEvidenceFactory {
public:
    [[nodiscard]] EngineeringEvidenceFactoryResult execute(
        const std::vector<EngineeringRequirement>& requirements,
        const std::vector<EngineeringAgentDefinition>& agents,
        const std::vector<EngineeringWorkItem>& work_items,
        double compute_budget,
        double labor_budget,
        bool approve_all_gates) const;
};

// Semiconductor Fabrication and Yield Digital Twin
struct SemiconductorProcessStep {
    std::string id;
    std::string type;
    double duration_s = 1.0;
    double temperature_k = 300.0;
    double target_thickness_m = 0.0;
    double dose_m2 = 0.0;
    double energy_ev = 0.0;
    double removal_fraction = 0.0;
    double defect_probability = 0.0;
    void validate() const;
};

struct WaferFabricationConfiguration {
    double wafer_diameter_m = 0.3;
    double die_width_m = 0.01;
    double die_height_m = 0.01;
    double edge_exclusion_m = 0.003;
    double initial_defect_density_m2 = 10.0;
    double critical_dimension_m = 10.0e-9;
    double overlay_standard_deviation_m = 1.0e-9;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};

struct SemiconductorDieResult {
    std::size_t row = 0;
    std::size_t column = 0;
    NextGenPoint2 center_m{0.0, 0.0};
    double critical_dimension_m = 0.0;
    double threshold_voltage_v = 0.0;
    double sheet_resistance_ohm_sq = 0.0;
    double leakage_a = 0.0;
    std::size_t defects = 0;
    bool functional = false;
};

struct SemiconductorFabricationResult {
    std::vector<SemiconductorDieResult> dies;
    double functional_yield = 0.0;
    double parametric_yield = 0.0;
    double mean_critical_dimension_m = 0.0;
    double critical_dimension_sigma_m = 0.0;
    double mean_threshold_voltage_v = 0.0;
    double total_cycle_time_s = 0.0;
    double total_energy_j = 0.0;
    double process_capability_cpk = 0.0;
    std::map<std::string, double> virtual_metrology;
    bool mass_balance_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_wafer_map = false) const;
};

class SemiconductorFabricationYieldDigitalTwin {
public:
    [[nodiscard]] SemiconductorFabricationResult simulate(
        const WaferFabricationConfiguration& configuration,
        const std::vector<SemiconductorProcessStep>& process_flow) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/core/numerical_rigor.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <list>
#include <map>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace aesim::advanced::frontier {

struct RankCheckpoint {
    int rank = -1;
    std::uint64_t generation = 0;
    std::vector<std::uint8_t> payload;
    std::string sha256;
};

struct ResilientPartition {
    std::size_t partition = 0;
    int owner_rank = -1;
    int mirror_rank = -1;
};

struct UlfmRecoveryReport {
    std::uint64_t generation = 0;
    std::vector<int> failed_ranks;
    std::vector<int> surviving_ranks;
    std::vector<ResilientPartition> partitions;
    std::vector<int> recovered_ranks;
    bool native_ulfm_available = false;
    bool native_repair_attempted = false;
    bool native_repair_succeeded = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class UlfmResilientRuntime {
public:
    explicit UlfmResilientRuntime(int world_size, std::size_t partition_count = 0);
    void checkpoint_rank(int rank, const std::vector<std::uint8_t>& payload, int mirror_rank = -1);
    void fail_rank(int rank);
    [[nodiscard]] UlfmRecoveryReport recover();
    [[nodiscard]] std::vector<std::uint8_t> restore_rank_payload(int rank) const;
    [[nodiscard]] std::uint64_t generation() const noexcept { return generation_; }
    [[nodiscard]] static bool native_ulfm_available() noexcept;
private:
    int world_size_ = 0;
    std::size_t partition_count_ = 0;
    std::uint64_t generation_ = 0;
    std::vector<bool> alive_;
    std::map<int, RankCheckpoint> checkpoints_;
    std::map<int, int> mirrors_;
};

enum class CheckpointCodec { ZfpFixedAccuracy, Sz3Predictive };

struct CompressedCheckpoint {
    CheckpointCodec codec = CheckpointCodec::ZfpFixedAccuracy;
    std::size_t value_count = 0;
    double absolute_error_bound = 0.0;
    double relative_error_bound = 0.0;
    double quantization_step = 0.0;
    std::vector<std::uint8_t> payload;
    std::string payload_sha256;
    [[nodiscard]] double compression_ratio() const noexcept;
    [[nodiscard]] doc::Value to_document(bool include_payload = false) const;
};

class ErrorBoundedCheckpointCompressor {
public:
    [[nodiscard]] static CompressedCheckpoint compress(const std::vector<double>& values,
                                                       CheckpointCodec codec,
                                                       double absolute_error_bound,
                                                       double relative_error_bound = 0.0);
    [[nodiscard]] static std::vector<double> decompress(const CompressedCheckpoint& compressed);
    [[nodiscard]] static bool verify(const std::vector<double>& original,
                                     const CompressedCheckpoint& compressed,
                                     double* max_absolute_error = nullptr,
                                     double* max_relative_error = nullptr);
    static void save(const std::string& path, const CompressedCheckpoint& compressed);
    [[nodiscard]] static CompressedCheckpoint load(const std::string& path);
};

struct OutOfCoreStatistics {
    std::uint64_t hits = 0;
    std::uint64_t misses = 0;
    std::uint64_t evictions = 0;
    std::uint64_t dirty_flushes = 0;
    std::size_t resident_chunks = 0;
    std::size_t chunk_size = 0;
    std::size_t element_count = 0;
    std::string backing_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class OutOfCoreArray {
public:
    OutOfCoreArray(std::string path, std::size_t elements, std::size_t chunk_size,
                   std::size_t max_resident_chunks, bool create);
    ~OutOfCoreArray();
    OutOfCoreArray(const OutOfCoreArray&) = delete;
    OutOfCoreArray& operator=(const OutOfCoreArray&) = delete;
    [[nodiscard]] double get(std::size_t index);
    void set(std::size_t index, double value);
    void flush();
    [[nodiscard]] OutOfCoreStatistics statistics(bool hash_backing_file = false);
private:
    struct Chunk { std::vector<double> data; bool dirty = false; std::list<std::size_t>::iterator lru; };
    std::string path_;
    std::size_t elements_ = 0;
    std::size_t chunk_size_ = 0;
    std::size_t max_resident_ = 0;
    std::unordered_map<std::size_t, Chunk> cache_;
    std::list<std::size_t> lru_;
    OutOfCoreStatistics stats_;
    Chunk& load_chunk(std::size_t chunk_index);
    void evict_if_needed();
    void flush_chunk(std::size_t chunk_index, Chunk& chunk);
};

struct HardwareNode {
    int numa_node = 0;
    std::vector<int> cpus;
    std::uint64_t memory_bytes = 0;
};

struct HardwareGpu {
    std::string name;
    std::string pci_address;
    int numa_node = -1;
};

struct HardwareTopology {
    unsigned logical_cpus = 0;
    unsigned physical_packages = 0;
    std::vector<HardwareNode> numa_nodes;
    std::vector<HardwareGpu> gpus;
    [[nodiscard]] doc::Value to_document() const;
};

struct PlacementRequest {
    std::size_t cpu_threads = 1;
    std::uint64_t memory_bytes = 0;
    bool require_gpu = false;
    std::optional<int> preferred_numa_node;
};

struct PlacementDecision {
    bool feasible = false;
    int numa_node = -1;
    std::vector<int> cpus;
    std::optional<std::size_t> gpu_index;
    std::string reason;
    [[nodiscard]] doc::Value to_document() const;
};

class HardwareAwareScheduler {
public:
    [[nodiscard]] static HardwareTopology discover();
    [[nodiscard]] static PlacementDecision place(const HardwareTopology& topology, const PlacementRequest& request);
    [[nodiscard]] static bool apply_cpu_affinity(const PlacementDecision& decision, std::string& error);
};

struct FloatingPointCertificate {
    std::string operation;
    std::size_t operation_count = 0;
    double computed = 0.0;
    long double reference = 0.0L;
    double absolute_error = 0.0;
    double certified_bound = 0.0;
    double unit_roundoff = 0.0;
    bool finite_domain = false;
    bool verified = false;
    std::string assumptions;
    std::string sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class FloatingPointVerifier {
public:
    [[nodiscard]] static FloatingPointCertificate certify_sum(const std::vector<double>& values);
    [[nodiscard]] static FloatingPointCertificate certify_dot(const std::vector<double>& a, const std::vector<double>& b);
    [[nodiscard]] static FloatingPointCertificate certify_horner(const std::vector<double>& coefficients, double x);
    [[nodiscard]] static bool verify(const FloatingPointCertificate& certificate);
};

struct Quaternion {
    double w = 1.0, x = 0.0, y = 0.0, z = 0.0;
    [[nodiscard]] double norm() const noexcept;
    void normalize();
    [[nodiscard]] doc::Value to_document() const;
};

struct RigidBodyState {
    Quaternion orientation;
    std::array<double,3> angular_velocity{0.0,0.0,0.0};
    [[nodiscard]] doc::Value to_document() const;
};

class LieGroupIntegrator {
public:
    [[nodiscard]] static RigidBodyState step(const RigidBodyState& state,
                                             const std::array<double,3>& torque,
                                             const std::array<double,3>& principal_inertia,
                                             double dt);
};

struct VariationalState { double position = 0.0; double momentum = 0.0; };
class VariationalIntegrator {
public:
    using PotentialGradient = std::function<double(double)>;
    [[nodiscard]] static VariationalState stormer_verlet(const VariationalState& state, double mass,
                                                         double dt, const PotentialGradient& gradient);
};

struct StiffIntegrationResult {
    double final_time = 0.0;
    std::vector<double> state;
    std::size_t steps = 0;
    std::size_t nonlinear_iterations = 0;
    double residual_norm = 0.0;
    bool converged = false;
    std::string method;
    [[nodiscard]] doc::Value to_document() const;
};

class StiffIntegrator {
public:
    using OdeFunction = core::numerics::OdeFunction;
    [[nodiscard]] static StiffIntegrationResult radau_iia(const OdeFunction& f, double t0, double t1,
                                                          const std::vector<double>& y0, double step,
                                                          double nonlinear_tolerance = 1e-10,
                                                          std::size_t max_newton_iterations = 12);
    [[nodiscard]] static StiffIntegrationResult rosenbrock_w(const OdeFunction& f, double t0, double t1,
                                                             const std::vector<double>& y0, double step);
    [[nodiscard]] static StiffIntegrationResult imex(const OdeFunction& explicit_part,
                                                     const OdeFunction& implicit_part,
                                                     double t0, double t1,
                                                     const std::vector<double>& y0, double step,
                                                     double nonlinear_tolerance = 1e-10,
                                                     std::size_t max_newton_iterations = 12);
};

enum class GnssMode { Standalone, Ppp, Rtk, PppRtk };

struct GnssObservation {
    std::size_t epoch = 0;
    std::string satellite;
    std::array<double,3> satellite_position_m{0.0,0.0,0.0};
    std::array<double,3> satellite_velocity_mps{0.0,0.0,0.0};
    double pseudorange_m = 0.0;
    double carrier_phase_cycles = 0.0;
    double wavelength_m = 0.190293672798;
    double doppler_hz = 0.0;
    double sigma_code_m = 1.0;
    double sigma_phase_m = 0.01;
    double sigma_doppler_mps = 0.1;
    double satellite_clock_m = 0.0;
    double satellite_clock_drift_mps = 0.0;
    double ionosphere_m = 0.0;
    double troposphere_mapping = 1.0;
    double code_bias_m = 0.0;
    double phase_bias_m = 0.0;
    double phase_windup_cycles = 0.0;
    double relativistic_m = 0.0;
    bool cycle_slip = false;
    bool has_second_frequency = false;
    double frequency_hz = 1575.42e6;
    double frequency2_hz = 1227.60e6;
    double pseudorange2_m = 0.0;
    double carrier_phase2_cycles = 0.0;
    double wavelength2_m = 0.244210213425;
    bool has_base = false;
    std::array<double,3> base_position_m{0.0,0.0,0.0};
    double base_pseudorange_m = 0.0;
    double base_carrier_phase_cycles = 0.0;
};

struct GnssImuPreintegration {
    std::size_t from_epoch = 0, to_epoch = 0;
    std::array<double,3> delta_position_m{0.0,0.0,0.0};
    std::array<double,3> delta_velocity_mps{0.0,0.0,0.0};
    double sigma_position_m = 0.25;
    double sigma_velocity_mps = 0.1;
};

struct GnssWheelSpeedFactor { std::size_t epoch = 0; double speed_mps = 0.0; double sigma_mps = 0.2; };
struct GnssMapFactor { std::size_t epoch = 0; std::array<double,3> position_m{0.0,0.0,0.0}; double sigma_m = 2.0; };

struct GnssEpochSolution {
    std::size_t epoch = 0;
    std::array<double,3> position_m{0.0,0.0,0.0};
    std::array<double,3> velocity_mps{0.0,0.0,0.0};
    double clock_bias_m = 0.0;
    double clock_drift_mps = 0.0;
    double zenith_wet_troposphere_m = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct GnssFactorGraphResult {
    GnssMode mode = GnssMode::Standalone;
    std::vector<GnssEpochSolution> epochs;
    std::map<std::string,double> floating_ambiguities_m;
    std::map<std::string,long long> fixed_ambiguities_cycles;
    bool ambiguities_fixed = false;
    double ambiguity_ratio = 0.0;
    double code_rms_m = 0.0;
    double carrier_rms_m = 0.0;
    double doppler_rms_mps = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class GnssCarrierPhaseFactorGraph {
public:
    GnssCarrierPhaseFactorGraph(GnssMode mode, std::size_t sliding_window_epochs = 0);
    void add_observation(GnssObservation observation);
    void add_imu_factor(GnssImuPreintegration factor);
    void add_wheel_speed_factor(GnssWheelSpeedFactor factor);
    void add_map_factor(GnssMapFactor factor);
    [[nodiscard]] GnssFactorGraphResult optimize(std::size_t maximum_iterations = 15,
                                                 double convergence_tolerance = 1e-5,
                                                 double ambiguity_ratio_threshold = 3.0);
private:
    GnssMode mode_;
    std::size_t window_;
    std::vector<GnssObservation> observations_;
    std::vector<GnssImuPreintegration> imu_;
    std::vector<GnssWheelSpeedFactor> wheel_;
    std::vector<GnssMapFactor> map_;
};

struct SpadLidarRequest {
    double range_m = 10.0;
    std::size_t pulses = 10000;
    std::size_t bins = 512;
    double bin_width_s = 0.5e-9;
    double photons_per_pulse = 0.02;
    double detection_efficiency = 0.25;
    double background_rate_hz = 1.0e6;
    double dark_rate_hz = 5.0e4;
    double timing_jitter_s = 0.2e-9;
    double dead_time_s = 20e-9;
    std::uint64_t seed = 1;
};

struct SpadLidarResult {
    double estimated_range_m = 0.0;
    std::vector<std::uint64_t> histogram;
    std::uint64_t detected_signal = 0;
    std::uint64_t detected_background = 0;
    std::uint64_t suppressed_dead_time = 0;
    double signal_to_background = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class SpadLidarSimulator { public: [[nodiscard]] static SpadLidarResult simulate(const SpadLidarRequest& request); };

struct CoherentLidarRequest {
    double range_m = 50.0;
    double radial_velocity_mps = 10.0;
    double carrier_hz = 193.414e12;
    double chirp_bandwidth_hz = 1.0e9;
    double chirp_duration_s = 50e-6;
    std::size_t samples = 2048;
    double snr_db = 30.0;
    std::uint64_t seed = 1;
};

struct CoherentLidarResult {
    double estimated_range_m = 0.0;
    double estimated_velocity_mps = 0.0;
    double up_beat_hz = 0.0;
    double down_beat_hz = 0.0;
    double peak_power = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};
class CoherentLidarSimulator { public: [[nodiscard]] static CoherentLidarResult simulate(const CoherentLidarRequest& request); };

struct RadarScatterer { double amplitude = 1.0; double radial_velocity_mps = 0.0; double micro_velocity_amplitude_mps = 0.0; double micro_frequency_hz = 0.0; double phase_rad = 0.0; };
struct PolarimetricMatrix { std::array<double,2> hh{1,0}, hv{0,0}, vh{0,0}, vv{1,0}; };
struct RadarSignatureRequest { double carrier_hz = 77e9; double pulse_repetition_hz = 2000.0; std::size_t pulses = 512; std::vector<RadarScatterer> scatterers; PolarimetricMatrix polarimetry; };
struct RadarPeak { double doppler_hz = 0.0; double radial_velocity_mps = 0.0; double power = 0.0; };
struct RadarSignatureResult { std::vector<RadarPeak> peaks; double cross_pol_ratio_db = 0.0; double co_pol_ratio_db = 0.0; std::array<double,3> pauli_power{0,0,0}; std::string evidence_sha256; [[nodiscard]] doc::Value to_document() const; };
class RadarSignatureSimulator { public: [[nodiscard]] static RadarSignatureResult simulate(const RadarSignatureRequest& request); };

class FrontierRuntimeSensingPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain, const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

} // namespace aesim::advanced::frontier

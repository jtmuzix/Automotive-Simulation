#pragma once
#include <cstddef>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class IndyCarCircuitClass { RoadStreet, ShortOval, Speedway, Indianapolis };
enum class IndyCarViolationSeverity { Advisory, SportingPenalty, TechnicalExclusion };

struct IndyCarApprovedPart { std::string category; std::string part_number; bool approved=true; bool sealed=false; std::string seal_id; void validate() const; };
struct IndyCarRuleProfile {
  std::string profile_id="INDYCAR-2026-07-15"; std::string effective_date="2026-07-15";
  double minimum_road_street_mass_kg=809.66, minimum_short_oval_mass_kg=802.86, minimum_speedway_mass_kg=789.25;
  double driver_equivalency_mass_kg=83.9146, fuel_cell_capacity_l=70.03, engine_displacement_l=2.2, maximum_engine_speed_rpm=12000.0;
  double superspeedway_boost_mbar_gauge=1300.0, qualifying_boost_mbar_gauge=1500.0, push_to_pass_boost_mbar_gauge=1650.0;
  double minimum_wheelbase_m=2.9845, maximum_wheelbase_m=3.0861, maximum_vehicle_height_m=1.03;
  double front_wheel_width_m=0.254, rear_wheel_width_m=0.3556, default_hybrid_energy_per_lap_j=2.5e6, maximum_hybrid_power_w=111855.0;
  double default_push_to_pass_total_s=200.0, default_push_to_pass_activation_s=20.0;
  bool tyre_warmers_prohibited=true, tyre_treatment_prohibited=true, driver_weight_jacker_only=true, oval_hybrid_self_start_prohibited=true;
  void validate() const; double minimum_mass_kg(IndyCarCircuitClass) const;
};
struct IndyCarVehicleConfiguration {
  std::string entrant, car_number, chassis_serial; IndyCarCircuitClass circuit=IndyCarCircuitClass::RoadStreet;
  double car_mass_excluding_driver_fuel_kg=810.0, driver_plus_ballast_kg=83.9146, fuel_l=0.0, wheelbase_m=3.02, vehicle_height_m=1.0;
  double engine_displacement_l=2.2, engine_speed_limit_rpm=12000.0, boost_mbar_gauge=1500.0, front_wheel_width_m=0.254, rear_wheel_width_m=0.3556;
  bool power_steering_present=false, ballast_in_keel=true; std::vector<IndyCarApprovedPart> parts; std::string ecu_software_sha256; void validate() const;
};
struct IndyCarRuleViolation { std::string rule, message; IndyCarViolationSeverity severity=IndyCarViolationSeverity::TechnicalExclusion; double measured=0.0, limit=0.0; };
struct IndyCarScrutineeringResult { bool legal=false; double minimum_mass_kg=0.0, mass_margin_kg=0.0; std::vector<IndyCarRuleViolation> violations; std::string configuration_sha256; };
class IndyCarRulePlatform { IndyCarRuleProfile profile_; public: explicit IndyCarRulePlatform(IndyCarRuleProfile); const IndyCarRuleProfile& profile() const noexcept; IndyCarScrutineeringResult inspect(const IndyCarVehicleConfiguration&) const; };

struct IndyCarOvalSegment { double distance_m=0.0,length_m=100.0,radius_m=250.0,banking_rad=0.2,grip=1.0,bump_height_m=0.0,crosswind_m_s=0.0; void validate() const; };
struct IndyCarOvalSetup {
  double mass_kg=900.0,wheelbase_m=3.02,front_track_m=1.70,rear_track_m=1.65,cg_height_m=0.31,front_static_fraction=0.43,crossweight_fraction=0.50;
  double front_roll_stiffness_n_m_rad=65000.0,rear_roll_stiffness_n_m_rad=52000.0,front_heave_stiffness_n_m=180000.0,rear_heave_stiffness_n_m=160000.0;
  double front_downforce_coefficient=1.25,rear_downforce_coefficient=1.75,drag_coefficient_area_m2=0.90,tyre_mu=1.75,tyre_stagger_m=0.003;
  double right_front_pressure_kpa=180.0,right_rear_pressure_kpa=170.0,minimum_ride_height_m=0.025; void validate() const;
};
struct IndyCarOvalState { double lap=0.0,distance_m=0.0,speed_m_s=0.0,steering_torque_n_m=0.0,front_slip_utilization=0.0,rear_slip_utilization=0.0,understeer_margin=0.0,right_front_load_n=0.0,right_rear_load_n=0.0,minimum_ride_height_m=0.0,right_front_temperature_k=300.0,right_rear_temperature_k=300.0; bool bottoming=false; };
struct IndyCarOvalDynamicsResult { bool stable=false; double lap_time_s=0.0,maximum_speed_m_s=0.0,maximum_steering_torque_n_m=0.0,minimum_understeer_margin=0.0,maximum_right_front_load_n=0.0,bottoming_fraction=0.0; std::vector<IndyCarOvalState> history; std::string evidence_sha256; };
class IndyCarOvalDynamicsLaboratory { public: IndyCarOvalDynamicsResult simulate(const std::vector<IndyCarOvalSegment>&,const IndyCarOvalSetup&,double,std::size_t,double=0.02) const; };

struct IndyCarAeroConfiguration { IndyCarCircuitClass circuit=IndyCarCircuitClass::RoadStreet; double reference_area_m2=1.5,lift_coefficient=-2.8,drag_coefficient=0.82,front_balance=0.43,cooling_area_m2=0.03; bool approved=true; void validate() const; };
struct IndyCarPackCar { std::string id; double longitudinal_position_m=0.0,lateral_position_m=0.0,speed_m_s=70.0,yaw_rad=0.0; IndyCarAeroConfiguration aero; void validate() const; };
struct IndyCarPackCarResult { std::string id; double tow_speed_gain_m_s=0.0,downforce_n=0.0,drag_n=0.0,front_balance=0.0,cooling_flow_fraction=1.0,wake_deficit=0.0,side_draft_force_n=0.0,turbulence_intensity=0.0; };
struct IndyCarPackAeroResult { bool configuration_legal=false; double minimum_cooling_fraction=1.0,maximum_wake_deficit=0.0; std::vector<IndyCarPackCarResult> cars; std::string evidence_sha256; };
class IndyCarPackAeroLaboratory { public: IndyCarPackAeroResult evaluate(const std::vector<IndyCarPackCar>&,double,double,double) const; };

struct IndyCarWeightJackerConfiguration { double minimum_position_mm=-8.0,maximum_position_mm=8.0,actuator_rate_mm_s=12.0,rear_spring_rate_n_m=180000.0,rear_track_m=1.65,front_roll_bar_min_n_m_rad=30000.0,front_roll_bar_max_n_m_rad=90000.0,rear_roll_bar_min_n_m_rad=25000.0,rear_roll_bar_max_n_m_rad=80000.0; void validate() const; };
struct IndyCarDriverSetupCommand { double time_s=0.0,weight_jacker_position_mm=0.0,front_roll_bar_fraction=0.5,rear_roll_bar_fraction=0.5; bool direct_driver_input=true; void validate() const; };
struct IndyCarSetupState { double time_s=0.0,weight_jacker_position_mm=0.0,crossweight_change_n=0.0,front_roll_stiffness_n_m_rad=0.0,rear_roll_stiffness_n_m_rad=0.0,balance_shift=0.0; };
struct IndyCarDriverSetupResult { bool legal=false; double final_weight_jacker_position_mm=0.0,maximum_crossweight_change_n=0.0; std::vector<std::string> violations; std::vector<IndyCarSetupState> history; std::string evidence_sha256; };
class IndyCarDriverSetupLaboratory { public: IndyCarDriverSetupResult simulate(const IndyCarWeightJackerConfiguration&,const std::vector<IndyCarDriverSetupCommand>&,double) const; };

struct IndyCarHybridEventProfile { IndyCarCircuitClass circuit=IndyCarCircuitClass::RoadStreet; double usable_energy_j=2.5e6,maximum_deployment_power_w=111855.0,maximum_regeneration_power_w=120000.0,maximum_regeneration_torque_n_m=250.0,push_to_pass_total_s=200.0,push_to_pass_max_activation_s=20.0,base_boost_mbar_gauge=1500.0,push_to_pass_boost_mbar_gauge=1650.0,minimum_state_of_charge=0.05,maximum_state_of_charge=0.98; void validate() const; };
struct IndyCarHybridSegment { double start_time_s=0.0,duration_s=1.0,speed_m_s=50.0,driver_hybrid_request=0.0,braking_power_available_w=0.0; bool push_to_pass_requested=false,push_to_pass_allowed_signal=true,opening_start_phase=false,command_blue=false,car_stalled=false,safety_crew_clear=false,driver_acknowledged_restart=false; void validate() const; };
struct IndyCarHybridState { double time_s=0.0,state_of_charge=0.0,deployment_power_w=0.0,regeneration_power_w=0.0,cumulative_hybrid_energy_j=0.0,push_to_pass_remaining_s=0.0,boost_mbar_gauge=0.0; bool push_to_pass_active=false,self_start_performed=false; };
struct IndyCarHybridOrchestrationResult { bool compliant=false; double deployed_energy_j=0.0,regenerated_energy_j=0.0,push_to_pass_used_s=0.0; std::size_t successful_self_starts=0; std::vector<std::string> violations; std::vector<IndyCarHybridState> history; std::string evidence_sha256; };
class IndyCarHybridOrchestrator { public: IndyCarHybridOrchestrationResult simulate(const IndyCarHybridEventProfile&,const std::vector<IndyCarHybridSegment>&,double) const; };

enum class IndyCarTyreCompound { Primary, Alternate, Wet, Setup, Speedway }; enum class IndyCarTyreCorner { LeftFront, RightFront, LeftRear, RightRear };
struct IndyCarTyreSet { std::string set_id,entrant; IndyCarTyreCompound compound=IndyCarTyreCompound::Primary; std::map<IndyCarTyreCorner,std::string> tyre_serials; std::size_t laps=0,heat_cycles=0; double tread_remaining=1.0,structural_health=1.0,temperature_k=295.0,cold_pressure_kpa=145.0; bool returned=false; void validate() const; };
struct IndyCarTyreSessionRequirement { std::string session_id; std::size_t laps=1; std::vector<IndyCarTyreCompound> allowed_compounds; bool mandatory_new_set=false,wet_authorized=false; double importance=1.0,ambient_temperature_k=298.0; void validate() const; };
struct IndyCarTyreAllocation { std::string session_id,set_id; IndyCarTyreCompound compound=IndyCarTyreCompound::Primary; double first_lap_grip_fraction=0.0,expected_time_loss_s=0.0,final_tread_remaining=0.0; };
struct IndyCarTyreStrategyResult { bool feasible=false,compound_requirement_satisfied=false,no_warmer_compliant=false; double weighted_time_loss_s=0.0; std::vector<IndyCarTyreAllocation> allocations; std::vector<IndyCarTyreSet> final_sets; std::vector<std::string> violations; std::string evidence_sha256; };
class IndyCarFirestoneStrategyPlatform { public: IndyCarTyreStrategyResult optimize(std::vector<IndyCarTyreSet>,const std::vector<IndyCarTyreSessionRequirement>&,bool,bool,bool) const; };

struct Indy500CarModel { double base_no_tow_speed_m_s=103.0,tow_gain_m_s=2.5,qualifying_boost_gain_m_s=1.2,drag_sensitivity_per_trim=0.05,stability_loss_per_trim=0.08,fuel_capacity_l=70.03,fuel_consumption_l_per_lap=2.5,pit_loss_s=34.0; void validate() const; };
struct Indy500Conditions { double air_temperature_k=300.0,track_temperature_k=318.0,wind_speed_m_s=3.0,wind_direction_rad=0.0,humidity=0.45,caution_probability_per_lap=0.025; void validate() const; };
struct Indy500QualifyingPlan { double aero_trim=0.5; bool qualifying_boost=true; double average_speed_m_s=0.0; std::vector<double> lap_speeds_m_s; double completion_probability=0.0,advancement_probability=0.0; };
struct Indy500MonthOfMayResult { bool rookie_orientation_complete=false; Indy500QualifyingPlan best_qualifying_plan; double best_no_tow_speed_m_s=0.0,expected_race_speed_m_s=0.0; std::size_t recommended_green_flag_stint_laps=0; double expected_pit_stops=0.0,expected_race_time_s=0.0; std::string evidence_sha256; };
class Indy500MonthOfMayPlatform { public: Indy500MonthOfMayResult evaluate(const Indy500CarModel&,const Indy500Conditions&,const std::vector<double>&,std::size_t=200) const; };

struct IndyCarQualifyingEntry { std::string car_id; double representative_lap_s=70.0,traffic_variance_s=0.2,interference_penalty_s=0.0; bool technical_pass=true; void validate() const; };
struct IndyCarOvalQualifyingAttempt { std::string car_id; std::vector<double> timed_lap_s; bool guaranteed_attempt=false,withdrawn_previous_time=false,technical_pass=true; void validate() const; };
struct IndyCarQualificationResult { std::vector<std::string> grid_order; std::map<std::string,double> classified_time_s; std::vector<std::string> eliminated,penalties; bool complete=false; std::string evidence_sha256; };
class IndyCarQualificationProcedureEngine { public: IndyCarQualificationResult road_street(const std::vector<IndyCarQualifyingEntry>&,std::size_t,std::size_t,std::size_t) const; IndyCarQualificationResult oval(const std::vector<IndyCarOvalQualifyingAttempt>&,std::size_t) const; };

enum class IndyCarTrackCondition { Green, LocalYellow, FullCourseYellow, Red }; enum class IndyCarRaceEventType { LapCompleted, Incident, PitLaneOpen, PitLaneClosed, WaveAround, OneToGo, Restart, RedFlag, GreenFlag, PitEntry, Penalty, Retirement };
struct IndyCarRaceCarState { std::string car_id; std::size_t lap=0; double elapsed_s=0.0; bool on_lead_lap=true,in_pit=false,retired=false; double penalty_s=0.0; void validate() const; };
struct IndyCarRaceControlEvent { double time_s=0.0; IndyCarRaceEventType type=IndyCarRaceEventType::LapCompleted; std::string car_id,detail; void validate() const; };
struct IndyCarRaceControlSnapshot { double time_s=0.0; IndyCarTrackCondition condition=IndyCarTrackCondition::Green; bool pit_lane_open=true; std::vector<std::string> running_order; };
struct IndyCarRaceControlResult { IndyCarTrackCondition final_condition=IndyCarTrackCondition::Green; bool pit_lane_open=true; std::vector<std::string> official_order; std::map<std::string,double> penalties_s; std::vector<std::string> violations; std::vector<IndyCarRaceControlSnapshot> timeline; std::string evidence_sha256; };
class IndyCarRaceControlStateMachine { public: IndyCarRaceControlResult process(std::vector<IndyCarRaceCarState>,const std::vector<IndyCarRaceControlEvent>&,IndyCarCircuitClass) const; };

enum class IndyCarPowerAssetType { Engine, Hybrid };
struct IndyCarPowerAsset { std::string serial; IndyCarPowerAssetType type=IndyCarPowerAssetType::Engine; std::string manufacturer; double accumulated_miles=0.0,life_limit_miles=2500.0,base_failure_probability=0.005; bool sealed=true,available=true; void validate() const; };
struct IndyCarPowerEvent { std::string event_id; double expected_miles=250.0,importance=1.0; bool indianapolis=false; void validate() const; };
struct IndyCarPowerAssignment { std::string event_id,engine_serial,hybrid_serial; double expected_failure_probability=0.0,expected_penalty_cost=0.0; };
struct IndyCarPowerPoolResult { bool feasible=false; double total_expected_failure_cost=0.0,total_penalty_cost=0.0; std::vector<IndyCarPowerAssignment> assignments; std::vector<std::string> violations; std::map<std::string,double> final_mileage; std::string evidence_sha256; };
class IndyCarPowerPoolManager { public: IndyCarPowerPoolResult optimize(std::vector<IndyCarPowerAsset>,const std::vector<IndyCarPowerEvent>&,std::size_t,std::size_t,double,double) const; };

} // namespace aesim::advanced

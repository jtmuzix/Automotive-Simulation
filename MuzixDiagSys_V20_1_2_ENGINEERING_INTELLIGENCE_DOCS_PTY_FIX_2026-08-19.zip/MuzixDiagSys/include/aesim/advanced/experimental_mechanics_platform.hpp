#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

enum class FrfEstimator { H1, H2, Hv };
enum class OmaMethod { FrequencyDomainDecomposition, CovarianceDrivenSsi };

struct NvhSignal { std::string id; double sample_rate_hz=0.0; std::vector<double> samples; void validate() const; };
struct FrequencyResponseFunction { std::vector<double> frequency_hz; std::vector<std::complex<double>> response; std::vector<double> coherence; FrfEstimator estimator=FrfEstimator::H1; [[nodiscard]] doc::Value to_document(bool include_spectrum=false) const; };
struct ModalMode { double frequency_hz=0.0; double damping_ratio=0.0; std::vector<std::complex<double>> shape; double confidence=0.0; [[nodiscard]] doc::Value to_document(bool include_shape=false) const; };
struct ModalCorrelationResult { std::vector<std::vector<double>> mac; std::vector<double> comac; std::vector<std::pair<std::size_t,std::size_t>> paired_modes; double mean_paired_mac=0.0; [[nodiscard]] doc::Value to_document() const; };
struct TransferPathInput { std::string path_id; std::vector<std::complex<double>> force_spectrum; std::vector<std::complex<double>> transfer_function; };
struct TransferPathContribution { std::string path_id; std::vector<std::complex<double>> response_spectrum; double rms_contribution=0.0; double normalized_contribution=0.0; };
struct TransferPathResult { std::vector<TransferPathContribution> paths; std::vector<std::complex<double>> reconstructed_response; double reconstruction_rms=0.0; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_spectra=false) const; };
class NvhExperimentalAnalysisWorkbench { public: [[nodiscard]] FrequencyResponseFunction estimate_frf(const NvhSignal&,const NvhSignal&,FrfEstimator=FrfEstimator::H1,std::size_t=1024,double=0.5) const; [[nodiscard]] std::vector<ModalMode> identify_operational_modes(const std::vector<NvhSignal>&,OmaMethod=OmaMethod::FrequencyDomainDecomposition,std::size_t=8,std::size_t=1024,double=0.5,std::size_t=16) const; [[nodiscard]] ModalCorrelationResult correlate_modes(const std::vector<ModalMode>&,const std::vector<ModalMode>&) const; [[nodiscard]] TransferPathResult transfer_path_analysis(const std::vector<TransferPathInput>&) const; };

struct BrakeStructuralMode { std::string id; double natural_frequency_hz=0.0; double modal_mass_kg=1.0; double damping_ratio=0.01; double rotor_participation=0.5; double pad_participation=0.5; void validate() const; };
struct BrakeSquealConfiguration { std::vector<BrakeStructuralMode> modes; std::vector<double> friction_coupling_n_m; double friction_coefficient=0.4; double interface_pressure_pa=1.0e6; double reference_pressure_pa=1.0e6; double rotor_temperature_k=350.0; double reference_temperature_k=350.0; double friction_temperature_slope_per_k=-2.0e-4; double pad_wear_fraction=0.0; double wear_coupling_gain=0.25; double instability_growth_threshold_per_s=0.1; void validate() const; };
struct BrakeSquealModeResult { std::complex<double> eigenvalue_per_s{}; double frequency_hz=0.0; double growth_rate_per_s=0.0; double effective_damping_ratio=0.0; bool unstable=false; std::vector<double> participation; };
struct BrakeSquealResult { std::vector<BrakeSquealModeResult> modes; std::vector<double> vibration_time_s; std::vector<double> vibration_acceleration_m_s2; std::size_t unstable_mode_count=0; double dominant_squeal_frequency_hz=0.0; double maximum_growth_rate_per_s=0.0; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_waveform=false) const; };
class BrakeSquealInstabilitySolver { public: [[nodiscard]] BrakeSquealResult analyze(const BrakeSquealConfiguration&,double=0.25,double=24000.0) const; };

enum class BearingDefectKind { None, InnerRaceSpall, OuterRaceSpall, RollingElementSpall, CageDefect, LubricationStarvation, Brinelling, Misalignment };
struct RollingBearingGeometry { std::size_t rolling_elements=8; double rolling_element_diameter_m=0.010; double pitch_diameter_m=0.045; double contact_angle_rad=0.0; double radial_clearance_m=15e-6; double radial_stiffness_n_m=1e8; double damping_n_s_m=250.0; void validate() const; };
struct BearingFaultState { BearingDefectKind defect=BearingDefectKind::None; double defect_angular_position_rad=0.0; double defect_width_m=0.0; double defect_depth_m=0.0; double lubrication_quality=1.0; double misalignment_rad=0.0; };
struct BearingOperatingPoint { double shaft_speed_rpm=0.0; double radial_load_n=0.0; double axial_load_n=0.0; double temperature_k=298.15; double sample_rate_hz=25600.0; double duration_s=0.5; std::uint64_t random_seed=1; };
struct BearingCharacteristicFrequencies { double shaft_hz=0.0,ftf_hz=0.0,bpfo_hz=0.0,bpfi_hz=0.0,bsf_hz=0.0; [[nodiscard]] doc::Value to_document() const; };
struct BearingDiagnosticFeatures { double rms=0.0,peak=0.0,crest_factor=0.0,kurtosis=0.0,envelope_bpfo_amplitude=0.0,envelope_bpfi_amplitude=0.0,envelope_bsf_amplitude=0.0,envelope_ftf_amplitude=0.0,spectral_kurtosis_peak=0.0,spectral_kurtosis_frequency_hz=0.0; };
struct BearingPrognosticEstimate { double severity=0.0,growth_rate_m_per_cycle=0.0,remaining_cycles=0.0,remaining_hours=0.0,lower_95_hours=0.0,upper_95_hours=0.0,failure_probability_100h=0.0; };
struct BearingFaultSimulationResult { BearingCharacteristicFrequencies characteristic; BearingDiagnosticFeatures features; BearingPrognosticEstimate prognostics; std::vector<double> time_s,acceleration_m_s2,envelope; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_waveform=false) const; };
class RollingBearingFaultPrognosticsLab { public: [[nodiscard]] BearingCharacteristicFrequencies characteristic_frequencies(const RollingBearingGeometry&,double) const; [[nodiscard]] BearingFaultSimulationResult simulate(const RollingBearingGeometry&,const BearingFaultState&,const BearingOperatingPoint&,double failure_defect_depth_m=1.5e-3) const; };

struct XfemNode2d { double x_m=0.0,y_m=0.0; }; struct XfemTriangle2d { std::array<std::size_t,3> nodes{}; };
struct XfemMesh2d { std::vector<XfemNode2d> nodes; std::vector<XfemTriangle2d> elements; double width_m=0.0,height_m=0.0; [[nodiscard]] static XfemMesh2d rectangular(double,double,std::size_t,std::size_t); void validate() const; };
struct XfemMaterial { double youngs_modulus_pa=70e9,poisson_ratio=0.33,fracture_toughness_pa_sqrt_m=30e6,paris_c_m_per_cycle=1e-12,paris_m=3.0,fatigue_threshold_pa_sqrt_m=3e6; void validate() const; };
struct XfemCrack { double start_x_m=0.0,start_y_m=0.0,tip_x_m=0.0,tip_y_m=0.0; };
struct XfemLoadCase { double sigma_x_pa=0.0,sigma_y_pa=0.0,tau_xy_pa=0.0,load_ratio_r=0.1,cycles=0.0,maximum_growth_increment_m=1e-3; };
struct XfemStepResult { XfemCrack crack; double k1_pa_sqrt_m=0.0,k2_pa_sqrt_m=0.0,j_integral_j_m2=0.0,crack_growth_m=0.0,growth_angle_rad=0.0,maximum_von_mises_pa=0.0; std::size_t enriched_nodes=0; };
struct XfemFractureResult { std::vector<XfemStepResult> steps; std::vector<double> displacement_xy_m; XfemCrack final_crack; bool unstable_fracture=false; double consumed_cycles=0.0; std::string evidence_sha256; [[nodiscard]] doc::Value to_document(bool include_displacements=false) const; };
class XfemCrackPropagationSolver { public: [[nodiscard]] XfemFractureResult solve(const XfemMesh2d&,const XfemMaterial&,XfemCrack,const XfemLoadCase&,std::size_t maximum_growth_steps=64) const; };

} // namespace aesim::advanced

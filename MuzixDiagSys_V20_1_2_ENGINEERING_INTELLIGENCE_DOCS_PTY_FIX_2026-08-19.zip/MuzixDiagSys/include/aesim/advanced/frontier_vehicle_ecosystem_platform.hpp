#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

struct EmcMeasurementPoint { double frequency_hz=0.0; double level_dbuv=0.0; double limit_dbuv=0.0; double uncertainty_db=0.0; };
struct EmcQualificationReport { bool passed=false; double worst_margin_db=0.0; double expanded_uncertainty_db=0.0; std::vector<EmcMeasurementPoint> corrected_points; };
class StandardsQualifiedEmcLaboratory {
public:
    void configure(double antenna_factor_db_per_m, double cable_loss_db, double preamplifier_gain_db, double receiver_uncertainty_db);
    [[nodiscard]] EmcQualificationReport qualify_cispr25(const std::vector<EmcMeasurementPoint>& points, double detector_correction_db=0.0) const;
    [[nodiscard]] double iso7637_transient_peak(double source_voltage_v, double source_resistance_ohm, double load_resistance_ohm, double rise_time_s, double harness_inductance_h) const;
    [[nodiscard]] double iso11452_immunity_field(double forward_power_w, double net_antenna_gain, double distance_m, double vswr) const;
private: double antenna_factor_=0.0, cable_loss_=0.0, preamp_gain_=0.0, receiver_uncertainty_=0.0;
};

enum class EngineeringToolKind { MatlabEngine, SimulinkSFunction, Stateflow, DSpace, VectorCanoe, EtasInca, NiVeristand, Speedgoat, OpalRt };
struct ToolSignal { std::string name; double value=0.0; std::string unit; std::uint64_t timestamp_ns=0; };
struct ToolExchangeReport { bool synchronized=false; double latency_s=0.0; double jitter_s=0.0; std::vector<ToolSignal> outputs; std::string evidence_digest; };
class MatlabSimulinkHilFederation {
public:
    void register_signal(std::string name, std::string unit, double scale=1.0, double offset=0.0);
    [[nodiscard]] std::vector<std::uint8_t> encode_frame(EngineeringToolKind kind, std::uint64_t sequence, const std::vector<ToolSignal>& signals) const;
    [[nodiscard]] std::vector<ToolSignal> decode_frame(const std::vector<std::uint8_t>& frame) const;
    [[nodiscard]] ToolExchangeReport synchronize(double requested_time_s, double remote_time_s, const std::vector<ToolSignal>& signals);
    [[nodiscard]] std::string generate_level2_s_function(const std::string& function_name) const;
private:
    struct Mapping { std::string unit; double scale=1.0; double offset=0.0; };
    std::map<std::string, Mapping> mappings_; double prior_latency_=0.0;
};

struct DifferentiationReport { double value=0.0; std::vector<double> gradient; std::vector<std::vector<double>> jacobian; double consistency_error=0.0; };
class TensorDifferentiableBridge {
public:
    using ScalarFunction=std::function<double(const std::vector<double>&)>;
    using VectorFunction=std::function<std::vector<double>(const std::vector<double>&)>;
    [[nodiscard]] DifferentiationReport value_and_gradient(const ScalarFunction& function, const std::vector<double>& x, double relative_step=1e-5) const;
    [[nodiscard]] DifferentiationReport value_and_jacobian(const VectorFunction& function, const std::vector<double>& x, double relative_step=1e-5) const;
    [[nodiscard]] std::vector<double> vector_jacobian_product(const VectorFunction& function, const std::vector<double>& x, const std::vector<double>& cotangent) const;
};

struct HeavyVehicleState { double speed_mps=0.0, yaw_rate_rad_s=0.0, articulation_rad=0.0, brake_reservoir_pa=800000.0, brake_temperature_k=300.0, battery_soc=0.8; };
struct HeavyVehicleInput { double throttle=0.0, brake=0.0, steering_rad=0.0, road_grade_rad=0.0, payload_kg=0.0; };
struct HeavyVehicleReport { HeavyVehicleState state; double stopping_distance_m=0.0, rollover_index=0.0, jackknife_index=0.0, energy_used_j=0.0; };
class HeavyCommercialVehiclePlatform {
public: void configure(double tractor_mass_kg, double trailer_mass_kg, double wheelbase_m, double cg_height_m, double battery_capacity_j);
    [[nodiscard]] HeavyVehicleReport advance(const HeavyVehicleState& state, const HeavyVehicleInput& input, double dt_s) const;
private: double tractor_mass_=9000, trailer_mass_=18000, wheelbase_=4.0, cg_height_=1.2, battery_capacity_=1e9;
};

struct EnduranceCar { std::string id, category; double energy_mj=0.0, fuel_kg=0.0, tire_wear=0.0, damage=0.0, lap_time_s=0.0; int driver_index=0; };
struct EnduranceRaceReport { std::vector<EnduranceCar> classification; std::map<std::string,double> bop_adjustments; bool slow_zone_active=false; double race_time_s=0.0; };
class WecImsaEndurancePlatform {
public: void set_balance_of_performance(std::string category, double power_factor, double mass_delta_kg);
    [[nodiscard]] EnduranceRaceReport run_stint(std::vector<EnduranceCar> cars, double duration_s, double rain_intensity, bool slow_zone) const;
private: std::map<std::string,std::pair<double,double>> bop_;
};

struct GeoPoint { double x=0.0,y=0.0,z=0.0; };
struct GeoTransform { double scale=1.0, rotation_rad=0.0, tx=0.0, ty=0.0, tz=0.0, rmse_m=0.0; };
struct RoadPolyline { std::string id; std::vector<GeoPoint> points; };
class GisPhotogrammetryPipeline {
public:
    [[nodiscard]] GeoPoint geodetic_to_enu(double latitude_deg, double longitude_deg, double altitude_m, double origin_lat_deg, double origin_lon_deg, double origin_alt_m) const;
    [[nodiscard]] GeoTransform register_point_clouds(const std::vector<GeoPoint>& source, const std::vector<GeoPoint>& target) const;
    [[nodiscard]] RoadPolyline extract_centerline(const std::vector<GeoPoint>& classified_road_points, std::size_t bins) const;
    [[nodiscard]] std::vector<GeoPoint> apply(const std::vector<GeoPoint>& points, const GeoTransform& transform) const;
};

enum class Contaminant { Water, Mud, Dust, Salt, Snow, Frost, Oil, Insects };
struct SensorSurfaceState { std::map<Contaminant,double> coverage; double temperature_k=293.15; double optical_transmission=1.0; double radar_loss_db=0.0; double lidar_return_factor=1.0; double washer_fluid_l=1.0; };
struct CleaningCommand { double washer_flow_l_s=0.0, air_knife_power_w=0.0, heater_power_w=0.0, wiper_speed_hz=0.0; };
class SensorContaminationCleaningPlatform {
public: [[nodiscard]] SensorSurfaceState advance(SensorSurfaceState state, double deposition_rate_per_s, Contaminant contaminant, const CleaningCommand& command, double ambient_k, double dt_s) const;
};

struct MotorcycleState { double speed_mps=0.0, roll_rad=0.0, roll_rate_rad_s=0.0, steer_rad=0.0, yaw_rate_rad_s=0.0, wheelie_height_m=0.0; };
struct RiderCommand { double throttle=0.0, front_brake=0.0, rear_brake=0.0, steer_torque_nm=0.0, body_lean_rad=0.0; };
struct MotorcycleReport { MotorcycleState state; double lateral_accel_mps2=0.0, tire_utilization=0.0, highside_risk=0.0, stoppie_risk=0.0; };
class MotorcycleRiderPlatform {
public: void configure(double mass_kg, double wheelbase_m, double cg_height_m, double max_tire_mu);
    [[nodiscard]] MotorcycleReport advance(const MotorcycleState& state, const RiderCommand& command, double dt_s) const;
private: double mass_=260.0,wheelbase_=1.42,cg_height_=0.58,mu_=1.3;
};

enum class OccupantPopulation { Pediatric, Adolescent, SmallAdultFemale, MidAdultMale, LargeAdultMale, Elderly, Pregnant, Obese, WheelchairSeated };
struct OccupantResponse { double head_injury_criterion=0.0, chest_deflection_mm=0.0, neck_injury_criterion=0.0, submarining_probability=0.0, egress_time_s=0.0, severe_injury_probability=0.0; };
class PopulationResolvedOccupantLibrary {
public: [[nodiscard]] OccupantResponse evaluate(OccupantPopulation population, double delta_v_mps, double pulse_duration_s, double belt_load_n, double airbag_pressure_kpa, double posture_offset_m) const;
};

struct TrafficActorState { std::string id; double x_m=0.0,y_m=0.0,speed_mps=0.0,heading_rad=0.0; std::string lane_id; };
struct TrafficFederationReport { std::vector<TrafficActorState> actors; double synchronization_error_s=0.0; std::size_t inserted=0, removed=0; };
class SumoTrafficToolFederation {
public:
    [[nodiscard]] std::string encode_traci_move(const TrafficActorState& actor) const;
    [[nodiscard]] TrafficFederationReport reconcile(const std::vector<TrafficActorState>& local, const std::vector<TrafficActorState>& remote, double local_time_s, double remote_time_s, double blend) const;
};

struct PassByNoiseSample { double time_s=0.0, distance_m=0.0, propulsion_db=0.0, tire_db=0.0, aero_db=0.0; };
struct PassByNoiseReport { double maximum_a_weighted_db=0.0, sound_exposure_level_db=0.0, background_corrected_db=0.0, uncertainty_db=0.0, margin_to_limit_db=0.0, passed=false; };
class RegulatoryPassByNoiseLaboratory {
public: [[nodiscard]] PassByNoiseReport qualify_iso362(const std::vector<PassByNoiseSample>& samples, double background_db, double limit_db, double microphone_uncertainty_db) const;
};

struct ParkingPose { int x=0,y=0; int heading=0; };
struct ParkingPlan { bool found=false; std::vector<ParkingPose> poses; double length_m=0.0; double clearance_m=0.0; };
class AutomatedParkingValetPlatform {
public: [[nodiscard]] ParkingPlan plan(const std::vector<std::string>& occupancy, ParkingPose start, ParkingPose goal, double cell_size_m) const;
};

struct PeridynamicReport { std::vector<double> displacement_m; std::vector<double> damage; double strain_energy_j=0.0; std::size_t broken_bonds=0; };
class PeridynamicBarSolver { public: [[nodiscard]] PeridynamicReport solve(std::size_t nodes, double length_m, double area_m2, double youngs_pa, double load_n, double critical_stretch) const; };
struct LbmReport { double mean_velocity_mps=0.0, max_velocity_mps=0.0, mass_residual=0.0; std::vector<double> density; };
class LatticeBoltzmannSolver { public: [[nodiscard]] LbmReport lid_driven_cavity(std::size_t nx, std::size_t ny, double lid_velocity, double viscosity, std::size_t steps) const; };
struct BemReport { std::vector<double> surface_pressure_pa; double radiated_power_w=0.0; double condition_estimate=0.0; };
class AcousticBoundaryElementSolver { public: [[nodiscard]] BemReport solve_sphere(const std::vector<GeoPoint>& collocation, double frequency_hz, double source_strength, double sound_speed_mps=343.0, double density=1.2) const; };
struct IgaReport { std::vector<double> deflection_m; double tip_deflection_m=0.0, strain_energy_j=0.0; };
class IsogeometricBeamSolver { public: [[nodiscard]] IgaReport solve_cantilever(std::size_t control_points, double length_m, double ei_nm2, double tip_load_n) const; };

struct TireParticleState { double airborne_kg=0.0, road_kg=0.0, soil_kg=0.0, water_kg=0.0, captured_kg=0.0; };
struct TireParticleReport { TireParticleState state; double mass_residual_kg=0.0, inhalation_exposure_kg=0.0, water_release_kg=0.0; };
class TireParticleEnvironmentalFate { public: [[nodiscard]] TireParticleReport advance(TireParticleState state, double emitted_kg, double wind_mps, double rainfall_m_s, double capture_efficiency, double population_exposure_factor, double dt_s) const; };

enum class CompetitionDiscipline { FormulaE, Rally, MotoGp, DragRacing };
struct CompetitionState { double elapsed_s=0.0, energy_mj=0.0, tire_wear=0.0, damage=0.0, position=1.0, penalty_s=0.0; };
struct CompetitionInput { double distance_m=0.0, speed_mps=0.0, throttle=0.0, braking=0.0, surface_grip=1.0, weather=0.0, attack_mode=0.0; };
struct CompetitionReport { CompetitionState state; double score=0.0, reliability=1.0; std::string classification; };
class ExpandedMotorsportPlatform { public: [[nodiscard]] CompetitionReport advance(CompetitionDiscipline discipline, CompetitionState state, const CompetitionInput& input, double dt_s) const; };

} // namespace aesim::advanced

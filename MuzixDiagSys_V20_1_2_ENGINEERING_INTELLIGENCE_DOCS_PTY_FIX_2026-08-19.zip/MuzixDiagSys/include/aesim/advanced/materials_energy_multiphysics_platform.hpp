#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

using Vector3d = std::array<double, 3>;
using DenseMatrix = std::vector<std::vector<double>>;

// -----------------------------------------------------------------------------
// Mesh-free SPH / MPM / DEM multiphysics.
// -----------------------------------------------------------------------------

enum class MeshFreeMethod { Sph, Mpm, Dem };
enum class ParticleBoundaryMode { Reflective, Periodic, Open };

struct MeshFreeParticle {
    std::uint64_t id = 0;
    std::string material_id;
    Vector3d position_m{};
    Vector3d velocity_m_s{};
    double mass_kg = 0.0;
    double density_kg_m3 = 0.0;
    double pressure_pa = 0.0;
    double temperature_k = 293.15;
    double radius_m = 0.001;
    double equivalent_plastic_strain = 0.0;
    double damage = 0.0;
    void validate() const;
};

struct SphMaterialModel {
    std::string id;
    double reference_density_kg_m3 = 1000.0;
    double bulk_modulus_pa = 2.2e9;
    double dynamic_viscosity_pa_s = 1.0e-3;
    double speed_of_sound_m_s = 1480.0;
    double heat_capacity_j_kg_k = 4180.0;
    double thermal_conductivity_w_m_k = 0.6;
    double surface_tension_n_m = 0.0;
    void validate() const;
};

struct MpmMaterialModel {
    std::string id;
    double reference_density_kg_m3 = 2700.0;
    double young_modulus_pa = 70.0e9;
    double poisson_ratio = 0.33;
    double yield_stress_pa = 250.0e6;
    double isotropic_hardening_pa = 1.0e9;
    double heat_capacity_j_kg_k = 900.0;
    double taylor_quinney = 0.9;
    void validate() const;
};

struct DemMaterialModel {
    std::string id;
    double density_kg_m3 = 2500.0;
    double normal_stiffness_n_m = 1.0e6;
    double tangential_stiffness_n_m = 5.0e5;
    double restitution = 0.5;
    double friction = 0.5;
    double rolling_friction = 0.02;
    double cohesion_pa = 0.0;
    void validate() const;
};

struct MeshFreeDomain {
    Vector3d minimum_m{};
    Vector3d maximum_m{1.0, 1.0, 1.0};
    ParticleBoundaryMode boundary_mode = ParticleBoundaryMode::Reflective;
    void validate() const;
};

struct MeshFreeSimulationConfig {
    double time_step_s = 1.0e-5;
    std::size_t steps = 1;
    std::size_t record_stride = 1;
    double smoothing_length_m = 0.01;
    double grid_spacing_m = 0.01;
    Vector3d gravity_m_s2{0.0, 0.0, -9.80665};
    MeshFreeDomain domain;
    double velocity_damping_per_s = 0.0;
    void validate() const;
};

struct ParticleFrameSummary {
    double time_s = 0.0;
    Vector3d center_of_mass_m{};
    Vector3d total_momentum_kg_m_s{};
    double kinetic_energy_j = 0.0;
    double internal_energy_j = 0.0;
    double maximum_pressure_pa = 0.0;
    double maximum_temperature_k = 0.0;
    std::size_t active_contacts = 0;
};

struct MeshFreeSimulationResult {
    MeshFreeMethod method = MeshFreeMethod::Sph;
    std::vector<MeshFreeParticle> particles;
    std::vector<ParticleFrameSummary> frames;
    double initial_mass_kg = 0.0;
    double final_mass_kg = 0.0;
    double maximum_mass_error_fraction = 0.0;
    double maximum_penetration_m = 0.0;
    std::size_t plastic_particles = 0;
    bool stable = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_particles = false) const;
};

class MeshFreeMultiphysicsLaboratory {
public:
    [[nodiscard]] MeshFreeSimulationResult simulate_sph(
        const std::vector<MeshFreeParticle>& particles,
        const std::map<std::string, SphMaterialModel>& materials,
        const MeshFreeSimulationConfig& config) const;
    [[nodiscard]] MeshFreeSimulationResult simulate_mpm(
        const std::vector<MeshFreeParticle>& particles,
        const std::map<std::string, MpmMaterialModel>& materials,
        const MeshFreeSimulationConfig& config) const;
    [[nodiscard]] MeshFreeSimulationResult simulate_dem(
        const std::vector<MeshFreeParticle>& particles,
        const std::map<std::string, DemMaterialModel>& materials,
        const MeshFreeSimulationConfig& config) const;
};

// -----------------------------------------------------------------------------
// Integrated computational materials engineering.
// -----------------------------------------------------------------------------

struct AlloyComposition {
    std::string alloy_id;
    std::map<std::string, double> mass_fraction;
    void validate() const;
};

struct ThermodynamicPhaseModel {
    std::string id;
    std::map<std::string, double> preferred_composition;
    double reference_gibbs_j_mol = 0.0;
    double entropy_j_mol_k = 0.0;
    double heat_capacity_j_mol_k = 25.0;
    double composition_penalty_j_mol = 2.0e4;
    double nucleation_barrier_j_mol = 0.0;
    double reference_diffusivity_m2_s = 1.0e-15;
    double diffusion_activation_j_mol = 1.0e5;
    double strengthening_coefficient_pa = 0.0;
    void validate() const;
};

struct HeatTreatmentSegment {
    double temperature_k = 293.15;
    double duration_s = 0.0;
    double cooling_rate_k_s = 0.0;
    double applied_strain_rate_s_inv = 0.0;
    void validate() const;
};

struct MicrostructureState {
    double time_s = 0.0;
    double temperature_k = 293.15;
    std::map<std::string, double> phase_fraction;
    double grain_size_m = 20.0e-6;
    double precipitate_radius_m = 1.0e-9;
    double precipitate_volume_fraction = 0.0;
    double dislocation_density_m2 = 1.0e12;
    double porosity_fraction = 0.0;
    double yield_strength_pa = 0.0;
    double ultimate_strength_pa = 0.0;
    double hardness_pa = 0.0;
    double thermal_conductivity_w_m_k = 0.0;
    double electrical_conductivity_s_m = 0.0;
};

struct IcmeProcessConfig {
    double initial_grain_size_m = 20.0e-6;
    double initial_dislocation_density_m2 = 1.0e12;
    double initial_porosity_fraction = 0.0;
    double matrix_friction_stress_pa = 30.0e6;
    double hall_petch_pa_sqrt_m = 0.35e6;
    double shear_modulus_pa = 26.0e9;
    double burgers_vector_m = 0.286e-9;
    double dislocation_strength_factor = 0.3;
    double grain_growth_prefactor_m2_s = 1.0e-10;
    double grain_growth_activation_j_mol = 1.2e5;
    double precipitation_prefactor_s_inv = 1.0e4;
    double precipitation_activation_j_mol = 8.0e4;
    void validate() const;
};

struct IcmeResult {
    AlloyComposition composition;
    std::vector<MicrostructureState> history;
    MicrostructureState final_state;
    double equilibrium_residual = 0.0;
    bool converged = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class IntegratedComputationalMaterialsEngineeringLab {
public:
    [[nodiscard]] std::map<std::string, double> equilibrium_phase_fractions(
        const AlloyComposition& composition,
        const std::vector<ThermodynamicPhaseModel>& phases,
        double temperature_k) const;
    [[nodiscard]] IcmeResult simulate_process(
        const AlloyComposition& composition,
        const std::vector<ThermodynamicPhaseModel>& phases,
        const std::vector<HeatTreatmentSegment>& schedule,
        const IcmeProcessConfig& config = {}) const;
};

// -----------------------------------------------------------------------------
// Manufacturing-process physics and as-built digital twin.
// -----------------------------------------------------------------------------

enum class ManufacturingProcessKind {
    LaserPowderBedFusion,
    DirectedEnergyDeposition,
    Casting,
    Forging,
    Welding,
    Machining,
    CompositeCure,
    HeatTreatment,
    ShotPeening
};

struct ManufacturingMaterialModel {
    std::string id;
    double density_kg_m3 = 7800.0;
    double heat_capacity_j_kg_k = 500.0;
    double thermal_conductivity_w_m_k = 25.0;
    double solidus_temperature_k = 1700.0;
    double liquidus_temperature_k = 1800.0;
    double latent_heat_j_kg = 2.5e5;
    double young_modulus_pa = 200.0e9;
    double yield_stress_pa = 400.0e6;
    double thermal_expansion_per_k = 12.0e-6;
    double shrinkage_fraction = 0.02;
    void validate() const;
};

struct ManufacturingProcessStep {
    ManufacturingProcessKind kind = ManufacturingProcessKind::HeatTreatment;
    double duration_s = 0.0;
    double source_power_w = 0.0;
    double travel_speed_m_s = 0.0;
    double path_length_m = 0.0;
    double layer_thickness_m = 0.0;
    double ambient_temperature_k = 293.15;
    double target_temperature_k = 293.15;
    double pressure_pa = 101325.0;
    double energy_absorptivity = 0.7;
    double material_removal_fraction = 0.0;
    Vector3d source_origin_m{};
    Vector3d source_direction{1.0, 0.0, 0.0};
    void validate() const;
};

struct AsBuiltVoxel {
    Vector3d nominal_position_m{};
    Vector3d displacement_m{};
    double peak_temperature_k = 293.15;
    double cooling_rate_k_s = 0.0;
    double melt_fraction = 0.0;
    double porosity_fraction = 0.0;
    double residual_von_mises_stress_pa = 0.0;
    double local_density_kg_m3 = 0.0;
    double quality_score = 1.0;
    std::vector<std::string> defects;
};

struct ManufacturingSimulationConfig {
    double voxel_volume_m3 = 1.0e-9;
    double convection_w_m2_k = 15.0;
    double radiation_emissivity = 0.5;
    double consolidation_efficiency = 0.98;
    double maximum_allowed_porosity = 0.01;
    double maximum_allowed_distortion_m = 0.001;
    std::size_t thermal_substeps = 20;
    void validate() const;
};

struct AsBuiltDigitalTwin {
    std::string component_id;
    std::vector<AsBuiltVoxel> voxels;
    double maximum_distortion_m = 0.0;
    double maximum_residual_stress_pa = 0.0;
    double mean_porosity_fraction = 0.0;
    double predicted_yield_strength_pa = 0.0;
    bool inspection_passed = false;
    std::vector<std::string> process_findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_voxels = false) const;
};

class ManufacturingProcessPhysicsLab {
public:
    [[nodiscard]] AsBuiltDigitalTwin simulate(
        const std::string& component_id,
        const std::vector<Vector3d>& nominal_voxel_centers,
        const ManufacturingMaterialModel& material,
        const std::vector<ManufacturingProcessStep>& process_chain,
        const ManufacturingSimulationConfig& config = {}) const;
};

// -----------------------------------------------------------------------------
// Switching-level power electronics and semiconductor reliability.
// -----------------------------------------------------------------------------

enum class SemiconductorTechnology { SiliconIgbt, SiliconMosfet, SiliconCarbideMosfet, GalliumNitrideHemt };

struct SwitchingDeviceModel {
    std::string id;
    SemiconductorTechnology technology = SemiconductorTechnology::SiliconCarbideMosfet;
    double on_resistance_ohm = 5.0e-3;
    double threshold_voltage_v = 4.0;
    double transconductance_s = 20.0;
    double output_capacitance_f = 500.0e-12;
    double gate_charge_c = 100.0e-9;
    double reverse_recovery_charge_c = 50.0e-9;
    double turn_on_energy_j_at_reference = 1.0e-3;
    double turn_off_energy_j_at_reference = 1.0e-3;
    double reference_current_a = 100.0;
    double reference_voltage_v = 400.0;
    double junction_to_case_k_w = 0.2;
    double thermal_capacitance_j_k = 5.0;
    double maximum_junction_temperature_k = 448.15;
    double power_cycle_exponent = 5.0;
    void validate() const;
};

struct ThreePhaseInverterModel {
    SwitchingDeviceModel switch_model;
    double dc_link_voltage_v = 800.0;
    double dc_link_capacitance_f = 1.0e-3;
    double dc_link_esr_ohm = 2.0e-3;
    double phase_resistance_ohm = 0.05;
    double phase_inductance_h = 300.0e-6;
    double back_emf_peak_v = 200.0;
    double electrical_frequency_hz = 200.0;
    double switching_frequency_hz = 20000.0;
    double modulation_index = 0.8;
    double dead_time_s = 500.0e-9;
    double gate_resistance_ohm = 2.0;
    double parasitic_inductance_h = 10.0e-9;
    double case_temperature_k = 333.15;
    void validate() const;
};

struct SwitchingSimulationConfig {
    double duration_s = 0.002;
    double time_step_s = 50.0e-9;
    std::size_t record_stride = 20;
    double initial_phase_current_a = 0.0;
    void validate(const ThreePhaseInverterModel& model) const;
};

struct PowerElectronicsSample {
    double time_s = 0.0;
    std::array<double, 3> phase_current_a{};
    std::array<double, 3> phase_voltage_v{};
    double dc_link_voltage_v = 0.0;
    double common_mode_voltage_v = 0.0;
    double junction_temperature_k = 0.0;
};

struct PowerElectronicsReliability {
    double accumulated_power_cycle_damage = 0.0;
    double estimated_cycles_to_failure = 0.0;
    double maximum_junction_temperature_k = 0.0;
    double junction_temperature_swing_k = 0.0;
    double insulation_stress_index = 0.0;
    bool thermal_limit_exceeded = false;
};

struct SwitchingPowerElectronicsResult {
    std::vector<PowerElectronicsSample> waveform;
    double average_output_power_w = 0.0;
    double conduction_loss_w = 0.0;
    double switching_loss_w = 0.0;
    double dc_link_loss_w = 0.0;
    double efficiency = 0.0;
    double phase_current_thd = 0.0;
    double common_mode_rms_v = 0.0;
    double maximum_voltage_overshoot_v = 0.0;
    PowerElectronicsReliability reliability;
    bool numerically_stable = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_waveform = false) const;
};

class SwitchingLevelPowerElectronicsLab {
public:
    [[nodiscard]] SwitchingPowerElectronicsResult simulate_three_phase_inverter(
        const ThreePhaseInverterModel& model,
        const SwitchingSimulationConfig& config = {}) const;
};

// -----------------------------------------------------------------------------
// Battery impedance, manufacturing and diagnostic tomography.
// -----------------------------------------------------------------------------

struct ElectrodeManufacturingProcess {
    double active_material_fraction = 0.94;
    double conductive_additive_fraction = 0.03;
    double binder_fraction = 0.03;
    double solids_fraction = 0.60;
    double coating_thickness_m = 70.0e-6;
    double drying_temperature_k = 373.15;
    double drying_time_s = 3600.0;
    double calender_pressure_pa = 100.0e6;
    double particle_radius_m = 5.0e-6;
    double initial_porosity = 0.45;
    double wetting_time_s = 7200.0;
    double formation_c_rate = 0.1;
    void validate() const;
};

struct ManufacturedCellState {
    double porosity = 0.0;
    double tortuosity = 0.0;
    double effective_ionic_conductivity_s_m = 0.0;
    double effective_electronic_conductivity_s_m = 0.0;
    double active_surface_area_m2_m3 = 0.0;
    double contact_resistance_ohm = 0.0;
    double capacity_ah = 0.0;
    double thickness_nonuniformity = 0.0;
    double wetting_fraction = 0.0;
    double formation_loss_fraction = 0.0;
    std::vector<std::string> defects;
};

struct BatteryImpedanceModel {
    double series_resistance_ohm = 1.0e-3;
    double charge_transfer_resistance_ohm = 2.0e-3;
    double double_layer_capacitance_f = 5000.0;
    double sei_resistance_ohm = 5.0e-4;
    double sei_capacitance_f = 1000.0;
    double warburg_coefficient_ohm_sqrt_s = 1.0e-3;
    double diffusion_time_s = 100.0;
    double inductance_h = 50.0e-9;
    double temperature_k = 298.15;
    double state_of_charge = 0.5;
    void validate() const;
};

struct BatteryImpedancePoint {
    double frequency_hz = 0.0;
    std::complex<double> impedance_ohm{};
    double magnitude_ohm = 0.0;
    double phase_deg = 0.0;
};

struct DistributionRelaxationPoint {
    double relaxation_time_s = 0.0;
    double resistance_density_ohm = 0.0;
};

struct CellImpedanceObservation {
    std::string cell_id;
    std::vector<BatteryImpedancePoint> spectrum;
};

struct CellDiagnosticResult {
    std::string cell_id;
    double ohmic_resistance_ohm = 0.0;
    double polarization_resistance_ohm = 0.0;
    double diffusion_indicator = 0.0;
    double anomaly_score = 0.0;
    std::vector<std::string> diagnosed_faults;
};

struct BatteryImpedanceManufacturingResult {
    ManufacturedCellState manufactured_state;
    std::vector<BatteryImpedancePoint> spectrum;
    std::vector<DistributionRelaxationPoint> relaxation_distribution;
    std::vector<CellDiagnosticResult> pack_diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_spectrum = false) const;
};

class BatteryImpedanceManufacturingLaboratory {
public:
    [[nodiscard]] ManufacturedCellState manufacture_electrode(
        const ElectrodeManufacturingProcess& process,
        double theoretical_capacity_ah,
        double electrolyte_conductivity_s_m = 1.0) const;
    [[nodiscard]] std::vector<BatteryImpedancePoint> impedance_sweep(
        const BatteryImpedanceModel& model,
        double minimum_frequency_hz,
        double maximum_frequency_hz,
        std::size_t points) const;
    [[nodiscard]] std::vector<DistributionRelaxationPoint> invert_relaxation_distribution(
        const std::vector<BatteryImpedancePoint>& spectrum,
        std::size_t relaxation_points = 40,
        double regularization = 1.0e-4) const;
    [[nodiscard]] std::vector<CellDiagnosticResult> diagnose_pack(
        const std::vector<CellImpedanceObservation>& observations) const;
    [[nodiscard]] BatteryImpedanceManufacturingResult run(
        const ElectrodeManufacturingProcess& process,
        double theoretical_capacity_ah,
        const BatteryImpedanceModel& impedance_model,
        double minimum_frequency_hz,
        double maximum_frequency_hz,
        std::size_t frequency_points,
        const std::vector<CellImpedanceObservation>& pack_observations = {}) const;
};

// -----------------------------------------------------------------------------
// Environmental corrosion, ingress and coupled degradation.
// -----------------------------------------------------------------------------

struct EnvironmentalMaterialModel {
    std::string id;
    double open_circuit_potential_v = 0.0;
    double corrosion_current_density_a_m2 = 1.0e-6;
    double tafel_slope_v = 0.12;
    double molar_mass_kg_mol = 0.055845;
    double valence = 2.0;
    double density_kg_m3 = 7800.0;
    double coating_thickness_m = 0.0;
    double coating_permeability_m2_s = 1.0e-16;
    double base_electrical_resistance_ohm = 1.0e-3;
    double stress_corrosion_threshold_pa = 1.0e9;
    void validate() const;
};

struct IngressCompartment {
    std::string id;
    double free_volume_m3 = 0.001;
    double exposed_area_m2 = 0.01;
    double initial_water_volume_m3 = 0.0;
    double initial_salt_mass_kg = 0.0;
    double temperature_k = 293.15;
    double relative_humidity = 0.5;
    double mechanical_stress_pa = 0.0;
    std::string material_id;
    void validate() const;
};

struct IngressPath {
    std::string from;
    std::string to;
    double hydraulic_conductance_m3_pa_s = 0.0;
    double capillary_radius_m = 0.0;
    double diffusion_area_m2 = 0.0;
    double diffusion_length_m = 0.001;
    double seal_damage = 0.0;
    void validate() const;
};

struct EnvironmentalExposure {
    double duration_s = 0.0;
    double ambient_temperature_k = 293.15;
    double ambient_relative_humidity = 0.5;
    double external_water_pressure_pa = 0.0;
    double external_salt_concentration_kg_m3 = 0.0;
    double ultraviolet_index = 0.0;
    double vibration_damage_rate_s_inv = 0.0;
    void validate() const;
};

struct CompartmentDegradationState {
    std::string id;
    double water_volume_m3 = 0.0;
    double salt_concentration_kg_m3 = 0.0;
    double corrosion_depth_m = 0.0;
    double coating_damage = 0.0;
    double seal_damage = 0.0;
    double electrical_resistance_ohm = 0.0;
    double isolation_resistance_ohm = 1.0e12;
    double stress_corrosion_damage = 0.0;
    bool water_ingress_detected = false;
};

struct EnvironmentalDegradationResult {
    std::vector<CompartmentDegradationState> compartments;
    double total_corroded_mass_kg = 0.0;
    double maximum_corrosion_depth_m = 0.0;
    double minimum_isolation_resistance_ohm = 0.0;
    bool high_voltage_isolation_failure = false;
    bool structural_corrosion_risk = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EnvironmentalCorrosionWaterIngressLab {
public:
    [[nodiscard]] EnvironmentalDegradationResult simulate(
        const std::vector<IngressCompartment>& compartments,
        const std::vector<IngressPath>& paths,
        const std::map<std::string, EnvironmentalMaterialModel>& materials,
        const std::vector<EnvironmentalExposure>& exposure_history,
        double integration_step_s = 60.0) const;
};

// -----------------------------------------------------------------------------
// Hydrogen and cryogenic-fuel storage, transfer and material integrity.
// -----------------------------------------------------------------------------

struct HydrogenTankModel {
    std::string id;
    double internal_volume_m3 = 0.1;
    double internal_radius_m = 0.25;
    double wall_thickness_m = 0.02;
    double liner_thickness_m = 0.003;
    double composite_hoop_strength_pa = 2.0e9;
    double liner_yield_strength_pa = 300.0e6;
    double heat_transfer_area_m2 = 1.0;
    double overall_heat_transfer_w_m2_k = 5.0;
    double maximum_pressure_pa = 70.0e6;
    double initial_mass_kg = 3.0;
    double initial_temperature_k = 293.15;
    double initial_liquid_fraction = 0.0;
    double permeation_coefficient_kg_m_s_pa = 1.0e-17;
    double liner_hydrogen_diffusivity_m2_s = 1.0e-12;
    void validate() const;
};

struct HydrogenOperatingScenario {
    double duration_s = 60.0;
    double time_step_s = 0.05;
    double ambient_temperature_k = 293.15;
    double inlet_mass_flow_kg_s = 0.0;
    double inlet_temperature_k = 293.15;
    double outlet_mass_flow_kg_s = 0.0;
    double leak_orifice_area_m2 = 0.0;
    double downstream_pressure_pa = 101325.0;
    double relief_pressure_pa = 0.0;
    bool cryogenic = false;
    void validate(const HydrogenTankModel& tank) const;
};

struct HydrogenTankSample {
    double time_s = 0.0;
    double mass_kg = 0.0;
    double pressure_pa = 0.0;
    double temperature_k = 0.0;
    double liquid_fraction = 0.0;
    double boil_off_rate_kg_s = 0.0;
    double leak_rate_kg_s = 0.0;
    double permeation_rate_kg_s = 0.0;
    double hoop_stress_pa = 0.0;
    double hydrogen_concentration_liner = 0.0;
};

struct HydrogenCryogenicFuelResult {
    std::vector<HydrogenTankSample> history;
    double released_hydrogen_kg = 0.0;
    double permeated_hydrogen_kg = 0.0;
    double maximum_pressure_pa = 0.0;
    double maximum_hoop_stress_pa = 0.0;
    double composite_margin = 0.0;
    double liner_margin = 0.0;
    double embrittlement_damage = 0.0;
    bool relief_activated = false;
    bool pressure_limit_exceeded = false;
    bool material_limit_exceeded = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};

class HydrogenCryogenicFuelLaboratory {
public:
    [[nodiscard]] double peng_robinson_pressure_pa(double mass_kg, double volume_m3, double temperature_k) const;
    [[nodiscard]] HydrogenCryogenicFuelResult simulate_tank(
        const HydrogenTankModel& tank,
        const HydrogenOperatingScenario& scenario) const;
};

// -----------------------------------------------------------------------------
// Discrete adjoint sensitivity and density-based topology optimization.
// -----------------------------------------------------------------------------

struct DiscreteAdjointProblem {
    std::vector<double> design;
    std::vector<double> right_hand_side;
    std::function<DenseMatrix(const std::vector<double>&)> system_matrix;
    std::function<std::vector<DenseMatrix>(const std::vector<double>&)> system_matrix_derivatives;
    std::function<std::vector<double>(const std::vector<double>&, const std::vector<double>&)> objective_state_gradient;
    std::function<std::vector<double>(const std::vector<double>&, const std::vector<double>&)> objective_direct_design_gradient;
    std::function<double(const std::vector<double>&, const std::vector<double>&)> objective;
};

struct DiscreteAdjointResult {
    std::vector<double> state;
    std::vector<double> adjoint;
    std::vector<double> gradient;
    double objective = 0.0;
    double primal_residual_norm = 0.0;
    double adjoint_residual_norm = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_vectors = false) const;
};

struct TopologyLoad {
    std::size_t node = 0;
    double force_x_n = 0.0;
    double force_y_n = 0.0;
};

struct TopologyOptimizationProblem {
    std::size_t elements_x = 10;
    std::size_t elements_y = 5;
    double element_width_m = 0.01;
    double element_height_m = 0.01;
    double thickness_m = 0.001;
    double young_modulus_pa = 70.0e9;
    double poisson_ratio = 0.3;
    double minimum_density = 1.0e-3;
    double volume_fraction = 0.5;
    double penalization = 3.0;
    double filter_radius_elements = 1.5;
    std::size_t maximum_iterations = 50;
    double convergence_tolerance = 1.0e-3;
    double move_limit = 0.2;
    std::set<std::size_t> fixed_nodes;
    std::vector<TopologyLoad> loads;
    void validate() const;
};

struct TopologyOptimizationResult {
    std::size_t elements_x = 0;
    std::size_t elements_y = 0;
    std::vector<double> density;
    std::vector<double> displacement;
    std::vector<double> compliance_history;
    std::vector<double> maximum_density_change_history;
    double final_compliance_j = 0.0;
    double achieved_volume_fraction = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_fields = false) const;
};

class AdjointTopologyOptimizationLab {
public:
    [[nodiscard]] DiscreteAdjointResult evaluate_discrete_adjoint(const DiscreteAdjointProblem& problem) const;
    [[nodiscard]] TopologyOptimizationResult optimize(const TopologyOptimizationProblem& problem) const;
};

// -----------------------------------------------------------------------------
// Advanced uncertainty quantification and rare-event computing.
// -----------------------------------------------------------------------------

enum class RandomVariableDistribution { Uniform, Normal, Lognormal };

struct RandomVariableDefinition {
    std::string name;
    RandomVariableDistribution distribution = RandomVariableDistribution::Normal;
    double parameter_a = 0.0; // uniform lower, normal/lognormal mean
    double parameter_b = 1.0; // uniform upper, normal/lognormal standard deviation
    void validate() const;
};

struct PolynomialChaosModel {
    std::vector<RandomVariableDefinition> variables;
    std::vector<std::vector<unsigned>> multi_indices;
    std::vector<double> coefficients;
    unsigned order = 0;
    double training_rmse = 0.0;
    double mean = 0.0;
    double variance = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] double evaluate(const std::vector<double>& physical_sample) const;
    [[nodiscard]] doc::Value to_document(bool include_coefficients = false) const;
};

struct AdvancedRareEventOptions {
    std::size_t samples = 10000;
    std::size_t adaptation_iterations = 4;
    std::size_t subset_levels = 8;
    double subset_probability = 0.1;
    std::uint64_t seed = 5489u;
    void validate() const;
};

struct AdvancedRareEventResult {
    double failure_probability = 0.0;
    double coefficient_of_variation = 0.0;
    double reliability_index = 0.0;
    std::vector<double> importance_mean_shift;
    std::vector<double> intermediate_thresholds;
    std::vector<double> first_order_sobol_indices;
    std::vector<double> total_sobol_indices;
    std::size_t model_evaluations = 0;
    std::string method;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AdvancedUncertaintyRareEventLab {
public:
    using ScalarModel = std::function<double(const std::vector<double>&)>;
    [[nodiscard]] PolynomialChaosModel fit_polynomial_chaos(
        const std::vector<RandomVariableDefinition>& variables,
        const ScalarModel& model,
        unsigned order = 3,
        std::size_t training_samples = 500,
        std::uint64_t seed = 5489u) const;
    [[nodiscard]] AdvancedRareEventResult estimate_importance_sampling(
        const std::vector<RandomVariableDefinition>& variables,
        const ScalarModel& limit_state,
        const AdvancedRareEventOptions& options = {}) const;
    [[nodiscard]] AdvancedRareEventResult estimate_subset_simulation(
        const std::vector<RandomVariableDefinition>& variables,
        const ScalarModel& limit_state,
        const AdvancedRareEventOptions& options = {}) const;
    [[nodiscard]] std::pair<std::vector<double>, std::vector<double>> sobol_indices(
        const std::vector<RandomVariableDefinition>& variables,
        const ScalarModel& model,
        std::size_t samples = 4096,
        std::uint64_t seed = 5489u) const;
};

// -----------------------------------------------------------------------------
// High-fidelity finite-volume reacting-flow combustion.
// -----------------------------------------------------------------------------

struct CombustionReactionModel {
    double pre_exponential_factor_s_inv = 1.0e9;
    double activation_energy_j_mol = 1.2e5;
    double fuel_order = 1.0;
    double oxygen_order = 1.0;
    double stoichiometric_oxygen_fuel_mass_ratio = 3.5;
    double heat_release_j_kg_fuel = 44.0e6;
    double no_pre_exponential_s_inv = 1.0e7;
    double no_activation_energy_j_mol = 2.5e5;
    double soot_formation_s_inv = 50.0;
    double soot_oxidation_s_inv = 20.0;
    void validate() const;
};

struct ReactingFlowCell {
    double density_kg_m3 = 1.2;
    double velocity_m_s = 0.0;
    double pressure_pa = 101325.0;
    double temperature_k = 300.0;
    double fuel_mass_fraction = 0.0;
    double oxygen_mass_fraction = 0.233;
    double product_mass_fraction = 0.0;
    double nitrogen_mass_fraction = 0.767;
    double no_mass_fraction = 0.0;
    double soot_mass_fraction = 0.0;
    double turbulence_kinetic_energy_m2_s2 = 0.0;
    double turbulence_dissipation_m2_s3 = 1.0;
    double droplet_fuel_mass_fraction = 0.0;
    double droplet_diameter_m = 20.0e-6;
    void validate() const;
};

struct ReactingFlowBoundary {
    ReactingFlowCell inlet;
    double outlet_pressure_pa = 101325.0;
};

struct ReactingFlowConfig {
    double domain_length_m = 0.5;
    double duration_s = 0.01;
    double time_step_s = 1.0e-6;
    double species_diffusivity_m2_s = 2.0e-5;
    double thermal_conductivity_w_m_k = 0.05;
    double heat_capacity_j_kg_k = 1100.0;
    double dynamic_viscosity_pa_s = 2.0e-5;
    double turbulent_schmidt = 0.7;
    double turbulent_prandtl = 0.9;
    double droplet_evaporation_constant_m2_s = 1.0e-8;
    std::size_t record_stride = 100;
    void validate(std::size_t cells) const;
};

struct CombustionFrameSummary {
    double time_s = 0.0;
    double total_heat_release_w = 0.0;
    double maximum_temperature_k = 0.0;
    double fuel_conversion_fraction = 0.0;
    double total_no_mass_kg = 0.0;
    double total_soot_mass_kg = 0.0;
    double pressure_drop_pa = 0.0;
};

struct ReactingFlowCombustionResult {
    std::vector<ReactingFlowCell> final_cells;
    std::vector<CombustionFrameSummary> history;
    double total_fuel_consumed_kg = 0.0;
    double total_heat_released_j = 0.0;
    double no_emissions_kg = 0.0;
    double soot_emissions_kg = 0.0;
    double maximum_temperature_k = 0.0;
    double mass_conservation_error_fraction = 0.0;
    bool stable = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_cells = false) const;
};

class HighFidelityReactingFlowCombustionLab {
public:
    [[nodiscard]] ReactingFlowCombustionResult simulate_1d(
        const std::vector<ReactingFlowCell>& initial_cells,
        const ReactingFlowBoundary& boundary,
        const CombustionReactionModel& chemistry,
        const ReactingFlowConfig& config = {}) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Vehicle-cloud MLOps and continuous AI assurance.
// -----------------------------------------------------------------------------

struct AiDatasetAsset {
    std::string id;
    std::string version;
    std::string uri;
    std::uint64_t samples = 0;
    std::map<std::string, std::string> schema;
    std::map<std::string, double> statistics;
    std::vector<std::string> licenses;
    std::vector<std::string> parent_assets;
    std::string sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct AiModelAsset {
    std::string id;
    std::string version;
    std::string format;
    std::string artifact_uri;
    std::vector<std::string> dataset_ids;
    std::map<std::string, std::string> parameters;
    std::map<std::string, double> training_metrics;
    std::string sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct AiEvaluationSample {
    std::string slice;
    double prediction = 0.0;
    double target = 0.0;
    double confidence = 1.0;
    bool correct = true;
    bool safety_violation = false;
};

struct AiAssuranceRequirement {
    std::string id;
    std::string slice = "*";
    std::string metric; // accuracy, rmse, calibration_error, violation_rate, coverage
    std::string comparison; // >=, <=
    double threshold = 0.0;
};

struct AiSliceMetrics {
    std::string slice;
    std::size_t samples = 0;
    double accuracy = 0.0;
    double rmse = 0.0;
    double calibration_error = 0.0;
    double safety_violation_rate = 0.0;
    double mean_confidence = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct AiAssuranceVerdict {
    std::string requirement_id;
    std::string slice;
    std::string metric;
    double observed = 0.0;
    double threshold = 0.0;
    bool passed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct AiAssuranceReport {
    std::string model_id;
    std::string model_sha256;
    std::vector<AiSliceMetrics> slices;
    std::vector<AiAssuranceVerdict> verdicts;
    bool passed = false;
    std::vector<std::string> invalidated_evidence;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct AiDriftReport {
    std::string feature;
    double population_stability_index = 0.0;
    double standardized_mean_shift = 0.0;
    double maximum_cdf_distance = 0.0;
    bool drift_detected = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

enum class AiDeploymentStage { Registered, Shadow, Canary, Cohort, Fleet, RolledBack };

struct AiDeploymentPolicy {
    double maximum_violation_rate = 0.001;
    double minimum_accuracy = 0.95;
    double maximum_drift_psi = 0.2;
    std::vector<double> cohort_fractions{0.01, 0.1, 0.5, 1.0};
    std::size_t minimum_observations_per_stage = 100;
};

struct AiDeploymentRecord {
    std::string deployment_id;
    std::string model_id;
    AiDeploymentStage stage = AiDeploymentStage::Registered;
    std::size_t cohort_index = 0;
    double deployed_fraction = 0.0;
    std::size_t observations = 0;
    double accuracy = 0.0;
    double violation_rate = 0.0;
    double drift_psi = 0.0;
    std::vector<std::string> history;
    std::string state_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class VehicleCloudMlopsPlatform {
public:
    void register_dataset(AiDatasetAsset dataset);
    void register_model(AiModelAsset model);
    [[nodiscard]] AiAssuranceReport evaluate(
        const std::string& model_id,
        const std::vector<AiEvaluationSample>& samples,
        const std::vector<AiAssuranceRequirement>& requirements,
        const std::vector<std::string>& dependent_evidence = {}) const;
    [[nodiscard]] AiDriftReport detect_drift(
        const std::string& feature,
        const std::vector<double>& baseline,
        const std::vector<double>& current,
        std::size_t bins = 10,
        double psi_threshold = 0.2) const;
    [[nodiscard]] AiDeploymentRecord create_deployment(
        std::string deployment_id,
        const std::string& model_id,
        AiDeploymentPolicy policy = {});
    [[nodiscard]] AiDeploymentRecord observe_deployment(
        const std::string& deployment_id,
        std::size_t observations,
        double accuracy,
        double violation_rate,
        double drift_psi);
    [[nodiscard]] doc::Value registry() const;

private:
    std::map<std::string, AiDatasetAsset> datasets_;
    std::map<std::string, AiModelAsset> models_;
    std::map<std::string, AiDeploymentPolicy> policies_;
    std::map<std::string, AiDeploymentRecord> deployments_;
};

// -----------------------------------------------------------------------------
// Robotic automotive test-laboratory orchestration.
// -----------------------------------------------------------------------------

struct LaboratoryInstrument {
    std::string id;
    std::string type;
    std::string hostname; // empty selects deterministic in-process instrument mode
    std::uint16_t port = 5025;
    std::set<std::string> capabilities;
    std::map<std::string, double> state;
    double command_latency_s = 0.0;
};

struct LaboratoryResource {
    std::string id;
    std::size_t capacity = 1;
};

struct LaboratoryStep {
    std::string id;
    std::string instrument_id;
    std::string command;
    std::vector<std::string> dependencies;
    std::vector<std::string> resources;
    std::string interlock_expression;
    double timeout_s = 5.0;
    std::optional<double> expected_minimum;
    std::optional<double> expected_maximum;
};

struct LaboratoryStepResult {
    std::string id;
    bool executed = false;
    bool passed = false;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    std::string response;
    std::optional<double> measured_value;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

struct LaboratoryRunResult {
    bool passed = false;
    std::vector<LaboratoryStepResult> steps;
    std::map<std::string, std::map<std::string, double>> final_instrument_state;
    double elapsed_s = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RoboticTestLaboratoryOrchestrator {
public:
    void register_instrument(LaboratoryInstrument instrument);
    void register_resource(LaboratoryResource resource);
    [[nodiscard]] LaboratoryRunResult execute(
        const std::vector<LaboratoryStep>& steps,
        bool stop_on_failure = true);
    [[nodiscard]] static std::string scpi_query(
        const std::string& hostname,
        std::uint16_t port,
        const std::string& command,
        double timeout_s);

private:
    std::map<std::string, LaboratoryInstrument> instruments_;
    std::map<std::string, LaboratoryResource> resources_;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Embedded code generation and MIL/SIL/PIL/HIL equivalence
// -----------------------------------------------------------------------------

struct StateSpaceControllerSpecification {
    std::string name = "controller";
    std::vector<std::vector<double>> a;
    std::vector<std::vector<double>> b;
    std::vector<std::vector<double>> c;
    std::vector<std::vector<double>> d;
    std::vector<double> initial_state;
    std::vector<double> output_minimum;
    std::vector<double> output_maximum;
    double sample_time_s = 0.001;
    bool fixed_point = false;
    unsigned fixed_fraction_bits = 16;
    [[nodiscard]] static StateSpaceControllerSpecification from_document(const doc::Value& value);
    [[nodiscard]] doc::Value to_document() const;
};

struct GeneratedEmbeddedCode {
    std::string header;
    std::string source;
    std::string manifest;
    std::string source_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct ControllerTraceSample {
    double time_s = 0.0;
    std::vector<double> input;
    std::vector<double> output;
    std::vector<double> state;
};

struct EquivalenceStageTrace {
    std::string stage; // MIL, SIL, PIL, or HIL
    std::vector<ControllerTraceSample> samples;
};

struct EquivalenceResult {
    bool equivalent = true;
    std::string reference_stage;
    std::map<std::string, double> maximum_absolute_error;
    std::map<std::string, double> maximum_relative_error;
    std::map<std::string, std::size_t> mismatches;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EmbeddedControllerCodeGenerator {
public:
    [[nodiscard]] GeneratedEmbeddedCode generate(
        const StateSpaceControllerSpecification& specification) const;
    void write(const GeneratedEmbeddedCode& code, const std::string& directory,
               const std::string& base_name) const;
    [[nodiscard]] EquivalenceStageTrace execute_mil(
        const StateSpaceControllerSpecification& specification,
        const std::vector<std::vector<double>>& input_sequence) const;
    [[nodiscard]] EquivalenceStageTrace execute_generated_semantics(
        const StateSpaceControllerSpecification& specification,
        const std::vector<std::vector<double>>& input_sequence,
        const std::string& stage) const;
    [[nodiscard]] EquivalenceResult compare(
        const EquivalenceStageTrace& reference,
        const std::vector<EquivalenceStageTrace>& candidates,
        double absolute_tolerance,
        double relative_tolerance) const;
};

// -----------------------------------------------------------------------------
// Manufacturing and end-of-line digital factory
// -----------------------------------------------------------------------------

struct ManufacturingCharacteristic {
    std::string id;
    double nominal = 0.0;
    double lower_specification = -1.0e300;
    double upper_specification = 1.0e300;
    double process_sigma = 0.0;
    double measurement_sigma = 0.0;
    std::string unit = "1";
};

struct ManufacturingStation {
    std::string id;
    std::vector<ManufacturingCharacteristic> characteristics;
    double cycle_time_s = 0.0;
    double availability = 1.0;
    double defect_escape_probability = 0.0;
};

struct ManufacturedComponentRecord {
    std::string serial;
    std::string supplier_lot;
    std::map<std::string, double> measurements;
    std::vector<std::string> defects;
    bool passed_station = true;
    [[nodiscard]] doc::Value to_document() const;
};

struct EndOfLineRequirement {
    std::string id;
    std::string measurement;
    double minimum = -1.0e300;
    double maximum = 1.0e300;
};

struct DigitalFactoryResult {
    std::vector<ManufacturedComponentRecord> genealogy;
    std::map<std::string, double> cp;
    std::map<std::string, double> cpk;
    std::map<std::string, std::size_t> defect_pareto;
    std::size_t produced = 0;
    std::size_t first_pass_yield = 0;
    std::size_t escaped_defects = 0;
    double throughput_per_hour = 0.0;
    std::string genealogy_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ManufacturingDigitalFactory {
public:
    [[nodiscard]] DigitalFactoryResult simulate(
        const std::vector<ManufacturingStation>& stations,
        const std::vector<EndOfLineRequirement>& eol_requirements,
        std::size_t units,
        std::uint64_t seed) const;
};

// -----------------------------------------------------------------------------
// Fleet prognostics and federated digital twins
// -----------------------------------------------------------------------------

struct FleetVehicleTwin {
    std::string vehicle_id;
    std::string cohort;
    std::string software_version;
    double age_days = 0.0;
    double usage_hours = 0.0;
    double health_index = 1.0;
    std::map<std::string, double> telemetry;
    std::map<std::string, double> model_parameters;
};

struct PrognosticEstimate {
    std::string vehicle_id;
    double remaining_useful_life_hours = 0.0;
    double confidence_lower_hours = 0.0;
    double confidence_upper_hours = 0.0;
    double failure_probability_horizon = 0.0;
    bool anomaly = false;
    double anomaly_score = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct FederatedClientUpdate {
    std::string client_id;
    std::vector<double> parameters;
    std::size_t sample_count = 0;
    double validation_loss = 0.0;
};

struct FederatedAggregationResult {
    std::vector<double> parameters;
    std::vector<std::string> accepted_clients;
    std::vector<std::string> rejected_clients;
    double aggregate_validation_loss = 0.0;
    std::string model_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class FleetDigitalTwinPlatform {
public:
    void upsert(FleetVehicleTwin twin);
    [[nodiscard]] std::vector<PrognosticEstimate> estimate_prognostics(
        double failure_threshold,
        double horizon_hours,
        std::size_t bootstrap_samples,
        std::uint64_t seed) const;
    [[nodiscard]] FederatedAggregationResult federated_aggregate(
        const std::vector<FederatedClientUpdate>& updates,
        const std::string& method,
        double clipping_norm,
        double outlier_z_threshold) const;
    [[nodiscard]] doc::Value fleet_report() const;
private:
    std::map<std::string, FleetVehicleTwin> twins_;
};

} // namespace aesim::advanced

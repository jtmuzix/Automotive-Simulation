#pragma once

#include "aesim/professional/document.hpp"

#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class StudioRole { Viewer, Engineer, Reviewer, Approver, Administrator };

struct StudioUser {
    std::string id;
    std::string display_name;
    std::set<StudioRole> roles;
};

struct StudioArtifact {
    std::string id;
    std::string type;
    doc::Value content;
    std::string content_sha256;
    std::uint64_t revision = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct StudioCommit {
    std::string id;
    std::string branch;
    std::vector<std::string> parent_ids;
    std::string author_id;
    std::string message;
    std::map<std::string, StudioArtifact> artifacts;
    std::string created_utc;
    std::string commit_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct StudioComment {
    std::uint64_t sequence = 0;
    std::string artifact_id;
    std::string author_id;
    std::string text;
    bool resolved = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct StudioReview {
    std::string id;
    std::string commit_id;
    std::string reviewer_id;
    std::string verdict;
    std::string rationale;
    [[nodiscard]] doc::Value to_document() const;
};

struct StudioMergeResult {
    bool merged = false;
    std::string commit_id;
    std::vector<std::string> conflicts;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CollaborativeEngineeringStudio {
public:
    explicit CollaborativeEngineeringStudio(std::string project_id);
    void add_user(StudioUser user);
    void create_branch(const std::string& branch, const std::string& from_branch,
                       const std::string& user_id);
    [[nodiscard]] std::string commit(const std::string& branch,
                                     const std::string& user_id,
                                     const std::string& message,
                                     std::vector<StudioArtifact> artifacts,
                                     const std::string& created_utc);
    std::uint64_t comment(const std::string& artifact_id, const std::string& user_id,
                          const std::string& text);
    void resolve_comment(std::uint64_t sequence, const std::string& user_id);
    void review(StudioReview review);
    [[nodiscard]] StudioMergeResult merge(const std::string& source_branch,
                                          const std::string& target_branch,
                                          const std::string& user_id,
                                          const std::string& created_utc);
    [[nodiscard]] doc::Value project_state() const;
    [[nodiscard]] std::string export_static_studio(const std::string& directory) const;
private:
    [[nodiscard]] bool authorized(const std::string& user_id, StudioRole role) const;
    [[nodiscard]] const StudioCommit& head(const std::string& branch) const;
    std::string project_id_;
    std::map<std::string, StudioUser> users_;
    std::map<std::string, StudioCommit> commits_;
    std::map<std::string, std::string> branches_;
    std::vector<StudioComment> comments_;
    std::vector<StudioReview> reviews_;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Continuous fleet cybersecurity operations center.
// -----------------------------------------------------------------------------

enum class FleetSecuritySeverity { Informational, Low, Medium, High, Critical };

struct FleetSecurityEvent {
    std::string id;
    double timestamp_s = 0.0;
    std::string vehicle_id;
    std::string asset_id;
    std::string source;
    std::string event_type;
    std::string technique;
    FleetSecuritySeverity severity = FleetSecuritySeverity::Informational;
    std::map<std::string, double> metrics;
    std::map<std::string, std::string> attributes;
};

struct FleetDetectionRule {
    std::string id;
    std::string event_type;
    std::string metric;
    std::string comparison; // >=, <=, >, <, ==
    double threshold = 0.0;
    std::size_t minimum_count = 1;
    double window_s = 60.0;
    FleetSecuritySeverity severity = FleetSecuritySeverity::Medium;
    std::string technique;
};

struct FleetAssetExposure {
    std::string asset_id;
    std::string software_version;
    std::vector<std::string> vulnerabilities;
    std::vector<std::string> privileges;
    double safety_criticality = 0.0;
};

struct FleetCyberIncident {
    std::string id;
    double first_timestamp_s = 0.0;
    double last_timestamp_s = 0.0;
    FleetSecuritySeverity severity = FleetSecuritySeverity::Informational;
    std::set<std::string> vehicle_ids;
    std::set<std::string> asset_ids;
    std::set<std::string> techniques;
    std::vector<std::string> event_ids;
    std::vector<std::string> attack_path;
    std::vector<std::string> containment_actions;
    double confidence = 0.0;
    double safety_impact = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct FleetCyberOperationsReport {
    std::vector<FleetCyberIncident> incidents;
    std::map<std::string, std::size_t> events_by_type;
    std::map<std::string, std::size_t> affected_vehicles_by_software;
    std::vector<std::string> required_regression_campaigns;
    std::vector<std::string> credential_revocations;
    bool emergency_response_required = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class FleetCyberSecurityOperationsCenter {
public:
    void register_rule(FleetDetectionRule rule);
    void register_asset(FleetAssetExposure asset);
    void ingest(FleetSecurityEvent event);
    void set_behavior_baseline(const std::string& event_type,
                               const std::string& metric,
                               double mean,
                               double standard_deviation);
    [[nodiscard]] FleetCyberOperationsReport analyze(
        double correlation_window_s = 300.0,
        double anomaly_z_threshold = 4.0) const;
    [[nodiscard]] doc::Value export_timeline() const;

private:
    std::map<std::string, FleetDetectionRule> rules_;
    std::map<std::string, FleetAssetExposure> assets_;
    std::vector<FleetSecurityEvent> events_;
    std::map<std::string, std::pair<double,double>> baselines_;
};

// -----------------------------------------------------------------------------
// Chiplet, NoC, memory hierarchy, and automotive SoC architecture synthesis.
// -----------------------------------------------------------------------------

enum class ChipletKind { Cpu, Gpu, Npu, Dsp, SafetyIsland, Memory, Io };

struct ChipletCandidate {
    std::string id;
    ChipletKind kind = ChipletKind::Cpu;
    std::string vendor;
    double compute_gops = 0.0;
    double memory_capacity_gb = 0.0;
    double memory_bandwidth_gb_s = 0.0;
    double power_w = 0.0;
    double thermal_resistance_k_w = 0.5;
    double cost = 0.0;
    double area_mm2 = 0.0;
    double failure_rate_fit = 0.0;
    unsigned asil_capability = 0;
    bool lockstep = false;
};

struct SocWorkloadRequirement {
    std::string id;
    ChipletKind preferred_kind = ChipletKind::Cpu;
    double compute_gops = 0.0;
    double memory_gb = 0.0;
    double bandwidth_gb_s = 0.0;
    double period_ms = 10.0;
    double deadline_ms = 10.0;
    unsigned asil = 0;
    unsigned replicas = 1;
    bool diverse_replicas = false;
};

struct ChipletLinkCandidate {
    std::string id;
    std::string endpoint_a;
    std::string endpoint_b;
    double bandwidth_gb_s = 0.0;
    double latency_ns = 0.0;
    double power_w = 0.0;
    double cost = 0.0;
    double bit_error_rate = 0.0;
};

struct SocCommunicationFlow {
    std::string id;
    std::string source_workload;
    std::string target_workload;
    double bandwidth_gb_s = 0.0;
    double maximum_latency_us = 0.0;
};

struct SocSynthesisOptions {
    double ambient_temperature_k = 318.15;
    double maximum_junction_temperature_k = 398.15;
    double maximum_power_w = 500.0;
    double weight_cost = 1.0;
    double weight_power = 1.0;
    double weight_area = 0.01;
    double weight_latency = 0.001;
    std::size_t maximum_search_nodes = 1000000;
};

struct SocWorkloadPlacement {
    std::string workload_id;
    unsigned replica = 0;
    std::string chiplet_id;
    double utilization = 0.0;
    double estimated_execution_ms = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct SocSynthesisResult {
    bool feasible = false;
    std::set<std::string> selected_chiplets;
    std::set<std::string> selected_links;
    std::vector<SocWorkloadPlacement> placements;
    std::map<std::string, double> chiplet_compute_utilization;
    std::map<std::string, double> chiplet_bandwidth_utilization;
    std::map<std::string, double> chiplet_temperature_k;
    double total_cost = 0.0;
    double total_power_w = 0.0;
    double total_area_mm2 = 0.0;
    double objective = 0.0;
    double estimated_system_failure_probability_per_hour = 0.0;
    std::size_t search_nodes = 0;
    std::vector<std::string> diagnostics;
    std::string certificate_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ChipletSocArchitectureSynthesizer {
public:
    [[nodiscard]] SocSynthesisResult synthesize(
        const std::vector<ChipletCandidate>& chiplets,
        const std::vector<SocWorkloadRequirement>& workloads,
        const std::vector<ChipletLinkCandidate>& links,
        const std::vector<SocCommunicationFlow>& flows,
        const SocSynthesisOptions& options = {}) const;
};

} // namespace aesim::advanced

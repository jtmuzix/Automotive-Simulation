#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced::connected {

// -----------------------------------------------------------------------------
// SAE J2735 application-message model + IEEE 1609.2 security service model.
// The application codec is a deterministic simulator interchange profile for
// the modeled J2735 message fields. IEEE/SAE conformance certification remains
// an external qualification activity against licensed normative test vectors.
// -----------------------------------------------------------------------------

enum class J2735MessageType : std::uint8_t { Bsm = 1, Spat = 2, Map = 3, Psm = 4, Tim = 5 };

struct J2735Message {
    J2735MessageType type = J2735MessageType::Bsm;
    std::uint32_t message_count = 0;
    std::uint32_t temporary_id = 0;
    double latitude_deg = 0.0;
    double longitude_deg = 0.0;
    double elevation_m = 0.0;
    double speed_m_s = 0.0;
    double heading_deg = 0.0;
    double acceleration_m_s2 = 0.0;
    std::uint16_t intersection_id = 0;
    std::uint8_t signal_group = 0;
    std::uint8_t event_state = 0;
    double min_end_time_s = 0.0;
    std::vector<double> geometry_xy_m;
    std::string advisory_text;
};

class J2735Codec {
public:
    [[nodiscard]] static std::vector<std::uint8_t> encode(const J2735Message& message);
    [[nodiscard]] static J2735Message decode(const std::vector<std::uint8_t>& bytes);
    [[nodiscard]] static bool semantically_valid(const J2735Message& message, std::string* reason = nullptr);
};

struct WaveIdentity {
    std::string signer_id;
    std::string public_key_pem;
    std::string private_key_pem;
    std::set<std::uint32_t> allowed_psids;
    std::uint64_t valid_from_ms = 0;
    std::uint64_t valid_until_ms = 0;
    std::uint64_t generation = 0;
};

struct WaveSecuredMessage {
    std::uint32_t psid = 0;
    std::uint64_t generation_time_ms = 0;
    std::uint64_t sequence = 0;
    std::string signer_id;
    std::vector<std::uint8_t> payload;
    std::vector<std::uint8_t> signature;
};

struct WaveVerificationResult {
    bool accepted = false;
    bool signature_valid = false;
    bool credential_valid = false;
    bool psid_authorized = false;
    bool fresh = false;
    bool replay = false;
    std::string reason;
};

class WaveSecurityService {
public:
    WaveSecurityService();
    [[nodiscard]] WaveIdentity issue_pseudonym(std::string signer_id,
                                               std::set<std::uint32_t> allowed_psids,
                                               std::uint64_t valid_from_ms,
                                               std::uint64_t valid_until_ms);
    void trust(const WaveIdentity& identity);
    void revoke(const std::string& signer_id);
    [[nodiscard]] WaveSecuredMessage sign(const WaveIdentity& identity,
                                          std::uint32_t psid,
                                          std::uint64_t generation_time_ms,
                                          const std::vector<std::uint8_t>& payload);
    [[nodiscard]] WaveVerificationResult verify(const WaveSecuredMessage& secured,
                                                std::uint64_t now_ms,
                                                std::uint64_t maximum_age_ms = 2000,
                                                std::uint64_t maximum_future_skew_ms = 100);
private:
    std::map<std::string, WaveIdentity> trusted_;
    std::set<std::string> revoked_;
    std::map<std::string, std::uint64_t> highest_sequence_;
    std::map<std::string, std::uint64_t> issue_generation_;
    std::map<std::string, std::uint64_t> signing_sequence_;
};

// -----------------------------------------------------------------------------
// DDS Security / SROS2 policy and encrypted topic transport laboratory.
// -----------------------------------------------------------------------------

enum class DdsAction { Discover, Publish, Subscribe };

struct DdsParticipantPermissions {
    std::string participant;
    std::set<int> domains;
    std::set<std::string> publish_topics;
    std::set<std::string> subscribe_topics;
    bool discovery = true;
};

struct DdsGovernance {
    bool require_authentication = true;
    bool encrypt_discovery = true;
    bool encrypt_user_data = true;
    bool allow_unauthenticated_participants = false;
};

struct DdsIdentity {
    std::string participant;
    std::string public_key_pem;
    std::string private_key_pem;
    std::uint64_t serial = 0;
    bool revoked = false;
};

struct DdsSecureSample {
    int domain = 0;
    std::string topic;
    std::string publisher;
    std::uint64_t sequence = 0;
    std::vector<std::uint8_t> nonce;
    std::vector<std::uint8_t> ciphertext;
    std::vector<std::uint8_t> authentication_tag;
    std::vector<std::uint8_t> signature;
};

struct DdsDeliveryResult {
    bool accepted = false;
    bool authorized = false;
    bool authenticated = false;
    bool integrity_valid = false;
    bool replay = false;
    std::vector<std::uint8_t> plaintext;
    std::string reason;
};

class DdsSros2SecurityLab {
public:
    explicit DdsSros2SecurityLab(DdsGovernance governance = {});
    [[nodiscard]] DdsIdentity issue_identity(const std::string& participant);
    void set_permissions(DdsParticipantPermissions permissions);
    void revoke(const std::string& participant);
    [[nodiscard]] bool authorize(const std::string& participant, int domain,
                                 const std::string& topic, DdsAction action) const;
    [[nodiscard]] DdsSecureSample publish(const DdsIdentity& publisher, int domain,
                                          const std::string& topic,
                                          const std::vector<std::uint8_t>& plaintext);
    [[nodiscard]] DdsDeliveryResult receive(const DdsIdentity& subscriber,
                                            const DdsSecureSample& sample);
    [[nodiscard]] std::string governance_xml() const;
    [[nodiscard]] std::string permissions_xml(const std::string& participant) const;
private:
    DdsGovernance governance_;
    std::map<std::string, DdsIdentity> identities_;
    std::map<std::string, DdsParticipantPermissions> permissions_;
    std::map<std::string, std::uint64_t> publish_sequence_;
    std::map<std::string, std::uint64_t> receive_sequence_;
    std::vector<std::uint8_t> domain_key_;
};

// -----------------------------------------------------------------------------
// Production-style camera ISP pipeline.
// -----------------------------------------------------------------------------

enum class BayerPattern { Rggb, Bggr, Grbg, Gbrg };

struct RawBayerFrame {
    std::size_t width = 0;
    std::size_t height = 0;
    unsigned bit_depth = 12;
    BayerPattern pattern = BayerPattern::Rggb;
    std::vector<std::uint16_t> pixels;
    double exposure_s = 0.01;
    double analog_gain = 1.0;
};

struct CameraIspConfiguration {
    double black_level = 64.0;
    double white_level = 4095.0;
    double lens_shading_strength = 0.12;
    double bad_pixel_sigma = 8.0;
    double denoise_strength = 0.20;
    bool automatic_white_balance = true;
    double red_gain = 2.0;
    double green_gain = 1.0;
    double blue_gain = 1.7;
    std::vector<double> color_matrix{1.55,-0.35,-0.20,-0.15,1.35,-0.20,-0.05,-0.55,1.60};
    double gamma = 2.2;
    double tone_map_strength = 0.65;
    double sharpen_strength = 0.25;
    double target_luma = 0.18;
    double auto_exposure_rate = 0.25;
};

struct CameraIspResult {
    std::size_t width = 0;
    std::size_t height = 0;
    std::vector<std::uint8_t> rgb8;
    double mean_luma = 0.0;
    double recommended_exposure_scale = 1.0;
    std::size_t corrected_bad_pixels = 0;
    std::size_t saturated_pixels = 0;
};

class CameraIspPipeline {
public:
    explicit CameraIspPipeline(CameraIspConfiguration configuration = {});
    [[nodiscard]] CameraIspResult process(const RawBayerFrame& long_exposure,
                                          const std::optional<RawBayerFrame>& short_exposure = std::nullopt) const;
private:
    CameraIspConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Driver Monitoring / Occupant Monitoring sensor digital twin and fusion.
// -----------------------------------------------------------------------------

struct CabinOccupantTruth {
    std::string seat;
    bool occupied = false;
    bool child = false;
    bool belted = false;
    double mass_kg = 0.0;
    double respiration_hz = 0.25;
    double heart_rate_bpm = 70.0;
};

struct DriverTruth {
    double eye_open_left = 1.0;
    double eye_open_right = 1.0;
    double gaze_yaw_deg = 0.0;
    double gaze_pitch_deg = 0.0;
    double head_yaw_deg = 0.0;
    double head_pitch_deg = 0.0;
    bool phone_in_hand = false;
    bool hands_on_wheel = true;
    bool sunglasses = false;
    bool spoof_artifact = false;
};

struct CabinEnvironment {
    double visible_lux = 300.0;
    double nir_reflectivity = 0.7;
    double camera_occlusion = 0.0;
    double vibration_g_rms = 0.02;
    double radar_interference = 0.0;
};

struct CabinSensorFrame {
    double time_s = 0.0;
    double left_eye_open = 1.0;
    double right_eye_open = 1.0;
    double gaze_yaw_deg = 0.0;
    double gaze_pitch_deg = 0.0;
    double head_yaw_deg = 0.0;
    double head_pitch_deg = 0.0;
    double phone_probability = 0.0;
    double hands_probability = 1.0;
    double face_confidence = 1.0;
    double liveness_confidence = 1.0;
    std::map<std::string, double> seat_occupancy_probability;
    std::map<std::string, double> child_probability;
    std::map<std::string, double> respiration_hz;
};

struct DmsOmsAssessment {
    double perclos = 0.0;
    double distraction_score = 0.0;
    double drowsiness_score = 0.0;
    bool driver_attentive = true;
    bool driver_available = true;
    bool spoof_detected = false;
    std::set<std::string> occupied_seats;
    std::set<std::string> child_seats;
    std::set<std::string> unbelted_occupied_seats;
};

class CabinSensorDigitalTwin {
public:
    explicit CabinSensorDigitalTwin(std::uint64_t seed = 1);
    [[nodiscard]] CabinSensorFrame sense(double time_s, const DriverTruth& driver,
                                         const std::vector<CabinOccupantTruth>& occupants,
                                         const CabinEnvironment& environment);
private:
    std::uint64_t state_;
};

class DmsOmsFusion {
public:
    explicit DmsOmsFusion(double window_s = 60.0);
    [[nodiscard]] DmsOmsAssessment update(const CabinSensorFrame& frame,
                                          const std::vector<CabinOccupantTruth>& occupant_truth_for_belts = {});
private:
    double window_s_;
    std::vector<CabinSensorFrame> history_;
};

// -----------------------------------------------------------------------------
// RTOS execution/timing co-simulator with preemption and priority inheritance.
// -----------------------------------------------------------------------------

enum class RtosKernelProfile { Generic, FreeRtos, Zephyr, Qnx, VxWorks };
enum class RtosSegmentKind { Compute, Lock, Unlock };

struct RtosSegment {
    RtosSegmentKind kind = RtosSegmentKind::Compute;
    std::uint64_t duration_ns = 0;
    std::string mutex;
};

struct RtosTask {
    std::string id;
    int priority = 0;
    std::uint64_t period_ns = 0;
    std::uint64_t deadline_ns = 0;
    std::uint64_t release_offset_ns = 0;
    bool is_isr = false;
    std::vector<RtosSegment> segments;
};

struct RtosTraceEvent {
    std::uint64_t time_ns = 0;
    std::string task;
    std::string event;
    int effective_priority = 0;
    std::string detail;
};

struct RtosSimulationResult {
    bool schedulable = true;
    std::size_t released_jobs = 0;
    std::size_t completed_jobs = 0;
    std::size_t deadline_misses = 0;
    std::size_t context_switches = 0;
    std::uint64_t maximum_response_ns = 0;
    std::uint64_t maximum_blocking_ns = 0;
    std::vector<RtosTraceEvent> trace;
};

struct RtosSimulationConfiguration {
    RtosKernelProfile profile = RtosKernelProfile::Zephyr;
    std::size_t cores = 1;
    std::uint64_t duration_ns = 100000000;
    std::uint64_t quantum_ns = 1000;
    std::uint64_t context_switch_ns = 250;
    bool priority_inheritance = true;
};

class RtosCoSimulator {
public:
    [[nodiscard]] RtosSimulationResult simulate(const std::vector<RtosTask>& tasks,
                                                const RtosSimulationConfiguration& configuration = {}) const;
};

// -----------------------------------------------------------------------------
// Central compute PCIe/CXL/IOMMU/SR-IOV transaction simulator.
// -----------------------------------------------------------------------------

enum class ComputeLinkProtocol { Pcie, CxlIo, CxlCache, CxlMem };
enum class ComputeTransactionKind { MmioRead, MmioWrite, DmaRead, DmaWrite, CxlLoad, CxlStore };

struct ComputeFabricNode {
    std::string id;
    bool is_switch = false;
    bool iommu = false;
    std::size_t sriov_virtual_functions = 0;
};

struct ComputeFabricLink {
    std::string id;
    std::string from;
    std::string to;
    ComputeLinkProtocol protocol = ComputeLinkProtocol::Pcie;
    double transfer_rate_gt_s = 16.0;
    unsigned lanes = 4;
    double encoding_efficiency = 128.0 / 130.0;
    std::uint64_t propagation_ns = 80;
    double utilization = 0.0;
    bool failed = false;
};

struct ComputeTransaction {
    std::uint64_t issue_time_ns = 0;
    std::string requester;
    std::string target;
    ComputeTransactionKind kind = ComputeTransactionKind::DmaRead;
    std::size_t bytes = 64;
    std::uint64_t virtual_address = 0;
    int virtual_function = -1;
    bool coherent = false;
};

struct ComputeTransactionResult {
    bool completed = false;
    bool iommu_translation_hit = false;
    bool aer_error = false;
    std::uint64_t completion_time_ns = 0;
    std::uint64_t latency_ns = 0;
    std::vector<std::string> route_links;
    std::string reason;
};

class CentralComputeFabricSimulator {
public:
    void add_node(ComputeFabricNode node);
    void add_link(ComputeFabricLink link);
    void map_iommu_page(std::string requester, std::uint64_t virtual_page, std::uint64_t physical_page);
    [[nodiscard]] ComputeTransactionResult transact(const ComputeTransaction& transaction);
    void reset_timing();
private:
    std::map<std::string, ComputeFabricNode> nodes_;
    std::map<std::string, ComputeFabricLink> links_;
    std::map<std::string, std::map<std::uint64_t, std::uint64_t>> iommu_pages_;
    std::map<std::string, std::set<std::uint64_t>> iommu_tlb_;
    std::map<std::string, std::uint64_t> link_available_ns_;
};

// -----------------------------------------------------------------------------
// Wireless BMS RF/security/estimation closed-loop digital twin.
// -----------------------------------------------------------------------------

struct WirelessBmsCell {
    std::string id;
    double soc = 0.5;
    double capacity_ah = 5.0;
    double open_circuit_voltage_v = 3.7;
    double internal_resistance_ohm = 0.003;
    double temperature_k = 298.15;
    double path_loss_db = 55.0;
    double clock_drift_ppm = 0.0;
    bool compromised = false;
};

struct WirelessBmsEnvironment {
    double transmit_power_dbm = 0.0;
    double receiver_sensitivity_dbm = -95.0;
    double noise_floor_dbm = -100.0;
    double interference_dbm = -110.0;
    double jammer_dbm = -200.0;
    double fading_sigma_db = 2.0;
    unsigned maximum_retries = 3;
    double packet_airtime_ms = 0.6;
};

struct WirelessBmsSample {
    std::string cell_id;
    bool delivered = false;
    unsigned attempts = 0;
    double latency_ms = 0.0;
    double rssi_dbm = -200.0;
    double snr_db = -100.0;
    double voltage_v = 0.0;
    double temperature_k = 0.0;
    double estimated_soc = 0.0;
    bool authentication_valid = false;
    bool balance_requested = false;
};

struct WirelessBmsPackReport {
    std::vector<WirelessBmsSample> samples;
    double packet_delivery_ratio = 0.0;
    double maximum_latency_ms = 0.0;
    double minimum_cell_voltage_v = 0.0;
    double maximum_cell_temperature_k = 0.0;
    bool contactor_open_requested = false;
    bool degraded_estimation = false;
};

class WirelessBmsDigitalTwin {
public:
    explicit WirelessBmsDigitalTwin(std::uint64_t seed = 1);
    [[nodiscard]] WirelessBmsPackReport step(std::vector<WirelessBmsCell>& cells,
                                             double pack_current_a, double dt_s,
                                             const WirelessBmsEnvironment& environment = {});
private:
    std::uint64_t state_;
    std::map<std::string, std::uint64_t> sequence_;
    std::map<std::string, double> estimated_soc_;
};

// -----------------------------------------------------------------------------
// LTE/5G/NTN telematics modem digital twin.
// -----------------------------------------------------------------------------

enum class RadioAccessTechnology { Lte, Nr, Ntn };
enum class ModemState { Off, Booting, Searching, Registering, Connected, Handover, Sleep, ThermalLimited };

struct CellularCell {
    std::string id;
    std::string operator_code;
    RadioAccessTechnology rat = RadioAccessTechnology::Nr;
    double rsrp_dbm = -90.0;
    double rsrq_db = -10.0;
    double sinr_db = 15.0;
    double bandwidth_mhz = 20.0;
    double load = 0.2;
    double base_latency_ms = 15.0;
    bool roaming = false;
    bool available = true;
};

struct EsimProfile {
    std::string iccid;
    std::string home_operator;
    std::set<std::string> roaming_partners;
    bool enabled = true;
};

struct QosFlow {
    std::string id;
    double requested_mbps = 1.0;
    double maximum_latency_ms = 100.0;
    unsigned priority = 5;
};

struct TelematicsInput {
    double dt_s = 0.1;
    bool power_on = true;
    bool data_pending = false;
    double payload_megabits = 0.0;
    double ambient_temperature_k = 298.15;
    std::vector<CellularCell> visible_cells;
    std::vector<QosFlow> flows;
};

struct TelematicsState {
    ModemState state = ModemState::Off;
    std::string serving_cell;
    double state_timer_s = 0.0;
    double inactivity_timer_s = 0.0;
    double modem_temperature_k = 298.15;
    double cumulative_energy_j = 0.0;
    double delivered_megabits = 0.0;
    std::size_t handovers = 0;
    std::size_t attach_failures = 0;
};

struct TelematicsStepResult {
    TelematicsState state;
    double instantaneous_throughput_mbps = 0.0;
    double latency_ms = 0.0;
    double power_w = 0.0;
    bool registered = false;
    bool roaming = false;
    bool qos_satisfied = true;
    std::string event;
};

class TelematicsModemDigitalTwin {
public:
    explicit TelematicsModemDigitalTwin(EsimProfile profile = {});
    [[nodiscard]] TelematicsStepResult step(const TelematicsInput& input,
                                            const TelematicsState& previous = {}) const;
private:
    EsimProfile profile_;
};

// Unified capability/self-test surface used by regression and external callers.
class ConnectedVehicleIntegrationPlatform {
public:
    [[nodiscard]] static doc::Value capabilities();
    [[nodiscard]] static doc::Value self_test();
};

} // namespace aesim::advanced::connected

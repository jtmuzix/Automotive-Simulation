#pragma once

#include "aesim/advanced/indycar_future_competition_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

// 1. 2028 2.4-litre power-unit co-design and homologation.
struct IndyCar2028PowerUnitDesign {
  std::string design_id;
  double displacement_l = 2.4;
  std::size_t cylinder_count = 6;
  double bore_m = 0.095;
  double stroke_m = 0.0564;
  double compression_ratio = 12.0;
  double maximum_engine_speed_rpm = 12000.0;
  double volumetric_efficiency = 1.05;
  double combustion_efficiency = 0.40;
  double maximum_boost_pa_gauge = 155000.0;
  double compressor_efficiency = 0.74;
  double turbine_efficiency = 0.72;
  double maximum_turbine_inlet_temperature_k = 1325.0;
  double maximum_compressor_speed_rpm = 155000.0;
  double fuel_lower_heating_value_j_kg = 26.8e6;
  double stoichiometric_air_fuel_ratio = 9.0;
  double renewable_ethanol_mass_fraction = 1.0;
  double engine_mass_kg = 105.0;
  double crankshaft_inertia_kg_m2 = 0.18;
  double mgu_coupling_efficiency = 0.985;
  double cylinder_variation_fraction = 0.012;
  void validate() const;
};

struct IndyCar2028PowerUnitDutyPoint {
  std::string point_id;
  double duration_s = 1.0;
  double engine_speed_rpm = 9000.0;
  double throttle_fraction = 1.0;
  double boost_pa_gauge = 120000.0;
  double lambda = 1.0;
  double spark_advance_deg = 18.0;
  double intake_temperature_k = 315.0;
  double ambient_pressure_pa = 101325.0;
  double coolant_temperature_k = 365.0;
  double oil_temperature_k = 390.0;
  double mgu_shaft_power_w = 0.0;
  void validate() const;
};

struct IndyCar2028PowerUnitHomologationRules {
  double minimum_displacement_l = 2.35;
  double maximum_displacement_l = 2.45;
  std::size_t required_cylinders = 6;
  double maximum_engine_speed_rpm = 12000.0;
  double maximum_engine_mass_kg = 115.0;
  double minimum_peak_power_w = 500000.0;
  double maximum_peak_power_w = 650000.0;
  double maximum_turbine_inlet_temperature_k = 1325.0;
  double maximum_compressor_speed_rpm = 160000.0;
  double maximum_cylinder_imbalance_fraction = 0.025;
  double minimum_knock_margin = 0.05;
  void validate() const;
};

struct IndyCar2028PowerUnitPointResult {
  std::string point_id;
  double brake_torque_n_m = 0.0;
  double brake_power_w = 0.0;
  double fuel_flow_kg_s = 0.0;
  double air_flow_kg_s = 0.0;
  double brake_thermal_efficiency = 0.0;
  double turbine_inlet_temperature_k = 0.0;
  double compressor_speed_rpm = 0.0;
  double knock_margin = 0.0;
  double indicated_mean_effective_pressure_pa = 0.0;
  std::vector<double> cylinder_peak_pressure_pa;
};

struct IndyCar2028PowerUnitResult {
  bool homologated = false;
  double peak_power_w = 0.0;
  double peak_torque_n_m = 0.0;
  double total_fuel_kg = 0.0;
  double cycle_brake_efficiency = 0.0;
  double minimum_knock_margin = 0.0;
  double maximum_turbine_inlet_temperature_k = 0.0;
  double maximum_compressor_speed_rpm = 0.0;
  double maximum_cylinder_imbalance_fraction = 0.0;
  std::vector<IndyCar2028PowerUnitPointResult> points;
  std::vector<std::string> violations;
  std::string evidence_sha256;
};

class IndyCar2028PowerUnitLaboratory {
 public:
  IndyCar2028PowerUnitResult evaluate(
      const IndyCar2028PowerUnitDesign& design,
      const std::vector<IndyCar2028PowerUnitDutyPoint>& duty_cycle,
      const IndyCar2028PowerUnitHomologationRules& rules) const;
};

// 2. MGU, inverter, and twenty-cell ultracapacitor electrothermal system.
struct IndyCarHybridHardwareConfiguration {
  std::string hardware_id;
  std::size_t ultracapacitor_cells = 20;
  double cell_capacitance_f = 3000.0;
  double cell_esr_ohm = 0.00032;
  double cell_minimum_voltage_v = 1.0;
  double cell_maximum_voltage_v = 2.85;
  double cell_thermal_capacity_j_k = 520.0;
  double cell_to_coolant_conductance_w_k = 3.8;
  double cell_variation_fraction = 0.008;
  double dc_bus_resistance_ohm = 0.0025;
  double contactor_resistance_ohm = 0.0004;
  double minimum_isolation_resistance_ohm = 500000.0;
  double mgu_peak_torque_n_m = 180.0;
  double mgu_base_speed_rpm = 8500.0;
  double mgu_peak_speed_rpm = 18000.0;
  double mgu_efficiency = 0.94;
  double mgu_thermal_capacity_j_k = 16000.0;
  double mgu_cooling_w_k = 180.0;
  double inverter_peak_current_a = 900.0;
  double inverter_switching_loss_coefficient = 0.00008;
  double inverter_conduction_resistance_ohm = 0.0018;
  double inverter_thermal_capacity_j_k = 10000.0;
  double inverter_cooling_w_k = 140.0;
  double maximum_component_temperature_k = 403.15;
  double coulombic_efficiency = 0.995;
  void validate() const;
};

struct IndyCarHybridMissionSegment {
  std::string segment_id;
  double duration_s = 1.0;
  double shaft_speed_rpm = 6000.0;
  double requested_shaft_torque_n_m = 0.0;  // Positive deploys; negative regenerates.
  double coolant_temperature_k = 333.15;
  double ambient_temperature_k = 303.15;
  double isolation_resistance_ohm = 1.0e7;
  bool contactors_commanded_closed = true;
  bool self_start_request = false;
  void validate() const;
};

struct IndyCarUltracapacitorState {
  std::vector<double> cell_voltage_v;
  std::vector<double> cell_temperature_k;
  double mgu_temperature_k = 333.15;
  double inverter_temperature_k = 333.15;
  double equivalent_full_cycles = 0.0;
  void validate(const IndyCarHybridHardwareConfiguration& configuration) const;
};

struct IndyCarHybridElectrothermalSample {
  std::string segment_id;
  double delivered_shaft_torque_n_m = 0.0;
  double shaft_power_w = 0.0;
  double dc_bus_voltage_v = 0.0;
  double dc_bus_current_a = 0.0;
  double mgu_loss_w = 0.0;
  double inverter_loss_w = 0.0;
  double minimum_cell_voltage_v = 0.0;
  double maximum_cell_voltage_v = 0.0;
  double maximum_cell_temperature_k = 0.0;
  double mgu_temperature_k = 0.0;
  double inverter_temperature_k = 0.0;
  bool contactors_closed = false;
  bool self_start_completed = false;
};

struct IndyCarHybridElectrothermalResult {
  bool safe = false;
  bool isolation_maintained = false;
  double deployed_energy_j = 0.0;
  double recovered_energy_j = 0.0;
  double electrical_loss_j = 0.0;
  double minimum_cell_voltage_v = 0.0;
  double maximum_cell_voltage_v = 0.0;
  double peak_component_temperature_k = 0.0;
  double estimated_remaining_useful_cycles = 0.0;
  IndyCarUltracapacitorState final_state;
  std::vector<IndyCarHybridElectrothermalSample> history;
  std::vector<std::string> faults;
  std::string evidence_sha256;
};

class IndyCarHybridElectrothermalLaboratory {
 public:
  IndyCarHybridElectrothermalResult simulate(
      const IndyCarHybridHardwareConfiguration& configuration,
      const std::vector<IndyCarHybridMissionSegment>& mission,
      const IndyCarUltracapacitorState& initial_state) const;
};

// 3. Gearbox, bellhousing, clutch, and driveline durability.
struct IndyCarDrivelineConfiguration {
  std::string assembly_id;
  std::vector<double> gear_ratios{2.70, 2.05, 1.62, 1.34, 1.14, 0.98};
  double final_drive_ratio = 3.20;
  double drivetrain_efficiency = 0.965;
  double input_inertia_kg_m2 = 0.22;
  double output_inertia_kg_m2 = 1.10;
  double shaft_torsional_stiffness_n_m_rad = 18000.0;
  double shaft_torsional_damping_n_m_s_rad = 120.0;
  double clutch_capacity_n_m = 900.0;
  double clutch_thermal_capacity_j_k = 18000.0;
  double clutch_cooling_w_k = 110.0;
  double dog_engagement_speed_limit_rpm = 850.0;
  double shift_actuation_time_s = 0.055;
  double differential_preload_n_m = 95.0;
  double differential_lock_fraction = 0.42;
  double gearbox_oil_thermal_capacity_j_k = 26000.0;
  double gearbox_oil_cooling_w_k = 190.0;
  double maximum_oil_temperature_k = 423.15;
  double maximum_clutch_temperature_k = 673.15;
  double gear_fatigue_reference_torque_n_m = 800.0;
  double halfshaft_fatigue_reference_torque_n_m = 1900.0;
  double bellhousing_load_limit_n_m = 2300.0;
  void validate() const;
};

struct IndyCarDrivelineCyclePoint {
  std::string point_id;
  double duration_s = 0.1;
  double engine_speed_rpm = 8000.0;
  double engine_torque_n_m = 500.0;
  std::size_t commanded_gear = 1;
  double wheel_speed_rpm = 750.0;
  double clutch_engagement_fraction = 1.0;
  double left_wheel_speed_rpm = 750.0;
  double right_wheel_speed_rpm = 750.0;
  double ambient_temperature_k = 303.15;
  bool shift_requested = false;
  void validate(std::size_t gear_count) const;
};

struct IndyCarDrivelineSample {
  std::string point_id;
  std::size_t selected_gear = 0;
  double input_torque_n_m = 0.0;
  double axle_torque_n_m = 0.0;
  double dog_speed_mismatch_rpm = 0.0;
  double clutch_slip_power_w = 0.0;
  double clutch_temperature_k = 0.0;
  double gearbox_oil_temperature_k = 0.0;
  double shaft_twist_rad = 0.0;
  double differential_bias_torque_n_m = 0.0;
  bool shift_completed = false;
  bool missed_shift = false;
};

struct IndyCarDrivelineDurabilityResult {
  bool durable = false;
  double gear_damage_fraction = 0.0;
  double halfshaft_damage_fraction = 0.0;
  double clutch_wear_fraction = 0.0;
  double bellhousing_load_margin = 0.0;
  double peak_clutch_temperature_k = 0.0;
  double peak_oil_temperature_k = 0.0;
  std::size_t completed_shifts = 0;
  std::size_t missed_shifts = 0;
  std::vector<IndyCarDrivelineSample> history;
  std::vector<std::string> failures;
  std::string evidence_sha256;
};

class IndyCarTransmissionDrivelineLaboratory {
 public:
  IndyCarDrivelineDurabilityResult simulate(
      const IndyCarDrivelineConfiguration& configuration,
      const std::vector<IndyCarDrivelineCyclePoint>& cycle,
      double initial_oil_temperature_k,
      double initial_clutch_temperature_k) const;
};

// 4. Hydraulic and carbon-brake system.
struct IndyCarBrakeSystemConfiguration {
  std::string system_id;
  double pedal_ratio = 5.2;
  double master_cylinder_area_m2 = 0.00042;
  double front_caliper_piston_area_m2 = 0.0032;
  double rear_caliper_piston_area_m2 = 0.0026;
  double front_effective_radius_m = 0.135;
  double rear_effective_radius_m = 0.130;
  double front_disc_mass_kg = 1.8;
  double rear_disc_mass_kg = 1.6;
  double carbon_specific_heat_j_kg_k = 1050.0;
  double front_cooling_w_k = 95.0;
  double rear_cooling_w_k = 80.0;
  double line_compliance_m3_pa = 1.5e-14;
  double fluid_bulk_modulus_pa = 1.55e9;
  double fluid_boiling_temperature_k = 523.15;
  double pad_friction_cold = 0.48;
  double pad_friction_hot = 0.56;
  double pad_optimum_temperature_k = 873.15;
  double maximum_disc_temperature_k = 1273.15;
  double pad_wear_coefficient = 2.0e-12;
  double disc_wear_coefficient = 4.0e-13;
  double maximum_line_pressure_pa = 12.0e6;
  void validate() const;
};

struct IndyCarBrakeEvent {
  std::string event_id;
  double duration_s = 1.0;
  double pedal_force_n = 0.0;
  double front_bias_fraction = 0.58;
  double vehicle_speed_m_s = 60.0;
  double front_wheel_speed_rad_s = 180.0;
  double rear_wheel_speed_rad_s = 180.0;
  double regen_brake_torque_n_m = 0.0;
  double ambient_temperature_k = 303.15;
  double duct_open_fraction = 1.0;
  double knockback_displacement_m3 = 0.0;
  void validate() const;
};

struct IndyCarBrakeSample {
  std::string event_id;
  double front_line_pressure_pa = 0.0;
  double rear_line_pressure_pa = 0.0;
  double front_brake_torque_n_m = 0.0;
  double rear_brake_torque_n_m = 0.0;
  double total_deceleration_m_s2 = 0.0;
  double front_disc_temperature_k = 0.0;
  double rear_disc_temperature_k = 0.0;
  double fluid_temperature_k = 0.0;
  double pedal_travel_m = 0.0;
  double front_slip_ratio = 0.0;
  double rear_slip_ratio = 0.0;
  bool front_lock_risk = false;
  bool rear_lock_risk = false;
};

struct IndyCarBrakeSystemResult {
  bool serviceable = false;
  double front_pad_wear_fraction = 0.0;
  double rear_pad_wear_fraction = 0.0;
  double front_disc_wear_fraction = 0.0;
  double rear_disc_wear_fraction = 0.0;
  double peak_front_disc_temperature_k = 0.0;
  double peak_rear_disc_temperature_k = 0.0;
  double peak_fluid_temperature_k = 0.0;
  double minimum_fade_margin = 0.0;
  std::vector<IndyCarBrakeSample> history;
  std::vector<std::string> faults;
  std::string evidence_sha256;
};

class IndyCarBrakeSystemLaboratory {
 public:
  IndyCarBrakeSystemResult simulate(
      const IndyCarBrakeSystemConfiguration& configuration,
      const std::vector<IndyCarBrakeEvent>& events,
      double vehicle_mass_kg,
      double tire_radius_m) const;
};

// 5. Laser-scanned track, evolving grip, drainage, and weather.
enum class IndyCarTrackMaterial { Asphalt, Concrete, Sealer, Paint, Patch };

struct IndyCarTrackMeshPoint {
  std::size_t index = 0;
  double distance_m = 0.0;
  double lateral_m = 0.0;
  double elevation_m = 0.0;
  double roughness_rms_m = 0.001;
  double macrotexture_depth_m = 0.0012;
  double drainage_slope = 0.02;
  double base_friction = 1.25;
  double solar_absorptivity = 0.88;
  IndyCarTrackMaterial material = IndyCarTrackMaterial::Asphalt;
  void validate() const;
};

struct IndyCarTrackWeatherSample {
  double time_s = 0.0;
  double air_temperature_k = 303.15;
  double relative_humidity = 0.50;
  double rainfall_mm_h = 0.0;
  double solar_flux_w_m2 = 650.0;
  double wind_speed_m_s = 3.0;
  double wind_direction_rad = 0.0;
  double cloud_fraction = 0.2;
  void validate() const;
};

struct IndyCarTrackTrafficSample {
  double time_s = 0.0;
  std::size_t mesh_index = 0;
  std::size_t vehicle_count = 1;
  double tire_energy_j = 0.0;
  double rubber_deposition_kg = 0.0;
  double contaminant_kg = 0.0;
  bool drying_vehicle = false;
  void validate() const;
};

struct IndyCarTrackCellState {
  std::size_t mesh_index = 0;
  double surface_temperature_k = 0.0;
  double water_film_m = 0.0;
  double rubber_coverage_fraction = 0.0;
  double contaminant_coverage_fraction = 0.0;
  double effective_friction = 0.0;
  double hydroplaning_speed_m_s = 0.0;
  double bump_velocity_severity = 0.0;
  double local_crosswind_m_s = 0.0;
};

struct IndyCarTrackEnvironmentResult {
  bool numerically_valid = false;
  double minimum_effective_friction = 0.0;
  double maximum_water_film_m = 0.0;
  double average_surface_temperature_k = 0.0;
  double dry_line_fraction = 0.0;
  std::vector<IndyCarTrackCellState> cells;
  std::vector<std::string> hazards;
  std::string evidence_sha256;
};

class IndyCarTrackEnvironmentTwin {
 public:
  IndyCarTrackEnvironmentResult evolve(
      const std::vector<IndyCarTrackMeshPoint>& mesh,
      const std::vector<IndyCarTrackWeatherSample>& weather,
      const std::vector<IndyCarTrackTrafficSample>& traffic,
      double simulation_end_time_s) const;
};

// 6. Full-field agent-based racecraft and raceability.
struct IndyCarRaceEntrant {
  std::string car_id;
  std::string team_id;
  std::string manufacturer;
  double qualifying_speed_m_s = 65.0;
  double driver_skill = 0.75;
  double aggression = 0.5;
  double defensive_tendency = 0.5;
  double tire_management = 0.7;
  double fuel_saving_skill = 0.7;
  double restart_skill = 0.7;
  double reliability = 0.98;
  std::size_t planned_pit_interval_laps = 30;
  void validate() const;
};

struct IndyCarFullFieldRaceConfiguration {
  std::string event_id;
  IndyCarCircuitClass circuit = IndyCarCircuitClass::RoadStreet;
  std::size_t laps = 100;
  double lap_distance_m = 4000.0;
  double base_tire_degradation_s_per_lap = 0.045;
  double wake_time_loss_s = 0.30;
  double tow_time_gain_s = 0.20;
  double passing_difficulty = 0.55;
  double caution_probability_per_car_lap = 0.0008;
  double pit_loss_s = 28.0;
  double restart_field_compression = 0.9;
  std::size_t maximum_field_size = 35;
  void validate() const;
};

struct IndyCarRaceLapRecord {
  std::size_t lap = 0;
  std::string car_id;
  std::size_t position = 0;
  double lap_time_s = 0.0;
  double cumulative_time_s = 0.0;
  double tire_age_laps = 0.0;
  double fuel_save_fraction = 0.0;
  bool pitted = false;
  bool retired = false;
};

struct IndyCarRaceClassificationEntry {
  std::string car_id;
  std::size_t position = 0;
  std::size_t completed_laps = 0;
  double elapsed_time_s = 0.0;
  std::size_t overtakes = 0;
  std::size_t pit_stops = 0;
  bool retired = false;
};

struct IndyCarFullFieldRaceResult {
  bool completed = false;
  std::size_t total_overtakes = 0;
  std::size_t lead_changes = 0;
  std::size_t cautions = 0;
  double raceability_index = 0.0;
  double average_field_spread_s = 0.0;
  std::vector<IndyCarRaceClassificationEntry> classification;
  std::vector<IndyCarRaceLapRecord> lap_records;
  std::vector<std::string> incidents;
  std::string evidence_sha256;
};

class IndyCarFullFieldCompetitionEngine {
 public:
  IndyCarFullFieldRaceResult simulate(
      const IndyCarFullFieldRaceConfiguration& configuration,
      const std::vector<IndyCarRaceEntrant>& entrants,
      std::uint64_t deterministic_seed) const;
};

// 7. Synchronized video, telemetry, and incident reconstruction.
struct IndyCarCameraCalibration {
  std::string camera_id;
  double clock_offset_s = 0.0;
  double clock_drift_ppm = 0.0;
  std::vector<double> pixel_to_track_homography{1.0, 0.0, 0.0,
                                                0.0, 1.0, 0.0,
                                                0.0, 0.0, 1.0};
  double pixel_sigma = 1.0;
  void validate() const;
};

struct IndyCarVideoDetection {
  std::string camera_id;
  std::string car_id;
  double camera_time_s = 0.0;
  double pixel_x = 0.0;
  double pixel_y = 0.0;
  double confidence = 1.0;
  bool contact_visible = false;
  void validate() const;
};

struct IndyCarIncidentTelemetrySample {
  std::string car_id;
  double time_s = 0.0;
  double track_x_m = 0.0;
  double track_y_m = 0.0;
  double speed_m_s = 0.0;
  double heading_rad = 0.0;
  double throttle_fraction = 0.0;
  double brake_pressure_pa = 0.0;
  double steering_angle_rad = 0.0;
  double longitudinal_acceleration_m_s2 = 0.0;
  double lateral_acceleration_m_s2 = 0.0;
  void validate() const;
};

struct IndyCarReconstructedTrajectoryPoint {
  std::string car_id;
  double time_s = 0.0;
  double track_x_m = 0.0;
  double track_y_m = 0.0;
  double speed_m_s = 0.0;
  double position_uncertainty_m = 0.0;
  double braking_fraction = 0.0;
  double steering_angle_rad = 0.0;
};

struct IndyCarIncidentReconstructionResult {
  bool reconstruction_valid = false;
  double incident_time_s = 0.0;
  std::string primary_car_id;
  std::string secondary_car_id;
  double minimum_separation_m = 0.0;
  double closing_speed_m_s = 0.0;
  double estimated_contact_energy_j = 0.0;
  double reconstruction_uncertainty_m = 0.0;
  double primary_avoidability_score = 0.0;
  double secondary_avoidability_score = 0.0;
  std::vector<IndyCarReconstructedTrajectoryPoint> trajectory;
  std::vector<std::string> findings;
  std::string evidence_sha256;
};

class IndyCarIncidentReconstructionPlatform {
 public:
  IndyCarIncidentReconstructionResult reconstruct(
      const std::vector<IndyCarCameraCalibration>& cameras,
      const std::vector<IndyCarVideoDetection>& video,
      const std::vector<IndyCarIncidentTelemetrySample>& telemetry,
      double vehicle_mass_kg,
      double contact_distance_m) const;
};

// 8. Pit-lane computer-vision officiating.
enum class IndyCarPitViolationType {
  Speeding,
  EntryLineCrossing,
  ExitLineCrossing,
  ClosedPitEntry,
  WrongPitBox,
  UnsafeRelease,
  CrewOverWallEarly,
  ExcessCrew,
  UncontrolledWheel,
  FuelConnectionMovement,
  PrematureRelease,
  ServiceOutsideBox,
  AdjacentBoxInterference,
  PitLaneBlockage
};

struct IndyCarPitBoxDefinition {
  std::string car_id;
  double start_m = 0.0;
  double end_m = 10.0;
  double lane_center_m = 0.0;
  void validate() const;
};

struct IndyCarPitVisionFrame {
  double time_s = 0.0;
  std::string car_id;
  double longitudinal_position_m = 0.0;
  double lateral_position_m = 0.0;
  double speed_m_s = 0.0;
  std::size_t crew_over_wall = 0;
  std::size_t detached_wheels_controlled = 0;
  std::size_t detached_wheels_uncontrolled = 0;
  bool pit_open = true;
  bool crossed_entry_line = false;
  bool crossed_exit_line = false;
  bool fuel_probe_connected = false;
  bool air_jack_active = false;
  bool wheel_service_complete = true;
  bool neighboring_box_obstructed = false;
  double detection_confidence = 1.0;
  void validate() const;
};

struct IndyCarPitLoopObservation {
  double time_s = 0.0;
  std::string car_id;
  double measured_speed_m_s = 0.0;
  double confidence = 1.0;
  void validate() const;
};

struct IndyCarPitVisionViolation {
  IndyCarPitViolationType type = IndyCarPitViolationType::Speeding;
  std::string car_id;
  double start_time_s = 0.0;
  double end_time_s = 0.0;
  double severity = 0.0;
  double confidence = 0.0;
  std::string evidence_reference;
};

struct IndyCarPitLaneVisionResult {
  bool compliant = false;
  std::size_t processed_frames = 0;
  std::size_t fused_loop_observations = 0;
  std::vector<IndyCarPitVisionViolation> violations;
  std::map<std::string, double> maximum_verified_speed_m_s;
  std::string evidence_sha256;
};

class IndyCarPitLaneVisionOfficiating {
 public:
  IndyCarPitLaneVisionResult adjudicate(
      const std::vector<IndyCarPitBoxDefinition>& boxes,
      const std::vector<IndyCarPitVisionFrame>& frames,
      const std::vector<IndyCarPitLoopObservation>& loop_observations,
      double pit_speed_limit_m_s,
      std::size_t maximum_crew_over_wall,
      double unsafe_release_gap_s) const;
};

// 9. Appeals, protests, precedent, and officiating audit.
enum class IndyCarAppealJurisdiction { Sporting, Technical, Safety, HybridPowertrain };
enum class IndyCarAppealOutcome { Accepted, Dismissed, Modified, Upheld, Remanded };

struct IndyCarAppealRule {
  std::string rule_id;
  IndyCarAppealJurisdiction jurisdiction = IndyCarAppealJurisdiction::Sporting;
  double minimum_penalty_points = 0.0;
  double maximum_penalty_points = 100.0;
  double filing_window_h = 24.0;
  bool appealable = true;
  std::vector<std::string> tags;
  void validate() const;
};

struct IndyCarPrecedentCase {
  std::string case_id;
  std::string rule_id;
  IndyCarAppealJurisdiction jurisdiction = IndyCarAppealJurisdiction::Sporting;
  std::vector<std::string> tags;
  double facts_severity = 0.5;
  double evidence_strength = 0.5;
  double penalty_points = 0.0;
  IndyCarAppealOutcome outcome = IndyCarAppealOutcome::Upheld;
  std::string decision_digest;
  void validate() const;
};

struct IndyCarAppealFiling {
  std::string appeal_id;
  std::string entrant_id;
  std::string rule_id;
  IndyCarAppealJurisdiction asserted_jurisdiction = IndyCarAppealJurisdiction::Sporting;
  double decision_time_h = 0.0;
  double filing_time_h = 0.0;
  double original_penalty_points = 0.0;
  double facts_severity = 0.5;
  double evidence_strength = 0.5;
  bool filing_fee_paid = true;
  bool conflict_disclosed = true;
  bool requests_stay = false;
  std::vector<std::string> tags;
  void validate() const;
};

struct IndyCarPrecedentMatch {
  std::string case_id;
  double similarity = 0.0;
  double penalty_points = 0.0;
  IndyCarAppealOutcome outcome = IndyCarAppealOutcome::Upheld;
};

struct IndyCarAppealDecision {
  IndyCarAppealOutcome outcome = IndyCarAppealOutcome::Dismissed;
  bool jurisdiction_valid = false;
  bool timely = false;
  bool procedurally_complete = false;
  bool stay_granted = false;
  double recommended_penalty_points = 0.0;
  double consistency_score = 0.0;
  std::vector<IndyCarPrecedentMatch> precedents;
  std::vector<std::string> reasons;
  std::string public_decision_digest;
  std::string complete_audit_digest;
};

class IndyCarAppealsPrecedentPlatform {
 public:
  IndyCarAppealDecision adjudicate(
      const IndyCarAppealRule& rule,
      const IndyCarAppealFiling& filing,
      const std::vector<IndyCarPrecedentCase>& precedents) const;
};

// 10. Complete Indianapolis 500 Month-of-May operations twin.
enum class Indy500SessionType {
  OpenTest,
  RookieOrientation,
  Refresher,
  Practice,
  FastFriday,
  QualifyingDayOne,
  TopTwelve,
  FastSix,
  LastChance,
  CarbDay,
  PitStopChallenge,
  Race
};

struct Indy500CompleteEntry {
  std::string car_id;
  std::string driver_id;
  std::string team_id;
  bool rookie = false;
  bool refresher_required = false;
  double baseline_no_tow_speed_m_s = 104.0;
  double qualifying_consistency = 0.75;
  double racecraft = 0.75;
  double pit_crew_performance = 0.75;
  double reliability = 0.98;
  double engine_mileage_km = 0.0;
  double available_engine_mileage_km = 4000.0;
  std::size_t tire_sets = 35;
  double programme_budget = 2.0e6;
  void validate() const;
};

struct Indy500SessionPlan {
  std::string session_id;
  Indy500SessionType type = Indy500SessionType::Practice;
  double start_time_h = 0.0;
  double duration_h = 1.0;
  double track_temperature_k = 315.0;
  double wind_speed_m_s = 3.0;
  double rain_probability = 0.0;
  double boost_multiplier = 1.0;
  std::size_t maximum_runs_per_entry = 4;
  void validate() const;
};

struct Indy500EntryOperationsResult {
  std::string car_id;
  bool orientation_complete = false;
  bool qualified = false;
  bool bumped = false;
  std::size_t grid_position = 0;
  double best_four_lap_average_m_s = 0.0;
  double projected_race_time_s = 0.0;
  std::size_t planned_pit_stops = 0;
  std::size_t tire_sets_remaining = 0;
  double engine_mileage_remaining_km = 0.0;
  double budget_remaining = 0.0;
  double readiness_score = 0.0;
  double pit_stop_challenge_time_s = 0.0;
  std::vector<std::string> issues;
};

struct Indy500SessionOutcome {
  std::string session_id;
  Indy500SessionType type = Indy500SessionType::Practice;
  bool completed = false;
  bool weather_interrupted = false;
  std::size_t runs_completed = 0;
  double track_time_used_h = 0.0;
};

struct Indy500CompleteMonthResult {
  bool event_ready = false;
  std::vector<Indy500EntryOperationsResult> entries;
  std::vector<Indy500SessionOutcome> sessions;
  std::vector<std::string> qualifying_order;
  std::vector<std::string> fast_six;
  std::vector<std::string> last_chance_entries;
  std::string pit_stop_challenge_winner;
  double expected_race_duration_s = 0.0;
  std::vector<std::string> event_issues;
  std::string evidence_sha256;
};

class Indy500CompleteMonthOfMayOperationsTwin {
 public:
  Indy500CompleteMonthResult simulate(
      const std::vector<Indy500CompleteEntry>& entries,
      const std::vector<Indy500SessionPlan>& sessions,
      std::size_t starting_field_size,
      std::uint64_t deterministic_seed) const;
};

}  // namespace aesim::advanced

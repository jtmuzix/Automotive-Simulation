#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::f1eco {

class F1PowerUnitFinancialCompliancePlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1TyreProductionMetrologyPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1SustainableFuelProductionLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1FactoryManufacturingTwin {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1VehicleAssemblyVariationTwin {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1CausalRaceEngineeringOptimizer {
public:
    [[nodiscard]] doc::Value optimize(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1AerodynamicRaceabilityDesignLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1CyberPhysicalSecurityLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1DriverMedicalPerformanceLaboratory {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class F1DriverDevelopmentLadderPlatform {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class FormulaOneIndustrialEcosystemPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::f1eco

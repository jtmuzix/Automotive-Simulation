#pragma once

#include "aesim/advanced/formula_one_performance_laboratory.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// Multi-car race dynamics and racecraft.
struct F1CompetitionCarState {
    std::string car_id;
    std::string team_id;
    double lap_distance_m = 0.0;
    int lap = 0;
    double lateral_offset_m = 0.0;
    double speed_m_s = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    double tyre_grip_multiplier = 1.0;
    double energy_store_soc = 0.5;
    double aerodynamic_damage = 0.0;
    double reliability_health = 1.0;
    double driver_aggression = 0.5;
    double driver_skill = 0.8;
    bool retired = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CompetitionCarCommand {
    double throttle = 0.0;
    double brake = 0.0;
    double target_lateral_offset_m = 0.0;
    double deployment_kw = 0.0;
    bool defend = false;
    bool attempt_overtake = false;
};

struct F1CompetitionTrackPoint {
    double distance_m = 0.0;
    double curvature_1_m = 0.0;
    double width_m = 12.0;
    double grip_multiplier = 1.0;
    double overtaking_quality = 0.5;
};

struct F1RaceInteraction {
    std::string trailing_car;
    std::string leading_car;
    double longitudinal_gap_m = 0.0;
    double lateral_overlap_m = 0.0;
    double downforce_multiplier = 1.0;
    double drag_multiplier = 1.0;
    double cooling_multiplier = 1.0;
    double collision_probability = 0.0;
    bool side_by_side = false;
    bool contact = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1MultiCarStepResult {
    std::vector<F1CompetitionCarState> cars;
    std::vector<F1RaceInteraction> interactions;
    std::vector<std::string> position_order;
    std::vector<std::string> events;
    double simulation_time_s = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1MultiCarRacecraftLaboratory {
public:
    explicit F1MultiCarRacecraftLaboratory(std::vector<F1CompetitionTrackPoint> track,
                                           double lap_length_m);
    [[nodiscard]] F1MultiCarStepResult step(
        double time_step_s,
        const std::vector<F1CompetitionCarState>& previous,
        const std::map<std::string, F1CompetitionCarCommand>& commands) const;
    [[nodiscard]] F1CompetitionCarCommand choose_racecraft_command(
        const F1CompetitionCarState& ego,
        const F1CompetitionCarState& opponent,
        double target_speed_m_s) const;
private:
    std::vector<F1CompetitionTrackPoint> track_;
    double lap_length_m_ = 0.0;
};

// Pit-stop, garage, and trackside operations.
enum class F1PitTaskKind { Jack, RemoveWheel, FitWheel, WheelGun, FrontWing, Release, Inspection, Repair };

struct F1CrewMember {
    std::string id;
    std::string role;
    double skill = 0.9;
    double fatigue = 0.0;
    double reaction_time_s = 0.18;
    void validate() const;
};

struct F1PitEquipment {
    std::string id;
    std::string kind;
    double nominal_cycle_s = 0.25;
    double reliability = 0.999;
    double recovery_time_s = 2.0;
    void validate() const;
};

struct F1PitTask {
    std::string id;
    F1PitTaskKind kind = F1PitTaskKind::Inspection;
    std::vector<std::string> predecessors;
    std::string crew_role;
    std::string equipment_kind;
    double nominal_duration_s = 0.2;
    bool safety_critical = false;
};

struct F1PitStopRequest {
    std::string car_id;
    std::vector<F1PitTask> tasks;
    bool front_wing_change = false;
    bool double_stack = false;
    double traffic_release_gap_s = 10.0;
    std::uint64_t random_seed = 1;
};

struct F1TaskExecution {
    std::string task_id;
    double start_s = 0.0;
    double finish_s = 0.0;
    std::string crew_id;
    std::string equipment_id;
    bool failed = false;
    bool recovered = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PitStopResult {
    double stationary_time_s = 0.0;
    double release_time_s = 0.0;
    bool unsafe_release = false;
    bool completed = false;
    std::vector<F1TaskExecution> executions;
    std::vector<std::string> warnings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1GarageWorkOrder {
    std::string id;
    std::string car_id;
    std::string operation;
    double labor_hours = 0.0;
    std::map<std::string, int> required_parts;
    std::vector<std::string> predecessors;
    double deadline_s = 0.0;
};

struct F1GarageScheduleEntry {
    std::string work_order_id;
    double start_s = 0.0;
    double finish_s = 0.0;
    bool parts_available = false;
    bool deadline_met = false;
    [[nodiscard]] doc::Value to_document() const;
};

class F1TracksideOperationsTwin {
public:
    void set_crew(std::vector<F1CrewMember> crew);
    void set_equipment(std::vector<F1PitEquipment> equipment);
    void set_inventory(std::map<std::string, int> inventory);
    [[nodiscard]] F1PitStopResult simulate_pit_stop(const F1PitStopRequest& request) const;
    [[nodiscard]] std::vector<F1GarageScheduleEntry> schedule_garage(
        const std::vector<F1GarageWorkOrder>& orders,
        double available_technicians) const;
private:
    std::vector<F1CrewMember> crew_;
    std::vector<F1PitEquipment> equipment_;
    std::map<std::string, int> inventory_;
};

// Sporting regulations, race control, and stewarding.
enum class F1RaceControlPhase { Green, LocalYellow, DoubleYellow, VirtualSafetyCar, SafetyCar, RedFlag, FormationLap, Finished };
enum class F1IncidentKind { TrackLimits, PitSpeeding, UnsafeRelease, YellowOvertake, Collision, Impeding, JumpStart, VscDelta, Other };
enum class F1PenaltyKind { None, Warning, Reprimand, FiveSeconds, TenSeconds, DriveThrough, StopGo, GridDrop, Disqualification };

struct F1SportingRule {
    std::string id;
    F1IncidentKind incident = F1IncidentKind::Other;
    double threshold = 0.0;
    F1PenaltyKind default_penalty = F1PenaltyKind::Warning;
    bool strict_liability = false;
    std::string rationale;
};

struct F1SportingProfile {
    int season = 2026;
    std::string section = "B";
    int issue = 7;
    std::string publication_date = "2026-06-25";
    std::vector<F1SportingRule> rules;
    [[nodiscard]] static F1SportingProfile fia_2026_issue_07();
};

struct F1RaceControlCommand {
    F1RaceControlPhase phase = F1RaceControlPhase::Green;
    double reference_speed_m_s = 0.0;
    double required_delta_s = 0.0;
    int sector = -1;
    std::string message;
};

struct F1IncidentEvidence {
    F1IncidentKind kind = F1IncidentKind::Other;
    std::string car_id;
    std::string other_car_id;
    double timestamp_s = 0.0;
    double measured_value = 0.0;
    double uncertainty = 0.0;
    bool mitigating_action = false;
    bool gained_advantage = false;
    std::map<std::string, double> channels;
};

struct F1StewardDecision {
    std::string rule_id;
    bool infringement = false;
    F1PenaltyKind penalty = F1PenaltyKind::None;
    double confidence = 0.0;
    double severity = 0.0;
    std::string reasoning;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1SportingRaceControlEngine {
public:
    explicit F1SportingRaceControlEngine(F1SportingProfile profile = F1SportingProfile::fia_2026_issue_07());
    void apply_command(const F1RaceControlCommand& command);
    [[nodiscard]] const F1RaceControlCommand& current_command() const noexcept;
    [[nodiscard]] double delta_compliance(double elapsed_s, double reference_elapsed_s) const;
    [[nodiscard]] F1StewardDecision adjudicate(const F1IncidentEvidence& evidence) const;
private:
    F1SportingProfile profile_;
    F1RaceControlCommand command_;
};

// Trackside sensor metrology and correlation campaigns.
struct F1TracksideSensor {
    std::string id;
    std::string quantity;
    std::string unit;
    double scale = 1.0;
    double bias = 0.0;
    double standard_uncertainty = 0.0;
    double drift_per_hour = 0.0;
    double bandwidth_hz = 100.0;
    double sample_rate_hz = 1000.0;
    double time_offset_s = 0.0;
    void validate() const;
};

struct F1SensorSample {
    std::string sensor_id;
    double timestamp_s = 0.0;
    double raw_value = 0.0;
};

struct F1CalibratedSample {
    std::string sensor_id;
    double timestamp_s = 0.0;
    double value = 0.0;
    double standard_uncertainty = 0.0;
};

struct F1CorrelationObservation {
    std::string run_id;
    std::string channel;
    double model_value = 0.0;
    double measured_value = 0.0;
    double standard_uncertainty = 1.0;
    std::string configuration;
};

struct F1CorrelationChannelResult {
    std::string channel;
    double scale = 1.0;
    double bias = 0.0;
    double rmse = 0.0;
    double normalized_rms = 0.0;
    double correlation = 0.0;
    std::size_t observations = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CampaignReport {
    std::vector<F1CalibratedSample> calibrated_samples;
    std::vector<F1CorrelationChannelResult> channels;
    std::vector<std::string> outliers;
    double synchronization_error_s = 0.0;
    double overall_score = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1TracksideMetrologyCampaign {
public:
    void register_sensor(F1TracksideSensor sensor);
    [[nodiscard]] F1CalibratedSample calibrate(const F1SensorSample& sample,
                                               double elapsed_hours = 0.0) const;
    [[nodiscard]] F1CampaignReport analyze(
        const std::vector<F1SensorSample>& samples,
        const std::vector<F1CorrelationObservation>& observations) const;
private:
    std::map<std::string, F1TracksideSensor> sensors_;
};

// Competitor intelligence, game theory, and championship optimization.
struct F1CompetitorBelief {
    std::string competitor_id;
    double pace_mean_s = 90.0;
    double pace_std_s = 0.5;
    double pit_loss_mean_s = 22.0;
    double pit_loss_std_s = 1.0;
    double tyre_degradation_s_lap = 0.08;
    double reliability_probability = 0.98;
    double aggression = 0.5;
    double wet_skill = 0.7;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1CompetitorObservation {
    std::string competitor_id;
    double lap_time_s = 90.0;
    double tyre_age_laps = 0.0;
    bool pitted = false;
    double observed_pit_loss_s = 0.0;
    bool retired = false;
};

enum class F1StrategicAction { Attack, Defend, Pit, Extend, Conserve, Undercut, Overcut };

struct F1GameScenario {
    F1CompetitorBelief ego;
    std::vector<F1CompetitorBelief> opponents;
    int laps_remaining = 10;
    double ego_tyre_age_laps = 0.0;
    double ego_energy_soc = 0.5;
    double rain_probability = 0.0;
    bool safety_car = false;
    std::map<F1StrategicAction, double> action_cost_s;
};

struct F1StrategicRecommendation {
    F1StrategicAction action = F1StrategicAction::Conserve;
    double expected_finish_position = 20.0;
    double win_probability = 0.0;
    double podium_probability = 0.0;
    double expected_points = 0.0;
    double championship_value = 0.0;
    std::map<F1StrategicAction, double> action_values;
    std::string rationale;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1CompetitorGameTheoryOptimizer {
public:
    explicit F1CompetitorGameTheoryOptimizer(std::uint64_t seed = 1);
    void set_belief(F1CompetitorBelief belief);
    void update(const F1CompetitorObservation& observation);
    [[nodiscard]] std::optional<F1CompetitorBelief> belief(const std::string& competitor_id) const;
    [[nodiscard]] F1StrategicRecommendation optimize(const F1GameScenario& scenario,
                                                     std::size_t simulations = 2000) const;
private:
    std::uint64_t seed_ = 1;
    std::map<std::string, F1CompetitorBelief> beliefs_;
};

} // namespace aesim::advanced

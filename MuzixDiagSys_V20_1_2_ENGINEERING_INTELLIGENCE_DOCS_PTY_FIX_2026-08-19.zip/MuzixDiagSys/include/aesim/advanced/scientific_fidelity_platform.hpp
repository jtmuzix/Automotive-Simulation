#pragma once

#include "aesim/advanced/generalized_simulation_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

using ScientificVector = std::vector<double>;
using ScientificMatrix = std::vector<ScientificVector>;

// -----------------------------------------------------------------------------
// Strongly coupled multiphysics solver.
// -----------------------------------------------------------------------------

struct MultiphysicsBlockDescriptor {
    std::string id;
    std::size_t size = 0;
    double residual_scale = 1.0;
    double update_scale = 1.0;
};

struct MultiphysicsConservationMetric {
    std::string id;
    double initial = 0.0;
    double input = 0.0;
    double output = 0.0;
    double stored = 0.0;
    double residual = 0.0;
};

struct MultiphysicsNewtonOptions {
    std::size_t maximum_iterations = 40;
    double absolute_tolerance = 1.0e-10;
    double relative_tolerance = 1.0e-8;
    double finite_difference_step = 1.0e-7;
    double minimum_line_search_factor = 1.0e-6;
    double regularization = 1.0e-12;
};

struct MultiphysicsIterationRecord {
    std::size_t iteration = 0;
    double residual_norm = 0.0;
    double update_norm = 0.0;
    double line_search_factor = 1.0;
};

struct MultiphysicsSolveReport {
    bool converged = false;
    ScientificVector state;
    ScientificVector residual;
    std::vector<MultiphysicsIterationRecord> history;
    std::vector<MultiphysicsConservationMetric> conservation;
    std::size_t linear_solves = 0;
    std::string termination_reason;
};

class StronglyCoupledMultiphysicsSolver {
public:
    using ResidualFunction = std::function<ScientificVector(const ScientificVector&)>;
    using JacobianFunction = std::function<ScientificMatrix(const ScientificVector&)>;
    using ConservationFunction =
        std::function<std::vector<MultiphysicsConservationMetric>(const ScientificVector&)>;

    void configure(std::vector<MultiphysicsBlockDescriptor> blocks,
                   ResidualFunction residual,
                   std::optional<JacobianFunction> jacobian = std::nullopt,
                   std::optional<ConservationFunction> conservation = std::nullopt);

    [[nodiscard]] MultiphysicsSolveReport solve(
        const ScientificVector& initial_state,
        const MultiphysicsNewtonOptions& options = {}) const;

    [[nodiscard]] const std::vector<MultiphysicsBlockDescriptor>& blocks() const noexcept;

private:
    std::vector<MultiphysicsBlockDescriptor> blocks_;
    ResidualFunction residual_;
    std::optional<JacobianFunction> jacobian_;
    std::optional<ConservationFunction> conservation_;
};

// -----------------------------------------------------------------------------
// High-order hp-adaptive discontinuous-Galerkin PDE framework.
// -----------------------------------------------------------------------------

struct HpPdeCell {
    double left = 0.0;
    double right = 0.0;
    std::size_t polynomial_order = 1;
    ScientificVector modal_coefficients;
    std::size_t refinement_level = 0;
};

struct HpPdeConfiguration {
    double advection_speed = 1.0;
    double diffusivity = 0.0;
    double reaction_rate = 0.0;
    bool periodic = true;
    std::size_t minimum_order = 1;
    std::size_t maximum_order = 8;
    std::size_t maximum_refinement_level = 8;
    double refine_indicator = 2.0e-3;
    double coarsen_indicator = 1.0e-5;
    double cfl = 0.2;
};

struct HpPdeStepReport {
    double time = 0.0;
    double time_step = 0.0;
    double mass = 0.0;
    double minimum_value = 0.0;
    double maximum_value = 0.0;
    std::size_t cells = 0;
    std::size_t degrees_of_freedom = 0;
    std::size_t h_refinements = 0;
    std::size_t p_refinements = 0;
    std::size_t coarsenings = 0;
};

class HpAdaptiveDiscontinuousGalerkinSolver {
public:
    using InitialCondition = std::function<double(double)>;
    using SourceFunction = std::function<double(double, double, double)>;

    void configure(double domain_left, double domain_right,
                   std::size_t initial_cells,
                   HpPdeConfiguration configuration,
                   InitialCondition initial_condition,
                   SourceFunction source = {});

    [[nodiscard]] HpPdeStepReport advance(double final_time);
    [[nodiscard]] double evaluate(double x) const;
    [[nodiscard]] double integral() const;
    [[nodiscard]] double l2_error(const std::function<double(double)>& exact) const;
    [[nodiscard]] const std::vector<HpPdeCell>& cells() const noexcept;

private:
    HpPdeConfiguration configuration_;
    std::vector<HpPdeCell> cells_;
    SourceFunction source_;
    double time_ = 0.0;

    [[nodiscard]] ScientificVector spatial_operator(const std::vector<HpPdeCell>& cells,
                                                    std::size_t cell_index) const;
    void adapt(HpPdeStepReport& report);
};

// -----------------------------------------------------------------------------
// Nonsmooth complementarity-based contact mechanics.
// -----------------------------------------------------------------------------

struct ContactBodyState {
    std::string id;
    double mass = 1.0;
    ScientificVector position{0.0, 0.0, 0.0};
    ScientificVector velocity{0.0, 0.0, 0.0};
    bool fixed = false;
};

struct ContactConstraint {
    std::string id;
    std::size_t body_a = 0;
    std::optional<std::size_t> body_b;
    ScientificVector normal{0.0, 1.0, 0.0};
    ScientificVector tangent{1.0, 0.0, 0.0};
    double gap = 0.0;
    double friction = 0.8;
    double restitution = 0.0;
    double normal_compliance = 0.0;
};

struct ContactImpulseResult {
    std::string constraint_id;
    double normal_impulse = 0.0;
    double tangential_impulse = 0.0;
    double complementarity_residual = 0.0;
    bool sticking = false;
};

struct ContactSolveReport {
    bool converged = false;
    std::size_t iterations = 0;
    double maximum_complementarity_residual = 0.0;
    double kinetic_energy_before = 0.0;
    double kinetic_energy_after = 0.0;
    std::vector<ContactImpulseResult> impulses;
};

class NonsmoothComplementarityContactSolver {
public:
    void configure(std::size_t maximum_iterations = 200,
                   double tolerance = 1.0e-10,
                   double relaxation = 1.0);

    [[nodiscard]] ContactSolveReport solve_velocity_impulses(
        std::vector<ContactBodyState>& bodies,
        const std::vector<ContactConstraint>& contacts,
        double time_step) const;

    void advance_positions(std::vector<ContactBodyState>& bodies, double time_step) const;

private:
    std::size_t maximum_iterations_ = 200;
    double tolerance_ = 1.0e-10;
    double relaxation_ = 1.0;
};

// -----------------------------------------------------------------------------
// Spatial stochastic fields and uncertain geometry.
// -----------------------------------------------------------------------------

enum class StochasticCovarianceModel {
    Exponential,
    SquaredExponential,
    Matern32,
    Matern52
};

struct StochasticFieldConfiguration {
    double mean = 0.0;
    double standard_deviation = 1.0;
    double correlation_length = 1.0;
    StochasticCovarianceModel covariance = StochasticCovarianceModel::Matern32;
    std::size_t retained_modes = 16;
    std::uint64_t seed = 1;
};

struct StochasticObservation {
    std::size_t point_index = 0;
    double value = 0.0;
    double standard_deviation = 1.0e-6;
};

struct StochasticFieldSample {
    ScientificVector values;
    ScientificVector coefficients;
    double captured_variance_fraction = 0.0;
};

class SpatialStochasticFieldModel {
public:
    void configure(std::vector<ScientificVector> points,
                   StochasticFieldConfiguration configuration);

    [[nodiscard]] StochasticFieldSample sample(std::uint64_t sample_index = 0) const;
    [[nodiscard]] StochasticFieldSample conditional_sample(
        const std::vector<StochasticObservation>& observations,
        std::uint64_t sample_index = 0) const;
    [[nodiscard]] ScientificMatrix covariance_matrix() const;
    [[nodiscard]] std::vector<ScientificVector> perturb_geometry(
        const std::vector<ScientificVector>& vertices,
        const std::vector<ScientificVector>& directions,
        const StochasticFieldSample& sample,
        double scale = 1.0) const;

private:
    std::vector<ScientificVector> points_;
    StochasticFieldConfiguration configuration_;
    ScientificVector eigenvalues_;
    ScientificMatrix eigenvectors_;
};

// -----------------------------------------------------------------------------
// Field-scale data assimilation and PDE-constrained inversion.
// -----------------------------------------------------------------------------

struct FieldObservation {
    std::size_t index = 0;
    double value = 0.0;
    double variance = 1.0;
};

struct FieldAssimilationReport {
    ScientificVector posterior_mean;
    ScientificMatrix posterior_covariance;
    double prior_misfit = 0.0;
    double posterior_misfit = 0.0;
    std::size_t accepted_observations = 0;
};

class EnsembleFieldAssimilator {
public:
    using Propagator = std::function<ScientificVector(const ScientificVector&)>;

    void configure(std::vector<ScientificVector> ensemble,
                   std::uint64_t seed = 1,
                   double inflation = 1.0,
                   double localization_radius = 0.0,
                   std::vector<ScientificVector> field_coordinates = {});

    void propagate(const Propagator& propagator);
    [[nodiscard]] FieldAssimilationReport assimilate(
        const std::vector<FieldObservation>& observations);
    [[nodiscard]] const std::vector<ScientificVector>& ensemble() const noexcept;

private:
    std::vector<ScientificVector> ensemble_;
    std::uint64_t seed_ = 1;
    double inflation_ = 1.0;
    double localization_radius_ = 0.0;
    std::vector<ScientificVector> coordinates_;
};

struct PdeInversionOptions {
    std::size_t maximum_iterations = 80;
    double gradient_tolerance = 1.0e-8;
    double initial_step = 1.0;
    double minimum_step = 1.0e-10;
    double regularization = 1.0e-6;
    double finite_difference_step = 1.0e-6;
};

struct PdeInversionIteration {
    std::size_t iteration = 0;
    double objective = 0.0;
    double gradient_norm = 0.0;
    double step = 0.0;
};

struct PdeInversionReport {
    bool converged = false;
    ScientificVector parameters;
    ScientificVector predicted_observations;
    std::vector<PdeInversionIteration> history;
    ScientificMatrix approximate_parameter_covariance;
};

class PdeConstrainedInverseSolver {
public:
    using ForwardModel = std::function<ScientificVector(const ScientificVector&)>;
    using JacobianModel = std::function<ScientificMatrix(const ScientificVector&)>;

    void configure(ForwardModel forward,
                   ScientificVector measured,
                   ScientificMatrix measurement_covariance,
                   ScientificVector prior,
                   ScientificMatrix prior_covariance,
                   std::optional<JacobianModel> jacobian = std::nullopt);

    [[nodiscard]] PdeInversionReport solve(
        const ScientificVector& initial_parameters,
        const PdeInversionOptions& options = {}) const;

private:
    ForwardModel forward_;
    ScientificVector measured_;
    ScientificMatrix measurement_covariance_;
    ScientificVector prior_;
    ScientificMatrix prior_covariance_;
    std::optional<JacobianModel> jacobian_;
};

// -----------------------------------------------------------------------------
// Real-fluid thermodynamics and phase equilibrium.
// -----------------------------------------------------------------------------

struct RealFluidComponent {
    std::string id;
    double critical_temperature_k = 0.0;
    double critical_pressure_pa = 0.0;
    double acentric_factor = 0.0;
    double molar_mass_kg_per_mol = 0.0;
    double ideal_heat_capacity_j_per_mol_k = 0.0;
};

struct RealFluidState {
    double temperature_k = 0.0;
    double pressure_pa = 0.0;
    double compressibility_factor = 1.0;
    double molar_density_mol_per_m3 = 0.0;
    double mass_density_kg_per_m3 = 0.0;
    double molar_enthalpy_j_per_mol = 0.0;
    ScientificVector fugacity_coefficients;
};

struct PhaseEquilibriumReport {
    bool converged = false;
    bool single_liquid = false;
    bool single_vapor = false;
    std::size_t iterations = 0;
    double vapor_fraction = 0.0;
    ScientificVector liquid_composition;
    ScientificVector vapor_composition;
    ScientificVector equilibrium_ratios;
    RealFluidState liquid;
    RealFluidState vapor;
    double material_balance_residual = 0.0;
};

class PengRobinsonThermodynamics {
public:
    void configure(std::vector<RealFluidComponent> components,
                   ScientificMatrix binary_interaction = {});

    [[nodiscard]] RealFluidState evaluate(double temperature_k,
                                          double pressure_pa,
                                          const ScientificVector& mole_fractions,
                                          bool liquid_root) const;

    [[nodiscard]] PhaseEquilibriumReport flash_pt(
        double temperature_k,
        double pressure_pa,
        const ScientificVector& overall_composition,
        std::size_t maximum_iterations = 100,
        double tolerance = 1.0e-10) const;

private:
    std::vector<RealFluidComponent> components_;
    ScientificMatrix binary_interaction_;
};

// -----------------------------------------------------------------------------
// Bayesian multimodel inference and model averaging.
// -----------------------------------------------------------------------------

struct BayesianModelEvidence {
    std::string model_id;
    double log_prior_probability = 0.0;
    double log_marginal_likelihood = 0.0;
    double predictive_mean = 0.0;
    double predictive_variance = 0.0;
};

struct BayesianModelPosterior {
    std::string model_id;
    double posterior_probability = 0.0;
    double log_bayes_factor_to_best = 0.0;
};

struct BayesianModelAverageReport {
    std::vector<BayesianModelPosterior> models;
    double predictive_mean = 0.0;
    double predictive_variance = 0.0;
    double effective_model_count = 0.0;
    std::string maximum_probability_model;
};

class BayesianMultimodelInference {
public:
    [[nodiscard]] BayesianModelAverageReport infer(
        const std::vector<BayesianModelEvidence>& evidence) const;

    [[nodiscard]] BayesianModelAverageReport sequential_update(
        const BayesianModelAverageReport& prior_report,
        const std::vector<BayesianModelEvidence>& new_evidence) const;

    [[nodiscard]] ScientificVector optimize_stacking_weights(
        const ScientificMatrix& log_predictive_density,
        std::size_t maximum_iterations = 2000,
        double learning_rate = 0.05) const;
};

// -----------------------------------------------------------------------------
// Quantitative total simulation error-budget propagation.
// -----------------------------------------------------------------------------

enum class SimulationErrorCategory {
    Measurement,
    Parameter,
    Numerical,
    ModelForm,
    Sampling,
    Implementation,
    BoundaryCondition,
    InitialCondition,
    Surrogate
};

struct SimulationErrorSource {
    std::string id;
    SimulationErrorCategory category = SimulationErrorCategory::Parameter;
    double standard_uncertainty = 0.0;
    double sensitivity = 1.0;
    std::size_t degrees_of_freedom = 0;
};

struct SimulationErrorContribution {
    std::string id;
    SimulationErrorCategory category = SimulationErrorCategory::Parameter;
    double variance = 0.0;
    double fractional_variance = 0.0;
};

struct SimulationErrorBudgetReport {
    double nominal_value = 0.0;
    double combined_standard_uncertainty = 0.0;
    double effective_degrees_of_freedom = 0.0;
    double coverage_factor = 1.96;
    double expanded_uncertainty = 0.0;
    double lower_interval = 0.0;
    double upper_interval = 0.0;
    double probability_below_limit = 0.0;
    std::vector<SimulationErrorContribution> contributions;
};

class QuantitativeSimulationErrorBudget {
public:
    void configure(std::vector<SimulationErrorSource> sources,
                   ScientificMatrix correlation = {});

    [[nodiscard]] SimulationErrorBudgetReport evaluate(
        double nominal_value,
        std::optional<double> upper_limit = std::nullopt,
        double confidence = 0.95) const;

private:
    std::vector<SimulationErrorSource> sources_;
    ScientificMatrix correlation_;
};

// -----------------------------------------------------------------------------
// Experimental metrology and virtual instrumentation.
// -----------------------------------------------------------------------------

struct VirtualInstrumentConfiguration {
    std::string id;
    std::string unit;
    double sample_rate_hz = 1000.0;
    double time_constant_s = 0.0;
    double transport_delay_s = 0.0;
    double aperture_s = 0.0;
    double bias = 0.0;
    double scale_factor = 1.0;
    double nonlinearity = 0.0;
    double noise_standard_deviation = 0.0;
    double random_walk_standard_deviation_per_sqrt_s = 0.0;
    double quantization_step = 0.0;
    double minimum_value = -1.0e300;
    double maximum_value = 1.0e300;
    ScientificVector calibration_polynomial{0.0, 1.0};
    std::uint64_t seed = 1;
};

struct VirtualInstrumentSample {
    std::string instrument_id;
    double truth_time_s = 0.0;
    double reported_time_s = 0.0;
    double truth_value = 0.0;
    double analog_value = 0.0;
    double reported_value = 0.0;
    double standard_uncertainty = 0.0;
    bool saturated = false;
};

class VirtualInstrument {
public:
    explicit VirtualInstrument(VirtualInstrumentConfiguration configuration);

    [[nodiscard]] std::vector<VirtualInstrumentSample> process(
        double begin_time_s,
        double end_time_s,
        const std::function<double(double)>& truth_signal);
    void reset();
    [[nodiscard]] const VirtualInstrumentConfiguration& configuration() const noexcept;

private:
    VirtualInstrumentConfiguration configuration_;
    double filtered_value_ = 0.0;
    double random_walk_bias_ = 0.0;
    bool initialized_ = false;
    std::mt19937_64 generator_;
};

struct MetrologyAcquisitionReport {
    std::map<std::string, std::vector<VirtualInstrumentSample>> channels;
    std::size_t total_samples = 0;
    double earliest_reported_time_s = 0.0;
    double latest_reported_time_s = 0.0;
};

class VirtualInstrumentationLaboratory {
public:
    void add_instrument(VirtualInstrumentConfiguration configuration);
    [[nodiscard]] MetrologyAcquisitionReport acquire(
        double begin_time_s,
        double end_time_s,
        const std::map<std::string, std::function<double(double)>>& truth_signals);
    void reset();

private:
    std::map<std::string, VirtualInstrument> instruments_;
};

// -----------------------------------------------------------------------------
// Advanced fracture and progressive-failure mechanics.
// -----------------------------------------------------------------------------

enum class ProgressiveFailureMode {
    Elastic,
    MatrixTension,
    MatrixCompression,
    FibreTension,
    FibreCompression,
    Shear,
    CohesiveOpening,
    CohesiveShear,
    Fractured
};

struct ProgressiveFailureMaterial {
    double young_modulus_pa = 1.0;
    double shear_modulus_pa = 1.0;
    double tensile_strength_pa = 1.0;
    double compressive_strength_pa = 1.0;
    double shear_strength_pa = 1.0;
    double fracture_energy_j_per_m2 = 1.0;
    double characteristic_length_m = 1.0;
    double residual_stiffness_fraction = 1.0e-6;
    double fatigue_threshold = 0.0;
    double paris_coefficient = 0.0;
    double paris_exponent = 2.0;
    double critical_crack_length_m = 1.0;
};

struct ProgressiveFailureState {
    double damage = 0.0;
    double maximum_equivalent_strain = 0.0;
    double dissipated_energy_j_per_m3 = 0.0;
    double crack_length_m = 0.0;
    double fatigue_cycles = 0.0;
    ProgressiveFailureMode mode = ProgressiveFailureMode::Elastic;
};

struct ProgressiveFailureResponse {
    ScientificVector stress;
    double tangent_modulus_pa = 0.0;
    double equivalent_stress_pa = 0.0;
    double damage_increment = 0.0;
    bool failed = false;
};

class ProgressiveFailureMaterialPoint {
public:
    explicit ProgressiveFailureMaterialPoint(ProgressiveFailureMaterial material);

    [[nodiscard]] ProgressiveFailureResponse update(
        const ScientificVector& strain,
        double cycle_increment = 0.0,
        double stress_intensity_range_pa_sqrt_m = 0.0);
    [[nodiscard]] const ProgressiveFailureState& state() const noexcept;
    void reset();

private:
    ProgressiveFailureMaterial material_;
    ProgressiveFailureState state_;
};

struct CohesiveZoneResponse {
    double normal_traction_pa = 0.0;
    double shear_traction_pa = 0.0;
    double damage = 0.0;
    double dissipated_energy_j_per_m2 = 0.0;
    bool separated = false;
};

class MixedModeCohesiveZone {
public:
    void configure(double normal_stiffness_pa_per_m,
                   double shear_stiffness_pa_per_m,
                   double normal_strength_pa,
                   double shear_strength_pa,
                   double mode_i_energy_j_per_m2,
                   double mode_ii_energy_j_per_m2,
                   double bk_exponent = 1.5);

    [[nodiscard]] CohesiveZoneResponse update(double normal_separation_m,
                                              double shear_separation_m);
    void reset();

private:
    double normal_stiffness_ = 0.0;
    double shear_stiffness_ = 0.0;
    double normal_strength_ = 0.0;
    double shear_strength_ = 0.0;
    double mode_i_energy_ = 0.0;
    double mode_ii_energy_ = 0.0;
    double bk_exponent_ = 1.5;
    double damage_ = 0.0;
    double dissipated_energy_ = 0.0;
    double previous_effective_separation_ = 0.0;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/advanced/formula_one_multiphysics_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// All quantities use SI units unless the member name states otherwise. Every
// stochastic subsystem is deterministic for identical inputs and seeds.

// -----------------------------------------------------------------------------
// Geometry-based suspension K&C and steering twin.
// -----------------------------------------------------------------------------

struct F1SuspensionHardpoint {
    std::string id;
    F1FidelityVector3 position_m{};
};

struct F1SuspensionCornerGeometry {
    std::string id;
    F1FidelityVector3 wheel_center_m{};
    F1FidelityVector3 upper_ball_joint_m{};
    F1FidelityVector3 lower_ball_joint_m{};
    F1FidelityVector3 tie_rod_outer_m{};
    F1FidelityVector3 upper_inner_front_m{};
    F1FidelityVector3 upper_inner_rear_m{};
    F1FidelityVector3 lower_inner_front_m{};
    F1FidelityVector3 lower_inner_rear_m{};
    F1FidelityVector3 tie_rod_inner_m{};
    F1FidelityVector3 pushrod_outer_m{};
    F1FidelityVector3 pushrod_inner_m{};
    double wheel_radius_m = 0.355;
    double static_toe_rad = 0.0;
    double static_camber_rad = -0.05235987755982989;
    double vertical_compliance_m_n = 1.5e-8;
    double camber_compliance_rad_n = 2.0e-7;
    double toe_compliance_rad_n = 1.2e-7;
    double steering_compliance_rad_nm = 1.0e-5;

    void validate() const;
};

struct F1SuspensionKandCConfiguration {
    std::array<F1SuspensionCornerGeometry, 4> corners;
    double rack_ratio_m_per_steering_rad = 0.015;
    double steering_column_stiffness_nm_rad = 850.0;
    double steering_column_damping_nm_s_rad = 12.0;
    double solver_tolerance_m = 1.0e-10;
    std::size_t maximum_solver_iterations = 50;

    void validate() const;
};

struct F1SuspensionCornerInput {
    double wheel_travel_m = 0.0;
    double rack_displacement_m = 0.0;
    double vertical_load_n = 0.0;
    double lateral_load_n = 0.0;
    double aligning_moment_nm = 0.0;
};

struct F1SuspensionCornerResult {
    std::string id;
    F1FidelityVector3 wheel_center_m{};
    double camber_rad = 0.0;
    double toe_rad = 0.0;
    double caster_rad = 0.0;
    double kingpin_inclination_rad = 0.0;
    double mechanical_trail_m = 0.0;
    double scrub_radius_m = 0.0;
    double motion_ratio = 1.0;
    double jacking_force_n = 0.0;
    double residual_norm_m = 0.0;
    std::size_t iterations = 0;
    bool converged = false;
};

struct F1SuspensionAxleMetrics {
    double roll_center_height_m = 0.0;
    double anti_dive_fraction = 0.0;
    double anti_squat_fraction = 0.0;
    double ackermann_fraction = 0.0;
};

struct F1SuspensionKandCResult {
    std::array<F1SuspensionCornerResult, 4> corners;
    F1SuspensionAxleMetrics front;
    F1SuspensionAxleMetrics rear;
    double steering_wheel_angle_rad = 0.0;
    double steering_column_torque_nm = 0.0;
    bool finite = true;
};

class F1SuspensionGeometryTwin {
public:
    explicit F1SuspensionGeometryTwin(F1SuspensionKandCConfiguration configuration);
    [[nodiscard]] const F1SuspensionKandCConfiguration& configuration() const noexcept;
    [[nodiscard]] F1SuspensionKandCResult solve(
        const std::array<F1SuspensionCornerInput, 4>& inputs,
        double steering_wheel_angle_rad,
        double steering_wheel_rate_rad_s = 0.0) const;
    [[nodiscard]] std::vector<F1SuspensionCornerResult> sweep_corner(
        std::size_t corner_index,
        double minimum_travel_m,
        double maximum_travel_m,
        std::size_t samples,
        double rack_displacement_m = 0.0) const;

private:
    F1SuspensionKandCConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Flexible-ring viscoelastic tyre and distributed tread contact.
// -----------------------------------------------------------------------------

struct F1TyrePronyTerm {
    double modulus_fraction = 0.0;
    double relaxation_time_s = 0.01;
};

struct F1FlexibleRingTyreConfiguration {
    std::size_t ring_nodes = 48;
    double unloaded_radius_m = 0.355;
    double width_m = 0.305;
    double belt_mass_kg = 8.0;
    double radial_stiffness_n_m = 3.2e5;
    double circumferential_stiffness_n_m = 1.8e5;
    double lateral_stiffness_n_m = 1.4e5;
    double structural_damping_n_s_m = 950.0;
    double tread_bristle_longitudinal_n_m = 1.8e7;
    double tread_bristle_lateral_n_m = 1.4e7;
    double tread_bristle_damping_n_s_m = 2800.0;
    double base_rubber_modulus_pa = 8.0e6;
    double glass_transition_temperature_k = 243.15;
    double wlf_c1 = 17.44;
    double wlf_c2_k = 51.6;
    std::vector<F1TyrePronyTerm> prony_terms;
    double dry_friction = 1.90;
    double wet_friction = 0.85;
    double hydrodynamic_lift_coefficient = 0.65;
    double groove_drainage_m2_s = 1.8e-5;
    double tread_heat_capacity_j_k = 24000.0;
    double belt_heat_capacity_j_k = 52000.0;
    double tread_to_belt_w_k = 620.0;
    double tread_to_road_w_k = 420.0;
    double belt_to_air_w_k = 105.0;
    double wear_energy_j = 1.5e8;
    double initial_tread_depth_m = 0.0030;
    double minimum_tread_depth_m = 0.0002;

    void validate() const;
};

struct F1FlexibleRingNodeState {
    double radial_displacement_m = 0.0;
    double radial_velocity_m_s = 0.0;
    double lateral_displacement_m = 0.0;
    double lateral_velocity_m_s = 0.0;
    double longitudinal_bristle_m = 0.0;
    double lateral_bristle_m = 0.0;
    double tread_temperature_k = 343.15;
    double wear_fraction = 0.0;
};

struct F1FlexibleRingTyreState {
    double time_s = 0.0;
    double belt_temperature_k = 338.15;
    double angular_speed_rad_s = 0.0;
    double accumulated_slip_energy_j = 0.0;
    std::vector<F1FlexibleRingNodeState> nodes;
};

struct F1FlexibleRingTyreInput {
    double time_step_s = 0.0005;
    double normal_load_n = 3500.0;
    double longitudinal_speed_m_s = 50.0;
    double lateral_speed_m_s = 0.0;
    double angular_speed_rad_s = 140.0;
    double camber_rad = 0.0;
    double inflation_pressure_pa = 150000.0;
    double road_temperature_k = 313.15;
    double ambient_temperature_k = 298.15;
    double water_film_depth_m = 0.0;
    double road_roughness_scale = 1.0;
    double applied_torque_nm = 0.0;
};

struct F1DistributedContactSample {
    std::size_t node = 0;
    double longitudinal_position_m = 0.0;
    double normal_pressure_pa = 0.0;
    double longitudinal_shear_pa = 0.0;
    double lateral_shear_pa = 0.0;
    double water_pressure_pa = 0.0;
    double local_friction = 0.0;
    double local_temperature_k = 0.0;
};

struct F1FlexibleRingTyreResult {
    F1FlexibleRingTyreState state;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double vertical_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double rolling_resistance_nm = 0.0;
    double effective_radius_m = 0.0;
    double contact_length_m = 0.0;
    double aquaplaning_fraction = 0.0;
    double average_tread_temperature_k = 0.0;
    double maximum_contact_pressure_pa = 0.0;
    double viscoelastic_loss_w = 0.0;
    std::vector<F1DistributedContactSample> contact;
    bool finite = true;
};

class F1FlexibleRingTyreModel {
public:
    explicit F1FlexibleRingTyreModel(F1FlexibleRingTyreConfiguration configuration = {});
    [[nodiscard]] const F1FlexibleRingTyreConfiguration& configuration() const noexcept;
    [[nodiscard]] F1FlexibleRingTyreState make_initial_state() const;
    [[nodiscard]] F1FlexibleRingTyreResult step(
        const F1FlexibleRingTyreInput& input,
        const F1FlexibleRingTyreState& state) const;

private:
    F1FlexibleRingTyreConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Circuit microclimate, drainage, debris, and spray platform.
// -----------------------------------------------------------------------------

struct F1CircuitCellConfiguration {
    double elevation_m = 0.0;
    double roughness = 0.5;
    double drainage_capacity_m_s = 0.0;
    double infiltration_m_s = 0.0;
    double solar_absorptivity = 0.85;
    double thermal_capacity_j_m2_k = 1.4e6;
    double obstacle_drag = 0.0;
    double debris_trap_fraction = 0.0;
};

struct F1CircuitEnvironmentConfiguration {
    std::size_t rows = 1;
    std::size_t columns = 1;
    double cell_size_x_m = 5.0;
    double cell_size_y_m = 5.0;
    std::vector<F1CircuitCellConfiguration> cells;
    double air_density_kg_m3 = 1.2;
    double air_heat_capacity_j_kg_k = 1005.0;
    double wind_diffusivity_m2_s = 2.0;
    double scalar_diffusivity_m2_s = 0.6;
    double spray_settling_speed_m_s = 0.8;
    double debris_mobility = 0.12;
    double rubber_grip_gain = 0.35;
    double water_grip_loss_per_mm = 0.22;

    void validate() const;
};

struct F1CircuitCellState {
    double air_temperature_k = 298.15;
    double surface_temperature_k = 303.15;
    double relative_humidity = 0.50;
    F1FidelityVector3 wind_m_s{};
    double water_depth_m = 0.0;
    double rubber_kg_m2 = 0.0;
    double marbles_kg_m2 = 0.0;
    double sharp_debris_kg_m2 = 0.0;
    double oil_contamination = 0.0;
    double spray_water_kg_m3 = 0.0;
};

struct F1CircuitEnvironmentState {
    double time_s = 0.0;
    std::vector<F1CircuitCellState> cells;
};

struct F1CircuitWeatherInput {
    double rainfall_m_s = 0.0;
    double ambient_temperature_k = 298.15;
    double relative_humidity = 0.5;
    F1FidelityVector3 free_stream_wind_m_s{};
    double solar_flux_w_m2 = 0.0;
    double longwave_sky_temperature_k = 285.0;
};

struct F1CircuitCarPassage {
    F1FidelityVector3 position_m{};
    F1FidelityVector3 velocity_m_s{};
    double tyre_water_displacement_kg_s = 0.0;
    double rubber_deposition_kg_s = 0.0;
    double marbles_generation_kg_s = 0.0;
    double debris_generation_kg_s = 0.0;
    double oil_leak_kg_s = 0.0;
    double wake_turbulence = 0.0;
};

struct F1CircuitCellOutput {
    double grip_scale = 1.0;
    double visibility_m = 1000.0;
    double puncture_probability_per_pass = 0.0;
    double drainage_flow_m3_s = 0.0;
};

struct F1CircuitEnvironmentResult {
    F1CircuitEnvironmentState state;
    std::vector<F1CircuitCellOutput> outputs;
    double total_surface_water_m3 = 0.0;
    double total_drained_water_m3 = 0.0;
    double minimum_visibility_m = 1000.0;
    double minimum_grip_scale = 1.0;
    bool finite = true;
};

class F1CircuitMicroclimatePlatform {
public:
    explicit F1CircuitMicroclimatePlatform(F1CircuitEnvironmentConfiguration configuration);
    [[nodiscard]] const F1CircuitEnvironmentConfiguration& configuration() const noexcept;
    [[nodiscard]] F1CircuitEnvironmentState make_initial_state() const;
    [[nodiscard]] F1CircuitEnvironmentResult step(
        double time_step_s,
        const F1CircuitEnvironmentState& state,
        const F1CircuitWeatherInput& weather,
        const std::vector<F1CircuitCarPassage>& cars = {}) const;
    [[nodiscard]] std::size_t cell_index(double x_m, double y_m) const;

private:
    F1CircuitEnvironmentConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Integrated damage-aware vehicle performance twin.
// -----------------------------------------------------------------------------

enum class F1DamageDomain {
    FrontWing, RearWing, Floor, Diffuser, Cooling, Suspension, Steering,
    Wheel, Tyre, PowerUnit, Gearbox, Sensor, Electrical
};

struct F1DamageComponentConfiguration {
    std::string id;
    F1DamageDomain domain = F1DamageDomain::Floor;
    double impact_capacity_j = 1000.0;
    double fatigue_capacity = 1.0;
    double thermal_limit_k = 400.0;
    double repair_time_s = 60.0;
    double repair_effectiveness = 0.95;
    double downforce_loss_at_failure = 0.0;
    double drag_increase_at_failure = 0.0;
    double cooling_loss_at_failure = 0.0;
    double alignment_error_rad_at_failure = 0.0;
    double reliability_hazard_at_failure = 0.0;

    void validate() const;
};

struct F1DamageState {
    double severity = 0.0;
    double cumulative_impact_j = 0.0;
    double fatigue_damage = 0.0;
    double maximum_temperature_k = 0.0;
    bool failed = false;
};

struct F1RealismDamageEvent {
    std::string component_id;
    double impact_energy_j = 0.0;
    double fatigue_increment = 0.0;
    double temperature_k = 0.0;
};

struct F1DamagePerformanceReport {
    std::map<std::string, F1DamageState> components;
    double front_downforce_scale = 1.0;
    double rear_downforce_scale = 1.0;
    double drag_scale = 1.0;
    double cooling_scale = 1.0;
    double steering_offset_rad = 0.0;
    std::array<double, 4> wheel_alignment_error_rad{};
    double failure_probability_per_lap = 0.0;
    double estimated_lap_time_loss_s = 0.0;
    bool safe_to_continue = true;
};

struct F1DamageRepairDecision {
    std::vector<std::string> components_to_repair;
    double repair_time_s = 0.0;
    double expected_remaining_lap_loss_s = 0.0;
    double expected_failure_probability = 0.0;
    double expected_value = 0.0;
};

class F1DamageAwareVehicleTwin {
public:
    explicit F1DamageAwareVehicleTwin(std::vector<F1DamageComponentConfiguration> configuration);
    [[nodiscard]] std::map<std::string, F1DamageState> make_initial_state() const;
    [[nodiscard]] F1DamagePerformanceReport update(
        const std::map<std::string, F1DamageState>& state,
        const std::vector<F1RealismDamageEvent>& events) const;
    [[nodiscard]] F1DamageRepairDecision optimize_repair(
        const F1DamagePerformanceReport& report,
        double remaining_race_time_s,
        double value_per_second,
        double failure_cost) const;

private:
    std::vector<F1DamageComponentConfiguration> configuration_;
};

// -----------------------------------------------------------------------------
// Driver visual, neuromuscular, and vestibular model.
// -----------------------------------------------------------------------------

struct F1DriverHumanConfiguration {
    double visual_processing_delay_s = 0.12;
    double neuromuscular_delay_s = 0.10;
    double steering_activation_time_s = 0.08;
    double pedal_activation_time_s = 0.07;
    double maximum_steering_torque_nm = 35.0;
    double maximum_brake_force_n = 1200.0;
    double neck_fatigue_rate = 2.0e-5;
    double heat_fatigue_rate = 1.5e-5;
    double dehydration_rate_per_s = 1.0e-5;
    double semicircular_canal_time_constant_s = 5.5;
    double otolith_time_constant_s = 0.5;
    double gaze_rate_limit_rad_s = 8.0;
    double peripheral_field_rad = 1.8;
    double base_control_noise = 0.002;
    std::uint64_t seed = 1;

    void validate() const;
};

struct F1DriverHumanState {
    double time_s = 0.0;
    double gaze_yaw_rad = 0.0;
    double gaze_pitch_rad = 0.0;
    double perceived_yaw_rate_rad_s = 0.0;
    double perceived_longitudinal_accel_m_s2 = 0.0;
    double perceived_lateral_accel_m_s2 = 0.0;
    double steering_activation = 0.0;
    double brake_activation = 0.0;
    double throttle_activation = 0.0;
    double neck_fatigue = 0.0;
    double cognitive_fatigue = 0.0;
    double dehydration = 0.0;
    double workload = 0.0;
};

struct F1DriverHumanInput {
    double time_step_s = 0.01;
    double target_heading_error_rad = 0.0;
    double target_speed_error_m_s = 0.0;
    double vehicle_yaw_rate_rad_s = 0.0;
    double longitudinal_accel_m_s2 = 0.0;
    double lateral_accel_m_s2 = 0.0;
    double vertical_accel_m_s2 = 9.81;
    double steering_feedback_torque_nm = 0.0;
    double visibility_m = 1000.0;
    double closing_speed_m_s = 0.0;
    double cockpit_temperature_k = 305.0;
    double radio_workload = 0.0;
    double surprise = 0.0;
    double motion_cue_scale = 1.0;
};

struct F1DriverHumanResult {
    F1DriverHumanState state;
    double steering_command_rad = 0.0;
    double steering_torque_nm = 0.0;
    double throttle_command = 0.0;
    double brake_command = 0.0;
    double perceived_heading_error_rad = 0.0;
    double visual_uncertainty_rad = 0.0;
    double control_precision_scale = 1.0;
    double motion_cue_conflict = 0.0;
    bool finite = true;
};

class F1DriverHumanDynamics {
public:
    explicit F1DriverHumanDynamics(F1DriverHumanConfiguration configuration = {});
    [[nodiscard]] F1DriverHumanState make_initial_state() const;
    [[nodiscard]] F1DriverHumanResult step(
        const F1DriverHumanInput& input,
        const F1DriverHumanState& state) const;

private:
    F1DriverHumanConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Detailed wheel-end and driveline mechanics.
// -----------------------------------------------------------------------------

struct F1WheelEndConfiguration {
    double bearing_radial_stiffness_n_m = 2.0e8;
    double bearing_axial_stiffness_n_m = 1.2e8;
    double bearing_dynamic_capacity_n = 90000.0;
    double bearing_friction_coefficient = 0.0015;
    double hub_bending_stiffness_nm_rad = 2.0e5;
    double rim_modal_mass_kg = 3.0;
    double rim_modal_frequency_hz = 280.0;
    double rim_modal_damping = 0.04;
    double bead_friction_coefficient = 0.75;
    double bead_seating_force_n = 24000.0;
    double tyre_gas_volume_m3 = 0.035;
    double initial_pressure_pa = 155000.0;
    double thermal_capacity_j_k = 18000.0;
    double cooling_w_k = 55.0;

    void validate() const;
};

struct F1DetailedDrivelineConfiguration {
    std::vector<double> gear_ratios{3.2, 2.4, 1.9, 1.55, 1.30, 1.12, 0.98, 0.86};
    double final_drive_ratio = 3.4;
    double input_shaft_inertia_kg_m2 = 0.12;
    double output_shaft_inertia_kg_m2 = 0.25;
    double shaft_stiffness_nm_rad = 18000.0;
    double shaft_damping_nm_s_rad = 80.0;
    double mesh_stiffness_nm_rad = 250000.0;
    double mesh_damping_nm_s_rad = 300.0;
    double backlash_rad = 0.0008;
    double dog_engagement_speed_rad_s = 8.0;
    double actuator_pressure_pa = 1.6e7;
    double actuator_time_constant_s = 0.025;
    double shift_cut_time_s = 0.035;
    double differential_lock_fraction = 0.35;

    void validate() const;
};

struct F1WheelDrivelineState {
    double time_s = 0.0;
    double bearing_temperature_k = 330.0;
    double bearing_damage = 0.0;
    double hub_deflection_rad = 0.0;
    double rim_modal_displacement_m = 0.0;
    double rim_modal_velocity_m_s = 0.0;
    double bead_slip_rad = 0.0;
    double tyre_pressure_pa = 155000.0;
    double input_shaft_angle_rad = 0.0;
    double input_shaft_speed_rad_s = 0.0;
    double output_shaft_angle_rad = 0.0;
    double output_shaft_speed_rad_s = 0.0;
    double actuator_pressure_pa = 0.0;
    double dog_engagement = 1.0;
    std::size_t current_gear = 1;
    std::size_t requested_gear = 1;
    double shift_timer_s = 0.0;
    double gear_damage = 0.0;
};

struct F1WheelDrivelineInput {
    double time_step_s = 0.0005;
    double engine_torque_nm = 0.0;
    double wheel_resistance_torque_nm = 0.0;
    double wheel_radial_load_n = 3500.0;
    double wheel_axial_load_n = 0.0;
    double wheel_aligning_moment_nm = 0.0;
    double tyre_bead_torque_nm = 0.0;
    double ambient_temperature_k = 298.15;
    std::size_t requested_gear = 1;
};

struct F1WheelDrivelineResult {
    F1WheelDrivelineState state;
    double delivered_wheel_torque_nm = 0.0;
    double bearing_friction_torque_nm = 0.0;
    double bearing_life_fraction = 1.0;
    double wheel_camber_compliance_rad = 0.0;
    double wheel_toe_compliance_rad = 0.0;
    double gear_mesh_force_n = 0.0;
    double shift_quality = 1.0;
    bool missed_shift = false;
    bool bead_slip_detected = false;
    bool finite = true;
};

class F1WheelEndDrivelineModel {
public:
    F1WheelEndDrivelineModel(F1WheelEndConfiguration wheel_end = {},
                             F1DetailedDrivelineConfiguration driveline = {});
    [[nodiscard]] F1WheelDrivelineState make_initial_state() const;
    [[nodiscard]] F1WheelDrivelineResult step(
        const F1WheelDrivelineInput& input,
        const F1WheelDrivelineState& state) const;

private:
    F1WheelEndConfiguration wheel_end_;
    F1DetailedDrivelineConfiguration driveline_;
};

// -----------------------------------------------------------------------------
// Trackside RF, telemetry propagation, and EMC twin.
// -----------------------------------------------------------------------------

struct F1RfSite {
    std::string id;
    F1FidelityVector3 position_m{};
    double antenna_gain_dbi = 8.0;
    double receiver_noise_figure_db = 4.0;
    double cable_loss_db = 1.0;
    double bandwidth_hz = 1.0e6;
};

struct F1RfReflector {
    F1FidelityVector3 position_m{};
    double reflection_loss_db = 8.0;
    double phase_offset_rad = 0.0;
};

struct F1RfTelemetryConfiguration {
    double carrier_frequency_hz = 2.4e9;
    double transmit_power_dbm = 20.0;
    double vehicle_antenna_gain_dbi = 2.0;
    double vehicle_cable_loss_db = 1.5;
    double polarization_mismatch_db = 1.0;
    double receiver_sensitivity_dbm = -100.0;
    double base_latency_s = 0.005;
    double jitter_s = 0.001;
    double packet_rate_hz = 100.0;
    std::vector<F1RfSite> sites;
    std::vector<F1RfReflector> reflectors;
    std::uint64_t seed = 1;

    void validate() const;
};

struct F1EmcSource {
    std::string id;
    double frequency_hz = 0.0;
    double field_strength_v_m = 0.0;
    double conducted_noise_v = 0.0;
    double duty_cycle = 1.0;
};

struct F1RfTelemetryInput {
    double time_s = 0.0;
    F1FidelityVector3 vehicle_position_m{};
    F1FidelityVector3 vehicle_velocity_m_s{};
    double vehicle_heading_rad = 0.0;
    double rain_rate_mm_h = 0.0;
    double external_interference_dbm = -120.0;
    std::vector<F1EmcSource> emc_sources;
    std::size_t payload_bytes = 256;
};

struct F1RfSiteResult {
    std::string site_id;
    double distance_m = 0.0;
    double received_power_dbm = -200.0;
    double snr_db = -100.0;
    double doppler_hz = 0.0;
    double packet_error_rate = 1.0;
};

struct F1RfTelemetryResult {
    std::vector<F1RfSiteResult> sites;
    std::string selected_site_id;
    double selected_snr_db = -100.0;
    double packet_error_rate = 1.0;
    double latency_s = 0.0;
    double emc_sensor_error_scale = 0.0;
    bool packet_delivered = false;
    std::uint64_t sequence = 0;
};

class F1TracksideRfTelemetryTwin {
public:
    explicit F1TracksideRfTelemetryTwin(F1RfTelemetryConfiguration configuration);
    void reset();
    [[nodiscard]] F1RfTelemetryResult transmit(const F1RfTelemetryInput& input);

private:
    F1RfTelemetryConfiguration configuration_;
    std::mt19937_64 random_;
    std::uint64_t sequence_ = 0;
};

// -----------------------------------------------------------------------------
// Tyre pedigree-to-performance digital thread.
// -----------------------------------------------------------------------------

struct F1TyreProductionRecord {
    std::string serial;
    std::string compound;
    std::string batch;
    double cure_temperature_k = 443.15;
    double cure_time_s = 900.0;
    double mass_kg = 13.0;
    double radial_force_variation_n = 0.0;
    double belt_offset_m = 0.0;
    double tread_thickness_m = 0.0030;
    double hardness_shore_a = 55.0;
    double void_fraction = 0.18;
    double storage_age_days = 0.0;
    double xray_defect_score = 0.0;
};

struct F1TyreLifecycleRecord {
    double heating_cycles = 0.0;
    double distance_m = 0.0;
    double maximum_temperature_k = 0.0;
    double cumulative_slip_energy_j = 0.0;
    double pressure_loss_pa = 0.0;
    double impact_damage = 0.0;
};

struct F1TyrePerformanceDistribution {
    std::string serial;
    double vertical_stiffness_mean_n_m = 0.0;
    double cornering_stiffness_mean_n_rad = 0.0;
    double peak_friction_mean = 0.0;
    double relaxation_length_mean_m = 0.0;
    double thermal_conductivity_mean_w_m_k = 0.0;
    double wear_energy_mean_j = 0.0;
    double failure_probability = 0.0;
    std::array<std::array<double, 6>, 6> covariance{};
};

struct F1TyreSetAssignment {
    std::string axle;
    std::string left_serial;
    std::string right_serial;
    double expected_balance_error = 0.0;
    double expected_performance_score = 0.0;
};

class F1TyrePedigreeDigitalThread {
public:
    void register_tyre(F1TyreProductionRecord production,
                       F1TyreLifecycleRecord lifecycle = {});
    void update_lifecycle(const std::string& serial,
                          const F1TyreLifecycleRecord& increment);
    [[nodiscard]] F1TyrePerformanceDistribution infer(const std::string& serial) const;
    [[nodiscard]] std::vector<F1TyreSetAssignment> optimize_sets(
        const std::vector<std::string>& serials,
        std::size_t axle_pairs) const;
    [[nodiscard]] std::vector<std::string> serials() const;

private:
    std::map<std::string, std::pair<F1TyreProductionRecord, F1TyreLifecycleRecord>> records_;
};

// -----------------------------------------------------------------------------
// Counterfactual probabilistic race engineer.
// -----------------------------------------------------------------------------

struct F1RaceBeliefScenario {
    std::string id;
    double probability = 1.0;
    double rain_start_s = 1.0e9;
    double safety_car_probability = 0.0;
    double tyre_degradation_scale = 1.0;
    double traffic_loss_s = 0.0;
    double pit_loss_s = 22.0;
    double failure_probability = 0.0;
};

struct F1RaceEngineerAction {
    std::string id;
    bool pit = false;
    std::string tyre_compound;
    double attack_fraction = 0.5;
    double energy_deployment_fraction = 0.5;
    double repair_time_s = 0.0;
};

struct F1CounterfactualOutcome {
    std::string action_id;
    double expected_points = 0.0;
    double expected_finish_time_s = 0.0;
    double standard_deviation_s = 0.0;
    double cvar95_loss = 0.0;
    double failure_probability = 0.0;
    double regret = 0.0;
    double value_of_information = 0.0;
    std::map<std::string, double> scenario_values;
};

struct F1RaceEngineerRecommendation {
    std::string recommended_action_id;
    std::vector<F1CounterfactualOutcome> outcomes;
    double decision_confidence = 0.0;
    std::string most_valuable_information;
};

class F1CounterfactualRaceEngineer {
public:
    using OutcomeModel = std::function<double(
        const F1RaceBeliefScenario&, const F1RaceEngineerAction&, std::mt19937_64&)>;

    explicit F1CounterfactualRaceEngineer(std::uint64_t seed = 1);
    [[nodiscard]] F1RaceEngineerRecommendation evaluate(
        const std::vector<F1RaceBeliefScenario>& scenarios,
        const std::vector<F1RaceEngineerAction>& actions,
        std::size_t samples_per_scenario,
        OutcomeModel finish_time_model = {}) const;

private:
    std::uint64_t seed_ = 1;
};

// -----------------------------------------------------------------------------
// Wind-tunnel facility physics and virtual measurement twin.
// -----------------------------------------------------------------------------

struct F1WindTunnelFacilityConfiguration {
    double test_section_width_m = 4.0;
    double test_section_height_m = 3.0;
    double test_section_length_m = 12.0;
    double wall_open_area_fraction = 0.0;
    double rolling_road_speed_scale = 1.0;
    double belt_boundary_layer_m = 0.002;
    double flow_angularity_yaw_rad = 0.0;
    double flow_angularity_pitch_rad = 0.0;
    double turbulence_intensity = 0.003;
    double pressure_pa = 101325.0;
    double temperature_k = 293.15;
    double humidity = 0.4;
    double balance_force_noise_n = 0.2;
    double balance_moment_noise_nm = 0.05;
    double balance_cross_talk = 0.002;
    double support_drag_area_m2 = 0.001;
    double wall_interference_gain = 0.8;
    std::uint64_t seed = 1;

    void validate() const;
};

struct F1WindTunnelModelConfiguration {
    double scale = 0.60;
    double reference_area_m2 = 1.5;
    double reference_length_m = 3.6;
    double frontal_area_m2 = 0.85;
    double support_drag_area_m2 = 0.001;
    double structural_compliance_m_n = 2.0e-7;
    double tyre_radius_m = 0.21;
};

struct F1WindTunnelRunInput {
    double air_speed_m_s = 50.0;
    double belt_speed_m_s = 50.0;
    double yaw_rad = 0.0;
    double ride_height_front_m = 0.025;
    double ride_height_rear_m = 0.045;
    double true_drag_coefficient = 0.85;
    double true_lift_coefficient = -3.5;
    double true_pitch_moment_coefficient = -0.10;
    double acquisition_time_s = 5.0;
    double sample_rate_hz = 1000.0;
};

struct F1WindTunnelMeasurement {
    double raw_drag_n = 0.0;
    double raw_lift_n = 0.0;
    double raw_pitch_moment_nm = 0.0;
    double corrected_drag_coefficient = 0.0;
    double corrected_lift_coefficient = 0.0;
    double corrected_pitch_moment_coefficient = 0.0;
    double blockage_fraction = 0.0;
    double reynolds_number = 0.0;
    double effective_yaw_rad = 0.0;
    double model_deflection_m = 0.0;
    double drag_uncertainty = 0.0;
    double lift_uncertainty = 0.0;
    double moment_uncertainty = 0.0;
    std::array<std::array<double, 3>, 3> covariance{};
};

class F1WindTunnelFacilityTwin {
public:
    F1WindTunnelFacilityTwin(F1WindTunnelFacilityConfiguration facility,
                             F1WindTunnelModelConfiguration model = {});
    void reset();
    [[nodiscard]] F1WindTunnelMeasurement run(const F1WindTunnelRunInput& input);
    [[nodiscard]] std::vector<F1WindTunnelMeasurement> yaw_sweep(
        const F1WindTunnelRunInput& base,
        double minimum_yaw_rad,
        double maximum_yaw_rad,
        std::size_t samples);

private:
    F1WindTunnelFacilityConfiguration facility_;
    F1WindTunnelModelConfiguration model_;
    std::mt19937_64 random_;
};

} // namespace aesim::advanced

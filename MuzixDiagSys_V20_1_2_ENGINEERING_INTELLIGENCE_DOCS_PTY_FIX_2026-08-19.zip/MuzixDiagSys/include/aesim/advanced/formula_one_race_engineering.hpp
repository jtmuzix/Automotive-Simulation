#pragma once

#include "aesim/advanced/formula_one_platform.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Formula One suspension, steering, heave, and aerodynamic-platform control.
// -----------------------------------------------------------------------------

enum class F1Corner { FrontLeft = 0, FrontRight = 1, RearLeft = 2, RearRight = 3 };

struct F1SuspensionCornerConfiguration {
    double motion_ratio = 0.82;
    double wheel_rate_n_m = 185000.0;
    double damper_bump_n_s_m = 8500.0;
    double damper_rebound_n_s_m = 10500.0;
    double bump_stop_gap_m = 0.012;
    double bump_stop_rate_n_m = 1800000.0;
    double droop_stop_gap_m = 0.030;
    double droop_stop_rate_n_m = 900000.0;
    double unsprung_mass_kg = 18.0;
    double tyre_vertical_rate_n_m = 310000.0;
    double tyre_vertical_damping_n_s_m = 1800.0;
    double static_corner_mass_kg = 190.0;
    double camber_static_rad = -0.052;
    double camber_gain_rad_m = -0.30;
    double toe_static_rad = 0.0;
    double bump_steer_rad_m = 0.035;
    void validate() const;
};

struct F1PlatformConfiguration {
    double sprung_mass_kg = 690.0;
    double pitch_inertia_kg_m2 = 940.0;
    double roll_inertia_kg_m2 = 330.0;
    double wheelbase_m = 3.40;
    double front_track_m = 1.62;
    double rear_track_m = 1.58;
    double cg_to_front_axle_m = 1.55;
    double cg_height_m = 0.30;
    double front_heave_rate_n_m = 420000.0;
    double rear_heave_rate_n_m = 360000.0;
    double front_heave_damping_n_s_m = 18000.0;
    double rear_heave_damping_n_s_m = 16000.0;
    double front_antiroll_rate_n_m = 210000.0;
    double rear_antiroll_rate_n_m = 175000.0;
    double chassis_torsional_rate_n_m_rad = 3200000.0;
    double steering_ratio = 11.5;
    double steering_compliance_rad_nm = 1.2e-5;
    double ackermann_fraction = 0.35;
    double nominal_front_ride_height_m = 0.030;
    double nominal_rear_ride_height_m = 0.050;
    double minimum_floor_clearance_m = 0.006;
    double maximum_suspension_travel_m = 0.045;
    std::array<F1SuspensionCornerConfiguration, 4> corners{};
    void validate() const;
};

struct F1PlatformState {
    double heave_m = 0.0;
    double heave_velocity_m_s = 0.0;
    double pitch_rad = 0.0;
    double pitch_rate_rad_s = 0.0;
    double roll_rad = 0.0;
    double roll_rate_rad_s = 0.0;
    std::array<double, 4> unsprung_displacement_m{};
    std::array<double, 4> unsprung_velocity_m_s{};
    std::array<double, 4> suspension_travel_m{};
    std::array<double, 4> corner_normal_load_n{};
    std::array<double, 4> camber_rad{};
    std::array<double, 4> toe_rad{};
    double steering_rack_angle_rad = 0.0;
    double plank_wear_mm = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PlatformInput {
    double time_step_s = 0.001;
    double vehicle_speed_m_s = 0.0;
    double longitudinal_acceleration_m_s2 = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    double steering_wheel_angle_rad = 0.0;
    double steering_torque_nm = 0.0;
    std::array<double, 4> road_height_m{};
    std::array<double, 4> road_vertical_velocity_m_s{};
    std::array<double, 4> aerodynamic_corner_load_n{};
    std::array<double, 4> additional_corner_load_n{};
};

struct F1PlatformStepResult {
    F1PlatformState state;
    std::array<double, 4> spring_force_n{};
    std::array<double, 4> damper_force_n{};
    std::array<double, 4> tyre_force_n{};
    std::array<double, 4> wheel_steer_angle_rad{};
    double front_ride_height_m = 0.0;
    double rear_ride_height_m = 0.0;
    double floor_clearance_m = 0.0;
    double aerodynamic_platform_error = 0.0;
    bool floor_contact = false;
    bool bottoming = false;
    bool wheel_lift = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PlatformSetupCandidate {
    double front_heave_scale = 1.0;
    double rear_heave_scale = 1.0;
    double front_antiroll_scale = 1.0;
    double rear_antiroll_scale = 1.0;
    double front_ride_height_offset_m = 0.0;
    double rear_ride_height_offset_m = 0.0;
};

struct F1PlatformSetupEvaluation {
    F1PlatformSetupCandidate setup;
    double objective = 0.0;
    double mean_platform_error = 0.0;
    double maximum_bottoming_m = 0.0;
    double load_variation = 0.0;
    double plank_wear_mm = 0.0;
    bool feasible = false;
    [[nodiscard]] doc::Value to_document() const;
};

class F1PlatformControlLaboratory {
public:
    explicit F1PlatformControlLaboratory(F1PlatformConfiguration configuration = {});
    [[nodiscard]] const F1PlatformConfiguration& configuration() const noexcept;
    [[nodiscard]] F1PlatformStepResult step(const F1PlatformInput& input,
                                            const F1PlatformState& previous) const;
    [[nodiscard]] F1PlatformSetupEvaluation evaluate_setup(
        const F1PlatformSetupCandidate& setup,
        const std::vector<F1PlatformInput>& lap_inputs,
        F1PlatformState initial = {}) const;
    [[nodiscard]] F1PlatformSetupEvaluation optimize_setup(
        const std::vector<F1PlatformSetupCandidate>& candidates,
        const std::vector<F1PlatformInput>& lap_inputs,
        F1PlatformState initial = {}) const;
private:
    F1PlatformConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Carbon brakes, brake-by-wire, and wheel-end thermal physics.
// -----------------------------------------------------------------------------

struct F1BrakeCornerConfiguration {
    double effective_radius_m = 0.145;
    double disc_thermal_capacity_j_k = 42000.0;
    double pad_thermal_capacity_j_k = 9500.0;
    double caliper_thermal_capacity_j_k = 17000.0;
    double rim_thermal_capacity_j_k = 32000.0;
    double tyre_gas_thermal_capacity_j_k = 6000.0;
    double disc_pad_conductance_w_k = 420.0;
    double disc_caliper_conductance_w_k = 115.0;
    double disc_rim_conductance_w_k = 90.0;
    double rim_tyre_conductance_w_k = 55.0;
    double base_cooling_w_k = 180.0;
    double maximum_hydraulic_pressure_pa = 12.0e6;
    double piston_area_m2 = 0.0056;
    double pad_wear_energy_j_per_mm = 2.8e8;
    double disc_wear_energy_j_per_mm = 7.5e8;
    void validate() const;
};

struct F1BrakeSystemConfiguration {
    std::array<F1BrakeCornerConfiguration, 4> corners{};
    double nominal_front_balance = 0.56;
    double migration_per_deceleration = 0.010;
    double bbw_response_time_s = 0.025;
    double hydraulic_response_time_s = 0.018;
    double maximum_regen_power_kw = 350.0;
    double minimum_disc_temperature_k = 573.15;
    double optimum_disc_temperature_k = 1073.15;
    double maximum_disc_temperature_k = 1273.15;
    double maximum_caliper_temperature_k = 493.15;
    double fluid_boiling_temperature_k = 543.15;
    void validate() const;
};

struct F1BrakeCornerState {
    double disc_temperature_k = 673.15;
    double pad_temperature_k = 623.15;
    double caliper_temperature_k = 353.15;
    double rim_temperature_k = 323.15;
    double tyre_gas_temperature_k = 313.15;
    double hydraulic_pressure_pa = 0.0;
    double disc_wear_mm = 0.0;
    double pad_wear_mm = 0.0;
    double oxidation_damage = 0.0;
    double flat_spot_severity = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1BrakeSystemState {
    std::array<F1BrakeCornerState, 4> corners{};
    double rear_brake_by_wire_command = 0.0;
    double brake_fluid_temperature_k = 343.15;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1BrakeInput {
    double time_step_s = 0.001;
    double pedal_command = 0.0;
    double driver_brake_balance = 0.56;
    double brake_migration = 0.0;
    double vehicle_speed_m_s = 0.0;
    std::array<double, 4> wheel_speed_rad_s{};
    std::array<double, 4> normal_load_n{{3500.0, 3500.0, 3000.0, 3000.0}};
    std::array<double, 4> road_friction{{1.8, 1.8, 1.8, 1.8}};
    std::array<double, 4> cooling_flow_scale{{1.0, 1.0, 1.0, 1.0}};
    double requested_regen_power_kw = 0.0;
    double available_regen_power_kw = 0.0;
    double ambient_temperature_k = 298.15;
    bool brake_by_wire_available = true;
};

struct F1BrakeStepResult {
    F1BrakeSystemState state;
    std::array<double, 4> hydraulic_torque_nm{};
    std::array<double, 4> total_wheel_brake_torque_nm{};
    std::array<double, 4> friction_coefficient{};
    std::array<double, 4> lockup_margin_nm{};
    double regenerative_power_kw = 0.0;
    double hydraulic_power_kw = 0.0;
    double recovered_energy_kj = 0.0;
    bool brake_by_wire_fault = false;
    bool lockup_detected = false;
    bool caliper_overtemperature = false;
    bool fluid_boiling_risk = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1CarbonBrakeLaboratory {
public:
    explicit F1CarbonBrakeLaboratory(F1BrakeSystemConfiguration configuration = {});
    [[nodiscard]] const F1BrakeSystemConfiguration& configuration() const noexcept;
    [[nodiscard]] F1BrakeStepResult step(const F1BrakeInput& input,
                                         const F1BrakeSystemState& previous) const;
private:
    F1BrakeSystemConfiguration configuration_;
};

// -----------------------------------------------------------------------------
// Survey-grade circuit, weather, wake, and track digital twin.
// -----------------------------------------------------------------------------

struct F1CircuitSurveyPoint {
    double distance_m = 0.0;
    Vector3 position_m{};
    double left_width_m = 6.0;
    double right_width_m = 6.0;
    double banking_rad = 0.0;
    double camber_rad = 0.0;
    double roughness_rms_m = 0.001;
    double drainage_rate_mm_h = 8.0;
    double solar_exposure = 1.0;
    double base_grip = 1.0;
};

struct F1SpatialWeatherSample {
    double distance_m = 0.0;
    double air_temperature_k = 298.15;
    double relative_humidity = 0.50;
    double rainfall_mm_h = 0.0;
    double solar_flux_w_m2 = 500.0;
    double wind_speed_m_s = 0.0;
    double wind_direction_rad = 0.0;
    double cloud_fraction = 0.0;
};

struct F1TrackCell {
    double distance_m = 0.0;
    double length_m = 1.0;
    Vector3 position_m{};
    double banking_rad = 0.0;
    double camber_rad = 0.0;
    double roughness_rms_m = 0.001;
    double drainage_rate_mm_h = 8.0;
    double surface_temperature_k = 303.15;
    double water_film_mm = 0.0;
    double rubber_fraction = 0.05;
    double marble_fraction = 0.0;
    double dust_fraction = 0.02;
    double oil_fraction = 0.0;
    double grip_multiplier = 1.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TrackPassage {
    double distance_m = 0.0;
    double tyre_energy_j = 0.0;
    double shed_rubber_kg = 0.0;
    double shed_marble_kg = 0.0;
    double spray_water_kg = 0.0;
};

struct F1WakeQuery {
    double leader_speed_m_s = 0.0;
    double gap_m = 100.0;
    double lateral_offset_m = 0.0;
    double leader_downforce_n = 0.0;
    double leader_drag_n = 0.0;
    double crosswind_m_s = 0.0;
};

struct F1WakeResult {
    double downforce_multiplier = 1.0;
    double drag_multiplier = 1.0;
    double cooling_multiplier = 1.0;
    double turbulence_intensity = 0.0;
    double lateral_wake_velocity_m_s = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TrackQueryResult {
    F1TrackCell cell;
    F1SpatialWeatherSample weather;
    double local_grade = 0.0;
    double curvature_1_m = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class F1CircuitDigitalTwin {
public:
    void build(const std::vector<F1CircuitSurveyPoint>& survey_points,
               double target_cell_length_m = 5.0);
    void set_weather_field(std::vector<F1SpatialWeatherSample> weather);
    void apply_contamination(double distance_m, double oil_fraction,
                             double dust_fraction);
    void advance(double time_step_s, const std::vector<F1TrackPassage>& passages);
    [[nodiscard]] F1TrackQueryResult query(double distance_m) const;
    [[nodiscard]] F1WakeResult evaluate_wake(const F1WakeQuery& query) const;
    [[nodiscard]] double lap_length_m() const noexcept;
    [[nodiscard]] const std::vector<F1TrackCell>& cells() const noexcept;
    [[nodiscard]] doc::Value to_document() const;
private:
    std::vector<F1CircuitSurveyPoint> survey_points_;
    std::vector<F1SpatialWeatherSample> weather_;
    std::vector<F1TrackCell> cells_;
    double lap_length_m_ = 0.0;
};

// -----------------------------------------------------------------------------
// Live telemetry, state estimation, and pit-wall engineering.
// -----------------------------------------------------------------------------

struct F1TelemetryFrame {
    double timestamp_s = 0.0;
    int lap = 0;
    double lap_distance_m = 0.0;
    double speed_m_s = 0.0;
    double throttle = 0.0;
    double brake = 0.0;
    double steering_angle_rad = 0.0;
    double fuel_mass_kg = 0.0;
    double energy_store_soc = 0.0;
    double coolant_temperature_k = 0.0;
    double oil_temperature_k = 0.0;
    double floor_acceleration_m_s2 = 0.0;
    std::array<double, 4> tyre_surface_temperature_k{};
    std::array<double, 4> tyre_pressure_pa{};
    std::array<double, 4> brake_disc_temperature_k{};
    std::array<double, 4> ride_height_m{};
    std::map<std::string, double> auxiliary_channels;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1EstimatedRaceState {
    std::array<double, 4> tyre_core_temperature_k{{343.15,343.15,343.15,343.15}};
    std::array<double, 4> tyre_wear_fraction{};
    double grip_multiplier = 1.0;
    double fuel_mass_kg = 0.0;
    double energy_store_soc = 0.5;
    double floor_damage_fraction = 0.0;
    double power_unit_health = 1.0;
    double cooling_margin_k = 25.0;
    double brake_wear_fraction = 0.0;
    double state_uncertainty = 1.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1TelemetryAnomaly {
    double timestamp_s = 0.0;
    std::string channel;
    double innovation = 0.0;
    double normalized_innovation = 0.0;
    std::string severity;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1PitWallContext {
    int current_lap = 0;
    int total_laps = 0;
    F1TyreCompound current_compound = F1TyreCompound::Medium;
    int current_tyre_age_laps = 0;
    double pit_loss_s = 22.0;
    double traffic_gap_ahead_s = 5.0;
    double traffic_gap_behind_s = 5.0;
    double forecast_water_mm = 0.0;
    double rain_probability = 0.0;
    bool safety_car = false;
    bool virtual_safety_car = false;
    double competitor_pace_delta_s = 0.0;
};

struct F1LivePitWallDecision {
    bool recommend_pit = false;
    int recommended_pit_lap = 0;
    F1TyreCompound recommended_compound = F1TyreCompound::Medium;
    double predicted_tyre_life_laps = 0.0;
    double undercut_probability = 0.0;
    double cooling_risk = 0.0;
    double reliability_risk = 0.0;
    double recommended_energy_deployment_scale = 1.0;
    std::vector<std::string> driver_messages;
    std::vector<std::string> engineering_rationale;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1LiveRaceEngineer {
public:
    explicit F1LiveRaceEngineer(std::size_t ensemble_size = 48,
                                std::uint64_t random_seed = 0xF12026ULL);
    void reset(const F1EstimatedRaceState& initial);
    [[nodiscard]] F1EstimatedRaceState ingest(const F1TelemetryFrame& frame);
    [[nodiscard]] F1LivePitWallDecision advise(const F1PitWallContext& context) const;
    [[nodiscard]] const std::vector<F1TelemetryAnomaly>& anomalies() const noexcept;
    [[nodiscard]] const F1EstimatedRaceState& state() const noexcept;
private:
    std::size_t ensemble_size_;
    std::uint64_t random_seed_;
    std::vector<F1EstimatedRaceState> ensemble_;
    F1EstimatedRaceState state_;
    std::optional<F1TelemetryFrame> previous_frame_;
    std::vector<F1TelemetryAnomaly> anomalies_;
};

// -----------------------------------------------------------------------------
// Reliability, damage, and component-allocation optimization.
// -----------------------------------------------------------------------------

enum class F1ComponentFamily {
    Ice, Turbocharger, Mguk, Inverter, EnergyStore, ControlElectronics,
    Gearbox, Differential, Driveshaft, Clutch, HydraulicSystem, Suspension,
    WheelBearing, Brake, CoolingSystem, Sensor, Ecu, Wiring, ActiveAero,
    Floor, Bodywork
};

struct F1ComponentDefinition {
    std::string serial;
    F1ComponentFamily family = F1ComponentFamily::Ice;
    double weibull_shape = 3.0;
    double characteristic_life_km = 3000.0;
    double maximum_temperature_k = 400.0;
    double thermal_activation = 5.0;
    double shock_tolerance = 1.0;
    double initial_health = 1.0;
    int grid_penalty_if_changed = 0;
    bool sealed = false;
    void validate() const;
};

struct F1ComponentState {
    F1ComponentDefinition definition;
    double accumulated_distance_km = 0.0;
    double equivalent_damage = 0.0;
    double health = 1.0;
    double failure_probability = 0.0;
    double maximum_observed_temperature_k = 0.0;
    int shock_events = 0;
    bool failed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1ComponentUsage {
    double distance_km = 0.0;
    double mean_temperature_k = 300.0;
    double maximum_temperature_k = 300.0;
    double vibration_rms = 0.0;
    double shock_severity = 0.0;
    double load_fraction = 0.0;
    double time_h = 0.0;
};

struct F1DamageEvent {
    std::string component_serial;
    double severity = 0.0;
    double impact_energy_j = 0.0;
    double temperature_k = 300.0;
    std::string description;
};

struct F1SessionRequirement {
    std::string session_id;
    double expected_distance_km = 0.0;
    double severity_multiplier = 1.0;
    double expected_temperature_k = 350.0;
    bool race_session = false;
    int championship_value = 1;
};

struct F1ComponentAssignment {
    std::string session_id;
    F1ComponentFamily family = F1ComponentFamily::Ice;
    std::string component_serial;
    double predicted_failure_probability = 0.0;
    double predicted_remaining_health = 0.0;
    int grid_penalty = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct F1AllocationPlan {
    bool feasible = false;
    double objective = 0.0;
    int total_grid_penalty = 0;
    double aggregate_failure_risk = 0.0;
    std::vector<F1ComponentAssignment> assignments;
    std::vector<std::string> warnings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class F1ReliabilityLifecycleManager {
public:
    void register_component(const F1ComponentDefinition& definition);
    [[nodiscard]] const F1ComponentState& component(const std::string& serial) const;
    [[nodiscard]] F1ComponentState apply_usage(const std::string& serial,
                                               const F1ComponentUsage& usage);
    [[nodiscard]] F1ComponentState apply_damage(const F1DamageEvent& event);
    [[nodiscard]] F1AllocationPlan optimize_allocation(
        const std::vector<F1SessionRequirement>& sessions,
        const std::vector<F1ComponentFamily>& required_families,
        double failure_risk_weight = 1000.0,
        double grid_penalty_weight = 15.0) const;
    [[nodiscard]] doc::Value to_document() const;
private:
    std::map<std::string, F1ComponentState> components_;
};

} // namespace aesim::advanced

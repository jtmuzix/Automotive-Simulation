#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

enum class SchedulingPolicy { FixedPriority, EarliestDeadlineFirst };

struct RealTimeTask {
    std::string id;
    std::uint64_t period_ns = 0;
    std::uint64_t deadline_ns = 0;
    std::uint64_t wcet_ns = 0;
    std::uint64_t release_jitter_ns = 0;
    int priority = 0;
    std::size_t cpu_affinity = 0;
};

struct RealTimeJobTrace {
    std::string task_id;
    std::uint64_t release_ns = 0;
    std::uint64_t start_ns = 0;
    std::uint64_t finish_ns = 0;
    std::uint64_t response_ns = 0;
    bool deadline_missed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct TimingQualificationReport {
    std::vector<RealTimeJobTrace> jobs;
    std::map<std::string, std::uint64_t> maximum_response_ns;
    std::map<std::string, std::size_t> deadline_misses;
    std::uint64_t maximum_release_jitter_ns = 0;
    std::uint64_t maximum_scheduling_latency_ns = 0;
    bool qualified = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RealTimeTargetLaboratory {
public:
    void set_policy(SchedulingPolicy policy);
    void set_cpu_count(std::size_t cpu_count);
    void add_task(RealTimeTask task);
    [[nodiscard]] TimingQualificationReport simulate(std::uint64_t duration_ns,
                                                     std::uint64_t seed = 1) const;
private:
    SchedulingPolicy policy_ = SchedulingPolicy::FixedPriority;
    std::size_t cpu_count_ = 1;
    std::vector<RealTimeTask> tasks_;
};

struct PtpSample {
    std::int64_t master_to_slave_ns = 0;
    std::int64_t slave_to_master_ns = 0;
    std::int64_t correction_ns = 0;
};

struct PtpDisciplineResult {
    double offset_ns = 0.0;
    double path_delay_ns = 0.0;
    double drift_ppm = 0.0;
    double rms_error_ns = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class PtpClockDiscipline {
public:
    [[nodiscard]] PtpDisciplineResult estimate(const std::vector<PtpSample>& samples,
                                               double elapsed_s) const;
};

struct AutosarPort {
    std::string name;
    std::string interface_name;
    bool provided = false;
};

struct AutosarRunnable {
    std::string name;
    std::uint64_t period_ns = 0;
    std::uint64_t deadline_ns = 0;
    std::uint64_t wcet_ns = 0;
    std::string task;
};

struct AutosarService {
    std::string name;
    std::uint16_t service_id = 0;
    std::uint16_t instance_id = 0;
    std::string process;
    std::set<std::string> dependencies;
};

struct AutosarModel {
    std::string system_name;
    std::map<std::string, AutosarPort> ports;
    std::map<std::string, AutosarRunnable> runnables;
    std::map<std::string, AutosarService> services;
    std::map<std::string, std::string> unknown_fragments;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

struct AutosarValidationReport {
    std::vector<std::string> errors;
    std::vector<std::string> warnings;
    double estimated_cpu_utilization = 0.0;
    bool valid = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AutosarToolchain {
public:
    [[nodiscard]] AutosarModel parse_arxml(const std::string& text) const;
    [[nodiscard]] std::string emit_arxml(const AutosarModel& model) const;
    [[nodiscard]] AutosarValidationReport validate(const AutosarModel& model) const;
    [[nodiscard]] std::string generate_rte_c(const AutosarModel& model,
                                             const std::string& component_name) const;
    [[nodiscard]] doc::Value generate_adaptive_manifests(const AutosarModel& model) const;
};

} // namespace aesim::advanced

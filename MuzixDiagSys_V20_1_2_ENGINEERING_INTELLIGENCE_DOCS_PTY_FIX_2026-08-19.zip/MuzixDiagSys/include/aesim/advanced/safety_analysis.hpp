#pragma once

#include "aesim/professional/document.hpp"

#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

struct HaraEvent {
    std::string id;
    std::string function;
    std::string malfunction;
    std::string operational_situation;
    std::string hazard;
    unsigned severity = 0;
    unsigned exposure = 0;
    unsigned controllability = 0;
    std::string asil;
};

struct FmeaEntry {
    std::string id;
    std::string component;
    std::string failure_mode;
    std::string local_effect;
    std::string vehicle_effect;
    std::string safety_mechanism;
    unsigned severity = 1;
    unsigned occurrence = 1;
    unsigned detection = 1;
    unsigned rpn = 1;
    double failure_rate_fit = 0.0;
    double safe_fraction = 0.0;
    double detected_fraction = 0.0;
    bool latent = false;
};

struct FmedaMetrics {
    double total_failure_rate_fit = 0.0;
    double safe_failure_rate_fit = 0.0;
    double detected_dangerous_rate_fit = 0.0;
    double single_point_fault_rate_fit = 0.0;
    double latent_multiple_point_fault_rate_fit = 0.0;
    double spfm = 1.0;
    double lfm = 1.0;
};

struct FaultTreeResult {
    std::string top_event;
    double probability = 0.0;
    std::vector<std::set<std::string>> minimal_cut_sets;
};

struct StpaUnsafeControlAction {
    std::string id;
    std::string controller;
    std::string action;
    std::string category;
    std::string context;
    std::string hazard;
    std::string safety_constraint;
};

struct SafetyAnalysisResult {
    std::string item;
    std::vector<HaraEvent> hara;
    std::vector<FmeaEntry> fmea;
    FmedaMetrics fmeda;
    std::vector<FaultTreeResult> fault_trees;
    std::vector<StpaUnsafeControlAction> stpa;
    [[nodiscard]] doc::Value to_document() const;
};

class SafetyAnalysisGenerator {
public:
    [[nodiscard]] SafetyAnalysisResult generate(const doc::Value& model) const;
    [[nodiscard]] static std::string asil(unsigned severity, unsigned exposure,
                                          unsigned controllability);

private:
    [[nodiscard]] FaultTreeResult analyze_fault_tree(const doc::Value& tree) const;
};

} // namespace aesim::advanced

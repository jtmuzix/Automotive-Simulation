#pragma once

#include "aesim/professional/document.hpp"

#include <complex>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// SPICE, EMC, and wiring-harness co-simulation
// -----------------------------------------------------------------------------

enum class SpiceElementKind {
    Resistor,
    Capacitor,
    Inductor,
    VoltageSource,
    CurrentSource
};

struct SpiceElement {
    std::string id;
    SpiceElementKind kind = SpiceElementKind::Resistor;
    std::string positive_node;
    std::string negative_node;
    double value = 0.0;
    double initial_condition = 0.0;
};

struct WiringHarnessSection {
    std::string id;
    std::string source_node;
    std::string destination_node;
    double length_m = 1.0;
    double resistance_ohm_per_m = 0.02;
    double inductance_h_per_m = 0.7e-6;
    double capacitance_f_per_m = 50e-12;
    std::size_t segments = 4;
};

struct HarnessCoupling {
    std::string aggressor_node;
    std::string victim_node;
    double mutual_capacitance_f = 0.0;
    double mutual_inductance_h = 0.0;
};

struct SpiceCircuit {
    std::string ground = "0";
    std::vector<SpiceElement> elements;
    std::vector<WiringHarnessSection> harness_sections;
    std::vector<HarnessCoupling> couplings;
};

struct SpiceTransientOptions {
    double start_time_s = 0.0;
    double stop_time_s = 0.01;
    double time_step_s = 1.0e-5;
    std::map<std::string, std::vector<double>> source_waveforms;
};

struct SpiceTransientResult {
    std::vector<double> time_s;
    std::map<std::string, std::vector<double>> node_voltage_v;
    std::map<std::string, std::vector<double>> branch_current_a;
    double maximum_kcl_residual_a = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_waveforms = true) const;
};

struct EmcSweepPoint {
    double frequency_hz = 0.0;
    std::map<std::string, double> node_magnitude_v;
    std::map<std::string, double> node_phase_rad;
    double common_mode_current_a = 0.0;
    double estimated_conducted_emission_dbuv = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct EmcSweepResult {
    std::vector<EmcSweepPoint> points;
    double peak_emission_dbuv = -300.0;
    double peak_frequency_hz = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SpiceEmcHarnessSimulator {
public:
    [[nodiscard]] SpiceTransientResult simulate_transient(
        const SpiceCircuit& circuit,
        const SpiceTransientOptions& options) const;
    [[nodiscard]] EmcSweepResult ac_sweep(
        const SpiceCircuit& circuit,
        double start_frequency_hz,
        double stop_frequency_hz,
        std::size_t points_per_decade,
        const std::string& driven_voltage_source) const;
};

// -----------------------------------------------------------------------------
// Cell-resolved battery abuse and thermal-runaway propagation
// -----------------------------------------------------------------------------

enum class BatteryAbuseType {
    InternalShort,
    ExternalHeating,
    Overcharge,
    Crush,
    CoolingLoss
};

struct BatteryCellDefinition {
    std::string id;
    double capacity_ah = 50.0;
    double nominal_voltage_v = 3.7;
    double internal_resistance_ohm = 0.002;
    double mass_kg = 0.9;
    double heat_capacity_j_kg_k = 900.0;
    double surface_area_m2 = 0.08;
    double convection_w_m2_k = 8.0;
    double vent_temperature_k = 393.15;
    double runaway_onset_temperature_k = 423.15;
    double runaway_energy_j = 450000.0;
    double gas_generation_mol = 2.5;
};

struct BatteryCellState {
    double state_of_charge = 0.8;
    double temperature_k = 298.15;
    double terminal_voltage_v = 3.7;
    double generated_gas_mol = 0.0;
    double runaway_progress = 0.0;
    bool vented = false;
    bool thermal_runaway = false;
};

struct BatteryThermalLink {
    std::size_t first_cell = 0;
    std::size_t second_cell = 0;
    double conductance_w_k = 1.0;
};

struct BatteryAbuseEvent {
    BatteryAbuseType type = BatteryAbuseType::ExternalHeating;
    std::size_t cell = 0;
    double start_time_s = 0.0;
    double duration_s = 1.0;
    double magnitude = 0.0;
};

struct BatteryAbuseSimulationOptions {
    double duration_s = 300.0;
    double time_step_s = 0.01;
    double pack_current_a = 0.0;
    double ambient_temperature_k = 298.15;
    double enclosure_volume_m3 = 0.1;
    double vent_pressure_pa = 250000.0;
};

struct BatteryAbuseResult {
    std::vector<double> time_s;
    std::vector<BatteryCellState> final_cells;
    std::vector<std::vector<double>> cell_temperature_k;
    std::vector<std::vector<double>> cell_voltage_v;
    std::vector<double> enclosure_pressure_pa;
    std::vector<double> pack_voltage_v;
    std::vector<std::string> events;
    std::size_t runaway_cells = 0;
    std::size_t vented_cells = 0;
    double maximum_temperature_k = 0.0;
    double maximum_pressure_pa = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_waveforms = true) const;
};

class CellResolvedBatteryAbuseSimulator {
public:
    [[nodiscard]] BatteryAbuseResult simulate(
        const std::vector<BatteryCellDefinition>& definitions,
        const std::vector<BatteryCellState>& initial_states,
        const std::vector<BatteryThermalLink>& thermal_links,
        const std::vector<BatteryAbuseEvent>& abuse_events,
        const BatteryAbuseSimulationOptions& options) const;
};

// -----------------------------------------------------------------------------
// E/E architecture synthesis
// -----------------------------------------------------------------------------

struct EeComputeNodeCandidate {
    std::string id;
    std::string zone;
    double cpu_capacity_mips = 0.0;
    double memory_capacity_mb = 0.0;
    double cost = 0.0;
    double mass_kg = 0.0;
    double power_w = 0.0;
    unsigned asil_capability = 0;
    std::string diversity_group;
    // Zonal architecture metadata. Appended for source compatibility with
    // existing aggregate initializers.
    std::string failure_domain;
    std::string power_feed;
    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
};

struct EeFunctionRequirement {
    std::string id;
    std::string zone;
    double cpu_mips = 0.0;
    double memory_mb = 0.0;
    double maximum_latency_ms = 1000.0;
    unsigned asil_level = 0;
    unsigned replicas = 1;
    bool require_diverse_replicas = false;
    // Optional physical endpoint location used to minimize zonal harnessing.
    bool has_endpoint_location = false;
    double endpoint_x_m = 0.0;
    double endpoint_y_m = 0.0;
    double endpoint_z_m = 0.0;
    double harness_mass_kg_per_m = 0.0;
    double harness_cost_per_m = 0.0;
    double maximum_harness_length_m = 1.0e300;
    bool require_failure_domain_diversity = false;
    bool require_power_feed_diversity = false;
};

struct EeCommunicationFlow {
    std::string id;
    std::string source_function;
    std::string destination_function;
    double bandwidth_mbps = 0.0;
    double maximum_latency_ms = 1000.0;
};

struct EeNetworkLinkCandidate {
    std::string id;
    std::string first_node;
    std::string second_node;
    double bandwidth_mbps = 100.0;
    double latency_ms = 0.1;
    double cost = 0.0;
    double mass_kg = 0.0;
    double power_w = 0.0;
};

struct EeArchitectureSynthesisOptions {
    double cost_weight = 1.0;
    double mass_weight = 1.0;
    double power_weight = 1.0;
    double cross_zone_latency_penalty = 0.05;
    double harness_mass_weight = 1.0;
    double harness_cost_weight = 1.0;
    double cross_zone_allocation_penalty = 0.0;
    std::size_t maximum_search_nodes = 1000000;
};

struct EeFunctionAllocation {
    std::string function_id;
    unsigned replica = 0;
    std::string compute_node;
    [[nodiscard]] doc::Value to_document() const;
};

struct EeArchitectureSynthesisResult {
    bool feasible = false;
    std::vector<EeFunctionAllocation> allocations;
    std::vector<std::string> selected_compute_nodes;
    std::vector<std::string> selected_network_links;
    std::map<std::string, double> compute_utilization;
    std::map<std::string, double> memory_utilization;
    std::map<std::string, double> link_utilization;
    double total_harness_length_m = 0.0;
    double total_harness_mass_kg = 0.0;
    double total_harness_cost = 0.0;
    std::size_t cross_zone_allocations = 0;
    bool failure_domain_diversity_satisfied = true;
    bool power_feed_diversity_satisfied = true;
    double objective = 0.0;
    std::size_t explored_search_nodes = 0;
    std::vector<std::string> diagnostics;
    std::string certificate_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EeArchitectureSynthesizer {
public:
    [[nodiscard]] EeArchitectureSynthesisResult synthesize(
        const std::vector<EeComputeNodeCandidate>& compute_nodes,
        const std::vector<EeFunctionRequirement>& functions,
        const std::vector<EeCommunicationFlow>& flows,
        const std::vector<EeNetworkLinkCandidate>& network_links,
        const EeArchitectureSynthesisOptions& options = {}) const;
};

} // namespace aesim::advanced

#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::indyint {

class IndyCarIntegratedCoSimulationRuntime {
public:
    [[nodiscard]] doc::Value run(const doc::Value& request,
                                 const std::string& working_directory = {}) const;
};

class IndyCarTelemetryAssimilationCalibration {
public:
    [[nodiscard]] doc::Value assimilate(const doc::Value& request,
                                        const std::string& working_directory = {}) const;
};

class IndyCarFullMultibodyVehicle {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarDetailedTireContactModel {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarUnsteadyAeroelasticAerodynamics {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarClosedLoopEcuHybridControl {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarRadioSemanticsTimingUncertainty {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarPitLaneDiscreteEventTwin {
public:
    [[nodiscard]] doc::Value simulate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarOccupantBiomechanics {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarUncertaintyModelValidityFramework {
public:
    [[nodiscard]] doc::Value evaluate(const doc::Value& request,
                                      const std::string& working_directory = {}) const;
};

class IndyCarIntegratedFidelityPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::indyint

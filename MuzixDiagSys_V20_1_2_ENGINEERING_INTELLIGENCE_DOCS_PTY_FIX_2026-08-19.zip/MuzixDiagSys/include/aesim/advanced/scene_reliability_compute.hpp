#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// OpenUSD scene composition and synthetic-data generation
// -----------------------------------------------------------------------------

struct UsdMaterial {
    std::string name;
    std::array<double, 3> diffuse_rgb{{0.5, 0.5, 0.5}};
    double metallic = 0.0;
    double roughness = 0.5;
    double radar_cross_section_dbsm = 0.0;
    double lidar_reflectivity = 0.5;
};

struct UsdSceneObject {
    std::string name;
    std::string semantic_class;
    std::array<double, 3> position_m{{0.0, 0.0, 0.0}};
    std::array<double, 3> size_m{{1.0, 1.0, 1.0}};
    std::array<double, 3> velocity_m_s{{0.0, 0.0, 0.0}};
    std::string material;
    std::uint64_t instance_id = 0;
};

struct SyntheticSensorRig {
    std::string name = "ego";
    std::size_t image_width = 1280;
    std::size_t image_height = 720;
    double horizontal_fov_deg = 90.0;
    double lidar_horizontal_resolution_deg = 1.0;
    double lidar_vertical_fov_deg = 30.0;
    std::size_t lidar_channels = 32;
    double maximum_range_m = 200.0;
};

struct SyntheticFrameResult {
    std::uint64_t frame_index = 0;
    doc::Value annotations;
    std::vector<std::array<double, 4>> lidar_points_xyzi;
    std::vector<std::array<double, 4>> radar_detections_range_azimuth_velocity_rcs;
    std::string frame_sha256;
    [[nodiscard]] doc::Value to_document(bool include_points = true) const;
};

class OpenUsdSyntheticDataFactory {
public:
    void add_material(UsdMaterial material);
    void add_object(UsdSceneObject object);
    void set_sensor_rig(SyntheticSensorRig rig);
    [[nodiscard]] std::string compose_usda(const std::string& stage_name = "MuzixScene") const;
    void write_usda(const std::string& path, const std::string& stage_name = "MuzixScene") const;
    [[nodiscard]] SyntheticFrameResult generate_frame(std::uint64_t frame_index,
                                                       double time_s,
                                                       std::uint64_t seed) const;
    void write_dataset(const std::string& directory,
                       std::size_t frame_count,
                       double step_s,
                       std::uint64_t seed) const;
private:
    std::map<std::string, UsdMaterial> materials_;
    std::vector<UsdSceneObject> objects_;
    SyntheticSensorRig rig_;
};

// -----------------------------------------------------------------------------
// Rare-event reliability analysis
// -----------------------------------------------------------------------------

struct ReliabilityVariable {
    std::string name;
    double mean = 0.0;
    double standard_deviation = 1.0;
};

using LimitStateFunction = std::function<double(const std::vector<double>&)>;

struct RareEventOptions {
    std::size_t samples = 10000;
    std::size_t subset_size = 1000;
    double subset_probability = 0.1;
    std::size_t maximum_levels = 10;
    std::size_t cross_entropy_iterations = 8;
    std::uint64_t seed = 1;
};

struct RareEventResult {
    std::string method;
    double failure_probability = 0.0;
    double standard_error = 0.0;
    double confidence_lower = 0.0;
    double confidence_upper = 0.0;
    double reliability_index = 0.0;
    std::size_t evaluations = 0;
    std::vector<double> most_probable_failure_point;
    std::vector<double> importance_factors;
    std::vector<double> thresholds;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RareEventReliabilityAnalyzer {
public:
    [[nodiscard]] RareEventResult crude_monte_carlo(
        const std::vector<ReliabilityVariable>& variables,
        const LimitStateFunction& limit_state,
        const RareEventOptions& options) const;
    [[nodiscard]] RareEventResult cross_entropy_importance_sampling(
        const std::vector<ReliabilityVariable>& variables,
        const LimitStateFunction& limit_state,
        const RareEventOptions& options) const;
    [[nodiscard]] RareEventResult subset_simulation(
        const std::vector<ReliabilityVariable>& variables,
        const LimitStateFunction& limit_state,
        const RareEventOptions& options) const;
    [[nodiscard]] RareEventResult form(
        const std::vector<ReliabilityVariable>& variables,
        const LimitStateFunction& limit_state,
        std::size_t maximum_iterations = 100,
        double tolerance = 1.0e-7) const;
};

// -----------------------------------------------------------------------------
// Cycle-accurate vehicle-compute and NPU co-simulation
// -----------------------------------------------------------------------------

enum class ComputeInstructionKind {
    IntegerAlu,
    FloatingPoint,
    Load,
    Store,
    Branch,
    Vector,
    NpuMac,
    Dma
};

struct ComputeInstruction {
    ComputeInstructionKind kind = ComputeInstructionKind::IntegerAlu;
    std::uint64_t address = 0;
    std::uint64_t data_address = 0;
    std::size_t operations = 1;
    bool branch_taken = false;
};

struct ComputeTaskTrace {
    std::string id;
    unsigned core = 0;
    unsigned priority = 0;
    std::uint64_t release_cycle = 0;
    std::uint64_t deadline_cycle = 0;
    std::vector<ComputeInstruction> instructions;
};

struct VehicleComputeConfiguration {
    unsigned cores = 4;
    double clock_hz = 2.0e9;
    std::size_t l1_sets = 64;
    std::size_t l1_line_bytes = 64;
    std::size_t l2_sets = 1024;
    std::size_t l2_line_bytes = 64;
    unsigned l1_hit_cycles = 1;
    unsigned l2_hit_cycles = 12;
    unsigned memory_cycles = 120;
    unsigned branch_mispredict_cycles = 15;
    std::size_t npu_macs_per_cycle = 1024;
    double dynamic_energy_nj_per_cycle = 0.5;
    double leakage_power_w = 5.0;
    double thermal_resistance_k_w = 0.5;
    double thermal_capacitance_j_k = 50.0;
    double ambient_temperature_k = 298.15;
    double throttle_temperature_k = 368.15;
};

struct ComputeTaskResult {
    std::string id;
    std::uint64_t start_cycle = 0;
    std::uint64_t finish_cycle = 0;
    std::uint64_t execution_cycles = 0;
    std::uint64_t l1_hits = 0;
    std::uint64_t l2_hits = 0;
    std::uint64_t memory_accesses = 0;
    std::uint64_t branch_mispredictions = 0;
    bool deadline_met = false;
    double energy_j = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct VehicleComputeResult {
    std::vector<ComputeTaskResult> tasks;
    std::uint64_t total_cycles = 0;
    double elapsed_s = 0.0;
    double energy_j = 0.0;
    double final_temperature_k = 298.15;
    std::uint64_t deadline_misses = 0;
    std::string trace_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CycleAccurateVehicleComputeSimulator {
public:
    explicit CycleAccurateVehicleComputeSimulator(VehicleComputeConfiguration configuration = {});
    [[nodiscard]] VehicleComputeResult run(std::vector<ComputeTaskTrace> tasks);
private:
    VehicleComputeConfiguration configuration_;
};

} // namespace aesim::advanced

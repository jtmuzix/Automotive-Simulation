#pragma once

#include "aesim/advanced/codegen_manufacturing_fleet.hpp"
#include "aesim/professional/document.hpp"

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <random>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::frontier {

// =============================================================================
// 1. OPC UA / Asset Administration Shell digital-twin gateway
// =============================================================================

enum class UaNodeClass { Object, Variable, Method };

struct UaNodeId {
    std::uint16_t namespace_index = 0;
    std::string identifier;
    [[nodiscard]] std::string str() const;
    [[nodiscard]] bool operator<(const UaNodeId& other) const noexcept;
    [[nodiscard]] bool operator==(const UaNodeId& other) const noexcept;
};

struct UaNode {
    UaNodeId id;
    UaNodeId parent;
    UaNodeClass node_class = UaNodeClass::Object;
    std::string browse_name;
    std::string display_name;
    std::string data_type = "BaseDataType";
    doc::Value value;
    bool writable = false;
    std::map<std::string, std::string> attributes;
};

struct UaNotification {
    std::uint64_t sequence = 0;
    UaNodeId node;
    doc::Value value;
    std::chrono::system_clock::time_point timestamp;
};

struct AasProperty {
    std::string id_short;
    std::string semantic_id;
    std::string value_type = "xs:string";
    std::string unit;
    doc::Value value;
};

struct AasSubmodel {
    std::string id;
    std::string id_short;
    std::string semantic_id;
    std::vector<AasProperty> properties;
};

struct AasShell {
    std::string id;
    std::string id_short;
    std::string global_asset_id;
    std::vector<AasSubmodel> submodels;
};

class OpcUaAasGateway {
public:
    using SubscriptionCallback = std::function<void(const UaNotification&)>;

    OpcUaAasGateway();
    ~OpcUaAasGateway();
    OpcUaAasGateway(const OpcUaAasGateway&) = delete;
    OpcUaAasGateway& operator=(const OpcUaAasGateway&) = delete;

    std::uint16_t register_namespace(const std::string& uri);
    UaNodeId add_object(std::uint16_t namespace_index, const std::string& identifier,
                        const std::string& browse_name, const UaNodeId& parent = {});
    UaNodeId add_variable(std::uint16_t namespace_index, const std::string& identifier,
                          const std::string& browse_name, const std::string& data_type,
                          doc::Value value, bool writable, const UaNodeId& parent = {});
    void write(const UaNodeId& node, doc::Value value);
    [[nodiscard]] doc::Value read(const UaNodeId& node) const;
    [[nodiscard]] std::vector<UaNode> browse(const UaNodeId& parent) const;
    [[nodiscard]] doc::Value address_space_document() const;

    std::uint64_t subscribe(const UaNodeId& node, double absolute_deadband,
                            SubscriptionCallback callback);
    void unsubscribe(std::uint64_t subscription_id);

    void set_shell(AasShell shell);
    void map_variable(const UaNodeId& node, const std::string& submodel_id_short,
                      std::string property_id_short, std::string semantic_id = {},
                      std::string unit = {});
    [[nodiscard]] doc::Value aas_environment() const;
    [[nodiscard]] std::string aas_json(bool pretty = true) const;
    bool write_aasx(const std::string& path, std::string& error) const;
    bool read_aasx(const std::string& path, std::string& error);

    // A native OPC UA network endpoint is enabled when open62541 is available at
    // build time. The in-process address space and AAS package engine remain fully
    // functional without that optional dependency.
    [[nodiscard]] bool native_opcua_available() const noexcept;
    bool start_native_server(std::uint16_t port, std::string& error);
    void stop_native_server();
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// =============================================================================
// 2. Physical Driver-in-the-Loop and OpenXR runtime
// =============================================================================

struct DilAxisCalibration {
    int minimum = -32768;
    int center = 0;
    int maximum = 32767;
    double deadzone = 0.02;
    bool invert = false;
};

struct DilInputState {
    double steering = 0.0;      // [-1, 1]
    double throttle = 0.0;      // [0, 1]
    double brake = 0.0;         // [0, 1]
    double clutch = 0.0;        // [0, 1]
    std::int32_t gear = 0;
    std::map<int, bool> buttons;
    std::uint64_t timestamp_ns = 0;
};

class PhysicalDilDevice {
public:
    PhysicalDilDevice();
    ~PhysicalDilDevice();
    PhysicalDilDevice(const PhysicalDilDevice&) = delete;
    PhysicalDilDevice& operator=(const PhysicalDilDevice&) = delete;

    bool open_evdev(const std::string& device_path, std::string& error);
    void configure_axis(unsigned code, DilAxisCalibration calibration, const std::string& role);
    [[nodiscard]] DilInputState poll(std::chrono::milliseconds timeout = std::chrono::milliseconds(0));
    bool set_constant_force(double normalized_force, std::string& error);
    void inject(const DilInputState& state);
    void close();
    [[nodiscard]] bool open() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

struct XrPose {
    double position_m[3] = {0.0, 0.0, 0.0};
    double orientation_xyzw[4] = {0.0, 0.0, 0.0, 1.0};
    bool position_valid = false;
    bool orientation_valid = false;
    std::uint64_t timestamp_ns = 0;
};

struct XrRuntimeState {
    bool native_runtime = false;
    bool system_available = false;
    bool session_running = false;
    std::string runtime_name;
    XrPose head;
    XrPose left_hand;
    XrPose right_hand;
};

class OpenXrDilRuntime {
public:
    OpenXrDilRuntime();
    ~OpenXrDilRuntime();
    OpenXrDilRuntime(const OpenXrDilRuntime&) = delete;
    OpenXrDilRuntime& operator=(const OpenXrDilRuntime&) = delete;

    bool initialize(std::string application_name, std::string& error);
    [[nodiscard]] XrRuntimeState poll();
    void inject_pose(const std::string& role, const XrPose& pose);
    void shutdown();
    [[nodiscard]] bool native_openxr_available() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// =============================================================================
// 3. Real automotive hardware I/O backends
// =============================================================================

enum class HardwareBackendKind {
    SocketCan,
    PeakPcan,
    KvaserCanlib,
    VectorXl,
    NiXnet,
    Plugin,
    Loopback
};

struct HardwareCanFrame {
    std::uint32_t identifier = 0;
    bool extended = false;
    bool fd = false;
    bool bitrate_switch = false;
    bool error = false;
    std::uint64_t timestamp_ns = 0;
    std::vector<std::uint8_t> data;
};

struct HardwareChannelConfig {
    HardwareBackendKind backend = HardwareBackendKind::SocketCan;
    std::string channel;
    std::uint32_t bitrate = 500000;
    std::uint32_t data_bitrate = 2000000;
    bool fd = false;
    bool receive_own_messages = false;
    std::string driver_library;
    std::string plugin_library;
};

struct HardwareBackendCapability {
    HardwareBackendKind backend = HardwareBackendKind::SocketCan;
    bool available = false;
    std::string detail;
};

class HardwareCanChannel {
public:
    HardwareCanChannel();
    ~HardwareCanChannel();
    HardwareCanChannel(const HardwareCanChannel&) = delete;
    HardwareCanChannel& operator=(const HardwareCanChannel&) = delete;

    static HardwareBackendCapability probe(HardwareBackendKind backend,
                                           const std::string& library_hint = {});
    bool open(const HardwareChannelConfig& config, std::string& error);
    bool send(const HardwareCanFrame& frame, std::string& error);
    [[nodiscard]] std::optional<HardwareCanFrame> receive(std::chrono::milliseconds timeout,
                                                          std::string& error);
    void close();
    [[nodiscard]] bool open() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// Stable C ABI for vendor/laboratory adapters whose proprietary SDK cannot be
// linked directly into a redistributable build. A plugin implementing this ABI
// is a real transport backend, not a simulation shim.
inline constexpr std::uint32_t kHardwarePluginAbiVersion = 1;

// =============================================================================
// 4. ns-3 packet-level network federation
// =============================================================================

struct Ns3Packet {
    std::uint64_t packet_id = 0;
    std::uint64_t tx_time_ns = 0;
    std::uint32_t source_node = 0;
    std::uint32_t destination_node = 0;
    std::uint16_t protocol = 0;
    std::uint8_t traffic_class = 0;
    std::vector<std::uint8_t> payload;
};

struct Ns3PacketResult {
    std::uint64_t packet_id = 0;
    bool delivered = false;
    bool congested = false;
    std::uint64_t rx_time_ns = 0;
    double latency_ms = 0.0;
    double loss_probability = 0.0;
    std::string diagnostic;
};

enum class Ns3Mode { ExternalUdpBridge, DeterministicReference };

struct Ns3FederationConfig {
    Ns3Mode mode = Ns3Mode::ExternalUdpBridge;
    std::string host = "127.0.0.1";
    std::uint16_t port = 47003;
    std::chrono::milliseconds timeout{1000};
    std::uint64_t seed = 1;
    double reference_bitrate_bps = 100000000.0;
    double reference_propagation_delay_ms = 0.2;
    double reference_loss_probability = 0.0;
};

class Ns3Federation {
public:
    Ns3Federation();
    ~Ns3Federation();
    Ns3Federation(const Ns3Federation&) = delete;
    Ns3Federation& operator=(const Ns3Federation&) = delete;

    bool connect(const Ns3FederationConfig& config, std::string& error);
    [[nodiscard]] Ns3PacketResult transmit(const Ns3Packet& packet);
    [[nodiscard]] std::vector<Ns3PacketResult> run_batch(const std::vector<Ns3Packet>& packets);
    void disconnect();
    [[nodiscard]] bool connected() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// =============================================================================
// 5. Jupyter is provided by python/muzixdiag/research_lab.py and notebooks/.
// The C++ capability record lets applications discover those assets reliably.
// =============================================================================

struct JupyterResearchEnvironment {
    std::string package = "muzixdiag";
    std::vector<std::string> notebooks;
    std::vector<std::string> workflows;
    [[nodiscard]] doc::Value to_document() const;
    static JupyterResearchEnvironment default_environment();
};

// =============================================================================
// 6. Prometheus/OpenMetrics observability
// =============================================================================

enum class PrometheusMetricType { Counter, Gauge, Histogram };
using MetricLabels = std::map<std::string, std::string>;

class PrometheusRegistry {
public:
    PrometheusRegistry();
    ~PrometheusRegistry();
    PrometheusRegistry(const PrometheusRegistry&) = delete;
    PrometheusRegistry& operator=(const PrometheusRegistry&) = delete;

    void define_counter(std::string name, std::string help);
    void define_gauge(std::string name, std::string help);
    void define_histogram(std::string name, std::string help, std::vector<double> buckets);
    void increment(const std::string& name, double amount = 1.0, const MetricLabels& labels = {});
    void set(const std::string& name, double value, const MetricLabels& labels = {});
    void observe(const std::string& name, double value, const MetricLabels& labels = {});
    [[nodiscard]] std::string render_text() const;
    [[nodiscard]] doc::Value snapshot() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

class PrometheusHttpExporter {
public:
    explicit PrometheusHttpExporter(PrometheusRegistry& registry);
    ~PrometheusHttpExporter();
    PrometheusHttpExporter(const PrometheusHttpExporter&) = delete;
    PrometheusHttpExporter& operator=(const PrometheusHttpExporter&) = delete;

    bool start(const std::string& bind_address, std::uint16_t port, std::string& error);
    void stop();
    [[nodiscard]] bool running() const noexcept;
    [[nodiscard]] std::string endpoint() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// =============================================================================
// 7. Sigstore/in-toto provenance
// =============================================================================

struct SigstoreMaterial {
    std::string uri;
    std::string sha256;
};

struct SigstoreResult {
    bool success = false;
    int exit_code = -1;
    std::string bundle_path;
    std::string statement_path;
    std::string statement_sha256;
    std::string diagnostic;
};

class SigstoreProvenance {
public:
    [[nodiscard]] static doc::Value in_toto_statement(
        const std::string& artifact_path,
        const std::string& predicate_type,
        const doc::Value& predicate,
        const std::vector<SigstoreMaterial>& materials = {});
    static bool write_statement(const std::string& artifact_path,
                                const std::string& predicate_type,
                                const doc::Value& predicate,
                                const std::vector<SigstoreMaterial>& materials,
                                const std::string& output_path,
                                std::string& error);
    [[nodiscard]] static bool cosign_available(const std::string& executable = "cosign");
    [[nodiscard]] static SigstoreResult sign_blob(const std::string& artifact_path,
                                                  const std::string& bundle_path,
                                                  const std::string& executable = "cosign",
                                                  const std::string& key_path = {});
    [[nodiscard]] static SigstoreResult verify_blob(const std::string& artifact_path,
                                                    const std::string& bundle_path,
                                                    const std::string& executable = "cosign",
                                                    const std::string& certificate_identity = {},
                                                    const std::string& certificate_oidc_issuer = {},
                                                    const std::string& key_path = {});
    [[nodiscard]] static bool validate_bundle_json(const std::string& bundle_path,
                                                   std::string& error);
};

// =============================================================================
// 8. Advanced Bayesian HMC/NUTS and multilevel Monte Carlo
// =============================================================================

using ParameterVector = std::vector<double>;
using LogDensity = std::function<double(const ParameterVector&)>;
using LogDensityGradient = std::function<ParameterVector(const ParameterVector&)>;

struct HmcOptions {
    std::size_t warmup = 500;
    std::size_t samples = 1000;
    std::size_t leapfrog_steps = 16;
    double step_size = 0.1;
    double target_acceptance = 0.8;
    double trajectory_jitter = 0.2; // fractional randomization of leapfrog count; seeded/reproducible
    bool adapt_step_size = true;
    std::uint64_t seed = 1;
};

struct NutsOptions {
    std::size_t warmup = 500;
    std::size_t samples = 1000;
    std::size_t maximum_tree_depth = 9;
    double initial_step_size = 0.1;
    double target_acceptance = 0.8;
    std::uint64_t seed = 1;
};

struct McmcDiagnostics {
    double acceptance_rate = 0.0;
    double mean_acceptance_probability = 0.0;
    double effective_sample_size_min = 0.0;
    double rhat_max = 1.0;
    std::size_t divergent_transitions = 0;
};

struct McmcResult {
    std::vector<ParameterVector> samples;
    McmcDiagnostics diagnostics;
    double final_step_size = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class HamiltonianMonteCarlo {
public:
    [[nodiscard]] static McmcResult sample(const LogDensity& log_density,
                                           const ParameterVector& initial,
                                           const HmcOptions& options,
                                           const LogDensityGradient& gradient = {});
};

class NoUTurnSampler {
public:
    [[nodiscard]] static McmcResult sample(const LogDensity& log_density,
                                           const ParameterVector& initial,
                                           const NutsOptions& options,
                                           const LogDensityGradient& gradient = {});
};

struct MlmcLevelSample {
    double fine = 0.0;
    double coarse = 0.0;
    double cost = 1.0;
};

struct MlmcResult {
    double estimate = 0.0;
    double variance_estimate = 0.0;
    double standard_error = 0.0;
    double total_cost = 0.0;
    std::vector<std::size_t> samples_per_level;
    std::vector<double> mean_correction;
    std::vector<double> variance_correction;
    [[nodiscard]] doc::Value to_document() const;
};

class MultilevelMonteCarlo {
public:
    using Sampler = std::function<MlmcLevelSample(std::size_t level, std::mt19937_64& rng)>;
    [[nodiscard]] static MlmcResult estimate(std::size_t levels,
                                             std::size_t pilot_samples,
                                             double target_rmse,
                                             std::uint64_t seed,
                                             const Sampler& sampler,
                                             std::size_t maximum_samples_per_level = 1000000);
};

// =============================================================================
// 9. Acoustic beamforming and active-noise control
// =============================================================================

struct AcousticPoint3 {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

struct BeamScanPoint {
    double azimuth_deg = 0.0;
    double elevation_deg = 0.0;
    double power = 0.0;
};

class AcousticBeamformer {
public:
    [[nodiscard]] static std::vector<double> delay_and_sum(
        const std::vector<std::vector<double>>& channels,
        const std::vector<AcousticPoint3>& microphones,
        double azimuth_deg, double elevation_deg,
        double sample_rate_hz, double sound_speed_mps = 343.0);
    [[nodiscard]] static std::vector<BeamScanPoint> scan_azimuth(
        const std::vector<std::vector<double>>& channels,
        const std::vector<AcousticPoint3>& microphones,
        double sample_rate_hz, double minimum_azimuth_deg,
        double maximum_azimuth_deg, double step_deg,
        double elevation_deg = 0.0, double sound_speed_mps = 343.0);
    [[nodiscard]] static std::vector<BeamScanPoint> mvdr_narrowband_scan(
        const std::vector<std::vector<double>>& channels,
        const std::vector<AcousticPoint3>& microphones,
        double sample_rate_hz, double frequency_hz,
        double minimum_azimuth_deg, double maximum_azimuth_deg,
        double step_deg, double diagonal_loading = 1e-6,
        double sound_speed_mps = 343.0);
};

struct AncStep {
    double control = 0.0;
    double anti_noise = 0.0;
    double error = 0.0;
};

class FxLmsController {
public:
    void configure(std::size_t adaptive_taps,
                   std::vector<double> secondary_path,
                   double adaptation_rate,
                   double leakage = 0.0,
                   double output_limit = 1.0);
    [[nodiscard]] AncStep step(double reference, double disturbance);
    void reset();
    [[nodiscard]] const std::vector<double>& coefficients() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    std::vector<double> weights_;
    std::vector<double> secondary_path_;
    std::vector<double> reference_history_;
    std::vector<double> filtered_reference_history_;
    std::vector<double> control_history_;
    double adaptation_rate_ = 0.0;
    double leakage_ = 0.0;
    double output_limit_ = 1.0;
};

// =============================================================================
// 10. Federated/private fleet learning (extends the existing FedAvg platform)
// =============================================================================

struct DifferentialPrivacyConfig {
    double clipping_norm = 1.0;
    double noise_multiplier = 1.0;
    double delta = 1e-6;
    std::uint64_t seed = 1;
};

struct PrivacyAccount {
    std::size_t mechanisms = 0;
    double rho_zcdp = 0.0;
    double epsilon = 0.0;
    double delta = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct PrivateFederatedResult {
    FederatedAggregationResult aggregation;
    PrivacyAccount privacy;
    std::vector<std::string> participants;
    std::string secure_aggregation_transcript_sha256;
    double staleness_weight_sum = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

class FederatedPrivacyEngine {
public:
    [[nodiscard]] static std::vector<double> fedprox_local_step(
        const std::vector<double>& local_parameters,
        const std::vector<double>& global_parameters,
        const std::vector<double>& gradient,
        double learning_rate, double proximal_mu);

    [[nodiscard]] static FederatedAggregationResult krum_aggregate(
        const std::vector<FederatedClientUpdate>& updates,
        std::size_t byzantine_clients);

    [[nodiscard]] static FederatedAggregationResult asynchronous_aggregate(
        const std::vector<double>& current_global,
        const std::vector<FederatedClientUpdate>& updates,
        const std::vector<std::size_t>& staleness,
        double base_server_learning_rate,
        double staleness_exponent);

    [[nodiscard]] static PrivateFederatedResult differentially_private_fedavg(
        const std::vector<FederatedClientUpdate>& updates,
        const DifferentialPrivacyConfig& config);

    [[nodiscard]] static PrivateFederatedResult secure_fedavg(
        const std::vector<FederatedClientUpdate>& updates,
        std::uint64_t round_nonce);
};

[[nodiscard]] doc::Value frontier_professional_capabilities();

} // namespace aesim::advanced::frontier

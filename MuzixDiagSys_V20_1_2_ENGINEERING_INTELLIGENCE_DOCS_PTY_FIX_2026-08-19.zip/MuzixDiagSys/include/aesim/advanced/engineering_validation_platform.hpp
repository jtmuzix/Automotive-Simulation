#pragma once

#include "aesim/advanced/formula_one_design_qualification.hpp"
#include "aesim/professional/document.hpp"
#include "aesim/research2/standards_deployment_platform.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Commercial tire parameter identification and virtual tire qualification.
// This layer deliberately reuses F1VirtualTireTestLaboratory as the authoritative
// force/transient solver; it adds commercial parameter-deck I/O, dataset splitting,
// validation statistics, and parameter uncertainty reporting.
// -----------------------------------------------------------------------------

struct CommercialTireParameterSet {
    F1TireIdentificationParameters force_model;
    double unloaded_radius_m = 0.33;
    double nominal_load_n = 4000.0;
    double turn_slip_gain = 0.0;
    double ply_steer_n = 0.0;
    double conicity_n = 0.0;
    std::map<std::string, double> vendor_parameters;
    void validate() const;
    [[nodiscard]] doc::Value to_document() const;
};

struct CommercialTireDataset {
    std::string name;
    std::vector<F1TireObservation> observations;
};

struct CommercialTireIdentificationOptions {
    std::vector<std::string> fitted_parameters;
    std::map<std::string, std::pair<double, double>> bounds;
    std::size_t maximum_iterations = 100;
    double huber_threshold = 2.5;
    double validation_fraction = 0.20;
    std::uint64_t split_seed = 0x715eULL;
};

struct TireFitMetrics {
    double rmse_fx_n = 0.0;
    double rmse_fy_n = 0.0;
    double rmse_mz_n_m = 0.0;
    double normalized_rmse = 0.0;
    double r_squared = 0.0;
    std::size_t samples = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct CommercialTireIdentificationReport {
    CommercialTireParameterSet parameters;
    F1TireIdentificationResult optimizer;
    TireFitMetrics training;
    TireFitMetrics validation;
    std::map<std::string, double> parameter_standard_deviation;
    bool validation_passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CommercialTireIdentificationLab {
public:
    [[nodiscard]] CommercialTireParameterSet import_tir(const std::string& path) const;
    void export_tir(const CommercialTireParameterSet& parameters, const std::string& path) const;
    [[nodiscard]] F1VirtualTireOutput evaluate(const CommercialTireParameterSet& parameters,
                                               F1VirtualTireInput input) const;
    [[nodiscard]] CommercialTireIdentificationReport identify(
        const CommercialTireDataset& dataset,
        const CommercialTireParameterSet& initial,
        const CommercialTireIdentificationOptions& options) const;
};

// -----------------------------------------------------------------------------
// Real-world measurement/test correlation and road-load reconstruction.
// -----------------------------------------------------------------------------

struct EngineeringSignal {
    std::string name;
    double start_time_s = 0.0;
    double sample_period_s = 0.001;
    std::vector<double> values;
    void validate() const;
};

struct SignalCorrelationRequest {
    std::string measured_channel;
    std::string simulated_channel;
    double simulated_scale = 1.0;
    double simulated_offset = 0.0;
};

struct SignalCorrelationMetrics {
    std::string measured_channel;
    std::string simulated_channel;
    double estimated_lag_s = 0.0;
    double rmse = 0.0;
    double nrmse = 0.0;
    double r_squared = 0.0;
    double peak_error = 0.0;
    double mean_bias = 0.0;
    double correlation_coefficient = 0.0;
    double spectral_coherence = 0.0;
    std::size_t aligned_samples = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct TestCorrelationReport {
    std::vector<SignalCorrelationMetrics> channels;
    double aggregate_score = 0.0;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class RealWorldTestCorrelationLab {
public:
    [[nodiscard]] TestCorrelationReport correlate(
        const std::vector<EngineeringSignal>& measured,
        const std::vector<EngineeringSignal>& simulated,
        const std::vector<SignalCorrelationRequest>& requests,
        double maximum_lag_s = 1.0) const;
    [[nodiscard]] EngineeringSignal reconstruct_base_displacement(
        const EngineeringSignal& vertical_acceleration_m_s2,
        double high_pass_hz = 0.25) const;
};

// -----------------------------------------------------------------------------
// Synthetic-data domain randomization and governed sim-to-real qualification.
// Reuses research2::SimToRealAdapter rather than introducing another adaptation
// solver.
// -----------------------------------------------------------------------------

struct DomainRandomizationVariable {
    std::string name;
    double minimum = 0.0;
    double maximum = 1.0;
};

struct DomainRandomizationSample {
    std::uint64_t sample_id = 0;
    std::map<std::string, double> values;
};

struct SyntheticSimToRealQualification {
    std::vector<DomainRandomizationSample> randomization_design;
    research2::SimToRealAdaptationReport adaptation;
    double rbf_mmd_before = 0.0;
    double rbf_mmd_after = 0.0;
    double standardized_mean_gap_before = 0.0;
    double standardized_mean_gap_after = 0.0;
    bool improved = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class SyntheticSimToRealPipeline {
public:
    [[nodiscard]] std::vector<DomainRandomizationSample> latin_hypercube(
        const std::vector<DomainRandomizationVariable>& variables,
        std::size_t samples,
        std::uint64_t seed) const;
    [[nodiscard]] SyntheticSimToRealQualification qualify(
        const research2::DomainDataset& synthetic,
        const research2::DomainDataset& real,
        const std::vector<DomainRandomizationVariable>& randomization_variables,
        std::size_t randomization_samples,
        std::uint64_t seed = 0x51a7ULL) const;
};

} // namespace aesim::advanced

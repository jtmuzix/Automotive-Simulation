#pragma once

#include "aesim/advanced/next_generation_labs.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <optional>
#include <queue>
#include <string>
#include <vector>

namespace aesim::advanced {

// -----------------------------------------------------------------------------
// Physically based multimodal sensor rendering
// -----------------------------------------------------------------------------

constexpr std::size_t kSpectralBands = 8;
using Spectrum = std::array<double, kSpectralBands>;

struct RenderMaterial {
    std::string id;
    Spectrum spectral_reflectance{0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
    Spectrum spectral_emission{};
    double roughness = 0.45;
    double metallic = 0.0;
    double index_of_refraction = 1.5;
    double opacity = 1.0;
    double lidar_reflectivity = 0.5;
    double radar_cross_section_m2 = 1.0;
    double radar_specularity = 0.5;
    double thermal_emissivity = 0.92;
    double temperature_k = 293.15;
    double retroreflectivity = 0.0;
    double surface_wetness = 0.0;
    double radar_relative_permittivity = 4.0;
    double volumetric_scattering_per_m = 0.0;
};

enum class RenderPrimitiveType { Sphere, AxisAlignedBox, Plane, Triangle };

struct RenderPrimitive {
    std::string id;
    std::string material_id;
    RenderPrimitiveType type = RenderPrimitiveType::Sphere;
    Vector3 position_m{};
    Vector3 velocity_m_s{};
    double radius_m = 0.5;
    Vector3 half_extents_m{0.5, 0.5, 0.5};
    Vector3 plane_normal{0.0, 0.0, 1.0};
    double plane_offset_m = 0.0;
    std::array<Vector3, 3> triangle_vertices{};
};

struct RenderMesh {
    std::string id;
    std::string material_id;
    std::vector<Vector3> vertices;
    std::vector<std::array<std::size_t, 3>> triangles;
    Vector3 velocity_m_s{};
};

struct RayTracingStatistics {
    std::size_t primitive_count = 0;
    std::size_t mesh_count = 0;
    std::size_t mesh_triangle_count = 0;
    std::size_t bounded_primitive_count = 0;
    std::size_t infinite_primitive_count = 0;
    std::size_t bvh_node_count = 0;
    std::size_t bvh_leaf_count = 0;
    std::size_t bvh_maximum_depth = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct SpectralPointLight {
    Vector3 position_m{};
    Spectrum radiant_intensity_w_sr{10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0, 10.0};
};

struct CameraRenderConfiguration {
    std::size_t width = 640;
    std::size_t height = 360;
    double focal_x_px = 520.0;
    double focal_y_px = 520.0;
    double principal_x_px = 320.0;
    double principal_y_px = 180.0;
    Vector3 position_m{};
    Vector3 forward{1.0, 0.0, 0.0};
    Vector3 up{0.0, 0.0, 1.0};
    double exposure_s = 0.008;
    double rolling_shutter_s = 0.0;
    unsigned samples_per_pixel = 1;
    unsigned maximum_bounces = 2;
    double atmospheric_extinction_per_m = 0.0;
    double shot_noise_scale = 0.0;
    double read_noise_std = 0.0;
    std::uint64_t random_seed = 1;
};

struct RenderedImage {
    std::size_t width = 0;
    std::size_t height = 0;
    std::vector<std::array<double, 3>> linear_rgb;
    std::vector<double> depth_m;
    std::vector<std::string> object_id;
    double mean_luminance = 0.0;
    [[nodiscard]] const std::array<double, 3>& pixel(std::size_t x, std::size_t y) const;
    [[nodiscard]] doc::Value to_document() const;
};

struct ThermalImage {
    std::size_t width = 0;
    std::size_t height = 0;
    std::vector<double> apparent_temperature_k;
    std::vector<std::string> object_id;
    [[nodiscard]] double pixel(std::size_t x, std::size_t y) const;
    [[nodiscard]] doc::Value to_document() const;
};

struct LidarRenderConfiguration {
    Vector3 origin_m{};
    std::vector<Vector3> unit_directions;
    double maximum_range_m = 250.0;
    std::size_t maximum_returns = 3;
    double pulse_energy_j = 1.0e-6;
    double receiver_aperture_m2 = 2.0e-4;
    double atmospheric_extinction_per_m = 0.0;
    double range_noise_std_m = 0.0;
    std::uint64_t random_seed = 1;
};

struct LidarReturn {
    std::size_t beam_index = 0;
    std::size_t return_index = 0;
    std::string object_id;
    Vector3 position_m{};
    double range_m = 0.0;
    double intensity = 0.0;
};

struct LidarFrame {
    std::vector<LidarReturn> returns;
    std::size_t beam_count = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct FmcwRadarConfiguration {
    Vector3 position_m{};
    Vector3 boresight{1.0, 0.0, 0.0};
    Vector3 platform_velocity_m_s{};
    double carrier_frequency_hz = 77.0e9;
    double chirp_slope_hz_s = 30.0e12;
    double sample_rate_hz = 10.0e6;
    std::size_t samples_per_chirp = 128;
    std::size_t chirp_count = 32;
    std::size_t receive_antennas = 4;
    double chirp_repetition_s = 60.0e-6;
    double antenna_spacing_m = 0.00195;
    double maximum_range_m = 250.0;
    double atmospheric_extinction_per_m = 0.0;
    bool include_ground_multipath = true;
};

struct RadarTargetTruth {
    std::string object_id;
    double range_m = 0.0;
    double radial_velocity_m_s = 0.0;
    double azimuth_rad = 0.0;
    double received_power = 0.0;
};

struct RadarIqFrame {
    std::size_t samples_per_chirp = 0;
    std::size_t chirp_count = 0;
    std::size_t receive_antennas = 0;
    std::vector<std::complex<double>> iq;
    std::vector<RadarTargetTruth> targets;
    [[nodiscard]] std::complex<double> sample(std::size_t antenna, std::size_t chirp,
                                               std::size_t index) const;
    [[nodiscard]] doc::Value to_document() const;
};

class PhysicallyBasedMultimodalRenderer {
public:
    void clear();
    void add_material(RenderMaterial material);
    void add_primitive(RenderPrimitive primitive);
    void add_mesh(RenderMesh mesh);
    void add_light(SpectralPointLight light);
    void set_environment_spectrum(Spectrum radiance);
    [[nodiscard]] RenderedImage render_camera(const CameraRenderConfiguration& configuration) const;
    [[nodiscard]] ThermalImage render_thermal(const CameraRenderConfiguration& configuration,
                                              double atmospheric_temperature_k = 293.15) const;
    [[nodiscard]] LidarFrame render_lidar(const LidarRenderConfiguration& configuration) const;
    [[nodiscard]] RadarIqFrame render_fmcw_radar(const FmcwRadarConfiguration& configuration) const;
    [[nodiscard]] RayTracingStatistics ray_tracing_statistics() const;
    [[nodiscard]] doc::Value scene_document() const;
private:
    std::map<std::string, RenderMaterial> materials_;
    std::vector<RenderPrimitive> primitives_;
    std::vector<RenderMesh> meshes_;
    std::vector<SpectralPointLight> lights_;
    Spectrum environment_radiance_{0.02, 0.025, 0.03, 0.035, 0.04, 0.045, 0.05, 0.055};
};

// -----------------------------------------------------------------------------
// Heterogeneous multicore automotive SoC
// -----------------------------------------------------------------------------

enum class AutomotiveComputeKind { RiscV32Im, Dsp, Gpu, Npu, SafetyLockstep };
enum class AcceleratorOperation { MemoryCopy, FirFilter, DenseLayer, MatrixMultiply, Crc32 };

struct AutomotiveCoreConfiguration {
    std::string id;
    AutomotiveComputeKind kind = AutomotiveComputeKind::RiscV32Im;
    double clock_hz = 200.0e6;
    std::size_t private_ram_bytes = 256 * 1024;
    std::size_t instruction_cache_bytes = 16 * 1024;
    std::size_t data_cache_bytes = 16 * 1024;
    double dynamic_power_w_per_utilization = 1.0;
    double leakage_power_w = 0.1;
    std::string lockstep_peer;
};

struct AcceleratorJob {
    std::uint64_t id = 0;
    std::string core_id;
    AcceleratorOperation operation = AcceleratorOperation::MemoryCopy;
    std::uint32_t input_a_address = 0;
    std::uint32_t input_b_address = 0;
    std::uint32_t output_address = 0;
    std::size_t element_count = 0;
    std::size_t rows = 0;
    std::size_t columns = 0;
    std::size_t inner_dimension = 0;
    std::vector<double> coefficients;
};

struct AcceleratorCompletion {
    std::uint64_t job_id = 0;
    std::string core_id;
    std::uint64_t start_cycle = 0;
    std::uint64_t finish_cycle = 0;
    std::size_t bytes_read = 0;
    std::size_t bytes_written = 0;
    std::uint32_t crc32 = 0;
};

struct AutomotiveCoreTelemetry {
    std::string id;
    AutomotiveComputeKind kind = AutomotiveComputeKind::RiscV32Im;
    std::uint64_t instructions = 0;
    std::uint64_t active_cycles = 0;
    std::uint64_t cache_misses = 0;
    double utilization = 0.0;
    double power_w = 0.0;
    double temperature_k = 298.15;
    bool halted = false;
};

struct HeterogeneousSoCReport {
    std::uint64_t elapsed_reference_cycles = 0;
    std::vector<AutomotiveCoreTelemetry> cores;
    std::vector<AcceleratorCompletion> completions;
    std::size_t coherence_transactions = 0;
    std::size_t interconnect_bytes = 0;
    bool lockstep_mismatch = false;
    [[nodiscard]] doc::Value to_document() const;
};

class HeterogeneousAutomotiveSoC {
public:
    HeterogeneousAutomotiveSoC(std::size_t shared_memory_bytes = 256 * 1024,
                               std::uint32_t shared_memory_base = 0x00080000U,
                               double reference_clock_hz = 200.0e6);
    ~HeterogeneousAutomotiveSoC();
    HeterogeneousAutomotiveSoC(HeterogeneousAutomotiveSoC&&) noexcept;
    HeterogeneousAutomotiveSoC& operator=(HeterogeneousAutomotiveSoC&&) noexcept;
    HeterogeneousAutomotiveSoC(const HeterogeneousAutomotiveSoC&) = delete;
    HeterogeneousAutomotiveSoC& operator=(const HeterogeneousAutomotiveSoC&) = delete;
    void add_core(AutomotiveCoreConfiguration configuration);
    void load_words(const std::string& core_id, std::uint32_t address,
                    const std::vector<std::uint32_t>& words);
    bool step_core(const std::string& core_id);
    void run_reference_cycles(std::uint64_t cycles);
    std::uint64_t submit_job(AcceleratorJob job);
    void request_external_interrupt(const std::string& core_id, bool pending = true);
    void write_shared8(std::uint32_t address, std::uint8_t value);
    void write_shared32(std::uint32_t address, std::uint32_t value);
    [[nodiscard]] std::uint8_t read_shared8(std::uint32_t address) const;
    [[nodiscard]] std::uint32_t read_shared32(std::uint32_t address) const;
    [[nodiscard]] std::uint32_t register_value(const std::string& core_id, unsigned index) const;
    [[nodiscard]] std::string uart_output(const std::string& core_id) const;
    [[nodiscard]] HeterogeneousSoCReport report() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// -----------------------------------------------------------------------------
// Chemistry-resolved battery and fuel-cell physics
// -----------------------------------------------------------------------------

enum class CellChemistry { Nmc811, Lfp, Nca, Lto, SodiumIon };

struct PorousElectrodeCellConfiguration {
    CellChemistry chemistry = CellChemistry::Nmc811;
    double nominal_capacity_ah = 5.0;
    double electrode_area_m2 = 0.12;
    double negative_thickness_m = 80.0e-6;
    double separator_thickness_m = 20.0e-6;
    double positive_thickness_m = 75.0e-6;
    double particle_radius_negative_m = 5.0e-6;
    double particle_radius_positive_m = 4.0e-6;
    double solid_diffusivity_negative_m2_s = 3.0e-14;
    double solid_diffusivity_positive_m2_s = 2.0e-14;
    double electrolyte_diffusivity_m2_s = 2.5e-10;
    double electrolyte_conductivity_s_m = 1.1;
    double reaction_rate_negative = 2.0e-11;
    double reaction_rate_positive = 1.5e-11;
    double maximum_concentration_negative_mol_m3 = 31000.0;
    double maximum_concentration_positive_mol_m3 = 52000.0;
    double initial_soc = 0.8;
    double initial_electrolyte_concentration_mol_m3 = 1000.0;
    double thermal_mass_j_k = 450.0;
    double thermal_conductance_w_k = 2.0;
    std::size_t negative_nodes = 8;
    std::size_t separator_nodes = 4;
    std::size_t positive_nodes = 8;
};

struct PorousElectrodeCellState {
    double time_s = 0.0;
    double state_of_charge = 0.0;
    double terminal_voltage_v = 0.0;
    double open_circuit_voltage_v = 0.0;
    double temperature_k = 298.15;
    double heat_generation_w = 0.0;
    double capacity_loss_fraction = 0.0;
    double sei_thickness_m = 5.0e-9;
    double plated_lithium_mol = 0.0;
    double lithium_inventory_fraction = 1.0;
    std::vector<double> negative_solid_concentration_mol_m3;
    std::vector<double> electrolyte_concentration_mol_m3;
    std::vector<double> positive_solid_concentration_mol_m3;
    [[nodiscard]] doc::Value to_document() const;
};

class PorousElectrodeCell {
public:
    explicit PorousElectrodeCell(PorousElectrodeCellConfiguration configuration = {});
    void reset(double state_of_charge, double temperature_k = 298.15);
    [[nodiscard]] const PorousElectrodeCellState& step(double current_a, double dt_s,
                                                        double ambient_temperature_k = 298.15,
                                                        double coolant_conductance_w_k = 0.0);
    [[nodiscard]] const PorousElectrodeCellState& state() const noexcept;
    [[nodiscard]] const PorousElectrodeCellConfiguration& configuration() const noexcept;
private:
    PorousElectrodeCellConfiguration configuration_;
    PorousElectrodeCellState state_;
};

struct PemFuelCellConfiguration {
    std::size_t cells = 300;
    double active_area_m2 = 0.025;
    double membrane_thickness_m = 18.0e-6;
    double nominal_hydrogen_pressure_pa = 180000.0;
    double nominal_air_pressure_pa = 160000.0;
    double hydrogen_volume_m3 = 0.008;
    double cathode_volume_m3 = 0.012;
    double thermal_mass_j_k = 12000.0;
    double thermal_conductance_w_k = 90.0;
    double compressor_efficiency = 0.7;
    double initial_membrane_water_content = 12.0;
};

struct PemFuelCellState {
    double time_s = 0.0;
    double stack_voltage_v = 0.0;
    double gross_power_w = 0.0;
    double compressor_power_w = 0.0;
    double net_power_w = 0.0;
    double hydrogen_pressure_pa = 0.0;
    double oxygen_pressure_pa = 0.0;
    double membrane_water_content = 0.0;
    double temperature_k = 353.15;
    double hydrogen_consumed_kg = 0.0;
    double liquid_water_kg = 0.0;
    double catalyst_activity = 1.0;
    [[nodiscard]] doc::Value to_document() const;
};

class PemFuelCellStack {
public:
    explicit PemFuelCellStack(PemFuelCellConfiguration configuration = {});
    void reset(double temperature_k = 353.15);
    [[nodiscard]] const PemFuelCellState& step(double stack_current_a, double dt_s,
                                               double hydrogen_feed_mol_s,
                                               double air_feed_mol_s,
                                               double coolant_temperature_k = 333.15);
    [[nodiscard]] const PemFuelCellState& state() const noexcept;
private:
    PemFuelCellConfiguration configuration_;
    PemFuelCellState state_;
};

// -----------------------------------------------------------------------------
// Grid-aware charging and V2G infrastructure
// -----------------------------------------------------------------------------

struct GridBusDefinition {
    std::string id;
    std::string parent_line_id;
    double nominal_voltage_v = 230.0;
    std::array<std::complex<double>, 3> fixed_power_va{};
};

struct GridLineDefinition {
    std::string id;
    std::string from_bus;
    std::string to_bus;
    std::array<std::complex<double>, 3> impedance_ohm{
        std::complex<double>{0.03, 0.02}, std::complex<double>{0.03, 0.02},
        std::complex<double>{0.03, 0.02}};
    double thermal_limit_a = 200.0;
};

struct ChargingVehicle {
    std::string id;
    std::string bus_id;
    double battery_capacity_kwh = 80.0;
    double energy_kwh = 30.0;
    double target_energy_kwh = 70.0;
    double minimum_reserve_kwh = 15.0;
    double maximum_charge_kw = 11.0;
    double maximum_discharge_kw = 7.0;
    double charge_efficiency = 0.94;
    double discharge_efficiency = 0.92;
    std::size_t departure_slot = 24;
    bool v2g_enabled = true;
};

struct GridTimeSlot {
    double duration_h = 0.25;
    double electricity_price_per_kwh = 0.15;
    double export_price_per_kwh = 0.08;
    double carbon_kg_per_kwh = 0.4;
    std::map<std::string, double> renewable_generation_kw_by_bus;
};

struct GridPowerFlowResult {
    bool converged = false;
    std::size_t iterations = 0;
    std::map<std::string, std::array<std::complex<double>, 3>> bus_voltage_v;
    std::map<std::string, std::array<std::complex<double>, 3>> line_current_a;
    double minimum_voltage_pu = 1.0;
    double maximum_line_loading = 0.0;
    double root_real_power_kw = 0.0;
    double losses_kw = 0.0;
    [[nodiscard]] doc::Value to_document() const;
};

struct ChargingSimulationResult {
    std::vector<GridPowerFlowResult> power_flow;
    std::map<std::string, std::vector<double>> vehicle_power_kw;
    std::map<std::string, double> final_energy_kwh;
    double imported_energy_kwh = 0.0;
    double exported_energy_kwh = 0.0;
    double energy_cost = 0.0;
    double carbon_kg = 0.0;
    double minimum_voltage_pu = 1.0;
    double maximum_line_loading = 0.0;
    std::size_t unmet_departures = 0;
    [[nodiscard]] doc::Value to_document() const;
};

struct GridChargingOptimizationOptions {
    double minimum_voltage_pu = 0.90;
    double maximum_line_loading = 1.0;
    double demand_charge_per_kw = 0.0;
    double battery_degradation_cost_per_kwh = 0.02;
    double carbon_cost_per_kg = 0.0;
    double departure_shortfall_penalty_per_kwh = 1000.0;
    std::size_t refinement_passes = 8;
    bool allow_v2g = true;
};

struct GridChargingOptimizationResult {
    ChargingSimulationResult simulation;
    std::map<std::string, std::vector<double>> optimized_vehicle_power_kw;
    double peak_grid_demand_kw = 0.0;
    double demand_charge = 0.0;
    double degradation_cost = 0.0;
    double carbon_cost = 0.0;
    double departure_shortfall_kwh = 0.0;
    double objective = 0.0;
    bool feasible = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class GridAwareChargingSimulator {
public:
    void clear();
    void add_bus(GridBusDefinition bus);
    void add_line(GridLineDefinition line);
    void add_vehicle(ChargingVehicle vehicle);
    [[nodiscard]] GridPowerFlowResult solve_power_flow(
        const std::map<std::string, double>& charging_power_kw,
        const std::map<std::string, double>& renewable_generation_kw_by_bus = {},
        std::size_t maximum_iterations = 100,
        double tolerance_v = 1.0e-5) const;
    [[nodiscard]] ChargingSimulationResult simulate(const std::vector<GridTimeSlot>& slots,
                                                     double minimum_voltage_pu = 0.90,
                                                     double maximum_line_loading = 1.0);
    [[nodiscard]] GridChargingOptimizationResult optimize_schedule(
        const std::vector<GridTimeSlot>& slots,
        const GridChargingOptimizationOptions& options = {});
private:
    std::map<std::string, GridBusDefinition> buses_;
    std::map<std::string, GridLineDefinition> lines_;
    std::map<std::string, ChargingVehicle> vehicles_;
};

// -----------------------------------------------------------------------------
// Factory and supply-chain discrete-event simulation
// -----------------------------------------------------------------------------

struct SupplyPartDefinition {
    std::string id;
    double initial_inventory = 0.0;
    double unit_cost = 0.0;
    double unit_carbon_kg = 0.0;
};

struct SupplierDefinition {
    std::string id;
    std::string part_id;
    double lead_time_h = 24.0;
    double delivery_batch = 100.0;
    double unit_cost = 0.0;
    double unit_carbon_kg = 0.0;
    double reliability = 0.98;
};

struct FactoryMachineDefinition {
    std::string id;
    std::string capability;
    double process_time_h = 1.0;
    double setup_time_h = 0.0;
    double mtbf_h = 1.0e9;
    double repair_time_h = 0.0;
    double energy_kw = 5.0;
    double scrap_probability = 0.0;
    double rework_probability = 0.0;
};

struct ProductOperation {
    std::string capability;
    double process_time_multiplier = 1.0;
};

struct ProductDefinition {
    std::string id;
    std::map<std::string, double> bill_of_materials;
    std::vector<ProductOperation> route;
    double selling_price = 0.0;
    double shipping_lead_time_h = 0.0;
    double shipping_cost = 0.0;
    double shipping_carbon_kg = 0.0;
};

struct CustomerOrder {
    std::string id;
    std::string product_id;
    std::size_t quantity = 1;
    double release_time_h = 0.0;
    double due_time_h = 0.0;
};

enum class SupplyDisruptionType { SupplierDelay, SupplierOutage, MachineOutage, TransportDelay };

struct SupplyDisruption {
    SupplyDisruptionType type = SupplyDisruptionType::SupplierDelay;
    std::string target_id;
    double start_time_h = 0.0;
    double end_time_h = 0.0;
    double severity = 1.0;
};

struct FactorySimulationResult {
    double simulated_until_h = 0.0;
    std::size_t completed_units = 0;
    std::size_t scrapped_units = 0;
    std::size_t reworked_units = 0;
    std::size_t late_units = 0;
    double service_level = 0.0;
    double average_lead_time_h = 0.0;
    double manufacturing_cost = 0.0;
    double revenue = 0.0;
    double energy_kwh = 0.0;
    double carbon_kg = 0.0;
    std::map<std::string, double> ending_inventory;
    std::map<std::string, double> machine_utilization;
    std::map<std::string, double> order_completion_time_h;
    std::vector<std::string> event_log;
    [[nodiscard]] doc::Value to_document() const;
};

class FactorySupplyChainSimulator {
public:
    explicit FactorySupplyChainSimulator(std::uint64_t random_seed = 1);
    void clear();
    void add_part(SupplyPartDefinition part);
    void add_supplier(SupplierDefinition supplier);
    void add_machine(FactoryMachineDefinition machine);
    void add_product(ProductDefinition product);
    void add_order(CustomerOrder order);
    void add_disruption(SupplyDisruption disruption);
    [[nodiscard]] FactorySimulationResult run(double horizon_h,
                                              std::size_t maximum_events = 100000);
private:
    std::uint64_t random_seed_ = 1;
    std::map<std::string, SupplyPartDefinition> parts_;
    std::vector<SupplierDefinition> suppliers_;
    std::map<std::string, FactoryMachineDefinition> machines_;
    std::map<std::string, ProductDefinition> products_;
    std::vector<CustomerOrder> orders_;
    std::vector<SupplyDisruption> disruptions_;
};

} // namespace aesim::advanced

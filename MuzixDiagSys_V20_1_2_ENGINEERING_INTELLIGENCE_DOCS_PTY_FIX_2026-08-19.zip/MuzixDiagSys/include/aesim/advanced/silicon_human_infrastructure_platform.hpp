#pragma once

#include "aesim/professional/document.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace aesim::advanced {

using SiliconMatrix = std::vector<std::vector<double>>;
using SensorVector3 = std::array<double, 3>;

// Silicon-to-System ECU and SoC Digital Twin
enum class SiliconCoreType { InOrderCpu, OutOfOrderCpu, LockstepCpu, Dsp, Gpu, Npu };
enum class SiliconFaultType { CorrectableBitFlip, UncorrectableBitFlip, CacheWayFailure,
                              InterconnectDrop, TimingViolation, ThermalThrottle, CoreFailure };
struct SiliconCacheConfiguration {
    std::size_t size_bytes = 32768, line_bytes = 64, associativity = 4;
    unsigned hit_cycles = 1, miss_cycles = 20;
    void validate() const;
};
struct SiliconCoreModel {
    std::string id;
    SiliconCoreType type = SiliconCoreType::InOrderCpu;
    double clock_hz = 8.0e8, instructions_per_cycle = 1.0;
    unsigned issue_width = 1, reorder_buffer_entries = 1;
    SiliconCacheConfiguration instruction_cache, data_cache;
    double static_power_w = 0.25, dynamic_energy_j_per_instruction = 2.0e-10;
    double thermal_resistance_k_w = 6.0, thermal_capacitance_j_k = 15.0;
    double throttle_temperature_k = 383.15, shutdown_temperature_k = 423.15;
    void validate() const;
};
struct SiliconMemoryModel {
    std::size_t shared_l2_bytes = 2 * 1024 * 1024, line_bytes = 64;
    unsigned l2_hit_cycles = 14, dram_cycles = 120;
    double dram_bandwidth_bytes_s = 2.0e10, interconnect_bandwidth_bytes_s = 3.2e10;
    double ecc_correctable_rate_per_bit_hour = 1.0e-15, ecc_uncorrectable_rate_per_bit_hour = 1.0e-18;
    void validate() const;
};
struct SiliconTaskModel {
    std::string id, preferred_core;
    std::uint64_t release_ns = 0, period_ns = 1000000, deadline_ns = 1000000;
    std::uint64_t instructions = 1000, instruction_fetches = 1000, data_reads = 100, data_writes = 20;
    std::size_t working_set_bytes = 4096;
    double vector_fraction = 0.0, branch_mispredict_fraction = 0.02;
    unsigned priority = 1;
    bool safety_critical = false;
    void validate() const;
};
struct SiliconFaultEvent {
    SiliconFaultType type = SiliconFaultType::CorrectableBitFlip;
    std::string target_id;
    std::uint64_t activation_ns = 0;
    double severity = 1.0;
    void validate() const;
};
struct SiliconSocConfiguration {
    std::vector<SiliconCoreModel> cores;
    SiliconMemoryModel memory;
    double ambient_temperature_k = 298.15, simulation_duration_s = 0.1, thermal_step_s = 1.0e-4;
    std::size_t maximum_task_instances = 1000000;
    bool deterministic_scheduling = true;
    void validate() const;
};
struct SiliconTaskRecord {
    std::string task_id, core_id;
    std::uint64_t release_ns = 0, start_ns = 0, finish_ns = 0, response_ns = 0;
    bool deadline_missed = false;
};
struct SiliconCoreReport {
    double utilization = 0.0, average_power_w = 0.0, peak_temperature_k = 0.0;
    std::uint64_t instructions = 0, l1_hits = 0, l1_misses = 0, branch_mispredictions = 0, throttle_events = 0;
    bool failed = false;
};
struct SiliconSocResult {
    std::vector<SiliconTaskRecord> task_records;
    std::map<std::string, SiliconCoreReport> cores;
    std::uint64_t l2_hits = 0, l2_misses = 0, dram_bytes = 0, coherence_transactions = 0;
    std::uint64_t correctable_ecc = 0, uncorrectable_ecc = 0;
    std::size_t deadline_misses = 0;
    bool safe_state_entered = false, schedulable = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_records = true) const;
};
class SiliconToSystemDigitalTwin {
public:
    [[nodiscard]] SiliconSocResult simulate(const SiliconSocConfiguration&, const std::vector<SiliconTaskModel>&,
                                            const std::vector<SiliconFaultEvent>& = {}) const;
};

// Formal Controller Synthesis and Fault-Tolerant Control
struct StateSpacePlant {
    SiliconMatrix a, b, c, d;
    double sample_time_s = 0.01;
    void validate() const;
};
struct LqrSynthesisOptions {
    SiliconMatrix q, r;
    std::size_t maximum_iterations = 10000;
    double tolerance = 1.0e-10;
    void validate(std::size_t states, std::size_t inputs) const;
};
struct ControlBarrierConstraint {
    std::vector<double> gradient;
    double lower_derivative = 0.0;
    void validate(std::size_t states) const;
};
struct ActuatorHealth {
    std::string id;
    double effectiveness = 1.0, minimum_command = -1.0e9, maximum_command = 1.0e9;
    bool stuck = false;
    double stuck_command = 0.0;
    void validate() const;
};
struct ControllerCertificate {
    SiliconMatrix feedback_gain, riccati_solution;
    double closed_loop_spectral_radius = 0.0, riccati_residual = 0.0;
    bool stabilizing = false, converged = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct FaultTolerantControlStep {
    std::vector<double> nominal_command, allocated_command, achieved_virtual_control;
    double allocation_residual = 0.0;
    bool barrier_active = false, runtime_assurance_intervened = false;
};
struct FaultTolerantControlResult {
    std::vector<std::vector<double>> state_history;
    std::vector<FaultTolerantControlStep> control_history;
    double maximum_state_norm = 0.0, maximum_allocation_residual = 0.0;
    std::size_t barrier_interventions = 0, runtime_assurance_interventions = 0;
    bool remained_safe = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};
class FormalControllerSynthesisLaboratory {
public:
    [[nodiscard]] ControllerCertificate synthesize_discrete_lqr(const StateSpacePlant&, const LqrSynthesisOptions&) const;
    [[nodiscard]] FaultTolerantControlResult simulate_fault_tolerant_control(
        const StateSpacePlant&, const ControllerCertificate&, const std::vector<double>&,
        const std::vector<ActuatorHealth>&, const SiliconMatrix&, std::size_t,
        const std::vector<ControlBarrierConstraint>& = {}, double state_safety_limit = 1.0e9) const;
};

// Sensor-Device Physics and Differentiable Rendering
struct SensorOpticalMaterial {
    std::string id;
    SensorVector3 visible_reflectance{0.5,0.5,0.5};
    double infrared_emissivity = 0.9, lidar_reflectivity = 0.5, radar_cross_section_m2 = 1.0, roughness = 0.5;
    void validate() const;
};
struct SensorSceneSphere {
    std::string id, material_id;
    SensorVector3 center_m{}, velocity_m_s{};
    double radius_m = 1.0, temperature_k = 293.15;
    void validate() const;
};
struct SensorPose {
    SensorVector3 position_m{}, forward{1.0,0.0,0.0}, up{0.0,0.0,1.0};
    void validate() const;
};
struct CameraDeviceModel {
    std::size_t width = 64, height = 48;
    double horizontal_fov_rad = 1.2, aperture_f_number = 2.8, exposure_s = 0.005;
    double quantum_efficiency = 0.6, full_well_electrons = 30000.0, read_noise_electrons = 2.0;
    double dark_current_electrons_s = 1.0, radial_distortion_k1 = 0.0, radial_distortion_k2 = 0.0;
    bool rolling_shutter = false;
    double row_time_s = 0.0;
    void validate() const;
};
struct LidarDeviceModel {
    std::size_t channels = 16, azimuth_samples = 360;
    double minimum_range_m = 0.5, maximum_range_m = 200.0, range_sigma_m = 0.02;
    double beam_divergence_rad = 0.001, detection_threshold = 0.001;
    void validate() const;
};
struct RadarDeviceModel {
    double carrier_frequency_hz = 77.0e9, bandwidth_hz = 1.0e9, chirp_duration_s = 50.0e-6;
    std::size_t chirps = 64;
    double phase_noise_rad = 0.001, detection_threshold = 1.0e-8;
    void validate() const;
};
struct CameraFrame {
    std::size_t width = 0, height = 0;
    std::vector<SensorVector3> linear_rgb;
    std::vector<std::array<double,6>> pose_jacobian_luminance;
};
struct DeviceLidarReturn {
    std::string object_id;
    SensorVector3 point_m{};
    double range_m = 0.0, intensity = 0.0, time_of_flight_s = 0.0;
};
struct DeviceRadarDetection {
    std::string object_id;
    double range_m = 0.0, radial_velocity_m_s = 0.0, received_power_w = 0.0;
    double beat_frequency_hz = 0.0, doppler_frequency_hz = 0.0;
};
struct SensorRenderingResult {
    CameraFrame camera;
    std::vector<DeviceLidarReturn> lidar;
    std::vector<DeviceRadarDetection> radar;
    double camera_saturation_fraction = 0.0, lidar_detection_fraction = 0.0;
    bool finite_gradients = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_pixels = false) const;
};
class SensorDevicePhysicsRenderer {
public:
    [[nodiscard]] SensorRenderingResult render(const SensorPose&, const CameraDeviceModel&, const LidarDeviceModel&,
        const RadarDeviceModel&, const std::vector<SensorSceneSphere>&,
        const std::map<std::string,SensorOpticalMaterial>&,
        SensorVector3 illumination_direction = {-1.0,-1.0,-1.0}, double illumination_lux = 10000.0,
        std::uint64_t deterministic_seed = 1) const;
};

// Digital Human and Cognitive Workload
struct HumanAnthropometry {
    double mass_kg = 75.0, stature_m = 1.75, age_years = 35.0, neck_strength_scale = 1.0;
    double chest_stiffness_n_m = 30000.0, belt_fit_quality = 1.0;
    void validate() const;
};
struct HumanExcitationSample {
    double time_s = 0.0;
    SensorVector3 vehicle_acceleration_m_s2{}, vehicle_angular_velocity_rad_s{};
    double belt_force_n = 0.0, airbag_force_n = 0.0, visual_motion_rad_s = 0.0;
    double cabin_temperature_k = 295.15, task_demand = 0.0, sleep_debt_h = 0.0;
    void validate() const;
};
struct HumanStateSample {
    double time_s = 0.0;
    SensorVector3 head_acceleration_m_s2{};
    double neck_force_n = 0.0, neck_moment_nm = 0.0, chest_deflection_m = 0.0;
    double hic15 = 0.0, nij = 0.0, chest_injury_index = 0.0;
    double workload = 0.0, fatigue = 0.0, reaction_time_s = 0.0, motion_sickness_incidence = 0.0;
};
struct DigitalHumanResult {
    std::vector<HumanStateSample> history;
    double maximum_hic15 = 0.0, maximum_nij = 0.0, maximum_chest_deflection_m = 0.0;
    double maximum_workload = 0.0, final_fatigue = 0.0, predicted_reaction_time_s = 0.0;
    double motion_sickness_dose = 0.0;
    bool injury_threshold_exceeded = false, cognitive_overload = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};
class DigitalHumanCognitiveLaboratory {
public:
    [[nodiscard]] DigitalHumanResult simulate(const HumanAnthropometry&, const std::vector<HumanExcitationSample>&) const;
};

// Advanced Crash and Post-Crash Safety
struct CrashZoneModel {
    std::string id;
    double crush_stiffness_n_m = 1.0e6, progressive_force_n = 100000.0;
    double maximum_crush_m = 0.3, fracture_energy_j = 10000.0;
    void validate() const;
};
struct CrashVehicleModel {
    double vehicle_mass_kg = 1500.0, initial_speed_m_s = 15.0;
    std::vector<CrashZoneModel> zones;
    double occupant_mass_kg = 75.0, restraint_stiffness_n_m = 20000.0, restraint_damping_n_s_m = 1500.0;
    double pretensioner_time_s = 0.02, load_limiter_force_n = 4500.0;
    double airbag_deployment_time_s = 0.03, airbag_stiffness_n_m = 10000.0;
    double battery_intrusion_threshold_m = 0.08, fuel_leak_threshold_m = 0.2;
    double initial_isolation_resistance_ohm = 1.0e6;
    void validate() const;
};
struct CrashSimulationOptions {
    double duration_s = 0.5, time_step_s = 1.0e-5, barrier_restitution = 0.0, ambient_temperature_k = 298.15;
    void validate() const;
};
struct CrashTimeSample {
    double time_s = 0.0, vehicle_speed_m_s = 0.0, vehicle_acceleration_m_s2 = 0.0;
    double total_crush_m = 0.0, occupant_displacement_m = 0.0, restraint_force_n = 0.0;
    double absorbed_energy_j = 0.0, battery_temperature_k = 0.0, isolation_resistance_ohm = 0.0;
};
struct CrashPostCrashResult {
    std::vector<CrashTimeSample> history;
    double maximum_deceleration_g = 0.0, maximum_crush_m = 0.0, occupant_hic_proxy = 0.0;
    double maximum_restraint_force_n = 0.0, absorbed_energy_j = 0.0, battery_intrusion_m = 0.0;
    bool battery_short_circuit = false, thermal_runaway = false, fuel_or_coolant_leak = false;
    bool high_voltage_isolation_lost = false;
    double estimated_extraction_time_s = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_history = false) const;
};
class AdvancedCrashPostCrashLaboratory {
public:
    [[nodiscard]] CrashPostCrashResult simulate(const CrashVehicleModel&, const CrashSimulationOptions& = {}) const;
};

// Vehicle-to-Grid and Charging Infrastructure
struct InfrastructureBus {
    std::string id;
    double nominal_voltage_v = 400.0, base_load_kw = 0.0, renewable_kw = 0.0;
    double transformer_limit_kw = 1000.0, line_resistance_ohm = 0.01;
    void validate() const;
};
struct InfrastructureCharger {
    std::string id, bus_id;
    double maximum_import_kw = 150.0, maximum_export_kw = 50.0, efficiency = 0.95;
    double power_factor = 0.99, thermal_limit_k = 353.15, connector_resistance_ohm = 0.001;
    void validate() const;
};
struct InfrastructureVehicle {
    std::string id;
    double capacity_kwh = 80.0, energy_kwh = 20.0, target_energy_kwh = 60.0, minimum_reserve_kwh = 10.0;
    double maximum_charge_kw = 150.0, maximum_discharge_kw = 50.0;
    std::size_t arrival_slot = 0, departure_slot = 1;
    bool bidirectional = true;
    double degradation_cost_per_kwh = 0.03;
    void validate() const;
};
struct InfrastructureTimeSlot {
    double duration_h = 0.25, import_price_per_kwh = 0.15, export_price_per_kwh = 0.08;
    double carbon_kg_per_kwh = 0.4, demand_response_kw = 0.0;
    bool grid_available = true;
    void validate() const;
};
struct InfrastructureDispatchSample {
    std::size_t slot = 0;
    std::map<std::string,double> vehicle_power_kw, bus_net_power_kw, bus_voltage_pu;
    double imported_kw = 0.0, exported_kw = 0.0, cost = 0.0, carbon_kg = 0.0;
};
struct VehicleGridResult {
    std::vector<InfrastructureDispatchSample> dispatch;
    std::map<std::string,double> final_energy_kwh;
    double imported_energy_kwh = 0.0, exported_energy_kwh = 0.0, total_cost = 0.0;
    double carbon_kg = 0.0, degradation_cost = 0.0, minimum_voltage_pu = 1.0;
    std::size_t unmet_departures = 0, grid_constraint_interventions = 0;
    bool islanding_supported = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_dispatch = false) const;
};
class VehicleGridChargingInfrastructureLab {
public:
    [[nodiscard]] VehicleGridResult optimize_and_simulate(const std::vector<InfrastructureBus>&,
        const std::vector<InfrastructureCharger>&, const std::vector<InfrastructureVehicle>&,
        const std::vector<InfrastructureTimeSlot>&) const;
};

// Non-Exhaust Emissions
struct NonExhaustVehicleState {
    double speed_m_s = 0.0, longitudinal_acceleration_m_s2 = 0.0, lateral_acceleration_m_s2 = 0.0;
    double vehicle_mass_kg = 1500.0, brake_friction_power_w = 0.0, regenerative_fraction = 0.0;
    double tire_temperature_k = 313.15, road_roughness_m = 0.001, precipitation_mm_h = 0.0, duration_s = 1.0;
    void validate() const;
};
struct NonExhaustMaterialModel {
    double tire_wear_coefficient_kg_j = 1.0e-12, brake_wear_coefficient_kg_j = 5.0e-12;
    double road_wear_coefficient_kg_j = 2.0e-13;
    std::array<double,4> airborne_fraction_by_bin{0.1,0.2,0.3,0.2};
    std::array<double,4> pm_mass_fraction{0.05,0.15,0.30,0.50};
    void validate() const;
};
struct DispersionEnvironment {
    double wind_speed_m_s = 2.0, mixing_height_m = 20.0, road_width_m = 10.0;
    double deposition_velocity_m_s = 0.01, receptor_distance_m = 10.0;
    void validate() const;
};
struct NonExhaustEmissionResult {
    double tire_mass_kg = 0.0, brake_mass_kg = 0.0, road_mass_kg = 0.0;
    std::array<double,4> emitted_mass_by_bin_kg{};
    double pm10_kg = 0.0, pm25_kg = 0.0, airborne_mass_kg = 0.0, deposited_mass_kg = 0.0;
    double runoff_mass_kg = 0.0, receptor_concentration_ug_m3 = 0.0, mass_balance_error_fraction = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
class NonExhaustEmissionsLaboratory {
public:
    [[nodiscard]] NonExhaustEmissionResult simulate(const std::vector<NonExhaustVehicleState>&,
        const NonExhaustMaterialModel&, const DispersionEnvironment&) const;
};

// Circular Economy and Life-Cycle Assessment
enum class LifecycleStage { RawMaterial, Manufacturing, Transport, Use, Maintenance, Reuse, Remanufacture, Recycling, Disposal };
struct LifecycleFlow {
    std::string id;
    LifecycleStage stage = LifecycleStage::RawMaterial;
    double amount = 0.0, co2e_kg_per_unit = 0.0, energy_mj_per_unit = 0.0, water_l_per_unit = 0.0;
    double critical_material_kg_per_unit = 0.0, recycled_content_fraction = 0.0;
    double recovery_fraction = 0.0, uncertainty_fraction = 0.0;
    void validate() const;
};
struct LifecycleScenario {
    double functional_units = 1.0, service_life_km = 200000.0, use_energy_kwh_per_km = 0.18;
    double grid_co2e_kg_per_kwh = 0.35, second_life_credit_fraction = 0.0, avoided_burden_fraction = 0.5;
    std::size_t uncertainty_samples = 512;
    std::uint64_t deterministic_seed = 1;
    void validate() const;
};
struct LifecycleAssessmentResult {
    std::map<LifecycleStage,double> co2e_by_stage_kg;
    double total_co2e_kg = 0.0, total_energy_mj = 0.0, total_water_l = 0.0;
    double critical_material_kg = 0.0, recovered_material_kg = 0.0, circularity_index = 0.0;
    double co2e_p05_kg = 0.0, co2e_p50_kg = 0.0, co2e_p95_kg = 0.0;
    std::map<std::string,double> contribution_fraction;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
class CircularEconomyLifecycleAssessmentLab {
public:
    [[nodiscard]] LifecycleAssessmentResult assess(const std::vector<LifecycleFlow>&, const LifecycleScenario&) const;
};

// Hardware Side-Channel Cybersecurity
enum class PhysicalAttackType { CorrelationPowerAnalysis, TimingAnalysis, ElectromagneticAnalysis, VoltageGlitch, ClockGlitch, LaserFault };
struct CryptographicTrace {
    std::uint8_t plaintext = 0, ciphertext = 0;
    std::vector<double> samples;
    double execution_time_ns = 0.0;
    bool faulted = false;
    void validate(std::size_t expected_samples = 0) const;
};
struct SideChannelExperiment {
    PhysicalAttackType type = PhysicalAttackType::CorrelationPowerAnalysis;
    std::vector<CryptographicTrace> traces;
    std::uint8_t true_key_byte = 0;
    double masking_noise_stddev = 0.0;
    bool constant_time = false, dual_rail_balancing = false;
    double glitch_amplitude_fraction = 0.0, glitch_width_ns = 0.0;
    void validate() const;
};
struct KeyHypothesisScore { std::uint8_t key = 0; double score = 0.0; };
struct SideChannelSecurityResult {
    std::vector<KeyHypothesisScore> ranking;
    std::uint8_t recovered_key = 0;
    std::size_t recovered_key_rank = 256;
    double maximum_correlation = 0.0, timing_t_statistic = 0.0, signal_to_noise_ratio = 0.0;
    double fault_success_fraction = 0.0, estimated_minimum_traces = 0.0;
    bool vulnerable = false;
    std::vector<std::string> findings;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_ranking = false) const;
};
class HardwareSideChannelCybersecurityLab {
public:
    [[nodiscard]] SideChannelSecurityResult analyze(const SideChannelExperiment&) const;
};

// Heterogeneous Solver Compiler and GPU Runtime
enum class KernelOperation { Input, Constant, Add, Subtract, Multiply, Divide, FusedMultiplyAdd, Sin, Cos, Exp, Log, Sqrt, ReduceSum };
enum class ComputeBackend { ScalarCpu, ThreadedCpu, Cuda, Hip, Sycl };
struct KernelNode {
    std::string id;
    KernelOperation operation = KernelOperation::Input;
    std::vector<std::string> inputs;
    double constant = 0.0;
    std::size_t element_count = 0;
    void validate() const;
};
struct ComputeDeviceModel {
    std::string id;
    ComputeBackend backend = ComputeBackend::ScalarCpu;
    double peak_flops = 1.0e9, memory_bandwidth_bytes_s = 1.0e10;
    std::size_t memory_bytes = 1ULL << 30U;
    double launch_latency_s = 1.0e-6, transfer_bandwidth_bytes_s = 1.0e10;
    bool available = true, deterministic_reductions = true;
    void validate() const;
};
struct KernelCompilationOptions {
    bool enable_fusion = true, enable_common_subexpression_elimination = true, mixed_precision = false, deterministic = true;
    std::size_t maximum_nodes = 100000;
    void validate() const;
};
struct CompiledKernelPlan {
    std::vector<KernelNode> ordered_nodes;
    std::map<std::string,std::string> assigned_device;
    std::size_t fused_operations = 0, temporary_bytes = 0;
    double estimated_runtime_s = 0.0;
    bool deterministic = false, valid = false;
    std::string plan_sha256;
    [[nodiscard]] doc::Value to_document() const;
};
struct KernelExecutionResult {
    std::map<std::string,std::vector<double>> outputs, gradients;
    double measured_runtime_s = 0.0, maximum_reference_error = 0.0;
    bool deterministic_replay = false, finite = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document(bool include_outputs = false) const;
};
class HeterogeneousSolverCompilerRuntime {
public:
    [[nodiscard]] CompiledKernelPlan compile(const std::vector<KernelNode>&,
        const std::vector<ComputeDeviceModel>&, const KernelCompilationOptions& = {}) const;
    [[nodiscard]] KernelExecutionResult execute(const CompiledKernelPlan&,
        const std::map<std::string,std::vector<double>>&, const std::vector<std::string>& = {}) const;
};

} // namespace aesim::advanced

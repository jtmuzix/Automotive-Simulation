#pragma once

#include "aesim/professional/document.hpp"
#include "aesim/industrial/signals.hpp"

#include <chrono>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::federation {

// -----------------------------------------------------------------------------
// IEEE 1516-oriented HLA federation and object model
// -----------------------------------------------------------------------------
struct FomAttribute {
    std::string name;
    std::string data_type;
    std::string transportation = "HLAreliable";
    std::string order = "TimeStamp";
};
struct FomObjectClass {
    std::string name;
    std::vector<FomAttribute> attributes;
};
struct FomParameter { std::string name; std::string data_type; };
struct FomInteractionClass {
    std::string name;
    std::vector<FomParameter> parameters;
    std::string transportation = "HLAreliable";
    std::string order = "TimeStamp";
};
struct FomValidationReport {
    bool pass = false;
    std::vector<std::string> errors;
    std::vector<std::string> warnings;
    [[nodiscard]] std::string report() const;
    [[nodiscard]] aesim::doc::Value to_document() const;
};
class HlaFomModel {
public:
    void load_xml(const std::string& path);
    void load_xml_text(const std::string& text);
    [[nodiscard]] std::string to_xml() const;
    [[nodiscard]] FomValidationReport validate() const;
    [[nodiscard]] const std::map<std::string,FomObjectClass>& object_classes() const noexcept { return objects_; }
    [[nodiscard]] const std::map<std::string,FomInteractionClass>& interaction_classes() const noexcept { return interactions_; }
private:
    std::map<std::string,FomObjectClass> objects_;
    std::map<std::string,FomInteractionClass> interactions_;
};

enum class HlaEventKind { AttributeUpdate, Interaction, Synchronization, TimeGrant };
struct HlaEvent {
    HlaEventKind kind = HlaEventKind::AttributeUpdate;
    double logical_time = 0.0;
    std::string class_name;
    std::string instance_name;
    std::map<std::string,aesim::doc::Value> values;
};
struct HlaFederateStatus {
    std::string name;
    double logical_time = 0.0;
    double lookahead = 0.0;
    bool regulating = true;
    bool constrained = true;
    std::uint64_t delivered_events = 0;
};
class HlaFederation {
public:
    void create(std::string federation_name, HlaFomModel model);
    std::uint64_t join(const std::string& federate_name, double lookahead_s = 0.0,
                       bool regulating = true, bool constrained = true);
    void resign(std::uint64_t federate);
    void publish_object(std::uint64_t federate, const std::string& class_name);
    void subscribe_object(std::uint64_t federate, const std::string& class_name);
    void publish_interaction(std::uint64_t federate, const std::string& class_name);
    void subscribe_interaction(std::uint64_t federate, const std::string& class_name);
    std::uint64_t register_object(std::uint64_t federate, const std::string& class_name,
                                  const std::string& instance_name);
    void update_attributes(std::uint64_t federate, std::uint64_t object,
                           const std::map<std::string,aesim::doc::Value>& values,
                           double logical_time);
    void send_interaction(std::uint64_t federate, const std::string& class_name,
                          const std::map<std::string,aesim::doc::Value>& parameters,
                          double logical_time);
    double time_advance_request(std::uint64_t federate, double requested_time);
    void register_sync_point(const std::string& label);
    void achieve_sync_point(std::uint64_t federate, const std::string& label);
    [[nodiscard]] std::vector<HlaEvent> poll(std::uint64_t federate, std::size_t maximum = 1024);
    [[nodiscard]] HlaFederateStatus status(std::uint64_t federate) const;
    [[nodiscard]] std::string report() const;
    void save(const std::string& path) const;
    void restore(const std::string& path);
private:
    struct Federate {
        HlaFederateStatus status;
        std::set<std::string> pub_obj, sub_obj, pub_int, sub_int;
        std::deque<HlaEvent> events;
        double requested = -1.0;
    };
    struct ObjectInstance {
        std::uint64_t owner = 0;
        std::string class_name;
        std::string name;
        std::map<std::string,aesim::doc::Value> values;
    };
    std::string name_;
    HlaFomModel fom_;
    std::map<std::uint64_t,Federate> federates_;
    std::map<std::uint64_t,ObjectInstance> objects_;
    std::map<std::string,std::set<std::uint64_t>> sync_achieved_;
    std::uint64_t next_federate_ = 1;
    std::uint64_t next_object_ = 1;
    void require_federate(std::uint64_t id) const;
};

// -----------------------------------------------------------------------------
// DCP real-time integration
// -----------------------------------------------------------------------------
enum class DcpPduType : std::uint16_t {
    Register=1, Configure=2, Initialize=3, Run=4, Data=5, Stop=6, Reset=7,
    Heartbeat=8, Acknowledge=9, Error=10
};
struct DcpPdu {
    std::uint16_t version = 1;
    DcpPduType type = DcpPduType::Data;
    std::uint32_t sequence = 0;
    std::uint64_t timestamp_ns = 0;
    std::vector<std::uint8_t> payload;
};
class DcpCodec {
public:
    static std::vector<std::uint8_t> encode(const DcpPdu& pdu);
    static DcpPdu decode(const std::vector<std::uint8_t>& bytes);
    static std::vector<std::array<std::uint8_t,8>> encode_can_segments(const DcpPdu& pdu);
    static DcpPdu decode_can_segments(const std::vector<std::array<std::uint8_t,8>>& segments);
};
enum class DcpTransportKind { Udp, TcpClient, TcpServer, Can, SharedMemory };
class DcpTransport {
public:
    DcpTransport();
    ~DcpTransport();
    DcpTransport(const DcpTransport&) = delete;
    DcpTransport& operator=(const DcpTransport&) = delete;
    void open_udp(const std::string& local_address, std::uint16_t local_port,
                  const std::string& remote_address, std::uint16_t remote_port);
    void open_tcp_server(const std::string& address, std::uint16_t port);
    void open_tcp_client(const std::string& address, std::uint16_t port);
    void open_can(const std::string& interface_name, std::uint32_t tx_id, std::uint32_t rx_id);
    void open_shared_memory(const std::string& name, bool endpoint_a, std::size_t capacity = 65536);
    void close();
    void send(const DcpPdu& pdu);
    [[nodiscard]] std::optional<DcpPdu> receive(std::chrono::milliseconds timeout);
    [[nodiscard]] bool open() const noexcept;
    [[nodiscard]] DcpTransportKind kind() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
enum class DcpSlaveState { Unregistered, Registered, Configured, Initialized, Running, Stopped, Error };
class DcpSlave {
public:
    explicit DcpSlave(std::string name = "aesim-dcp-slave");
    DcpPdu handle(const DcpPdu& request);
    void set_inputs(std::vector<double> values);
    void set_parameters(std::vector<double> values);
    [[nodiscard]] const std::vector<double>& outputs() const noexcept;
    [[nodiscard]] DcpSlaveState state() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    std::string name_;
    DcpSlaveState state_ = DcpSlaveState::Unregistered;
    std::vector<double> inputs_, parameters_, outputs_;
    std::uint32_t last_sequence_ = 0;
};

// -----------------------------------------------------------------------------
// FMI Layered Standard BUS-oriented vECU communication
// -----------------------------------------------------------------------------
enum class FmiLsBusType { Can, CanFd, Lin, Ethernet };
struct FmiLsBusFrame {
    FmiLsBusType type = FmiLsBusType::Can;
    std::uint64_t timestamp_ns = 0;
    std::uint32_t identifier = 0;
    std::uint16_t channel = 0;
    bool extended = false;
    bool bitrate_switch = false;
    bool error = false;
    std::vector<std::uint8_t> payload;
};
class FmiLsBusCodec {
public:
    static std::vector<std::uint8_t> encode(const FmiLsBusFrame& frame);
    static FmiLsBusFrame decode(const std::vector<std::uint8_t>& bytes);
    static aesim::doc::Value metadata(const FmiLsBusFrame& frame);
};
class FmiLsVirtualBus {
public:
    explicit FmiLsVirtualBus(double bitrate = 500000.0, double data_bitrate = 2000000.0);
    void attach(const std::string& endpoint);
    void transmit(const std::string& endpoint, FmiLsBusFrame frame);
    void advance(std::uint64_t target_time_ns);
    [[nodiscard]] std::vector<FmiLsBusFrame> receive(const std::string& endpoint);
    [[nodiscard]] std::uint64_t arbitration_losses(const std::string& endpoint) const;
    [[nodiscard]] std::string save_state() const;
    void load_state(const std::string& json);
    [[nodiscard]] std::string status() const;
private:
    struct Pending { std::string endpoint; FmiLsBusFrame frame; std::uint64_t order = 0; };
    double bitrate_, data_bitrate_;
    std::uint64_t now_ns_ = 0, next_order_ = 0;
    std::set<std::string> endpoints_;
    std::vector<Pending> pending_;
    std::map<std::string,std::deque<FmiLsBusFrame>> inbox_;
    std::map<std::string,std::uint64_t> arbitration_losses_;
};

// -----------------------------------------------------------------------------
// QEMU production virtual ECU execution
// -----------------------------------------------------------------------------
enum class VecuArchitecture { Arm, AArch64, RiscV32, RiscV64 };
struct QemuVecuConfig {
    VecuArchitecture architecture = VecuArchitecture::AArch64;
    std::string executable;
    std::string machine = "virt";
    std::string cpu;
    std::string kernel_image;
    std::string disk_image;
    std::string qmp_socket;
    std::vector<std::string> extra_arguments;
    bool enable_kvm = false;
};
class QemuVecu {
public:
    QemuVecu();
    ~QemuVecu();
    QemuVecu(const QemuVecu&) = delete;
    QemuVecu& operator=(const QemuVecu&) = delete;
    void start(const QemuVecuConfig& config, std::chrono::milliseconds timeout = std::chrono::seconds(10));
    void pause();
    void resume();
    void save_snapshot(const std::string& name);
    void load_snapshot(const std::string& name);
    aesim::doc::Value query_status();
    void stop();
    [[nodiscard]] bool running() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

// -----------------------------------------------------------------------------
// Nonlinear/economic MPC with hard real-time fallback
// -----------------------------------------------------------------------------
using MpcVector = std::vector<double>;
using MpcDynamics = std::function<MpcVector(const MpcVector&, const MpcVector&, double)>;
using MpcStageCost = std::function<double(const MpcVector&, const MpcVector&, std::size_t)>;
using MpcTerminalCost = std::function<double(const MpcVector&)>;
struct MpcBounds { MpcVector minimum, maximum; };
struct MpcResult {
    bool converged = false;
    bool used_fallback = false;
    bool deadline_exceeded = false;
    std::size_t iterations = 0;
    double objective = 0.0;
    double solve_time_us = 0.0;
    MpcVector command;
    std::vector<MpcVector> control_trajectory;
    std::vector<MpcVector> state_trajectory;
    std::string diagnostic;
};
class NonlinearEconomicMpc {
public:
    void configure(std::size_t horizon, double step_s, MpcDynamics dynamics,
                   MpcStageCost stage_cost, MpcTerminalCost terminal_cost,
                   MpcBounds control_bounds, MpcVector fallback,
                   std::size_t maximum_iterations = 50, double gradient_tolerance = 1e-5,
                   double initial_step = 0.2);
    MpcResult solve(const MpcVector& state, std::chrono::microseconds deadline);
    void set_warm_start(std::vector<MpcVector> controls);
    [[nodiscard]] std::string status() const;
private:
    std::size_t horizon_ = 0, maximum_iterations_ = 0;
    double step_s_ = 0.0, gradient_tolerance_ = 0.0, initial_step_ = 0.0;
    MpcDynamics dynamics_;
    MpcStageCost stage_cost_;
    MpcTerminalCost terminal_cost_;
    MpcBounds bounds_;
    MpcVector fallback_;
    std::vector<MpcVector> warm_start_;
};

// -----------------------------------------------------------------------------
// Lockstep and redundant-controller execution
// -----------------------------------------------------------------------------
enum class VotePolicy { Exact, Tolerance, Median, WeightedMedian };
struct ReplicaOutput {
    std::string replica;
    bool healthy = true;
    double execution_time_us = 0.0;
    MpcVector values;
    std::string diagnostic;
};
struct LockstepResult {
    bool accepted = false;
    bool degraded = false;
    MpcVector voted;
    std::vector<ReplicaOutput> replicas;
    std::vector<std::string> excluded;
    std::string diagnostic;
};
class RedundantController {
public:
    using Controller = std::function<MpcVector(const MpcVector&)>;
    void add_replica(std::string name, Controller controller, double weight = 1.0);
    void set_policy(VotePolicy policy, double tolerance = 1e-6, std::size_t minimum_quorum = 2);
    void inject_bias(const std::string& replica, MpcVector bias);
    void inject_failure(const std::string& replica, bool fail);
    LockstepResult execute(const MpcVector& input, std::chrono::microseconds deadline);
    [[nodiscard]] std::string status() const;
private:
    struct Replica {
        std::string name;
        Controller controller;
        double weight = 1.0;
        MpcVector bias;
        bool fail = false;
        std::uint64_t calls = 0, errors = 0, excluded = 0;
    };
    std::vector<Replica> replicas_;
    VotePolicy policy_ = VotePolicy::Median;
    double tolerance_ = 1e-6;
    std::size_t minimum_quorum_ = 2;
};

// -----------------------------------------------------------------------------
// Mutation-based release qualification
// -----------------------------------------------------------------------------
enum class MutationOperator { RelationalBoundary, NegateCondition, ArithmeticReplacement,
                              ConstantPerturbation, BooleanReplacement };
struct MutationCase {
    std::string id;
    MutationOperator operation = MutationOperator::RelationalBoundary;
    std::size_t offset = 0;
    std::string original;
    std::string replacement;
    std::string file;
};
struct MutationResult {
    MutationCase mutation;
    bool killed = false;
    bool timed_out = false;
    int exit_code = -1;
    double duration_s = 0.0;
    std::string output;
};
struct MutationReport {
    bool baseline_passed = false;
    int baseline_exit_code = -1;
    double baseline_duration_s = 0.0;
    std::string baseline_output;
    std::vector<MutationResult> results;
    std::size_t killed = 0, survived = 0, timed_out = 0;
    double score = 0.0;
    [[nodiscard]] aesim::doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};
class MutationQualifier {
public:
    std::vector<MutationCase> discover(const std::string& source_path,
                                       const std::set<MutationOperator>& enabled = {}) const;
    MutationReport execute(const std::vector<MutationCase>& mutations,
                           const std::string& command_template,
                           const std::string& output_directory,
                           std::chrono::seconds timeout) const;
};

// -----------------------------------------------------------------------------
// Cloud-native study scheduler and artifact governance
// -----------------------------------------------------------------------------
struct WorkerCapabilities {
    std::string id;
    std::string architecture;
    std::uint32_t cpu_cores = 1;
    std::uint64_t memory_mb = 0;
    std::set<std::string> accelerators;
    std::set<std::string> labels;
};
struct ClaimedTask {
    std::string task_id;
    std::string study_id;
    aesim::doc::Value payload;
    std::uint32_t attempt = 0;
    std::int64_t lease_expires_unix = 0;
};
class StudyControlPlane {
public:
    StudyControlPlane();
    ~StudyControlPlane();
    StudyControlPlane(const StudyControlPlane&) = delete;
    StudyControlPlane& operator=(const StudyControlPlane&) = delete;
    void open(const std::string& sqlite_path, const std::string& artifact_root);
    void close();
    void register_worker(const WorkerCapabilities& worker);
    std::string submit_study(const std::string& name, const std::vector<aesim::doc::Value>& tasks,
                             std::uint32_t maximum_attempts = 3,
                             std::set<std::string> required_labels = {});
    std::optional<ClaimedTask> claim(const std::string& worker_id, std::chrono::seconds lease);
    void heartbeat(const std::string& worker_id, const std::string& task_id,
                   std::chrono::seconds lease);
    void complete(const std::string& worker_id, const std::string& task_id,
                  const aesim::doc::Value& result);
    void fail(const std::string& worker_id, const std::string& task_id,
              const std::string& reason, bool retryable = true);
    std::string store_artifact(const std::string& path, const std::string& media_type,
                               const std::string& owner);
    void approve_artifact(const std::string& sha256, const std::string& reviewer,
                          const std::string& state);
    bool verify_artifact(const std::string& sha256, std::string& error) const;
    [[nodiscard]] aesim::doc::Value study_status(const std::string& study_id) const;
    [[nodiscard]] aesim::doc::Value artifact_record(const std::string& sha256) const;
    [[nodiscard]] std::string status() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};


class StudyControlServer {
public:
    explicit StudyControlServer(StudyControlPlane& control_plane);
    ~StudyControlServer();
    StudyControlServer(const StudyControlServer&) = delete;
    StudyControlServer& operator=(const StudyControlServer&) = delete;
    void start(const std::string& address, std::uint16_t port);
    void stop();
    [[nodiscard]] bool running() const noexcept;
    [[nodiscard]] std::uint16_t port() const noexcept;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
class StudyControlClient {
public:
    static aesim::doc::Value call(const std::string& address, std::uint16_t port,
                                  const aesim::doc::Value& request,
                                  std::chrono::milliseconds timeout = std::chrono::seconds(5));
};

// -----------------------------------------------------------------------------
// Integrated command surface
// -----------------------------------------------------------------------------
class FederationPlatform {
public:
    explicit FederationPlatform(aesim::industrial::SignalRegistry& signals);
    void update(double simulation_time_s);
    [[nodiscard]] std::string command(const std::vector<std::string>& arguments);
    [[nodiscard]] std::string status() const;
private:
    aesim::industrial::SignalRegistry& signals_;
    double time_s_ = 0.0;
    HlaFederation hla_;
    DcpSlave dcp_slave_;
    FmiLsVirtualBus bus_;
    QemuVecu qemu_;
    NonlinearEconomicMpc mpc_;
    RedundantController redundant_;
    MutationQualifier mutation_;
    StudyControlPlane cloud_;
};

} // namespace aesim::federation

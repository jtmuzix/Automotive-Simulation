#pragma once

#include "aesim/high_fidelity/integrated_vehicle.hpp"
#include "aesim/high_fidelity/vehicle_depth.hpp"

#include <array>
#include <optional>
#include <string>

namespace aesim::high_fidelity {

struct IntegratedDepthInput {
    IntegratedVehicleInput base{};
    double world_x_m = 0.0;
    double world_y_m = 0.0;
    double heading_rad = 0.0;
    Vec3d wind_velocity_m_s{};
    double grille_open_fraction = 1.0;
    double spoiler_fraction = 0.0;
    double trailer_articulation_rad = 0.0;
    double brake_pedal_force_n = 0.0;
    // Environmental inputs drive insulation leakage and contamination-sensitive
    // EMI behavior in the high-voltage parasitic network.
    double relative_humidity = 0.5;
    double electrical_contamination_fraction = 0.0;
    double sensor_vibration_rms_m_s2 = 0.0;
    double sensor_radiation_dose_rate_gy_s = 0.0;
    double sensor_supply_voltage_v = 5.0;
    double sensor_electromagnetic_field_v_m = 0.0;
    bool crash_detected = false;
};

struct IntegratedDepthState {
    double time_s = 0.0;
    double world_x_m = 0.0;
    double world_y_m = 0.0;
    double heading_rad = 0.0;
    double total_longitudinal_tire_force_n = 0.0;
    double total_lateral_tire_force_n = 0.0;
    double total_brake_torque_nm = 0.0;
    double aerodynamic_drag_n = 0.0;
    double flexible_body_stress_pa = 0.0;
    double hv_bus_voltage_v = 0.0;
    double hv_dc_link_ripple_v_rms = 0.0;
    double hv_common_mode_current_a = 0.0;
    double motor_bearing_current_a = 0.0;
    double hv_isolation_resistance_ohm = 0.0;
    double conducted_emissions_dbuv = 0.0;
    double radiated_emissions_dbuv_m = 0.0;
    bool emi_limit_exceeded = false;
    double inverter_torque_nm = 0.0;
    double maximum_tire_wear_fraction = 0.0;
    double maximum_tire_damage = 0.0;
    double aggregate_energy_residual_j = 0.0;
    std::uint64_t ecu_deadline_misses = 0;
    std::size_t replay_events = 0;
};

class IntegratedVehicleDepthRuntime {
public:
    IntegratedVehicleDepthRuntime();
    ~IntegratedVehicleDepthRuntime();

    void reset(double ambient_temperature_k = 298.15);
    void set_input(const IntegratedDepthInput& input);
    const IntegratedDepthState& advance(double dt_s);

    void add_terrain_patch(TerrainPatch patch);
    bool remove_terrain_patch(const std::string& id);
    void puncture_tire(std::size_t corner, double leak_area_m2);
    void impact_tire(std::size_t corner, double energy_j, double sidewall_fraction);
    void set_hv_ground_fault(std::size_t node, double resistance_ohm);
    void clear_hv_ground_fault(std::size_t node);
    void set_machine_fault(MachineElectricalFault fault, double magnitude = 0.0);
    void set_brake_leak(std::size_t corner, double leakage_m3_s_pa);
    void inject_ecu_overrun(const std::string& runnable, double multiplier, double duration_s);

    ReplayCheckpoint create_checkpoint(const std::string& id);
    bool restore_checkpoint(const std::string& id);
    bool create_branch(const std::string& name, const std::string& checkpoint_id);
    bool select_branch(const std::string& name);
    bool counterfactual(std::size_t event_index, const std::string& input_name, double value,
                        const std::string& cause);
    bool replay(std::optional<std::size_t> through_event = std::nullopt);
    bool save_replay(const std::string& path) const;
    bool load_replay(const std::string& path);

    bool set_fidelity(FidelityDomain domain, FidelityLevel level);
    void set_automatic_fidelity(bool enabled, double computational_budget);

    [[nodiscard]] const IntegratedDepthInput& input() const noexcept { return input_; }
    [[nodiscard]] const IntegratedDepthState& state() const noexcept { return state_; }
    [[nodiscard]] IntegratedHighFidelityVehicle& base_vehicle() noexcept { return base_; }
    [[nodiscard]] const IntegratedHighFidelityVehicle& base_vehicle() const noexcept { return base_; }
    [[nodiscard]] FlexibleBodyModalSystem& flexible_body() noexcept { return flexible_body_; }
    [[nodiscard]] EnvironmentalTerrain3D& terrain() noexcept { return terrain_; }
    [[nodiscard]] std::array<AdvancedStructuralTire,4>& advanced_tires() noexcept { return tires_; }
    [[nodiscard]] DistributedHighVoltageNetwork& high_voltage() noexcept { return high_voltage_; }
    [[nodiscard]] HighVoltageParasiticsEmiModel& high_voltage_parasitics() noexcept { return high_voltage_parasitics_; }
    [[nodiscard]] SwitchingResolvedElectricDrive& electric_drive() noexcept { return electric_drive_; }
    [[nodiscard]] MultidimensionalAerothermalModel& aerothermal() noexcept { return aerothermal_; }
    [[nodiscard]] DetailedBrakeHydraulicSystem& detailed_brakes() noexcept { return brakes_; }
    [[nodiscard]] AutosarMulticoreRuntime& autosar_runtime() noexcept { return autosar_; }
    [[nodiscard]] CheckpointReplayManager& checkpoint_replay() noexcept { return replay_; }
    [[nodiscard]] MultiFidelityCoordinator& fidelity() noexcept { return fidelity_; }

    [[nodiscard]] const FlexibleBodyModalSystem& flexible_body() const noexcept { return flexible_body_; }
    [[nodiscard]] const EnvironmentalTerrain3D& terrain() const noexcept { return terrain_; }
    [[nodiscard]] const std::array<AdvancedStructuralTire,4>& advanced_tires() const noexcept { return tires_; }
    [[nodiscard]] const DistributedHighVoltageNetwork& high_voltage() const noexcept { return high_voltage_; }
    [[nodiscard]] const HighVoltageParasiticsEmiModel& high_voltage_parasitics() const noexcept { return high_voltage_parasitics_; }
    [[nodiscard]] const SwitchingResolvedElectricDrive& electric_drive() const noexcept { return electric_drive_; }
    [[nodiscard]] const MultidimensionalAerothermalModel& aerothermal() const noexcept { return aerothermal_; }
    [[nodiscard]] const DetailedBrakeHydraulicSystem& detailed_brakes() const noexcept { return brakes_; }
    [[nodiscard]] const AutosarMulticoreRuntime& autosar_runtime() const noexcept { return autosar_; }
    [[nodiscard]] const CheckpointReplayManager& checkpoint_replay() const noexcept { return replay_; }
    [[nodiscard]] const MultiFidelityCoordinator& fidelity() const noexcept { return fidelity_; }

    [[nodiscard]] std::string status() const;
private:
    IntegratedDepthInput input_{};
    IntegratedDepthState state_{};
    double reset_ambient_k_ = 298.15;
    IntegratedHighFidelityVehicle base_;
    FlexibleBodyModalSystem flexible_body_;
    EnvironmentalTerrain3D terrain_;
    std::array<AdvancedStructuralTire,4> tires_{};
    DistributedHighVoltageNetwork high_voltage_;
    HighVoltageParasiticsEmiModel high_voltage_parasitics_;
    SwitchingResolvedElectricDrive electric_drive_;
    MultidimensionalAerothermalModel aerothermal_;
    DetailedBrakeHydraulicSystem brakes_;
    AutosarMulticoreRuntime autosar_;
    CheckpointReplayManager replay_;
    MultiFidelityCoordinator fidelity_;
    std::array<double,4> wheel_speed_rad_s_{};
    std::array<TerrainSample3D,4> terrain_samples_{};
    std::array<double,4> normal_load_n_{{4200.0,4200.0,3900.0,3900.0}};
    std::array<double,4> tire_force_x_n_{};
    std::array<double,4> tire_force_y_n_{};
    double structure_accumulator_s_ = 0.0;
    double tire_accumulator_s_ = 0.0;
    double hv_accumulator_s_ = 0.0;
    double drive_accumulator_s_ = 0.0;
    double brake_accumulator_s_ = 0.0;
    double ecu_accumulator_s_ = 0.0;
    bool replay_execution_ = false;

    void reset_models(double ambient_temperature_k);
    const IntegratedDepthState& advance_internal(double dt_s, bool record_event);
    void configure_fidelity_adapters();
    [[nodiscard]] ReplayFrame replay_frame(double dt_s, const std::string& cause) const;
    void execute_replay_frame(const ReplayFrame& frame);
    [[nodiscard]] std::string capture_replay_state() const;
    void restore_replay_state(const std::string& state_blob);
    [[nodiscard]] double update_period(FidelityDomain domain) const;
    void update_state();
};

[[nodiscard]] FidelityDomain parse_fidelity_domain(const std::string& text);
[[nodiscard]] FidelityLevel parse_fidelity_level(const std::string& text);
[[nodiscard]] MachineElectricalFault parse_machine_fault(const std::string& text);
[[nodiscard]] TerrainSurface parse_terrain_surface(const std::string& text);

} // namespace aesim::high_fidelity

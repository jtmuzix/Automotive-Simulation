#pragma once

#include "aesim/high_fidelity/integrated_depth.hpp"

#include <array>
#include <chrono>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace aesim::high_fidelity {

// -----------------------------------------------------------------------------
// Unified one-dimensional thermo-fluid network.
// -----------------------------------------------------------------------------

enum class FluidKind {
    Air,
    Exhaust,
    Coolant,
    LubricatingOil,
    Gasoline,
    Diesel,
    Hydrogen,
    Refrigerant,
    BrakeFluid
};

struct ThermoFluidProperties {
    double density_kg_m3 = 1.0;
    double specific_heat_j_kg_k = 1000.0;
    double ratio_of_specific_heats = 1.4;
    double dynamic_viscosity_pa_s = 1.8e-5;
    double thermal_conductivity_w_m_k = 0.026;
    double gas_constant_j_kg_k = 287.05;
    double vapor_pressure_pa = 0.0;
    double latent_heat_j_kg = 0.0;
    bool compressible = true;
};

struct ThermoFluidNodeDefinition {
    std::string id;
    FluidKind fluid = FluidKind::Air;
    double volume_m3 = 0.01;
    double initial_pressure_pa = 101325.0;
    double initial_temperature_k = 298.15;
    double initial_vapor_quality = 0.0;
    double wall_temperature_k = 298.15;
    double wall_heat_capacity_j_k = 5000.0;
    double wall_heat_transfer_w_k = 10.0;
    std::map<std::string,double> species_mass_fraction;
    bool fixed_pressure = false;
    bool fixed_temperature = false;
};

struct ThermoFluidBranchDefinition {
    std::string id;
    std::size_t from = 0;
    std::size_t to = 0;
    double length_m = 1.0;
    double hydraulic_diameter_m = 0.02;
    double flow_area_m2 = 3.0e-4;
    double roughness_m = 1.0e-5;
    double minor_loss_coefficient = 0.0;
    double valve_open_fraction = 1.0;
    double pump_pressure_rise_pa = 0.0;
    double compressor_pressure_ratio = 1.0;
    double compressor_efficiency = 0.72;
    double heat_transfer_area_m2 = 0.1;
    double external_temperature_k = 298.15;
    double external_heat_transfer_w_m2_k = 0.0;
    double maximum_mass_flow_kg_s = 100.0;
    bool check_valve = false;
};

struct ThermoFluidBoundaryFlow {
    std::size_t node = 0;
    double mass_flow_kg_s = 0.0; // positive enters the node
    double temperature_k = 298.15;
    std::map<std::string,double> species_mass_fraction;
};

struct ThermoFluidNetworkInput {
    std::vector<ThermoFluidBoundaryFlow> boundaries;
    std::map<std::string,double> valve_open_fraction;
    std::map<std::string,double> pump_pressure_rise_pa;
    std::map<std::string,double> compressor_pressure_ratio;
    std::map<std::string,double> external_temperature_k;
    std::map<std::string,double> external_heat_w;
};

struct ThermoFluidNodeState {
    double pressure_pa = 101325.0;
    double temperature_k = 298.15;
    double mass_kg = 0.0;
    double internal_energy_j = 0.0;
    double vapor_quality = 0.0;
    double wall_temperature_k = 298.15;
    std::map<std::string,double> species_mass_kg;
};

struct ThermoFluidBranchState {
    double mass_flow_kg_s = 0.0;
    double pressure_drop_pa = 0.0;
    double reynolds_number = 0.0;
    double mach_number = 0.0;
    double heat_transfer_w = 0.0;
    double shaft_power_w = 0.0;
    bool choked = false;
    bool cavitating = false;
};

struct ThermoFluidNetworkState {
    double time_s = 0.0;
    std::vector<ThermoFluidNodeState> nodes;
    std::vector<ThermoFluidBranchState> branches;
    double total_mass_kg = 0.0;
    double total_internal_energy_j = 0.0;
    double boundary_mass_integral_kg = 0.0;
    double boundary_energy_integral_j = 0.0;
    double shaft_work_integral_j = 0.0;
    double heat_transfer_integral_j = 0.0;
    double mass_residual_kg = 0.0;
    double energy_residual_j = 0.0;
    std::map<std::string,double> species_residual_kg;
};

class UnifiedThermoFluidNetwork {
public:
    UnifiedThermoFluidNetwork();
    std::size_t add_node(ThermoFluidNodeDefinition definition);
    std::size_t add_branch(ThermoFluidBranchDefinition definition);
    void clear();
    void reset();
    const ThermoFluidNetworkState& step(const ThermoFluidNetworkInput& input, double dt_s);
    [[nodiscard]] const std::vector<ThermoFluidNodeDefinition>& node_definitions() const noexcept;
    [[nodiscard]] const std::vector<ThermoFluidBranchDefinition>& branch_definitions() const noexcept;
    [[nodiscard]] const ThermoFluidNetworkState& state() const noexcept;
    [[nodiscard]] std::optional<std::size_t> node_index(const std::string& id) const;
    [[nodiscard]] std::optional<std::size_t> branch_index(const std::string& id) const;
    [[nodiscard]] std::string report() const;
    static ThermoFluidProperties properties(FluidKind fluid, double temperature_k,
                                            double pressure_pa, double vapor_quality = 0.0);
private:
    std::vector<ThermoFluidNodeDefinition> nodes_;
    std::vector<ThermoFluidBranchDefinition> branches_;
    ThermoFluidNetworkState state_;
    double initial_mass_kg_ = 0.0;
    double initial_energy_j_ = 0.0;
    std::map<std::string,double> initial_species_mass_kg_;
};

// -----------------------------------------------------------------------------
// Cranktrain, valvetrain, and elastohydrodynamic bearing dynamics.
// -----------------------------------------------------------------------------

struct CranktrainConfiguration {
    std::size_t cylinders = 4;
    double bore_m = 0.0825;
    double stroke_m = 0.0928;
    double connecting_rod_m = 0.145;
    double compression_ratio = 10.5;
    double crank_segment_inertia_kg_m2 = 0.012;
    double flywheel_inertia_kg_m2 = 0.18;
    double crank_torsional_stiffness_nm_rad = 18000.0;
    double crank_torsional_damping_nm_s_rad = 12.0;
    double main_bearing_diameter_m = 0.052;
    double main_bearing_length_m = 0.026;
    double main_bearing_radial_clearance_m = 28.0e-6;
    double oil_viscosity_pa_s = 0.012;
    double oil_supply_pressure_pa = 350000.0;
    double cam_base_radius_m = 0.018;
    double maximum_valve_lift_m = 0.0105;
    double valve_mass_kg = 0.095;
    double valve_spring_stiffness_n_m = 42000.0;
    double valve_spring_preload_n = 120.0;
    double valvetrain_damping_n_s_m = 35.0;
    double intake_open_deg = 350.0;
    double intake_close_deg = 590.0;
    double exhaust_open_deg = 130.0;
    double exhaust_close_deg = 370.0;
};

struct CranktrainInput {
    std::vector<double> cylinder_pressure_pa;
    double load_torque_nm = 0.0;
    double starter_torque_nm = 0.0;
    double oil_temperature_k = 373.15;
    double oil_supply_pressure_pa = 350000.0;
    double intake_cam_phase_deg = 0.0;
    double exhaust_cam_phase_deg = 0.0;
};

struct BearingState {
    double load_n = 0.0;
    double eccentricity_ratio = 0.0;
    double minimum_film_thickness_m = 0.0;
    double friction_torque_nm = 0.0;
    double friction_power_w = 0.0;
    double peak_film_pressure_pa = 0.0;
    double sommerfeld_number = 0.0;
    double mixed_lubrication_fraction = 0.0;
    double temperature_k = 373.15;
};

struct ValveState {
    double commanded_lift_m = 0.0;
    double actual_lift_m = 0.0;
    double velocity_m_s = 0.0;
    double acceleration_m_s2 = 0.0;
    double spring_force_n = 0.0;
    double contact_force_n = 0.0;
    bool floating = false;
    bool bouncing = false;
};

struct CranktrainState {
    double time_s = 0.0;
    double crank_angle_deg = 0.0;
    double engine_speed_rad_s = 0.0;
    double indicated_torque_nm = 0.0;
    double delivered_torque_nm = 0.0;
    double bearing_friction_torque_nm = 0.0;
    double torsional_energy_j = 0.0;
    double rotational_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
    double energy_residual_j = 0.0;
    std::vector<double> segment_angle_rad;
    std::vector<double> segment_speed_rad_s;
    std::vector<BearingState> main_bearings;
    std::vector<ValveState> intake_valves;
    std::vector<ValveState> exhaust_valves;
};

class CranktrainValvetrainEhlSystem {
public:
    CranktrainValvetrainEhlSystem();
    explicit CranktrainValvetrainEhlSystem(CranktrainConfiguration configuration);
    void configure(CranktrainConfiguration configuration);
    void reset(double engine_speed_rpm = 900.0, double oil_temperature_k = 373.15);
    const CranktrainState& step(const CranktrainInput& input, double dt_s);
    [[nodiscard]] const CranktrainState& state() const noexcept;
    [[nodiscard]] const CranktrainConfiguration& configuration() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    CranktrainConfiguration configuration_;
    CranktrainState state_;
    double previous_stored_energy_j_ = 0.0;
    double input_work_j_ = 0.0;
    double output_work_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Injection, spray, combustion, and emissions formation.
// -----------------------------------------------------------------------------

enum class FuelChemistry { Gasoline, Diesel, EthanolE85, Hydrogen, Ammonia, SyntheticGasoline };

struct InjectionCombustionConfiguration {
    std::size_t cylinders = 4;
    FuelChemistry fuel = FuelChemistry::Gasoline;
    double rail_volume_m3 = 7.5e-5;
    double rail_bulk_modulus_pa = 1.35e9;
    double rail_target_pressure_pa = 200.0e5;
    double pump_flow_kg_s = 0.012;
    double injector_flow_coefficient = 0.82;
    double injector_orifice_area_m2 = 1.8e-7;
    double injector_needle_mass_kg = 0.0016;
    double injector_needle_stiffness_n_m = 18000.0;
    double injector_needle_damping_n_s_m = 8.0;
    double maximum_needle_lift_m = 70.0e-6;
    double fuel_density_kg_m3 = 745.0;
    double lower_heating_value_j_kg = 43.0e6;
    double stoichiometric_air_fuel_ratio = 14.7;
    double latent_heat_j_kg = 350000.0;
    double evaporation_constant_m2_s = 2.5e-8;
    double wall_film_time_constant_s = 0.18;
    double cylinder_displacement_m3 = 0.0005;
    double compression_ratio = 10.5;
    std::size_t droplet_bins = 8;
};

struct InjectionCombustionInput {
    double engine_speed_rpm = 2000.0;
    double crank_angle_deg = 0.0;
    double requested_fuel_mass_kg_cycle = 1.5e-5;
    double injection_start_deg = 300.0;
    double injection_duration_deg = 45.0;
    double spark_or_ignition_deg = 705.0;
    double intake_pressure_pa = 100000.0;
    double intake_temperature_k = 315.0;
    double exhaust_pressure_pa = 110000.0;
    double oxygen_mass_fraction = 0.232;
    double egr_fraction = 0.0;
    double coolant_temperature_k = 360.0;
    double cylinder_wall_temperature_k = 430.0;
};

struct DropletBinState {
    double mass_kg = 0.0;
    double sauter_mean_diameter_m = 20.0e-6;
    double temperature_k = 300.0;
    double penetration_m = 0.0;
    double evaporated_mass_kg = 0.0;
    double wall_impinged_mass_kg = 0.0;
};

struct CylinderCombustionState {
    double pressure_pa = 101325.0;
    double unburned_temperature_k = 315.0;
    double burned_temperature_k = 315.0;
    double trapped_air_mass_kg = 0.0;
    double vapor_fuel_mass_kg = 0.0;
    double wall_film_mass_kg = 0.0;
    double burned_fraction = 0.0;
    double heat_release_rate_w = 0.0;
    double indicated_torque_nm = 0.0;
    double knock_integral = 0.0;
    double ignition_delay_s = 0.0;
    std::vector<DropletBinState> droplets;
    double nox_kg_s = 0.0;
    double soot_kg_s = 0.0;
    double hc_kg_s = 0.0;
    double co_kg_s = 0.0;
    double co2_kg_s = 0.0;
    double particulate_number_s = 0.0;
};

struct InjectionCombustionState {
    double time_s = 0.0;
    double rail_pressure_pa = 0.0;
    double pump_power_w = 0.0;
    double total_fuel_flow_kg_s = 0.0;
    double total_indicated_torque_nm = 0.0;
    double total_heat_release_w = 0.0;
    double fuel_mass_residual_kg = 0.0;
    double chemical_energy_residual_j = 0.0;
    std::vector<double> needle_lift_m;
    std::vector<double> needle_velocity_m_s;
    std::vector<CylinderCombustionState> cylinders;
};

class DetailedInjectionCombustionSystem {
public:
    DetailedInjectionCombustionSystem();
    explicit DetailedInjectionCombustionSystem(InjectionCombustionConfiguration configuration);
    void configure(InjectionCombustionConfiguration configuration);
    void reset(double rail_pressure_pa = -1.0, double temperature_k = 298.15);
    const InjectionCombustionState& step(const InjectionCombustionInput& input, double dt_s);
    [[nodiscard]] const InjectionCombustionState& state() const noexcept;
    [[nodiscard]] const InjectionCombustionConfiguration& configuration() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    InjectionCombustionConfiguration configuration_;
    InjectionCombustionState state_;
    double injected_fuel_integral_kg_ = 0.0;
    double consumed_fuel_integral_kg_ = 0.0;
    double chemical_input_integral_j_ = 0.0;
    double released_energy_integral_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Transmission, clutch, torque converter, and planetary gearset physics.
// -----------------------------------------------------------------------------

enum class TransmissionArchitecture {
    Manual,
    AutomatedManual,
    DualClutch,
    TorqueConverterAutomatic,
    PlanetaryHybrid,
    ContinuouslyVariable,
    MultiSpeedEaxle
};

enum class HydraulicShiftPhase { Idle, Fill, TorqueTransfer, Inertia, Complete, Fault };

struct HydraulicClutchCircuitConfiguration {
    double piston_area_m2 = 0.0042;
    double piston_return_preload_n = 280.0;
    double piston_return_stiffness_n_m = 1.8e5;
    double piston_maximum_travel_m = 0.0022;
    double clutch_clearance_m = 0.00065;
    double cavity_dead_volume_m3 = 8.0e-6;
    double apply_orifice_area_m2 = 1.4e-6;
    double release_orifice_area_m2 = 1.8e-6;
    double leakage_coefficient_m3_s_pa = 2.0e-14;
    double accumulator_volume_m3 = 9.0e-6;
    double accumulator_precharge_pa = 2.0e5;
    double accumulator_polytropic_exponent = 1.35;
    double maximum_pressure_pa = 2.2e6;
    double plate_pairs = 6.0;
    double effective_friction_radius_m = 0.085;
};

struct TransmissionHydraulicConfiguration {
    bool enabled = true;
    double pump_displacement_m3_rev = 8.5e-6;
    double pump_volumetric_efficiency = 0.86;
    double pump_mechanical_efficiency = 0.82;
    double line_volume_m3 = 1.4e-4;
    double fluid_bulk_modulus_pa = 1.35e9;
    double fluid_density_kg_m3 = 845.0;
    double viscosity_reference_pa_s = 0.032;
    double viscosity_reference_temperature_k = 353.15;
    double viscosity_temperature_coefficient_per_k = 0.026;
    double minimum_line_pressure_pa = 3.5e5;
    double maximum_line_pressure_pa = 2.4e6;
    double pressure_per_input_torque_pa_nm = 1700.0;
    double pressure_per_throttle_pa = 6.0e5;
    double regulator_flow_coefficient_m3_s_pa_sqrt = 1.5e-8;
    double line_leakage_coefficient_m3_s_pa = 2.5e-13;
    double filter_resistance_pa_s_m3 = 2.5e9;
    double solenoid_resistance_ohm = 5.4;
    double solenoid_inductance_h = 0.012;
    double solenoid_force_n_a = 18.0;
    double valve_spool_mass_kg = 0.018;
    double valve_spool_stiffness_n_m = 8200.0;
    double valve_spool_damping_n_s_m = 22.0;
    double valve_spool_maximum_travel_m = 0.0012;
    double valve_pressure_feedback_area_m2 = 8.0e-6;
    double sump_heat_capacity_j_k = 42000.0;
    double cooler_conductance_w_k = 120.0;
    double shift_fill_time_s = 0.070;
    double shift_torque_phase_s = 0.110;
    double shift_inertia_phase_s = 0.180;
    HydraulicClutchCircuitConfiguration primary;
    HydraulicClutchCircuitConfiguration secondary;
    HydraulicClutchCircuitConfiguration lockup{
        0.0032,220.0,1.5e5,0.0018,0.00050,6.0e-6,1.0e-6,1.6e-6,
        1.5e-14,7.0e-6,1.8e5,1.35,2.0e6,5.0,0.090};
};

struct TransmissionConfiguration {
    TransmissionArchitecture architecture = TransmissionArchitecture::TorqueConverterAutomatic;
    std::vector<double> forward_ratios{4.71,3.14,2.11,1.67,1.29,1.0,0.84,0.67};
    double final_drive_ratio = 3.20;
    double input_inertia_kg_m2 = 0.12;
    double output_inertia_kg_m2 = 0.18;
    double shaft_stiffness_nm_rad = 22000.0;
    double shaft_damping_nm_s_rad = 18.0;
    double backlash_rad = 0.0022;
    double clutch_capacity_nm = 650.0;
    double clutch_static_friction = 0.13;
    double clutch_dynamic_friction = 0.10;
    double clutch_heat_capacity_j_k = 18000.0;
    double clutch_cooling_w_k = 90.0;
    double gear_mesh_efficiency = 0.985;
    double oil_temperature_k = 353.15;
    double planetary_sun_teeth = 30.0;
    double planetary_ring_teeth = 78.0;
    double torque_converter_k_factor = 150.0;
    double torque_converter_stall_ratio = 2.05;
    double cvt_min_ratio = 0.42;
    double cvt_max_ratio = 2.45;
    TransmissionHydraulicConfiguration hydraulics;
};

struct TransmissionInput {
    double engine_torque_nm = 0.0;
    double motor_torque_nm = 0.0;
    double engine_speed_rad_s = 0.0;
    double output_speed_rad_s = 0.0;
    int requested_gear = 1;
    double clutch_command = 1.0;
    double secondary_clutch_command = 0.0;
    double lockup_command = 0.0;
    double cvt_ratio_command = 1.0;
    double brake_torque_nm = 0.0;
    double ambient_temperature_k = 298.15;
    double throttle_fraction = 0.0;
    double battery_voltage_v = 13.8;
    // Negative duty requests automatic valve control from the clutch commands.
    double primary_solenoid_duty = -1.0;
    double secondary_solenoid_duty = -1.0;
    double lockup_solenoid_duty = -1.0;
};

struct ClutchState {
    double normal_force_n = 0.0;
    double slip_speed_rad_s = 0.0;
    double transmitted_torque_nm = 0.0;
    double temperature_k = 353.15;
    double wear_fraction = 0.0;
    double friction_energy_j = 0.0;
    bool locked = false;
};

struct HydraulicActuatorState {
    double command = 0.0;
    double solenoid_current_a = 0.0;
    double solenoid_force_n = 0.0;
    double spool_position_m = 0.0;
    double spool_velocity_m_s = 0.0;
    double apply_flow_m3_s = 0.0;
    double release_flow_m3_s = 0.0;
    double leakage_flow_m3_s = 0.0;
    double cavity_pressure_pa = 0.0;
    double accumulator_pressure_pa = 0.0;
    double piston_travel_m = 0.0;
    double fill_fraction = 0.0;
    double clamp_force_n = 0.0;
    double hydraulic_loss_w = 0.0;
};

struct TransmissionState {
    double time_s = 0.0;
    int engaged_gear = 1;
    double effective_ratio = 1.0;
    double input_speed_rad_s = 0.0;
    double output_speed_rad_s = 0.0;
    double output_torque_nm = 0.0;
    double reaction_torque_nm = 0.0;
    double shaft_twist_rad = 0.0;
    double gear_mesh_force_n = 0.0;
    double oil_temperature_k = 353.15;
    double churning_loss_w = 0.0;
    double mesh_loss_w = 0.0;
    double energy_residual_j = 0.0;
    double sun_speed_rad_s = 0.0;
    double ring_speed_rad_s = 0.0;
    double carrier_speed_rad_s = 0.0;
    double pump_flow_m3_s = 0.0;
    double pump_power_w = 0.0;
    double line_pressure_pa = 0.0;
    double regulator_flow_m3_s = 0.0;
    double hydraulic_loss_w = 0.0;
    double hydraulic_energy_residual_j = 0.0;
    HydraulicShiftPhase shift_phase = HydraulicShiftPhase::Idle;
    double shift_phase_time_s = 0.0;
    int pending_gear = 1;
    HydraulicActuatorState primary_hydraulic;
    HydraulicActuatorState secondary_hydraulic;
    HydraulicActuatorState lockup_hydraulic;
    ClutchState primary_clutch;
    ClutchState secondary_clutch;
    ClutchState lockup_clutch;
};

class FullTransmissionSystem {
public:
    FullTransmissionSystem();
    explicit FullTransmissionSystem(TransmissionConfiguration configuration);
    void configure(TransmissionConfiguration configuration);
    void reset(double temperature_k = 353.15);
    const TransmissionState& step(const TransmissionInput& input, double dt_s);
    [[nodiscard]] const TransmissionState& state() const noexcept;
    [[nodiscard]] const TransmissionConfiguration& configuration() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    TransmissionConfiguration configuration_;
    TransmissionState state_;
    double previous_stored_energy_j_ = 0.0;
    double previous_hydraulic_energy_j_ = 0.0;
    double input_work_j_ = 0.0;
    double output_work_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Particle-scale battery aging, gas generation, and thermal propagation.
// -----------------------------------------------------------------------------

struct ParticleBatteryConfiguration {
    std::size_t series_cells = 24;
    std::size_t parallel_cells = 1;
    std::size_t radial_shells = 6;
    double nominal_capacity_ah = 5.0;
    double electrode_particle_radius_m = 5.0e-6;
    double solid_diffusivity_m2_s = 1.0e-14;
    double electrolyte_diffusivity_m2_s = 2.0e-10;
    double exchange_current_density_a_m2 = 3.5;
    double active_area_m2 = 1.8;
    double cell_internal_resistance_ohm = 0.0023;
    double cell_heat_capacity_j_k = 950.0;
    double neighbor_conductance_w_k = 1.2;
    double coolant_conductance_w_k = 2.5;
    double sei_growth_rate_m_s = 2.0e-16;
    double lithium_plating_rate_kg_c = 4.0e-12;
    double gas_generation_mol_c = 1.0e-10;
    double cell_free_volume_m3 = 4.0e-6;
    double vent_pressure_pa = 1.2e6;
    double runaway_onset_k = 423.15;
    double propagation_onset_k = 473.15;
    double runaway_heat_j = 2.5e5;
    double initial_soc = 0.75;
    double initial_temperature_k = 298.15;
};

struct ParticleBatteryInput {
    double pack_current_a = 0.0; // positive discharge
    double coolant_temperature_k = 298.15;
    double ambient_pressure_pa = 101325.0;
    bool balancing_enabled = false;
};

struct ParticleCellState {
    std::vector<double> anode_lithium_fraction;
    std::vector<double> cathode_lithium_fraction;
    double electrolyte_concentration_mol_m3 = 1000.0;
    double terminal_voltage_v = 3.7;
    double temperature_k = 298.15;
    double sei_thickness_m = 5.0e-9;
    double plated_lithium_kg = 0.0;
    double gas_moles = 0.0;
    double internal_pressure_pa = 101325.0;
    double capacity_fraction = 1.0;
    double resistance_scale = 1.0;
    double short_resistance_ohm = 1.0e12;
    double runaway_progress = 0.0;
    bool vented = false;
    bool in_runaway = false;
};

struct ParticleBatteryState {
    double time_s = 0.0;
    double pack_voltage_v = 0.0;
    double pack_power_w = 0.0;
    double average_soc = 0.0;
    double maximum_temperature_k = 0.0;
    double total_gas_moles = 0.0;
    double minimum_capacity_fraction = 1.0;
    double maximum_resistance_scale = 1.0;
    double vented_gas_moles = 0.0;
    double charge_residual_c = 0.0;
    double energy_residual_j = 0.0;
    std::size_t runaway_cells = 0;
    std::vector<ParticleCellState> cells;
};

class ParticleScaleBatteryPack {
public:
    ParticleScaleBatteryPack();
    explicit ParticleScaleBatteryPack(ParticleBatteryConfiguration configuration);
    void configure(ParticleBatteryConfiguration configuration);
    void reset(double soc = -1.0, double temperature_k = -1.0);
    const ParticleBatteryState& step(const ParticleBatteryInput& input, double dt_s);
    void set_internal_short(std::size_t cell, double resistance_ohm);
    void clear_internal_short(std::size_t cell);
    [[nodiscard]] const ParticleBatteryState& state() const noexcept;
    [[nodiscard]] const ParticleBatteryConfiguration& configuration() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    ParticleBatteryConfiguration configuration_;
    ParticleBatteryState state_;
    double initial_lithium_inventory_c_ = 0.0;
    double external_charge_c_ = 0.0;
    double initial_stored_energy_j_ = 0.0;
    double electrical_work_j_ = 0.0;
    double thermal_rejection_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Raw-signal radar, camera, and lidar simulation.
// -----------------------------------------------------------------------------

struct RawSensorTarget {
    std::string id;
    Vec3d position_m{};
    Vec3d velocity_m_s{};
    Vec3d dimensions_m{4.5,1.8,1.5};
    double radar_cross_section_m2 = 10.0;
    double lidar_reflectivity = 0.5;
    std::array<double,3> rgb_reflectance{{0.5,0.5,0.5}};
    double emissive_luminance_cd_m2 = 0.0;
};

struct RadarRawConfiguration {
    double carrier_frequency_hz = 77.0e9;
    double sweep_bandwidth_hz = 1.0e9;
    double chirp_duration_s = 60.0e-6;
    std::size_t samples_per_chirp = 64;
    std::size_t chirps = 32;
    std::size_t receive_channels = 4;
    double transmit_power_w = 0.02;
    double antenna_gain_linear = 100.0;
    double noise_figure_db = 12.0;
    double phase_noise_rad_rms = 0.006;
    std::uint64_t seed = 42;
};

struct RadarDetection {
    double range_m = 0.0;
    double range_rate_m_s = 0.0;
    double azimuth_rad = 0.0;
    double snr_db = 0.0;
};

struct RadarRawState {
    std::vector<std::complex<double>> iq;
    std::vector<double> range_doppler_power;
    std::vector<RadarDetection> detections;
    double thermal_noise_power_w = 0.0;
    std::size_t interference_events = 0;
};

class RawFmcwRadar {
public:
    RawFmcwRadar();
    explicit RawFmcwRadar(RadarRawConfiguration configuration);
    void configure(RadarRawConfiguration configuration);
    void reset();
    const RadarRawState& simulate(const std::vector<RawSensorTarget>& targets,
                                  const Vec3d& ego_velocity_m_s,
                                  double rain_rate_mm_h,
                                  double interference_power_w = 0.0);
    [[nodiscard]] const RadarRawState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    RadarRawConfiguration configuration_;
    RadarRawState state_;
    std::mt19937_64 random_;
};

struct CameraRawConfiguration {
    std::size_t width = 96;
    std::size_t height = 54;
    double horizontal_fov_rad = 1.2;
    double vertical_fov_rad = 0.72;
    double exposure_s = 0.004;
    double line_time_s = 20.0e-6;
    double aperture_f_number = 2.0;
    double quantum_efficiency = 0.48;
    double full_well_electrons = 18000.0;
    double read_noise_electrons = 3.0;
    double dark_current_electrons_s = 1.2;
    double radial_distortion_k1 = -0.12;
    double radial_distortion_k2 = 0.025;
    std::uint64_t seed = 43;
};

struct CameraRawState {
    std::vector<std::uint16_t> bayer12;
    std::vector<double> depth_m;
    double mean_signal_electrons = 0.0;
    double saturation_fraction = 0.0;
    double visibility_scale = 1.0;
};

class RawCameraSensor {
public:
    RawCameraSensor();
    explicit RawCameraSensor(CameraRawConfiguration configuration);
    void configure(CameraRawConfiguration configuration);
    void reset();
    const CameraRawState& simulate(const std::vector<RawSensorTarget>& targets,
                                   double ambient_luminance_lux,
                                   double yaw_rate_rad_s,
                                   double rain_rate_mm_h,
                                   double fog_visibility_m,
                                   double lens_contamination_fraction);
    [[nodiscard]] const CameraRawState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    CameraRawConfiguration configuration_;
    CameraRawState state_;
    std::mt19937_64 random_;
};

struct LidarRawConfiguration {
    std::size_t azimuth_beams = 64;
    std::size_t elevation_beams = 16;
    std::size_t waveform_bins = 256;
    double maximum_range_m = 200.0;
    double pulse_width_s = 4.0e-9;
    double wavelength_m = 905.0e-9;
    double receiver_noise_std = 0.002;
    double detection_threshold = 0.015;
    std::uint64_t seed = 44;
};

struct LidarReturn {
    Vec3d point_m{};
    double intensity = 0.0;
    double range_m = 0.0;
    std::size_t beam_index = 0;
};

struct LidarRawState {
    std::vector<double> waveforms;
    std::vector<LidarReturn> returns;
    double atmospheric_backscatter = 0.0;
    double missed_return_fraction = 0.0;
};

class RawWaveformLidar {
public:
    RawWaveformLidar();
    explicit RawWaveformLidar(LidarRawConfiguration configuration);
    void configure(LidarRawConfiguration configuration);
    void reset();
    const LidarRawState& simulate(const std::vector<RawSensorTarget>& targets,
                                  double rain_rate_mm_h,
                                  double fog_visibility_m,
                                  double window_contamination_fraction);
    [[nodiscard]] const LidarRawState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    LidarRawConfiguration configuration_;
    LidarRawState state_;
    std::mt19937_64 random_;
};

struct RawSensorSuiteState {
    double time_s = 0.0;
    RadarRawState radar;
    CameraRawState camera;
    LidarRawState lidar;
};

class RawSensorSuite {
public:
    RawSensorSuite();
    const RawSensorSuiteState& simulate(const std::vector<RawSensorTarget>& targets,
                                        const Vec3d& ego_velocity_m_s,
                                        double yaw_rate_rad_s,
                                        double ambient_luminance_lux,
                                        double rain_rate_mm_h,
                                        double fog_visibility_m,
                                        double contamination_fraction,
                                        double dt_s);
    [[nodiscard]] RawFmcwRadar& radar() noexcept;
    [[nodiscard]] RawCameraSensor& camera() noexcept;
    [[nodiscard]] RawWaveformLidar& lidar() noexcept;
    [[nodiscard]] const RawSensorSuiteState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    RawFmcwRadar radar_;
    RawCameraSensor camera_;
    RawWaveformLidar lidar_;
    RawSensorSuiteState state_;
};

// -----------------------------------------------------------------------------
// Human driver, HMI, and automation takeover behavior.
// -----------------------------------------------------------------------------

enum class AutomationMode { Manual, Assisted, Automated, TakeoverRequested, MinimumRiskManeuver };
enum class HmiUrgency { None, Advisory, Caution, Warning, Critical };

struct HumanDriverConfiguration {
    double preview_time_s = 1.2;
    double steering_gain = 0.42;
    double steering_natural_frequency_hz = 1.8;
    double steering_damping_ratio = 0.82;
    double pedal_time_constant_s = 0.22;
    double preferred_time_headway_s = 1.6;
    double maximum_acceleration_m_s2 = 2.2;
    double comfortable_deceleration_m_s2 = 3.2;
    double base_reaction_time_s = 0.65;
    double distracted_reaction_multiplier = 2.0;
    double fatigue_accumulation_per_s = 1.0e-4;
    double fatigue_recovery_per_s = 4.0e-4;
    double trust_adaptation_rate = 0.02;
    double takeover_warning_s = 7.0;
    std::uint64_t seed = 45;
};

struct HumanDriverInput {
    double vehicle_speed_m_s = 0.0;
    double target_speed_m_s = 0.0;
    double lane_offset_m = 0.0;
    double lane_heading_error_rad = 0.0;
    double road_curvature_1_m = 0.0;
    double lead_range_m = 1.0e6;
    double lead_speed_m_s = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    bool automation_available = true;
    bool automation_fault = false;
    bool odd_exit_predicted = false;
    bool driver_monitoring_attention = true;
    bool driver_acknowledged = false;
    bool rest_opportunity = false;
};

struct HumanDriverState {
    double time_s = 0.0;
    AutomationMode automation_mode = AutomationMode::Manual;
    HmiUrgency hmi_urgency = HmiUrgency::None;
    double steering_command_rad = 0.0;
    double throttle_command = 0.0;
    double brake_command = 0.0;
    double desired_acceleration_m_s2 = 0.0;
    double attention = 1.0;
    double fatigue = 0.0;
    double trust = 0.5;
    double takeover_time_remaining_s = 0.0;
    double reaction_delay_s = 0.65;
    double hmi_audible_level = 0.0;
    double hmi_haptic_level = 0.0;
    bool hands_on_wheel = true;
    bool takeover_completed = false;
};

class HumanDriverHmiModel {
public:
    HumanDriverHmiModel();
    explicit HumanDriverHmiModel(HumanDriverConfiguration configuration);
    void configure(HumanDriverConfiguration configuration);
    void reset(AutomationMode mode = AutomationMode::Manual);
    void request_mode(AutomationMode mode);
    const HumanDriverState& step(const HumanDriverInput& input, double dt_s);
    [[nodiscard]] const HumanDriverState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    HumanDriverConfiguration configuration_;
    HumanDriverState state_;
    AutomationMode requested_mode_ = AutomationMode::Manual;
    std::deque<std::pair<double,std::array<double,3>>> delayed_commands_;
    std::mt19937_64 random_;
    double steering_velocity_rad_s_ = 0.0;
};

// -----------------------------------------------------------------------------
// Closed-loop traffic, infrastructure, V2X, and formal ODD management.
// -----------------------------------------------------------------------------

enum class TrafficAgentKind { PassengerCar, HeavyTruck, Bus, Motorcycle, Bicycle, Pedestrian };
enum class TrafficSignalState { Red, RedAmber, Green, Amber };

struct TrafficAgent {
    std::string id;
    TrafficAgentKind kind = TrafficAgentKind::PassengerCar;
    double longitudinal_position_m = 0.0;
    double lateral_position_m = 0.0;
    double speed_m_s = 0.0;
    double acceleration_m_s2 = 0.0;
    double desired_speed_m_s = 25.0;
    double desired_headway_s = 1.5;
    double minimum_gap_m = 2.0;
    double maximum_acceleration_m_s2 = 1.8;
    double comfortable_deceleration_m_s2 = 2.5;
    int lane = 0;
    int desired_lane = 0;
    bool connected = true;
};

struct TrafficSignalController {
    std::string id;
    double position_m = 250.0;
    double red_s = 30.0;
    double green_s = 35.0;
    double amber_s = 4.0;
    double offset_s = 0.0;
    TrafficSignalState state = TrafficSignalState::Green;
    double time_to_change_s = 0.0;
};

struct V2xPacket {
    std::string sender;
    std::string receiver;
    std::string type;
    double transmit_time_s = 0.0;
    double delivery_time_s = 0.0;
    std::map<std::string,double> numeric;
    bool authenticated = true;
};

struct OddDefinition {
    double minimum_temperature_k = 253.15;
    double maximum_temperature_k = 323.15;
    double maximum_rain_rate_mm_h = 35.0;
    double minimum_visibility_m = 80.0;
    double maximum_road_grade = 0.12;
    double minimum_friction = 0.35;
    double maximum_speed_m_s = 36.0;
    bool requires_map = true;
    bool requires_v2x = false;
    bool permits_construction_zone = false;
};

struct OddAssessment {
    bool inside = true;
    double boundary_margin = 1.0;
    double predicted_exit_time_s = 1.0e9;
    std::vector<std::string> violated_dimensions;
    bool minimum_risk_maneuver_required = false;
};

struct TrafficWorldInput {
    double ego_position_m = 0.0;
    double ego_lateral_position_m = 0.0;
    double ego_speed_m_s = 0.0;
    double ego_acceleration_m_s2 = 0.0;
    double ambient_temperature_k = 298.15;
    double rain_rate_mm_h = 0.0;
    double visibility_m = 10000.0;
    double road_grade = 0.0;
    double road_friction = 1.0;
    bool map_available = true;
    bool v2x_available = true;
    bool construction_zone = false;
};

struct TrafficWorldState {
    double time_s = 0.0;
    std::vector<TrafficAgent> agents;
    std::vector<TrafficSignalController> signals;
    std::vector<V2xPacket> delivered_packets;
    OddAssessment odd;
    double nearest_lead_range_m = 1.0e6;
    double nearest_lead_speed_m_s = 0.0;
    std::size_t lane_changes = 0;
    std::size_t v2x_delivered = 0;
    std::size_t v2x_dropped = 0;
};

class ClosedLoopTrafficV2xOddWorld {
public:
    ClosedLoopTrafficV2xOddWorld();
    void reset();
    void set_odd(OddDefinition odd);
    void add_agent(TrafficAgent agent);
    bool remove_agent(const std::string& id);
    void add_signal(TrafficSignalController signal);
    void transmit(V2xPacket packet, double distance_m, double obstruction_loss_db = 0.0);
    const TrafficWorldState& step(const TrafficWorldInput& input, double dt_s);
    [[nodiscard]] const TrafficWorldState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    OddDefinition odd_;
    TrafficWorldState state_;
    std::deque<V2xPacket> pending_packets_;
    std::mt19937_64 random_{46};
};

// -----------------------------------------------------------------------------
// Mechanism-based durability, prognostics, and remaining useful life.
// -----------------------------------------------------------------------------

enum class DurabilityMechanism {
    StructuralFatigue,
    ThermomechanicalFatigue,
    BearingFatigue,
    GearPitting,
    BrakeWear,
    TireWear,
    BatteryCapacityFade,
    BatteryResistanceGrowth,
    CatalystAging,
    ConnectorFretting
};

struct DurabilityComponentDefinition {
    std::string id;
    DurabilityMechanism mechanism = DurabilityMechanism::StructuralFatigue;
    double reference_load = 1.0;
    double fatigue_exponent = 5.0;
    double cycles_to_failure_at_reference = 1.0e6;
    double initial_crack_m = 1.0e-5;
    double critical_crack_m = 5.0e-3;
    double paris_c = 1.0e-12;
    double paris_m = 3.0;
    double activation_energy_j_mol = 0.0;
    double reference_temperature_k = 298.15;
    double wear_rate_per_j = 0.0;
    double nominal_life_hours = 5000.0;
};

struct DurabilityLoadSample {
    std::string component_id;
    double alternating_load = 0.0;
    double mean_load = 0.0;
    double temperature_k = 298.15;
    double dissipated_energy_j = 0.0;
    double throughput = 0.0;
};

struct DurabilityComponentState {
    double cumulative_damage = 0.0;
    double crack_length_m = 0.0;
    double wear_fraction = 0.0;
    double health_index = 1.0;
    double remaining_useful_life_h = 0.0;
    double remaining_useful_life_std_h = 0.0;
    double failure_probability = 0.0;
    std::size_t counted_cycles = 0;
    std::vector<double> rainflow_turning_points;
    std::vector<double> rul_particles_h;
};

struct DurabilityPrognosticsState {
    double time_s = 0.0;
    std::map<std::string,DurabilityComponentState> components;
    double minimum_health_index = 1.0;
    double earliest_rul_h = 1.0e9;
    double maximum_failure_probability = 0.0;
};

class MechanismDurabilityPrognostics {
public:
    MechanismDurabilityPrognostics();
    void clear();
    void add_component(DurabilityComponentDefinition definition);
    void reset();
    const DurabilityPrognosticsState& step(const std::vector<DurabilityLoadSample>& loads,
                                            double dt_s);
    [[nodiscard]] const DurabilityPrognosticsState& state() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string,DurabilityComponentDefinition> definitions_;
    DurabilityPrognosticsState state_;
    std::mt19937_64 random_{47};
};

// -----------------------------------------------------------------------------
// FMI/OpenX interoperability and real-time SIL/PIL/HIL execution.
// -----------------------------------------------------------------------------

enum class ExecutionMode { Offline, Sil, Pil, Hil };

struct EcosystemRealtimeTaskDefinition {
    std::string id;
    double period_s = 0.01;
    double deadline_s = 0.01;
    int priority = 1;
    std::function<void(double)> callback;
};

struct RealtimeTaskState {
    std::uint64_t releases = 0;
    std::uint64_t completions = 0;
    std::uint64_t deadline_misses = 0;
    double last_execution_s = 0.0;
    double maximum_execution_s = 0.0;
    double next_release_s = 0.0;
};

struct RealtimeExecutionState {
    double simulation_time_s = 0.0;
    double wall_time_s = 0.0;
    double real_time_factor = 0.0;
    double maximum_jitter_s = 0.0;
    std::uint64_t overruns = 0;
    std::map<std::string,RealtimeTaskState> tasks;
    std::map<std::string,double> analog_inputs;
    std::map<std::string,double> analog_outputs;
    std::deque<std::vector<std::uint8_t>> network_rx;
    std::deque<std::vector<std::uint8_t>> network_tx;
};

class RealtimeSilPilHilExecutor {
public:
    RealtimeSilPilHilExecutor();
    void reset();
    void set_mode(ExecutionMode mode);
    void set_wall_clock_pacing(bool enabled);
    void add_task(EcosystemRealtimeTaskDefinition task);
    void clear_tasks();
    void set_analog_input(const std::string& channel, double value);
    [[nodiscard]] double analog_input(const std::string& channel, double fallback = 0.0) const;
    void set_analog_output(const std::string& channel, double value);
    void push_network_rx(std::vector<std::uint8_t> frame);
    [[nodiscard]] std::optional<std::vector<std::uint8_t>> pop_network_tx();
    const RealtimeExecutionState& step(double dt_s);
    [[nodiscard]] const RealtimeExecutionState& state() const noexcept;
    [[nodiscard]] ExecutionMode mode() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    ExecutionMode mode_ = ExecutionMode::Offline;
    bool wall_clock_pacing_ = false;
    std::vector<EcosystemRealtimeTaskDefinition> tasks_;
    RealtimeExecutionState state_;
    std::chrono::steady_clock::time_point wall_epoch_{};
};

struct InteroperabilitySnapshot {
    double time_s = 0.0;
    std::map<std::string,double> scalars;
    std::vector<TrafficAgent> traffic_agents;
    std::vector<TrafficSignalController> traffic_signals;
    OddAssessment odd;
};

class FmiOpenXInteroperability {
public:
    FmiOpenXInteroperability();
    void reset();
    void register_scalar(const std::string& name, double initial_value,
                         const std::string& unit, bool input);
    void set_scalar(const std::string& name, double value);
    [[nodiscard]] double scalar(const std::string& name) const;
    void set_snapshot(InteroperabilitySnapshot snapshot);
    void export_fmi3_model_description(const std::string& path,
                                       const std::string& model_identifier) const;
    void export_open_drive(const std::string& path, double road_length_m,
                           double lane_width_m, int lanes) const;
    void export_open_scenario(const std::string& path) const;
    void export_open_odd(const std::string& path) const;
    void export_osi_ground_truth(const std::string& path) const;
    void export_open_label(const std::string& path) const;
    void import_open_scenario(const std::string& path);
    [[nodiscard]] const InteroperabilitySnapshot& snapshot() const noexcept;
    [[nodiscard]] std::string report() const;
private:
    struct ScalarRecord {
        double value = 0.0;
        std::string unit;
        bool input = false;
        std::uint32_t value_reference = 0;
    };
    std::map<std::string,ScalarRecord> scalars_;
    InteroperabilitySnapshot snapshot_;
};

// -----------------------------------------------------------------------------
// Fully coupled vehicle-ecosystem runtime.
// -----------------------------------------------------------------------------

struct IntegratedEcosystemInput {
    IntegratedDepthInput vehicle{};
    double target_speed_m_s = 25.0;
    double lane_offset_m = 0.0;
    double lane_heading_error_rad = 0.0;
    double road_curvature_1_m = 0.0;
    double ambient_luminance_lux = 10000.0;
    double rain_rate_mm_h = 0.0;
    double fog_visibility_m = 10000.0;
    double sensor_contamination_fraction = 0.0;
    bool map_available = true;
    bool v2x_available = true;
    bool construction_zone = false;
    bool automation_fault = false;
    bool driver_attention = true;
    bool driver_acknowledged = false;
    bool use_human_driver_commands = true;
};

struct IntegratedEcosystemState {
    double time_s = 0.0;
    IntegratedDepthState vehicle{};
    double fluid_mass_residual_kg = 0.0;
    double fluid_energy_residual_j = 0.0;
    double crank_delivered_torque_nm = 0.0;
    double indicated_torque_nm = 0.0;
    double transmission_output_torque_nm = 0.0;
    double particle_pack_voltage_v = 0.0;
    double battery_maximum_temperature_k = 0.0;
    std::size_t radar_detections = 0;
    std::size_t lidar_returns = 0;
    double camera_saturation_fraction = 0.0;
    AutomationMode automation_mode = AutomationMode::Manual;
    bool inside_odd = true;
    double odd_boundary_margin = 1.0;
    double minimum_health_index = 1.0;
    double earliest_rul_h = 1.0e9;
    double real_time_factor = 0.0;
    std::uint64_t real_time_overruns = 0;
    double aggregate_energy_residual_j = 0.0;
};

class IntegratedVehicleEcosystemRuntime {
public:
    IntegratedVehicleEcosystemRuntime();
    void reset(double ambient_temperature_k = 298.15);
    void set_input(const IntegratedEcosystemInput& input);
    const IntegratedEcosystemState& advance(double dt_s);
    void set_execution_mode(ExecutionMode mode, bool wall_clock_pacing = false);
    void set_driver_mode(AutomationMode mode);
    void add_traffic_agent(TrafficAgent agent);
    void add_traffic_signal(TrafficSignalController signal);
    void set_odd(OddDefinition odd);
    void set_battery_short(std::size_t cell, double resistance_ohm);
    void clear_battery_short(std::size_t cell);
    void export_interoperability_bundle(const std::string& directory) const;

    [[nodiscard]] const IntegratedEcosystemInput& input() const noexcept;
    [[nodiscard]] const IntegratedEcosystemState& state() const noexcept;
    [[nodiscard]] IntegratedVehicleDepthRuntime& vehicle_depth() noexcept;
    [[nodiscard]] UnifiedThermoFluidNetwork& thermo_fluid() noexcept;
    [[nodiscard]] CranktrainValvetrainEhlSystem& cranktrain() noexcept;
    [[nodiscard]] DetailedInjectionCombustionSystem& combustion() noexcept;
    [[nodiscard]] FullTransmissionSystem& transmission() noexcept;
    [[nodiscard]] ParticleScaleBatteryPack& particle_battery() noexcept;
    [[nodiscard]] RawSensorSuite& raw_sensors() noexcept;
    [[nodiscard]] HumanDriverHmiModel& human_driver() noexcept;
    [[nodiscard]] ClosedLoopTrafficV2xOddWorld& traffic_world() noexcept;
    [[nodiscard]] MechanismDurabilityPrognostics& durability() noexcept;
    [[nodiscard]] RealtimeSilPilHilExecutor& realtime() noexcept;
    [[nodiscard]] FmiOpenXInteroperability& interoperability() noexcept;

    [[nodiscard]] const IntegratedVehicleDepthRuntime& vehicle_depth() const noexcept;
    [[nodiscard]] const UnifiedThermoFluidNetwork& thermo_fluid() const noexcept;
    [[nodiscard]] const CranktrainValvetrainEhlSystem& cranktrain() const noexcept;
    [[nodiscard]] const DetailedInjectionCombustionSystem& combustion() const noexcept;
    [[nodiscard]] const FullTransmissionSystem& transmission() const noexcept;
    [[nodiscard]] const ParticleScaleBatteryPack& particle_battery() const noexcept;
    [[nodiscard]] const RawSensorSuite& raw_sensors() const noexcept;
    [[nodiscard]] const HumanDriverHmiModel& human_driver() const noexcept;
    [[nodiscard]] const ClosedLoopTrafficV2xOddWorld& traffic_world() const noexcept;
    [[nodiscard]] const MechanismDurabilityPrognostics& durability() const noexcept;
    [[nodiscard]] const RealtimeSilPilHilExecutor& realtime() const noexcept;
    [[nodiscard]] const FmiOpenXInteroperability& interoperability() const noexcept;
    [[nodiscard]] std::string status() const;
private:
    IntegratedEcosystemInput input_{};
    IntegratedEcosystemState state_{};
    IntegratedVehicleDepthRuntime depth_;
    UnifiedThermoFluidNetwork fluid_;
    CranktrainValvetrainEhlSystem cranktrain_;
    DetailedInjectionCombustionSystem combustion_;
    FullTransmissionSystem transmission_;
    ParticleScaleBatteryPack particle_battery_;
    RawSensorSuite sensors_;
    HumanDriverHmiModel driver_;
    ClosedLoopTrafficV2xOddWorld traffic_;
    MechanismDurabilityPrognostics durability_;
    RealtimeSilPilHilExecutor realtime_;
    FmiOpenXInteroperability interoperability_;
    double engine_crank_angle_deg_ = 0.0;
    double sensor_accumulator_s_ = 0.0;
    double traffic_accumulator_s_ = 0.0;
    double durability_accumulator_s_ = 0.0;
    void configure_default_network();
    void configure_default_durability();
    void configure_realtime_tasks();
    void publish_interoperability_snapshot();
};

[[nodiscard]] FluidKind parse_fluid_kind(const std::string& text);
[[nodiscard]] TransmissionArchitecture parse_transmission_architecture(const std::string& text);
[[nodiscard]] ExecutionMode parse_execution_mode(const std::string& text);
[[nodiscard]] AutomationMode parse_automation_mode(const std::string& text);
[[nodiscard]] std::string to_string(FluidKind value);
[[nodiscard]] std::string to_string(TransmissionArchitecture value);
[[nodiscard]] std::string to_string(ExecutionMode value);
[[nodiscard]] std::string to_string(AutomationMode value);

} // namespace aesim::high_fidelity

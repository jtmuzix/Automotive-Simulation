#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace aesim::high_fidelity {

struct Vec3d {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

// -----------------------------------------------------------------------------
// Flexible-body chassis and component modal dynamics.
// -----------------------------------------------------------------------------

struct FlexibleModeDefinition {
    std::string name;
    double natural_frequency_hz = 20.0;
    double damping_ratio = 0.03;
    double modal_mass_kg = 100.0;
    std::array<double,4> corner_vertical_participation{};
    std::array<double,4> corner_lateral_participation{};
    Vec3d imu_rotation_participation_rad_m{};
    double steering_column_participation_rad_m = 0.0;
    double battery_strain_participation_per_m = 0.0;
    double stress_recovery_pa_per_m = 1.0e8;
    double generalized_force_scale = 1.0;
};

struct FlexibleBodyConfiguration {
    std::vector<FlexibleModeDefinition> modes;
    double nonlinear_stiffness_ratio = 0.08;
    double maximum_modal_displacement_m = 0.08;
    double fatigue_reference_stress_pa = 2.5e8;
    double fatigue_exponent = 5.0;
};

struct FlexibleBodyInput {
    std::array<Vec3d,4> corner_forces_n{};
    Vec3d powertrain_mount_force_n{};
    Vec3d battery_mount_force_n{};
    Vec3d aerodynamic_force_n{};
    Vec3d aerodynamic_moment_nm{};
    double steering_rack_force_n = 0.0;
    double trailer_hitch_vertical_force_n = 0.0;
};

struct FlexibleModeState {
    double displacement_m = 0.0;
    double velocity_m_s = 0.0;
    double acceleration_m_s2 = 0.0;
    double generalized_force_n = 0.0;
    double strain_energy_j = 0.0;
    double kinetic_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
    double recovered_stress_pa = 0.0;
    double fatigue_damage = 0.0;
};

struct FlexibleBodyState {
    double time_s = 0.0;
    std::vector<FlexibleModeState> modes;
    std::array<double,4> corner_vertical_deflection_m{};
    std::array<double,4> corner_lateral_deflection_m{};
    Vec3d imu_rotation_error_rad{};
    double steering_column_twist_rad = 0.0;
    double battery_enclosure_strain = 0.0;
    double maximum_absolute_stress_pa = 0.0;
    double total_mechanical_energy_j = 0.0;
    double total_dissipated_energy_j = 0.0;
    double energy_residual_j = 0.0;
};

class FlexibleBodyModalSystem {
public:
    FlexibleBodyModalSystem();
    explicit FlexibleBodyModalSystem(FlexibleBodyConfiguration configuration);
    void configure(FlexibleBodyConfiguration configuration);
    void reset();
    const FlexibleBodyState& step(const FlexibleBodyInput& input, double dt_s);
    [[nodiscard]] const FlexibleBodyConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] const FlexibleBodyState& state() const noexcept { return state_; }
    void restore_state(const FlexibleBodyState& state);
    [[nodiscard]] std::string report() const;
private:
    FlexibleBodyConfiguration configuration_;
    FlexibleBodyState state_;
};

// -----------------------------------------------------------------------------
// Three-dimensional environmental road and terrain.
// -----------------------------------------------------------------------------

enum class TerrainSurface {
    Asphalt,
    Concrete,
    Cobblestone,
    Gravel,
    Sand,
    Mud,
    Snow,
    Ice,
    Water,
    Soil
};

struct TerrainPatch {
    std::string id;
    double min_x_m = 0.0;
    double max_x_m = 0.0;
    double min_y_m = 0.0;
    double max_y_m = 0.0;
    TerrainSurface surface = TerrainSurface::Asphalt;
    double height_offset_m = 0.0;
    double friction_scale = 1.0;
    double roughness_rms_m = 0.0;
    double water_depth_m = 0.0;
    double snow_depth_m = 0.0;
    double loose_depth_m = 0.0;
    double soil_cohesion_pa = 0.0;
    double soil_internal_friction_rad = 0.0;
    double temperature_k = 293.15;
};

struct TerrainConfiguration {
    std::uint64_t seed = 0xA3519D7ULL;
    double base_height_m = 0.0;
    double base_friction = 1.0;
    double base_roughness_rms_m = 0.002;
    double longitudinal_grade_rad = 0.0;
    double lateral_crown_rad = 0.0;
    double harmonic_wavelength_m = 18.0;
    double harmonic_amplitude_m = 0.006;
    double ambient_temperature_k = 293.15;
    double rainfall_rate_mm_h = 0.0;
    double snowfall_rate_mm_h = 0.0;
    double drainage_time_constant_s = 240.0;
    double snow_melt_rate_m_s_k = 2.0e-7;
};

struct TerrainSample3D {
    Vec3d position_m{};
    Vec3d normal{0.0,0.0,1.0};
    TerrainSurface surface = TerrainSurface::Asphalt;
    double friction = 1.0;
    double roughness_rms_m = 0.0;
    double water_depth_m = 0.0;
    double snow_depth_m = 0.0;
    double loose_depth_m = 0.0;
    double soil_sinkage_m = 0.0;
    double soil_compaction = 0.0;
    double temperature_k = 293.15;
};

class EnvironmentalTerrain3D {
public:
    EnvironmentalTerrain3D();
    explicit EnvironmentalTerrain3D(TerrainConfiguration configuration);
    void configure(const TerrainConfiguration& configuration);
    void reset();
    void add_patch(TerrainPatch patch);
    bool remove_patch(const std::string& id);
    void clear_patches();
    bool load_height_grid_csv(const std::string& path, double origin_x_m,
                              double origin_y_m, double spacing_m);
    void advance_weather(double dt_s);
    [[nodiscard]] TerrainSample3D sample(double x_m, double y_m,
                                         double normal_load_n = 0.0) const;
    [[nodiscard]] std::vector<TerrainSample3D> contact_strip(double x_m, double y_m,
                                                              double heading_rad,
                                                              double half_length_m,
                                                              std::size_t samples,
                                                              double normal_load_n) const;
    [[nodiscard]] const TerrainConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] std::string report() const;
private:
    TerrainConfiguration configuration_;
    std::vector<TerrainPatch> patches_;
    std::vector<double> grid_height_m_;
    std::size_t grid_rows_ = 0;
    std::size_t grid_columns_ = 0;
    double grid_origin_x_m_ = 0.0;
    double grid_origin_y_m_ = 0.0;
    double grid_spacing_m_ = 1.0;
    double accumulated_water_m_ = 0.0;
    double accumulated_snow_m_ = 0.0;
    [[nodiscard]] double procedural_height(double x_m, double y_m) const;
    [[nodiscard]] double grid_height(double x_m, double y_m) const;
};

// -----------------------------------------------------------------------------
// Advanced structural tire, inflation, wear, and failure.
// -----------------------------------------------------------------------------

enum class TireFailureState {
    Healthy,
    UnderInflated,
    Punctured,
    RunFlat,
    BeltSeparation,
    Blowout
};

struct AdvancedTireConfiguration {
    double unloaded_radius_m = 0.335;
    double width_m = 0.235;
    double contained_air_volume_m3 = 0.032;
    double gas_mass_kg = 0.11;
    double gas_constant_j_kg_k = 287.05;
    double nominal_pressure_pa = 240000.0;
    double belt_radial_stiffness_n_m = 2.6e6;
    double sidewall_stiffness_n_m = 310000.0;
    double belt_damping_n_s_m = 14500.0;
    double sidewall_damping_n_s_m = 5200.0;
    double longitudinal_stiffness_n = 120000.0;
    double lateral_stiffness_n_rad = 95000.0;
    double camber_stiffness_n_rad = 12000.0;
    double pneumatic_trail_m = 0.052;
    double rolling_resistance = 0.011;
    double initial_tread_depth_m = 0.008;
    double legal_tread_depth_m = 0.0016;
    double wear_energy_j_per_m3 = 3.4e11;
    double carcass_heat_capacity_j_k = 19500.0;
    double tread_heat_capacity_j_k = 10500.0;
    double air_heat_capacity_j_k = 115.0;
    double tread_to_carcass_w_k = 170.0;
    double carcass_to_air_w_k = 35.0;
    double carcass_to_ambient_w_k = 48.0;
    double puncture_leak_area_m2 = 0.0;
    double belt_damage_energy_j = 4.0e6;
    double sidewall_damage_energy_j = 2.0e6;
    double blowout_pressure_pa = 85000.0;
    double maximum_pressure_pa = 420000.0;
    bool run_flat_capable = false;
};

struct AdvancedTireInput {
    TerrainSample3D terrain{};
    double normal_load_n = 4000.0;
    double wheel_angular_speed_rad_s = 0.0;
    double hub_longitudinal_speed_m_s = 0.0;
    double hub_lateral_speed_m_s = 0.0;
    double camber_rad = 0.0;
    double drive_torque_nm = 0.0;
    double brake_torque_nm = 0.0;
    double ambient_temperature_k = 298.15;
    double external_heat_w = 0.0;
};

struct AdvancedTireState {
    double time_s = 0.0;
    double pressure_pa = 240000.0;
    double air_temperature_k = 298.15;
    double tread_temperature_k = 298.15;
    double carcass_temperature_k = 298.15;
    double belt_deflection_m = 0.0;
    double belt_velocity_m_s = 0.0;
    double sidewall_deflection_m = 0.0;
    double sidewall_velocity_m_s = 0.0;
    double slip_ratio = 0.0;
    double slip_angle_rad = 0.0;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double rolling_resistance_force_n = 0.0;
    double effective_radius_m = 0.335;
    double tread_depth_m = 0.008;
    double wear_fraction = 0.0;
    double belt_damage = 0.0;
    double sidewall_damage = 0.0;
    double leak_mass_flow_kg_s = 0.0;
    double dissipated_energy_j = 0.0;
    double stored_energy_j = 0.0;
    double energy_residual_j = 0.0;
    TireFailureState failure = TireFailureState::Healthy;
    bool hydroplaning = false;
};

class AdvancedStructuralTire {
public:
    AdvancedStructuralTire();
    explicit AdvancedStructuralTire(AdvancedTireConfiguration configuration);
    void configure(const AdvancedTireConfiguration& configuration);
    void reset(double ambient_temperature_k = 298.15);
    void puncture(double leak_area_m2);
    void repair_puncture();
    void apply_impact(double energy_j, double sidewall_fraction);
    const AdvancedTireState& step(const AdvancedTireInput& input, double dt_s);
    [[nodiscard]] const AdvancedTireState& state() const noexcept { return state_; }
    void restore_state(const AdvancedTireState& state);
    [[nodiscard]] std::string report() const;
private:
    AdvancedTireConfiguration configuration_;
    AdvancedTireState state_;
    double gas_mass_kg_ = 0.11;
};

// -----------------------------------------------------------------------------
// Distributed high-voltage electrical network and protection transients.
// -----------------------------------------------------------------------------

enum class ProtectionState { Closed, Open, Tripped, Welded };

struct HighVoltageNodeDefinition {
    std::string name;
    double capacitance_f = 0.001;
    double initial_voltage_v = 0.0;
    double leakage_resistance_ohm = 1.0e7;
};

struct HighVoltageBranchDefinition {
    std::string name;
    std::size_t from = 0;
    std::size_t to = 0;
    double resistance_ohm = 0.005;
    double inductance_h = 5.0e-6;
    double current_limit_a = 1000.0;
    double fuse_i2t_a2_s = 2.5e6;
    double pyrofuse_trigger_delay_s = 0.002;
    bool contactor = false;
    bool pyrofuse = false;
};

struct HighVoltageLoad {
    std::size_t node = 0;
    double requested_power_w = 0.0;
    double minimum_voltage_v = 50.0;
    double maximum_current_a = 1000.0;
    bool enabled = true;
};

struct HighVoltageNetworkInput {
    double source_voltage_v = 400.0;
    double source_resistance_ohm = 0.02;
    std::size_t source_node = 0;
    std::vector<HighVoltageLoad> loads;
    bool crash_detected = false;
    double ambient_temperature_k = 298.15;
};

struct HighVoltageBranchState {
    double current_a = 0.0;
    double temperature_k = 298.15;
    double fuse_i2t_a2_s = 0.0;
    double arc_energy_j = 0.0;
    ProtectionState protection = ProtectionState::Closed;
};

struct HighVoltageNetworkState {
    double time_s = 0.0;
    std::vector<double> node_voltage_v;
    std::vector<HighVoltageBranchState> branches;
    double source_current_a = 0.0;
    double delivered_load_power_w = 0.0;
    double resistive_loss_w = 0.0;
    double stored_electrical_energy_j = 0.0;
    double protection_dissipated_energy_j = 0.0;
    double isolation_resistance_ohm = 1.0e9;
    double energy_residual_j = 0.0;
    bool pyrofuse_fired = false;
    bool undervoltage = false;
    bool overcurrent = false;
};

class DistributedHighVoltageNetwork {
public:
    DistributedHighVoltageNetwork();
    void configure(std::vector<HighVoltageNodeDefinition> nodes,
                   std::vector<HighVoltageBranchDefinition> branches);
    void configure_default_dual_inverter_network();
    void reset(double source_voltage_v = 400.0, double ambient_temperature_k = 298.15);
    void set_branch_protection(std::size_t branch, ProtectionState state);
    void weld_contactor(std::size_t branch);
    void apply_ground_fault(std::size_t node, double resistance_ohm);
    void clear_ground_fault(std::size_t node);
    const HighVoltageNetworkState& step(const HighVoltageNetworkInput& input, double dt_s);
    [[nodiscard]] const HighVoltageNetworkState& state() const noexcept { return state_; }
    void restore_state(const HighVoltageNetworkState& state);
    [[nodiscard]] std::string report() const;
private:
    std::vector<HighVoltageNodeDefinition> nodes_;
    std::vector<HighVoltageBranchDefinition> branches_;
    HighVoltageNetworkState state_;
    std::map<std::size_t,double> ground_fault_ohm_;
    double crash_timer_s_ = 0.0;
};

// -----------------------------------------------------------------------------
// Switching-resolved inverter and electromagnetic machine.
// -----------------------------------------------------------------------------

enum class MachineElectricalFault { None, PhaseAOpen, PhaseBOpen, PhaseCOpen, PhaseShort, ResolverBias };

struct SwitchingMachineConfiguration {
    double phase_resistance_ohm = 0.018;
    double d_axis_inductance_h = 0.00024;
    double q_axis_inductance_h = 0.00034;
    double permanent_magnet_flux_wb = 0.115;
    int pole_pairs = 4;
    double rotor_inertia_kg_m2 = 0.18;
    double viscous_friction_nm_s = 0.01;
    double switching_frequency_hz = 10000.0;
    double current_controller_kp = 1.8;
    double current_controller_ki = 650.0;
    double maximum_phase_current_a = 600.0;
    double maximum_modulation = 0.94;
    double semiconductor_on_resistance_ohm = 0.0018;
    double switching_energy_j_per_a_v = 2.5e-8;
    double thermal_capacity_j_k = 42000.0;
    double thermal_conductance_w_k = 650.0;
    double dc_link_capacitance_f = 0.0015;
};

struct SwitchingMachineInput {
    double dc_bus_voltage_v = 400.0;
    double requested_torque_nm = 0.0;
    double load_torque_nm = 0.0;
    double ambient_temperature_k = 298.15;
    bool speed_imposed = false;
    double imposed_speed_rad_s = 0.0;
};

struct SwitchingMachineState {
    double time_s = 0.0;
    std::array<double,3> phase_current_a{};
    std::array<double,3> phase_voltage_v{};
    std::array<double,3> duty_cycle{{0.5,0.5,0.5}};
    std::array<bool,6> switch_gate{};
    double d_axis_current_a = 0.0;
    double q_axis_current_a = 0.0;
    double rotor_electrical_angle_rad = 0.0;
    double rotor_speed_rad_s = 0.0;
    double electromagnetic_torque_nm = 0.0;
    double dc_bus_current_a = 0.0;
    double copper_loss_w = 0.0;
    double switching_loss_w = 0.0;
    double conduction_loss_w = 0.0;
    double inverter_temperature_k = 298.15;
    double stored_magnetic_energy_j = 0.0;
    double stored_kinetic_energy_j = 0.0;
    double energy_residual_j = 0.0;
    double current_total_harmonic_distortion = 0.0;
    std::uint64_t switching_events = 0;
    MachineElectricalFault fault = MachineElectricalFault::None;
};

class SwitchingResolvedElectricDrive {
public:
    SwitchingResolvedElectricDrive();
    explicit SwitchingResolvedElectricDrive(SwitchingMachineConfiguration configuration);
    void configure(const SwitchingMachineConfiguration& configuration);
    void reset(double temperature_k = 298.15);
    void set_fault(MachineElectricalFault fault, double magnitude = 0.0);
    const SwitchingMachineState& step(const SwitchingMachineInput& input, double dt_s);
    [[nodiscard]] const SwitchingMachineState& state() const noexcept { return state_; }
    void restore_state(const SwitchingMachineState& state);
    [[nodiscard]] std::string report() const;
private:
    SwitchingMachineConfiguration configuration_;
    SwitchingMachineState state_;
    double d_integrator_v_ = 0.0;
    double q_integrator_v_ = 0.0;
    double carrier_phase_ = 0.0;
    double fault_magnitude_ = 0.0;
};

// -----------------------------------------------------------------------------
// High-voltage parasitics and EMI/EMC prediction.
// -----------------------------------------------------------------------------

struct HighVoltageParasiticsConfiguration {
    double source_resistance_ohm = 0.018;
    double source_inductance_h = 2.0e-6;
    double dc_link_capacitance_f = 0.0015;
    double dc_link_esr_ohm = 0.003;
    double dc_link_esl_h = 35.0e-9;
    double differential_cable_resistance_ohm = 0.006;
    double differential_cable_inductance_h = 1.2e-6;
    double common_mode_capacitance_f = 3.0e-9;
    double chassis_return_resistance_ohm = 0.08;
    double chassis_return_inductance_h = 0.8e-6;
    double nominal_isolation_resistance_ohm = 5.0e7;
    double motor_bearing_capacitance_f = 120.0e-12;
    double motor_bearing_resistance_ohm = 2.0e6;
    double gate_rise_time_s = 80.0e-9;
    double gate_fall_time_s = 100.0e-9;
    double switching_frequency_hz = 10000.0;
    double cable_length_m = 2.5;
    double cable_loop_area_m2 = 0.012;
    double shield_transfer_impedance_ohm_m = 0.012;
    double shield_effectiveness_db = 45.0;
    double lisn_impedance_ohm = 50.0;
    double radiated_measurement_distance_m = 3.0;
    double maximum_conducted_dbuv = 90.0;
    double maximum_radiated_dbuv_m = 54.0;
    std::size_t harmonic_count = 32;
};

struct HighVoltageParasiticsInput {
    double source_voltage_v = 400.0;
    double inverter_dc_current_a = 0.0;
    std::array<double,3> phase_current_a{};
    std::array<double,3> phase_voltage_v{};
    std::array<double,3> duty_cycle{{0.5,0.5,0.5}};
    std::array<bool,6> switch_gate{};
    double switching_frequency_hz = 0.0; // <=0 uses the configured frequency.
    double motor_electrical_speed_rad_s = 0.0;
    double ambient_temperature_k = 298.15;
    double relative_humidity = 0.5;
    double contamination_fraction = 0.0;
    double external_ground_fault_resistance_ohm = 0.0;
};

struct EmiHarmonic {
    double frequency_hz = 0.0;
    double differential_voltage_v_rms = 0.0;
    double common_mode_voltage_v_rms = 0.0;
    double differential_conducted_dbuv = 0.0;
    double common_mode_conducted_dbuv = 0.0;
    double radiated_field_dbuv_m = 0.0;
};

struct HighVoltageParasiticsState {
    double time_s = 0.0;
    double dc_link_voltage_v = 0.0;
    double source_inductor_current_a = 0.0;
    double dc_link_ripple_v_rms = 0.0;
    double dc_link_ripple_v_peak_to_peak = 0.0;
    double common_mode_voltage_v = 0.0;
    double common_mode_current_a = 0.0;
    double chassis_voltage_v = 0.0;
    double isolation_resistance_ohm = 0.0;
    double leakage_current_a = 0.0;
    double bearing_voltage_v = 0.0;
    double bearing_current_a = 0.0;
    double peak_dv_dt_v_s = 0.0;
    double differential_conducted_dbuv = 0.0;
    double common_mode_conducted_dbuv = 0.0;
    double radiated_field_dbuv_m = 0.0;
    double equivalent_electric_field_v_m = 0.0;
    double resistive_loss_w = 0.0;
    double dielectric_loss_w = 0.0;
    double stored_energy_j = 0.0;
    double energy_residual_j = 0.0;
    bool conducted_limit_exceeded = false;
    bool radiated_limit_exceeded = false;
    bool isolation_fault = false;
    std::vector<EmiHarmonic> harmonics;
};

class HighVoltageParasiticsEmiModel {
public:
    HighVoltageParasiticsEmiModel();
    explicit HighVoltageParasiticsEmiModel(HighVoltageParasiticsConfiguration configuration);
    void configure(const HighVoltageParasiticsConfiguration& configuration);
    void reset(double bus_voltage_v = 400.0);
    const HighVoltageParasiticsState& step(const HighVoltageParasiticsInput& input,
                                           double dt_s);
    [[nodiscard]] const HighVoltageParasiticsState& state() const noexcept { return state_; }
    void restore_state(const HighVoltageParasiticsState& state);
    [[nodiscard]] std::string report() const;
private:
    HighVoltageParasiticsConfiguration configuration_;
    HighVoltageParasiticsState state_;
    double previous_dc_link_voltage_v_ = 400.0;
    double previous_common_mode_drive_v_ = 0.0;
    double previous_stored_energy_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Multidimensional aerodynamics and aero-thermal cooling flow.
// -----------------------------------------------------------------------------

struct AerothermalConfiguration {
    double frontal_area_m2 = 2.25;
    double wheelbase_m = 2.75;
    double track_m = 1.58;
    double base_drag_coefficient = 0.29;
    double base_lift_coefficient = 0.05;
    double base_side_coefficient_per_rad = 1.8;
    double yaw_moment_coefficient_per_rad = 0.22;
    double pitch_moment_coefficient = -0.04;
    double roll_moment_coefficient_per_rad = -0.18;
    double reference_ride_height_m = 0.145;
    double radiator_area_m2 = 0.55;
    double battery_cooling_area_m2 = 0.25;
    double brake_duct_area_m2 = 0.035;
    double underhood_pressure_recovery = 0.68;
};

struct AerothermalInput {
    Vec3d vehicle_velocity_m_s{};
    Vec3d wind_velocity_m_s{};
    double yaw_rad = 0.0;
    double pitch_rad = 0.0;
    double roll_rad = 0.0;
    std::array<double,4> ride_height_m{{0.145,0.145,0.145,0.145}};
    double grille_open_fraction = 1.0;
    double spoiler_fraction = 0.0;
    double trailer_articulation_rad = 0.0;
    double ambient_density_kg_m3 = 1.225;
    double ambient_temperature_k = 298.15;
};

struct AerothermalState {
    Vec3d aerodynamic_force_n{};
    Vec3d aerodynamic_moment_nm{};
    double drag_coefficient = 0.29;
    double lift_coefficient = 0.05;
    double side_coefficient = 0.0;
    double yaw_angle_rad = 0.0;
    double relative_air_speed_m_s = 0.0;
    double radiator_air_mass_flow_kg_s = 0.0;
    double battery_air_mass_flow_kg_s = 0.0;
    std::array<double,4> brake_air_mass_flow_kg_s{};
    double underhood_pressure_pa = 0.0;
    double radiator_heat_transfer_w_k = 0.0;
    double battery_heat_transfer_w_k = 0.0;
    std::array<double,4> brake_heat_transfer_w_k{};
    double aerodynamic_power_w = 0.0;
};

class MultidimensionalAerothermalModel {
public:
    MultidimensionalAerothermalModel();
    explicit MultidimensionalAerothermalModel(AerothermalConfiguration configuration);
    void configure(const AerothermalConfiguration& configuration);
    const AerothermalState& step(const AerothermalInput& input);
    [[nodiscard]] const AerothermalState& state() const noexcept { return state_; }
    void restore_state(const AerothermalState& state) { state_ = state; }
    [[nodiscard]] std::string report() const;
private:
    AerothermalConfiguration configuration_;
    AerothermalState state_;
};

// -----------------------------------------------------------------------------
// Detailed brake hydraulics, tribology, wear, and judder.
// -----------------------------------------------------------------------------

struct DetailedBrakeConfiguration {
    double master_cylinder_area_m2 = 5.1e-4;
    double pedal_ratio = 4.2;
    double booster_gain = 5.5;
    double fluid_bulk_modulus_pa = 1.55e9;
    double line_volume_m3 = 2.5e-5;
    double hose_compliance_m3_pa = 1.3e-15;
    double valve_flow_coefficient_m3_s_pa_sqrt = 4.0e-8;
    std::array<double,4> caliper_piston_area_m2{{0.0034,0.0034,0.0024,0.0024}};
    std::array<double,4> effective_radius_m{{0.145,0.145,0.135,0.135}};
    std::array<double,4> disc_mass_kg{{9.5,9.5,7.0,7.0}};
    double disc_specific_heat_j_kg_k = 490.0;
    double pad_friction_cold = 0.42;
    double pad_friction_hot = 0.30;
    double fade_start_k = 650.0;
    double fade_full_k = 1000.0;
    double pad_wear_energy_j_per_m = 1.2e9;
    double rotor_wear_energy_j_per_m = 8.0e9;
    double fluid_boiling_point_k = 503.0;
    double wet_boiling_point_k = 433.0;
    double runout_m = 20.0e-6;
    double judder_gain_nm_m = 2.0e6;
};

struct DetailedBrakeInput {
    double pedal_force_n = 0.0;
    std::array<double,4> wheel_speed_rad_s{};
    std::array<double,4> abs_release_fraction{};
    double vehicle_speed_m_s = 0.0;
    double ambient_temperature_k = 298.15;
    double water_exposure = 0.0;
    std::array<double,4> cooling_air_mass_flow_kg_s{};
};

struct DetailedBrakeCornerState {
    double line_pressure_pa = 0.0;
    double caliper_clamp_force_n = 0.0;
    double brake_torque_nm = 0.0;
    double disc_temperature_k = 298.15;
    double pad_temperature_k = 298.15;
    double pad_thickness_m = 0.012;
    double rotor_thickness_m = 0.030;
    double transfer_layer = 0.5;
    double friction_coefficient = 0.42;
    double judder_torque_nm = 0.0;
    double pad_wear_m = 0.0;
    double rotor_wear_m = 0.0;
};

struct DetailedBrakeState {
    double time_s = 0.0;
    double master_pressure_pa = 0.0;
    double fluid_temperature_k = 298.15;
    double vapor_fraction = 0.0;
    std::array<DetailedBrakeCornerState,4> corners{};
    double hydraulic_energy_j = 0.0;
    double friction_energy_j = 0.0;
    double dissipated_heat_j = 0.0;
    double energy_residual_j = 0.0;
    bool hydraulic_fallback_active = false;
    bool boiling = false;
};

class DetailedBrakeHydraulicSystem {
public:
    DetailedBrakeHydraulicSystem();
    explicit DetailedBrakeHydraulicSystem(DetailedBrakeConfiguration configuration);
    void configure(const DetailedBrakeConfiguration& configuration);
    void reset(double ambient_temperature_k = 298.15);
    void set_circuit_leak(std::size_t corner, double leakage_m3_s_pa);
    void set_runout(std::size_t corner, double runout_m);
    const DetailedBrakeState& step(const DetailedBrakeInput& input, double dt_s);
    [[nodiscard]] const DetailedBrakeState& state() const noexcept { return state_; }
    void restore_state(const DetailedBrakeState& state);
    [[nodiscard]] std::string report() const;
private:
    DetailedBrakeConfiguration configuration_;
    DetailedBrakeState state_;
    std::array<double,4> leakage_m3_s_pa_{};
    std::array<double,4> runout_m_{};
};

// -----------------------------------------------------------------------------
// Multicore ECU execution with AUTOSAR-oriented services.
// -----------------------------------------------------------------------------

enum class AutosarService { Rte, Com, Dem, Nvm, Wdgm, EcuM, Doip, TimeSync };
enum class RunnableActivation { Periodic, Event, Network };

struct EcuCoreDefinition {
    std::string name;
    double clock_hz = 400.0e6;
};

struct AutosarRunnableDefinition {
    std::string name;
    RunnableActivation activation = RunnableActivation::Periodic;
    double period_s = 0.01;
    double deadline_s = 0.01;
    std::uint64_t worst_case_cycles = 100000;
    int priority = 10;
    std::vector<std::size_t> core_affinity;
    std::vector<AutosarService> services;
    std::string input_signal;
    std::string output_signal;
    std::string network_frame;
};

struct AutosarRunnableStatistics {
    std::uint64_t releases = 0;
    std::uint64_t completions = 0;
    std::uint64_t preemptions = 0;
    std::uint64_t deadline_misses = 0;
    double maximum_response_time_s = 0.0;
    double total_execution_time_s = 0.0;
};

struct AutosarNetworkFrame {
    std::string name;
    double release_time_s = 0.0;
    double delivery_time_s = 0.0;
    std::uint32_t sequence_counter = 0;
    std::uint32_t crc = 0;
    std::map<std::string,double> signals;
};

struct AutosarRuntimeState {
    double time_s = 0.0;
    std::vector<AutosarRunnableStatistics> runnable_statistics;
    std::vector<double> core_utilization;
    std::uint64_t rte_reads = 0;
    std::uint64_t rte_writes = 0;
    std::uint64_t com_frames_sent = 0;
    std::uint64_t com_frames_received = 0;
    std::uint64_t dem_events = 0;
    std::uint64_t nvm_writes = 0;
    std::uint64_t watchdog_resets = 0;
    std::uint64_t end_to_end_errors = 0;
    bool ecu_operational = true;
};

class AutosarMulticoreRuntime {
public:
    AutosarMulticoreRuntime();
    ~AutosarMulticoreRuntime();
    void configure(std::vector<EcuCoreDefinition> cores,
                   std::vector<AutosarRunnableDefinition> runnables);
    void configure_default_vehicle_controller();
    void reset();
    void write_rte(const std::string& signal, double value);
    [[nodiscard]] std::optional<double> read_rte(const std::string& signal) const;
    void trigger_event(const std::string& runnable_name);
    void receive_network_frame(const AutosarNetworkFrame& frame);
    void set_network_latency(double base_latency_s, double jitter_s, double loss_probability);
    void inject_execution_overrun(const std::string& runnable_name, double multiplier,
                                  double duration_s);
    void report_dem_event(const std::string& dtc, bool active);
    void write_nvm(const std::string& key, double value);
    [[nodiscard]] std::optional<double> read_nvm(const std::string& key) const;
    const AutosarRuntimeState& step(double dt_s);
    [[nodiscard]] std::vector<AutosarNetworkFrame> take_transmitted_frames();
    [[nodiscard]] const AutosarRuntimeState& state() const noexcept { return state_; }
    [[nodiscard]] std::string report() const;
private:
    struct Job;
    std::vector<EcuCoreDefinition> cores_;
    std::vector<AutosarRunnableDefinition> runnables_;
    AutosarRuntimeState state_;
    std::vector<Job> jobs_;
    std::vector<std::optional<std::size_t>> running_job_;
    std::vector<double> next_release_s_;
    std::set<std::size_t> event_pending_;
    std::map<std::string,double> rte_;
    std::map<std::string,double> nvm_;
    std::map<std::string,bool> dem_;
    std::deque<AutosarNetworkFrame> receive_queue_;
    std::vector<AutosarNetworkFrame> transmit_queue_;
    std::mt19937_64 random_{0xA5705A2ULL};
    double network_base_latency_s_ = 0.0004;
    double network_jitter_s_ = 0.0001;
    double network_loss_probability_ = 0.0;
    std::map<std::string,std::pair<double,double>> overruns_;
    std::uint32_t sequence_counter_ = 0;
};

// -----------------------------------------------------------------------------
// Checkpointing, deterministic causal replay, and branching.
// -----------------------------------------------------------------------------

struct ReplayFrame {
    double dt_s = 0.0;
    std::map<std::string,double> inputs;
    std::string cause;
};

struct ReplayCheckpoint {
    std::string id;
    std::string branch;
    std::size_t event_index = 0;
    double time_s = 0.0;
    std::string state_blob;
    std::uint64_t state_hash = 0;
};

struct ReplayBranch {
    std::string name;
    std::string parent;
    std::size_t fork_event_index = 0;
    std::vector<ReplayFrame> events;
};

class CheckpointReplayManager {
public:
    using Capture = std::function<std::string()>;
    using Restore = std::function<void(const std::string&)>;
    using Reset = std::function<void()>;
    using Execute = std::function<void(const ReplayFrame&)>;

    CheckpointReplayManager();
    void bind(Capture capture, Restore restore, Reset reset, Execute execute);
    void clear();
    void record(ReplayFrame frame);
    ReplayCheckpoint checkpoint(const std::string& id);
    bool restore_checkpoint(const std::string& id);
    bool create_branch(const std::string& name, const std::string& checkpoint_id);
    bool select_branch(const std::string& name);
    bool replace_event(std::size_t event_index, ReplayFrame replacement);
    bool replay(std::optional<std::size_t> through_event = std::nullopt);
    bool save(const std::string& path) const;
    bool load(const std::string& path);
    [[nodiscard]] std::string causal_trace(std::size_t from_event = 0) const;
    [[nodiscard]] const std::string& active_branch() const noexcept { return active_branch_; }
    [[nodiscard]] std::size_t event_count() const;
    [[nodiscard]] std::optional<ReplayFrame> event(std::size_t event_index) const;
    [[nodiscard]] std::string report() const;
private:
    Capture capture_;
    Restore restore_;
    Reset reset_;
    Execute execute_;
    std::map<std::string,ReplayCheckpoint> checkpoints_;
    std::map<std::string,ReplayBranch> branches_;
    std::string active_branch_ = "main";
    bool replaying_ = false;
};

// -----------------------------------------------------------------------------
// State-conserving multi-fidelity runtime coordination.
// -----------------------------------------------------------------------------

enum class FidelityLevel { Reduced = 0, Engineering = 1, Detailed = 2 };
enum class FidelityDomain { Structure, Terrain, Tire, HighVoltage, ElectricDrive, Aerothermal, Brake, Ecu };

struct ConservedProjectionState {
    double energy_j = 0.0;
    double mass_kg = 0.0;
    double charge_c = 0.0;
    double momentum_kg_m_s = 0.0;
};

struct FidelityTransition {
    double time_s = 0.0;
    FidelityDomain domain = FidelityDomain::Structure;
    FidelityLevel from = FidelityLevel::Engineering;
    FidelityLevel to = FidelityLevel::Detailed;
    ConservedProjectionState before{};
    ConservedProjectionState after{};
    ConservedProjectionState correction{};
    bool accepted = false;
};

struct FidelityDomainAdapter {
    std::function<ConservedProjectionState()> capture;
    std::function<bool(FidelityLevel)> project;
};

class MultiFidelityCoordinator {
public:
    MultiFidelityCoordinator();
    void reset();
    void register_domain(FidelityDomain domain, FidelityLevel initial,
                         FidelityDomainAdapter adapter);
    bool switch_level(FidelityDomain domain, FidelityLevel level, double time_s);
    void set_auto_mode(bool enabled, double computational_budget);
    void update_auto(double time_s, double error_indicator, double event_severity);
    [[nodiscard]] FidelityLevel level(FidelityDomain domain) const;
    [[nodiscard]] ConservedProjectionState correction() const noexcept { return correction_; }
    [[nodiscard]] const std::vector<FidelityTransition>& transitions() const noexcept { return transitions_; }
    [[nodiscard]] std::string report() const;
private:
    struct Entry { FidelityLevel level = FidelityLevel::Engineering; FidelityDomainAdapter adapter; };
    std::map<FidelityDomain,Entry> domains_;
    std::vector<FidelityTransition> transitions_;
    ConservedProjectionState correction_{};
    bool auto_mode_ = false;
    double computational_budget_ = 0.5;
};

[[nodiscard]] std::string to_string(TerrainSurface value);
[[nodiscard]] std::string to_string(TireFailureState value);
[[nodiscard]] std::string to_string(ProtectionState value);
[[nodiscard]] std::string to_string(MachineElectricalFault value);
[[nodiscard]] std::string to_string(FidelityLevel value);
[[nodiscard]] std::string to_string(FidelityDomain value);

} // namespace aesim::high_fidelity

#pragma once

#include "aesim/core/cylinder_combustion.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace aesim::high_fidelity {

// -----------------------------------------------------------------------------
// Deterministic multi-rate execution with mass, energy, charge, and momentum
// conservation accounting.
// -----------------------------------------------------------------------------

struct ConservationState {
    double stored_energy_j = 0.0;
    double stored_mass_kg = 0.0;
    double stored_charge_c = 0.0;
    double stored_momentum_kg_m_s = 0.0;
    double energy_in_w = 0.0;
    double energy_out_w = 0.0;
    double mass_in_kg_s = 0.0;
    double mass_out_kg_s = 0.0;
    double charge_in_a = 0.0;
    double charge_out_a = 0.0;
    double external_force_n = 0.0;
};

struct ConservationResidual {
    double energy_j = 0.0;
    double mass_kg = 0.0;
    double charge_c = 0.0;
    double momentum_kg_m_s = 0.0;
    double normalized_energy = 0.0;
    double normalized_mass = 0.0;
    double normalized_charge = 0.0;
    double normalized_momentum = 0.0;
};

struct ConservativeTaskConfig {
    std::string name;
    std::string conservation_domain;
    double period_s = 0.001;
    double phase_s = 0.0;
    int priority = 0;
    bool enabled = true;
};

struct ConservativeTaskStatistics {
    std::uint64_t executions = 0;
    double last_scheduled_time_s = 0.0;
    double maximum_lateness_s = 0.0;
    ConservationResidual cumulative_residual;
    ConservationResidual maximum_absolute_step_residual;
    std::uint64_t tolerance_violations = 0;
};

class ConservativeMultiRateSolver {
public:
    ConservativeMultiRateSolver();
    ~ConservativeMultiRateSolver();
    using Callback = std::function<ConservationState(double scheduled_time_s, double elapsed_s)>;

    std::size_t add_task(const ConservativeTaskConfig& config, Callback callback);
    void clear();
    void reset(double start_time_s = 0.0);
    void advance(double dt_s);
    void set_enabled(std::size_t task_id, bool enabled);
    void set_period(std::size_t task_id, double period_s);
    void set_relative_tolerances(double energy, double mass, double charge, double momentum);

    [[nodiscard]] double time_s() const noexcept;
    [[nodiscard]] ConservativeTaskStatistics statistics(std::size_t task_id) const;
    [[nodiscard]] const ConservativeTaskStatistics& statistics_ref(std::size_t task_id) const;
    [[nodiscard]] std::map<std::string, ConservationResidual> domain_residuals() const;
    [[nodiscard]] std::string report() const;

private:
    struct Task;
    std::vector<Task> tasks_;
    std::vector<std::size_t> execution_order_;
    std::int64_t time_ns_ = 0;
    std::array<double,4> tolerances_{{1.0e-6, 1.0e-8, 1.0e-8, 1.0e-6}};

    static std::int64_t to_ns(double seconds);
    static double to_s(std::int64_t nanoseconds) noexcept;
};

// -----------------------------------------------------------------------------
// Seven-degree-of-freedom body/unsprung multibody suspension with anti-roll
// coupling and longitudinal/lateral compliance steer.
// -----------------------------------------------------------------------------

struct SuspensionHardpoint {
    double x_m = 0.0;
    double y_m = 0.0;
    double wheel_rate_n_m = 32000.0;
    double bump_damping_n_s_m = 3000.0;
    double rebound_damping_n_s_m = 4200.0;
    double unsprung_mass_kg = 45.0;
    double tire_vertical_rate_n_m = 220000.0;
    double tire_vertical_damping_n_s_m = 500.0;
    double bump_stop_clearance_m = 0.065;
    double bump_stop_rate_n_m = 220000.0;
    double rebound_stop_clearance_m = 0.090;
    double rebound_stop_rate_n_m = 120000.0;
    double motion_ratio = 0.95;
    double camber_static_rad = -0.015;
    double camber_gain_rad_m = -0.28;
    double toe_static_rad = 0.0;
    double toe_gain_rad_m = 0.035;
    double longitudinal_bushing_stiffness_n_m = 1.2e6;
    double lateral_bushing_stiffness_n_m = 9.0e5;
    double bushing_damping_n_s_m = 6500.0;
    double compliance_steer_rad_m = 0.32;
    double compliance_camber_rad_m = -0.12;
};

struct MultibodySuspensionConfiguration {
    double sprung_mass_kg = 1500.0;
    double roll_inertia_kg_m2 = 650.0;
    double pitch_inertia_kg_m2 = 2450.0;
    double heave_damping_n_s_m = 0.0;
    double front_antiroll_rate_nm_rad = 28000.0;
    double rear_antiroll_rate_nm_rad = 19000.0;
    double gravity_m_s2 = 9.80665;
    std::array<SuspensionHardpoint,4> corners{{
        {-1.20, 0.79}, {-1.20, -0.79}, {1.55, 0.78}, {1.55, -0.78}
    }};
};

struct MultibodySuspensionInput {
    std::array<double,4> road_height_m{};
    std::array<double,4> road_vertical_velocity_m_s{};
    std::array<double,4> tire_longitudinal_force_n{};
    std::array<double,4> tire_lateral_force_n{};
    std::array<double,4> active_actuator_force_n{};
    double aerodynamic_heave_force_n = 0.0;
    double aerodynamic_roll_moment_nm = 0.0;
    double aerodynamic_pitch_moment_nm = 0.0;
};

struct SuspensionCornerDynamicState {
    double unsprung_displacement_m = 0.0;
    double unsprung_velocity_m_s = 0.0;
    double suspension_travel_m = 0.0;
    double suspension_velocity_m_s = 0.0;
    double suspension_force_n = 0.0;
    double tire_force_n = 0.0;
    double longitudinal_bushing_deflection_m = 0.0;
    double lateral_bushing_deflection_m = 0.0;
    double hub_longitudinal_offset_m = 0.0;
    double hub_lateral_offset_m = 0.0;
    double camber_rad = 0.0;
    double toe_rad = 0.0;
    bool bump_stop_engaged = false;
    bool rebound_stop_engaged = false;
    bool airborne = false;
};

struct MultibodySuspensionState {
    double time_s = 0.0;
    double heave_m = 0.0;
    double heave_velocity_m_s = 0.0;
    double roll_rad = 0.0;
    double roll_rate_rad_s = 0.0;
    double pitch_rad = 0.0;
    double pitch_rate_rad_s = 0.0;
    std::array<SuspensionCornerDynamicState,4> corners{};
    double vertical_force_residual_n = 0.0;
    double roll_moment_residual_nm = 0.0;
    double pitch_moment_residual_nm = 0.0;
    double mechanical_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
};

class MultibodySuspensionSystem {
public:
    MultibodySuspensionSystem();
    explicit MultibodySuspensionSystem(MultibodySuspensionConfiguration configuration);
    void configure(const MultibodySuspensionConfiguration& configuration);
    void reset();
    const MultibodySuspensionState& step(const MultibodySuspensionInput& input, double dt_s);
    [[nodiscard]] const MultibodySuspensionState& state() const noexcept { return state_; }
    [[nodiscard]] const MultibodySuspensionConfiguration& configuration() const noexcept { return configuration_; }
    [[nodiscard]] std::string report() const;
private:
    MultibodySuspensionConfiguration configuration_;
    MultibodySuspensionState state_;
    std::array<double,4> sprung_preload_n_{};
    std::array<double,4> tire_preload_n_{};
    void compute_preloads();
};

// -----------------------------------------------------------------------------
// Flexible ring tire, distributed contact patch, transient bristles, thermal
// state, wear, water-film friction, and road enveloping.
// -----------------------------------------------------------------------------

struct RoadContactSample {
    double longitudinal_offset_m = 0.0;
    double height_m = 0.0;
    double friction_scale = 1.0;
    double water_depth_m = 0.0;
    double loose_depth_m = 0.0;
};

struct FlexibleRingTireConfiguration {
    std::size_t ring_nodes = 24;
    double unloaded_radius_m = 0.335;
    double width_m = 0.235;
    double wheel_inertia_kg_m2 = 1.55;
    double ring_radial_stiffness_n_m = 2.35e6;
    double ring_radial_damping_n_s_m = 14500.0;
    double belt_coupling_stiffness_n_m = 3.2e5;
    double vertical_stiffness_n_m = 235000.0;
    double longitudinal_stiffness_n = 115000.0;
    double lateral_stiffness_n_rad = 92000.0;
    double bristle_damping_n_s_m = 850.0;
    double relaxation_length_longitudinal_m = 0.28;
    double relaxation_length_lateral_m = 0.36;
    double reference_mu = 1.05;
    double load_sensitivity = 0.08;
    double camber_stiffness_n_rad = 11500.0;
    double pneumatic_trail_m = 0.055;
    double rolling_resistance_coefficient = 0.011;
    double tread_thermal_capacity_j_k = 10500.0;
    double carcass_thermal_capacity_j_k = 19000.0;
    double tread_to_carcass_w_k = 170.0;
    double carcass_to_ambient_w_k = 48.0;
    double nominal_pressure_pa = 240000.0;
    double initial_tread_depth_m = 0.0075;
    double wear_energy_j_per_m3 = 3.4e11;
    double hydroplaning_speed_coefficient = 9.0;
};

struct FlexibleRingTireInput {
    double normal_load_n = 4000.0;
    double wheel_angular_speed_rad_s = 0.0;
    double hub_longitudinal_speed_m_s = 0.0;
    double hub_lateral_speed_m_s = 0.0;
    double camber_rad = 0.0;
    double drive_torque_nm = 0.0;
    double brake_torque_nm = 0.0;
    double ambient_temperature_c = 25.0;
    double inflation_pressure_pa = 240000.0;
    std::vector<RoadContactSample> road_samples;

    // Optional zero-copy road sample view. When populated, this view takes
    // precedence over road_samples for the duration of step(). The caller must
    // keep the referenced storage alive until step() returns. Unsorted views
    // remain supported; the implementation copies only that exceptional case.
    const RoadContactSample* road_samples_data = nullptr;
    std::size_t road_sample_count = 0;
};

struct RingNodeState {
    double radial_deflection_m = 0.0;
    double radial_velocity_m_s = 0.0;
    double normal_force_n = 0.0;
    bool in_contact = false;
};

struct FlexibleRingTireState {
    double wheel_angle_rad = 0.0;
    double wheel_angular_speed_rad_s = 0.0;
    double effective_radius_m = 0.335;
    double loaded_radius_m = 0.320;
    double contact_patch_length_m = 0.0;
    double enveloped_road_height_m = 0.0;
    double slip_ratio = 0.0;
    double slip_angle_rad = 0.0;
    double relaxed_longitudinal_slip = 0.0;
    double relaxed_lateral_slip = 0.0;
    double longitudinal_force_n = 0.0;
    double lateral_force_n = 0.0;
    double vertical_force_n = 0.0;
    double aligning_moment_nm = 0.0;
    double overturning_moment_nm = 0.0;
    double rolling_resistance_torque_nm = 0.0;
    double friction_coefficient = 1.0;
    double utilization = 0.0;
    double tread_temperature_c = 25.0;
    double carcass_temperature_c = 25.0;
    double tread_depth_m = 0.0075;
    double wear_fraction = 0.0;
    double dissipated_energy_j = 0.0;
    double ring_strain_energy_j = 0.0;
    std::vector<RingNodeState> ring;
};

class FlexibleRingTire {
public:
    FlexibleRingTire();
    explicit FlexibleRingTire(FlexibleRingTireConfiguration configuration);
    void configure(const FlexibleRingTireConfiguration& configuration);
    void reset(double temperature_c = 25.0);
    const FlexibleRingTireState& step(const FlexibleRingTireInput& input, double dt_s);
    [[nodiscard]] const FlexibleRingTireState& state() const noexcept { return state_; }
    [[nodiscard]] std::string report() const;
private:
    FlexibleRingTireConfiguration configuration_;
    FlexibleRingTireState state_;
    double bristle_x_m_ = 0.0;
    double bristle_y_m_ = 0.0;
    std::vector<double> node_x_scratch_;
    std::vector<double> node_radial_y_scratch_;
    std::vector<RoadContactSample> node_road_scratch_;
};

// -----------------------------------------------------------------------------
// Multi-inertia torsional driveline with clutch, gear mesh, propshaft and
// halfshaft compliance, lash contact, differential bias, and energy accounting.
// -----------------------------------------------------------------------------

struct TorsionalDrivelineConfiguration {
    double engine_inertia_kg_m2 = 0.22;
    double gearbox_input_inertia_kg_m2 = 0.065;
    double propshaft_inertia_kg_m2 = 0.045;
    double differential_inertia_kg_m2 = 0.085;
    double wheel_inertia_kg_m2 = 1.65;
    double clutch_stiffness_nm_rad = 4800.0;
    double clutch_damping_nm_s_rad = 32.0;
    double clutch_capacity_nm = 650.0;
    double gear_mesh_stiffness_nm_rad = 18000.0;
    double gear_mesh_damping_nm_s_rad = 75.0;
    double propshaft_stiffness_nm_rad = 9200.0;
    double propshaft_damping_nm_s_rad = 48.0;
    double propshaft_backlash_rad = 0.0040;
    double halfshaft_stiffness_nm_rad = 12500.0;
    double halfshaft_damping_nm_s_rad = 42.0;
    double halfshaft_backlash_rad = 0.0020;
    double final_drive_ratio = 3.70;
    double differential_preload_nm = 25.0;
    double differential_bias_ratio = 2.4;
    double efficiency = 0.975;
};

struct TorsionalDrivelineInput {
    double engine_torque_nm = 0.0;
    double clutch_engagement = 1.0;
    double gear_ratio = 3.0;
    double left_resisting_torque_nm = 0.0;
    double right_resisting_torque_nm = 0.0;
    double differential_lock_command = 0.0;
};

struct TorsionalDrivelineState {
    double engine_angle_rad = 0.0;
    double engine_speed_rad_s = 0.0;
    double gearbox_angle_rad = 0.0;
    double gearbox_speed_rad_s = 0.0;
    double propshaft_angle_rad = 0.0;
    double propshaft_speed_rad_s = 0.0;
    double differential_angle_rad = 0.0;
    double differential_speed_rad_s = 0.0;
    std::array<double,2> wheel_angle_rad{};
    std::array<double,2> wheel_speed_rad_s{};
    double clutch_torque_nm = 0.0;
    double gear_mesh_torque_nm = 0.0;
    double propshaft_torque_nm = 0.0;
    std::array<double,2> halfshaft_torque_nm{};
    int propshaft_contact_side = 0;
    std::array<int,2> halfshaft_contact_side{};
    double differential_lock_fraction = 0.0;
    double stored_torsional_energy_j = 0.0;
    double kinetic_energy_j = 0.0;
    double dissipated_energy_j = 0.0;
    double energy_residual_j = 0.0;
};

class TorsionalDriveline {
public:
    TorsionalDriveline();
    explicit TorsionalDriveline(TorsionalDrivelineConfiguration configuration);
    void configure(const TorsionalDrivelineConfiguration& configuration);
    void reset(double engine_speed_rad_s = 0.0, double wheel_speed_rad_s = 0.0,
               double gear_ratio = 3.0);
    const TorsionalDrivelineState& step(const TorsionalDrivelineInput& input, double dt_s);
    [[nodiscard]] const TorsionalDrivelineState& state() const noexcept { return state_; }
    [[nodiscard]] std::string report() const;
private:
    TorsionalDrivelineConfiguration configuration_;
    TorsionalDrivelineState state_;
};

// -----------------------------------------------------------------------------
// Distributed thermal graph for engine, battery, e-machines, inverters,
// coolant circuits, radiator/chiller, cabin, and ambient boundaries.
// -----------------------------------------------------------------------------

enum class ThermalNodeId : std::size_t {
    EngineMetal, EngineOil, EngineCoolant, BatteryCore, BatteryCoolant,
    FrontMachine, RearMachine, FrontInverter, RearInverter, PowerElectronicsCoolant,
    CabinAir, CabinMass, Count
};

struct DistributedThermalConfiguration {
    std::array<double,static_cast<std::size_t>(ThermalNodeId::Count)> heat_capacity_j_k{{
        180000.0, 55000.0, 70000.0, 620000.0, 65000.0,
        95000.0, 95000.0, 42000.0, 42000.0, 58000.0,
        45000.0, 320000.0
    }};
    double engine_metal_to_coolant_w_k = 1350.0;
    double engine_metal_to_oil_w_k = 420.0;
    double oil_to_coolant_w_k = 240.0;
    double battery_core_to_coolant_w_k = 980.0;
    double machine_to_coolant_w_k = 520.0;
    double inverter_to_coolant_w_k = 760.0;
    double cabin_mass_to_air_w_k = 380.0;
    double cabin_to_ambient_w_k = 120.0;
    double radiator_ua_w_k_at_30m_s = 4200.0;
    double low_temperature_radiator_ua_w_k_at_30m_s = 2800.0;
    double chiller_maximum_w = 12000.0;
    double heat_pump_maximum_w = 9000.0;
    double coolant_pump_power_w = 450.0;
    double fan_power_w = 700.0;
};

struct DistributedThermalInput {
    double ambient_temperature_c = 25.0;
    double vehicle_speed_m_s = 0.0;
    double engine_heat_w = 0.0;
    double engine_oil_friction_heat_w = 0.0;
    double battery_heat_w = 0.0;
    double front_machine_heat_w = 0.0;
    double rear_machine_heat_w = 0.0;
    double front_inverter_heat_w = 0.0;
    double rear_inverter_heat_w = 0.0;
    double solar_cabin_heat_w = 0.0;
    double occupant_cabin_heat_w = 0.0;
    double cabin_temperature_setpoint_c = 22.0;
    double engine_coolant_pump_command = 1.0;
    double battery_coolant_pump_command = 1.0;
    double power_electronics_pump_command = 1.0;
    double radiator_fan_command = 0.0;
    double battery_chiller_command = 0.0;
    double cabin_hvac_command = 1.0;
};

struct DistributedThermalState {
    double time_s = 0.0;
    std::array<double,static_cast<std::size_t>(ThermalNodeId::Count)> temperature_c{};
    double radiator_heat_rejection_w = 0.0;
    double low_temperature_radiator_heat_rejection_w = 0.0;
    double battery_chiller_heat_w = 0.0;
    double cabin_hvac_heat_w = 0.0;
    double auxiliary_power_w = 0.0;
    double boundary_heat_input_w = 0.0;
    double boundary_heat_output_w = 0.0;
    double stored_thermal_energy_j = 0.0;
    double cumulative_heat_input_j = 0.0;
    double cumulative_heat_rejected_j = 0.0;
    double energy_residual_j = 0.0;
    bool battery_derated = false;
    bool engine_overtemperature = false;
    bool power_electronics_derated = false;
};

class DistributedVehicleThermalNetwork {
public:
    DistributedVehicleThermalNetwork();
    explicit DistributedVehicleThermalNetwork(DistributedThermalConfiguration configuration);
    void configure(const DistributedThermalConfiguration& configuration);
    void reset(double uniform_temperature_c = 25.0);
    const DistributedThermalState& step(const DistributedThermalInput& input, double dt_s);
    [[nodiscard]] const DistributedThermalState& state() const noexcept { return state_; }
    [[nodiscard]] double temperature(ThermalNodeId id) const noexcept;
    [[nodiscard]] std::string report() const;
private:
    DistributedThermalConfiguration configuration_;
    DistributedThermalState state_;
    double reference_energy_j_ = 0.0;
};

// -----------------------------------------------------------------------------
// Deterministic sensor uncertainty and scheduled/intermittent fault injection.
// -----------------------------------------------------------------------------

enum class SensorFaultMode {
    Bias, Scale, Drift, Stuck, Dropout, SaturationHigh, SaturationLow,
    NoiseBurst, RateLimit, QuantizationChange, PolarityReverse, IntermittentOpen
};

struct SensorFaultEvent {
    std::string id;
    SensorFaultMode mode = SensorFaultMode::Bias;
    double start_time_s = 0.0;
    double duration_s = -1.0;
    double magnitude = 0.0;
    double secondary = 0.0;
    double duty_cycle = 1.0;
    double intermittency_period_s = 0.1;
};

struct SensorEnvironment {
    // Environmental inputs are dimensionless fractions unless a unit is shown.
    // Keeping them in one value object makes a recorded experiment replayable.
    double ambient_temperature_k = 298.15;
    double relative_humidity = 0.50;
    double ambient_pressure_pa = 101325.0;
    double vibration_rms_m_s2 = 0.0;
    double contamination_fraction = 0.0;
    double radiation_dose_rate_gy_s = 0.0;
    double supply_voltage_v = 5.0;
    double electromagnetic_field_v_m = 0.0;
};

struct SensorConfiguration {
    std::string name;
    double bias = 0.0;
    double scale = 1.0;
    double gaussian_sigma = 0.0;
    double random_walk_sigma_per_sqrt_s = 0.0;
    double drift_per_s = 0.0;
    double quantization = 0.0;
    double minimum = -1.0e30;
    double maximum = 1.0e30;
    double latency_s = 0.0;
    double sample_period_s = 0.0;
    double dropout_probability = 0.0;
    double rate_limit_per_s = 1.0e30;

    // Environmental sensitivities are deliberately explicit instead of being
    // hidden in a generic polynomial. This permits each coefficient to be
    // calibrated from chamber, vibration-table, EMC, and life-test data.
    double reference_temperature_k = 298.15;
    double temperature_bias_per_k = 0.0;
    double temperature_scale_per_k = 0.0;
    double humidity_bias_per_fraction = 0.0;
    double pressure_bias_per_pa = 0.0;
    double vibration_noise_sigma_per_m_s2 = 0.0;
    double contamination_bias_per_fraction = 0.0;
    double contamination_scale_loss_per_fraction = 0.0;
    double radiation_bias_per_gy = 0.0;
    double aging_bias_per_hour = 0.0;
    double aging_scale_loss_per_hour = 0.0;
    double nominal_supply_voltage_v = 5.0;
    double supply_bias_per_v = 0.0;
    double emi_bias_per_v_m = 0.0;
    double cross_axis_sensitivity = 0.0;
    double hysteresis = 0.0;

    // A first-order sensor-body thermal state captures self-heating and lag.
    double self_heating_w = 0.0;
    double thermal_resistance_k_w = 0.0;
    double thermal_time_constant_s = 1.0;
    double contamination_accumulation_rate_per_s = 1.0;
    double contamination_recovery_rate_per_s = 0.0;
    double contamination_dropout_gain = 0.0;
    double minimum_supply_voltage_v = 0.0;
    double supply_dropout_gain_per_v = 0.0;
    std::uint64_t seed = 1;
};

struct SensorOutput {
    double value = 0.0;
    double timestamp_s = 0.0;
    double age_s = 0.0;
    double uncertainty_sigma = 0.0;
    double sensor_temperature_k = 298.15;
    double effective_bias = 0.0;
    double effective_scale = 1.0;
    double accumulated_operating_hours = 0.0;
    double accumulated_radiation_dose_gy = 0.0;
    double accumulated_contamination_fraction = 0.0;
    bool valid = true;
    bool held = false;
    bool saturated = false;
    std::vector<std::string> active_faults;
};

class UncertainSensorChannel {
public:
    UncertainSensorChannel();
    explicit UncertainSensorChannel(SensorConfiguration configuration);
    void configure(const SensorConfiguration& configuration);
    void reset(double initial_value = 0.0);
    void add_fault(const SensorFaultEvent& fault);
    void clear_faults();
    SensorOutput sample(double true_value, double time_s, double dt_s);
    SensorOutput sample(double true_value, double time_s, double dt_s,
                        const SensorEnvironment& environment,
                        double cross_axis_value = 0.0);
    const SensorOutput& sample_ref(double true_value, double time_s, double dt_s);
    const SensorOutput& sample_ref(double true_value, double time_s, double dt_s,
                                   const SensorEnvironment& environment,
                                   double cross_axis_value = 0.0);
    // Calibration removes the current effective offset while preserving physical
    // aging and environmental states, matching an in-service zero/reference trim.
    void calibrate(double reference_true_value, double reference_measured_value);
    void service(bool remove_contamination = true, bool reset_age = false);
    [[nodiscard]] const SensorOutput& output() const noexcept { return output_; }
    [[nodiscard]] std::string report() const;
private:
    SensorConfiguration configuration_;
    SensorOutput output_;
    std::vector<SensorFaultEvent> faults_;
    std::mt19937_64 random_;
    std::normal_distribution<double> normal_{0.0,1.0};
    std::uniform_real_distribution<double> uniform_{0.0,1.0};
    std::deque<std::pair<double,double>> delay_line_;
    double random_walk_ = 0.0;
    double last_sample_time_s_ = -1.0e30;
    double last_output_value_ = 0.0;
    double previous_true_value_ = 0.0;
    double sensor_temperature_k_ = 298.15;
    double operating_hours_ = 0.0;
    double radiation_dose_gy_ = 0.0;
    double retained_contamination_ = 0.0;
    double calibration_bias_correction_ = 0.0;
    std::unordered_map<std::string,double> stuck_values_;
};

class SensorFaultInjectionSuite {
public:
    void add_or_replace_sensor(const SensorConfiguration& configuration);
    void add_fault(const std::string& sensor_name, const SensorFaultEvent& fault);
    void clear_faults();
    void reset();
    SensorOutput sample(const std::string& sensor_name, double true_value, double time_s, double dt_s);
    SensorOutput sample(const std::string& sensor_name, double true_value, double time_s,
                        double dt_s, const SensorEnvironment& environment,
                        double cross_axis_value = 0.0);
    UncertainSensorChannel& channel(const std::string& sensor_name);
    const UncertainSensorChannel& channel(const std::string& sensor_name) const;
    void calibrate(const std::string& sensor_name, double reference_true_value,
                   double reference_measured_value);
    void service(const std::string& sensor_name, bool remove_contamination = true,
                 bool reset_age = false);
    [[nodiscard]] std::map<std::string,SensorOutput> outputs() const;
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string,UncertainSensorChannel> channels_;
};

// -----------------------------------------------------------------------------
// Fixed-priority preemptive ECU scheduling directly coupled to a priority/TSN
// network. Task releases may block on message freshness and task completion
// emits frames whose serialization and propagation delay affect downstream jobs.
// -----------------------------------------------------------------------------

struct NetworkGateWindow {
    int priority = 0;
    std::uint64_t open_offset_us = 0;
    std::uint64_t close_offset_us = 1000;
};

struct EcuNetworkFrameTemplate {
    std::uint32_t message_id = 0;
    std::string destination_ecu;
    std::size_t payload_bytes = 8;
    int priority = 0;
    std::uint64_t deadline_us = 10000;
};

struct RealtimeTaskDefinition {
    std::string ecu;
    std::string name;
    std::uint64_t period_us = 10000;
    std::uint64_t offset_us = 0;
    std::uint64_t relative_deadline_us = 10000;
    std::uint64_t best_case_execution_us = 50;
    std::uint64_t worst_case_execution_us = 100;
    int priority = 10;
    std::vector<std::uint32_t> required_message_ids;
    std::uint64_t maximum_input_age_us = 50000;
    std::vector<EcuNetworkFrameTemplate> output_frames;
    bool enabled = true;
};

struct RealtimeTaskStatistics {
    std::uint64_t releases = 0;
    std::uint64_t completions = 0;
    std::uint64_t preemptions = 0;
    std::uint64_t blocked_releases = 0;
    std::uint64_t deadline_misses = 0;
    std::uint64_t maximum_response_us = 0;
    double mean_response_us = 0.0;
};

struct RealtimeNetworkStatistics {
    std::uint64_t transmitted_frames = 0;
    std::uint64_t delivered_frames = 0;
    std::uint64_t dropped_frames = 0;
    std::uint64_t network_deadline_misses = 0;
    std::uint64_t maximum_latency_us = 0;
    double mean_latency_us = 0.0;
    double utilization = 0.0;
};

class RealtimeEcuNetworkSimulator {
public:
    RealtimeEcuNetworkSimulator();
    ~RealtimeEcuNetworkSimulator();
    void reset();
    void add_ecu(const std::string& name, double background_load_fraction = 0.0);
    void add_or_replace_task(const RealtimeTaskDefinition& task);
    void configure_network(double bitrate_mbps, std::uint64_t propagation_delay_us,
                           std::uint64_t gate_cycle_us);
    void set_gate_windows(std::vector<NetworkGateWindow> windows);
    void inject_message(std::uint32_t message_id, const std::string& source_ecu,
                        const std::string& destination_ecu, std::size_t payload_bytes,
                        int priority, std::uint64_t deadline_us);
    void advance(double dt_s);
    [[nodiscard]] std::uint64_t time_us() const noexcept { return time_us_; }
    [[nodiscard]] std::map<std::string,RealtimeTaskStatistics> task_statistics() const;
    [[nodiscard]] const RealtimeNetworkStatistics& network_statistics() const noexcept { return network_statistics_; }
    [[nodiscard]] std::optional<std::uint64_t> last_message_arrival_us(const std::string& ecu,
                                                                       std::uint32_t message_id) const;
    [[nodiscard]] std::string report() const;
private:
    struct Job {
        std::size_t task_index = 0;
        std::uint64_t release_us = 0;
        std::uint64_t absolute_deadline_us = 0;
        std::uint64_t execution_us = 0;
        std::uint64_t remaining_us = 0;
        bool started = false;
        bool blocked_reported = false;
    };
    struct EcuState {
        double background_load_fraction = 0.0;
        double background_accumulator = 0.0;
        std::vector<Job> ready;
        std::optional<Job> running;
        std::map<std::uint32_t,std::uint64_t> message_arrivals;
    };
    struct Frame {
        std::uint32_t message_id = 0;
        std::string source_ecu;
        std::string destination_ecu;
        std::size_t payload_bytes = 0;
        int priority = 0;
        std::uint64_t enqueue_us = 0;
        std::uint64_t absolute_deadline_us = 0;
        std::uint64_t serialization_us = 0;
        std::uint64_t remaining_us = 0;
        std::uint64_t arrival_us = 0;
    };
    std::uint64_t time_us_ = 0;
    double bitrate_bits_per_us_ = 100.0;
    std::uint64_t propagation_delay_us_ = 5;
    std::uint64_t gate_cycle_us_ = 1000;
    std::vector<NetworkGateWindow> gate_windows_;
    std::map<std::string,EcuState> ecus_;
    std::vector<RealtimeTaskDefinition> tasks_;
    std::map<std::string,RealtimeTaskStatistics> task_statistics_;
    std::deque<Frame> network_queue_;
    std::optional<Frame> transmitting_;
    std::deque<Frame> propagation_queue_;
    RealtimeNetworkStatistics network_statistics_;
    std::uint64_t busy_network_us_ = 0;
    std::mt19937_64 random_{0xA5E1C0DEULL};
};

// -----------------------------------------------------------------------------
// Finite-volume one-dimensional compressible gas duct and crank-angle resolved
// combustion/gas-exchange engine model.
// -----------------------------------------------------------------------------

struct GasCellState {
    double density_kg_m3 = 1.18;
    double velocity_m_s = 0.0;
    double pressure_pa = 101325.0;
    double temperature_k = 298.15;
    double total_energy_j_m3 = 0.0;
};

struct GasDuctConfiguration {
    std::size_t cells = 24;
    double length_m = 0.8;
    double diameter_m = 0.055;
    double roughness_m = 1.0e-5;
    double wall_temperature_k = 350.0;
    double wall_heat_transfer_w_m2_k = 30.0;
    double gamma = 1.4;
    double gas_constant_j_kg_k = 287.05;
    double cfl = 0.45;
};

struct GasBoundaryCondition {
    double pressure_pa = 101325.0;
    double temperature_k = 298.15;
    double velocity_m_s = 0.0;
};

struct GasDuctState {
    std::vector<GasCellState> cells;
    double inlet_mass_flow_kg_s = 0.0;
    double outlet_mass_flow_kg_s = 0.0;
    double stored_mass_kg = 0.0;
    double stored_energy_j = 0.0;
    double cumulative_wall_heat_j = 0.0;
    double mass_residual_kg = 0.0;
    double energy_residual_j = 0.0;
};

class OneDimensionalGasDuct {
public:
    OneDimensionalGasDuct();
    explicit OneDimensionalGasDuct(GasDuctConfiguration configuration);
    void configure(const GasDuctConfiguration& configuration);
    void reset(double pressure_pa = 101325.0, double temperature_k = 298.15);
    const GasDuctState& step(double dt_s, const GasBoundaryCondition& inlet,
                             const GasBoundaryCondition& outlet);
    void exchange_with_cell(std::size_t cell, double mass_kg, double specific_enthalpy_j_kg,
                            double axial_momentum_kg_m_s);
    [[nodiscard]] const GasDuctState& state() const noexcept { return state_; }
    [[nodiscard]] double pressure_at(std::size_t cell) const;
    [[nodiscard]] double temperature_at(std::size_t cell) const;
    [[nodiscard]] std::string report() const;
private:
    GasDuctConfiguration configuration_;
    GasDuctState state_;
    std::vector<std::array<double,3>> conserved_;
    double reference_mass_kg_ = 0.0;
    double reference_energy_j_ = 0.0;
    double cumulative_boundary_mass_kg_ = 0.0;
    double cumulative_boundary_energy_j_ = 0.0;
    void synchronize_primitive();
};

struct CrankAngleEngineConfiguration {
    core::CylinderGeometry geometry;
    core::CombustionParameters combustion;
    GasDuctConfiguration intake_duct;
    GasDuctConfiguration exhaust_duct;
    double intake_valve_diameter_m = 0.032;
    double exhaust_valve_diameter_m = 0.028;
    double intake_max_lift_m = 0.0095;
    double exhaust_max_lift_m = 0.0085;
    double intake_open_deg = 350.0;
    double intake_close_deg = 590.0;
    double exhaust_open_deg = 130.0;
    double exhaust_close_deg = 375.0;
    double valve_discharge_coefficient = 0.72;
    double exhaust_backpressure_pa = 101325.0;
};

struct CrankAngleEngineInput {
    double rpm = 1500.0;
    double load = 0.5;
    double throttle = 0.5;
    double ambient_pressure_pa = 101325.0;
    double ambient_temperature_k = 298.15;
    double lambda = 1.0;
    double spark_deg_btdc = 12.0;
    double egr_fraction = 0.0;
    double fuel_lhv_j_kg = 42.7e6;
};

struct CrankAngleEngineState {
    double time_s = 0.0;
    double crank_angle_deg = 0.0;
    double indicated_torque_nm = 0.0;
    double torque_ripple_nm = 0.0;
    double intake_manifold_pressure_pa = 101325.0;
    double exhaust_manifold_pressure_pa = 101325.0;
    double intake_mass_flow_kg_s = 0.0;
    double exhaust_mass_flow_kg_s = 0.0;
    double fuel_flow_kg_s = 0.0;
    double indicated_power_w = 0.0;
    double exhaust_temperature_k = 700.0;
    double peak_cylinder_pressure_bar = 0.0;
    double knock_index = 0.0;
    double gas_mass_residual_kg = 0.0;
    double gas_energy_residual_j = 0.0;
    core::CylinderResolvedCombustionState combustion;
};

class CrankAngleGasDynamicsEngine {
public:
    CrankAngleGasDynamicsEngine();
    explicit CrankAngleGasDynamicsEngine(CrankAngleEngineConfiguration configuration);
    void configure(const CrankAngleEngineConfiguration& configuration);
    void reset(double ambient_pressure_pa = 101325.0, double ambient_temperature_k = 298.15);
    const CrankAngleEngineState& step(const CrankAngleEngineInput& input, double dt_s);
    [[nodiscard]] const CrankAngleEngineState& state() const noexcept { return state_; }
    [[nodiscard]] const OneDimensionalGasDuct& intake_duct() const noexcept { return intake_duct_; }
    [[nodiscard]] const OneDimensionalGasDuct& exhaust_duct() const noexcept { return exhaust_duct_; }
    [[nodiscard]] std::string report() const;
private:
    CrankAngleEngineConfiguration configuration_;
    CrankAngleEngineState state_;
    core::CylinderResolvedCombustionModel combustion_;
    OneDimensionalGasDuct intake_duct_;
    OneDimensionalGasDuct exhaust_duct_;
    double cycle_accumulator_deg_ = 0.0;
};

// -----------------------------------------------------------------------------
// Cell-resolved single-particle-equivalent electrochemistry with parallel-cell
// current sharing, electrolyte polarization, aging, cell-to-cell conduction,
// coolant heat transfer, internal shorts, and thermal-runaway propagation.
// -----------------------------------------------------------------------------

struct ElectrochemicalCellConfiguration {
    double capacity_ah = 5.0;
    double nominal_voltage_v = 3.65;
    double ohmic_resistance_ohm = 0.0032;
    double charge_transfer_resistance_ohm = 0.0018;
    double diffusion_time_constant_s = 75.0;
    double electrolyte_time_constant_s = 14.0;
    double electrolyte_capacitance_f = 1800.0;
    double thermal_capacity_j_k = 950.0;
    double surface_area_m2 = 0.065;
    double coolant_conductance_w_k = 2.8;
    double neighbor_conductance_w_k = 0.85;
    double sei_growth_coefficient = 2.0e-13;
    double plating_coefficient = 2.0e-10;
    double runaway_trigger_temperature_k = 423.15;
    double runaway_activation_temperature_k = 390.0;
    double runaway_heat_release_j = 420000.0;
    double vent_progress = 0.72;
};

struct ElectrochemicalPackConfiguration {
    std::size_t series_cells = 24;
    std::size_t parallel_cells = 2;
    ElectrochemicalCellConfiguration cell;
    double initial_soc = 0.80;
    double initial_temperature_k = 298.15;
    double minimum_cell_voltage_v = 2.7;
    double maximum_cell_voltage_v = 4.2;
    double maximum_cell_temperature_k = 333.15;
    double maximum_discharge_current_a = 500.0;
    double maximum_charge_current_a = 300.0;
};

struct ElectrochemicalCellState {
    double bulk_soc = 0.8;
    double surface_soc = 0.8;
    double electrolyte_overpotential_v = 0.0;
    double temperature_k = 298.15;
    double terminal_voltage_v = 3.8;
    double current_a = 0.0;
    double heat_generation_w = 0.0;
    double sei_thickness_m = 0.0;
    double lithium_plating_fraction = 0.0;
    double capacity_loss_fraction = 0.0;
    double resistance_growth_fraction = 0.0;
    double internal_short_resistance_ohm = 1.0e12;
    double runaway_progress = 0.0;
    bool vented = false;
};

struct ElectrochemicalPackInput {
    double requested_pack_current_a = 0.0; // positive discharge, negative charge
    double coolant_temperature_k = 298.15;
    double coolant_flow_fraction = 1.0;
    double ambient_temperature_k = 298.15;
};

struct ElectrochemicalPackState {
    double time_s = 0.0;
    double pack_voltage_v = 0.0;
    double pack_current_a = 0.0;
    double pack_power_w = 0.0;
    double mean_soc = 0.0;
    double minimum_cell_voltage_v = 0.0;
    double maximum_cell_voltage_v = 0.0;
    double minimum_cell_temperature_k = 0.0;
    double maximum_cell_temperature_k = 0.0;
    double available_discharge_current_a = 0.0;
    double available_charge_current_a = 0.0;
    double stored_electrochemical_energy_j = 0.0;
    double stored_thermal_energy_j = 0.0;
    double cumulative_electrical_energy_j = 0.0;
    double cumulative_heat_rejected_j = 0.0;
    double charge_residual_c = 0.0;
    double energy_residual_j = 0.0;
    std::size_t runaway_cells = 0;
    std::size_t vented_cells = 0;
    bool current_limited = false;
    bool thermal_propagation_active = false;
    std::vector<ElectrochemicalCellState> cells;
};

class CellResolvedElectrochemicalPack {
public:
    CellResolvedElectrochemicalPack();
    explicit CellResolvedElectrochemicalPack(ElectrochemicalPackConfiguration configuration);
    void configure(const ElectrochemicalPackConfiguration& configuration);
    void reset();
    const ElectrochemicalPackState& step(const ElectrochemicalPackInput& input, double dt_s);
    void set_internal_short(std::size_t series_index, std::size_t parallel_index,
                            double resistance_ohm);
    [[nodiscard]] const ElectrochemicalPackState& state() const noexcept { return state_; }
    [[nodiscard]] std::string report() const;
private:
    ElectrochemicalPackConfiguration configuration_;
    ElectrochemicalPackState state_;
    double initial_charge_c_ = 0.0;
    double cumulative_external_charge_c_ = 0.0;
    double initial_total_energy_j_ = 0.0;
    [[nodiscard]] std::size_t index(std::size_t series_index, std::size_t parallel_index) const;
    static double open_circuit_voltage(double soc, double temperature_k);
    static double open_circuit_energy_per_coulomb_integral(double soc);
};

// -----------------------------------------------------------------------------
// Automated bounded nonlinear calibration, cross-validation, covariance and
// prediction uncertainty, residual diagnostics, and parameter sensitivity.
// -----------------------------------------------------------------------------

struct AssuranceParameter {
    std::string name;
    double initial = 0.0;
    double lower = -1.0e30;
    double upper = 1.0e30;
    double finite_difference_step = 1.0e-4;
};

struct AssuranceObservation {
    std::vector<double> input;
    std::vector<double> observed;
    std::vector<double> sigma;
    std::string experiment;
};

struct ValidationMetrics {
    std::size_t samples = 0;
    double rmse = 0.0;
    double mae = 0.0;
    double maximum_absolute_error = 0.0;
    double r_squared = 0.0;
    double normalized_rmse = 0.0;
    double coverage_95 = 0.0;
    double residual_mean = 0.0;
    double residual_lag1_correlation = 0.0;
};

struct ParameterUncertainty {
    double estimate = 0.0;
    double standard_error = 0.0;
    double lower_95 = 0.0;
    double upper_95 = 0.0;
    double normalized_sensitivity = 0.0;
};

struct AutomatedAssuranceOptions {
    std::size_t maximum_iterations = 80;
    double initial_damping = 1.0e-2;
    double convergence_tolerance = 1.0e-8;
    std::size_t cross_validation_folds = 4;
    std::size_t uncertainty_samples = 500;
    std::uint64_t seed = 0xC411B4A7ULL;
};

struct AutomatedAssuranceResult {
    bool converged = false;
    std::size_t iterations = 0;
    double initial_cost = 0.0;
    double final_cost = 0.0;
    std::vector<double> calibrated_parameters;
    std::map<std::string,ParameterUncertainty> parameters;
    std::vector<std::vector<double>> covariance;
    ValidationMetrics calibration_metrics;
    ValidationMetrics cross_validation_metrics;
    std::vector<double> predictive_lower_95;
    std::vector<double> predictive_upper_95;
    std::vector<std::string> warnings;
};

class AutomatedCalibrationValidationUQ {
public:
    using Model = std::function<std::vector<double>(const std::vector<double>& parameters,
                                                     const std::vector<double>& input)>;

    AutomatedAssuranceResult run(const std::vector<AssuranceParameter>& parameters,
                                 const std::vector<AssuranceObservation>& observations,
                                 const Model& model,
                                 const AutomatedAssuranceOptions& options = {}) const;
    [[nodiscard]] static std::string report(const AutomatedAssuranceResult& result);
    static bool export_json(const AutomatedAssuranceResult& result, const std::string& path);
};

} // namespace aesim::high_fidelity

#pragma once

#include "aesim/high_fidelity/ecosystem.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <optional>
#include <random>
#include <string>
#include <vector>

namespace aesim::high_fidelity {

// Nonlinear crash structure and occupant restraints.
enum class ImpactDirection { Front, Rear, Left, Right, Rollover };
struct CrashZoneDefinition {
    std::string id; ImpactDirection direction = ImpactDirection::Front;
    double available_crush_m = 0.65; double initial_stiffness_n_m = 4.0e5;
    double hardening_n_m2 = 1.2e6; double damping_n_s_m = 2.5e4;
    double yield_force_n = 8.0e4; double mass_kg = 350.0;
};
struct OccupantDefinition {
    double mass_kg = 75.0; double pelvis_fraction = 0.52; double torso_fraction = 0.36;
    double head_fraction = 0.12; double belt_slack_m = 0.025; double belt_stiffness_n_m = 1.2e5;
    double belt_damping_n_s_m = 2200.0; double belt_load_limit_n = 6000.0;
    double pretensioner_time_s = 0.012; double pretensioner_retraction_m = 0.09;
    double airbag_trigger_deceleration_m_s2 = 35.0; double airbag_delay_s = 0.025;
    double airbag_stiffness_n_m = 4.0e4; double airbag_vent_damping_n_s_m = 1800.0;
};
struct CrashInput {
    bool contact = false; ImpactDirection direction = ImpactDirection::Front;
    double relative_speed_m_s = 0.0; double overlap_fraction = 1.0; double barrier_mass_kg = 1.0e12;
    double vehicle_mass_kg = 1900.0; double vehicle_speed_m_s = 0.0; double roll_rate_rad_s = 0.0;
};
struct OccupantInjuryState {
    double pelvis_excursion_m = 0.0; double torso_excursion_m = 0.0; double head_excursion_m = 0.0;
    double belt_force_n = 0.0; double airbag_force_n = 0.0; double head_acceleration_m_s2 = 0.0;
    double chest_acceleration_m_s2 = 0.0; double hic15 = 0.0; double chest_3ms_g = 0.0;
    double neck_injury_index = 0.0; bool pretensioner_fired = false; bool airbag_deployed = false;
};
struct CrashState {
    double time_s = 0.0; bool active = false; bool structure_bottomed = false;
    double crush_m = 0.0; double crush_velocity_m_s = 0.0; double impact_force_n = 0.0;
    double vehicle_acceleration_m_s2 = 0.0; double absorbed_energy_j = 0.0;
    double kinetic_energy_change_j = 0.0; double energy_residual_j = 0.0;
    double intrusion_m = 0.0; OccupantInjuryState occupant;
};
class NonlinearCrashOccupantSystem {
public:
    NonlinearCrashOccupantSystem();
    void configure_zone(CrashZoneDefinition zone); void configure_occupant(OccupantDefinition occupant);
    void reset(); const CrashState& step(const CrashInput& input, double dt_s);
    [[nodiscard]] const CrashState& state() const noexcept; [[nodiscard]] std::string report() const;
private:
    std::map<ImpactDirection,CrashZoneDefinition> zones_; OccupantDefinition occupant_; CrashState state_;
    double vehicle_velocity_m_s_ = 0.0; double pelvis_velocity_m_s_ = 0.0;
    double torso_velocity_m_s_ = 0.0; double head_velocity_m_s_ = 0.0;
    std::deque<std::pair<double,double>> head_acceleration_history_;
    bool previous_contact_ = false;
    double initial_impact_energy_j_ = 0.0;
    double impact_effective_mass_kg_ = 1.0;
};

// Battery vent gas, fire and enclosure-pressure propagation.
struct BatteryFireCellDefinition {
    double mass_kg = 0.78; double heat_capacity_j_kg_k = 1050.0; double surface_area_m2 = 0.035;
    double thermal_runaway_onset_k = 423.15; double vent_temperature_k = 393.15;
    double reaction_enthalpy_j_kg = 1.6e6; double gas_yield_kg_kg = 0.22;
    double activation_energy_j_mol = 8.2e4; double pre_exponential_1_s = 2.0e8;
};
struct BatteryFireInput {
    std::vector<double> external_heat_w; std::vector<double> electrical_heat_w;
    double cooling_temperature_k = 298.15; double cooling_conductance_w_k = 3.0;
    double ambient_pressure_pa = 101325.0; double vent_area_m2 = 0.0;
    double oxygen_mass_fraction = 0.21; bool ignition_source = false;
};
struct BatteryFireCellState {
    double temperature_k = 298.15; double reaction_progress = 0.0; double gas_generated_kg = 0.0; double gas_released_kg = 0.0;
    double remaining_reactive_mass_kg = 0.0; double internal_pressure_pa = 101325.0;
    bool vented = false; bool runaway = false; bool burning = false;
};
struct BatteryFireState {
    double time_s = 0.0; std::vector<BatteryFireCellState> cells;
    double enclosure_gas_mass_kg = 0.0; double enclosure_temperature_k = 298.15;
    double enclosure_pressure_pa = 101325.0; double vent_mass_flow_kg_s = 0.0;
    double heat_release_rate_w = 0.0; double cumulative_heat_release_j = 0.0;
    double toxic_gas_mass_kg = 0.0; double hydrogen_mass_kg = 0.0; double carbon_monoxide_mass_kg = 0.0;
    bool enclosure_ruptured = false; double energy_residual_j = 0.0;
};
class BatteryVentGasFireSystem {
public:
    explicit BatteryVentGasFireSystem(std::size_t cells = 24);
    void configure_cell(BatteryFireCellDefinition definition); void configure_enclosure(double volume_m3, double rupture_pressure_pa);
    void reset(double temperature_k = 298.15); void trigger_internal_short(std::size_t cell, double heat_w);
    void clear_internal_short(std::size_t cell); const BatteryFireState& step(const BatteryFireInput& input, double dt_s);
    [[nodiscard]] const BatteryFireState& state() const noexcept; [[nodiscard]] std::string report() const;
private:
    BatteryFireCellDefinition definition_; BatteryFireState state_; double enclosure_volume_m3_ = 0.16;
    double rupture_pressure_pa_ = 220000.0; std::vector<double> short_heat_w_; double stored_energy_reference_j_ = 0.0;
    double input_energy_integral_j_ = 0.0; double output_energy_integral_j_ = 0.0;
};

// Reduced-order 3D CFD and conjugate heat transfer.
struct CfdModeDefinition {
    std::string id; double decay_rate_1_s = 1.0; double input_gain = 1.0;
    std::vector<double> velocity_x_shape; std::vector<double> velocity_y_shape; std::vector<double> velocity_z_shape;
    std::vector<double> temperature_shape;
};
struct CfdCellDefinition { Vec3d center_m{}; double volume_m3 = 0.01; double solid_heat_capacity_j_k = 0.0; double wall_conductance_w_k = 0.0; };
struct CfdInput { double inlet_mass_flow_kg_s = 0.0; double inlet_temperature_k = 298.15; Vec3d freestream_velocity_m_s{}; double heat_source_w = 0.0; double fan_command = 0.0; };
struct CfdCellState { Vec3d velocity_m_s{}; double fluid_temperature_k = 298.15; double solid_temperature_k = 298.15; double pressure_pa = 101325.0; double heat_flux_w = 0.0; };
struct ReducedOrderCfdState {
    double time_s = 0.0; std::vector<double> modal_coordinates; std::vector<CfdCellState> cells;
    double pressure_drop_pa = 0.0; double outlet_temperature_k = 298.15; double captured_mass_flow_kg_s = 0.0;
    double convective_heat_transfer_w = 0.0; double stored_energy_j = 0.0; double energy_residual_j = 0.0;
};
class ReducedOrderCfdChtSystem {
public:
    ReducedOrderCfdChtSystem(); void configure_cells(std::vector<CfdCellDefinition> cells);
    void configure_modes(std::vector<CfdModeDefinition> modes); void reset(double temperature_k = 298.15);
    const ReducedOrderCfdState& step(const CfdInput& input, double dt_s);
    [[nodiscard]] const ReducedOrderCfdState& state() const noexcept; [[nodiscard]] std::string report() const;
private:
    std::vector<CfdCellDefinition> definitions_; std::vector<CfdModeDefinition> modes_; ReducedOrderCfdState state_;
    double reference_energy_j_ = 0.0; double net_energy_integral_j_ = 0.0;
};

// Unified lubrication, tribology, friction and wear.
enum class TribologyContactKind { JournalBearing, RollingBearing, GearMesh, PistonRing, CamFollower, Clutch, Seal, CvJoint };
struct TribologyContactDefinition {
    std::string id; TribologyContactKind kind = TribologyContactKind::JournalBearing;
    double effective_radius_m = 0.025; double contact_width_m = 0.02; double roughness_rms_m = 0.3e-6;
    double hardness_pa = 5.0e9; double wear_coefficient = 1.0e-8; double boundary_friction = 0.12;
    double mixed_friction = 0.06; double hydrodynamic_friction = 0.015; double thermal_capacity_j_k = 1500.0;
};
struct TribologyLoad { std::string id; double normal_load_n = 0.0; double sliding_speed_m_s = 0.0; double rolling_speed_m_s = 0.0; double supplied_oil_flow_kg_s = 0.0; };
struct TribologyInput { std::vector<TribologyLoad> loads; double oil_temperature_k = 363.15; double oil_pressure_pa = 350000.0; double contamination_ppm = 0.0; double water_fraction = 0.0; };
struct TribologyContactState {
    double film_thickness_m = 0.0; double lambda_ratio = 0.0; double friction_coefficient = 0.0;
    double friction_force_n = 0.0; double friction_power_w = 0.0; double flash_temperature_k = 0.0;
    double wear_depth_m = 0.0; double debris_mass_kg = 0.0; double scuffing_risk = 0.0; double pitting_damage = 0.0;
};
struct TribologyState { double time_s = 0.0; std::map<std::string,TribologyContactState> contacts; double oil_viscosity_pa_s = 0.0; double oil_degradation = 0.0; double total_friction_power_w = 0.0; double total_debris_mass_kg = 0.0; };
class UnifiedTribologyWearSystem {
public:
    UnifiedTribologyWearSystem(); void add_contact(TribologyContactDefinition definition); void clear(); void reset();
    const TribologyState& step(const TribologyInput& input, double dt_s);
    [[nodiscard]] const TribologyState& state() const noexcept; [[nodiscard]] std::string report() const;
private: std::map<std::string,TribologyContactDefinition> definitions_; TribologyState state_; };


// Vehicle-wide lubrication/hydraulic fluid network feeding the tribology layer.
enum class LubricationNodeKind { Reservoir, Junction, BearingFeed, PistonJet, TurboFeed, VvtActuator, Cooler, Filter, Accumulator, Return };
enum class LubricationEdgeKind { Pipe, Pump, Restrictor, ReliefValve, CheckValve, Orifice, ScavengePump };
struct LubricationFluidProperties {
    double density_kg_m3 = 850.0;
    double reference_viscosity_pa_s = 0.012;
    double reference_temperature_k = 373.15;
    double viscosity_temperature_coefficient_1_k = 0.028;
    double vapor_pressure_pa = 5000.0;
    double bulk_modulus_pa = 1.4e9;
    double specific_heat_j_kg_k = 2000.0;
    void validate() const;
};
struct LubricationNodeDefinition {
    std::string id; LubricationNodeKind kind = LubricationNodeKind::Junction;
    double elevation_m = 0.0; double volume_m3 = 1.0e-4; double initial_pressure_pa = 101325.0;
    double initial_temperature_k = 363.15; double demanded_flow_kg_s = 0.0; double heat_load_w = 0.0;
};
struct LubricationEdgeDefinition {
    std::string id; LubricationEdgeKind kind = LubricationEdgeKind::Pipe; std::string from_node; std::string to_node;
    double length_m = 0.5; double diameter_m = 0.008; double roughness_m = 1.0e-5; double flow_coefficient = 1.0;
    double pump_displacement_m3_rev = 1.0e-6; double pump_speed_rpm = 0.0; double pump_efficiency = 0.80;
    double cracking_pressure_pa = 0.0; double maximum_flow_kg_s = 10.0;
};
struct LubricationNetworkInput {
    double ambient_temperature_k = 298.15; double acceleration_x_m_s2 = 0.0; double acceleration_y_m_s2 = 0.0;
    double acceleration_z_m_s2 = 9.80665; double reservoir_fill_fraction = 1.0; double entrained_air_fraction = 0.0;
    std::map<std::string,double> pump_speed_rpm_override; std::map<std::string,double> demand_flow_kg_s_override;
};
struct LubricationNodeState {
    double pressure_pa = 101325.0; double temperature_k = 363.15; double supplied_flow_kg_s = 0.0;
    double demanded_flow_kg_s = 0.0; double starvation_fraction = 0.0; double cavitation_fraction = 0.0;
};
struct LubricationEdgeState {
    double mass_flow_kg_s = 0.0; double pressure_drop_pa = 0.0; double reynolds_number = 0.0;
    double hydraulic_power_w = 0.0; double cavitation_fraction = 0.0;
};
struct LubricationNetworkState {
    double time_s = 0.0; std::map<std::string,LubricationNodeState> nodes; std::map<std::string,LubricationEdgeState> edges;
    double oil_viscosity_pa_s = 0.0; double entrained_air_fraction = 0.0; double minimum_supply_margin = 1.0;
    double total_pump_power_w = 0.0; double total_heat_to_oil_w = 0.0; double mass_balance_residual_kg_s = 0.0;
    bool cavitating = false; bool starved = false;
};
class LubricationHydraulicNetwork {
public:
    explicit LubricationHydraulicNetwork(LubricationFluidProperties fluid = {});
    void add_node(LubricationNodeDefinition node); void add_edge(LubricationEdgeDefinition edge); void clear();
    void reset(double temperature_k = 363.15); const LubricationNetworkState& step(const LubricationNetworkInput& input, double dt_s);
    [[nodiscard]] const LubricationNetworkState& state() const noexcept; [[nodiscard]] std::string report() const;
private:
    LubricationFluidProperties fluid_; std::map<std::string,LubricationNodeDefinition> nodes_;
    std::map<std::string,LubricationEdgeDefinition> edges_; LubricationNetworkState state_;
};

// Structural acoustics, NVH and psychoacoustics.
struct NvhModeDefinition { std::string id; double natural_frequency_hz = 100.0; double damping_ratio = 0.03; double modal_mass_kg = 10.0; double acoustic_radiation_gain = 0.01; };
struct NvhExcitation { std::string source; double frequency_hz = 0.0; double force_rms_n = 0.0; double phase_rad = 0.0; std::map<std::string,double> participation; };
struct NvhInput { std::vector<NvhExcitation> excitations; double vehicle_speed_m_s = 0.0; double cabin_background_pa = 2.0e-5; double sample_rate_hz = 2000.0; };
struct NvhModeState { double displacement_m = 0.0; double velocity_m_s = 0.0; double acceleration_m_s2 = 0.0; double sound_pressure_pa = 0.0; };
struct NvhState {
    double time_s = 0.0; std::map<std::string,NvhModeState> modes; double overall_spl_db = 0.0;
    double a_weighted_spl_db = 0.0; double loudness_sone = 0.0; double sharpness_acum = 0.0;
    double roughness_asper = 0.0; double tonality = 0.0; double steering_wheel_rms_m_s2 = 0.0;
    double seat_rail_rms_m_s2 = 0.0; double ride_comfort_index = 0.0;
};
class StructuralAcousticsNvhSystem {
public:
    void add_mode(NvhModeDefinition mode); void clear(); void reset(); const NvhState& step(const NvhInput& input, double dt_s);
    [[nodiscard]] const NvhState& state() const noexcept; [[nodiscard]] std::string report() const;
private: std::map<std::string,NvhModeDefinition> definitions_; NvhState state_; };

// Power electronics degradation and semiconductor lifetime.
enum class SemiconductorKind { Igbt, SiliconMosfet, SicMosfet, GanHemt, Diode, Capacitor };
struct PowerDeviceDefinition { std::string id; SemiconductorKind kind = SemiconductorKind::SicMosfet; double rated_current_a = 500.0; double rated_voltage_v = 1200.0; double thermal_resistance_k_w = 0.08; double thermal_capacity_j_k = 120.0; double nominal_life_cycles = 2.0e6; double activation_energy_j_mol = 7.0e4; };
struct PowerDeviceLoad { std::string id; double current_rms_a = 0.0; double voltage_v = 0.0; double switching_frequency_hz = 10000.0; double conduction_loss_w = 0.0; double switching_loss_w = 0.0; double coolant_temperature_k = 323.15; };
struct PowerDeviceState { double junction_temperature_k = 323.15; double case_temperature_k = 323.15; double bond_wire_damage = 0.0; double solder_damage = 0.0; double gate_oxide_damage = 0.0; double on_resistance_growth = 0.0; double failure_probability = 0.0; double remaining_life_h = 1.0e9; bool failed_open = false; bool failed_short = false; };
struct PowerElectronicsLifetimeState { double time_s = 0.0; std::map<std::string,PowerDeviceState> devices; double minimum_remaining_life_h = 1.0e9; double maximum_failure_probability = 0.0; };
class PowerElectronicsLifetimeSystem {
public:
    void add_device(PowerDeviceDefinition definition); void clear(); void reset(double temperature_k = 323.15);
    const PowerElectronicsLifetimeState& step(const std::vector<PowerDeviceLoad>& loads, double dt_s);
    [[nodiscard]] const PowerElectronicsLifetimeState& state() const noexcept; [[nodiscard]] std::string report() const;
private: std::map<std::string,PowerDeviceDefinition> definitions_; PowerElectronicsLifetimeState state_; std::map<std::string,double> previous_junction_k_; };

// Water ingress, contamination, corrosion and icing.
struct ExposureComponentDefinition { std::string id; double exposed_area_m2 = 0.1; double seal_leak_coefficient_kg_s_pa = 1.0e-10; double drainage_rate_1_s = 0.01; double corrosion_allowance_m = 1.0e-3; double nominal_insulation_ohm = 1.0e8; double ice_shedding_acceleration_m_s2 = 20.0; };
struct ExposureInput { double rain_rate_mm_h = 0.0; double splash_pressure_pa = 0.0; double ambient_temperature_k = 298.15; double humidity_fraction = 0.5; double road_salt_kg_m3 = 0.0; double dust_kg_m3 = 0.0; double vehicle_acceleration_m_s2 = 0.0; double deicing_heat_w = 0.0; };
struct ExposureComponentState { double liquid_water_kg = 0.0; double ice_mass_kg = 0.0; double salt_mass_kg = 0.0; double dust_mass_kg = 0.0; double corrosion_depth_m = 0.0; double insulation_resistance_ohm = 1.0e8; double connector_resistance_ohm = 1.0e-3; double blockage_fraction = 0.0; bool ingress_fault = false; bool frozen = false; };
struct EnvironmentalExposureState { double time_s = 0.0; std::map<std::string,ExposureComponentState> components; double maximum_blockage_fraction = 0.0; double minimum_insulation_ohm = 1.0e12; double maximum_corrosion_fraction = 0.0; };
class EnvironmentalIngressCorrosionIcingSystem {
public:
    void add_component(ExposureComponentDefinition definition); void clear(); void reset();
    const EnvironmentalExposureState& step(const ExposureInput& input, double dt_s);
    [[nodiscard]] const EnvironmentalExposureState& state() const noexcept; [[nodiscard]] std::string report() const;
private: std::map<std::string,ExposureComponentDefinition> definitions_; EnvironmentalExposureState state_; };

// Detailed steering mechanics and road feel.
struct SteeringConfiguration { double ratio = 15.0; double wheel_inertia_kg_m2 = 0.035; double column_stiffness_nm_rad = 85.0; double column_damping_nm_s_rad = 1.6; double rack_mass_kg = 4.2; double rack_stiffness_n_m = 2.5e5; double rack_damping_n_s_m = 2400.0; double rack_travel_per_wheel_rad_m = 0.055; double eps_torque_limit_nm = 10.0; double eps_power_limit_w = 800.0; double friction_nm = 0.45; double backlash_rad = 0.002; };
struct SteeringInput { double driver_torque_nm = 0.0; double assist_command_nm = 0.0; double left_aligning_moment_nm = 0.0; double right_aligning_moment_nm = 0.0; double vehicle_speed_m_s = 0.0; double supply_voltage_v = 12.0; double ambient_temperature_k = 298.15; };
struct SteeringState { double time_s = 0.0; double steering_wheel_angle_rad = 0.0; double column_twist_rad = 0.0; double rack_position_m = 0.0; double road_wheel_angle_rad = 0.0; double driver_torque_nm = 0.0; double assist_torque_nm = 0.0; double road_feedback_torque_nm = 0.0; double eps_current_a = 0.0; double eps_temperature_k = 298.15; double steering_effort_nm = 0.0; double kickback_nm = 0.0; double on_center_gradient_nm_rad = 0.0; double energy_residual_j = 0.0; };
class DetailedSteeringRoadFeelSystem {
public:
    DetailedSteeringRoadFeelSystem(); explicit DetailedSteeringRoadFeelSystem(SteeringConfiguration configuration);
    void configure(SteeringConfiguration configuration); void reset(); const SteeringState& step(const SteeringInput& input, double dt_s);
    [[nodiscard]] const SteeringState& state() const noexcept; [[nodiscard]] std::string report() const;
private: SteeringConfiguration configuration_; SteeringState state_; double wheel_velocity_rad_s_ = 0.0; double rack_velocity_m_s_ = 0.0; double input_energy_j_ = 0.0; double dissipated_energy_j_ = 0.0; };

// Predictive energy, thermal and chassis control.
struct RoutePreviewPoint { double distance_m = 0.0; double grade = 0.0; double curvature_1_m = 0.0; double speed_limit_m_s = 30.0; double traffic_speed_m_s = 30.0; double ambient_temperature_k = 298.15; };
struct PredictiveControlInput { double speed_m_s = 0.0; double target_speed_m_s = 0.0; double battery_soc = 0.7; double battery_temperature_k = 303.15; double cabin_temperature_k = 295.15; double motor_temperature_k = 323.15; double road_friction = 1.0; double lateral_acceleration_m_s2 = 0.0; std::vector<RoutePreviewPoint> route; };
struct PredictiveControlState { double time_s = 0.0; double wheel_torque_command_nm = 0.0; double regenerative_brake_fraction = 0.0; double cooling_pump_command = 0.0; double fan_command = 0.0; double active_suspension_gain = 0.0; double ride_height_command_m = 0.0; double predicted_energy_j = 0.0; double predicted_battery_damage = 0.0; double predicted_comfort_cost = 0.0; double objective = 0.0; std::size_t evaluated_candidates = 0; };
class PredictiveVehicleController {
public:
    void reset(); void configure_horizon(double horizon_s, double step_s); const PredictiveControlState& step(const PredictiveControlInput& input, double dt_s);
    [[nodiscard]] const PredictiveControlState& state() const noexcept; [[nodiscard]] std::string report() const;
private: PredictiveControlState state_; double horizon_s_ = 5.0; double prediction_step_s_ = 0.5; };

// Complete autonomous perception, prediction, planning and control.
enum class AutonomousMode { Disabled, Standby, Active, Degraded, EmergencyStop };
struct AutonomousObjectMeasurement { std::string id; double x_m = 0.0; double y_m = 0.0; double vx_m_s = 0.0; double vy_m_s = 0.0; double covariance_x_m2 = 1.0; double covariance_y_m2 = 1.0; double confidence = 1.0; TrafficAgentKind kind = TrafficAgentKind::PassengerCar; };
struct AutonomousInput { double ego_x_m = 0.0; double ego_y_m = 0.0; double ego_heading_rad = 0.0; double ego_speed_m_s = 0.0; double target_speed_m_s = 25.0; double lane_center_y_m = 0.0; double lane_width_m = 3.6; double road_curvature_1_m = 0.0; double road_friction = 1.0; bool inside_odd = true; double sensor_quality = 1.0; std::vector<AutonomousObjectMeasurement> measurements; };
struct AutonomousTrack { std::string id; double x_m = 0.0; double y_m = 0.0; double vx_m_s = 0.0; double vy_m_s = 0.0; double ax_m_s2 = 0.0; double ay_m_s2 = 0.0; double covariance = 1.0; double confidence = 0.0; double age_s = 0.0; std::vector<Vec3d> predicted_trajectory; };
struct PlannedTrajectoryPoint { double time_s = 0.0; double x_m = 0.0; double y_m = 0.0; double speed_m_s = 0.0; double acceleration_m_s2 = 0.0; double curvature_1_m = 0.0; };
struct AutonomousState { double time_s = 0.0; AutonomousMode mode = AutonomousMode::Disabled; std::vector<AutonomousTrack> tracks; std::vector<PlannedTrajectoryPoint> trajectory; double steering_command_rad = 0.0; double acceleration_command_m_s2 = 0.0; double throttle_command = 0.0; double brake_command = 0.0; double minimum_predicted_clearance_m = 1.0e9; double time_to_collision_s = 1.0e9; double plan_cost = 0.0; bool emergency_braking = false; std::size_t candidate_trajectories = 0; };
class CompleteAutonomousDrivingStack {
public:
    void reset(); void set_mode(AutonomousMode mode); const AutonomousState& step(const AutonomousInput& input, double dt_s);
    [[nodiscard]] const AutonomousState& state() const noexcept; [[nodiscard]] std::string report() const;
private: AutonomousState state_; std::map<std::string,AutonomousTrack> tracks_; };

// Fully integrated lifecycle runtime.
struct IntegratedLifecycleInput {
    IntegratedEcosystemInput ecosystem{}; CrashInput crash{}; BatteryFireInput battery_fire{};
    CfdInput cfd{}; TribologyInput tribology{}; NvhInput nvh{}; ExposureInput exposure{};
    SteeringInput steering{}; PredictiveControlInput predictive{}; AutonomousInput autonomy{};
    bool predictive_control_enabled = true; bool autonomy_enabled = true;
};
struct IntegratedLifecycleState {
    double time_s = 0.0; IntegratedEcosystemState ecosystem{}; double crash_severity = 0.0;
    double battery_fire_pressure_pa = 101325.0; double fire_heat_release_w = 0.0;
    double cfd_outlet_temperature_k = 298.15; double tribology_friction_power_w = 0.0;
    double cabin_spl_db = 0.0; double power_electronics_minimum_life_h = 1.0e9;
    double environmental_maximum_corrosion_fraction = 0.0; double steering_effort_nm = 0.0;
    double predictive_objective = 0.0; AutonomousMode autonomous_mode = AutonomousMode::Disabled;
    double autonomous_clearance_m = 1.0e9; double aggregate_energy_residual_j = 0.0;
};
class IntegratedVehicleLifecycleRuntime {
public:
    IntegratedVehicleLifecycleRuntime(); void reset(double ambient_temperature_k = 298.15);
    void set_input(const IntegratedLifecycleInput& input); const IntegratedLifecycleState& advance(double dt_s);
    void set_autonomous_mode(AutonomousMode mode); void trigger_battery_short(std::size_t cell, double heat_w);
    void clear_battery_short(std::size_t cell); [[nodiscard]] const IntegratedLifecycleInput& input() const noexcept;
    [[nodiscard]] const IntegratedLifecycleState& state() const noexcept; [[nodiscard]] std::string status() const;
    [[nodiscard]] IntegratedVehicleEcosystemRuntime& ecosystem() noexcept; [[nodiscard]] NonlinearCrashOccupantSystem& crash() noexcept;
    [[nodiscard]] BatteryVentGasFireSystem& battery_fire() noexcept; [[nodiscard]] ReducedOrderCfdChtSystem& cfd() noexcept;
    [[nodiscard]] UnifiedTribologyWearSystem& tribology() noexcept; [[nodiscard]] StructuralAcousticsNvhSystem& nvh() noexcept;
    [[nodiscard]] PowerElectronicsLifetimeSystem& power_electronics_lifetime() noexcept;
    [[nodiscard]] EnvironmentalIngressCorrosionIcingSystem& exposure() noexcept; [[nodiscard]] DetailedSteeringRoadFeelSystem& steering() noexcept;
    [[nodiscard]] PredictiveVehicleController& predictive_controller() noexcept; [[nodiscard]] CompleteAutonomousDrivingStack& autonomy() noexcept;
private:
    IntegratedLifecycleInput input_{}; IntegratedLifecycleState state_{}; IntegratedVehicleEcosystemRuntime ecosystem_;
    NonlinearCrashOccupantSystem crash_; BatteryVentGasFireSystem battery_fire_; ReducedOrderCfdChtSystem cfd_;
    UnifiedTribologyWearSystem tribology_; StructuralAcousticsNvhSystem nvh_; PowerElectronicsLifetimeSystem lifetime_;
    EnvironmentalIngressCorrosionIcingSystem exposure_; DetailedSteeringRoadFeelSystem steering_;
    PredictiveVehicleController predictive_; CompleteAutonomousDrivingStack autonomy_;
    void configure_defaults(); void update_autonomous_measurements();
};

[[nodiscard]] AutonomousMode parse_autonomous_mode(const std::string& text);
[[nodiscard]] ImpactDirection parse_impact_direction(const std::string& text);
[[nodiscard]] std::string to_string(AutonomousMode value);
[[nodiscard]] std::string to_string(ImpactDirection value);

} // namespace aesim::high_fidelity

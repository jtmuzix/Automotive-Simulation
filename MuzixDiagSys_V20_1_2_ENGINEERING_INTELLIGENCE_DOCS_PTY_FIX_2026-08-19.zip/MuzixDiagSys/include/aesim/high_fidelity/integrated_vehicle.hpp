#pragma once

#include "aesim/high_fidelity/vehicle_systems.hpp"

#include <array>
#include <cstddef>
#include <optional>
#include <string>
#include <vector>

namespace aesim::high_fidelity {

struct IntegratedVehicleInput {
    double engine_rpm = 0.0;
    double engine_torque_nm = 0.0;
    double requested_wheel_torque_nm = 0.0;
    double brake_fraction = 0.0;
    double vehicle_speed_m_s = 0.0;
    double vehicle_acceleration_m_s2 = 0.0;
    double steering_angle_rad = 0.0;
    double lateral_acceleration_m_s2 = 0.0;
    double ambient_temperature_k = 298.15;
    double ambient_pressure_pa = 101325.0;
    double road_friction = 1.0;
    double road_grade_rad = 0.0;
    double road_roughness_m = 0.002;
    double road_water_depth_m = 0.0;
    double road_loose_depth_m = 0.0;
    double gear_ratio = 3.0;
    double battery_current_override_a = 0.0;
    bool use_battery_current_override = false;

    // Chamber, vibration-table, contamination, supply, radiation, and EMC
    // conditions are explicit runtime inputs so sensor degradation is both
    // calibratable and deterministic under checkpoint/replay execution.
    double relative_humidity = 0.50;
    double sensor_vibration_rms_m_s2 = 0.0;
    double sensor_contamination_fraction = 0.0;
    double sensor_radiation_dose_rate_gy_s = 0.0;
    double sensor_supply_voltage_v = 5.0;
    double sensor_electromagnetic_field_v_m = 0.0;
};

struct IntegratedVehicleState {
    double time_s = 0.0;
    double travelled_distance_m = 0.0;
    double measured_vehicle_speed_m_s = 0.0;
    double measured_engine_rpm = 0.0;
    double estimated_longitudinal_force_n = 0.0;
    double estimated_acceleration_m_s2 = 0.0;
    double total_tire_longitudinal_force_n = 0.0;
    double total_tire_lateral_force_n = 0.0;
    double total_vertical_load_n = 0.0;
    double aggregate_conservation_severity = 0.0;
    std::uint64_t conservation_tolerance_violations = 0;
    std::size_t recorded_calibration_observations = 0;
};

class IntegratedHighFidelityVehicle {
public:
    IntegratedHighFidelityVehicle();
    ~IntegratedHighFidelityVehicle();

    void reset(double ambient_temperature_k = 298.15);
    void set_input(const IntegratedVehicleInput& input);
    const IntegratedVehicleState& advance(double dt_s);

    void add_sensor_fault(const std::string& sensor_name, const SensorFaultEvent& fault);
    void clear_sensor_faults();
    void set_internal_battery_short(std::size_t series_index, std::size_t parallel_index,
                                    double resistance_ohm);

    AutomatedAssuranceResult calibrate_road_load(
        const AutomatedAssuranceOptions& options = {});
    [[nodiscard]] const std::optional<AutomatedAssuranceResult>& last_assurance() const noexcept;
    bool export_last_assurance(const std::string& path) const;

    [[nodiscard]] const IntegratedVehicleInput& input() const noexcept { return input_; }
    [[nodiscard]] const IntegratedVehicleState& state() const noexcept { return state_; }
    [[nodiscard]] const ConservativeMultiRateSolver& solver() const noexcept { return solver_; }
    [[nodiscard]] const MultibodySuspensionSystem& suspension() const noexcept { return suspension_; }
    [[nodiscard]] const std::array<FlexibleRingTire,4>& tires() const noexcept { return tires_; }
    [[nodiscard]] const TorsionalDriveline& driveline() const noexcept { return driveline_; }
    [[nodiscard]] const DistributedVehicleThermalNetwork& thermal() const noexcept { return thermal_; }
    [[nodiscard]] const SensorFaultInjectionSuite& sensors() const noexcept { return sensors_; }
    [[nodiscard]] const RealtimeEcuNetworkSimulator& ecu_network() const noexcept { return ecu_network_; }
    [[nodiscard]] const CrankAngleGasDynamicsEngine& engine() const noexcept { return engine_; }
    [[nodiscard]] const CellResolvedElectrochemicalPack& battery() const noexcept { return battery_; }
    [[nodiscard]] std::string status() const;

private:
    IntegratedVehicleInput input_;
    IntegratedVehicleState state_;
    ConservativeMultiRateSolver solver_;
    MultibodySuspensionSystem suspension_;
    std::array<FlexibleRingTire,4> tires_;
    TorsionalDriveline driveline_;
    DistributedVehicleThermalNetwork thermal_;
    SensorFaultInjectionSuite sensors_;
    RealtimeEcuNetworkSimulator ecu_network_;
    CrankAngleGasDynamicsEngine engine_;
    CellResolvedElectrochemicalPack battery_;
    AutomatedCalibrationValidationUQ assurance_;
    std::optional<AutomatedAssuranceResult> last_assurance_;
    std::vector<AssuranceObservation> road_load_observations_;
    double previous_observation_speed_m_s_ = 0.0;
    bool observation_initialized_ = false;
    double road_phase_m_ = 0.0;
    std::array<std::array<RoadContactSample,11>,4> road_profiles_{};
    std::array<double,4> previous_road_height_m_{};
    std::array<double,4> wheel_angular_speed_rad_s_{};
    std::array<double,4> wheel_normal_load_n_{{4200.0,4200.0,3900.0,3900.0}};
    std::array<double,4> tire_longitudinal_force_n_{};
    std::array<double,4> tire_lateral_force_n_{};
    std::array<UncertainSensorChannel*,4> sensor_channels_{};
    std::vector<std::size_t> task_ids_;

    void configure_default_sensors();
    void configure_default_ecus();
    void configure_solver_tasks();
    void record_calibration_observation(double dt_s);
    void update_aggregate_state();
    void update_road_profiles() noexcept;
    [[nodiscard]] ConservationState engine_conservation() const;
    [[nodiscard]] ConservationState chassis_conservation() const;
    [[nodiscard]] ConservationState driveline_conservation() const;
    [[nodiscard]] ConservationState battery_conservation() const;
    [[nodiscard]] ConservationState thermal_conservation() const;
};

} // namespace aesim::high_fidelity

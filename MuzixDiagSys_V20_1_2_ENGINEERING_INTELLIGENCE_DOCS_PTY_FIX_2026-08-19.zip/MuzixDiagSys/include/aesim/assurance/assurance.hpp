#pragma once

#include "aesim/assurance/resilience.hpp"
#include "aesim/industrial/network.hpp"
#include "aesim/industrial/signals.hpp"
#include "aesim/industrial/traceability.hpp"
#include "aesim/professional/document.hpp"

#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

struct sqlite3;

namespace aesim::assurance {

struct XmlNode {
    std::string name;
    std::map<std::string, std::string> attributes;
    std::string text;
    std::vector<XmlNode> children;
    [[nodiscard]] const XmlNode* first(const std::string& local_name) const;
    [[nodiscard]] std::vector<const XmlNode*> all(const std::string& local_name) const;
};
[[nodiscard]] XmlNode parse_xml(const std::string& xml);
[[nodiscard]] std::string xml_escape(const std::string& value);

struct Runnable {
    std::string name;
    std::uint64_t period_ns = 0;
    std::uint64_t next_release_ns = 0;
    std::vector<std::string> reads;
    std::vector<std::string> writes;
    std::string operation;
    std::uint64_t invocations = 0;
};
struct AutosarModel {
    std::string software_component;
    std::vector<std::string> provided_ports;
    std::vector<std::string> required_ports;
    std::vector<Runnable> runnables;
};
class VirtualRte {
public:
    AutosarModel import_arxml(const std::string& path);
    void write(const std::string& data_element, double value);
    [[nodiscard]] double read(const std::string& data_element) const;
    void tick(std::uint64_t now_ns);
    void com_receive(const std::string& pdu, const std::map<std::string,double>& values);
    [[nodiscard]] std::map<std::string,double> com_transmit(const std::string& pdu) const;
    void dem_report(const std::string& event, bool failed);
    [[nodiscard]] bool dem_failed(const std::string& event) const;
    void nvm_write(const std::string& block, const std::vector<std::uint8_t>& data);
    [[nodiscard]] std::vector<std::uint8_t> nvm_read(const std::string& block) const;
    void watchdog_checkpoint(const std::string& supervised_entity, std::uint64_t now_ns);
    [[nodiscard]] std::string watchdog_status(std::uint64_t now_ns, std::uint64_t deadline_ns) const;
    [[nodiscard]] std::string status() const;
private:
    AutosarModel model_;
    std::map<std::string,double> data_;
    std::map<std::string,std::vector<std::string>> pdu_signals_;
    std::map<std::string,bool> dem_;
    std::map<std::string,std::vector<std::uint8_t>> nvm_;
    std::map<std::string,std::uint64_t> watchdog_;
};

struct OdxService { std::string name; std::uint8_t sid = 0; std::vector<std::uint8_t> request_prefix; };
class DiagnosticWorkbench {
public:
    void import_odx(const std::string& path);
    [[nodiscard]] std::vector<std::uint8_t> invoke(const std::string& service, const std::vector<std::uint8_t>& payload, industrial::AutomotiveNetwork& network) const;
    [[nodiscard]] std::string run_otx(const std::string& path, VirtualRte& rte, industrial::AutomotiveNetwork& network);
    [[nodiscard]] static std::vector<std::uint8_t> doip_packet(std::uint16_t payload_type, const std::vector<std::uint8_t>& payload);
    [[nodiscard]] static std::pair<std::uint16_t,std::vector<std::uint8_t>> parse_doip(const std::vector<std::uint8_t>& packet);
    [[nodiscard]] std::string sovd_request(const std::string& method, const std::string& resource, const doc::Value& body = {});
    [[nodiscard]] std::string status() const;
private:
    std::map<std::string,OdxService> services_;
    std::map<std::string,doc::Value> sovd_resources_;
};

struct SomeIpMessage {
    std::uint16_t service_id=0, method_id=0, client_id=0, session_id=0;
    std::uint8_t interface_version=1, message_type=0, return_code=0;
    std::vector<std::uint8_t> payload;
};
[[nodiscard]] std::vector<std::uint8_t> encode_someip(const SomeIpMessage& message);
[[nodiscard]] SomeIpMessage decode_someip(const std::vector<std::uint8_t>& bytes);
class AdaptiveRuntime {
public:
    void bind_network_fault_laboratory(industrial::NetworkFaultLaboratory* laboratory);
    void offer(std::uint16_t service, std::uint16_t instance, std::uint8_t major, std::uint32_t ttl_ms);
    void stop_offer(std::uint16_t service, std::uint16_t instance);
    [[nodiscard]] bool available(std::uint16_t service, std::uint16_t instance) const;
    [[nodiscard]] SomeIpMessage call(const SomeIpMessage& request);
    void publish(std::uint16_t service, std::uint16_t event, std::vector<std::uint8_t> payload);
    [[nodiscard]] std::optional<SomeIpMessage> last_event(std::uint16_t service, std::uint16_t event) const;
    [[nodiscard]] std::string status() const;
private:
    struct Service { std::uint8_t major=1; std::uint32_t ttl_ms=0; std::uint64_t calls=0; };
    std::map<std::pair<std::uint16_t,std::uint16_t>,Service> services_;
    std::map<std::pair<std::uint16_t,std::uint16_t>,SomeIpMessage> events_;
    industrial::NetworkFaultLaboratory* network_fault_laboratory_ = nullptr;
};

struct SecuredPdu { std::uint64_t freshness=0; std::vector<std::uint8_t> payload; std::vector<std::uint8_t> authenticator; };
class SecOc {
public:
    explicit SecOc(std::string key = "aesim-development-key");
    [[nodiscard]] SecuredPdu protect(const std::vector<std::uint8_t>& payload, std::uint64_t freshness, std::size_t tag_bytes=8) const;
    [[nodiscard]] bool verify(const SecuredPdu& pdu, const std::string& channel, std::string& error);
private:
    std::string key_;
    std::map<std::string,std::uint64_t> latest_freshness_;
};
struct CyberCampaignResult { std::string id; std::size_t attacks=0, detected=0, blocked=0, false_positives=0; double mean_detection_ms=0.0; doc::Value to_document() const; std::string report() const; };
class CyberCampaignRunner {
public:
    [[nodiscard]] CyberCampaignResult run(const std::string& path, SecOc& secoc, AdaptiveRuntime& adaptive, industrial::AutomotiveNetwork& network);
};

struct FailureMode { std::string id, item, effect, safety_mechanism; unsigned severity=1, occurrence=1, detection=1; double failure_rate_fit=0.0, safe_fraction=0.0, detected_fraction=0.0; };
struct SafetyMetrics { double spfm=0.0, lfm=0.0; unsigned total_rpn=0, maximum_rpn=0; std::size_t modes=0; std::string report() const; };
class SafetyRepository {
public:
    void load(const std::string& path);
    [[nodiscard]] SafetyMetrics analyze() const;
    [[nodiscard]] doc::Value safety_case() const;
    void record_evidence(const std::string& claim, const std::string& artifact, const std::string& verdict);
    [[nodiscard]] std::string status() const;
private:
    doc::Value work_products_ = doc::Value::Object{};
    std::vector<FailureMode> failure_modes_;
    std::map<std::string,doc::Value> evidence_;
};

struct FixedPointFormat { bool is_signed=true; unsigned integer_bits=1, fractional_bits=15; double scale=1.0/32768.0; double minimum=-1.0, maximum=0.999969482421875; double worst_quantization_error=0.5/32768.0; };
class EfmiGenerator {
public:
    [[nodiscard]] FixedPointFormat analyze_range(double minimum, double maximum, double max_error, unsigned max_bits=32) const;
    [[nodiscard]] std::string generate(const std::string& model_path, const std::string& output_directory) const;
};

class OdsRepository {
public:
    OdsRepository(); ~OdsRepository();
    OdsRepository(const OdsRepository&) = delete; OdsRepository& operator=(const OdsRepository&) = delete;
    void open(const std::string& path);
    void close();
    std::int64_t add_test(const std::string& name, const std::string& verdict, const std::string& artifact);
    void add_measurement(std::int64_t test_id, const std::string& channel, const std::string& unit, double time_s, double value);
    [[nodiscard]] std::string query_tests() const;
    void export_atfx(const std::string& path) const;
    void import_atfx(const std::string& path);
    [[nodiscard]] std::string status() const;
private:
    sqlite3* db_ = nullptr;
    std::string path_;
};

struct McdcResult { std::size_t conditions=0, covered=0; double percentage=0.0; std::vector<std::string> uncovered; std::string report() const; };
struct TemporalResult { bool passed=true; std::string property; std::size_t failing_index=0; double failing_time_s=0.0; std::string reason; std::string replay_path; std::string report() const; };
class VerificationEngine {
public:
    [[nodiscard]] McdcResult mcdc(const std::string& vectors_path) const;
    [[nodiscard]] TemporalResult temporal(const std::string& trace_csv, const std::string& property_path, const std::string& replay_output) const;
};

class AssurancePlatform {
public:
    AssurancePlatform(industrial::SignalRegistry& signals, industrial::AutomotiveNetwork& network, industrial::TraceabilityRepository& traceability);
    [[nodiscard]] std::string command(const std::vector<std::string>& args);
    [[nodiscard]] std::string status() const;
    [[nodiscard]] resilience::SimulationAssuranceFramework& resilience_framework() noexcept { return resilience_; }
    [[nodiscard]] const resilience::SimulationAssuranceFramework& resilience_framework() const noexcept { return resilience_; }
private:
    industrial::SignalRegistry& signals_;
    industrial::AutomotiveNetwork& network_;
    industrial::TraceabilityRepository& traceability_;
    VirtualRte rte_;
    DiagnosticWorkbench diagnostics_;
    AdaptiveRuntime adaptive_;
    SecOc secoc_;
    CyberCampaignRunner cyber_;
    SafetyRepository safety_;
    EfmiGenerator efmi_;
    OdsRepository ods_;
    VerificationEngine verification_;
    resilience::SimulationAssuranceFramework resilience_;
    [[nodiscard]] std::string resilience_command(const std::vector<std::string>& args);
};

} // namespace aesim::assurance

#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::assurance::resilience {

[[nodiscard]] std::uint64_t stable_monotonic_ns() noexcept;
[[nodiscard]] std::string utc_now();

enum class ErrorSeverity : unsigned char { Info, Notice, Warning, Error, Critical };
[[nodiscard]] const char* severity_name(ErrorSeverity severity) noexcept;
[[nodiscard]] ErrorSeverity parse_severity(const std::string& text);

struct ErrorDescriptor {
    std::string code;
    std::string category;
    ErrorSeverity severity = ErrorSeverity::Error;
    std::string title;
    std::string description;
    bool recoverable = false;
    std::vector<std::string> remediation;
};

struct ErrorOccurrence {
    std::uint64_t id = 0;
    std::string code;
    std::string timestamp_utc;
    std::string subsystem;
    std::string operation;
    std::string message;
    std::vector<std::uint64_t> causes;
    doc::Value context{doc::Value::Object{}};
    std::string state_sha256;
};

class ErrorProvenanceGraph {
public:
    void register_descriptor(ErrorDescriptor descriptor);
    [[nodiscard]] std::uint64_t record(const std::string& code,
                                       const std::string& subsystem,
                                       const std::string& operation,
                                       const std::string& message,
                                       std::vector<std::uint64_t> causes = {},
                                       doc::Value context = doc::Value::Object{},
                                       std::string state_sha256 = {});
    [[nodiscard]] std::optional<ErrorDescriptor> descriptor(const std::string& code) const;
    [[nodiscard]] std::optional<ErrorOccurrence> occurrence(std::uint64_t id) const;
    [[nodiscard]] std::vector<ErrorOccurrence> occurrences() const;
    [[nodiscard]] std::vector<ErrorOccurrence> trace(std::uint64_t id) const;
    void clear_occurrences();
    [[nodiscard]] doc::Value to_document() const;
    void restore_document(const doc::Value& document);
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_;
    std::map<std::string, ErrorDescriptor> descriptors_;
    std::map<std::uint64_t, ErrorOccurrence> occurrences_;
    std::uint64_t next_id_ = 1;
};

enum class FaultEffect : unsigned char { Fail, Exception, Delay, Drop, Corrupt, ResourceExhaustion };
[[nodiscard]] const char* fault_effect_name(FaultEffect effect) noexcept;
[[nodiscard]] FaultEffect parse_fault_effect(const std::string& text);

enum class FaultTrigger : unsigned char { Invocation, SimulationTime, Event, Probability };
[[nodiscard]] const char* fault_trigger_name(FaultTrigger trigger) noexcept;
[[nodiscard]] FaultTrigger parse_fault_trigger(const std::string& text);

struct FaultRule {
    std::string id;
    std::string subsystem = "*";
    std::string operation = "*";
    FaultEffect effect = FaultEffect::Fail;
    FaultTrigger trigger = FaultTrigger::Invocation;
    std::uint64_t invocation = 1;
    double simulation_time_s = 0.0;
    std::string event;
    double probability = 1.0;
    bool once = true;
    bool enabled = true;
    doc::Value parameters{doc::Value::Object{}};
};

struct FaultContext {
    std::string subsystem;
    std::string operation;
    double simulation_time_s = 0.0;
    std::string event;
};

struct FaultDecision {
    bool injected = false;
    std::string rule_id;
    FaultEffect effect = FaultEffect::Fail;
    std::uint64_t decision_index = 0;
    doc::Value parameters{doc::Value::Object{}};
};

class DeterministicChaosEngine {
public:
    explicit DeterministicChaosEngine(std::uint64_t seed = 0xA351F00DULL);
    void set_seed(std::uint64_t seed);
    [[nodiscard]] std::uint64_t seed() const;
    void reset();
    void add(FaultRule rule);
    bool remove(const std::string& id);
    void clear();
    void load(const std::string& path);
    [[nodiscard]] std::vector<FaultRule> rules() const;
    [[nodiscard]] std::vector<FaultDecision> evaluate(const FaultContext& context);
    [[nodiscard]] double apply_numeric(double value, const std::vector<FaultDecision>& decisions) const;
    [[nodiscard]] doc::Value to_document() const;
    void restore_document(const doc::Value& document);
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_;
    std::uint64_t seed_;
    std::uint64_t decision_index_ = 0;
    std::map<std::string, FaultRule> rules_;
    std::map<std::string, std::uint64_t> invocation_counts_;
    std::set<std::string> fired_once_;
};

struct CheckpointComponent {
    std::string path;
    int restore_order = 0;
    std::function<doc::Value()> capture;
    std::function<void(const doc::Value&)> restore;
};

struct HierarchicalCheckpoint {
    std::string id;
    std::string label;
    std::string created_utc;
    std::string parent_id;
    std::map<std::string, doc::Value> components;
    std::map<std::string, std::string> component_sha256;
    std::string aggregate_sha256;
    doc::Value metadata{doc::Value::Object{}};
};

struct RestoreReport {
    bool success = false;
    bool rollback_attempted = false;
    bool rollback_succeeded = false;
    std::size_t components_restored = 0;
    std::string checkpoint_id;
    std::string scope;
    std::string error;
    [[nodiscard]] std::string report() const;
};

class HierarchicalCheckpointManager {
public:
    void register_component(CheckpointComponent component);
    bool unregister_component(const std::string& path);
    [[nodiscard]] HierarchicalCheckpoint create(const std::string& label,
                                                const std::string& parent_id = {},
                                                doc::Value metadata = doc::Value::Object{});
    [[nodiscard]] std::vector<std::string> ids() const;
    [[nodiscard]] std::optional<HierarchicalCheckpoint> get(const std::string& id) const;
    [[nodiscard]] bool verify(const HierarchicalCheckpoint& checkpoint, std::string& error) const;
    [[nodiscard]] RestoreReport restore(const std::string& id, const std::string& scope = {});
    bool save(const std::string& id, const std::string& path, std::string& error) const;
    [[nodiscard]] HierarchicalCheckpoint load(const std::string& path);
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_;
    std::map<std::string, CheckpointComponent> components_;
    std::map<std::string, HierarchicalCheckpoint> checkpoints_;
};

struct ConservationTolerance {
    double absolute = 1.0e-9;
    double relative = 1.0e-6;
};

struct ConservationQuantityResult {
    std::string domain;
    std::string quantity;
    std::string unit;
    double storage_change = 0.0;
    double external_net = 0.0;
    double transfer_net = 0.0;
    double residual = 0.0;
    double normalized_residual = 0.0;
    bool passed = true;
};

struct ConservationStepResult {
    std::uint64_t step = 0;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    bool passed = true;
    std::size_t violations = 0;
    std::vector<ConservationQuantityResult> quantities;
    [[nodiscard]] std::string report() const;
};

class CrossSubsystemConservationLedger {
public:
    void define_quantity(const std::string& quantity, const std::string& unit,
                         ConservationTolerance tolerance = {});
    void reset(double time_s = 0.0);
    void set_storage(const std::string& domain, const std::string& quantity, double value);
    void add_external_rate(const std::string& domain, const std::string& quantity, double rate);
    void add_transfer_rate(const std::string& from_domain, const std::string& to_domain,
                           const std::string& quantity, double rate);
    [[nodiscard]] ConservationStepResult close_step(double end_time_s);
    [[nodiscard]] std::optional<ConservationStepResult> last_result() const;
    [[nodiscard]] doc::Value to_document() const;
    void restore_document(const doc::Value& document);
    [[nodiscard]] std::string report() const;
private:
    struct QuantityDefinition { std::string unit; ConservationTolerance tolerance; };
    struct Cell { double previous_storage=0.0; double current_storage=0.0; double external_rate=0.0; double transfer_rate=0.0; bool initialized=false; };
    mutable std::mutex mutex_;
    std::map<std::string, QuantityDefinition> quantities_;
    std::map<std::string, std::map<std::string, Cell>> ledger_;
    std::optional<ConservationStepResult> last_;
    double previous_time_s_ = 0.0;
    std::uint64_t step_ = 0;
};

enum class TrustLevel : unsigned char { High, Medium, Low, Reject };
[[nodiscard]] const char* trust_level_name(TrustLevel level) noexcept;

struct NumericalEvidence {
    std::string id;
    std::string metric;
    double value = 0.0;
    std::string unit;
    double absolute_uncertainty = 0.0;
    double confidence_level = 0.95;
    std::string algorithm;
    std::string solver;
    unsigned precision_bits = 53;
    double residual = 0.0;
    double tolerance = 0.0;
    double condition_estimate = 1.0;
    std::uint64_t iterations = 0;
    bool converged = true;
    bool inside_validity_domain = true;
    std::vector<std::string> provenance;
    std::string input_sha256;
    std::string result_sha256;
    std::string timestamp_utc;
    [[nodiscard]] double trust_score() const noexcept;
    [[nodiscard]] TrustLevel trust_level() const noexcept;
};

class NumericalEvidenceRegistry {
public:
    void record(NumericalEvidence evidence);
    [[nodiscard]] std::optional<NumericalEvidence> get(const std::string& id) const;
    [[nodiscard]] std::vector<NumericalEvidence> list() const;
    void clear();
    [[nodiscard]] doc::Value to_document() const;
    void restore_document(const doc::Value& document);
    [[nodiscard]] std::string report() const;
private:
    mutable std::mutex mutex_;
    std::map<std::string, NumericalEvidence> evidence_;
};

struct CacheLookup {
    bool hit = false;
    bool stale = false;
    bool recomputed = false;
    std::string key;
    doc::Value value;
    std::vector<std::string> stale_dependencies;
};

class SemanticResultCache {
public:
    [[nodiscard]] std::size_t set_dependency(const std::string& name, const std::string& semantic_hash);
    [[nodiscard]] std::optional<std::string> dependency(const std::string& name) const;
    [[nodiscard]] std::string put(const std::string& name_space,
                                  const doc::Value& inputs,
                                  const doc::Value& settings,
                                  doc::Value value,
                                  std::set<std::string> tags = {},
                                  std::set<std::string> dependencies = {});
    [[nodiscard]] CacheLookup get(const std::string& key);
    [[nodiscard]] std::string key_for(const std::string& name_space,
                                      const doc::Value& inputs,
                                      const doc::Value& settings,
                                      const std::set<std::string>& dependencies = {}) const;
    [[nodiscard]] CacheLookup get_or_compute(const std::string& name_space,
                                             const doc::Value& inputs,
                                             const doc::Value& settings,
                                             const std::function<doc::Value()>& compute,
                                             std::set<std::string> tags = {},
                                             std::set<std::string> dependencies = {});
    [[nodiscard]] std::size_t invalidate_dependency(const std::string& name);
    [[nodiscard]] std::size_t invalidate_tag(const std::string& tag);
    [[nodiscard]] std::size_t invalidate_namespace(const std::string& name_space);
    void clear();
    [[nodiscard]] std::size_t size() const;
    [[nodiscard]] doc::Value to_document() const;
    void restore_document(const doc::Value& document);
    bool save(const std::string& path, std::string& error) const;
    void load(const std::string& path);
    [[nodiscard]] std::string report() const;
private:
    struct Entry {
        std::string key;
        std::string name_space;
        std::string input_sha256;
        std::string settings_sha256;
        doc::Value value;
        std::set<std::string> tags;
        std::map<std::string, std::string> dependencies;
        std::string created_utc;
    };
    mutable std::mutex mutex_;
    std::map<std::string, std::string> dependencies_;
    std::map<std::string, Entry> entries_;
    std::uint64_t hits_ = 0;
    std::uint64_t misses_ = 0;
    std::uint64_t invalidations_ = 0;
};


struct IncrementalSimulationNodeResult {
    std::string id;
    bool source = false;
    bool cache_hit = false;
    bool recomputed = false;
    std::string cache_key;
    std::string value_sha256;
    double elapsed_ms = 0.0;
};

struct IncrementalSimulationReport {
    bool success = false;
    std::size_t source_nodes = 0;
    std::size_t reused_nodes = 0;
    std::size_t recomputed_nodes = 0;
    std::vector<std::string> execution_order;
    std::vector<IncrementalSimulationNodeResult> nodes;
    std::map<std::string, doc::Value> outputs;
    std::string aggregate_sha256;
    [[nodiscard]] doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};

class IncrementalSimulationGraph {
public:
    using Compute = std::function<doc::Value(const std::map<std::string, doc::Value>&)>;
    explicit IncrementalSimulationGraph(SemanticResultCache& cache);
    void set_source(std::string id, doc::Value value);
    void add_node(std::string id, std::vector<std::string> dependencies,
                  doc::Value settings, Compute compute,
                  std::set<std::string> semantic_dependencies = {},
                  std::set<std::string> tags = {});
    void remove_node(const std::string& id);
    void clear();
    [[nodiscard]] IncrementalSimulationReport execute(
        std::vector<std::string> targets = {}) const;
private:
    struct Node {
        std::string id;
        std::vector<std::string> dependencies;
        doc::Value settings;
        Compute compute;
        std::set<std::string> semantic_dependencies;
        std::set<std::string> tags;
    };
    SemanticResultCache* cache_ = nullptr;
    std::map<std::string, doc::Value> sources_;
    std::map<std::string, Node> nodes_;
};

struct OperationGuardResult {
    bool dropped = false;
    std::vector<FaultDecision> decisions;
};

class SimulationAssuranceFramework {
public:
    SimulationAssuranceFramework();
    ErrorProvenanceGraph& errors() noexcept { return errors_; }
    DeterministicChaosEngine& chaos() noexcept { return chaos_; }
    HierarchicalCheckpointManager& checkpoints() noexcept { return checkpoints_; }
    CrossSubsystemConservationLedger& conservation() noexcept { return conservation_; }
    NumericalEvidenceRegistry& numerics() noexcept { return numerics_; }
    SemanticResultCache& cache() noexcept { return cache_; }
    [[nodiscard]] const ErrorProvenanceGraph& errors() const noexcept { return errors_; }
    [[nodiscard]] const DeterministicChaosEngine& chaos() const noexcept { return chaos_; }
    [[nodiscard]] const HierarchicalCheckpointManager& checkpoints() const noexcept { return checkpoints_; }
    [[nodiscard]] const CrossSubsystemConservationLedger& conservation() const noexcept { return conservation_; }
    [[nodiscard]] const NumericalEvidenceRegistry& numerics() const noexcept { return numerics_; }
    [[nodiscard]] const SemanticResultCache& cache() const noexcept { return cache_; }

    [[nodiscard]] OperationGuardResult guard(const FaultContext& context);
    [[nodiscard]] doc::Value manifest(const std::string& run_name = {}) const;
    bool write_certificate(const std::string& path, const std::string& run_name,
                           std::string& error) const;
    [[nodiscard]] bool verify_certificate(const std::string& path, std::string& error) const;
    [[nodiscard]] std::string status() const;
private:
    ErrorProvenanceGraph errors_;
    DeterministicChaosEngine chaos_;
    HierarchicalCheckpointManager checkpoints_;
    CrossSubsystemConservationLedger conservation_;
    NumericalEvidenceRegistry numerics_;
    SemanticResultCache cache_;
};

} // namespace aesim::assurance::resilience

#pragma once

#include "aesim/industrial/signals.hpp"
#include "aesim/professional/document.hpp"

#include <array>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::frontier {

// ---------------------------------------------------------------------------
// SysML v2 / ReqIF digital thread
// ---------------------------------------------------------------------------

enum class ThreadElementKind {
    Package, PartDefinition, PartUsage, PortDefinition, InterfaceDefinition,
    ActionDefinition, StateDefinition, Requirement, VerificationCase,
    TestCase, Model, Calibration, Dataset, Artifact, Evidence, Unknown
};

std::string thread_kind_name(ThreadElementKind kind);

struct ThreadElement {
    std::string id;
    std::string qualified_name;
    std::string name;
    ThreadElementKind kind = ThreadElementKind::Unknown;
    std::string statement;
    std::map<std::string, std::string> attributes;
    std::string source;
    std::string sha256;
};

struct ThreadRelation {
    std::string id;
    std::string type;
    std::string source_id;
    std::string target_id;
    std::map<std::string, std::string> attributes;
};

struct ImpactReport {
    std::string changed_id;
    std::vector<ThreadElement> affected;
    std::vector<ThreadElement> stale_evidence;
    std::vector<std::string> paths;
    [[nodiscard]] aesim::doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};

class DigitalThreadRepository {
public:
    void clear();
    void import_sysml(const std::string& path);
    void export_sysml(const std::string& path) const;
    void import_reqif(const std::string& path);
    void export_reqif(const std::string& path) const;
    void import_links(const std::string& path);
    void add_element(ThreadElement element);
    void add_relation(ThreadRelation relation);
    [[nodiscard]] const std::map<std::string, ThreadElement>& elements() const noexcept;
    [[nodiscard]] const std::vector<ThreadRelation>& relations() const noexcept;
    [[nodiscard]] std::optional<ThreadElement> find(const std::string& id_or_name) const;
    [[nodiscard]] ImpactReport impact(const std::string& changed_id) const;
    [[nodiscard]] aesim::doc::Value to_document() const;
    void save(const std::string& path) const;
    void load(const std::string& path);
    [[nodiscard]] std::string status() const;

private:
    std::map<std::string, ThreadElement> elements_;
    std::vector<ThreadRelation> relations_;
    std::uint64_t next_relation_ = 1;
};

// ---------------------------------------------------------------------------
// ISO/PAS 8800-oriented AI safety lifecycle
// ---------------------------------------------------------------------------

enum class AssuranceVerdict { Pass, Fail, Inconclusive, Missing };
std::string assurance_verdict_name(AssuranceVerdict verdict);

struct AiDatasetRecord {
    std::string id;
    std::string path;
    std::string sha256;
    std::string license;
    std::string approval;
    std::map<std::string, double> coverage;
    std::vector<std::string> known_gaps;
};

struct AiModelRecord {
    std::string id;
    std::string path;
    std::string sha256;
    std::string dataset_id;
    std::string operating_domain;
    std::string approval;
    std::map<std::string, double> metrics;
    std::vector<std::string> runtime_monitors;
    std::vector<double> fallback_output;
};

struct AiSafetyRequirement {
    std::string id;
    std::string statement;
    std::string asil;
    std::vector<std::string> evidence_ids;
};

struct AiEvidence {
    std::string id;
    std::string requirement_id;
    std::string artifact;
    std::string artifact_sha256;
    AssuranceVerdict verdict = AssuranceVerdict::Missing;
    std::map<std::string, double> metrics;
    std::string message;
};

struct AiAssuranceReport {
    bool releasable = false;
    std::size_t requirements_total = 0;
    std::size_t requirements_passed = 0;
    std::size_t requirements_failed = 0;
    std::size_t requirements_missing = 0;
    std::vector<std::string> findings;
    [[nodiscard]] aesim::doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};

class AiSafetyLifecycle {
public:
    void clear();
    void load(const std::string& path);
    void record_evidence(AiEvidence evidence);
    [[nodiscard]] AiAssuranceReport evaluate() const;
    [[nodiscard]] aesim::doc::Value safety_case() const;
    void write_safety_case(const std::string& path) const;
    [[nodiscard]] const std::map<std::string, AiDatasetRecord>& datasets() const noexcept;
    [[nodiscard]] const std::map<std::string, AiModelRecord>& models() const noexcept;
    [[nodiscard]] std::string status() const;

private:
    std::map<std::string, AiDatasetRecord> datasets_;
    std::map<std::string, AiModelRecord> models_;
    std::map<std::string, AiSafetyRequirement> requirements_;
    std::map<std::string, AiEvidence> evidence_;
    std::map<std::string, std::string> metadata_;
};

// ---------------------------------------------------------------------------
// SAE/ETSI V2X and roadside infrastructure
// ---------------------------------------------------------------------------

enum class V2xMessageKind { Bsm, Spat, Map, Tim, Cam, Denm, Cpm, Unknown };
std::string v2x_kind_name(V2xMessageKind kind);
V2xMessageKind parse_v2x_kind(const std::string& text);

struct V2xMessage {
    V2xMessageKind kind = V2xMessageKind::Unknown;
    std::string station_id;
    std::uint64_t sequence = 0;
    std::uint64_t timestamp_ms = 0;
    double latitude_deg = 0.0;
    double longitude_deg = 0.0;
    double elevation_m = 0.0;
    double speed_m_s = 0.0;
    double heading_deg = 0.0;
    double acceleration_m_s2 = 0.0;
    std::map<std::string, double> numeric;
    std::map<std::string, std::string> text;
    std::string certificate_id;
    std::string signature_hex;
};

struct V2xChannelConfiguration {
    double transmit_power_dbm = 23.0;
    double carrier_frequency_hz = 5.9e9;
    double path_loss_exponent = 2.2;
    double noise_floor_dbm = -96.0;
    double receive_threshold_dbm = -88.0;
    double packet_error_floor = 0.0;
    std::uint64_t seed = 1;
};

struct V2xDelivery {
    bool delivered = false;
    bool authenticated = false;
    bool replay = false;
    bool plausible = true;
    double received_power_dbm = -200.0;
    double packet_error_probability = 1.0;
    std::string reason;
    V2xMessage message;
};

struct SignalPhase {
    std::string movement;
    std::string state;
    double minimum_end_time_s = 0.0;
};

class V2xSecurityAuthority {
public:
    V2xSecurityAuthority();
    ~V2xSecurityAuthority();
    V2xSecurityAuthority(V2xSecurityAuthority&&) noexcept;
    V2xSecurityAuthority& operator=(V2xSecurityAuthority&&) noexcept;
    V2xSecurityAuthority(const V2xSecurityAuthority&) = delete;
    V2xSecurityAuthority& operator=(const V2xSecurityAuthority&) = delete;

    void initialize(const std::string& directory, const std::string& authority_name);
    std::string issue_pseudonym(const std::string& station_id, std::uint64_t valid_from_ms,
                                std::uint64_t valid_to_ms);
    void revoke(const std::string& certificate_id);
    [[nodiscard]] V2xMessage sign(V2xMessage message, const std::string& certificate_id) const;
    [[nodiscard]] bool verify(const V2xMessage& message, std::string& reason) const;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

class RoadsideUnit {
public:
    explicit RoadsideUnit(std::string id = "RSU-1");
    void configure_intersection(std::string intersection_id,
                                std::vector<std::pair<double, double>> reference_polygon,
                                std::vector<SignalPhase> phases);
    void set_phase(const std::string& movement, const std::string& state, double minimum_end_time_s);
    [[nodiscard]] V2xMessage map_message(std::uint64_t timestamp_ms) const;
    [[nodiscard]] V2xMessage spat_message(std::uint64_t timestamp_ms) const;
    [[nodiscard]] V2xMessage tim_message(std::uint64_t timestamp_ms,
                                         const std::string& advisory,
                                         double radius_m) const;
    [[nodiscard]] std::string status() const;

private:
    std::string id_;
    std::string intersection_id_;
    std::vector<std::pair<double, double>> polygon_;
    std::vector<SignalPhase> phases_;
};

class V2xNetwork {
public:
    explicit V2xNetwork(V2xChannelConfiguration configuration = {});
    void configure(V2xChannelConfiguration configuration);
    [[nodiscard]] std::vector<std::uint8_t> encode(const V2xMessage& message) const;
    [[nodiscard]] V2xMessage decode(const std::vector<std::uint8_t>& bytes) const;
    [[nodiscard]] V2xDelivery transmit(const V2xMessage& message, double distance_m,
                                       const V2xSecurityAuthority* authority = nullptr);
    void reset_replay_state();
    [[nodiscard]] std::string status() const;

private:
    V2xChannelConfiguration configuration_;
    std::map<std::string, std::uint64_t> latest_sequence_;
    std::uint64_t transmissions_ = 0;
    std::uint64_t deliveries_ = 0;
    std::uint64_t authentication_failures_ = 0;
    std::uint64_t replay_rejections_ = 0;
};

// ---------------------------------------------------------------------------
// OpenMATERIAL, OpenLABEL, OpenODD, coverage and synthesis
// ---------------------------------------------------------------------------

struct MaterialRecord {
    std::string id;
    std::string name;
    double roughness = 0.5;
    double refractive_index = 1.0;
    double radar_relative_permittivity = 1.0;
    double radar_conductivity_s_m = 0.0;
    double lidar_reflectivity = 0.5;
    double infrared_emissivity = 0.9;
    std::map<double, double> spectral_reflectance;
};

struct LabelObject {
    std::string id;
    std::string type;
    std::string coordinate_system;
    std::array<double, 3> position{};
    std::array<double, 3> dimensions{};
    std::array<double, 4> orientation{1.0, 0.0, 0.0, 0.0};
    double confidence = 1.0;
    std::map<std::string, std::string> attributes;
};

struct LabelFrame {
    std::uint64_t frame = 0;
    double timestamp_s = 0.0;
    std::vector<LabelObject> objects;
};

struct OddDimension {
    std::string name;
    bool numeric = false;
    double minimum = 0.0;
    double maximum = 0.0;
    std::vector<std::string> categories;
};

struct OddDomain {
    std::string id;
    std::string description;
    std::vector<OddDimension> dimensions;
    [[nodiscard]] bool contains(const std::map<std::string, aesim::doc::Value>& point,
                                std::string& reason) const;
    [[nodiscard]] aesim::doc::Value to_document() const;
};

class OpenXAssetRepository {
public:
    void clear();
    void import_material(const std::string& path);
    void export_material(const std::string& path) const;
    void import_openlabel(const std::string& path);
    void export_openlabel(const std::string& path) const;
    void import_openodd(const std::string& path);
    void export_openodd(const std::string& path) const;
    [[nodiscard]] const std::map<std::string, MaterialRecord>& materials() const noexcept;
    [[nodiscard]] const std::vector<LabelFrame>& frames() const noexcept;
    [[nodiscard]] const OddDomain& odd() const;
    [[nodiscard]] std::string qualify() const;
    [[nodiscard]] std::string status() const;

private:
    std::map<std::string, MaterialRecord> materials_;
    std::vector<LabelFrame> frames_;
    std::optional<OddDomain> odd_;
};

struct CoverageBin {
    std::string dimension;
    std::string label;
    std::size_t hits = 0;
};

struct OddCoverageReport {
    std::size_t samples = 0;
    std::size_t bins_total = 0;
    std::size_t bins_covered = 0;
    std::size_t pair_bins_total = 0;
    std::size_t pair_bins_covered = 0;
    double coverage_percent = 0.0;
    double pairwise_coverage_percent = 0.0;
    std::vector<CoverageBin> bins;
    std::vector<std::string> uncovered;
    [[nodiscard]] aesim::doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};

class OddCoverageEngine {
public:
    void configure(OddDomain domain, std::size_t numeric_bins = 5);
    void add_sample(std::map<std::string, aesim::doc::Value> sample);
    void load_samples(const std::string& path);
    [[nodiscard]] OddCoverageReport analyze() const;
    [[nodiscard]] aesim::doc::Value synthesize(std::size_t maximum_scenarios,
                                                std::uint64_t seed = 1) const;
    void write_scenarios(const std::string& path, std::size_t maximum_scenarios,
                         std::uint64_t seed = 1) const;
    [[nodiscard]] std::string status() const;

private:
    OddDomain domain_;
    std::size_t numeric_bins_ = 5;
    std::vector<std::map<std::string, aesim::doc::Value>> samples_;
};

// ---------------------------------------------------------------------------
// Battery thermal runaway and propagation
// ---------------------------------------------------------------------------

enum class AbuseMode { None, InternalShort, ExternalShort, Overcharge, Heater, Crush, Penetration };
std::string abuse_mode_name(AbuseMode mode);
AbuseMode parse_abuse_mode(const std::string& text);

struct RunawayCellState {
    double core_temperature_k = 298.15;
    double surface_temperature_k = 298.15;
    double reaction_progress = 0.0;
    double gas_mass_kg = 0.0;
    double vented_mass_kg = 0.0;
    double stored_energy_j = 0.0;
    bool vent_open = false;
    bool runaway = false;
    bool failed = false;
    AbuseMode abuse = AbuseMode::None;
    double abuse_intensity = 0.0;
};

struct RunawayPackConfiguration {
    std::size_t rows = 4;
    std::size_t columns = 8;
    double cell_mass_kg = 0.9;
    double heat_capacity_j_kg_k = 1000.0;
    double surface_heat_capacity_j_k = 120.0;
    double core_surface_conductance_w_k = 2.5;
    double neighbor_conductance_w_k = 1.0;
    double coolant_conductance_w_k = 0.5;
    double reaction_onset_k = 393.15;
    double runaway_temperature_k = 473.15;
    double vent_temperature_k = 423.15;
    double activation_energy_j_mol = 82000.0;
    double pre_exponential_per_s = 4.0e8;
    double reaction_enthalpy_j_kg = 1.5e6;
    double gas_yield_kg_per_kg = 0.08;
    double radiative_emissivity = 0.85;
    double barrier_factor = 1.0;
};

struct RunawayPackOutput {
    double time_s = 0.0;
    double peak_temperature_k = 0.0;
    double total_heat_release_w = 0.0;
    double total_vented_gas_kg = 0.0;
    std::size_t runaway_cells = 0;
    std::size_t failed_cells = 0;
    bool propagation = false;
    double energy_residual_w = 0.0;
};

class ThermalRunawayPack {
public:
    explicit ThermalRunawayPack(RunawayPackConfiguration configuration = {});
    void configure(RunawayPackConfiguration configuration);
    void reset(double initial_temperature_k = 298.15);
    void inject(std::size_t row, std::size_t column, AbuseMode mode, double intensity);
    void clear_abuse(std::size_t row, std::size_t column);
    [[nodiscard]] RunawayPackOutput step(double dt_s, double coolant_temperature_k,
                                         double ambient_temperature_k);
    [[nodiscard]] const std::vector<RunawayCellState>& cells() const noexcept;
    [[nodiscard]] const RunawayPackOutput& output() const noexcept;
    [[nodiscard]] aesim::doc::Value state_document() const;
    void restore_state(const aesim::doc::Value& state);
    [[nodiscard]] std::string status() const;

private:
    RunawayPackConfiguration configuration_;
    std::vector<RunawayCellState> cells_;
    RunawayPackOutput output_;
};

// ---------------------------------------------------------------------------
// Mixed-criticality virtual ECU and WCET
// ---------------------------------------------------------------------------

enum class CriticalityLevel { QM, ASIL_A, ASIL_B, ASIL_C, ASIL_D };
std::string criticality_name(CriticalityLevel level);
CriticalityLevel parse_criticality(const std::string& text);

enum class VecuOpcode { LoadConst, LoadSignal, StoreSignal, Add, Sub, Mul, Div, Min, Max,
                        Clamp, CompareGreater, JumpIfZero, Jump, End };

struct VecuInstruction {
    VecuOpcode opcode = VecuOpcode::End;
    int destination = 0;
    int source_a = 0;
    int source_b = 0;
    double immediate = 0.0;
    int target = 0;
    std::string signal;
};

struct VecuTask {
    std::string id;
    CriticalityLevel criticality = CriticalityLevel::QM;
    std::uint64_t period_ns = 1'000'000;
    std::uint64_t deadline_ns = 1'000'000;
    int priority = 1;
    std::uint64_t lo_budget_ns = 100'000;
    std::uint64_t hi_budget_ns = 200'000;
    std::size_t max_instructions = 1000;
    std::vector<VecuInstruction> program;
};

struct WcetTaskResult {
    std::string id;
    std::uint64_t static_instruction_cost_ns = 0;
    std::uint64_t response_time_lo_ns = 0;
    std::uint64_t response_time_hi_ns = 0;
    std::uint64_t measured_max_ns = 0;
    std::uint64_t measured_p999_ns = 0;
    bool schedulable_lo = false;
    bool schedulable_hi = false;
};

struct WcetReport {
    bool schedulable = false;
    std::vector<WcetTaskResult> tasks;
    [[nodiscard]] aesim::doc::Value to_document() const;
    [[nodiscard]] std::string report() const;
};

class MixedCriticalityVecu {
public:
    explicit MixedCriticalityVecu(aesim::industrial::SignalRegistry& signals);
    ~MixedCriticalityVecu();
    MixedCriticalityVecu(const MixedCriticalityVecu&) = delete;
    MixedCriticalityVecu& operator=(const MixedCriticalityVecu&) = delete;
    void load(const std::string& path);
    void reset(std::uint64_t time_ns = 0);
    void step(std::uint64_t target_time_ns);
    [[nodiscard]] WcetReport analyze_wcet(std::size_t measured_iterations = 100);
    [[nodiscard]] aesim::doc::Value state_document() const;
    void restore_state(const aesim::doc::Value& state);
    [[nodiscard]] std::string status() const;
    [[nodiscard]] bool loaded() const noexcept;
    [[nodiscard]] bool high_criticality_mode() const noexcept;

private:
    struct RuntimeTask;
    aesim::industrial::SignalRegistry& signals_;
    std::vector<RuntimeTask> tasks_;
    std::uint64_t current_time_ns_ = 0;
    bool high_criticality_mode_ = false;
    std::uint64_t deadline_misses_ = 0;
    std::uint64_t budget_overruns_ = 0;
    void execute_task(RuntimeTask& task, bool record_timing);
};

// ---------------------------------------------------------------------------
// Differentiable simulation and automatic differentiation
// ---------------------------------------------------------------------------

struct GradientResult {
    double value = 0.0;
    std::map<std::string, double> gradient;
};

struct DifferentiableStepResult {
    double time_s = 0.0;
    std::map<std::string, double> states;
    std::map<std::string, std::map<std::string, double>> sensitivities;
};

class DifferentiableModel {
public:
    void load(const std::string& path);
    void reset();
    void set_input(const std::string& name, double value);
    void set_parameter(const std::string& name, double value);
    [[nodiscard]] GradientResult evaluate(const std::string& output) const;
    [[nodiscard]] DifferentiableStepResult step(double dt_s);
    [[nodiscard]] aesim::doc::Value jacobian() const;
    [[nodiscard]] std::string status() const;

private:
    struct Impl;
    std::shared_ptr<Impl> impl_;
};

// ---------------------------------------------------------------------------
// Integrated platform
// ---------------------------------------------------------------------------

class FrontierPlatform {
public:
    explicit FrontierPlatform(aesim::industrial::SignalRegistry& signals);
    void update(double time_s, double step_s, double speed_m_s, double rpm,
                double battery_temperature_k = 298.15);
    [[nodiscard]] std::string command(const std::vector<std::string>& arguments);
    [[nodiscard]] std::string status() const;

    DigitalThreadRepository& digital_thread() noexcept;
    AiSafetyLifecycle& ai_safety() noexcept;
    V2xNetwork& v2x() noexcept;
    OpenXAssetRepository& openx() noexcept;
    OddCoverageEngine& odd_coverage() noexcept;
    ThermalRunawayPack& runaway() noexcept;
    MixedCriticalityVecu& vecu() noexcept;
    DifferentiableModel& differentiable() noexcept;

private:
    aesim::industrial::SignalRegistry& signals_;
    DigitalThreadRepository digital_thread_;
    AiSafetyLifecycle ai_safety_;
    V2xSecurityAuthority v2x_security_;
    V2xNetwork v2x_;
    RoadsideUnit roadside_;
    OpenXAssetRepository openx_;
    OddCoverageEngine odd_coverage_;
    ThermalRunawayPack runaway_;
    MixedCriticalityVecu vecu_;
    DifferentiableModel differentiable_;
    std::string last_error_;
};

} // namespace aesim::frontier

# Formula One Regulatory and Competition Platform

**Revision:** 2026-08-22  
**Public header:** `include/aesim/advanced/formula_one_regulatory_competition_platform.hpp`  
**Focused library:** `aesim_formula_one`  
**CLI family:** `f1-regulatory`

## Purpose

This platform provides thirty Formula One-specific production systems. The original ten cover the 2026 electrical architecture, full-grid competition, championship governance, power-unit governance, operational restrictions, race-control evidence, pit-lane and parc ferme vision, regulatory case law, accident reconstruction, and Grade 1 circuit qualification. The first 2026-08-22 additive expansion adds component/supply-perimeter governance, fuel-energy-flow forensics, electronic-system legality, power-unit test-bench forensics, gearbox/clutch homologation, cell-resolved energy-store analysis, materials/manufacturing compliance, multimodal track-limits and driving-standards adjudication, wheel-retention/debris dynamics, and on-car marshalling/impact-warning qualification. The second additive expansion adds personnel/curfew governance, regulation-migration impact planning, hot/cold compression-ratio metrology, hybrid degraded-mode qualification, tyre pressure/blanket forensics, dynamic aero photogrammetry, pit-equipment release interlocks, persistent FOD evolution, causal fault isolation, and controlled rulebook-to-executable-check compilation.

The implementation is additive. Existing Formula One physics, race-engineering, performance, team, design, frontier, physical-operations, and championship-operations APIs remain available without source-level changes. `aesim_advanced` links `aesim_formula_one` publicly, so existing aggregate consumers retain access to the complete Formula One stack.

Every domain:

- rejects malformed, duplicate, non-finite, chronologically invalid, or physically impossible input;
- returns a canonical JSON-compatible `doc::Value` report;
- records explicit findings with identifiers, severity, subject, and measured value;
- produces a SHA-256 `evidence_digest` over the complete canonical report;
- optionally writes its report atomically to a caller-supplied working directory;
- is exercised by compiled positive, negative, deterministic, and boundary regressions.

## Public API

```cpp
#include "aesim/advanced/formula_one_regulatory_competition_platform.hpp"

using namespace aesim::advanced::f1reg;

FormulaOneRegulatoryCompetitionPlatform platform;
auto capabilities = platform.capabilities();
auto report = platform.execute("ers-electrical-hardware", request, "evidence/f1");
auto self_test = platform.self_test("evidence/f1-self-test");
```

Direct class entry points are also available:

| System | Public class | Method |
|---|---|---|
| 2026 ERS hardware, metering, and Overtake Mode | `F12026ErsElectrothermalLaboratory` | `evaluate` |
| 22-car full-field competition | `F1FullFieldCompetitionEngine` | `simulate` |
| Championship and Super-Licence governance | `F1ChampionshipGovernancePlatform` | `evaluate` |
| Power-unit homologation and supply | `F1PowerUnitHomologationPlatform` | `evaluate` |
| ATR, CFD, testing, and factory operations | `F1OperationalRestrictionsPlatform` | `evaluate` |
| FIA remote race-control fusion | `F1RemoteRaceControlFusionCenter` | `evaluate` |
| Pit-lane and parc ferme vision | `F1PitLaneVisionOfficiatingPlatform` | `evaluate` |
| Appeals, protests, directives, and precedent | `F1RegulatoryCaseLawCompiler` | `evaluate` |
| ADR and black-box accident reconstruction | `F1AccidentReconstructionLaboratory` | `reconstruct` |
| Grade 1 circuit homologation | `F1CircuitHomologationPlatform` | `evaluate` |
| Component classification and supply-perimeter governance | `F1ComponentClassificationGovernanceEngine` | `evaluate` |
| Fuel energy-flow metering and anti-circumvention | `F1FuelEnergyFlowComplianceLaboratory` | `evaluate` |
| SECU/electronic-system and calibration legality | `F1ElectronicSystemsCompliancePlatform` | `evaluate` |
| Power-unit dyno/test-bench restrictions and forensics | `F1PowerUnitTestBenchForensicsPlatform` | `evaluate` |
| Gearbox, clutch, and torque-transfer homologation | `F1GearboxClutchHomologationTwin` | `evaluate` |
| Cell-resolved ERS energy-store analysis | `F1EnergyStoreCellLaboratory` | `evaluate` |
| FIA materials and manufacturing-process compliance | `F1MaterialsManufacturingComplianceDatabase` | `evaluate` |
| Multimodal track-limits and driving-standards adjudication | `F1TrackLimitsDrivingStandardsLaboratory` | `evaluate` |
| Wheel retention, tethers, and detached-debris dynamics | `F1WheelRetentionDebrisDynamicsLaboratory` | `evaluate` |
| On-car FIA marshalling and impact-warning interface | `F1MarshallingImpactWarningTwin` | `evaluate` |
| Personnel limits, restricted periods, and curfew governance | `F1PersonnelRestrictedPeriodGovernanceEngine` | `evaluate` |
| Regulation migration and design-impact planning | `F1RegulationMigrationDesignImpactPlanner` | `evaluate` |
| Hot/cold compression-ratio metrology | `F1CompressionRatioMetrologyLaboratory` | `evaluate` |
| Single-ICE and hybrid degraded-mode qualification | `F1HybridDegradedModeQualificationPlatform` | `evaluate` |
| Tyre pressure and blanket regulatory forensics | `F1TyrePressureBlanketForensicsLaboratory` | `evaluate` |
| Dynamic on-track aero-deflection photogrammetry | `F1DynamicAeroDeflectionPhotogrammetrySystem` | `evaluate` |
| Pit-equipment telemetry and unsafe-release interlock | `F1PitEquipmentUnsafeReleaseInterlockTwin` | `evaluate` |
| Persistent FOD/debris-field simulation | `F1PersistentFodDebrisFieldSimulator` | `evaluate` |
| Real-time causal fault isolation and root-cause ranking | `F1RealtimeFaultIsolationCausalEngine` | `evaluate` |
| Rulebook-to-executable-checks compilation | `F1RulebookExecutableChecksCompiler` | `evaluate` |

## CLI usage

```bash
./build/full/muzixdiagsys_advanced_platform f1-regulatory capabilities \
  build/f1-regulatory-capabilities.json

./build/full/muzixdiagsys_advanced_platform f1-regulatory self-test \
  build/f1-regulatory-self-test \
  build/f1-regulatory-self-test.json

./build/full/muzixdiagsys_advanced_platform f1-regulatory DOMAIN \
  REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Supported domains:

```text
ers-electrical-hardware
full-field-competition
championship-governance
power-unit-governance
operational-restrictions
remote-race-control
pit-lane-vision
regulatory-case-law
accident-reconstruction
circuit-homologation
component-classification-governance
fuel-energy-flow-compliance
electronic-systems-compliance
power-unit-test-bench-forensics
gearbox-clutch-homologation
energy-store-cell-laboratory
materials-manufacturing-compliance
track-limits-driving-standards
wheel-retention-debris-dynamics
marshalling-impact-warning
personnel-restricted-period-governance
regulation-migration-design-impact
compression-ratio-metrology
hybrid-degraded-mode-qualification
tyre-pressure-blanket-forensics
dynamic-aero-deflection-photogrammetry
pit-equipment-unsafe-release-interlock
persistent-fod-debris-field
fault-isolation-causal-root-cause
rulebook-executable-checks-compiler
```

Canonical requests are in `examples/formula_one_regulatory_competition/`.

## 1. 2026 ERS hardware, energy metering, and Overtake Mode

**Domain:** `ers-electrical-hardware`  
**Class:** `F12026ErsElectrothermalLaboratory`

The laboratory resolves the complete electrical path from the cell topology to MGU-K shaft delivery. Hardware inputs define cell series/parallel topology, capacity, voltage bounds, resistance, thermal capacity, cooling, current limits, MGU-K torque-speed envelope, MGU and inverter efficiency, DC resistance, component thermal limits, isolation threshold, and energy-meter bias/uncertainty.

Mission segments define duration, MGU speed, requested shaft power, available braking power, coolant and ambient temperature, isolation resistance, Straight Mode state, Overtake Mode state, proximity eligibility, and yellow-condition restriction.

The solver performs the following operations for every segment:

1. Validates Overtake Mode eligibility and yellow-condition restrictions.
2. Applies the speed-dependent MGU-K torque and power envelope.
3. Applies lap deployment and harvesting energy limits.
4. Solves the energy-store terminal-current quadratic rather than assuming nominal voltage.
5. Applies charge/discharge current, available-charge, and empty-capacity limits.
6. Recomputes DC power, shaft power, and torque after every limiting operation.
7. Integrates SOC and exact first-order cell, MGU, and inverter thermal states.
8. Accounts for pack resistance, inverter resistance/switching-equivalent losses, and MGU losses.
9. Compares true and reported electrical energy against declared meter uncertainty.
10. Emits isolation, illegal-mode, voltage, thermal, deploy-limit, harvest-limit, and metering findings.

Important outputs include `final_soc`, deployed and harvested energy, electrical loss, true and reported meter energy, meter uncertainty, peak current, peak shaft power, voltage extrema, thermal extrema, segment history, findings, and evidence digest.

## 2. Full-field 22-car, 11-team competition engine

**Domain:** `full-field-competition`  
**Class:** `F1FullFieldCompetitionEngine`

The engine requires exactly 22 unique cars, 22 unique drivers, and 11 unique teams with two cars per team. Each entrant defines baseline pace, skill, aggression, tire management, race-finish reliability, electrical-energy management, planned pit lap, pit loss, initial fuel, and initial electrical energy.

The deterministic lap loop includes:

- exact conversion of race-finish reliability into a per-lap failure probability;
- fuel burn, tire aging, tire-management effects, and traffic-independent pace variation;
- Overtake Mode usage and electrical-energy harvesting;
- planned and degradation-triggered pit stops;
- Safety Car, Virtual Safety Car, and red-flag states;
- incident probability, damage accumulation, and retirement;
- end-of-lap classification;
- pairwise green-flag overtake counting that excludes pit-cycle and retirement changes;
- Grand Prix or configurable Sprint points;
- driver and constructor scoring summaries;
- fixed-seed reproducibility through a platform-local deterministic RNG.

Outputs include complete classification, winner, fastest lap, overtakes, neutralization counts, points, lap summaries, and evidence digest.

## 3. Championship, points, entries, and Super-Licence governance

**Domain:** `championship-governance`  
**Class:** `F1ChampionshipGovernancePlatform`

The governance engine consumes driver credentials, race and Sprint classifications, configurable points tables, partial-points fractions, exclusions, disqualifications, bonus points, points deductions, and championship penalties.

It computes:

- driver and constructor points;
- classification eligibility;
- race and Sprint points;
- disqualification and points-deduction effects;
- race-start and finish records;
- win and countback statistics;
- deterministic championship tiebreaks by finishing-position counts and identifier;
- Super-Licence eligibility from age, possession state, and configurable points threshold;
- final driver and constructor champions;
- event-by-event audit records.

The points rules are data-driven so historical, current, or prospective profiles can be evaluated without code changes.

## 4. Power-unit homologation, supply, parity, and pool governance

**Domain:** `power-unit-governance`  
**Class:** `F1PowerUnitHomologationPlatform`

The platform models manufacturer registration, homologated specification identity, approved software versions, declared supply capacity, works/customer supply records, hardware and software parity, calibration release parity, serialized seasonal elements, seals, allocation limits, grid penalties, and controlled specification changes.

Implemented checks include:

- team supply against a registered manufacturer;
- manufacturer supply-capacity limits;
- hardware identity against the homologated baseline;
- software identity against the approved release set;
- works/customer equivalence across hardware, software, and calibration release;
- duplicate element serial rejection;
- allowed element types and configurable seasonal limits;
- per-driver excess-element grid-penalty calculation;
- change-request gating for reliability, safety, cost-saving, or supply-continuity reasons;
- rejection of incomplete evidence or expected performance-gain changes.

## 5. ATR, wind-tunnel, CFD, testing, and factory operations

**Domain:** `operational-restrictions`  
**Class:** `F1OperationalRestrictionsPlatform`

The operational compliance engine calculates championship-position-dependent ATR entitlement using a configurable factor table. It qualifies wind-tunnel runs, restricted CFD jobs, track-test categories, driver/circuit/instrumentation eligibility, mileage limits, and factory-shutdown observance.

Wind-tunnel checks include nominated facility, occupancy chronology, overlapping records, model scale, run count, and wind-on time. CFD checks include unique job identity, solver, geometry revision, declared Formula One purpose, and restricted compute usage. Track-test categories include TCC, TPC, TMC, tire, young-driver, filming, and demonstration profiles with configurable mileage limits. Factory activities are interval-tested against shutdown periods.

Outputs report allowed and used wind-on hours, run count, compute units, per-category mileage, findings, and evidence digest.

## 6. FIA remote operations and multimodal race-control fusion

**Domain:** `remote-race-control`  
**Class:** `F1RemoteRaceControlFusionCenter`

The fusion center combines video, telemetry, timing, radio, light-panel, marshal, and other evidence through a common observation contract. Every observation has a unique reference, incident identity, source, type, time, latency, confidence, source reliability, involved cars, and optional measured value.

The implementation:

- corrects observation time for source latency;
- groups evidence by incident;
- computes reliability-weighted incident type, event time, and car participation;
- measures synchronization spread;
- applies confidence review thresholds;
- maps incident types to configured rules and recommendations;
- prioritizes incidents by confidence and evidence density;
- calculates authenticated local, remote, and combined network availability;
- identifies the primary control mode;
- creates a SHA-256 chained decision audit log.

Recommendations remain decision support. The system intentionally does not replace human official authority.

## 7. Pit-lane and parc ferme computer-vision officiating

**Domain:** `pit-lane-vision`  
**Class:** `F1PitLaneVisionOfficiatingPlatform`

The platform validates car identity, non-overlapping pit-box geometry, speed limits, line crossings, release gaps, wheel control, wheel-nut retention, car movement before wheel completion, crew placement, equipment obstruction, pit-box use, adjacent-box interference, authorized parc ferme work, like-for-like replacement, and access windows.

Observations are sorted globally and temporally coalesced only when car, violation type, and interval proximity agree. Evidence references are deduplicated. The final violation list is chronological and contains start/end times, confidence, car identity, violation type, and evidence references.

## 8. Appeals, protests, technical directives, and precedent compiler

**Domain:** `regulatory-case-law`  
**Class:** `F1RegulatoryCaseLawCompiler`

The compiler versions rules and directives by identity, jurisdiction, effective time, supersession, repeal state, and tags. Precedents contain jurisdiction, decision time, tags, outcome, and penalty units. Filings support protest, right-of-review, and appeal procedures.

Implemented procedural gates include:

- unique filing identity;
- valid rule and jurisdiction;
- effective and non-repealed rule version;
- standing;
- filing deadline;
- fee payment;
- evidence admissibility;
- the new, significant, and relevant evidence test for right-of-review filings;
- request for a stay of penalty;
- Jaccard tag similarity against earlier precedents in the same jurisdiction;
- deterministic best-precedent selection;
- recommended outcome and penalty units.

## 9. Accident reconstruction, ADR, and black-box forensics

**Domain:** `accident-reconstruction`  
**Class:** `F1AccidentReconstructionLaboratory`

The laboratory ingests serialized vehicle masses, strictly time-ordered telemetry, optional camera-derived positions, and one or more vehicle/barrier contacts. It performs circular heading interpolation, position fusion that does not dilute telemetry speed or acceleration, contact-normal projection, relative closing-speed reconstruction, reduced-mass impulse calculation, delta-V, dissipated energy, barrier deformation, peak acceleration, HIC15 estimate, neck-load estimate, and uncertainty bounds.

Outputs include complete reconstructed trajectories, contact-pair identity, event time, relative speed and angle, impulse, delta-V, energy, deformation, injury-related estimates, uncertainty interval, threshold findings, and evidence digest.

The outputs support engineering investigation; they are not medical diagnoses or legal determinations.

## 10. Grade 1 circuit homologation and safety design

**Domain:** `circuit-homologation`  
**Class:** `F1CircuitHomologationPlatform`

Each circuit segment defines length, radius, width, friction, gradient, crossfall, runoff, runoff deceleration, barrier type and angle, sight distance, drainage capacity, and design rainfall. A reference car defines mass, downforce coefficient, and frontal area.

The platform computes:

- aero-assisted design speed;
- segment kinetic energy;
- energy-based required runoff;
- reaction-and-braking sight distance;
- width compliance;
- barrier-angle compliance;
- drainage margin;
- pit-lane width, fast-lane width, entry, and exit geometry;
- circular marshal-post spacing;
- medical response, medical-center, and helicopter readiness;
- light-panel visibility and redundant power;
- Grade 1 eligibility and certificate status.

An unsafe design returns `certificate_status: withheld`; it never selects a nominal grade merely because the calculation completed.

## 11. Component classification and supply-perimeter governance

**Domain:** `component-classification-governance`  
**Class:** `F1ComponentClassificationGovernanceEngine`

The governance engine classifies serialized components as LTC, SSC, TRC, FSC, OSC, DSC, LPUC, SSPUC, OSPUC, or DSPUC and audits the legal engineering/supply perimeter around each item. It validates unique component and homologation identities, listed-component design authority, standard-supply approval, transferable-component agreements, open-source publication state, defined-specification conformance, and prohibited transfers or engineering-artifact sharing. The result is an auditable component-by-component compliance record rather than a duplicate manufacturing model.

## 12. Fuel energy-flow metering and anti-circumvention

**Domain:** `fuel-energy-flow-compliance`  
**Class:** `F1FuelEnergyFlowComplianceLaboratory`

This laboratory integrates sampled fuel mass flow into true and measured fuel energy using declared lower heating value, meter bias and uncertainty, pressure/temperature state, and downstream storage. It reconstructs engine-side energy demand and detects meter-envelope violations, unexplained accounting residuals, or downstream-energy buffering inconsistent with the declared configuration. Sample history and aggregate energy accounting are retained in the SHA-256 evidence report.

## 13. Electronic systems, SECU signals, and calibration legality

**Domain:** `electronic-systems-compliance`  
**Class:** `F1ElectronicSystemsCompliancePlatform`

The electronic compliance platform audits approved firmware hashes, declared signal/channel identity, sampling and timing properties, undocumented channels, calibration-write authorization and freeze windows, and actuator-control paths. It rejects prohibited closed-loop driver aids and external-inference actuator paths while preserving the existing ECU/HIL and cybersecurity implementations as upstream engineering systems.

## 14. Power-unit test-bench restrictions and dyno forensics

**Domain:** `power-unit-test-bench-forensics`  
**Class:** `F1PowerUnitTestBenchForensicsPlatform`

The dyno forensics platform qualifies declared benches and sessions against approved bench identities, operating-hour budgets, shutdown periods, declaration state, and logged-versus-declared energy. It aggregates utilization by bench, detects undeclared or excessive operation, and exposes the evidence needed to distinguish legitimate test activity from hidden development work.

## 15. Gearbox, clutch, and torque-transfer homologation

**Domain:** `gearbox-clutch-homologation`  
**Class:** `F1GearboxClutchHomologationTwin`

This twin checks homologated ratio identity and ordering, reverse availability, clutch paddle and bite-point behavior, clutch-disengagement operation, driver-requested shifts, automatic-shift prohibitions, shift timing/synchronization, clutch slip energy, and derived wear. It adds Formula One regulatory/homologation logic around the established driveline physics rather than replacing that physics.

## 16. Cell-resolved ERS energy-store laboratory

**Domain:** `energy-store-cell-laboratory`  
**Class:** `F1EnergyStoreCellLaboratory`

The laboratory resolves individual cells through SOC-dependent open-circuit voltage, ohmic and RC polarization, current throughput, capacity fade, thermal evolution, imbalance, voltage/temperature limits, and thermal-runaway state propagation. It is the Formula One-specific regulatory and race-duty layer above the existing general electrification cell/pack implementation.

## 17. Materials and manufacturing-process compliance

**Domain:** `materials-manufacturing-compliance`  
**Class:** `F1MaterialsManufacturingComplianceDatabase`

The database binds serialized material lots to category, process, certificate, density, strength, chemistry, and traceability metadata, then evaluates each component/application against allowed categories, allowed processes, physical-property bounds, prohibited chemistry, and evidence requirements. This connects existing manufacturing physics and provenance to Formula One-specific material legality.

## 18. Multimodal track limits and driving standards

**Domain:** `track-limits-driving-standards`  
**Class:** `F1TrackLimitsDrivingStandardsLaboratory`

The adjudication laboratory fuses weighted wheel-position observations from multiple sensing modalities, propagates uncertainty to each reconstructed contact patch, and determines four-wheel boundary excursions against configured track geometry. It also evaluates declared driving-standard events such as gaining an advantage, unsafe rejoining, forcing another car off, avoidable contact, and yellow-condition conduct, producing evidence intended for review rather than autonomous stewarding.

## 19. Wheel retention, tethers, and detached-debris dynamics

**Domain:** `wheel-retention-debris-dynamics`  
**Class:** `F1WheelRetentionDebrisDynamicsLaboratory`

The safety laboratory resolves wheel/tether load capacity and safety factor, detects single or total tether overload, calculates detached-wheel translational and rotational energy, and integrates a drag-and-gravity projectile trajectory when detachment occurs. The outputs can feed the existing accident-reconstruction and circuit-safety layers without duplicating them.

## 20. On-car marshalling and impact-warning interface

**Domain:** `marshalling-impact-warning`  
**Class:** `F1MarshallingImpactWarningTwin`

This twin models authenticated marshalling channels, channel availability and latency, sector/time state messages, vehicle receipt/display timing, stale or conflicting states, acknowledgements, and impact-triggered warning/medical signalling. It therefore closes the on-car interface between the existing remote race-control, telemetry, driver, and accident-response systems.

## 21. Personnel limits, restricted periods, and curfew governance

**Domain:** `personnel-restricted-period-governance`  
**Class:** `F1PersonnelRestrictedPeriodGovernanceEngine`

The engine reconstructs declared operational and trainee personnel occupancy from ordered entry, exit, and activity events. It validates declarations and credentials, calculates peak concurrent personnel, enforces category limits, evaluates operational activity against restricted periods, tracks approved exceptions, rejects duplicate entry/unmatched exit states, and produces a time-indexed compliance trail. It is an event/governance layer over existing team-operations systems, not a duplicate staffing scheduler.

## 22. Regulation migration and design-impact planning

**Domain:** `regulation-migration-design-impact`  
**Class:** `F1RegulationMigrationDesignImpactPlanner`

This planner compares rule digests between regulation issues, maps changed-rule tags to engineering artifacts, propagates impact through declared artifact dependencies, rejects dependency cycles, and computes direct/indirect impact counts, validation effort, requalification cost, and dependency-aware critical-path lead time. The result identifies which CAD, CFD, test, calibration, manufacturing, or evidence artifacts require requalification when a rule revision changes.

## 23. Hot/cold compression-ratio metrology

**Domain:** `compression-ratio-metrology`  
**Class:** `F1CompressionRatioMetrologyLaboratory`

The laboratory computes swept volume from measured bore/stroke, reconstructs compression ratio from measured chamber clearance, applies clearance-volume measurement uncertainty conservatively, checks hot and cold temperature windows, requires both conditions for every cylinder, and compares measured chamber volume with a first-order thermal-expansion prediction. A design fails if the uncertainty-bounded upper compression ratio exceeds the configured regulatory limit.

## 24. Hybrid degraded-mode qualification

**Domain:** `hybrid-degraded-mode-qualification`  
**Class:** `F1HybridDegradedModeQualificationPlatform`

This state-machine qualifier evaluates NORMAL_HYBRID, DEGRADED_HYBRID, SINGLE_ICE, and SAFE_SHUTDOWN operation from ICE, energy-store, inverter, MGU-K, isolation, cell-voltage, temperature, SOC, contactor, and driver-demand state. It integrates SOC over mission steps, computes delivered/unmet power, verifies safe HV isolation, and rejects MGU-K requests during Single-ICE operation. It layers regulatory degraded-state behavior over the existing ERS/electrification physics.

## 25. Tyre pressure and blanket regulatory forensics

**Domain:** `tyre-pressure-blanket-forensics`  
**Class:** `F1TyrePressureBlanketForensicsLaboratory`

The forensics layer validates unique tyre/set serialization, conservative cold pressure after sensor uncertainty, blanket temperature and exposure time, and time-ordered pressure/temperature observations. It calculates ideal-gas thermal pressure baselines, residuals, pressure-drop rates, and documented bleed exceptions to distinguish normal thermal evolution from under-pressure setup or unexplained pressure manipulation.

## 26. Dynamic on-track aero-deflection photogrammetry

**Domain:** `dynamic-aero-deflection-photogrammetry`  
**Class:** `F1DynamicAeroDeflectionPhotogrammetrySystem`

Calibrated camera origins and unit observation rays are fused by a least-squares three-dimensional line-intersection solve for every marker and frame. The system projects marker displacement along declared surface normals, reports ray RMS reconstruction error, compares dynamic deflection against configured legality limits, and correlates measured deflection with supplied FE predictions. This is a specialist dynamic-compliance layer above existing static scrutineering, CFD, FE, and generic photogrammetry capabilities.

## 27. Pit-equipment telemetry and unsafe-release interlock

**Domain:** `pit-equipment-unsafe-release-interlock`  
**Class:** `F1PitEquipmentUnsafeReleaseInterlockTwin`

The twin evaluates all four wheel-gun channels using nut torque, engagement angle, packet age, signature validity, nut/wheel presence, jack state, auxiliary sensor freshness, release-light timing, and approaching-car time-to-conflict. It independently computes whether release is safe and detects false-green commands, stale sensor releases, incomplete wheel retention, jack-up releases, and traffic conflicts.

## 28. Persistent FOD and debris-field simulation

**Domain:** `persistent-fod-debris-field`  
**Class:** `F1PersistentFodDebrisFieldSimulator`

The simulator maintains debris objects across vehicle passes and cleanup events rather than treating debris as a one-shot collision. Carbon, metal, and other particles carry position, mass, area, sharpness, blockage factor, and persistence. Encounters accumulate puncture probability, radiator and brake-duct blockage, floor impact energy, wake-driven lateral displacement, and debris decay; cleanup removes a configured spatial fraction of the persistent field.

## 29. Real-time causal fault isolation and root-cause ranking

**Domain:** `fault-isolation-causal-root-cause`  
**Class:** `F1RealtimeFaultIsolationCausalEngine`

A directed causal graph links sensor, mechanical, electrical, software, and thermal nodes. The engine propagates causal reachability, combines configured priors with abnormal/normal residual evidence using a deterministic Bayesian likelihood model, normalizes posterior root probabilities, reports posterior entropy, ranks root causes, and recommends follow-up tests by expected information gain per test cost. This separates symptoms such as sensor excursions from upstream physical causes.

## 30. Rulebook-to-executable-checks compiler

**Domain:** `rulebook-executable-checks-compiler`  
**Class:** `F1RulebookExecutableChecksCompiler`

The compiler accepts controlled scalar comparison requirements and applicability expressions over dotted fact paths, compiles them into an intermediate representation, resolves rule cross-references, rejects reference cycles, requires explicit human approval, surfaces unresolved ambiguity terms, executes applicable rules against supplied facts, and runs declared positive/negative regression vectors. Generated checks are therefore inspectable and testable; the system does not treat unconstrained natural-language parsing as authoritative law.

## Focused build and validation

```bash
cmake -S . -B build/f1-regulatory -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DBUILD_TESTING=ON

cmake --build build/f1-regulatory --parallel --target \
  aesim_formula_one \
  formula_one_regulatory_competition_platform_tests

ctest --test-dir build/f1-regulatory --output-on-failure \
  -R '^formula_one_.*_unit_tests$'

python3 tests/formula_one_regulatory_competition_source_regression.py .
python3 tests/documentation_consistency_regression.py .
python3 tests/user_manual_regression.py .
```

Sanitizer validation may be performed through the project option or by instrumenting the four regulatory production translation units and compiled test with AddressSanitizer and UndefinedBehaviorSanitizer.

## Qualification boundaries

This platform is an engineering, rules-development, training, and evidence-organization system. It does not grant FIA homologation, issue a Super Licence, authorize an Overtake Mode activation, impose a sporting penalty, certify an energy meter, approve a power-unit change, certify a circuit, or replace officials, stewards, medical professionals, accredited metrology, or formal legal proceedings.

Regulatory thresholds and procedures are deliberately configurable. Before using an output for a real program, bind the request to the applicable regulation issue, event notes, technical directives, measurement procedures, track certificate, and official decisions. Preserve the request, executable identity, source revision, result, and evidence digest together.

## Motorsport CLI convenience aliases

The original `f1-regulatory` family remains authoritative. Additive suite routing is available through `f1 run regulatory DOMAIN ...`; shortcuts include `f1-race`, `f1-ers`, and `f1-race-control`. See `MOTORSPORT_CLI_COMMANDS.md`.

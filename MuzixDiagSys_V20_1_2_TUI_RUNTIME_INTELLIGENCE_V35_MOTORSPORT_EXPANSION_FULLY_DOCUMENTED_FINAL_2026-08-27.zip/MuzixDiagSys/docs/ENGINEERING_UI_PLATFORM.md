# Engineering UI Platform

MuzixDiagSys exposes the engineering UI as an additive `ui ...` namespace in the authenticated `muzixdiagsys` shell. The implementation is shared with the existing simulator/backend state; it does not replace or remove legacy command families. The terminal and browser surfaces execute canonical shell commands rather than maintaining a second simulation-control implementation.

## Architecture and data policy

The platform is implemented by `include/aesim/app/engineering_ui_platform.hpp`, `src/ui/engineering_ui_platform.cpp`, and `src/ui/advanced_engineering_workbenches.cpp`, with live integration in `src/ui/console_frontend.cpp` and `src/simulation_runtime.cpp`. Live workbenches consume backend telemetry returned through `Backend::engineering_ui_metrics()`. If the active backend does not expose a quantity, the UI reports it as unavailable instead of fabricating a value. Artifact digests are real SHA-256 digests. Runtime profiling reads operating-system/process counters and, when installed, NVIDIA or AMD GPU telemetry.

A synchronized time cursor is shared by telemetry interpolation, trace-window inspection, solver-window reporting, configuration/result capture, and automotive visualization. This makes historical inspection deterministic across workbenches rather than letting each pane maintain an unrelated notion of time.

## 1. Terminal capability negotiation

`ui terminal status` reports terminal geometry and detected color, Unicode, Braille, SGR mouse, focus, bracketed-paste, synchronized-output, Sixel, Kitty graphics, OSC-8, OSC-52, and enhanced keyboard capabilities. Detection uses the active TTY/environment plus explicit `MUZIX_*` overrides so remote/SSH environments can be qualified rather than guessed.

## 2. SGR mouse interaction and hit testing

Interactive terminal mode enables SGR mouse reporting and decodes press, release, drag, motion, wheel, modifier, and button events. A z-ordered hit-test map is rebuilt from rendered regions. The shell uses it for pane focus, output-record selection, contextual inspection/bookmarking, output scrolling, dashboard/watch-page scrolling, and overlay navigation. Mouse protocol handling is restored when terminal mode exits.

## 3. Dashboard/layout designer

Use `ui dashboard-designer ...` for transactional dashboard editing:

```text
ui dashboard-designer list
ui dashboard-designer create dyno "Dyno Validation" 12
ui dashboard-designer add dyno rpm 0 0 4 2 rpm "Engine RPM"
ui dashboard-designer move dyno rpm 4 0
ui dashboard-designer resize dyno rpm 6 3
ui dashboard-designer clone dyno rpm rpm-copy
ui dashboard-designer set dyno rpm title "Powertrain RPM"
ui dashboard-designer undo dyno
ui dashboard-designer redo dyno
ui dashboard-designer show dyno
```

Grid bounds and overlap constraints are validated before mutation; failed edits leave the previous valid layout intact. Undo/redo operates on valid layout revisions.

## 4. Global synchronized time cursor

```text
ui time status
ui time set 12.5
ui time window 5
ui time play
ui time pause
ui time speed 0.25
ui time follow on
ui time next-event
ui time previous-event
ui time bookmark braking
ui time goto-bookmark braking
ui time event 12.63 ABS_ENTRY
```

The cursor can follow live simulation time or inspect historical samples. Window-aware trace and solver commands use the same cursor/window interval.

## 5. Multi-signal oscilloscope / telemetry workbench

```text
ui scope list
ui scope show
ui scope stats rpm
ui scope fft rpm
ui scope hist rpm
ui scope corr rpm torque_nm
ui scope clear
```

The workbench stores timestamped live channels and provides interpolation, min/max/mean/RMS/standard deviation, histogramming, Hann-windowed frequency analysis, correlation, and text rendering. Live signals are also indexed by structured global search.

## 6. Network/protocol trace analyzer

```text
ui trace-analyzer show
ui trace-analyzer window protocol:UDS
ui trace-analyzer add uds CAN1 0x7E8 62 F1 90 41
ui trace-analyzer inspect 1
ui trace-analyzer clear
```

The analyzer accepts CAN, CAN FD, CAN XL, LIN, FlexRay, Ethernet, SOME/IP, DoIP, UDS, XCP, DDS, ROS 2, V2X, OPC UA, and custom trace records. UDS, DoIP, SOME/IP, and CAN-family records receive protocol-aware decoding; every supported protocol retains raw payload visibility. Filters support `:`, equality/inequality, and numeric comparison operators. `window` automatically constrains results to the synchronized time interval.

## 7. Configuration/result diff and merge viewer

```text
ui compare capture baseline
ui compare capture candidate
ui compare show baseline candidate
ui compare merge base left right merged
ui compare accept merged rpm candidate
ui compare list
```

The viewer compares typed property bags, reports changed fields, performs real three-way merge conflict analysis, and supports explicit field acceptance. Shell `capture` records the active backend metrics at the synchronized time cursor, making it suitable for result-state comparisons as well as programmatic configuration bags.

## 8. Workflow graph editor

```text
ui workflow-editor create validation "Validation"
ui workflow-editor add-node validation load "Load Dataset"
ui workflow-editor add-node validation run "Run Simulation"
ui workflow-editor connect validation load run
ui workflow-editor start validation load
ui workflow-editor show validation
```

The editor performs graph CRUD against the production `globalui::WorkflowGraph` data structure, including node deletion and edge disconnection. It is a graph authoring/inspection surface; existing workflow execution commands remain authoritative for workflow execution.

## 9. Solver/convergence console

`ui solver-console status`, `window`, `sample`, and `clear` operate on real backend solver channels. Local error and timestep are recorded when exposed. Residuals, condition numbers, and iteration counts remain `n/a` unless the active backend supplies them; the UI does not infer or fabricate solver diagnostics.

## 10. Runtime CPU/GPU/MPI profiler

`ui profiler sample` samples process RSS/I/O and Linux CPU deltas, detects MPI rank/size from standard launch environments, and reads NVIDIA GPU utilization/memory through an absolute `nvidia-smi` path or AMDGPU sysfs when those facilities exist. `ui profiler show` renders history; unavailable devices remain explicitly unavailable.

## 11. Experiment matrix UI

```text
ui experiments add run-001 complete pressure=22.1 wing=7 obj.lap=87.41 tag.series=f1
ui experiments list series:f1
ui experiments pareto lap
ui experiments remove run-001
```

Rows carry numeric parameters, objectives, state, and tags. Filtering and Pareto-front computation operate on the stored matrix.

## 12. Artifact/evidence browser

```text
ui artifacts index build/evidence
ui artifacts list
ui artifacts inspect build/evidence/result.json
```

Indexing recursively records actual filesystem size, modification metadata, SHA-256, and recognized signature/bundle sidecars. It does not substitute filename-derived or synthetic hashes.

## 13. Regression triage dashboard

`ui regressions load <ctest-log>` parses standard CTest output, including dotted progress records and `***Failed` markers, then classifies pass/fail/timeout/skip outcomes for `ui regressions status`.

## 14. Automotive engineering visualizations

```text
ui vehicle-viz four-corner
ui vehicle-viz system-flow
ui vehicle-viz energy-flow
```

The four-corner view uses live tire temperature, slip, and load. Tire pressure is printed only when a pressure channel is supplied by the active backend. System flow uses live powertrain/thermal quantities. Energy flow uses live fuel-chemical, shaft, friction, and wheel-power channels and computes efficiency only when the required measurements exist.

## 15. Persistent attach/detach and observer sessions

```text
ui sessions create validation "Validation Session"
ui sessions detach validation
ui sessions attach validation
ui sessions observe validation reviewer
ui sessions release validation reviewer
ui sessions rename validation "Final Validation"
ui sessions list
```

Sessions persist a restorable simulator/UI state snapshot plus owner/read-only-observer metadata. Session identifiers are path-safe, registry/state files are owner-only on POSIX, and only the logical owner may take control. This is simulator-state persistence and observer metadata; it does not daemonize a running simulator process or replace `tmux`/systemd for process survival after the simulator itself exits.

## 16. Braille, Sixel, and Kitty high-resolution rendering

`ui graphics mode auto|ascii|unicode|braille|sixel|kitty` selects the rendering backend. Auto mode negotiates from terminal capabilities. Braille performs actual 2x4-dot bitmap packing. Sixel and Kitty modes emit their native graphics escape sequences; ASCII/Unicode remain portable fallbacks.

## 17. Structured global search

Examples:

```text
ui global-search kind:workbench
ui global-search kind:signal rpm
ui global-search kind:command battery
ui global-search -kind:signal validation
```

Documents support free text, field filters, and negation. Existing command metadata, workbenches, dashboards, and live signal channels are indexed rather than maintaining a disconnected search catalog.

## 18. OSC-8 hyperlinks and secure OSC-52 clipboard

`ui osc hyperlink <target> <label>` emits OSC-8 only when allowed and strips control characters from labels/targets. OSC-52 clipboard output is opt-in with `ui osc clipboard-on`, has a maximum payload, and refuses values explicitly marked sensitive by callers. Clipboard integration is off by default.

## 19. Context breadcrumbs, peek panels, and pinned inspectors

```text
ui context visit vehicle://active
ui context breadcrumbs
ui context back
ui context forward
ui context peek signal://rpm
ui context pin signal://rpm
ui context inspectors
ui context unpin signal://rpm
```

Navigation maintains independent back/forward history, a transient peek target, and persistent pinned inspector targets over the shared `globalui::ContextGraph`.

## 20. First-class browser engineering UI

```text
ui web start
ui web start 8080 127.0.0.1
ui web status
ui web stop
```

The built-in HTTP server serves the V18 browser engineering desktop over the existing authenticated `/api/state`, `/api/schema`, `/api/stream`, and `/api/command` endpoints. It uses a per-process 128-bit bearer token, constant-time token comparison, restrictive CSP, bounded command queues/payloads, deterministic header parsing, and canonical shell-command execution. Remote bind addresses are rejected unless `MUZIX_WEB_ALLOW_REMOTE=1` is explicitly set.

The V18 browser surface adds operational functionality without adding feature-specific mutation endpoints:

- **Live Operations Cockpit** — live KPI cards, bounded sparkline history, stream age/drop indicators, dashboard freeze/live/baseline controls, `what-changed`, and SOE first-out actions.
- **Canonical Command Staging** — add, inspect, clear, toggle atomic mode, and commit through the pre-existing `ui command-stage` authority. Commit-time revalidation and rollback restrictions are unchanged.
- **Canonical Macro Library** — record, stop/cancel, inspect, persist, load, and run macros through `ui macro`; the browser does not keep a second macro registry.
- **Incident / First-Out Response** — one-place access to SOE, alarm-flood, transient-lens, change-investigator, and incident-workspace commands.
- **Engineering Scratchpad / Unit Calculator** — dimension-checked expression evaluation and unit conversion through the existing virtual-channel and semantic-unit services.
- **Persistent browser presentation preferences** — workbench favorites, command history, and signal watchlists are stored only as browser-local presentation preferences. They do not replace simulator/workspace state.
- **Signal Watchlist** — up to 24 canonical streamed signals with live values and client-side sparklines derived from the bounded `/api/stream` frame cache.
- **Workbench discovery** — text filtering and favorites in the authoritative `/api/schema` workbench list.
- **Problems controls** — severity filtering, clear/export, and inspector drill-in over the existing browser Problems collection.
- **Bounded browser exports** — client-side CSV export of the already-received telemetry frame cache and JSON snapshot export of `/api/state`; no filesystem mutation endpoint is added.
- **Quick controls** — Status, Quickstart, Run loop, Pause loop, and deterministic Step dispatch the same canonical commands as the shell.
- **Keyboard workflow** — `Ctrl/Cmd+K` workbench filter, `Ctrl/Cmd+L` command line, `Ctrl/Cmd+Shift+P` Command Palette, `Ctrl/Cmd+Shift+O` Live Operations, `Ctrl/Cmd+Shift+S` Command Staging, and Up/Down command history.

The browser remains a presentation/client layer. Simulation, telemetry, SOE, incident analysis, macro storage, command staging, unit conversion, dashboard references, run comparison, and diagnostics remain owned by their existing C++ authorities.

## 21. Engineering Mission Control

Mission Control is the operational control plane for active engineering work. It combines live simulator telemetry, host/GPU profiler state, explicit subsystem readiness, the shared `globalui::JobManager`, regression health, and deduplicated operator alerts.

```text
ui mission-control status
ui mission-control jobs
ui mission-control submit "Thermal sweep" experiment run thermal-sweep
ui mission-control state 1 running
ui mission-control progress 1 42 sampling-cell-17
ui mission-control subsystem hil-rack degraded "PTP offset above target"
ui mission-control alert warning "Timing drift" "HIL timing margin reduced"
ui mission-control ack 1
ui mission-control cancel 1
```

`submit` registers a tracked engineering job; it does not pretend that a shell command has been launched asynchronously. State/progress changes are explicit and use the same validated `JobManager` state ledger that other UI infrastructure can consume. The status page reports active/non-terminal jobs, current process/GPU resource data when available, registered subsystem health, unacknowledged alerts, and non-passing regression count. Repeated equivalent unacknowledged alerts are coalesced with an occurrence count.

## 22. N-Way Run Comparison Workbench

The run-comparison workbench stores complete timestamped channel histories and compares one baseline against any number of candidate runs.

```text
ui run-compare capture baseline "Baseline setup"
ui scope clear
# execute another run and collect telemetry
ui run-compare capture candidate-a "Candidate A"
ui run-compare baseline baseline
ui run-compare compare speed_kmh time
ui run-compare compare speed_kmh distance_m
ui run-compare envelope speed_kmh time
ui run-compare load-csv dyno-17 results/dyno17.csv time_s
ui run-compare show dyno-17
ui run-compare list
```

`capture` copies the real in-memory telemetry histories accumulated by `TelemetryWorkbench`; when no history exists it captures the current backend metric snapshot rather than fabricating a waveform. `load-csv` performs quoted CSV parsing and accepts any numeric signal columns. Alignment supports `time`, `index`, or any numeric channel such as `distance_m`, `lap`, or `crank_angle`. Channel values are linearly interpolated onto the baseline alignment coordinates over the common domain. The report computes paired sample count, baseline/candidate means, bias, MAE, RMSE, maximum absolute delta, and Pearson correlation. `envelope` emits aligned min/mean/max/count data across all stored runs.

## 23. Requirements–Verification–Evidence Matrix

The V&V matrix creates an explicit trace from requirement to verification case to immutable evidence digest.

```text
ui verification-matrix add-requirement REQ-BRK-001 "Dry stopping distance" standard=Internal-VV clause=4.2 owner=VehicleDynamics criticality=safety
ui verification-matrix add-verification VER-BRK-001 "100-0 stop" req=REQ-BRK-001 run=run-42 metric=stopping_distance_m observed=34.9 expected=35.0 tolerance=0.5
ui verification-matrix evidence VER-BRK-001 reports/run-42/brake.csv "signed acceptance result"
ui verification-matrix matrix
ui verification-matrix coverage
ui verification-matrix trace REQ-BRK-001
ui verification-matrix stale
```

A verification with finite `observed`, `expected`, and non-negative `tolerance` automatically derives pass/fail when no verdict was explicitly supplied. Evidence attachment requires an existing regular file and records its actual SHA-256 and byte size. Matrix, coverage, and trace evaluation re-hash evidence on demand, so deletion or modification changes the effective requirement state to `stale`. Aggregate requirement verdicts propagate fail, stale, inconclusive, and unverified states rather than collapsing them into a single Boolean. Coverage reports verification coverage, evidence coverage, orphan requirements, and stale-artifact count.

## 24. Design-Space Explorer

Design-Space Explorer operates directly on the existing `ExperimentMatrix`; there is no second experiment database.

```text
ui design-space summary
ui design-space summary series:f1
ui design-space sensitivity lap
ui design-space correlations
ui design-space parallel
ui design-space feasible obj.lap<88 pressure>=22
ui design-space pareto lap energy
```

The explorer computes parameter/objective ranges and means, pairwise-complete Pearson correlation matrices, objective sensitivity rankings by absolute correlation, and a normalized parallel-coordinate table suitable for SSH terminals. Feasibility expressions support `<`, `<=`, `>`, `>=`, `=`, `==`, and `!=`; prefix objective fields with `obj.` and optionally parameters with `p.`/`param.`. Missing fields make a run infeasible rather than silently substituting values. Pareto results are provided by the existing experiment engine so optimization semantics stay consistent.

## 25. Engineering Flight Recorder

The Flight Recorder is a bounded multitrack operational history. The central console command lifecycle automatically records command submissions and command results for both normal simulator commands and `ui ...` commands. Live engineering telemetry is recorded at a bounded one-second simulation-time cadence so the recorder remains useful during high-rate solver execution without becoming an unbounded per-step log.

```text
ui flight-recorder status
ui flight-recorder show
ui flight-recorder show kind:command
ui flight-recorder show severity:error after:120 before:180
ui flight-recorder inspect 42
ui flight-recorder bookmark "braking onset"
ui flight-recorder record safety warning "ABS intervention" "front-left wheel slip exceeded target"
ui flight-recorder capacity 500000
ui flight-recorder export-jsonl reports/run-42-flight.jsonl
ui flight-recorder export-csv reports/run-42-flight.csv
ui flight-recorder clear
```

Structured filters include `kind:`, `severity:`, `uri:`, `command:`, `after:`, and `before:`; a leading `-` negates a term. Each event carries an immutable sequence number, wall-clock timestamp, simulation time when available, severity, kind, title, detail, object URI, command/correlation metadata, and optional numeric metrics. JSONL export preserves the metric map and full event schema; CSV export provides interoperable tabular event records. Capacity is validated between 100 and 5,000,000 events and uses FIFO eviction.

The browser workbench exposes direct launch controls for Mission Control, N-Way Run Comparison, the V&V Matrix, Design-Space Explorer, and Flight Recorder. Those controls execute the same canonical commands as the terminal; no simulation or analysis logic is duplicated in JavaScript.

## 26. Unified Engineering Workspace

The **Unified Engineering Workspace** is a coordinated projection over the existing schema-driven desktop. It is not a second desktop engine. The built-in `unified-engineering` workspace opens the command palette, time-travel timeline, Signal Explorer, Run Manager, Professional Diagnostic Center, Causal Difference Explorer, persistent Dashboard Builder, CLI/GUI Equivalence view, and TUI Pane/Layout controller as tabs backed by the same authoritative models used by terminal commands and the browser API.

```text
ui desktop select unified-engineering
ui desktop workspace-json
ui desktop workbenches
```

The original `default` workspace remains the startup selection, so the new workspace is additive and does not change existing startup behavior. Browser workbenches issue canonical `ui ...` commands through `/api/command`; they do not duplicate simulator state or engineering algorithms in JavaScript.

## 27. Universal Command Palette

`ui palette <query>` now merges the existing Experience Manager command/action index with `StructuredGlobalSearch`, which indexes registered workbenches, canonical engineering operations, live signal metadata, diagnostic/run-management actions, and other structured engineering objects. Duplicate invocations are removed and normal access-policy evaluation is applied before a result is exposed as executable.

```text
ui palette tire temperature
ui palette run manager
ui palette time checkpoint
ui palette diagnostic
```

F2/Ctrl-Space continues to open the interactive terminal palette. The browser Command Palette workbench uses the same command route. An unavailable result remains visible with its blocking reason rather than bypassing command access policy.

## 28. Timeline and real time-travel interface

`SynchronizedTimeCursor` now exposes a bounded textual timeline, range queries, event navigation, named bookmarks, playback/follow-live state, and real simulator checkpoints. Cursor movement and simulator-state restoration are deliberately separate operations.

```text
ui time timeline
ui time bookmark braking-onset
ui time bookmarks
ui time goto-bookmark braking-onset
ui time checkpoint pre-fault
ui time restore pre-fault
```

`bookmark` records a temporal reference only. `checkpoint` calls the production `Backend::capture_ui_state()` serializer and stores the state through the existing Experience Manager branch mechanism under `timeline.<name>`. `restore` retrieves that branch and calls `Backend::restore_ui_state()`. Successful checkpoint/restore activity is also recorded in the existing Engineering Flight Recorder. A restore therefore changes real simulator/controller state; moving the cursor or visiting a bookmark does not.

The browser Time Travel workbench exposes these exact canonical operations. Existing Studio time-travel/debugger facilities remain authoritative for their established workflows; this UI layer does not introduce another simulation-state engine.

## 29. Causal Difference Explorer

The Causal Difference Explorer extends the existing `NWayRunComparisonWorkbench`. It computes aligned candidate-to-baseline signal divergence using interpolation, absolute/relative tolerances, first-divergence time, maximum absolute difference, and RMSE. A dependency graph constrains upstream evidence traversal and can attach maximum-lag and confidence metadata.

```text
ui run-compare baseline run-A
ui causal-difference divergences run-B 1e-6 1e-4
ui causal-difference explain run-B vehicle.speed 1e-6 1e-4
ui causal-difference add-edge throttle vehicle.speed 0.5 0.95
ui causal-difference graph
```

This workbench is an **evidence navigator**, not an unsupported causal-inference claim. A displayed path means that signals both diverged and are connected by the declared dependency model within the configured timing constraints. The existing research-grade causal analyzer remains available for workflows that require its deeper counterfactual/causal machinery.

## 30. Persistent Telemetry Dashboard Builder

`DashboardDesigner` remains the single dashboard composition engine and now supports deterministic, validated persistence in the `MZUX-DASHBOARD|1` format. Existing create/add/remove/clone/move/resize/set/undo/redo operations are unchanged.

```text
ui dashboard-designer create powertrain "Powertrain Lab" 12
ui dashboard-designer add powertrain rpm 0 0 4 2 engine.rpm "Engine RPM"
ui dashboard-designer add powertrain speed 0 4 4 2 vehicle.speed "Vehicle Speed"
ui dashboard-designer save ./powertrain-dashboard.mzux
ui dashboard-designer load ./powertrain-dashboard.mzux
```

Loads validate the header, dashboard geometry, IDs, widget limits, and encoded fields before replacing the active collection. Saves use temporary-file plus rename replacement so a failed write does not leave a partially written dashboard collection.

## 31. Experiment / Run Manager

The existing `ExperimentMatrix` is the authoritative run database. The Run Manager enriches each run with reproducibility/provenance fields while preserving the original parameter/objective/tag representation: parent run, scenario, vehicle, configuration hash, build ID, host, random seed, start/completion timestamps, notes, and artifact references.

```text
ui run-manager list
ui run-manager add run-042 complete scenario=wet-braking vehicle=prototype seed=42 param.mu=0.72 obj.stop_m=36.8 tag.series=validation
ui run-manager inspect run-042
ui run-manager state run-042 accepted
ui run-manager annotate run-042 "Validated against proving-ground dataset PG-218"
ui run-manager artifact run-042 reports/run-042.csv
ui run-manager save ./campaign-runs.mzux
ui run-manager load ./campaign-runs.mzux
ui run-manager pareto stop_m energy_kwh
```

Persistence uses the validated `MZUX-RUNS|1` format and atomic replacement. `Design-Space Explorer`, DOE/optimization tools, and run-comparison workbenches continue to consume this same matrix; no duplicate experiment database was introduced.

## 32. Signal Explorer and Professional Diagnostic Center

### 32.1 Signal Explorer

`TelemetryWorkbench` now associates optional engineering metadata with its existing signal histories. Search covers canonical name, label, unit, subsystem, source, description, tags, and consumers. The inspector reports current/statistical state, validated range, nominal sample rate, provenance, and producer/consumer context while preserving the same underlying telemetry series used by Scope and plotting tools.

```text
ui signal-explorer list
ui signal-explorer search brake temperature
ui signal-explorer inspect vehicle.speed
ui signal-explorer history vehicle.speed 120 135
ui signal-explorer set-meta vehicle.speed label="Road Speed" unit=m/s subsystem=vehicle source=dynamics tags=kinematics,validation consumers=dashboard,controller min=0 max=120 rate=100
```

### 32.2 Professional Diagnostic Center

The Professional Diagnostic Center aggregates—not duplicates—existing Mission Control alerts, regression failures, solver-health samples, and warning/error events from the Engineering Flight Recorder. Each item has a stable reference such as `alert:17`, `flight:42`, `solver:latest`, or `regression:test_name`.

```text
ui diagnostic-center status
ui diagnostic-center explain alert:17
ui diagnostic-center explain solver:latest
ui diagnostic-center explain regression:vehicle_dynamics_regression
ui diagnostic-center ack 17
ui diagnostic-center clear 17
```

`explain` provides correlated evidence and source context. Alert acknowledgement/clearing delegates to Mission Control; the diagnostic center does not maintain a shadow alarm database.

## 33. TUI Pane/Layout Framework and CLI/GUI Equivalence

### 33.1 TUI pane/layout framework

`TuiPaneLayoutManager` provides named, persistent terminal arrangements over the existing dashboard, output/diagnostic, command, and watch renderers. Pane visibility/focus maps to the existing terminal frontend state. Horizontal layouts render dashboard/watch panes side-by-side when the terminal is sufficiently wide; vertical layouts weight analytical versus lower-pane space. No duplicate dashboard or output renderer is created.

```text
ui pane status
ui pane layouts
ui pane create trackside horizontal
ui pane add telemetry dashboard 2.0
ui pane add signals watch 1.0
ui pane add evidence diagnostics 1.0
ui pane focus telemetry
ui pane resize signals 1.5
ui pane hide evidence
ui pane show evidence
ui pane save ./tui-layouts.mzux
ui pane load ./tui-layouts.mzux
```

The built-in `engineering` layout remains available. Persistence uses `MZUX-TUI-LAYOUT|1` and validates names, pane IDs/views, weights, visibility, focus, and orientation before accepting state.

### 33.2 CLI/GUI equivalence layer

`CliGuiEquivalenceRegistry` records the mapping from a UI action ID to its canonical command, label, context, and mutating/read-only character. Both TUI and browser users can inspect the mapping directly:

```text
ui equivalence list
ui equivalence search timeline
ui equivalence show timeline.checkpoint
```

The mapping is descriptive and auditable; command execution still travels through the canonical console command dispatcher and access policy. The browser's dedicated V20.1.2 workbenches invoke the mapped command paths, which prevents GUI-only behavior from diverging from CLI semantics.

## Qualification

Focused release checks are:

```bash
cmake --build build/full --target engineering_ui_platform_tests -j2
./build/full/engineering_ui_platform_tests
python3 tests/engineering_ui_platform_regression.py .
python3 tests/professional_ui_workbenches_cli_regression.py build/full/muzixdiagsys
python3 tests/backend_executable_cli_parity_regression.py ...
python3 tests/duplicate_implementation_regression.py .
python3 tests/build_warning_policy_regression.py .
python3 tests/source_package_regression.py .
```

The original Unified Engineering UI C++ qualification exercised 33 feature families, including a real loopback browser request/authorization/command round trip. The V17 research-grade workbenches expanded that suite to 61 feature families; the V20.1.2 integrated terminal cockpit now exercises **69 feature families** in the same authoritative C++ suite. The end-to-end InteractiveShell regression exercises **55 UI capability routes**. The source regression verifies concrete class, shell-route, CMake, security, API/CLI-equivalence, and real-data integration markers and rejects unfinished implementation markers.

## V12 professional engineering desktop

The V12 layer extends the existing engineering UI rather than replacing it. `SchemaDrivenEngineeringDesktop` maintains recursive dock trees and detached windows with monitor/geometry metadata, persisted in the `MZDX12` workspace format. `BrowserEngineeringServer` exposes `/api/schema` and an authenticated resumable `/api/stream` path; the browser uses those interfaces and the same canonical command executor as SSH/terminal operation.

`CampaignOrchestrationResourcePlanner` invokes the production `aesim::platform::CampaignManager`, while `AdaptiveDoeOptimizationStudio` stages LHS, low-discrepancy, Gaussian-process expected-improvement, uncertainty, and hybrid proposals directly into the existing `ExperimentMatrix`. The scenario timeline emits validated canonical JSON. The workflow debugger queues actual canonical commands and observes their results. Review decisions are SHA-256 chained. Topology consumes real trace frames. Virtual channels are parsed and dimension checked before entering `TelemetryWorkbench`. Plot tools operate on actual telemetry series and support cursor/delta/slope/statistics/integral/threshold/rise/settling/overshoot measurements plus durable annotations.

Operator command families:

```text
ui desktop ...
ui stream ...
ui campaign ...
ui adaptive-doe ...
ui scenario-timeline ...
ui workflow-debugger ...
ui review-center ...
ui topology ...
ui virtual-channel ...
ui plot-tools ...
```

## V13 professional engineering operations

The schema-driven desktop now registers six additional workbenches: `digital-twin-3d`, `runbook`, `release-planner`, `data-catalog`, `calibration-correlation`, and `collaboration`. The 3D twin consumes live telemetry; calibration reuses `CalibrationMapStudio`; release planning reuses ContextGraph, V&V and regression triage; runbook/catalog evidence use production SHA-256; live collaboration complements rather than duplicates persistent Collaborative Engineering Studio review/versioning.

## V16 graphical engineering desktop

V16 retains every terminal/browser UI capability above and adds a direct-manipulation renderer over the same canonical models. It does not create a parallel simulator-control stack. The browser now renders the dock tree recursively and supplies graphical 3D, plotting, data-grid, calibration, topology, scenario, workflow/debugging, track/lap, and semantic/problems views.

New structured/nested operations used by the graphical client are:

```text
ui semantic json <command-line>
ui desktop activate <tab-id>
ui desktop reorder <tab-id> <index>
ui scenario-timeline resize <event-id> <duration-s>
ui workflow-editor json <graph-id>
ui workflow-debugger json
ui calibration-correlation json
ui run-compare track-json [max-points]
```

Five additional schema workbench projections are registered without duplicating backends: `scope`, `engineering-data-grid`, `workflow-editor`, `track-lap-analysis`, and `semantic-cli`. Existing scenario, debugger, topology, 3D, calibration, streaming, assurance, campaign, and collaboration workbenches remain registered.

The browser docking desktop supports tab activation/reordering/movement, recursive splitting, splitter ratio adjustment, logical floating windows and workbench drag/drop. WebGL renders the existing digital-twin scene. Telemetry plotting consumes the out-of-core `lod_samples` path. The grid virtualizes streamed frames. Calibration editing invokes `CalibrationMapStudio` operations. Topology renders `LiveEeCosimulationTopologyCanvas`. Scenario drag/resize mutates `VisualScenarioEventTimelineComposer`. Workflow authoring/debugging uses `WorkflowGraphEditor` and `WorkflowExecutionDebugger`. Track/lap analysis projects `NWayRunComparisonWorkbench`. Semantic diagnostics consume `SemanticCliService` and `UiAccessPolicy`.

See `ENGINEERING_UI_PLATFORM.md` (V16 section) and User Manual Chapter 78 for the complete operator workflow and architecture.

## V19 shared help and Problems diagnostics

The browser Problems panel and terminal Semantic CLI now share the V19 diagnostic contract. Each semantic diagnostic can expose a stable code, severity, source byte offset, human explanation, likely cause, remediation, corrective example, canonical resolution, and access/capability state. This is a presentation extension of the existing `SemanticCliService`; no second browser validation engine exists.

Detailed CLI help is available with `help <command-or-subcommand>`, discovery with `help search <term>`, and diagnostic lookup with `help errors [CODE]`. Completion-detail text is generated from the same root metadata and nested command grammar, so the browser, terminal completion pane, contextual forms, and manual use one canonical vocabulary. Mission Control remains responsible for operational alarms and Regression Triage for test evidence; the Problems panel remains command/editor/workspace diagnostics.


## V17 research-grade engineering desktop workbenches

The V17 browser renderer extends the V16 direct-manipulation desktop with 28 schema-registered research-grade workbenches. The renderer is deliberately generic: workbench metadata and actions come from `WorkbenchSchema`, and all browser actions use the authenticated `/api/command` endpoint. This prevents a browser-only formal solver, plugin registry, migration engine, run database, safety engine, or scheduler from diverging from the interactive shell.

The workbenches are: `formal-verification`, `field-visualization`, `jacobian-inspector`, `distributed-trace`, `hpc-placement`, `safety-analysis`, `temporal-bisection`, `contract-monitor`, `state-machine`, `numerical-trust`, `run-lineage`, `realtime-deadline`, `cosim-sync`, `coverage-explorer`, `cyber-attack`, `engineering-notebook`, `report-composer`, `crdt-collaboration`, `plugin-manager`, `migration-center`, `dependency-heatmap`, `performance-investigator`, `divergence-investigator`, `failure-clustering`, `twin-measurement`, `alert-rules`, `product-line`, and `control-room`.

Backend ownership is explicit. `specification-discovery` owns formal verification; `advanced-safety-cli` owns advanced safety execution; `frontier-professional hardware-probe` owns hardware discovery; `frontier-professional jupyter` owns Jupyter integration; `plugin ...` owns extension loading; `config ...` owns schema migration; the existing campaign/federation runtimes own distributed execution. UI models either present those results or provide new bounded analysis/persistence where no prior model existed.

The two new durable UI data formats are `MZUX-NOTEBOOK|1` and `MZUX-CRDT|1`. Numerical/graph features include sparse greedy column coloring, trace critical-path extraction, nearest scientific-field probes and tolerance slices, temporal telemetry bisection, RSS uncertainty budgets, graph shortest paths, run DAG traversal, deterministic failure clustering, digital-twin section intersections, stateful live contracts, and duration-aware alert rules.

See User Manual Chapter 83 for exact commands and operator examples.

## V20.1.2 integrated terminal engineering surfaces

This release extends the existing engineering UI models with terminal-native operator surfaces. It does **not** introduce parallel telemetry, event, job, alert, experiment, causal, comparison, or navigation stores. Each view is a renderer/controller over the authoritative model already owned by `EngineeringUiSuite` or `ExperienceManager`.

### Backend/API to InteractiveShell command parity

Every new public renderer/backend operation has a canonical `InteractiveShell` route:

| Backend/API | Canonical InteractiveShell route | Existing authoritative state |
|---|---|---|
| `TelemetryWorkbench::sparkline()` | `ui sparkline <signal> [width] [begin-s end-s]` | `TelemetryWorkbench` samples/LOD store |
| `SynchronizedTimeCursor::time_travel_panel()` | `ui time-travel [status|panel|timeline|...]` | synchronized cursor + backend state capture/restore |
| synchronized events + flight recorder | `ui event-timeline [limit width]` | time cursor + `EngineeringFlightRecorder` |
| `CausalDifferenceExplorer` | `ui causal-inspector ...` | existing causal dependency graph + N-way run comparison |
| `ExperimentMatrix` cockpit projection | `ui experiment-cockpit [filter]` | `ExperimentMatrix` + canonical jobs |
| `globalui::JobManager` | `ui jobs ...` / `ui job-manager ...` | Mission Control's single `JobManager` |
| `EngineeringMissionControl::alerts()` | `ui notifications ...` | Mission Control alert store + Experience issues |
| lower-pane renderer/layout integration | `ui lowerpane ...` | existing scrollback plus analytical view projections |
| `ContextGraph`/`NavigationContext` | `ui navigator ...` | global context graph/navigation history |
| backend settable-parameter metadata | `ui parameter-inspector [name|list]` | `Backend::settable_parameters()` + live metrics |
| `ExperienceManager`/context/signal help | `ui doc-inspect <topic>` | canonical command help + context graph + signal metadata |
| `AutomotiveVisualization::motorsport_pit_wall()` | `ui pit-wall [series]` | live engineering metrics |
| `NWayRunComparisonWorkbench::track_map()` | `ui track-map [width height max-points]` | N-way comparison run channels |
| `AutomotiveVisualization::friction_circle()` | `ui friction-circle [width height]` | live vehicle-dynamics metrics |
| `RuntimeProfiler::dashboard()` | `ui performance-profiler [dashboard|status|...]` | existing runtime profiler history |
| `AutomotiveVisualization::uncertainty_compact()` | `ui uncertainty-view [width rows]` | uncertainty channels from active backend |
| Experience state history | `ui undo`, `ui redo`, `ui state undo`, `ui state redo` | existing `ExperienceManager` undo/redo history |

Aliases such as `ui telemetry-sparkline`, `ui timeline`, `ui notification-center`, `ui subsystem-navigator`, and `ui documentation-inspector` resolve to the same implementations. They are compatibility/discoverability aliases, not duplicate feature owners.

### High-resolution Unicode telemetry sparklines

`TelemetryWorkbench::sparkline()` uses the existing LOD query path and Unicode block levels `▁▂▃▄▅▆▇█`. Width is bounded to 4–512 columns. Empty bins carry the preceding value so irregularly sampled data remains readable without inventing interpolated extrema. Statistics are calculated from the selected time interval rather than from display bins.

```text
ui sparkline rpm
ui sparkline engine.coolant_c 64 120 180
ui telemetry-sparkline battery.soc 48 0 600
```

The output includes the signal name, trend, minimum, maximum, mean, and unit when available. Out-of-core histories remain bounded because the renderer consumes `lod_samples()` instead of materializing a second time-series database.

### Event timeline and time-travel control

`ui event-timeline` combines the synchronized cursor timeline with recent engineering-flight-recorder entries. Commands executed from the interactive shell are recorded as command events, and failed command results are recorded as error events; the detailed payload remains in the flight recorder.

```text
ui event-timeline 30 120
ui time-travel status
ui time-travel bookmark before-fault
ui time-travel checkpoint baseline-state
ui time-travel next-event
ui time-travel previous-event
ui time-travel restore baseline-state
```

A checkpoint is real only when `Backend::capture_ui_state()` returns restorable simulator state. Restore calls `Backend::restore_ui_state()`; the UI never fabricates a replay snapshot. Bookmarks and analytical cursor motion remain separate from state restoration.

### Causal inspector

`ui causal-inspector` is an operator-facing alias of the existing dependency-constrained `CausalDifferenceExplorer`:

```text
ui causal-inspector status
ui causal-inspector divergences candidate 1e-9 1e-6
ui causal-inspector explain candidate speed_kmh 1e-9 1e-6
ui causal-inspector add-edge torque_nm speed_kmh 3.0 0.9
```

The inspector reports declared dependencies and temporal divergence evidence. It does not claim causal proof beyond the configured dependency graph and observed run evidence.

### Experiment cockpit, jobs, and notifications

The experiment cockpit summarizes the existing `ExperimentMatrix` and the single Mission Control `JobManager`:

```text
ui experiment-cockpit
ui experiment-cockpit series:f1
ui jobs submit thermal-sweep "ui run-manager list"
ui jobs list
ui jobs inspect 1
ui jobs progress 1 50 midpoint
ui jobs state 1 running
ui jobs cancel 1
```

The notification center projects Mission Control alerts together with Experience issues:

```text
ui notifications unread
ui notifications all
ui notifications ack 3
ui notifications clear 3
```

Acknowledgement and clearing mutate the authoritative Mission Control alert store. There is no second notification database.

### Tabbed lower-pane architecture

The historical Command Activity pane remains the default view. Its scroll/search/bookmark semantics are unchanged. The same bounded lower-pane geometry can now present analytical views:

```text
ui lowerpane tabs
ui lowerpane view activity
ui lowerpane view events
ui lowerpane view timeline
ui lowerpane view jobs
ui lowerpane view notifications
ui lowerpane view experiments
ui lowerpane view profiler
ui lowerpane view navigator
ui lowerpane view causal
ui lowerpane next
ui lowerpane previous
```

The selected lower-pane view is persisted in UI preferences and in project UI layout metadata. `ui prefs reset` restores `activity`. Custom pane layouts can focus the same view names through `ui pane ...`; this changes presentation/focus only and does not create another model.

### Hierarchical subsystem navigator and parameter inspector

`EngineeringUiSuite::update_live_signals()` projects live signals into the existing `ContextGraph` under a stable `vehicle://live` hierarchy. Explicit telemetry subsystem metadata takes precedence and is canonicalized for common domains; otherwise the signal prefix is classified into Powertrain, Driveline, Vehicle Dynamics, Chassis/Tyres/Brakes, Electrification, Thermal, Electronics/Diagnostics, Solver/Numerics, Motorsport, Driver Controls, or Runtime/Other.

```text
ui navigator tree
ui navigator compact
ui navigator find battery
ui navigator inspect subsystem://electrification
ui navigator select signal://battery.soc
ui navigator breadcrumbs
ui navigator back
ui navigator forward
ui navigator pin signal://battery.soc
ui navigator pins
```

The parameter inspector uses the active backend's own settable-parameter list:

```text
ui parameter-inspector list
ui parameter-inspector engine.redline_rpm
set engine.redline_rpm 7200
```

A current value is shown only when the active telemetry backend exposes a corresponding metric. Otherwise the inspector explicitly says that the current value is not exposed; it does not invent one.

### Undo/redo and inline documentation

UI state undo/redo remains the existing `ExperienceManager` history:

```text
ui undo
ui redo
ui state undo
ui state redo
```

This is distinct from line-editor history and from deterministic simulator time travel. Time-travel state restoration uses checkpoints; text editing uses the editor's own undo stack.

Inline documentation combines canonical command help, context-object inspection, signal metadata, and contextual Experience help:

```text
ui doc-inspect set
ui doc-inspect rpm
ui doc-inspect signal://rpm
ui documentation-inspector current
```

### Motorsport pit wall, terminal track map, and friction circle

The pit wall consumes live engineering metrics and accepts a series label without introducing a series-specific duplicate renderer:

```text
ui pit-wall f1
ui pit-wall indycar
ui pit-wall nascar
```

It reports available lap/position/delta/speed/RPM/gear/driver-demand/fuel/energy and four-corner tyre channels; unavailable backend channels remain `n/a`.

The terminal track map renders coordinate channels from the existing N-way comparison workbench:

```text
ui run-compare load-csv baseline baseline.csv time_s
ui run-compare load-csv candidate candidate.csv time_s
ui run-compare baseline baseline
ui track-map 76 22 2400
```

Recognized coordinate pairs include `position_x_m`/`position_y_m`, `x_m`/`y_m`, `pos_x_m`/`pos_y_m`, longitude/latitude variants, and GPS longitude/latitude variants. `B` marks the baseline, other runs receive distinct glyphs, and `*` marks overlap.

The friction circle accepts direct `longitudinal_g`/`lateral_g` channels when exposed. Otherwise m/s² channels are converted using standard gravity; the implementation does not infer units from numerical magnitude.

```text
ui friction-circle
ui friction-circle 55 19
```

### Performance profiler and compact uncertainty view

The terminal performance dashboard is a projection of the existing runtime profiler:

```text
ui performance-profiler dashboard
ui performance-profiler sample
ui performance-profiler show
ui performance-profiler clear
```

It displays compact history for CPU/RSS/GPU where available and retains explicit unavailability for unsupported GPU/MPI data.

The uncertainty view recognizes canonical suffix conventions without synthesizing uncertainty:

```text
ui uncertainty-view
ui uncertainty-view 100 30
```

Recognized suffixes are `.sigma`, `.stddev`, `.uncertainty`, `.lower`, `.upper`, `.lower95`, and `.upper95`; a base value or `<base>.mean` supplies the center estimate. When no uncertainty channels are exposed, the UI says so explicitly.

### Qualification

The engineering UI unit suite now exercises 78 feature families, including the professional operator coordination layer. `tests/engineering_ui_platform_regression.py` requires the concrete renderer methods and shell routes, while `tests/unified_engineering_ui_cli_regression.py` executes the integrated terminal command surface against the real authenticated executable. PTY regressions continue to protect default Command Activity behavior, lower-pane visibility, resize anchoring, scroll anchoring, preferences, golden frames, and input handling.

## V20.1.2 terminal readability, native selection, and meter policy

The terminal frontend now separates **terminal selection ownership** from **application mouse interaction**. Application mouse reporting is not enabled when the TUI starts. This keeps normal terminal-emulator drag highlighting, copy, and paste available in the default operating mode, including over SSH.

```text
ui mouse status
ui mouse on
ui mouse off
ui mouse toggle
ui mouse regions
```

`ui mouse on` enables only xterm button-event mode (`1000`) and SGR extended coordinates (`1006`). It intentionally does **not** enable button-motion (`1002`) or all-motion (`1003`) reporting. Continuous motion reporting interferes with terminal-native selection and can create large raw-input bursts. `ui mouse off` defensively disables `1000`, `1002`, `1003`, and `1006` so a terminal cannot remain captured because of a stale mode from an earlier session.

Bracketed paste (`2004`) remains enabled independently of mouse capture. Pasted input continues through the protected-paste path and is not auto-executed simply because it contains line breaks. Complete SGR mouse escape sequences received while application capture is off are consumed as no-ops by the input state machine; they cannot leak into the command buffer or leave InteractiveShell waiting for a later Escape key.

### High-resolution bounded meters

Bounded percentage/range bars now use the shared header-only utility:

```cpp
aesim::core::terminal_visuals::high_resolution_bar(...)
```

The renderer uses full and fractional block elements (`█`, `▉`, `▊`, `▋`, `▌`, `▍`, `▎`, `▏`) with `░` for remaining range, providing eighth-cell resolution. It clamps non-finite/out-of-range input safely and preserves fixed terminal-column width. The same utility is used by dashboard gauges, simulation scope/status views, ODD coverage, and cylinder-balance reporting instead of maintaining independent `#`-fill implementations.

Telemetry sparklines are **not** routed through this utility. Sparklines remain time-series views (`▁▂▃▄▅▆▇█`) because they encode trend shape rather than bounded completion or utilization.

### Readability organization

The status row preserves its established automation-visible prefix (`CMD | INS | LOOP ... | DASH ...`) and introduces stronger Unicode grouping separators before pane/filter/input/focus state where width permits. Scenario-event timelines use distinct start (`◆`), active-duration (`━`), and idle (`·`) glyphs with an explicit legend. These changes improve scanning without changing command ownership or removing existing panels.

For operator-focused examples, see [`REAL_WORLD_TUI_USAGE_GUIDE.md`](REAL_WORLD_TUI_USAGE_GUIDE.md).


## Professional operator TUI coordination layer (V20.1.2)

The terminal operator extensions deliberately add coordination/read-model services around existing authorities rather than duplicate simulation or engineering state.

| Capability | Authoritative inputs / execution path |
|---|---|
| Semantic instrument limits, trend, quality, provenance | `TelemetryWorkbench` history and signal metadata |
| Dashboard freeze/delta | `DashboardReferenceOverlay` over the current telemetry snapshot; display-only freeze |
| Baseline overlay | `NWayRunComparisonWorkbench` interpolation into `DashboardReferenceOverlay` |
| Linked cursor bus | existing `SynchronizedTimeCursor` and `InstrumentGradePlotMeasurementToolkit` A/B cursors |
| Transient lens | existing telemetry history at linked/SOE event times |
| First-out/SOE | existing `EngineeringMissionControl` alert records plus explicit operator markers |
| Output minimap | existing InteractiveShell logical scrollback/search/bookmark/transaction metadata |
| Multi-selection | central stable-ID selection registry; mutations delegated to existing collection authorities |
| Command staging | existing Semantic CLI + preview, then normal InteractiveShell/transaction dispatch after fresh commit-time validation |
| Command macros | successfully completed canonical/UI commands; replay through normal InteractiveShell dispatch |
| Performance HUD | existing `UiPerformanceMonitor` |
| Visual declutter | rendered dashboard rows only; no telemetry or alert suppression |

`EngineeringUiSuite` owns the new coordination objects (`dashboard_reference`, `transient_lens`, `linked_cursors`, `sequence_of_events`, `selections`, `command_staging`, and `macros`) beside the pre-existing services they coordinate. The linked cursor bus is attached to the pre-existing global/plot cursor objects rather than storing independent cursor truth. Baseline-run commands interpolate channels from the pre-existing run-comparison workbench. Staged and macro commands enter the same queued command path as typed input, retaining authorization, semantic validation, transaction capture, logging, undo/redo, and backend behavior.

The focused engineering UI regression covers 78 feature families and includes the coordination contracts above. The production PTY regression additionally proves that staged commands and recorded macros are consumed by the normal shell loop rather than a feature-specific executor.

## V19 Integrated Engineering Analysis Desktop

V19 extends the V18 browser desktop with integrated analysis and qualification surfaces while preserving the same authenticated transport and backend ownership model. The browser still uses only `/api/state`, `/api/schema`, `/api/stream`, and `/api/command`. It does not maintain independent requirements, runs, SOE events, state machines, diagnostics, calibrations, artifacts, permissions, or qualification records.

### Shared engineering context and linked cursors

A browser-wide context coordinates the selected engineering object across compatible workbenches. Requirements, verifications, signals, runs, event records, states, diagnostic causal nodes, calibration cells, artifacts, and runtime resources publish a common `kind/id/source/metadata` selection. Compatible panes receive that context through the browser presentation layer. This is presentation state only; authoritative object data remains in the existing backend services.

Primary, Cursor A, and Cursor B are synchronized through `ui linked-cursor set ...` and `ui linked-cursor status`. Follow-live uses the current stream time as a browser presentation convenience and periodically resynchronizes the existing primary cursor. It does not create an independent simulator clock.

### Requirements & Evidence Matrix

The browser consumes `ui verification-matrix json`, `coverage`, `trace`, `stale`, and the existing evidence attachment command. The matrix provides requirement verdict, criticality, standard/clause, owner, linked verification records, live requirement margin, evidence metadata, and stale-evidence visibility. Evidence attachment remains a canonical mutation subject to the normal semantic/access policy.

### N-Way Run Comparison and Regression Divergence

`ui run-compare json [channel] [axis] [max-points]` is a bounded graphical projection of the existing `NWayRunComparisonWorkbench`. It supplies run metadata, channel lists, decimated points, baseline identity, and comparison statistics without adding another run store. The N-Way Run Comparison Studio overlays run traces and synchronizes clicks to the shared primary cursor. The Regression Divergence Investigator continues to use the existing causal-difference authority and sends the earliest meaningful divergence into the same linked cursor/context.

### Engineering Event Timeline and state-machine debugger

The Event Timeline visualizes the existing SOE/first-out records and links event selection to the existing cursor, transient lens, and alarm-flood analysis. The State Machine debugger consumes the existing state-machine JSON model, renders states/transitions/guards graphically, and submits transition events only through the canonical state-machine command path.

### Diagnostic causal graph

Diagnostic Center now renders the existing automotive diagnostic `CausalGraph` directly through `causal inline-json [workflow-id]`. The browser adds no diagnostic graph database. Node selection exposes evidence class, confidence, source, current value, and explanation while the established Professional Diagnostic Center remains available alongside it.

### Resource / Solver Observability

The browser combines `ui profiler json`, `ui solver-console json`, and the existing performance investigator. The new JSON commands expose bounded existing history/samples rather than introducing new profiler or solver telemetry stores. CPU, memory, I/O, GPU, timestep, local error, nonlinear/linear iteration, residual, and conservation information are presented together.

### Calibration Change Review

The existing Calibration Correlation editor now supports an explicit review step. Selected cells show before/proposed values and deltas. The proposed canonical `set` or `edit` command is passed through `ui semantic json` before the Apply action is enabled. Existing `ui calibration-correlation stage` and `approve` commands provide the review lifecycle. No parallel calibration map or approval database is created.

### Artifact/evidence, reproducibility, and qualification

The Artifact & Evidence Browser uses the existing evidence index and SHA-256 metadata. The Reproducibility Manifest aggregates existing project status, run metadata/lineage, data catalog, and evidence information into a client-side audit view/export. The Qualification Dashboard aggregates existing requirements coverage, stale evidence, review center, runbook, release planner, and regression-triage outputs; it does not calculate a second qualification truth model.

### Role-aware affordances

The command line, quick controls, and consequential V19 controls preflight through `ui semantic json <command>`. Controls are disabled when the canonical semantic/access result says the operation is invalid or unavailable. This is an ergonomic preflight only: `/api/command` and the backend authorization system remain authoritative and re-check the operation when it executes.

### Structured canonical JSON results

Command panels automatically detect canonical JSON command results and render nested objects, arrays, and flat-object tables with Structured/Raw/Download views. Raw command text remains available. This renderer is presentation-only and does not change command schemas or introduce browser-specific result formats.

### V19 keyboard shortcuts

- `Ctrl/Cmd+Shift+R`: Requirements & Evidence Matrix.
- `Ctrl/Cmd+Shift+C`: N-Way Run Comparison Studio.
- `Ctrl/Cmd+Shift+Q`: Engineering Qualification Dashboard.
- Existing V18 search, command, palette, Live Operations, and Command Staging shortcuts remain unchanged.

## TUI interaction intelligence V25

The V25 layer adds reversible pane-layout history, a structured TreeGrid, semantic output folding, telemetry trust overlays, a debugger over the existing macro library, shift handoff records, collaboration control-token/follow semantics, dynamic command-precondition explanations, deterministic session comparison, and CPU/NUMA/cache topology visualization. These facilities are owned by `EngineeringUiSuite` and deliberately compose existing authorities rather than creating new simulator, telemetry, command, session-recorder, or profiler backends.

Canonical entry points are `ui pane history|checkpoint|diff|undo|redo`, `ui tree-grid`, `ui output-nav`, `ui trust-overlay`, `ui macro debug|step|continue|trace`, `ui handoff`, `ui collaboration control-*|follow|audit`, `ui availability`, `ui replay-compare`, and `ui hardware-topology`.

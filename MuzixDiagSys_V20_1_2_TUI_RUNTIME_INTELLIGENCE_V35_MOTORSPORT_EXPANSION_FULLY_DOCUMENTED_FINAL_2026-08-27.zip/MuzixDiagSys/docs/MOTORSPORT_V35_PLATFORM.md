# MuzixDiagSys V35 Motorsport Expansion Platform

**Release:** 2026-08-27  
**Library:** `aesim_motorsport_v35`  
**Public header:** `include/aesim/advanced/motorsport_v35_platform.hpp`  
**Qualification executable:** `muzixdiagsys_motorsport_v35`

V35 adds ten cross-series motorsport engineering systems while retaining all established Formula One, IndyCar, NASCAR, NHRA, generalized competition, and frontier vehicle-ecosystem APIs. It is intentionally implemented as a focused library so endurance/rally/Formula-E/GT and cross-series analysis can be built and tested without rebuilding unrelated multiphysics domains.

The platform is an **engineering simulation model**, not an official rules engine or homologation authority. Series-specific limits in a study should be configured from the applicable rule set and event bulletin. The built-in defaults are deterministic engineering defaults used to exercise the algorithms.

## 1. Architecture and non-duplication contract

`aesim_motorsport_v35` depends only on `aesim_core`. `aesim_advanced` links it after the established V34 dependency chain and `aesim/advanced/platform.hpp` exposes the API.

The pre-existing `WecImsaEndurancePlatform` remains uniquely defined in the frontier vehicle-ecosystem platform. V35 extends that facade through `run_detailed_stint`; the facade applies its existing category BoP state and delegates to `EnduranceRaceEngineeringPlatform`. No second compatibility facade is maintained.

V35 likewise does not replace existing F1, IndyCar, NASCAR, NHRA, generic race-strategy, telemetry, tyre, or TUI workbenches. The new classes provide missing cross-series/high-fidelity behavior and can feed those existing authorities.

## 2. Build, discovery, and qualification

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON

cmake --build build/full --parallel 2 --target \
  aesim_motorsport_v35 \
  motorsport_v35_platform_tests \
  muzixdiagsys_motorsport_v35

./build/full/muzixdiagsys_motorsport_v35 capabilities
./build/full/muzixdiagsys_motorsport_v35 self-test

ctest --test-dir build/full --output-on-failure \
  -R '^motorsport_v35_(platform_unit_tests|source_regression|cli_self_test)$'
```

A C++ application can consume the focused library directly:

```cpp
#include "aesim/advanced/motorsport_v35_platform.hpp"
using namespace aesim::advanced::motorsport;
```

or consume the same API through the umbrella header and `aesim_advanced`.

## 3. Full WEC / IMSA endurance-race engineering

### 3.1 Core objects

- `EnduranceVehicleSpec`: category, mass, power, fuel capacity, per-stint energy, hybrid deployment, refuel rate, base lap time, brake-life rate, and drivetrain hazard.
- `EnduranceDriver`: FIA-style rating category plus pace, wet, traffic, fatigue, continuous/event driving time, and accumulated rest.
- `EnduranceRaceState`: time, laps, fuel, stint energy, tyre/brake life, damage, reliability, penalties, garage time, active driver, tyre compound, and retirement.
- `EnduranceStintConditions`: target duration, lap distance, rain, ambient/track temperature, traffic, night fraction, visibility, and neutralization mode.

Supported endurance categories are `Lmh`, `Lmdh`, `Gtp`, `Lmp2`, `Lmgt3`, and `Gt3`. Neutralization modes are green, local yellow, full-course yellow, Safety Car, Slow Zone, and red flag.

### 3.2 Stint model

`simulate_stint()` derives a physically constrained average-lap estimate from driver skill/rating, fatigue, night/visibility, rain, tyre condition, damage, brake condition, traffic, and neutralization. Completed laps are then constrained by time, fuel, and remaining virtual stint energy. The report advances tyre/brake life, damage/contact exposure, fatigue, reliability, fuel, energy, elapsed time, and rule findings.

Driver limits are configured with:

```cpp
EnduranceRaceEngineeringPlatform endurance;
endurance.configure_driver_limits(
    4.0 * 3600.0,   // maximum continuous driving
    14.0 * 3600.0,  // maximum event driving
    3600.0,         // required rest before returning
    false);          // service concurrency
```

### 3.3 Pit operations

`execute_pit_stop()` supports refueling, tyre changes, driver changes, damage repair, and brake service. Fuel is bounded by tank capacity, driver changes are checked against available drivers/rest rules, and service time respects concurrent-versus-sequential policy.

### 3.4 Classification

`classify()` provides deterministic ordering of endurance race states by race completion while retaining retirement/penalty state. Use series-specific post-processing when an event requires a specialized official classification rule.

### 3.5 Minimal example

```cpp
EnduranceVehicleSpec car;
car.id = "hypercar-7";
car.category = EnduranceClass::Lmh;
car.fuel_capacity_kg = 90.0;

EnduranceDriver driver;
driver.id = "driver-a";
driver.rating = DriverRating::Gold;

EnduranceRaceState state;
state.car_id = car.id;
state.fuel_kg = 80.0;

EnduranceStintConditions conditions;
conditions.duration_s = 45.0 * 60.0;
conditions.traffic_density = 0.65;
conditions.night_fraction = 0.40;

EnduranceRaceEngineeringPlatform platform;
auto report = platform.simulate_stint(car, {driver}, state, conditions);
```

## 4. Advanced Balance-of-Performance engineering laboratory

`BalanceOfPerformanceLaboratory` is a regulator/engineering analysis tool, not an automatic homologation decision maker.

### 4.1 Observation normalization

Each `BopObservation` carries observed/reference lap time plus explicit driver, tyre, weather, traffic, track-type, current-parameter, and sensitivity information. The laboratory removes those declared offsets before inferring manufacturer latent performance.

### 4.2 Robust latent-performance inference

`infer_latent_performance()` performs iteratively reweighted robust estimation by manufacturer, reports the estimated latent time offset and standard error, calculates the maximum standardized anomaly, and can flag statistically suspicious slow outliers.

### 4.3 Bounded parity optimization

`optimize()` evaluates current manufacturer performance spread and applies bounded mass/power changes toward the inferred mean. `predict_lap_delta()` also supports high-speed power, stint energy, aero, and refueling sensitivity for counterfactual studies. The report returns before/after parameter sets, predicted deltas, initial/final spread, and whether the requested target spread is met.

Recommended workflow:

1. normalize multi-track observations;
2. inspect standard errors and anomaly scores;
3. reject poor-quality or non-comparable observations explicitly;
4. run bounded counterfactual optimization;
5. validate the proposed adjustment on tracks not used to estimate it;
6. document uncertainty rather than interpreting the optimizer as an official BoP ruling.

## 5. World Rally / stage-rally platform

`WorldRallyStagePlatform` models a rally as ordered timed road segments instead of a circuit lap.

### 5.1 Route and surface

`RallyStageSegment` supports asphalt, gravel, mud, snow, ice, and mixed surfaces with curvature, gradient, roughness, water, snow depth, and road-cleaning sensitivity. `RallyStageConditions` adds road position, rain, visibility, ambient temperature, and altitude.

Road order affects gravel cleaning and mud/rut development deterministically. Tyre/surface compatibility, curvature, roughness, water/snow, altitude, driver state, and visibility all influence segment velocity/time.

### 5.2 Pace notes and co-driver performance

`PaceNote` records distance, feature, severity, and confidence. Supported features include corner, crest, compression, junction, caution, jump, water, narrow, opens, and tightens. Note confidence combines with co-driver skill and crew trust; poor information adds stage-time loss and risk instead of being represented as a generic driver penalty.

### 5.3 Puncture, damage, fatigue, and service

Puncture probability is derived from deterministic hazard inputs and a caller-supplied seed, enabling exact replay. Damage, tyre life, puncture count, fatigue, penalties, and retirement remain in the crew state.

`service()` spends a finite service window on engine, suspension, body, and tyre work and reports work that could not be completed before the window closed.

## 6. Formula E full-fidelity competition

`FormulaEFullFidelityPlatform` couples lap pace with energy and electrothermal state.

### 6.1 Energy and brake blending

The lap model accounts for requested pace, lift-and-coast, front/rear regeneration, maximum regeneration power, regeneration efficiency, friction-brake blending, tyre condition, weather, traffic, and neutralization. The result exposes consumed and regenerated energy, battery/brake temperature, usable energy, and rule/feasibility state.

### 6.2 Battery thermal derating

Battery temperature is advanced from traction/regen heat input and cooling. Above the thermal threshold the available drive power is progressively derated; the model therefore couples aggressive energy deployment to later performance rather than treating the energy budget as a scalar countdown.

### 6.3 Attack Mode optimization

`optimize_attack_mode()` evaluates legal activation-lap combinations. Neutralized activation opportunities can be rejected, required activation count/duration are enforced by the configured event rules, and infeasible energy trajectories are discarded.

### 6.4 Duel qualifying and neutralization energy

`run_duel_qualifying()` seeds entries from group times and resolves elimination duels. `neutralization_energy_adjustment()` computes the configured reduction associated with neutralized running so race-energy accounting can be updated consistently.

## 7. Motorsport driver behavioral digital twin

`MotorsportDriverDigitalTwin` separates persistent driver traits from latent event state.

Persistent traits include aggressiveness, braking consistency, tyre-management skill, wet skill, traffic tolerance, defensive/overtaking propensity, pressure resilience, and learning rate. `observe()` assimilates telemetry observations into pace bias, braking variance, confidence, fatigue, frustration, risk appetite, tyre confidence, and brake confidence.

`predict()` reports expected pace offset, error probability, attack/defend propensity, tyre-saving behavior, and braking variability for the current race progress, traffic, rain, and championship pressure.

Use the twin as a probabilistic behavioral input to strategy/racecraft studies; do not interpret a single inferred latent state as a clinical or psychological diagnosis of a real driver.

## 8. Unified spatial track-state field

`SpatialTrackStateField` is a longitudinal/lateral grid whose cells contain:

- rubber and marbles;
- water depth;
- surface temperature;
- oil, dust, gravel, and mud;
- snow and ice;
- roughness;
- microtexture and macrotexture; and
- derived local grip.

`advance_weather()` evolves precipitation, drainage, evaporation, freeze/melt behavior, solar heating/convection, rubber wash-off, and dust removal. `apply_vehicle_pass()` displaces water, deposits rubber/heat, forms marbles, and can carry debris back onto the racing surface after an excursion. `deposit_debris()` adds local contamination directly.

The grid is intended to be a shared environmental state for racecraft, tyre, strategy, wet-weather, and visualization systems rather than another independent track model.

## 9. Racecraft interaction physics

`RacecraftInteractionPhysics::assess()` evaluates an ego car and another car inside a `RacecraftCornerEnvelope`.

The result includes longitudinal overlap, lateral clearance, closing time, safe corner speed, braking demand/feasibility, aero-wake loss, collision probability, track-envelope legality, expected time gain, and a recommended action. Actions include inside/outside attack, inside/outside defense, crossover, yield, and hold line.

When the intended move is physically infeasible or produces excessive collision risk, the engine recommends a lower-risk action instead of treating racecraft as an unconstrained strategy decision.

## 10. Hierarchical race strategy AI

`HierarchicalRaceStrategyAI::choose()` scores candidate strategies at five levels:

1. championship context;
2. race outcome;
3. stint execution;
4. lap management; and
5. corner/racecraft behavior.

Utility combines expected points, race time, performance variance, reliability, tyre/energy risk, traffic exposure, weather uncertainty, Safety-Car optionality, and explicit risk tolerance. The result includes the selected strategy and a complete ranking rather than returning an opaque choice.

`update_opponent_pit_probability()` provides a Bayesian/log-odds opponent-intent update from lap-time delta, tyre age, energy saving, and whether the pit window is open.

## 11. Lap-time loss attribution and driver coaching

`LapTimeAttributionCoach` synchronizes a driver lap to a reference in the distance domain. Positive interval loss is partitioned among:

- braking;
- entry;
- minimum speed;
- traction;
- straight-line performance;
- traffic;
- tyres;
- energy;
- damage; and
- weather.

Attribution weights are normalized interval-by-interval so the reported causes reconcile to measured positive time loss. Corner-active regions are discovered from steering/braking/lateral-acceleration behavior. Reports include per-corner components, lap-total components, ranked improvement opportunities, and actionable coaching text.

Use a physically comparable reference. Comparing different weather, fuel, tyre, damage, traffic, or energy states without supplying those signals will incorrectly assign some contextual loss to driver/vehicle categories.

## 12. GT3 / GT4 customer-racing ecosystem

`GtCustomerRacingPlatform` supports `Gt3`, `Gt4`, and one-make cup categories with Pro/Gold/Silver/Bronze driver classes.

### 12.1 Stint model

`run_stint()` combines mass/power BoP, power-to-mass behavior, driver pace, rain, tyre life, damage, fuel-limited stint length, brake wear, engine mileage, gearbox mileage, reliability, elapsed time, and team operating cost.

### 12.2 Pit and component lifecycle

Pit service supports refueling, tyres, driver change, front splitter, rear wing, gearbox, and engine replacement. The platform enforces fuel capacity, minimum stop time, concurrency policy, mandatory driver change where configured, available inventory, parts cost, and team cash. Replaced components receive renewed life/mileage state instead of simply removing a generic damage scalar.

This layer is deliberately customer-racing oriented: team cash and spares availability can make a mechanically desirable service action operationally infeasible.

## 13. Cross-system workflow example

A useful endurance/GT engineering workflow is:

1. initialize `SpatialTrackStateField` and advance forecast/rain conditions;
2. infer or set current BoP parameters;
3. initialize driver twins from historical observations;
4. run endurance/GT stint candidates under current traffic and track state;
5. evaluate close-car interactions with `RacecraftInteractionPhysics`;
6. score pit/tyre/driver-change alternatives with `HierarchicalRaceStrategyAI`;
7. update opponent pit probability as observed lap degradation evolves;
8. assimilate the completed stint into the driver twin;
9. run `LapTimeAttributionCoach` against a comparable reference; and
10. record the accepted strategy, assumptions, configuration, and result through the existing experiment/reproducibility services.

For rally, substitute stage segments/pace notes/service windows for circuit stints. For Formula E, use energy/Attack Mode feasibility as hard strategy constraints.

## 14. Numerical and modeling boundaries

- Values representing fractions should normally be within `[0,1]`; the implementation clamps or validates where required by the API contract.
- V35 is deterministic for equal inputs and deterministic seeds.
- The models are reduced-order engineering simulations. They are not a replacement for CFD, multibody, tyre FE, electrochemical cell, or official timing/scoring systems where those higher-fidelity authorities are required.
- BoP results are sensitivity-driven engineering counterfactuals, not official regulatory decisions.
- Rules such as driving-time limits, required service concurrency, Attack Mode requirements, minimum stop times, and event energy limits should be configured for the event being studied.
- Driver-behavior outputs are engineering latent-state estimates, not medical or psychological assessments.

## 15. Regression and evidence contract

The V35 qualification surface consists of:

- `motorsport_v35_platform_unit_tests` - compiled behavioral coverage across all ten capability families;
- `motorsport_v35_source_regression` - public API, algorithm, CMake, documentation, non-duplication, legacy WEC facade delegation, and incomplete-work checks; and
- `motorsport_v35_cli_self_test` - standalone ten-family runtime qualification.

Recommended release command:

```bash
ctest --test-dir build/full --output-on-failure \
  -R 'motorsport_v35_|formula_one_|indycar_|nascar_|nhra_'
```

The broader project release gate should also include duplicate-implementation detection, warning policy, documentation regressions, and deterministic source-package validation.

## 16. Related documentation

- `MUZIXDIAGSYS_USER_MANUAL.md`, Chapter 95
- `MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md`, Section 34
- `MOTORSPORT_CLI_COMMANDS.md`
- `GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md`
- `NATIVE_QUALIFICATION_PLATFORM.md`
- existing Formula One, IndyCar, NASCAR, and NHRA platform references in this directory

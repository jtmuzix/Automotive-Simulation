# MuzixDiagSys Native Qualification Platform (V34)

The Native Qualification Platform is an additive software-assurance layer built on the V33 generalized engineering-operations foundation. It does not replace V33 coverage, build-cost, test-management, fuzzing, compatibility, provenance, or architecture services. It adds native C++ qualification workflows that operate across compilers, instrumentation modes, binary artifacts, stochastic streams, host resources, processes, and static-analysis evidence.

## 1. Sanitizer Qualification Matrix & Failure Workbench

`SanitizerQualificationWorkbench` builds a toolchain-aware qualification matrix for AddressSanitizer, UndefinedBehaviorSanitizer, ThreadSanitizer, LeakSanitizer, MemorySanitizer, Clang integer sanitizers, `_GLIBCXX_DEBUG`, and `_GLIBCXX_ASSERTIONS`. The compatibility engine rejects invalid combinations (for example TSan with ASan/LSan/MSan, or MSan on GCC). It generates compiler flags, parses sanitizer diagnostics, normalizes stack frames and unstable addresses, fingerprints findings with SHA-256, persists baselines, supports explicit suppressions, and gates only newly introduced findings at or above the configured severity.

## 2. Combinatorial Build & Configuration Interaction Explorer

`CombinatorialConfigurationExplorer` treats CMake/runtime options as finite-domain variables. Constraints have antecedents plus required and forbidden assignments; valid configurations are enumerated by deterministic backtracking. The covering-array generator constructs 2-way, 3-way, or configurable N-way interaction sets and greedily chooses valid configurations that maximize uncovered weighted interactions. High-risk interactions can be assigned additional weight. Reports include valid-space size, selected matrix size, unweighted and weighted interaction coverage, and concrete uncovered interactions.

## 3. Build Reproducibility Forensics Workbench

`BuildReproducibilityForensicsWorkbench` compares complete SHA-256 identities and decomposes ELF files by section name, size, and section digest. Non-ELF artifacts fall back to whole-file analysis. Unix static archives are parsed directly, including GNU/BSD extended names, so archive member order and size can be compared without external tooling. Printable absolute paths are extracted to identify build-directory leakage. Metadata, `.debug*`, `.comment`, `.note.gnu.build-id`, archive ordering, timestamps, and embedded paths are classified into probable causes with deterministic remediation guidance such as prefix maps, deterministic `ar`, stable linker inputs, and `SOURCE_DATE_EPOCH`.

## 4. Binary Size / Link-Map / Symbol-Bloat Regression Analyzer

`BinarySizeRegressionAnalyzer` combines physical file size, native section sizes, GNU/LLVM `nm -S` symbol-size output, and GNU-style linker-map object contributions. It attributes growth to sections and symbols, separately accounts for template-like symbols, RTTI, vtables, and static initializers, and compares a candidate against explicit total, section, and per-symbol growth budgets. The result ranks the largest symbol regressions and emits exact budget violations.

## 5. Stochastic Stream Registry & Seed-Lineage Ledger

`StochasticStreamRegistry` replaces ad-hoc shared RNG coupling with stable named streams. Seeds are derived hierarchically from the root seed, parent stream, stream name, and versioned `SplitMix64V1` algorithm using SHA-256. Every stream records parentage, derived seed, consumption count, algorithm, and state digest. The registry provides deterministic integer, uniform, and normal draws, detects seed collisions and broken parentage, audits unexpected consumers between snapshots, persists the complete ledger without IEEE-754 loss of 64-bit state, validates the ledger on load, and resumes the exact deterministic stream position.

## 6. Host Resource Lifetime & Ownership Auditor

`HostResourceLifetimeAuditor` assigns every instrumented resource a unique token, resource kind, native ID, owner, creation site, metadata, and acquisition sequence. Snapshots preserve the complete tracked ownership graph and, on Linux, also sample live `/proc/self/fd`, socket symlinks, `/proc/self/task`, and `/proc/self/maps`. Snapshot diffs identify newly live owned resources, released resources, and host-level FD/socket/thread/map deltas. Supported resource classes include FDs, sockets, pipes, threads, children, mappings, shared memory, locks, temporary paths, GPU objects, plugin/dynamic-library handles, and IPC objects.

## 7. Process Lifecycle / Signal-Chaos Qualification Laboratory

`ProcessLifecycleChaosLab` launches a real isolated child process group and deliberately applies SIGINT, SIGTERM, SIGHUP, SIGQUIT, or SIGKILL on POSIX systems. The parent synchronizes with the child after `setsid()`, sends the signal to the whole group, waits under a graceful deadline, escalates to SIGKILL when required, reaps the child, reports the exact exit/signal state, and verifies the process group no longer exists. Windows uses a new process group with console-break/termination semantics. Reports explicitly distinguish launch, delivery, timeout, reaping, orphan/group cleanup, and pass/fail.

## 8. Static-Analysis Orchestration & Technical-Debt Gate

`StaticAnalysisOrchestrator` normalizes clang-tidy, GCC analyzer/compiler, cppcheck, Clang analyzer, CodeQL/SARIF, and generic compiler findings. It parses conventional compiler diagnostics and SARIF 2.1 data, assigns stable fingerprints, resolves longest-prefix source ownership, persists a baseline, applies fingerprint/rule suppressions, and gates only newly introduced findings according to severity. The workbench generates deterministic command plans for clang-tidy, cppcheck, GCC `-fanalyzer`, and Clang Static Analyzer and exports normalized findings back to SARIF for CI ingestion.

## 9. Spectrum-Based Regression Fault Localizer

`SpectrumRegressionFaultLocalizer` combines per-test pass/fail outcomes with covered source elements. It implements Ochiai, Tarantula, DStar, and Jaccard suspiciousness. The base spectrum score is augmented—not replaced—by explicit changed-code state, recent-change weight, historical defect density, and call-graph proximity. The ranked report includes failing and passing cover counts, the raw spectrum score, and the combined engineering-prior score for every candidate element.

## 10. Cross-Compiler / Cross-Optimization Differential Qualification

`CrossCompilerOptimizationDifferentialQualification` provides a default GCC/Clang O0/O2/O3 matrix plus an explicit fast-math policy profile. Callers execute each profile through a supplied runner and return a state hash, numerical metrics, event sequence, exception type, and exit code. The analyzer checks state/event/exception/exit equivalence and evaluates each numerical metric against absolute, relative, and IEEE-754 ULP tolerances. ULP distance is computed directly from ordered double bit patterns, including adjacent-representable-value qualification.

## Qualification CLI

When tools are enabled, `muzixdiagsys_native_qualification` exposes:

```text
muzixdiagsys_native_qualification capabilities [OUTPUT.json]
muzixdiagsys_native_qualification self-test DIRECTORY [OUTPUT.json]
```

The self-test exercises all ten capability families with real parsing, persistence, deterministic RNG continuation, host ownership snapshots, an actual child-process termination/reap cycle, SARIF round-trip, spectrum ranking, and ULP-aware differential analysis. A non-zero exit status is returned if any capability check fails.

## Architectural Integration

The implementation lives in the isolated `aesim_native_qualification` static library. It PUBLIC-depends on the V33 generalized engineering-operations library and core/professional services, and `aesim_advanced` adds it after its established legacy dependency chain so existing motorsport/fundamental-physics dependency-order guards remain intact. The umbrella `aesim/advanced/platform.hpp` exposes the public V34 header.

The corresponding source regression verifies all ten public capability classes, algorithm/evidence tokens, CMake/CLI/test/documentation integration, and rejects incomplete-work markers or versioned duplicate surfaces.


## Related current platforms

V34 consumes V33 generalized engineering-operations services rather than replacing them. V35 is an independent focused motorsport layer linked after V34 in `aesim_advanced`. See `GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md`, `MOTORSPORT_V35_PLATFORM.md`, and User Manual Chapters 93-95.

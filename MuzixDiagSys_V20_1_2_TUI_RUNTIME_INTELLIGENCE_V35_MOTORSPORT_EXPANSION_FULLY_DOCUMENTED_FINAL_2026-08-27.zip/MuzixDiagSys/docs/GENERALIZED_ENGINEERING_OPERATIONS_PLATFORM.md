# MuzixDiagSys Generalized Engineering Operations Platform (V33)

## Purpose

The Generalized Engineering Operations Platform adds software-engineering qualification capabilities that apply across MuzixDiagSys rather than duplicating vehicle, motorsport, simulation, or existing TUI diagnostic features. The implementation is exposed through `aesim::advanced::genops`, is linked into `aesim_advanced`, and is also available through the isolated `aesim_generalized_engineering_operations` library so qualification workflows can build without compiling unrelated advanced simulation domains.

The platform is fully implemented in native C++ and provides deterministic unit tests plus a standalone qualification executable, `muzixdiagsys_generalized_ops`.

## 1. Systematic Concurrency Interleaving Explorer

`SystematicInterleavingExplorer` explores bounded alternate schedules rather than merely inspecting a trace that has already occurred. It models reads, writes, locks, unlocks, assertions, and scheduler-visible yields. The engine maintains per-thread and per-lock vector clocks, derives happens-before relationships, detects conflicting unordered memory accesses, reports deadlock and assertion failures, enforces step/preemption/schedule bounds, and applies dynamic partial-order reduction to independent enabled operations.

Every first failing schedule receives a SHA-256 identity, and its first observable failure prefix receives a separate SHA-256 identity. Data races, deadlocks, assertion failures, and invalid unlocks are treated as concurrency failures. The engine retains the complete first failing witness plus the shortest prefix of that witness at which the failure became observable. `replay()` deterministically re-executes a recorded schedule and rejects invalid thread/action transitions.

## 2. Hermetic External-I/O Record / Replay Sandbox

`HermeticIoSandbox` records nondeterministic process/environment interactions into an ordered, integrity-protected tape and later replays them without touching the live external dependency. The canonical operations cover environment variables, file reads, wall-clock reads, subprocess execution, DNS lookup, TCP request/response exchanges, temporary-path generation, and arbitrary custom/device operations through `invoke()`.

Replay is strict: operation kind, request key, request payload, sequence order, status, and response must match the tape. Each record carries both a response SHA-256 and a whole-record SHA-256 covering the request, status, and response, so tampering with either side of an interaction is detected. Tape persistence uses the versioned `muzixdiagsys.hermetic-io-tape.v1` JSON schema. Truncated, malformed, reordered, or integrity-damaged records are rejected.

## 3. Persistence Crash-Consistency and Storage-Fault Laboratory

`CrashConsistencyLab` qualifies atomic state replacement using real same-directory transaction files. The implementation writes and synchronizes a temporary image, writes a transaction journal, performs atomic rename, synchronizes the parent directory on POSIX systems, and cleans/reconciles transaction debris during recovery.

The fault matrix covers short writes, no-space conditions, I/O errors, permission failures, stale transaction debris, rename failure, synchronization failure, and simulated process loss after temp write, journal creation, and rename. After each injected failure and recovery, the target must be byte-for-byte either the previous committed value or the complete new value; a partial value is a qualification failure. Temporary/journal debris is also checked.

## 4. API / ABI / CLI Compatibility Governance Center

`CompatibilityGovernanceCenter` compares versioned compatibility snapshots across five surfaces: API, ABI, CLI, schema, and configuration. Entries carry signatures and optional deprecation/removal metadata. Added interfaces require at least a minor semantic-version increment; removed or signature-changed interfaces are breaking; deprecation-state changes are patch-compatible.

Semantic versions are parsed and policy-checked. A deprecated interface cannot be removed before its declared removal version. ABI snapshots may be populated from `nm`-style symbol output using `parse_nm_symbols()`, while callers can populate API, CLI, schema, and configuration snapshots from their respective registries.

## 5. Adaptive Test Execution and Flakiness Operations Manager

`AdaptiveTestManager` maintains persistent per-test statistical history. Failure probability uses a Beta(1,1) posterior estimate and duration uses an exponentially weighted moving average. Repeated instability can trigger time-bounded automatic quarantine while release-blocking tests and their complete prerequisite closure remain mandatory.

Planning validates the dependency DAG, calculates downstream critical-path weight, accounts for impact and criticality, honors per-test memory estimates, allocates workers, respects dependency completion times, assigns retry budgets from observed failure probability, identifies tests blocked by skipped prerequisites, and records why each test is scheduled, quarantined, or blocked. Candidates carry ownership metadata and the resulting plan groups historically failing tests by owner (falling back to `unowned`) for explicit flaky-test routing. Historical state can be saved and reloaded from JSON; a zero `now_epoch_s` uses the host wall clock so quarantine expiry behaves correctly without mandatory timestamp plumbing.

## 6. Native C++ Code-Coverage and Change-Coverage Workbench

`NativeCoverageWorkbench` ingests LCOV as the canonical cross-compiler interchange format, allowing GCC/gcov/lcov and Clang/llvm-cov pipelines to feed the same engine. It aggregates executed and total lines, functions, and branches and calculates line, function, branch, and changed-line coverage.

Changed source lines can be supplied independently of coverage import. Paths are normalized across slash conventions before matching. The workbench reports uncovered changed lines and retains both source-line-to-test and function-to-test execution mappings so an engineer can determine which tests genuinely exercise a production change.

## 7. Translation-Unit / Header / Build-Cost Profiler

`BuildCostProfiler` quantifies native build cost rather than relying on translation-unit size alone. It records compile duration, peak compiler RSS, object size, direct/transitive headers, template-instantiation count, and template-instantiation time. It can ingest Ninja `.ninja_log`, Clang `-ftime-trace` JSON, and GCC `-ftime-report` text in addition to direct samples.

Reports aggregate per-translation-unit mean/max compile cost and per-header fan-out/rebuild blast radius. The profiler also estimates aggregate compiler memory pressure and recommends a safe compile parallelism for a supplied memory budget.

## 8. Architecture Fitness and Dependency-Boundary Gate

`ArchitectureFitnessGate` recursively scans C/C++ source and header files, resolves project-local include dependencies, maps files into configured architecture layers, and checks those edges against explicit allowed-dependency policies. Longest matching path prefixes are used for deterministic layer assignment.

The engine reports forbidden dependency edges and uses Tarjan strongly connected components to expose cyclic **inter-layer** dependencies; ordinary same-layer includes do not manufacture self-cycles. Layer prefixes are validated for empty or ambiguous duplicate assignments. Optional ownership policies map source prefixes to owners; proposed changes can then be checked against the actor performing the change. A fitness report fails when boundary, configured cycle, or ownership gates fail.

## 15. Long-Run Soak / Endurance Qualification Controller

`SoakEnduranceController` executes the supplied cycle callback for **every requested endurance cycle**, while `sample_every` controls which cycle observations are retained for trend analysis. Metrics include RSS, heap, GPU memory, open file descriptors, sockets, threads, queue depth, latency, workspace storage, checkpoint storage, numerical drift, and deterministic state hash. Elapsed time must remain monotonic.

The final report calculates p50/p95/p99 latency and least-squares growth trends for latency, RSS, heap, storage, and checkpoint size normalized per 1,000 cycles. Absolute resource limits, performance-degradation limits, resource-growth limits, numerical-drift bounds, and periodic state-hash consistency are enforced as qualification criteria. Violations are retained individually instead of being collapsed into a single boolean.

## 19. Unified Fuzz Corpus and Failure-Triage Hub

`FuzzCorpusHub` is deliberately a corpus/triage layer rather than another protocol-specific fuzzer. Existing and future fuzz engines can submit discoveries containing bytes, coverage features, failure signature, subsystem, source, and seed. Inputs are SHA-256 content-addressed and each normalized coverage-feature set receives a deterministic SHA-256 coverage fingerprint; duplicate payloads are rejected and admission is signal-driven by new coverage or new failure signatures.

The hub performs greedy corpus minimization while preserving discovered coverage and failures, explicit seed promotion (promoted seeds remain in the minimized corpus), delta-debugging failure minimization with deterministic byte canonicalization, persistent manifest/object storage with checksum and coverage-fingerprint validation, failure clustering, subsystem routing, regression-corpus promotion, and deterministic reproducer bundle creation (`input.bin`, metadata, and executable `reproduce.sh`). Seed promotion, fingerprints, provenance, and triage metadata survive save/load.

## Unified qualification surface

`GeneralizedEngineeringOperationsPlatform::capabilities()` exposes the ten implemented capabilities. `self_test()` exercises every subsystem in one deterministic qualification run and writes `generalized-engineering-operations-self-test.json` with an evidence SHA-256 digest.

The standalone executable supports:

```text
muzixdiagsys_generalized_ops capabilities [OUTPUT.json]
muzixdiagsys_generalized_ops self-test DIRECTORY [OUTPUT.json]
```

The feature library is intentionally isolated from the broad `aesim_advanced` archive for efficient engineering-tool builds, while `aesim_advanced` PUBLIC-links it so the normal advanced platform retains the complete feature surface.

## Build and validation

With tests and tools enabled, the focused qualification targets are:

```bash
cmake --build <build-dir> --target generalized_engineering_operations_platform_tests muzixdiagsys_generalized_ops
ctest --test-dir <build-dir> -R generalized_engineering_operations
```

The source regression additionally verifies the public classes, implementation algorithms, CMake integration, CLI commands, tests, documentation, and absence of incomplete implementation markers in the new subsystem.


## Related current platforms

V34 builds on this layer with native toolchain/binary/process qualification (`NATIVE_QUALIFICATION_PLATFORM.md`). V35 adds cross-series motorsport engineering (`MOTORSPORT_V35_PLATFORM.md`). The comprehensive operator/developer integration is documented in User Manual Chapters 93-95.

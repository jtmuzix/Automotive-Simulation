# Engineering Intelligence Platform

**Release:** 2026-08-19  
**Facade:** `aesim::advanced::intelligence::EngineeringIntelligencePlatform`  
**Standalone route:** `muzixdiagsys_advanced_platform engineering-intelligence ...`

The Engineering Intelligence Platform connects existing MuzixDiagSys physics, E/E architecture, software, timing, assurance, calibration, provenance, reproducibility, and requirement services into twenty deterministic engineering-analysis domains. It is additive: no existing command, simulator model, project format, motorsport platform, or advanced API command is replaced.

## 1. Architecture and non-duplication contract

The platform deliberately reuses canonical implementations where the simulator already had the required numerical or engineering authority:

- `EeArchitectureSynthesizer` remains the only E/E architecture solver. The engineering-intelligence route extends it with zonal placement, harness objectives, failure-domain diversity, and independent power-feed diversity.
- `ElectronicsPackagingPcbHarnessReliabilityLaboratory`, `RawSensorMetrologyLaboratory`, `LubricantChemistryConditionMonitoring`, `J3400Iso15118ConformanceLaboratory`, `BayesianExperimentalDesigner`, and the established scenario-space coverage/novelty service remain canonical owners reused by the second ten-domain expansion.
- `ConservationGovernor` remains the conservation authority. Cross-domain auditing aggregates its interface-level conservation evidence instead of implementing a competing balance solver.
- The parameter-identifiability laboratory delegates SVD/rank/correlation work to the existing validated identifiability implementation.
- `WholeVehicleConsequenceEngine` and `SimulationCausalityMicroscope` share one `EngineeringDependencyGraph`.
- Existing core SHA-256 facilities provide evidence and capsule integrity.
- The 3D harness synthesizer feeds routed harness geometry into the existing electronics/PCB/harness reliability laboratory instead of creating a second electrical reliability model.
- Workshop ADAS calibration reuses `RawSensorMetrologyLaboratory` for the uncertainty budget.
- Oil-condition analysis reuses `LubricantChemistryConditionMonitoring` rather than duplicating lubricant chemistry.
- Charging-connector aging feeds its aged mechanical/contact state into `J3400Iso15118ConformanceLaboratory` for canonical physical and thermal qualification.
- Scientific experiment planning delegates ranking to `BayesianExperimentalDesigner`.
- HPC novelty control calls the existing Frontier-Next scenario-space coverage/behavior-novelty service and adds campaign scheduling rather than replacing that metric implementation.

The capability response exposes these invariants explicitly as `shared_dependency_graph`, `extends_existing_ee_architecture_synthesizer`, `extends_existing_conservation_governor`, `reuses_existing_identifiability_solver`, `reuses_existing_raw_sensor_metrology`, `reuses_existing_lubricant_chemistry`, `reuses_existing_j3400_conformance`, `reuses_existing_bayesian_experimental_design`, and `reuses_existing_scenario_coverage_novelty`.

## 2. Build and discover

From the repository root:

```bash
cmake -S . -B build/full -G Ninja \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DBUILD_TESTING=ON \
  -DAESIM_BUILD_TOOLS=ON
cmake --build build/full --parallel --target \
  muzixdiagsys_advanced_platform \
  engineering_intelligence_platform_tests \
  engineering_intelligence_expansion_tests
```

Discover the twenty domains:

```bash
./build/full/muzixdiagsys_advanced_platform \
  engineering-intelligence capabilities \
  build/engineering-intelligence/capabilities.json
```

Run the integrated 20-domain qualification:

```bash
mkdir -p build/engineering-intelligence/self-test
./build/full/muzixdiagsys_advanced_platform \
  engineering-intelligence self-test \
  build/engineering-intelligence/self-test \
  build/engineering-intelligence/self-test.json
```

Run an individual domain:

```text
muzixdiagsys_advanced_platform engineering-intelligence \
  DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

The exact domain identifiers are:

```text
whole-vehicle-consequence-engine
zonal-ee-architecture-synthesizer
vehicle-software-service-graph-simulator
end-to-end-timebase-laboratory
cross-domain-conservation-auditor
parameter-identifiability-sloppiness-laboratory
signal-lineage-calibration-provenance
simulation-causality-microscope
computational-reproducibility-capsules
cross-layer-requirement-propagation
geometric-wiring-harness-synthesizer
vehicle-function-actuator-arbitration
age-of-information-freshness-laboratory
adas-service-calibration-workshop-metrology
embedded-resource-degradation-laboratory
concurrent-ecu-race-lock-order-analyzer
cross-fluid-condition-diagnostics
charging-connector-aging-laboratory
scientific-hypothesis-experiment-planner
hpc-experiment-novelty-redundancy-controller
```

## 3. Whole-Vehicle Consequence Engine

Use this domain to answer “what else changes if I change this?” across physical, software, signal, calibration, network, power, thermal, requirement, human, and manufacturing dependencies.

### Request model

`nodes[]` supports:

| Field | Meaning |
|---|---|
| `id` | Unique node identifier. |
| `domain` | Engineering domain such as `vehicle`, `thermal`, `controls`, or `manufacturing`. |
| `quantity` | Physical/logical quantity represented by the node. |
| `unit` | Engineering unit label. |
| `baseline_value` | Baseline value used for relative change reporting. |
| `criticality` | Root-cause/consequence importance multiplier. |
| `metadata` | Optional string metadata map. |

`edges[]` supports `id`, `from`, `to`, `kind`, `local_gain`, `delay_s`, `confidence`, and `rationale`. Supported dependency kinds are `physical`, `software`, `signal`, `calibration`, `network`, `power`, `thermal`, `requirement`, `human`, and `manufacturing`.

`changes[]` contains `node_id`, `delta`, and optional `relative`. Analysis controls are `maximum_depth`, `maximum_visits_per_node`, `minimum_effect_magnitude`, and `minimum_confidence`.

### Example

```json
{
  "nodes": [
    {"id":"rear_inverter_mass","domain":"vehicle","quantity":"mass","unit":"kg","baseline_value":18.0,"criticality":1.0},
    {"id":"rear_axle_load","domain":"dynamics","quantity":"rear axle load","unit":"kg","baseline_value":620.0,"criticality":1.1},
    {"id":"rear_tire_temp","domain":"tire","quantity":"temperature","unit":"degC","baseline_value":92.0,"criticality":1.2}
  ],
  "edges": [
    {"id":"mass_to_load","from":"rear_inverter_mass","to":"rear_axle_load","kind":"physical","local_gain":0.93,"confidence":0.98,"rationale":"rearward inverter placement"},
    {"id":"load_to_temp","from":"rear_axle_load","to":"rear_tire_temp","kind":"thermal","local_gain":0.05,"delay_s":35.0,"confidence":0.82}
  ],
  "changes": [
    {"node_id":"rear_inverter_mass","delta":4.0}
  ],
  "maximum_depth":8
}
```

Run:

```bash
./build/full/muzixdiagsys_advanced_platform engineering-intelligence \
  whole-vehicle-consequence-engine consequence.json consequence-result.json
```

The result reports each affected node, absolute/relative delta, confidence, accumulated delay, depth, causal path, domain-level effect aggregation, diagnostics, and evidence SHA-256.

## 4. Zonal E/E Architecture Synthesizer

This route solves constrained allocation of vehicle functions onto zonal/central compute candidates while considering CPU, memory, ASIL capability, replica diversity, network bandwidth/latency, harness geometry, harness mass/cost, cross-zone placement, failure domains, and independent power feeds.

### Principal request fields

`compute_nodes[]`: `id`, `zone`, `cpu_capacity_mips`, `memory_capacity_mb`, `cost`, `mass_kg`, `power_w`, `asil_capability`, `diversity_group`, `failure_domain`, `power_feed`, `x_m`, `y_m`, `z_m`.

`functions[]`: `id`, `zone`, `cpu_mips`, `memory_mb`, `maximum_latency_ms`, `asil_level`, `replicas`, `require_diverse_replicas`, `has_endpoint_location`, `endpoint_x_m`, `endpoint_y_m`, `endpoint_z_m`, `harness_mass_kg_per_m`, `harness_cost_per_m`, `maximum_harness_length_m`, `require_failure_domain_diversity`, `require_power_feed_diversity`.

`flows[]`: `id`, `source_function`, `destination_function`, `bandwidth_mbps`, `maximum_latency_ms`.

`network_links[]`: `id`, `first_node`, `second_node`, `bandwidth_mbps`, `latency_ms`, `cost`, `mass_kg`, `power_w`.

`options`: `cost_weight`, `mass_weight`, `power_weight`, `cross_zone_latency_penalty`, `harness_mass_weight`, `harness_cost_weight`, `cross_zone_allocation_penalty`, `maximum_search_nodes`.

Use `require_failure_domain_diversity` and `require_power_feed_diversity` for replicated safety functions that must survive common-cause compute/power failures. When legacy `require_diverse_replicas` is enabled and `diversity_group` is omitted, node identity is used as the fallback diversity group.

## 5. Vehicle Software Service-Graph Simulator

This domain evaluates end-to-end SDV service chains under execution, communication, queueing, deadline, crash, throttling, and network-partition effects.

`services[]` fields: `id`, `host`, `execution_time_ms`, `memory_mb`, `maximum_end_to_end_latency_ms`, `restart_time_ms`, `queue_capacity`, `priority`.

`links[]` fields: `id`, `from_service`, `to_service`, `propagation_latency_ms`, `bandwidth_mbps`, `fixed_overhead_ms`.

`requests[]` fields: `id`, `release_time_s`, `source_service`, `target_service`, `payload_kb`.

Optional `faults[]` fields: `time_s`, `kind`, `target_id`, `factor`. Fault kinds are `crash`, `recover`, `throttle`, `clear-throttle`, `partition`, and `heal-partition`.

Payload size participates in route cost through serialization delay. The simulator reports deterministic request completion/failure, path, latency, deadline misses, service busy fractions, completed/dropped request counts, and evidence hash.

## 6. End-to-End Timebase Laboratory

The timebase laboratory estimates local-to-reference clock correction and translates synchronization error into spatial registration error.

Two request modes are supported:

1. **Synthetic clock mode:** provide `clocks[]`, `reference_times_s`, optional `seed`, `object_speed_m_s`, and `synchronization_tolerance_s`.
2. **Observation mode:** provide `observations[]` directly.

Clock fields are `id`, `initial_offset_s`, `drift_ppm`, `quantization_s`, and `jitter_standard_deviation_s`.

Observation fields are `clock_id`, `local_timestamp_s`, `reference_timestamp_s`, `forward_path_delay_s`, `reverse_path_delay_s`, `weight`, and `object_speed_m_s`.

Outputs include correction scale/offset, estimated drift, RMS error, maximum timing error, maximum spatial error, observation count, global worst-case values, synchronization status, diagnostics, and evidence hash.

## 7. Cross-Domain Conservation Auditor

Provide `samples[]`; each sample contains `domain`, `interface_id`, `quantity`, `time_s`, `transferred_in`, `transferred_out`, `storage_change`, `modeled_generation`, `modeled_dissipation`, `absolute_tolerance`, and `relative_tolerance`.

Optional controls are `rollback_available` and `abort_multiple`.

The auditor reports interface residuals, normalized residuals, domain residual aggregation, contribution fractions, dominant interface/domain, and overall pass/fail evidence. Use consistent units within each conserved quantity. Suitable quantities include energy, mass, charge, species mass, and momentum.

## 8. Parameter Identifiability & Sloppiness Laboratory

Provide:

- `parameter_names[]`;
- `sensitivity_matrix[][]` where rows are observations and columns correspond to the parameter list;
- optional `observation_standard_deviations[]`;
- optional `singular_value_tolerance`;
- optional `maximum_condition_number`.

The output reports numerical rank, identifiability, condition number, sloppiness ratio, explicit unbounded flags, singular values, normalized information eigenvalues, parameter correlation, weak parameters, strongly correlated pairs, and evidence SHA-256.

Use this before calibration/optimization. A rank-deficient or extremely sloppy problem indicates that the requested parameters cannot be uniquely or robustly inferred from the supplied measurements/sensitivities.

## 9. Signal-Lineage / Calibration Provenance

`nodes[]` contains `id`, `kind`, `version`, `unit`, and optional `artifact_sha256`. Supported kinds are `sensor`, `signal`, `transform`, `calibration`, `software`, `network`, `estimator`, `controller`, and `actuator`.

`edges[]` contains `id`, `from`, `to`, `operation`, `scale`, `offset`, and `delay_s`.

`calibrations[]` contains `calibration_id`, `node_id`, `version`, `parameter_set_sha256`, `source`, `timestamp_utc`, and numeric `parameters`.

For upstream trace, set `operation` to `trace-upstream` (or omit it) and supply `signal_id`. For downstream impact analysis, set `operation` to `impact` and supply `source_id`. `maximum_depth` bounds traversal.

The trace result preserves lineage order, calibration provenance, accumulated scale/delay, validation diagnostics, and evidence hashing.

## 10. Simulation Causality Microscope

This domain consumes the same `nodes[]` and `edges[]` schema as the Whole-Vehicle Consequence Engine, then adds:

- `observed_node`;
- `observed_delta`;
- optional `maximum_depth`;
- optional `maximum_candidates`.

It traverses upstream from the observed anomaly and ranks candidate causes using observed magnitude, path gain, confidence, node criticality, and accumulated causal delay. Each ranked candidate includes its complete causal path to the observed node.

Use consequence analysis for forward “what if?” questions and the microscope for reverse “why did this happen?” questions. They intentionally share the same graph model.

## 11. Computational Reproducibility Capsules

### Create

The default operation is `create`. Supply `name`, `source_revision`, `model_version`, `command_line`, optional `random_seed`, `configuration`, `artifacts[]`, `environment_whitelist[]`, and `root_directory`.

Each artifact entry contains `path`, `role`, and optional `required`.

The generated capsule contains canonical `capsule.json`, `configuration.json`, copied artifacts, artifact/configuration SHA-256 hashes, selected environment metadata, source/model identity, seed, compiler/platform/executable identity, and executable `replay.sh`.

Example:

```json
{
  "operation":"create",
  "name":"brake-controller-baseline",
  "source_revision":"4ac9d8e",
  "model_version":"v20.1.2",
  "command_line":"./build/full/muzixdiagsys --project brake.muzixproj",
  "random_seed":42,
  "configuration":{"vehicle":"baseline","deterministic":true},
  "artifacts":[{"path":"inputs/brake-map.json","role":"calibration","required":true}],
  "environment_whitelist":["OMP_NUM_THREADS"],
  "root_directory":"build/reproducibility-capsules"
}
```

### Verify

```json
{
  "operation":"verify",
  "capsule_directory":"build/reproducibility-capsules/brake-controller-baseline"
}
```

Verification re-hashes the manifest configuration and every required artifact. Unsafe environment identifiers, absolute/traversal artifact destinations, and symlink escapes are rejected by capsule creation/verification.

## 12. Cross-Layer Requirement Propagation

`requirements[]` fields are `id`, `statement`, `metric`, `unit`, `direction`, `limit`, optional `measured_value`, and `layer`. `direction` is `maximum` by default or `minimum` for lower-bound requirements.

`allocations[]` fields are `parent_requirement`, `child_requirement`, `allocated_budget`, and `interface_overhead`.

The engine recursively evaluates effective values, committed child budgets, margins, pass/fail status, and complete violation chains. Cyclic requirement graphs are rejected.

For hypothetical analysis, add `change_requirement_id` and `measured_delta`; the engine evaluates the changed measured value without requiring callers to rebuild the graph manually.

Example end-to-end latency budget:

```json
{
  "requirements":[
    {"id":"aeb_e2e","statement":"AEB command reaches brake actuator within 20 ms","metric":"latency","unit":"ms","direction":"maximum","limit":20,"layer":"vehicle"},
    {"id":"perception","metric":"latency","unit":"ms","limit":8,"measured_value":6,"layer":"software"},
    {"id":"control","metric":"latency","unit":"ms","limit":6,"measured_value":5,"layer":"ecu"}
  ],
  "allocations":[
    {"parent_requirement":"aeb_e2e","child_requirement":"perception","allocated_budget":8},
    {"parent_requirement":"aeb_e2e","child_requirement":"control","allocated_budget":6,"interface_overhead":1}
  ]
}
```


## 13. 3D Wiring Harness Geometric Routing & Manufacturability Synthesizer

Domain: `geometric-wiring-harness-synthesizer`.

This is the geometric realization layer that was previously missing between zonal E/E allocation and the existing electrical/reliability harness solvers. It uses a deterministic 3D grid A* search with bend and proximity penalties, then simplifies the route into manufacturing segments and evaluates length, bend radius, clip count, mass, cost, collision clearance, and manufacturability.

Request fields:

- `endpoints[]`: `id`, optional `zone`, and `position` containing `x_m`, `y_m`, `z_m`.
- `keep_outs[]`: `id`, `minimum`, `maximum`, `clearance_m`, `proximity_penalty`.
- `routes[]`: `id`, `source_endpoint`, `destination_endpoint`, `bundle_diameter_m`, `minimum_bend_radius_m`, `maximum_length_m`, `clip_spacing_m`, `service_loop_length_m`, `mass_kg_per_m`, `cost_per_m`, `conductor_area_m2`, and `current_a`.
- `grid_resolution_m`: geometric search resolution.
- `maximum_expanded_nodes`: deterministic A* work bound.

The result contains routed 3D points, realized length and bend radius, bend/clip counts, mass/cost, compliance flags, diagnostics, totals, evidence SHA-256, and `canonical_harness_reliability`. The latter is produced by the existing `ElectronicsPackagingPcbHarnessReliabilityLaboratory`; the router does not duplicate harness electrical/reliability physics.

## 14. Vehicle Function Interaction & Actuator Arbitration Engine

Domain: `vehicle-function-actuator-arbitration`.

This engine evaluates simultaneous commands from independently valid vehicle functions that compete for a shared actuator. It supports driver override, command priority, authority, blend weight, mutually exclusive groups, physical saturation, slew-rate limiting, conflict detection, ownership transitions, and chatter limits.

`actuators[]` fields are `id`, `minimum_value`, `maximum_value`, `maximum_slew_per_s`, and `conflict_threshold`. `commands[]` fields are `time_s`, `function_id`, `actuator_id`, `requested_value`, integer `priority`, `authority`, `blend_weight`, `driver_override`, and `exclusive_group`. `maximum_owner_switches_per_actuator` bounds accepted ownership chatter.

Outputs include a deterministic per-time/per-actuator arbitration timeline, active/winning functions, request spread, saturation/slew flags, ownership changes, conflict counts, ownership-switch counts, interaction diagnostics, and evidence.

## 15. Age-of-Information / Data Freshness Laboratory

Domain: `age-of-information-freshness-laboratory`.

This laboratory distinguishes end-to-end *freshness* from task or network latency. Every sample records `stream_id`, `sequence`, `generation_time_s`, `arrival_time_s`, `consumption_time_s`, `freshness_budget_s`, `base_variance`, and `variance_time_constant_s`.

For each stream the engine computes mean/max/p95 age, transport and processing delay, freshness-budget violation fraction, time-weighted mean Age of Information, and a deterministic estimator-variance inflation model. `maximum_allowed_violation_fraction` defines the qualification threshold. Use it with the service-graph and timebase laboratories to distinguish synchronized, on-time data from information that is nevertheless stale when consumed.

## 16. ADAS Service Calibration & Workshop Metrology Laboratory

Domain: `adas-service-calibration-workshop-metrology`.

This models service-bay calibration feasibility for camera, radar, and LiDAR sensors. It estimates yaw/pitch correction from weighted alignment observations and combines observation fit with target position/angle, floor slope, wheel alignment, steering center, and ride-height uncertainty. Static-target and dynamic-road procedures are supported.

`setup` defines `target_position_standard_uncertainty_mm`, `target_angle_standard_uncertainty_deg`, `floor_slope_standard_uncertainty_deg`, `wheel_alignment_standard_uncertainty_deg`, `steering_center_standard_uncertainty_deg`, and `ride_height_standard_uncertainty_mm`. `sensors[]` defines `id`, `kind`, `procedure`, `yaw_tolerance_deg`, and `pitch_tolerance_deg`. `observations[]` defines true/measured yaw and pitch plus `standard_uncertainty_deg`.

The uncertainty calculation delegates to the existing `RawSensorMetrologyLaboratory`. Results include correction angles, standard and expanded uncertainty, maximum pre-calibration error, per-sensor feasibility, global worst uncertainty, and evidence.

## 17. Embedded Software Memory & Resource Degradation Laboratory

Domain: `embedded-resource-degradation-laboratory`.

This is a trace-driven long-duration ECU resource model. It implements deterministic first-fit or best-fit heap allocation with alignment, block splitting/coalescing, external-fragmentation tracking, duplicate allocation/free detection, leak detection, stack high-water marks, queue-capacity tracking, and handle lifecycle/capacity tracking.

`configuration` fields are `heap_bytes`, `stack_limit_bytes`, `queue_capacity`, `handle_capacity`, and `best_fit_allocator`. `events[]` contains `time_s`, `thread_id`, `kind`, `resource_id`, `amount`, and `alignment`. Event kinds are `allocate`, `free`, `stack-use`, `queue-depth`, `handle-open`, and `handle-close`.

The result reports peak/final heap use, largest free block, peak external fragmentation, per-thread stack high-water values, peak queue depth and handles, allocation/invalid-free/leak counts, diagnostics, and an overall resource-safety decision.

## 18. Concurrent ECU Software Race & Lock-Order Analyzer

Domain: `concurrent-ecu-race-lock-order-analyzer`.

The analyzer consumes an ordered software trace and applies vector-clock happens-before reasoning to memory accesses. Mutex release/acquire events synchronize clocks; common-lock protection suppresses false race reports. In parallel it builds a lock-order graph and detects cycles that represent potential deadlock orders. It also diagnoses double locks, unlocks of unowned locks, leaked locks, and repeated failed try-lock attempts without progress.

`events[]` fields are unique `sequence`, `thread_id`, `kind`, and `object_id`. Kinds are `read`, `write`, `lock`, `unlock`, `try-lock-failed`, and `progress`. `starvation_failed_try_lock_threshold` controls starvation/livelock diagnostics.

Outputs include concrete race pairs with thread/access/sequence provenance, lock-order cycles, misuse diagnostics, per-thread failed-try-lock/progress counts, race/deadlock-order status, and evidence.

## 19. Cross-Fluid Condition Chemistry & Service Diagnostics Laboratory

Domain: `cross-fluid-condition-diagnostics`.

The laboratory evaluates engine oil, transmission oil, differential oil, coolant, brake fluid, refrigerant oil, and hydraulic fluid under one service-diagnostics interface. Inputs can include service time, temperature, water content, viscosity, conductivity, pH, glycol fraction, boiling point, TAN/TBN, oxidation, additive depletion, soot, fuel dilution, wear metals, particle index, and acid number.

Oil categories are passed through the existing `LubricantChemistryConditionMonitoring` authority and retain its canonical report. The new layer adds fluid-specific service scoring and alerts for coolant, brake fluid, refrigerant oil, and hydraulic fluid, plus cross-fluid correlation diagnostics such as simultaneous coolant ionic degradation and elevated engine-oil water that warrants leak investigation.

Results include a 0-100 condition score, `normal`/`monitor`/`service-soon`/`service-now` state, alerts, minimum fleet/vehicle fluid score, cross-fluid diagnostics, and evidence.

## 20. EV Charging Connector Mechanical & Contact-Aging Laboratory

Domain: `charging-connector-aging-laboratory`.

This adds the missing physical connector lifecycle beneath the existing charging protocol/conformance stack. It models plating wear from mating cycles, contamination, misalignment and arc events; mechanical damage and corrosion; resistance growth; I-squared-R loss; connector temperature; insertion-force increase; and retention-force loss.

Request fields include `voltage_v`, `current_a`, `ambient_temperature_c`, `initial_contact_resistance_ohm`, `initial_insertion_force_n`, `initial_retention_force_n`, `insulation_resistance_ohm`, `plating_thickness_um`, `mating_cycles`, `contamination_fraction`, `humidity_fraction`, `misalignment_fraction`, `cable_strain_fraction`, `arc_events`, and `thermal_resistance_k_per_w`.

The aged state is then passed to the canonical `J3400Iso15118ConformanceLaboratory`; output includes the complete canonical conformance report plus physical/thermal compliance, remaining plating thickness, contact resistance, temperature, forces, damage/corrosion indices, connector loss, and evidence.

## 21. Scientific Hypothesis Discovery & Discriminating-Experiment Planner

Domain: `scientific-hypothesis-experiment-planner`.

The discovery stage accepts `variables`, numeric `rows`, and `target_variable`. It computes robust Pearson association, screens by `minimum_absolute_correlation`, penalizes predictors that are strongly correlated with other candidate explanatory variables, and derives normalized hypothesis priors. Generated statements remain explicitly **non-causal** (`causal_claim=false`).

`experiments[]` then defines `id`, `cost`, declared `outcomes`, and `outcome_probability_by_hypothesis`. The engine validates likelihoods and delegates expected-information-gain/entropy ranking to the existing `BayesianExperimentalDesigner`; `cost_weight` can trade information gain against experiment expense.

The result contains discovered hypotheses, correlations, confounder penalties, priors, canonical Bayesian design evidence, prior entropy, and the recommended discriminating experiment. This feature proposes what to test next; it does not assert causation from correlation.

## 22. HPC Experiment Novelty & Redundancy Controller

Domain: `hpc-experiment-novelty-redundancy-controller`.

Each `experiments[]` entry contains `id`, a fixed-width numeric `behavior` embedding, `uncertainty`, `estimated_compute_cost`, and `completed`. The controller standardizes behavior dimensions across the campaign, measures every pending experiment against completed behavior, suppresses candidates within `redundancy_distance_threshold`, and ranks the remainder by novelty plus uncertainty value minus optional compute-cost penalty. `maximum_new_experiments` limits admission to the next HPC batch.

The controller also invokes the existing Frontier-Next `scenario-space-coverage-metrics-platform`; `canonical_scenario_coverage` and `baseline_mean_behavior_novelty` therefore remain tied to the simulator's established coverage/novelty semantics rather than introducing a second incompatible metric.

Outputs identify each candidate's nearest completed experiment, normalized distance, novelty, scheduling utility, redundant/scheduled state, final scheduled/suppressed IDs, canonical coverage, and evidence.

## 23. Recommended integrated workflow

A strong end-to-end workflow is:

1. Build a `SignalLineageCalibrationProvenance` graph for the signals/calibrations involved in the study.
2. Use the `ParameterIdentifiabilitySloppinessLaboratory` before fitting model parameters.
3. Validate physical coupling with the `CrossDomainConservationAuditor`.
4. Qualify E/E allocation with the `Zonal E/E Architecture Synthesizer`.
5. Exercise software chains with the `Vehicle Software Service-Graph Simulator` and fault injection.
6. Quantify clock/spatial alignment with the `End-to-End Timebase Laboratory`.
7. Evaluate quantitative budgets with `Cross-Layer Requirement Propagation`.
8. Use the `Whole-Vehicle Consequence Engine` before committing an engineering change.
9. Route safety-critical shared actuators through Vehicle Function Interaction arbitration.
10. Check consumed-signal freshness with the Age-of-Information laboratory.
11. Qualify physical harness routing after E/E allocation and before accepting SI/PI assumptions.
12. Qualify workshop sensor calibration uncertainty where service procedures matter.
13. Exercise long-duration ECU resource and concurrency traces.
14. Evaluate fluid condition and charging-connector aging for service/lifecycle studies.
15. Use scientific hypothesis planning to choose discriminating experiments without asserting causality.
16. Use HPC novelty control to suppress redundant campaign runs.
17. Seal the accepted experiment with a `Computational Reproducibility Capsule`.

This ordering moves from provenance/observability to physical validity, architecture/timing, requirements, causal decision support, and finally reproducibility evidence.

## 24. C++ integration

Include the exported platform header:

```cpp
#include "aesim/advanced/engineering_intelligence_platform.hpp"
```

The public namespace is:

```cpp
aesim::advanced::intelligence
```

Direct applications may instantiate individual engines or route document requests through `EngineeringIntelligencePlatform::execute()`. Use the individual typed classes when the caller already owns structured C++ data; use the façade for JSON/document-driven automation and CLI-equivalent integration.

## 25. Validation

Focused validation targets are:

```bash
cmake --build build/full --parallel --target \
  engineering_intelligence_platform_tests \
  engineering_intelligence_expansion_tests \
  muzixdiagsys_advanced_platform

ctest --test-dir build/full --output-on-failure -R \
  'engineering_intelligence_(platform|expansion).*|engineering_intelligence_cli_regression'
```

The facade self-test independently executes all twenty domains. Existing feature-retention, duplicate-implementation, engineering-validation, command-surface, source-package, and documentation regressions remain part of release qualification.

The PTY streamlined-experience regression uses ordered, continuous-buffer synchronization for command-result/focus markers. This is intentionally a test-harness hardening change only: it does not alter terminal UI behavior or command semantics.

## 26. Engineering interpretation boundaries

These capabilities provide deterministic engineering analysis, evidence, and decision support. They do not make safety, homologation, cybersecurity, calibration-validity, or certification claims automatically. Requirement budgets remain valid only if their source requirements, units, allocations, and measurements are valid. Causal and consequence graphs represent declared dependencies and gains; their conclusions are only as strong as those declarations and confidence values. Reproducibility capsules prove artifact/configuration integrity and replay metadata, not physical model validity.

# MuzixDiagSys Documentation

**Current documentation revision:** 2026-08-27 - V35 Motorsport Expansion, V34 Native Qualification, and V33 Generalized Engineering Operations.

The authoritative operating manual is [`MUZIXDIAGSYS_USER_MANUAL.md`](MUZIXDIAGSYS_USER_MANUAL.md). The PDF is generated from that Markdown source; edit the Markdown first and regenerate the PDF with `../tools/generate_user_manual_pdf.sh`.

## Start here

- [Comprehensive User Manual](MUZIXDIAGSYS_USER_MANUAL.md) - installation, terminal operation, engineering workflows, complete command reference, testing, troubleshooting, glossary, and integrated platform chapters through V35.
- [Comprehensive User Manual PDF](MUZIXDIAGSYS_USER_MANUAL.pdf) - release rendering of the same authoritative manual.
- [Tutorial and Exact Command Guide](MUZIXDIAGSYS_TUTORIAL_AND_EXACT_COMMAND_GUIDE.md) - practical beginner-to-advanced workflows, including V33, V34, and V35 qualification workflows.
- [Documentation Index](DOCUMENTATION_INDEX.md) - authoritative/current references versus dated historical implementation and validation records.
- [Real-World TUI Usage Guide](REAL_WORLD_TUI_USAGE_GUIDE.md) - terminal-oriented operator workflows.

## Current V33-V35 platform references

- [V35 Motorsport Expansion Platform](MOTORSPORT_V35_PLATFORM.md) - WEC/IMSA endurance, BoP, rally, Formula E, driver digital twin, spatial track state, racecraft physics, hierarchical strategy, lap-time attribution/coaching, and GT3/GT4 customer racing.
- [V34 Native Qualification Platform](NATIVE_QUALIFICATION_PLATFORM.md) - sanitizers, configuration interactions, reproducible-build forensics, binary bloat, RNG lineage, resource ownership, process lifecycle, static analysis, fault localization, and compiler/optimization differential qualification.
- [V33 Generalized Engineering Operations Platform](GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md) - concurrency interleavings, hermetic I/O, persistence fault laboratory, compatibility governance, adaptive test execution, native coverage, build-cost profiling, architecture fitness, soak qualification, and unified fuzz corpus/triage.
- [Motorsport CLI Command Reference](MOTORSPORT_CLI_COMMANDS.md) - established F1/IndyCar/NASCAR/NHRA convenience routing plus the separate V35 qualification executable.
- [Advanced API CLI Commands](ADVANCED_API_CLI_COMMANDS.md) - advanced JSON command registry and the boundary between that registry and isolated V33-V35 qualification tools.

## Major current engineering references

- [Engineering Intelligence Platform](ENGINEERING_INTELLIGENCE_PLATFORM.md) - 20-domain reference covering consequence/causality, zonal E/E and geometric harness routing, software service graphs and actuator arbitration, timebase/AoI, conservation, identifiability, provenance, reproducibility, requirement budgets, workshop ADAS calibration, embedded-resource/concurrency degradation, fluid/charging-connector condition, scientific hypothesis planning, and HPC novelty control.
- [Global Mathematical Assurance](GLOBAL_MATHEMATICAL_ASSURANCE.md) - automatic error budgets, adaptive precision, exact reductions, convergence/MMS, derivative/KKT certification, consensus, property testing, and sealed evidence.
- [CTest Runtime-Artifact Fixture](CTEST_ARTIFACT_FIXTURE.md) - direct CTest build dependency closure, compiled-test fixture semantics, and missing-executable cascade prevention.
- [Global UI Architecture](GLOBAL_UI_ARCHITECTURE.md) - modular providers, context graph, rich forms, graph workflows, jobs, linked dashboards, persistence, virtualization, rendering, and accessibility.
- [Engineering UI Platform](ENGINEERING_UI_PLATFORM.md) - terminal/browser engineering workbenches and the V16 graphical engineering desktop.

## Documentation maintenance

Run the documentation gates after editing current guidance:

```bash
python3 tests/user_manual_regression.py .
python3 tests/documentation_consistency_regression.py .
./tools/generate_user_manual_pdf.sh
```

Then validate deterministic source packaging:

```bash
python3 tests/source_package_regression.py . build/doc-package-regression
```

Root-level dated `*_IMPLEMENTATION_REPORT_*.md`, `*_VALIDATION_*.txt`, and debug/refactor records are historical evidence. Do not rewrite them to describe later releases; current guidance belongs in the manual, tutorial, platform references, README, and documentation index.

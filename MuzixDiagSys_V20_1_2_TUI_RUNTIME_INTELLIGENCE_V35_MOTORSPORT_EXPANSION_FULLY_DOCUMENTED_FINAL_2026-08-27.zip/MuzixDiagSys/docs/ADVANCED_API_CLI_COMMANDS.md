# Advanced API CLI Commands

**Revision:** 2026-08-08

This guide documents the additive command registry that exposes mature MuzixDiagSys C++ engineering APIs through `muzixdiagsys_advanced_platform`. The adapters call the existing production implementations; they do not duplicate or replace the underlying physics, numerical solvers, lifecycle models, electronics models, autonomy systems, or motorsport command families.


## Isolated V33-V35 engineering qualification tools

Three current platform families are deliberately **not** duplicated as JSON commands in this registry. They have focused native libraries and small qualification executables so software-engineering and motorsport validation can be built without recompiling the complete advanced command backend:

```text
muzixdiagsys_generalized_ops        # V33 generalized engineering operations
muzixdiagsys_native_qualification   # V34 native C++ qualification
muzixdiagsys_motorsport_v35         # V35 cross-series motorsport expansion
```

Use `capabilities` and `self-test` on those executables. Their production C++ APIs remain available through `aesim_advanced`; this separation is a build/qualification boundary, not a reduction in the advanced platform feature surface. See `GENERALIZED_ENGINEERING_OPERATIONS_PLATFORM.md`, `NATIVE_QUALIFICATION_PLATFORM.md`, and `MOTORSPORT_V35_PLATFORM.md`.


## Interactive `muzixdiagsys` integration

The complete advanced dispatcher is also linked directly into the primary authenticated interactive console started by `muzixdiagsys`; no subprocess wrapper or duplicate API implementation is used. Inside that console:

```text
advanced commands
advanced commands --category electronics
advanced describe spice
advanced spice capabilities
advanced spice schema
advanced spice example
advanced spice run request.json result.json build/spice-evidence
```

All 214 registry commands are reachable through `advanced <command> ...`. API command names that do **not** collide with an existing simulator root are additionally available directly, for example `spice capabilities` or `world-model self-test ...`. The direct-export policy also covers the standalone advanced-platform dispatcher: safe roots such as `standards`, `emerging`, `frontier-runtime`, `frontier-expansion`, `frontier-systems`, `frontier-integration`, `frontier-next`, `interop`, `rosbag2`, `wireless-phy`, `native-solvers`, `slurm`, and `kubernetes` are first-class interactive roots. When a name is already owned by the simulator—such as `physics`, `calibrate`, `checkpoint`, `mdf`, `xcp`, `realtime`, `benchmark`, `solver`, `optimize`, or `safety`—the original simulator command keeps its established meaning and the advanced/API form remains available under `advanced`, for example `advanced physics capabilities`. This preserves backward compatibility while exposing the complete advanced dispatcher interactively.

Use `help advanced`, `command-schema validate`, and Tab completion after starting `muzixdiagsys` to discover and validate the integrated command surface.

For commands with an optional output path, `-` is the stdout sentinel. This is especially useful inside the interactive shell or pipelines; no file literally named `-` is created.

The public NASCAR façade APIs `nascar-ecosystem`, `nascar-frontier`, and `nascar-next-generation` are also available directly, through `motorsport ...`, and through `advanced ...`. A source-level CLI regression inventories all public advanced `*Platform` façades exposing `execute` + `self_test`; the current audit covers 20 façade APIs and fails if a new façade appears without an interactive mapping.

## Discovery and common grammar

```bash
./build/full/muzixdiagsys_advanced_platform commands
./build/full/muzixdiagsys_advanced_platform commands --category physics
./build/full/muzixdiagsys_advanced_platform describe credibility
./build/full/muzixdiagsys_advanced_platform credibility capabilities
./build/full/muzixdiagsys_advanced_platform credibility schema
./build/full/muzixdiagsys_advanced_platform credibility example
./build/full/muzixdiagsys_advanced_platform credibility self-test build/credibility-self-test build/credibility-self-test.json
./build/full/muzixdiagsys_advanced_platform credibility run request.json result.json build/credibility-evidence
```

All 214 registered commands support `capabilities`, `describe`, `schema`, `example`, `self-test`, and `run`. An operation token may be supplied in place of `run` when scripting a domain-specific workflow; the selected production adapter records the operation in its evidence output. A request file may also be supplied directly as shorthand for `run`.


## Orchestration, vehicle-service, and verification APIs

The registry now includes 27 production API commands covering the complete orchestration and engineering-service expansion. They use the same `capabilities`, `schema`, `example`, operation, `self-test`, output, evidence, and qualification machinery as the existing APIs and are available directly from `muzixdiagsys` when non-conflicting and always through `advanced <command> ...`.

```text
api-workflow       api-sweep           api-batch
api-contract-test  api-doctor          api-provenance
api-cache          api-jobs            api-cancel
api-resume         bms                 range
brakes             vehicle-estimator   sensor-fusion
suspension-rig     lap-sim             temporal-monitor
mutation-test      metamorphic-test    property-test
scenario-compile   safety-case         hara
fmea               fta                 tara
```

Examples:

```bash
api-workflow example
api-sweep schema
api-jobs submit jobs/request.json jobs/submit.json
bms simulate requests/bms.json results/bms.json
range predict requests/route.json results/range.json
brakes stopping-distance requests/brakes.json results/brakes.json
vehicle-estimator estimate requests/estimator.json results/estimator.json
sensor-fusion fuse requests/fusion.json results/fusion.json
suspension-rig seven-post requests/rig.json results/rig.json
lap-sim simulate requests/lap.json results/lap.json
temporal-monitor synthesize requests/monitor.json results/monitor.json
scenario-compile compile requests/scenario.json results/scenario.json
safety-case generate requests/safety.json results/safety.json
tara analyze requests/tara.json results/tara.json
```

`api-sweep` implements deterministic grid, pseudo-random, Latin-hypercube, and multidimensional Sobol sampling. `api-workflow` validates dependency DAGs, resolves typed result-to-request bindings, writes durable checkpoints, and resumes completed nodes. `api-cache` persists the production semantic result cache; `api-jobs`, `api-cancel`, and `api-resume` provide a durable filesystem-backed job state machine. `api-provenance` records and verifies SHA-256 request/result/content digests. The assurance commands reuse the production temporal-logic, mutation-testing, OpenSCENARIO, HARA/FMEA/FMEDA/FTA/STPA engines; `tara` adds deterministic automotive cyber-risk scoring and cybersecurity-goal generation.

## Global execution options

| Option | Behavior |
|---|---|
| `--pretty` / `--compact` | Pretty or compact JSON serialization. |
| `--output-format json|jsonl|csv|yaml` | Select deterministic output serialization. |
| `--evidence-dir PATH` | Supplies the default working/evidence directory and writes a command evidence artifact. |
| `--seed N` | Records/injects the deterministic seed when absent from the request; request-level seed values remain authoritative and are reflected in execution metadata. |
| `--threads N` | Records the requested execution-thread policy for orchestration and evidence. |
| `--backend NAME` | Records the requested backend policy (`auto`, CPU, OpenMP, Kokkos, HIP, CUDA, MPI, or a domain-supported backend). |
| `--precision NAME` | Records the requested precision policy (`auto`, `double`, `long-double`, `mp`, or a domain-supported precision). |
| `--deterministic` | Marks the execution request as deterministic. |
| `--strict` | Enables strict request metadata and injects `strict=true` when absent. |
| `--fail-on-warning` | Converts a non-empty warning/warnings field in the returned evidence into a failed qualification. |
| `--timeout SECONDS` | Applies a post-execution wall-time qualification and returns exit code 2 if exceeded. |
| `--profile` | Adds measured wall-time profiling information. |
| `--trace FILE` / `--metrics FILE` | Writes compact execution trace and metric sidecars. |
| `--no-large-arrays` | Truncates arrays larger than 128 entries in presentation output while preserving the executed calculation. |
| `--include-fields` / `--include-history` | Preserve large field/history arrays when pruning is requested. |
| `--dry-run` / `--validate-only` | Parse and validate the request without executing the engineering model. |
| `--explain` | Adds a concise pass/fail interpretation to the result. |
| `--compare FILE` | Attaches canonical comparison/hash evidence against a reference document. CLI-generated elapsed/profile timing is excluded from the canonical comparison, while substantive mismatches force `passed=false` and exit code 2. |
| `--schema` / `--example` / `--capabilities` | Force registry introspection without positional operation syntax. |

## Digital Thread commands

| Command | Existing API surface |
|---|---|
| `digital-thread` | SysmlV2DigitalThread / AutomatedCalibrationEngine |
| `calibrate` | SysmlV2DigitalThread / AutomatedCalibrationEngine |

## Lifecycle commands

| Command | Existing API surface |
|---|---|
| `crash` | Crash/Lifecycle APIs |
| `lifecycle` | Crash/Lifecycle APIs |

## Electronics commands

| Command | Existing API surface |
|---|---|
| `spice` | Electronics and power-distribution APIs |
| `battery-abuse` | Electronics and power-distribution APIs |
| `ee-architect` | Electronics and power-distribution APIs |
| `analog` | Electronics and power-distribution APIs |
| `adc` | Electronics and power-distribution APIs |
| `dac` | Electronics and power-distribution APIs |
| `pcb-si` | Electronics and power-distribution APIs |
| `pcb-pi` | Electronics and power-distribution APIs |
| `grounding` | Electronics and power-distribution APIs |
| `power-device` | Electronics and power-distribution APIs |
| `gate-driver` | Electronics and power-distribution APIs |
| `double-pulse` | Electronics and power-distribution APIs |
| `obc` | Electronics and power-distribution APIs |
| `dc-dc` | Electronics and power-distribution APIs |
| `wireless-charge` | Electronics and power-distribution APIs |
| `can-phy` | Electronics and power-distribution APIs |
| `lv-power` | Electronics and power-distribution APIs |
| `sleep-wake` | Electronics and power-distribution APIs |
| `pmic` | Electronics and power-distribution APIs |
| `hv-precharge` | Electronics and power-distribution APIs |

## Materials commands

| Command | Existing API surface |
|---|---|
| `materials` | MaterialsEnergyMultiphysics APIs |
| `icme` | MaterialsEnergyMultiphysics APIs |
| `as-built` | MaterialsEnergyMultiphysics APIs |
| `inverter-switching` | MaterialsEnergyMultiphysics APIs |
| `battery-eis` | MaterialsEnergyMultiphysics APIs |
| `corrosion` | MaterialsEnergyMultiphysics APIs |
| `hydrogen` | MaterialsEnergyMultiphysics APIs |
| `topopt` | MaterialsEnergyMultiphysics APIs |
| `rare-event` | MaterialsEnergyMultiphysics APIs |
| `combustion` | MaterialsEnergyMultiphysics APIs |

## Physics commands

| Command | Existing API surface |
|---|---|
| `physics` | FundamentalPhysics APIs |
| `entropy` | FundamentalPhysics APIs |
| `nonlinear-structure` | FundamentalPhysics APIs |
| `surface-chemistry` | FundamentalPhysics APIs |
| `rarefied-gas` | FundamentalPhysics APIs |
| `phase-field` | FundamentalPhysics APIs |
| `wave-coupling` | FundamentalPhysics APIs |
| `rom` | FundamentalPhysics APIs |
| `model-validity` | FundamentalPhysics APIs |
| `sensor-placement` | FundamentalPhysics APIs |
| `causal-localize` | FundamentalPhysics APIs |

## Software Quality commands

| Command | Existing API surface |
|---|---|
| `realtime` | Realtime/AUTOSAR/qualification APIs |
| `ptp` | Realtime/AUTOSAR/qualification APIs |
| `autosar` | Realtime/AUTOSAR/qualification APIs |
| `mlops` | Realtime/AUTOSAR/qualification APIs |
| `test-lab` | Realtime/AUTOSAR/qualification APIs |
| `sim-quality` | Realtime/AUTOSAR/qualification APIs |
| `vehicle-validate` | Realtime/AUTOSAR/qualification APIs |
| `regulation` | Realtime/AUTOSAR/qualification APIs |
| `composites` | Realtime/AUTOSAR/qualification APIs |
| `aeroelastic` | Realtime/AUTOSAR/qualification APIs |
| `tire-compound` | Realtime/AUTOSAR/qualification APIs |
| `tribology` | Realtime/AUTOSAR/qualification APIs |
| `surrogate` | Realtime/AUTOSAR/qualification APIs |
| `counterfactual` | Realtime/AUTOSAR/qualification APIs |
| `physical-test-plan` | Realtime/AUTOSAR/qualification APIs |

## Scientific commands

| Command | Existing API surface |
|---|---|
| `scientific` | ScientificFidelity APIs |
| `multiphysics-solve` | ScientificFidelity APIs |
| `dg` | ScientificFidelity APIs |
| `contact` | ScientificFidelity APIs |
| `random-field` | ScientificFidelity APIs |
| `enkf` | ScientificFidelity APIs |
| `inverse-pde` | ScientificFidelity APIs |
| `real-fluid` | ScientificFidelity APIs |
| `bayes-model` | ScientificFidelity APIs |
| `error-budget` | ScientificFidelity APIs |
| `instrument` | ScientificFidelity APIs |

## Measurement Debug commands

| Command | Existing API surface |
|---|---|
| `measurement` | Measurement/debug/regression APIs |
| `mdf` | Measurement/debug/regression APIs |
| `a2l` | Measurement/debug/regression APIs |
| `xcp` | Measurement/debug/regression APIs |
| `clock-align` | Measurement/debug/regression APIs |
| `time-travel` | Measurement/debug/regression APIs |
| `regression-impact` | Measurement/debug/regression APIs |

## Simulation commands

| Command | Existing API surface |
|---|---|
| `sim` | GeneralizedSimulation APIs |
| `distributed-run` | GeneralizedSimulation APIs |
| `checkpoint` | GeneralizedSimulation APIs |
| `mesh` | GeneralizedSimulation APIs |
| `autotune` | GeneralizedSimulation APIs |
| `modelica` | GeneralizedSimulation APIs |
| `solver-diff` | GeneralizedSimulation APIs |
| `benchmark` | GeneralizedSimulation APIs |
| `datalake` | GeneralizedSimulation APIs |
| `openapi` | GeneralizedSimulation APIs |
| `equivalence` | GeneralizedSimulation APIs |

## Deep Engineering commands

| Command | Existing API surface |
|---|---|
| `solver` | DeepEngineering APIs |
| `cad` | DeepEngineering APIs |
| `cfd` | DeepEngineering APIs |
| `vecu` | DeepEngineering APIs |
| `credibility` | DeepEngineering APIs |

## Architecture commands

| Command | Existing API surface |
|---|---|
| `mdo` | Architecture/intelligence/sustainability APIs |
| `sciml` | Architecture/intelligence/sustainability APIs |
| `pde-assimilate` | Architecture/intelligence/sustainability APIs |
| `electronics-reliability` | Architecture/intelligence/sustainability APIs |
| `photonics` | Architecture/intelligence/sustainability APIs |
| `cabin` | Architecture/intelligence/sustainability APIs |
| `fuel-cell` | Architecture/intelligence/sustainability APIs |
| `morphing` | Architecture/intelligence/sustainability APIs |
| `maintenance` | Architecture/intelligence/sustainability APIs |
| `recycling` | Architecture/intelligence/sustainability APIs |

## Fleet commands

| Command | Existing API surface |
|---|---|
| `codegen` | Codegen/manufacturing/fleet APIs |
| `factory` | Codegen/manufacturing/fleet APIs |
| `fleet` | Codegen/manufacturing/fleet APIs |
| `fleet-soc` | Codegen/manufacturing/fleet APIs |
| `chiplet` | Codegen/manufacturing/fleet APIs |

## Autonomy commands

| Command | Existing API surface |
|---|---|
| `world-model` | NextGenerationAutonomy APIs |
| `coop-perception` | NextGenerationAutonomy APIs |
| `pqc` | NextGenerationAutonomy APIs |
| `next-battery` | NextGenerationAutonomy APIs |
| `pnt` | NextGenerationAutonomy APIs |
| `climate` | NextGenerationAutonomy APIs |
| `generative-cad` | NextGenerationAutonomy APIs |
| `engineering-agent` | NextGenerationAutonomy APIs |
| `semiconductor-fab` | NextGenerationAutonomy APIs |

## Silicon Human commands

| Command | Existing API surface |
|---|---|
| `sensor-render` | Silicon/Human/Infrastructure APIs |
| `digital-human` | Silicon/Human/Infrastructure APIs |
| `post-crash` | Silicon/Human/Infrastructure APIs |
| `v2g` | Silicon/Human/Infrastructure APIs |
| `nonexhaust` | Silicon/Human/Infrastructure APIs |
| `lca` | Silicon/Human/Infrastructure APIs |
| `sidechannel` | Silicon/Human/Infrastructure APIs |
| `kernel-runtime` | Silicon/Human/Infrastructure APIs |

## Integrated commands

| Command | Existing API surface |
|---|---|
| `renderer` | PhysicallyBasedMultimodalRenderer |

## Vehicle Ecosystem commands

| Command | Existing API surface |
|---|---|
| `heavy-vehicle` | FrontierVehicleEcosystem APIs |
| `endurance` | FrontierVehicleEcosystem APIs |
| `matlab-hil` | FrontierVehicleEcosystem APIs |
| `gis` | FrontierVehicleEcosystem APIs |
| `sensor-clean` | FrontierVehicleEcosystem APIs |
| `motorcycle` | FrontierVehicleEcosystem APIs |
| `sumo` | FrontierVehicleEcosystem APIs |
| `passby-noise` | FrontierVehicleEcosystem APIs |
| `parking` | FrontierVehicleEcosystem APIs |

## Frontier Compute commands

| Command | Existing API surface |
|---|---|
| `chiplet-3dic` | FrontierComputeEnergyRisk APIs |
| `photonic-ai` | FrontierComputeEnergyRisk APIs |
| `e-road` | FrontierComputeEnergyRisk APIs |
| `hv-breakdown` | FrontierComputeEnergyRisk APIs |
| `quantum` | FrontierComputeEnergyRisk APIs |
| `hybrid-storage` | FrontierComputeEnergyRisk APIs |
| `robotics` | FrontierComputeEnergyRisk APIs |
| `mobility-market` | FrontierComputeEnergyRisk APIs |
| `proof-runtime` | FrontierComputeEnergyRisk APIs |
| `warranty` | FrontierComputeEnergyRisk APIs |

## High-value workflows

### Solver credibility and uncertainty

```bash
./build/full/muzixdiagsys_advanced_platform credibility self-test build/credibility build/credibility.json --profile --explain
./build/full/muzixdiagsys_advanced_platform error-budget self-test build/error-budget build/error-budget.json
./build/full/muzixdiagsys_advanced_platform solver-diff self-test build/solver-diff build/solver-diff.json
./build/full/muzixdiagsys_advanced_platform benchmark self-test build/benchmark build/benchmark.json
```

### Measurement and debugging

```bash
./build/full/muzixdiagsys_advanced_platform mdf self-test build/mdf build/mdf.json
./build/full/muzixdiagsys_advanced_platform a2l self-test build/a2l build/a2l.json
./build/full/muzixdiagsys_advanced_platform xcp self-test build/xcp build/xcp.json
./build/full/muzixdiagsys_advanced_platform time-travel self-test build/time-travel build/time-travel.json
./build/full/muzixdiagsys_advanced_platform regression-impact self-test build/regression-impact build/regression-impact.json
```

### Physics and scientific computing

```bash
./build/full/muzixdiagsys_advanced_platform physics self-test build/physics build/physics.json
./build/full/muzixdiagsys_advanced_platform cfd self-test build/cfd build/cfd.json
./build/full/muzixdiagsys_advanced_platform cad self-test build/cad build/cad.json
./build/full/muzixdiagsys_advanced_platform multiphysics-solve self-test build/multiphysics build/multiphysics.json
./build/full/muzixdiagsys_advanced_platform inverse-pde self-test build/inverse-pde build/inverse-pde.json
```

### Electronics and electrification

```bash
./build/full/muzixdiagsys_advanced_platform battery-abuse self-test build/battery-abuse build/battery-abuse.json
./build/full/muzixdiagsys_advanced_platform double-pulse self-test build/double-pulse build/double-pulse.json
./build/full/muzixdiagsys_advanced_platform pcb-si self-test build/pcb-si build/pcb-si.json
./build/full/muzixdiagsys_advanced_platform hv-precharge self-test build/hv-precharge build/hv-precharge.json
```

## Qualification and compatibility

The registry is additive. Existing `frontier-*`, standards, Formula One, NASCAR, IndyCar, NHRA, Slurm, Kubernetes, graph, and legacy advanced-platform commands retain their existing dispatch paths. `tests/advanced_api_cli_commands_regression.py` hard-codes the complete 214-command registry, executes every command capability path and self-test, exercises the global output/validation controls, and rejects unfinished implementation markers from the new CLI source surface.

## Lifecycle, transport, XIL, formal, network, and safety API expansion

The 21 commands below extend the registry from 173 to **194** commands. They are implemented by production in-process backends and participate in the same schema/example/self-test/evidence/interactive-completion machinery as every earlier advanced API.

```text
api-version          api-migrate          api-baseline
api-diff             api-replay           api-lineage
artifact-store       api-metrics          api-trace
grpc-server          telemetry-stream     xil-orchestrator
formal-reachability  wcet                 schedulability
slam                 network-digital-twin diagnostic-stack
road-surface         sotif                rss-safety
```

Key operation families:

| Command | Operations beyond the common grammar |
|---|---|
| `api-version` | `list`, `show`, `compatibility`, `deprecated`, `history` |
| `api-migrate` | `request`, `result`, `document`, `inspect` |
| `api-baseline` | `create`, `capture`, `compare`, `update`, `history`, `verify` |
| `api-diff` | `result`, `workflow`, `timeseries`, `distribution`, `evidence` |
| `api-replay` | `replay`, `verify` |
| `api-lineage` | `record`, `show`, `ancestors`, `descendants`, `graph`, `impact` |
| `artifact-store` | `put`, `get`, `inspect`, `verify`, `refs`, `pin`, `list`, `gc` |
| `api-metrics` | `measure`, `show`, `summarize`, `list` |
| `api-trace` | `trace`, `show`, `graph`, `critical-path`, `export` |
| `grpc-server` | `start`, `status`, `stop`, `call`, `serve` |
| `telemetry-stream` | `start`, `status`, `stop`, `topics`, `publish`, `probe` |
| `xil-orchestrator` | `campaign`, `compare`, `script` |
| `formal-reachability` | `analyze`, `certify`, `counterexample` |
| `wcet` | `analyze` |
| `schedulability` | `analyze`, `partition` |
| `slam` | `estimate` |
| `network-digital-twin` | `simulate`, `tsn`, `can-xl`, `t1s` |
| `diagnostic-stack` | `topology`, `obd`, `uds`, `doip`, `sovd`, `dtc` |
| `road-surface` | `sample`, `export` |
| `sotif` | `analyze`, `falsify` |
| `rss-safety` | `analyze` |

Examples from the primary interactive shell:

```text
api-version show version-request.json version-result.json
api-baseline capture baseline-request.json baseline-result.json
api-diff timeseries timeseries-request.json diff-result.json
api-replay verify replay-request.json replay-verification.json
artifact-store put artifact-request.json artifact-result.json
api-metrics measure metric-request.json metric-result.json
api-trace critical-path trace-request.json critical-path.json
grpc-server self-test
telemetry-stream self-test
xil-orchestrator script xil-request.json xil-result.json
formal-reachability certify reachability-request.json certificate-result.json
wcet analyze wcet-request.json wcet-result.json
schedulability analyze tasks.json schedulability-result.json
slam estimate slam-request.json slam-result.json
network-digital-twin tsn network.json tsn-result.json
diagnostic-stack uds diagnostic.json diagnostic-result.json
road-surface sample road.json surface-result.json
sotif falsify sotif.json sotif-result.json
rss-safety analyze rss.json rss-result.json
```

The gRPC wire contract is retained in `schemas/grpc/muzixdiagsys_advanced_api.proto`. The service uses HTTP/2 + standard gRPC five-byte message framing and Protobuf field encoding; its built-in `call` and `self-test` paths perform actual loopback protocol exchanges. `telemetry-stream` similarly performs an RFC 6455 Upgrade and sends actual WebSocket frames.

For request-field details, persistence layouts, numerical semantics, protocol behavior, and examples, see [`API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md`](API_LIFECYCLE_TRANSPORT_SYSTEM_SERVICES.md).


## Control, physical-system, co-simulation, and qualification expansion

The current append-only registry is **214 commands**. The 20 newest production services are:

```text
control-synthesis          safety-shield             prognostics
nvh                        aftertreatment             occupant-safety
fmi-cosim                  ssp-orchestrator           automotive-middleware
charging-session           depot-energy               ota-campaign
digital-key                accident-reconstruction    tire-digital-twin
thermal-management         driveline                  aero-map
ads-qualification          probabilistic-model-check
```

All twenty use the same capability/schema/example/self-test/evidence grammar, are direct safe roots in the primary interactive shell, and remain available as `advanced <command> ...`. Their production backends, operations, inputs, outputs, examples, and validation policy are documented in [`CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md`](CONTROL_PHYSICS_COSIM_ENGINEERING_SERVICES.md).


## Engineering Intelligence standalone command surface (2026-08-19)

The Engineering Intelligence Platform is a focused facade over existing and extended `aesim_advanced` services. It is **not appended to the 214-command advanced API registry**, so the registry count remains 214. The standalone advanced-platform executable routes all twenty domains through one document interface:

```text
muzixdiagsys_advanced_platform engineering-intelligence capabilities [output.json]
muzixdiagsys_advanced_platform engineering-intelligence self-test DIRECTORY [output.json]
muzixdiagsys_advanced_platform engineering-intelligence DOMAIN REQUEST.json OUTPUT.json [WORKING_DIRECTORY]
```

Domains:

```text
whole-vehicle-consequence-engine
zonal-ee-architecture-synthesizer
vehicle-software-service-graph-simulator
end-to-end-timebase-laboratory
cross-domain-conservation-auditor
parameter-identifiability-sloppiness-laboratory
signal-lineage-calibration-provenance
simulation-causality-microscope
computational-reproducibility-capsules
cross-layer-requirement-propagation
geometric-wiring-harness-synthesizer
vehicle-function-actuator-arbitration
age-of-information-freshness-laboratory
adas-service-calibration-workshop-metrology
embedded-resource-degradation-laboratory
concurrent-ecu-race-lock-order-analyzer
cross-fluid-condition-diagnostics
charging-connector-aging-laboratory
scientific-hypothesis-experiment-planner
hpc-experiment-novelty-redundancy-controller
```

The facade preserves the simulator's ownership boundaries: consequence and causality share `EngineeringDependencyGraph`; zonal allocation extends `EeArchitectureSynthesizer`; conservation uses `ConservationGovernor`; identifiability delegates to the existing validated decomposition; workshop calibration reuses raw-sensor metrology; cross-fluid oil analysis reuses lubricant chemistry; charging-connector qualification reuses J3400/ISO 15118 conformance; scientific planning reuses Bayesian experimental design; and HPC novelty control reuses the established scenario-coverage/novelty authority. See [`ENGINEERING_INTELLIGENCE_PLATFORM.md`](ENGINEERING_INTELLIGENCE_PLATFORM.md) for exact request fields and examples, and User Manual Chapter 91 for the integrated workflow.

## Frontier Professional standalone command surface (2026-08-10)

The Frontier Professional Integration is **not** appended to the advanced API registry and therefore does not change the registry's 214-command count. It is a focused executable linked against the same production `aesim_advanced` graph:

```text
muzixdiagsys_frontier_professional capabilities
muzixdiagsys_frontier_professional self-test [scratch-dir]
muzixdiagsys_frontier_professional opcua-aas [output.aasx]
muzixdiagsys_frontier_professional dil-openxr
muzixdiagsys_frontier_professional hardware-probe
muzixdiagsys_frontier_professional ns3-reference
muzixdiagsys_frontier_professional jupyter
muzixdiagsys_frontier_professional prometheus
muzixdiagsys_frontier_professional sigstore [artifact]
muzixdiagsys_frontier_professional bayes
muzixdiagsys_frontier_professional mlmc
muzixdiagsys_frontier_professional acoustics
muzixdiagsys_frontier_professional federated
```

See `docs/FRONTIER_PROFESSIONAL_INTEGRATION.md` and User Manual Chapter 73 for API semantics, native dependency detection, physical-hardware boundaries, notebook use, privacy accounting, and validation.

## V16 graphical engineering desktop support commands

The browser GUI consumes these structured/nested canonical operations; they are also available interactively and do not replace their parent command families:

```text
ui semantic json <command-line>
ui desktop activate <tab-id>
ui desktop reorder <tab-id> <index>
ui scenario-timeline resize <event-id> <duration-s>
ui workflow-editor json <graph-id>
ui workflow-debugger json
ui calibration-correlation json
ui run-compare track-json [max-points]
```

See `ENGINEERING_UI_PLATFORM.md` for GUI behavior and data contracts.

## V19 interactive help and error recovery

All direct advanced/API roots participate in the common help workflow even when their domain-specific request schema remains documented in this file. Use `help <root>` or `help <root> <operation>` for an operator-oriented description, `help search <term>` when the root is unknown, and `help errors [CODE]` when command validation/execution reports a diagnostic. `ui semantic <full-command-line>` validates root resolution, structured operands where metadata is available, permissions, capabilities, and runtime state before execution.

For automation, prefer each API command's `schema`/`capabilities` operation and structured result files; use `ui semantic json <command-line>` for command-entry diagnostics. Scripts should key on stable diagnostic codes/JSON fields rather than human prose.


## Browser research workbench API/CLI parity

The research-grade browser workbenches do not define independent REST mutation resources. `/api/schema` publishes canonical workbench actions and authenticated `/api/command` executes them through the same interactive-shell dispatcher. Consequently every browser backend action has a shell equivalent by construction. Read-only `/api/state` and `/api/stream` remain presentation transports.

Plugin and migration actions demonstrate strict parity: the browser executes `plugin list|load|unload` and `config check-version|migrate|diff|upgrade-all` directly. Formal and safety workbenches link to the backend CLI registry (`specification-discovery`, `advanced-safety-cli`) rather than embedding duplicate solver logic.

#pragma once

#include "aesim/app/ui_experience.hpp"
#include "aesim/app/global_ui_architecture.hpp"
#include "aesim/app/terminal_workstation_platform.hpp"

#include <cstdint>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::tuiproductivity {

enum class ChordFeedState : unsigned char { idle, awaiting, matched, rejected };
struct ChordBinding { std::vector<std::string> keys; std::string action; std::string context="global"; std::string description; };
struct ChordFeedResult { ChordFeedState state=ChordFeedState::idle; std::string action; std::string report; };
class LeaderKeyWhichKeyManager {
public:
    void set_leader(std::string key); [[nodiscard]] const std::string& leader() const noexcept { return leader_; }
    bool bind(ChordBinding binding,std::string& error); bool unbind(const std::vector<std::string>& keys,std::string_view context="global"); void clear();
    [[nodiscard]] ChordFeedResult feed(std::string key,std::string_view context="global"); void reset() noexcept { pending_.clear(); leader_active_=false; }
    [[nodiscard]] std::string report(std::string_view context="global") const; [[nodiscard]] const std::vector<ChordBinding>& bindings() const noexcept { return bindings_; }
    [[nodiscard]] bool active() const noexcept { return leader_active_; }
private: std::string leader_="space"; std::vector<ChordBinding> bindings_; std::vector<std::string> pending_; bool leader_active_=false;
};

struct GhostSuggestion { std::string full_command,ghost_suffix,reason; int score=0; };
class GhostTextSuggestionEngine {
public:
    [[nodiscard]] std::vector<GhostSuggestion> suggest(std::string_view input,const ux::ExperienceManager& experience,const std::vector<std::string>& history={},const std::vector<std::string>& context_hints={},std::size_t limit=5) const;
    [[nodiscard]] std::string report(std::string_view input,const ux::ExperienceManager& experience,const std::vector<std::string>& history={},const std::vector<std::string>& context_hints={}) const;
};

struct CommandAstArgument { std::string name,value; bool explicit_named=false,valid=true; std::string error; };
struct StructuredCommandAst { std::string original,canonical_path; const ux::CommandMetadata* metadata=nullptr; std::vector<CommandAstArgument> arguments; std::vector<std::string> extras; bool valid=false; std::vector<std::string> diagnostics; };
class StructuredCommandAstEditor {
public:
    [[nodiscard]] StructuredCommandAst parse(std::string_view line,const ux::ExperienceManager& experience) const;
    bool set(StructuredCommandAst& ast,std::string_view parameter,std::string value,std::string& error) const;
    [[nodiscard]] std::string emit(const StructuredCommandAst& ast) const; [[nodiscard]] std::string report(const StructuredCommandAst& ast) const;
    void validate(StructuredCommandAst& ast) const;
private: [[nodiscard]] static std::vector<std::string> tokenize(std::string_view line,std::string& error); [[nodiscard]] static std::string quote(std::string_view value);
};

struct KeyConflict { std::string key,context,first_action,second_action,kind; };
struct KeybindingAnalysis { std::vector<KeyConflict> conflicts; std::vector<std::string> unused_keys; std::map<std::string,std::size_t> context_counts; std::map<std::string,std::string> key_actions; };
class KeybindingConflictAnalyzer {
public:
    [[nodiscard]] KeybindingAnalysis analyze(const std::vector<ux::KeyBinding>& bindings,const std::vector<ChordBinding>& chords={}) const;
    [[nodiscard]] std::string report(const KeybindingAnalysis&) const; [[nodiscard]] std::string heatmap(const KeybindingAnalysis&) const;
};

enum class MruKind : unsigned char { pane,tab,workspace,context };
struct MruEntry { MruKind kind=MruKind::pane; std::string id,title,invocation,preview; std::uint64_t last_used=0; std::size_t uses=0; };
class MruUiSwitcher {
public:
    void touch(MruKind kind,std::string id,std::string title,std::string invocation,std::string preview={}); bool erase(MruKind kind,std::string_view id); void clear();
    [[nodiscard]] std::vector<MruEntry> recent(std::string_view query={},std::size_t limit=12) const; [[nodiscard]] std::string report(std::string_view query={}) const;
private: std::vector<MruEntry> entries_; std::uint64_t clock_=0;
};

enum class SnapshotFormat : unsigned char { ansi,plain,html,svg };
struct SnapshotMetadata { std::string title="MuzixDiagSys TUI Snapshot"; std::map<std::string,std::string> fields; int columns=120; int rows=40; };
class TuiSnapshotExporter {
public:
    [[nodiscard]] std::string export_text(std::string_view frame,SnapshotFormat format,const SnapshotMetadata& metadata={}) const;
    bool save(const std::filesystem::path& path,std::string_view frame,SnapshotFormat format,const SnapshotMetadata& metadata,std::string& error) const;
    [[nodiscard]] static std::optional<SnapshotFormat> parse_format(std::string value);
};

struct SignatureHelp { std::string command_path,current_parameter,signature,description; std::vector<std::string> choices; std::string unit,default_value; bool required=false; std::optional<double> minimum,maximum; bool found=false; };
class CommandSignatureHelpEngine {
public:
    [[nodiscard]] SignatureHelp help(std::string_view line,const ux::ExperienceManager& experience) const; [[nodiscard]] std::string report(const SignatureHelp&) const;
private: StructuredCommandAstEditor ast_;
};

enum class NumericStep : unsigned char { coarse_down,fine_down,fine_up,coarse_up,minimum,maximum,reset };
struct NumericAdjustmentState { bool active=false; double original_si=0,current_si=0,minimum_si=0,maximum_si=0,fine_step_si=0,coarse_step_si=0; std::string canonical_unit,display_unit,label; };
class NumericAdjuster {
public:
    explicit NumericAdjuster(const globalui::UnitRegistry* units=nullptr):units_(units){}
    bool begin(std::string label,double value_si,double minimum_si,double maximum_si,double fine_step_si,double coarse_step_si,std::string canonical_unit,std::string display_unit,std::string& error);
    bool adjust(NumericStep step,std::string& error); void cancel() noexcept { state_={}; }
    bool commit(const std::function<bool(double,std::string&)>& setter,std::string& error);
    [[nodiscard]] NumericAdjustmentState state() const noexcept { return state_; } [[nodiscard]] std::string report() const;
private: const globalui::UnitRegistry* units_=nullptr; NumericAdjustmentState state_{};
};

enum class ProblemSeverity : unsigned char { notice,warning,error,critical };
struct ProblemItem { std::string id,source,code,title,detail,remediation,context_uri; ProblemSeverity severity=ProblemSeverity::notice; std::size_t occurrences=1; bool acknowledged=false,resolved=false; std::vector<std::string> actions; };
class ProblemsPane {
public:
    void clear_view(); void ingest(const std::vector<ux::Issue>& issues); void ingest(const ux::CommandResult& result,std::string source="command"); void ingest(const std::vector<terminalws::ManagedAlarm>& alarms);
    void upsert(ProblemItem item); bool acknowledge(std::string_view id); bool resolve(std::string_view id); void set_filter(std::optional<ProblemSeverity> minimum,std::string query={});
    [[nodiscard]] std::vector<ProblemItem> visible() const; [[nodiscard]] std::optional<ProblemItem> selected() const; bool next(); bool previous();
    [[nodiscard]] std::string report(std::size_t width=120) const; [[nodiscard]] std::string action_report(std::string_view id) const;
private: std::map<std::string,ProblemItem> items_; std::optional<ProblemSeverity> minimum_; std::string query_; std::size_t cursor_=0;
};

class TuiProductivityPlatform {
public:
    LeaderKeyWhichKeyManager chords; GhostTextSuggestionEngine ghost; StructuredCommandAstEditor command_ast; KeybindingConflictAnalyzer key_analyzer; MruUiSwitcher mru; TuiSnapshotExporter snapshots; CommandSignatureHelpEngine signatures; NumericAdjuster numeric; ProblemsPane problems;
    TuiProductivityPlatform():numeric(&units){}
    globalui::UnitRegistry units;
};

} // namespace sim::console::tuiproductivity

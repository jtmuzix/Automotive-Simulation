#pragma once

#include <array>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::engineeringui {

class TelemetryWorkbench;

// V24 runtime-intelligence instruments. These consume existing simulator/TUI
// authorities; they do not replace telemetry, solver, HPC, calibration, or
// incident stores.

struct ThreadRuntimeObservation {
    std::uint64_t timestamp_ms=0,thread_id=0; std::string name,state; int cpu=-1; double cpu_percent=0.0;
};
struct LockContentionObservation {
    std::uint64_t timestamp_ms=0,waiter_thread=0,owner_thread=0; std::string lock_name; double wait_us=0.0,hold_us=0.0; bool waiting=true;
};
struct DeadlockCycle { std::vector<std::uint64_t> threads; std::vector<std::string> locks; };
class ThreadLockContentionDeadlockWorkbench {
public:
    bool observe_thread(ThreadRuntimeObservation observation,std::string& error);
    bool observe_lock(LockContentionObservation observation,std::string& error);
    std::size_t sample_process_threads(std::string& error);
    void clear();
    [[nodiscard]] std::vector<DeadlockCycle> deadlocks() const;
    [[nodiscard]] std::string report_threads(std::size_t limit=64) const;
    [[nodiscard]] std::string report_locks(std::size_t limit=40) const;
    [[nodiscard]] std::string report_deadlocks() const;
private:
    std::map<std::uint64_t,ThreadRuntimeObservation> threads_;
    std::deque<LockContentionObservation> locks_;
};

struct MemoryNumaSnapshot {
    std::uint64_t timestamp_ms=0,rss_bytes=0,peak_rss_bytes=0,virtual_bytes=0,heap_bytes=0,page_faults_minor=0,page_faults_major=0;
    std::map<int,std::uint64_t> numa_pages; double remote_numa_fraction=0.0;
};
struct MemoryOwnerRecord { std::string owner; std::uint64_t bytes=0; std::string category,source; };
class MemoryAllocatorNumaExplorer {
public:
    bool sample_process(std::string& error); void clear();
    bool set_owner(MemoryOwnerRecord owner,std::string& error); bool remove_owner(std::string_view owner);
    [[nodiscard]] std::optional<MemoryNumaSnapshot> latest() const;
    [[nodiscard]] std::string report(std::size_t history=12) const;
    [[nodiscard]] std::string owners_report(std::size_t limit=30) const;
private: std::deque<MemoryNumaSnapshot> samples_; std::map<std::string,MemoryOwnerRecord> owners_;
};

struct EquationTermDefinition { std::string name,signal,unit,source; double coefficient=1.0,constant_value=0.0; bool use_signal=true; };
struct ModelEquationDefinition { std::string id,title,lhs_signal,lhs_unit,description; std::vector<EquationTermDefinition> rhs_terms; double constant=0.0; };
struct ModelEquationEvaluation { std::string id,title,lhs_unit; double time_s=0.0,lhs=0.0,rhs=0.0,residual=0.0; std::vector<std::pair<std::string,double>> terms; bool complete=false; std::vector<std::string> missing; };
class ModelEquationResidualInspector {
public:
    bool upsert(ModelEquationDefinition equation,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::optional<ModelEquationEvaluation> evaluate(std::string_view id,const TelemetryWorkbench& telemetry,double time_s) const;
    [[nodiscard]] std::string report(std::string_view id,const TelemetryWorkbench& telemetry,double time_s) const;
    [[nodiscard]] std::string list() const;
private: std::map<std::string,ModelEquationDefinition> equations_;
};

struct PmuCounterSnapshot {
    std::uint64_t timestamp_ms=0,cycles=0,instructions=0,cache_references=0,cache_misses=0,branches=0,branch_misses=0,context_switches=0,page_faults=0;
    double ipc=0.0,cache_miss_percent=0.0,branch_miss_percent=0.0; bool hardware_counters=false;
};
class CpuMicroarchitecturePmuProfiler {
public:
    CpuMicroarchitecturePmuProfiler(); ~CpuMicroarchitecturePmuProfiler();
    CpuMicroarchitecturePmuProfiler(const CpuMicroarchitecturePmuProfiler&)=delete; CpuMicroarchitecturePmuProfiler& operator=(const CpuMicroarchitecturePmuProfiler&)=delete;
    bool start(std::string& error); bool sample(std::string& error); void stop(); void clear();
    [[nodiscard]] bool running() const noexcept; [[nodiscard]] std::string report(std::size_t history=12) const;
private:
    struct CounterFd { std::string name; int fd=-1; };
    std::vector<CounterFd> counters_; std::deque<PmuCounterSnapshot> samples_; bool running_=false;
};

struct SurrogateInputDomain { std::string name,unit; double minimum=0.0,maximum=0.0,mean=0.0,scale=1.0; };
struct SurrogateValidityModel { std::string id,label; std::vector<SurrogateInputDomain> inputs; double warning_distance=0.5,failure_distance=1.0,max_prediction_error=0.0; };
struct SurrogateValidityAssessment { std::string id,status="UNKNOWN"; double score=0.0,max_domain_distance=0.0; std::vector<std::string> out_of_domain; };
class SurrogateValidityOodMonitor {
public:
    bool upsert(SurrogateValidityModel model,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::optional<SurrogateValidityAssessment> evaluate(std::string_view id,const std::map<std::string,double>& inputs) const;
    [[nodiscard]] std::string report(std::string_view id,const std::map<std::string,double>& inputs) const;
    [[nodiscard]] std::string list() const;
private: std::map<std::string,SurrogateValidityModel> models_;
};

struct QueueFlowSample { std::uint64_t timestamp_ms=0; std::string queue; std::uint64_t depth=0,capacity=0,enqueued=0,dequeued=0,dropped=0; double p95_wait_ms=0.0; };
struct QueueFlowAssessment { std::string queue,status; double utilization=0.0,growth_per_s=0.0,p95_wait_ms=0.0; std::uint64_t dropped=0; };
class QueueBackpressureFlowControlAnalyzer {
public:
    bool observe(QueueFlowSample sample,std::string& error); void clear(std::string_view queue={});
    [[nodiscard]] std::vector<QueueFlowAssessment> analyze() const;
    [[nodiscard]] std::string report(std::size_t limit=40) const;
private: std::map<std::string,std::deque<QueueFlowSample>> queues_;
};

struct ControlAuthorityChannel { std::string id,label,unit; double command=0.0,minimum=0.0,maximum=0.0; std::uint64_t observations=0,saturated_observations=0; };
class ControlAuthoritySaturationWorkbench {
public:
    bool configure(ControlAuthorityChannel channel,std::string& error); bool observe(std::string_view id,double command,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::string report(std::string_view id={}) const;
private: std::map<std::string,ControlAuthorityChannel> channels_;
};

enum class CalibrationGovernanceState : unsigned char { editable,locked,frozen,leased,approval_required,homologated };
struct CalibrationGovernanceRule { std::string parameter,authority,reason,lease_holder; CalibrationGovernanceState state=CalibrationGovernanceState::editable; std::uint64_t expires_ms=0; };
struct CalibrationGovernanceAudit { std::uint64_t timestamp_ms=0; std::string parameter,actor,action,detail; bool allowed=false; };
class CalibrationGovernanceParameterLockManager {
public:
    bool set_rule(CalibrationGovernanceRule rule,std::string actor,std::string& error); bool erase(std::string_view parameter,std::string actor); void clear();
    [[nodiscard]] bool authorize(std::string_view parameter,std::string_view actor,bool approval_present,std::string& reason);
    [[nodiscard]] std::string report(std::string_view parameter={}) const; [[nodiscard]] std::string audit_report(std::size_t limit=100) const;
    [[nodiscard]] static std::optional<CalibrationGovernanceState> parse_state(std::string_view text); [[nodiscard]] static std::string state_name(CalibrationGovernanceState state);
private: std::map<std::string,CalibrationGovernanceRule> rules_; std::deque<CalibrationGovernanceAudit> audit_;
};

struct DistributedClockObservation { std::uint64_t timestamp_ms=0; std::string node; double offset_us=0.0,drift_ppm=0.0,rtt_ms=0.0; };
struct CausalMessageObservation { std::uint64_t sequence=0; std::string source,destination,message; double source_time_s=0.0,receive_time_s=0.0; };
class DistributedClockCausalityInspector {
public:
    bool observe_clock(DistributedClockObservation observation,std::string& error); bool observe_message(CausalMessageObservation observation,std::string& error); void clear();
    [[nodiscard]] std::string clock_report(double warning_offset_us=100.0,double failure_offset_us=500.0) const;
    [[nodiscard]] std::string causality_report(double tolerance_us=1.0,std::size_t limit=50) const;
private: std::map<std::string,DistributedClockObservation> clocks_; std::deque<CausalMessageObservation> messages_;
};

struct MatrixTensorRecord { std::string id,label,unit; std::size_t rows=0,cols=0; std::vector<double> values; };
struct MatrixTensorAnalysis { std::size_t rank=0; double frobenius_norm=0.0,condition_number=0.0,min_value=0.0,max_value=0.0; bool square=false,symmetric=false,positive_definite=false; std::vector<double> eigenvalues; };
class MatrixTensorInspector {
public:
    bool upsert(MatrixTensorRecord matrix,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] std::optional<MatrixTensorAnalysis> analyze(std::string_view id,double tolerance=1e-10) const;
    [[nodiscard]] std::string report(std::string_view id) const; [[nodiscard]] std::string heatmap(std::string_view id,std::size_t max_rows=24,std::size_t max_cols=48) const; [[nodiscard]] std::string list() const;
private: std::map<std::string,MatrixTensorRecord> matrices_;
};

struct DimensionSignature { std::array<int,7> exponents{}; bool angle=false,dimensionless=false; [[nodiscard]] bool operator==(const DimensionSignature& other) const noexcept { return exponents==other.exponents&&angle==other.angle; } };
struct UnitAuditResult { bool valid=false,compatible=false; std::string left,right,operation,derived,detail; };
class DimensionalUnitConsistencyAuditor {
public:
    [[nodiscard]] std::optional<DimensionSignature> dimension(std::string_view unit) const;
    [[nodiscard]] UnitAuditResult audit(std::string_view left_unit,std::string_view operation,std::string_view right_unit,std::string_view expected_unit={}) const;
    [[nodiscard]] std::string report(std::string_view left_unit,std::string_view operation,std::string_view right_unit,std::string_view expected_unit={}) const;
    [[nodiscard]] std::string known_units() const;
};

struct PostmortemRecord { std::uint64_t id=0,timestamp_ms=0,thread_id=0; std::string kind,summary,detail,signal_name,artifact_path,reproducibility_id,checkpoint_id; std::vector<std::string> stack; };
class CrashExceptionPostmortemWorkbench {
public:
    CrashExceptionPostmortemWorkbench();
    CrashExceptionPostmortemWorkbench(const CrashExceptionPostmortemWorkbench& other);
    CrashExceptionPostmortemWorkbench& operator=(const CrashExceptionPostmortemWorkbench& other);
    ~CrashExceptionPostmortemWorkbench();
    std::uint64_t record_exception(std::string summary,std::string detail,std::vector<std::string> stack={});
    std::uint64_t record_signal(int signal_number,std::string detail={});
    bool arm_signal_capture(std::filesystem::path directory,std::string& error); void disarm_signal_capture();
    std::size_t ingest_pending_markers(std::string& error); bool attach_artifact(std::uint64_t id,std::string artifact,std::string& error); void clear();
    [[nodiscard]] std::string report(std::optional<std::uint64_t> id={},std::size_t limit=30) const;
private: std::deque<PostmortemRecord> records_; std::uint64_t next_id_=1; std::filesystem::path marker_directory_; bool armed_=false;
};

} // namespace sim::console::engineeringui

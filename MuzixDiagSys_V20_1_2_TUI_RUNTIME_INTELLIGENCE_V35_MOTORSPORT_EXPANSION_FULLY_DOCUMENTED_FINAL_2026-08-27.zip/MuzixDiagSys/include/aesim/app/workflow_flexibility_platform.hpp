#pragma once

#include "aesim/app/global_ui_architecture.hpp"
#include "aesim/app/ui_experience.hpp"
#include "aesim/core/provenance.hpp"

#include <cstdint>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::workflowflex {

struct EngineeringContextCapsule {
    std::uint32_t schema_version = 1;
    std::string id;
    std::string label;
    std::uint64_t captured_ms = 0;
    std::string backend_state;
    ux::WorkspaceState workspace;
    std::vector<std::string> navigation_history;
    std::size_t navigation_cursor = 0;
    std::vector<std::string> selected_objects;
    std::vector<std::string> staged_commands;
    std::string active_workflow;
    std::string configuration_stack;
    std::map<std::string, std::string> filters;
    std::map<std::string, std::string> metadata;
    std::string sha256;
};

struct ContextCapsuleDifference { std::string field,left,right; };

class ContextCapsuleRegistry {
public:
    bool capture(EngineeringContextCapsule capsule, std::string& error);
    bool erase(std::string_view id);
    [[nodiscard]] std::optional<EngineeringContextCapsule> get(std::string_view id) const;
    [[nodiscard]] std::vector<EngineeringContextCapsule> list() const;
    [[nodiscard]] std::optional<EngineeringContextCapsule> clone(std::string_view id,std::string new_id,std::string new_label,std::string& error);
    [[nodiscard]] std::vector<ContextCapsuleDifference> diff(std::string_view left,std::string_view right,std::string& error) const;
    bool export_capsule(std::string_view id,const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::optional<EngineeringContextCapsule> import_capsule(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] std::string report() const;
    [[nodiscard]] static std::string serialize(const EngineeringContextCapsule& capsule,bool include_digest=true);
    [[nodiscard]] static std::optional<EngineeringContextCapsule> deserialize(std::string_view text,std::string& error);
    [[nodiscard]] static std::string digest(const EngineeringContextCapsule& capsule);
private:
    std::map<std::string,EngineeringContextCapsule> capsules_;
};

struct ConfigurationLayer {
    std::string id,label,source;
    bool enabled=true;
    std::map<std::string,std::string> values;
};
struct EffectiveValueSource {
    std::string layer_id,layer_label,source,value;
    bool enabled=true,winner=false;
};
struct EffectiveValueInspection {
    std::string key;
    bool defined=false;
    std::string effective_value;
    std::vector<EffectiveValueSource> chain;
    [[nodiscard]] std::string report() const;
};
class ConfigurationOverlayStack {
public:
    bool add(ConfigurationLayer layer,std::string& error);
    bool erase(std::string_view id);
    bool enable(std::string_view id,bool enabled,std::string& error);
    bool move(std::string_view id,std::size_t new_index,std::string& error);
    bool set(std::string_view layer,std::string key,std::string value,std::string& error);
    bool unset(std::string_view layer,std::string_view key,std::string& error);
    [[nodiscard]] std::optional<ConfigurationLayer> layer(std::string_view id) const;
    [[nodiscard]] std::vector<ConfigurationLayer> layers() const { return layers_; }
    [[nodiscard]] std::optional<std::string> effective(std::string_view key) const;
    [[nodiscard]] std::map<std::string,std::string> effective_all() const;
    [[nodiscard]] EffectiveValueInspection inspect(std::string_view key) const;
    [[nodiscard]] std::vector<std::string> diff_effective(const ConfigurationOverlayStack& other) const;
    [[nodiscard]] std::string serialize() const;
    bool deserialize(std::string_view text,std::string& error);
    bool save(const std::filesystem::path& path,std::string& error) const;
    bool load(const std::filesystem::path& path,std::string& error);
    [[nodiscard]] std::string report() const;
private:
    std::vector<ConfigurationLayer> layers_;
};

struct ScratchBranchStatus {
    bool active=false;
    std::string name,branch_name;
    std::vector<std::string> commands;
    std::uint64_t started_ms=0;
};
class ScratchBranchManager {
public:
    bool begin(std::string name,ux::ExperienceManager& experience,std::string backend_state,ux::WorkspaceState workspace,std::string& error);
    void record(std::string canonical_command);
    bool commit(ux::ExperienceManager& experience,std::string& error);
    bool discard(ux::ExperienceManager& experience,const std::function<bool(const std::string&,std::string&)>& restore_backend,const std::function<bool(const ux::WorkspaceState&,std::string&)>& restore_workspace,std::string& error);
    [[nodiscard]] ScratchBranchStatus status() const { return status_; }
    [[nodiscard]] const std::optional<ux::WorkspaceState>& original_workspace() const noexcept { return workspace_; }
private:
    ScratchBranchStatus status_;
    std::optional<ux::WorkspaceState> workspace_;
};

struct PortableMacro { std::string name; std::vector<std::string> commands; std::map<std::string,std::string> defaults; };
struct WorkflowPack {
    std::uint32_t schema_version=1;
    std::string id,title,description;
    std::string minimum_simulator_version="26";
    std::vector<globalui::WorkflowGraph> workflows;
    std::vector<PortableMacro> macros;
    std::vector<ux::WorkspaceDefinition> workspaces;
    std::vector<ux::CustomDashboard> dashboards;
    std::vector<ConfigurationLayer> configuration_layers;
    std::vector<EngineeringContextCapsule> contexts;
    std::map<std::string,std::string> metadata;
    std::string sha256;
};
class WorkflowPackCodec {
public:
    [[nodiscard]] static std::string serialize(const WorkflowPack& pack,bool include_digest=true);
    [[nodiscard]] static std::optional<WorkflowPack> deserialize(std::string_view text,std::string& error);
    [[nodiscard]] static std::string digest(const WorkflowPack& pack);
    static bool validate(const WorkflowPack& pack,std::string& error);
    static bool save(const WorkflowPack& pack,const std::filesystem::path& path,std::string& error);
    [[nodiscard]] static std::optional<WorkflowPack> load(const std::filesystem::path& path,std::string& error);
};

struct RecoveryRule {
    std::string id,diagnostic_code,message_contains;
    std::vector<std::string> commands;
    bool retry_original=true;
};
struct RecoveryPlan {
    std::uint64_t id=0;
    std::string original_command;
    std::vector<ux::DiagnosticMessage> diagnostics;
    std::vector<std::string> corrective_commands;
    bool retry_original=false;
    std::string pre_backend_state;
    ux::WorkspaceState pre_workspace;
    bool applied=false,succeeded=false;
    std::string outcome;
    [[nodiscard]] std::string report() const;
};
class GuidedRecoveryEngine {
public:
    bool add_rule(RecoveryRule rule,std::string& error);
    bool erase_rule(std::string_view id);
    [[nodiscard]] RecoveryPlan build(std::string original_command,const ux::CommandResult& result,std::string pre_backend_state,ux::WorkspaceState pre_workspace);
    [[nodiscard]] std::optional<RecoveryPlan> get(std::uint64_t id) const;
    [[nodiscard]] std::vector<RecoveryPlan> plans() const;
    bool execute(std::uint64_t id,const std::function<ux::CommandResult(const std::string&)>& execute_command,const std::function<bool(const std::string&,std::string&)>& restore_backend,const std::function<bool(const ux::WorkspaceState&,std::string&)>& restore_workspace,std::string& error);
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string,RecoveryRule> rules_;
    std::map<std::uint64_t,RecoveryPlan> plans_;
    std::uint64_t next_id_=1;
};

enum class PromotionKind : unsigned char { automatic,macro,workflow,configuration_overlay,context_capsule,workflow_pack };
struct PromotionRequest {
    std::string name;
    PromotionKind requested=PromotionKind::automatic;
    std::vector<std::string> commands;
    std::map<std::string,std::string> configuration_changes;
    std::optional<EngineeringContextCapsule> context;
    bool contains_branching_or_validation=false;
    bool portable=false;
};
struct PromotionArtifact {
    PromotionKind kind=PromotionKind::automatic;
    std::string rationale;
    std::optional<PortableMacro> macro;
    std::optional<globalui::WorkflowGraph> workflow;
    std::optional<ConfigurationLayer> configuration_layer;
    std::optional<EngineeringContextCapsule> context;
    std::optional<WorkflowPack> pack;
    [[nodiscard]] std::string report() const;
};
class PromotionEngine {
public:
    [[nodiscard]] PromotionArtifact promote(const PromotionRequest& request,std::string& error) const;
};

[[nodiscard]] EngineeringContextCapsule make_context_capsule(std::string id,std::string label,std::string backend_state,ux::WorkspaceState workspace,std::vector<std::string> navigation_history,std::size_t navigation_cursor,std::vector<std::string> selected_objects,std::vector<std::string> staged_commands,std::string active_workflow,std::string configuration_stack,std::map<std::string,std::string> filters={},std::map<std::string,std::string> metadata={});

} // namespace sim::console::workflowflex

#pragma once

#include "aesim/security/authentication.hpp"

#include <atomic>
#include <cstddef>
#include <memory>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace sim::console {

enum class TransmissionMode : unsigned char { Manual, Automatic };

struct EngineView {
    double afr = 0.0;
    double bmep_bar = 0.0;
    double boost_kpa_gauge = 0.0;
    double brake_thermal_efficiency = 0.0;
    double bsfc_g_kwh = 0.0;
    double coolant_c = 0.0;
    double egt_c = 0.0;
    double fmep_bar = 0.0;
    double friction_power_kw = 0.0;
    double fuel_flow_g_s = 0.0;
    double fuel_l_h = 0.0;
    double horsepower = 0.0;
    double imep_bar = 0.0;
    double indicated_power_kw = 0.0;
    double knock_margin_index = 0.0;
    double lambda = 1.0;
    double load = 0.0;
    double maf_g_s = 0.0;
    double map_kpa = 0.0;
    double mean_piston_speed_m_s = 0.0;
    double mfb50_deg_atdc = 0.0;
    double oil_c = 0.0;
    double oil_pressure_kpa = 0.0;
    double peak_cylinder_pressure_bar = 0.0;
    double power_kw = 0.0;
    double pumping_loss_kw = 0.0;
    bool rev_limited = false;
    double rpm = 0.0;
    bool running = false;
    double throttle = 0.0;
    double torque_nm = 0.0;
    double volumetric_efficiency = 0.0;
};

struct TransmissionView {
    double clutch = 0.0;
    double converter_multiplier = 0.0;
    double converter_slip = 0.0;
    int gear = 0;
    bool lockup = false;
    TransmissionMode mode = TransmissionMode::Automatic;
    double shift_timer_s = 0.0;
};

struct GearboxView {
    double efficiency = 0.0;
    double final_drive = 0.0;
    std::vector<double> forward_ratios;
};

struct VehicleView {
    double acceleration_m_s2 = 0.0;
    double brake_force_n = 0.0;
    double distance_m = 0.0;
    double drag_force_n = 0.0;
    double driver_demand_fraction = 0.0;
    double effective_driveline_efficiency = 0.0;
    double effective_mass_kg = 0.0;
    double effective_rolling_coefficient = 0.0;
    double grade_force_n = 0.0;
    double jerk_m_s3 = 0.0;
    double pedal_speed_target_kmh = 0.0;
    double road_load_power_kw = 0.0;
    double rolling_force_n = 0.0;
    double speed_limiter_factor = 0.0;
    double speed_m_s = 0.0;
    double wheel_force_n = 0.0;
    double wheel_power_kw = 0.0;
    double wheel_torque_nm = 0.0;
};

struct VehicleParametersView {
    double drag_coefficient_area_m2 = 0.0;
    double mass_kg = 0.0;
    double tire_radius_m = 0.0;
};

struct EngineGeometryView {
    double bore_m = 0.0;
    double compression_ratio = 0.0;
    int cylinders = 0;
    double displacement_liters = 0.0;
    double rod_length_m = 0.0;
    double stroke_m = 0.0;
};

struct EngineParametersView {
    double ambient_pressure_kpa = 0.0;
    double ambient_temp_c = 0.0;
    EngineGeometryView geometry;
    double max_boost_kpa_gauge = 0.0;
    double redline_rpm = 0.0;
};

struct FuelView {
    double cooling_factor = 0.0;
    double density_kg_l = 0.0;
    std::string display_name;
    double ethanol_fraction = 0.0;
    std::string key;
    double knock_resistance = 0.0;
    double lower_heating_value_mj_kg = 0.0;
    double stoich_afr = 0.0;
};

struct DriverInputsView {
    double brake = 0.0;
    double clutch = 0.0;
    bool ignition = false;
    bool starter = false;
    double throttle = 0.0;
};

struct EmissionsView {
    double catalyst_efficiency = 0.0;
    bool catalyst_efficiency_fault = false;
    bool catalyst_light_off = false;
    double catalyst_temp_c = 0.0;
    double co2_g_s = 0.0;
    double co_g_s = 0.0;
    double downstream_lambda = 0.0;
    double hc_g_s = 0.0;
    double nox_g_s = 0.0;
    double pm_g_s = 0.0;
    double upstream_lambda = 0.0;
};

struct Snapshot {
    EngineView engine;
    TransmissionView transmission;
    GearboxView gearbox;
    VehicleView vehicle;
    VehicleParametersView vehicle_params;
    EngineParametersView engine_params;
    FuelView fuel;
    DriverInputsView inputs;
    EmissionsView emissions;
    std::string vehicle_preset_key;
    std::string vehicle_preset_name;
    std::string engine_preset_key;
    std::string engine_preset_name;
    std::string plugin_dashboard_summary;
    std::vector<std::string> plugin_dashboard_lines;
};

struct PresetView {
    std::string key;
    std::string display_name;
    std::vector<std::string> aliases;
};

class Backend {
public:
    virtual ~Backend() = default;
    [[nodiscard]] virtual Snapshot snapshot() const = 0;
    [[nodiscard]] virtual std::vector<std::string> settable_parameters() const = 0;
    [[nodiscard]] virtual bool manual_transmission_selected() const = 0;
    [[nodiscard]] virtual std::vector<std::string> industrial_completion_candidates(
        const std::vector<std::string>& tokens, bool ends_space) const = 0;
    [[nodiscard]] virtual std::vector<PresetView> engine_presets() const = 0;
    [[nodiscard]] virtual std::vector<PresetView> vehicle_presets() const = 0;
    [[nodiscard]] virtual std::map<std::string,double> engineering_ui_metrics() const { return {}; }

    // Optional full-state hooks used by the interactive undo/redo and UI branch
    // controls. Backends that cannot serialize state remain fully compatible;
    // the UI reports the limitation instead of disabling unrelated features.
    [[nodiscard]] virtual std::string capture_ui_state() const { return {}; }
    virtual bool restore_ui_state(const std::string&, std::string& error) {
        error = "backend does not expose restorable UI state";
        return false;
    }
    [[nodiscard]] virtual std::string engineering_fidelity_status() const { return {}; }
    virtual bool set_engineering_fidelity_profile(std::string_view, std::string& error) {
        error = "backend does not expose a fidelity controller";
        return false;
    }
    [[nodiscard]] virtual std::string plugin_v2_control(const std::vector<std::string>&) {
        return "plugin ABI v2 control is unavailable on this backend\n";
    }
};

[[nodiscard]] std::string help_text();
[[nodiscard]] std::string command_help_text(std::string_view query);
[[nodiscard]] std::string error_reference_text(std::string_view code = {});
[[nodiscard]] std::string advanced_help_text(const Backend& backend);
[[nodiscard]] std::string one_line(const Snapshot& snapshot);
[[nodiscard]] std::string detailed_status(const Snapshot& snapshot);
[[nodiscard]] std::string dashboard(const Snapshot& snapshot);
[[nodiscard]] std::string drive_readiness_summary(const Snapshot& snapshot, bool loop_active);
[[nodiscard]] std::optional<std::string> resolve_root_command(std::string_view alias);
[[nodiscard]] const std::vector<std::string>& dashboard_page_names();
[[nodiscard]] std::string dashboard_page_list_text();
[[nodiscard]] std::string fixed_dashboard_page(
    const Snapshot& snapshot, bool loop_active, const std::string& requested_page);
[[nodiscard]] std::string fixed_dashboard_page(
    const Snapshot& snapshot, bool loop_active, const std::string& requested_page, int width);
[[nodiscard]] std::vector<std::string> dashboard_dictionary_terms();
[[nodiscard]] std::string dashboard_dictionary_lookup(std::string query);
[[nodiscard]] std::string global_command_schema_report(const Backend& backend, bool include_paths);
[[nodiscard]] std::string command_alias_report();
[[nodiscard]] std::string validate_global_command_schema(const Backend& backend);
[[nodiscard]] std::vector<std::string> completion_candidates(
    const std::string& line, const Backend& backend);
[[nodiscard]] std::string parameter_help_text(const Backend& backend);

class Session {
public:
    explicit Session(Backend& backend, const aesim::security::UserIdentity& identity);
    ~Session();
    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;
    Session(Session&&) noexcept;
    Session& operator=(Session&&) noexcept;

    [[nodiscard]] bool interactive() const noexcept;
    [[nodiscard]] int dashboard_refresh_interval_ms();
    [[nodiscard]] std::mutex& output_mutex() noexcept;

    void start(bool loop_active);
    [[nodiscard]] std::optional<std::string> next_command(std::atomic<bool>& loop_active);
    void present_command_result(const std::string& command,
                                const std::string& output,
                                bool keep_running,
                                bool loop_active);
    void render_dashboard_only(bool loop_active);
    void print_batch_telemetry(const std::string& line);
    void print_error(const std::string& line);
    void finish();

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace sim::console

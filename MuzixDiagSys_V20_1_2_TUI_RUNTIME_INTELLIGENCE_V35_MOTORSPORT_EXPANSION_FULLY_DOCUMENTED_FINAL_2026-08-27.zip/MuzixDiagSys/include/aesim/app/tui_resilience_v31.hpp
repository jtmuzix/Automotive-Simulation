#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::terminalws {

// V31 terminal resilience, diagnostic, security, and durable-operations services.
// These services extend the existing workstation and canonical command pipeline;
// they do not own authoritative simulation state.

enum class TerminalProtocolDirection : unsigned char { rx, tx };
struct TerminalProtocolEvent {
    std::uint64_t id=0,timestamp_ms=0;
    TerminalProtocolDirection direction=TerminalProtocolDirection::rx;
    std::string protocol,raw,escaped,decoded;
    bool malformed=false;
};
struct TerminalProtocolStatistics {
    std::size_t events=0,rx=0,tx=0,malformed=0,text_bytes=0,control_bytes=0;
    std::map<std::string,std::size_t> by_protocol;
};
class AnsiTerminalProtocolInspector {
public:
    void start(std::size_t capacity=8192); void stop() noexcept { capturing_=false; }
    [[nodiscard]] bool capturing() const noexcept { return capturing_; }
    void clear();
    void ingest(TerminalProtocolDirection direction,std::string_view bytes,std::uint64_t timestamp_ms=0);
    [[nodiscard]] std::vector<TerminalProtocolEvent> events(std::string_view protocol={},std::size_t limit=200) const;
    [[nodiscard]] std::optional<TerminalProtocolEvent> event(std::uint64_t id) const;
    [[nodiscard]] std::optional<std::string> replay_bytes(std::uint64_t id,std::string& error) const;
    [[nodiscard]] TerminalProtocolStatistics statistics() const;
    bool export_json(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string report(std::string_view protocol={},std::size_t limit=80) const;
private:
    void append(TerminalProtocolDirection direction,std::uint64_t timestamp_ms,std::string protocol,std::string raw,std::string decoded,bool malformed);
    bool capturing_=false; std::size_t capacity_=8192; std::uint64_t next_id_=1;
    std::deque<TerminalProtocolEvent> events_; std::size_t text_bytes_=0,control_bytes_=0;
};

struct GoldenFrameMask { std::size_t row0=0,column0=0,row1=0,column1=0; std::string reason; };
struct GoldenFrameDifference {
    std::size_t row=0,column=0; std::string kind,expected,actual,expected_style,actual_style;
};
struct GoldenFrameComparison {
    std::size_t rows=0,columns=0,identical=0,glyph_mismatch=0,style_mismatch=0,missing=0,masked=0;
    std::vector<GoldenFrameDifference> differences;
    [[nodiscard]] bool pass() const noexcept { return glyph_mismatch==0&&style_mismatch==0&&missing==0; }
};
class GoldenFrameVisualRegressionWorkbench {
public:
    bool add_mask(GoldenFrameMask mask,std::string& error); void clear_masks() noexcept { masks_.clear(); }
    [[nodiscard]] GoldenFrameComparison compare(std::string_view expected,std::string_view actual,std::size_t columns=0,std::size_t rows=0) const;
    bool compare_files(const std::filesystem::path& expected,const std::filesystem::path& actual,GoldenFrameComparison& out,std::string& error) const;
    bool approve(const std::filesystem::path& golden,std::string_view frame,std::string& error) const;
    bool export_json(const std::filesystem::path& path,const GoldenFrameComparison& comparison,std::string& error) const;
    [[nodiscard]] std::string render(const GoldenFrameComparison& comparison,std::size_t limit=100) const;
    [[nodiscard]] std::string overlay(std::string_view expected,std::string_view actual,std::size_t columns=0,std::size_t rows=0) const;
private: std::vector<GoldenFrameMask> masks_;
};

enum class PersistentJobState : unsigned char { queued,starting,running,paused,detached,completed,failed,cancelled,orphaned };
struct PersistentJobRecord {
    std::uint64_t id=0,created_ms=0,started_ms=0,changed_ms=0;
    std::string title,command,working_directory,log_path,status_path;
    PersistentJobState state=PersistentJobState::queued;
    long long pid=-1; int exit_code=0; bool exit_code_known=false,attached=true;
};
class PersistentBackgroundJobSupervisor {
public:
    bool configure(const std::filesystem::path& directory,std::string& error);
    std::uint64_t submit(std::string title,std::string command,std::string working_directory,bool start_now,std::string& error);
    bool start(std::uint64_t id,std::string& error); bool pause(std::uint64_t id,std::string& error); bool resume(std::uint64_t id,std::string& error);
    bool cancel(std::uint64_t id,std::string& error); bool detach(std::uint64_t id,std::string& error); bool attach(std::uint64_t id,std::string& error);
    bool recover(std::uint64_t id,std::string& error); void refresh();
    [[nodiscard]] std::optional<PersistentJobRecord> get(std::uint64_t id) const; [[nodiscard]] std::vector<PersistentJobRecord> list() const;
    [[nodiscard]] std::string tail(std::uint64_t id,std::size_t lines,std::string& error) const; [[nodiscard]] std::string report() const;
private:
    bool persist(std::string& error) const; bool load(std::string& error); bool signal_job(std::uint64_t id,int signal,PersistentJobState state,std::string& error);
    std::filesystem::path directory_,database_; std::map<std::uint64_t,PersistentJobRecord> jobs_; std::uint64_t next_id_=1;
};

enum class ForwardCommandState : unsigned char { queued,conflict,forwarding,forwarded,failed,discarded };
struct StoreForwardCommand {
    std::uint64_t id=0,created_ms=0,base_revision=0; std::string command,detail;
    bool mutating=true,replay_safe=true; ForwardCommandState state=ForwardCommandState::queued;
};
struct StoreForwardCacheEntry { std::string key,value; std::uint64_t revision=0,timestamp_ms=0; };
class DisconnectedStoreForwardOperationsMode {
public:
    bool configure(const std::filesystem::path& path,std::string& error);
    void disconnect(); void reconnect(std::uint64_t remote_revision); [[nodiscard]] bool connected() const noexcept { return connected_; }
    [[nodiscard]] std::uint64_t remote_revision() const noexcept { return remote_revision_; }
    std::uint64_t stage(std::string command,bool mutating,bool replay_safe,std::string& error);
    bool resolve(std::uint64_t id,std::string_view action,std::string replacement,std::string& error);
    [[nodiscard]] std::vector<StoreForwardCommand> ready() const; bool mark_forwarding(std::uint64_t id,std::string& error);
    void record_result(std::string_view command,bool success,std::string detail,bool mutating);
    void cache(std::string key,std::string value); [[nodiscard]] std::optional<StoreForwardCacheEntry> cached(std::string_view key) const;
    [[nodiscard]] static bool replay_safe_command(std::string_view command);
    [[nodiscard]] std::string report() const;
private:
    bool persist(std::string& error) const; bool load(std::string& error);
    std::filesystem::path path_; bool connected_=true; std::uint64_t remote_revision_=1,next_id_=1;
    std::map<std::uint64_t,StoreForwardCommand> queue_; std::map<std::string,StoreForwardCacheEntry> cache_;
};

enum class RedactionSeverity : unsigned char { low,medium,high,critical };
struct RedactionFinding { std::string category; RedactionSeverity severity=RedactionSeverity::medium; std::size_t begin=0,end=0; std::string preview; };
struct RedactionPolicy { std::string name; std::set<std::string> redact_categories,flag_categories; };
class SafeShareRedactionWorkbench {
public:
    SafeShareRedactionWorkbench();
    [[nodiscard]] std::vector<std::string> policy_names() const; bool select_policy(std::string_view name,std::string& error); [[nodiscard]] std::string active_policy() const { return active_; }
    [[nodiscard]] std::vector<RedactionFinding> inspect(std::string_view text) const; [[nodiscard]] std::string redact(std::string_view text,std::vector<RedactionFinding>* findings=nullptr) const;
    bool inspect_file(const std::filesystem::path& path,std::vector<RedactionFinding>& findings,std::string& error) const;
    bool redact_file(const std::filesystem::path& input,const std::filesystem::path& output,std::string& error) const;
    bool verify_file(const std::filesystem::path& path,std::string& error) const;
    [[nodiscard]] std::string report(const std::vector<RedactionFinding>& findings) const;
private: std::map<std::string,RedactionPolicy> policies_; std::string active_="public";
};

enum class PluginHealthState : unsigned char { healthy,degraded,quarantined,disabled };
struct PluginIsolationPolicy {
    double max_render_ms=25,max_cpu_percent=50; std::size_t max_memory_bytes=256u*1024u*1024u,max_errors=5,max_invalid_output=3;
    std::set<std::string> permissions;
};
struct PluginRuntimeSample { std::uint64_t timestamp_ms=0; double render_ms=0,cpu_percent=0; std::size_t memory_bytes=0; bool error=false,ansi_valid=true,utf8_valid=true,blocking=false; std::string detail; };
struct PluginHealthRecord { std::string id; PluginHealthState state=PluginHealthState::healthy; PluginIsolationPolicy policy; std::deque<PluginRuntimeSample> samples; std::size_t errors=0,invalid_output=0,violations=0,restarts=0; std::string reason; };
class PluginHealthIsolationQuarantineCenter {
public:
    bool register_plugin(std::string id,std::string& error); bool unregister_plugin(std::string_view id);
    bool set_policy(std::string_view id,PluginIsolationPolicy policy,std::string& error); bool observe(std::string_view id,PluginRuntimeSample sample,std::string& error);
    bool quarantine(std::string_view id,std::string reason,std::string& error); bool enable(std::string_view id,std::string& error); bool disable(std::string_view id,std::string& error); bool restart(std::string_view id,std::string& error);
    bool grant(std::string_view id,std::string permission,std::string& error); bool revoke(std::string_view id,std::string_view permission,std::string& error);
    [[nodiscard]] bool execution_allowed(std::string_view id,std::string_view permission={},std::string* reason=nullptr) const;
    [[nodiscard]] std::string report(std::string_view id={}) const;
private: void evaluate(PluginHealthRecord& record); std::map<std::string,PluginHealthRecord> plugins_;
};

struct TerminalCompatibilityProfile {
    std::string name,term; int columns=80,rows=24,latency_ms=0;
    bool utf8=true,color256=true,truecolor=false,mouse=false,osc8=false,osc52=false,sixel=false,kitty=false,synchronized_updates=false;
};
struct TerminalCompatibilityRequirement {
    int min_columns=80,min_rows=24; bool require_utf8=true,require_color256=false,require_truecolor=false,require_mouse=false,require_osc8=false,require_osc52=false,require_graphics=false,require_sync_updates=false;
};
struct TerminalCompatibilityResult { std::string profile; bool pass=true; std::vector<std::string> warnings,failures; };
class TerminalCompatibilityMatrixSimulator {
public:
    TerminalCompatibilityMatrixSimulator();
    bool upsert(TerminalCompatibilityProfile profile,std::string& error); bool remove(std::string_view name); [[nodiscard]] std::vector<TerminalCompatibilityProfile> profiles() const;
    [[nodiscard]] TerminalCompatibilityResult evaluate(std::string_view profile,const TerminalCompatibilityRequirement& requirements) const;
    [[nodiscard]] std::string matrix(const TerminalCompatibilityRequirement& requirements) const;
    [[nodiscard]] std::string preview(std::string_view frame,std::string_view profile,std::string& error) const;
private: std::map<std::string,TerminalCompatibilityProfile> profiles_;
};

enum class ScheduleKind : unsigned char { once,recurring,condition };
struct ScheduledCommandEntry {
    std::uint64_t id=0,created_ms=0,next_due_ms=0,interval_ms=0,last_run_ms=0,runs=0,max_runs=0;
    std::string name,command,condition,last_detail; ScheduleKind kind=ScheduleKind::once;
    bool enabled=true,edge_triggered=true,previous_condition=false; std::size_t retry_limit=3,retries=0; std::uint64_t retry_delay_ms=5000;
};
struct ScheduledExecutionRecord { std::uint64_t schedule_id=0,timestamp_ms=0; bool queued=false; std::string command,detail; };
class DeferredScheduledCommandWorkflowRunner {
public:
    bool configure(const std::filesystem::path& path,std::string& error);
    std::uint64_t add_at(std::string name,std::uint64_t epoch_ms,std::string command,std::string& error);
    std::uint64_t add_every(std::string name,std::uint64_t interval_ms,std::string command,std::string& error);
    std::uint64_t add_condition(std::string name,std::string condition,std::string command,bool edge_triggered,std::string& error);
    bool pause(std::uint64_t id,std::string& error); bool resume(std::uint64_t id,std::string& error); bool remove(std::uint64_t id);
    std::size_t tick(std::uint64_t now_ms,const std::map<std::string,double>& metrics,const std::function<bool(const std::string&,std::string&)>& enqueue);
    [[nodiscard]] std::vector<ScheduledCommandEntry> entries() const; [[nodiscard]] std::vector<ScheduledExecutionRecord> audit(std::size_t limit=100) const; [[nodiscard]] std::string report() const;
private:
    [[nodiscard]] static std::optional<bool> evaluate_condition(std::string_view expression,const std::map<std::string,double>& metrics,std::string& error);
    bool persist(std::string& error) const; bool load(std::string& error);
    std::filesystem::path path_; std::map<std::uint64_t,ScheduledCommandEntry> entries_; std::deque<ScheduledExecutionRecord> audit_; std::uint64_t next_id_=1;
};

struct GlyphWidthProbe { std::string id,glyph,label; int expected_width=1; std::optional<int> observed_width; };
class UnicodeCellWidthGlyphCalibrationLaboratory {
public:
    UnicodeCellWidthGlyphCalibrationLaboratory();
    bool observe(std::string_view id,int observed_width,std::string& error); bool observe_cursor(std::string_view id,int start_column,int end_column,std::string& error);
    void clear_observations(); [[nodiscard]] std::vector<GlyphWidthProbe> probes() const;
    [[nodiscard]] std::string probe_line() const; [[nodiscard]] std::map<std::string,std::string> fallback_profile() const;
    [[nodiscard]] std::string apply_fallbacks(std::string_view text) const; [[nodiscard]] std::string report() const;
private: std::map<std::string,GlyphWidthProbe> probes_;
};

enum class TuiTraceKind : unsigned char { input,key_dispatch,focus,selection,command,backend,layout,invalidation,render,terminal_write,mouse,scheduler,offline,plugin };
struct TuiTraceEvent {
    std::uint64_t id=0,timestamp_ms=0; TuiTraceKind kind=TuiTraceKind::input;
    std::string source,target,action,detail; std::size_t rows=0,bytes=0;
};
class TuiEventFocusTraceDebugger {
public:
    void enable(bool value=true) noexcept { enabled_=value; } [[nodiscard]] bool enabled() const noexcept { return enabled_; }
    void clear(); std::uint64_t record(TuiTraceEvent event);
    [[nodiscard]] std::vector<TuiTraceEvent> events(std::string_view filter={},std::size_t limit=200) const;
    [[nodiscard]] std::vector<TuiTraceEvent> causal_window(std::uint64_t id,std::size_t before=8,std::size_t after=8) const;
    bool export_json(const std::filesystem::path& path,std::string& error) const; [[nodiscard]] std::string report(std::string_view filter={},std::size_t limit=100) const;
private: bool enabled_=false; std::uint64_t next_id_=1; std::size_t capacity_=8192; std::deque<TuiTraceEvent> events_;
};

} // namespace sim::console::terminalws

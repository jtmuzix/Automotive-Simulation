#pragma once

#include "aesim/app/global_ui_architecture.hpp"
#include "aesim/app/workflow_flexibility_platform.hpp"
#include "aesim/studio/engineering_studio.hpp"

#include <cstdint>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::workflowintelligence {

// -----------------------------------------------------------------------------
// #1 Dependency-aware engineering action planner
// -----------------------------------------------------------------------------
struct ActionCapability {
    std::string id;
    std::string command;
    std::set<std::string> requires_facts;
    std::set<std::string> produces_facts;
    std::set<std::string> conflicts;
    std::set<std::string> exclusive_resources;
    double estimated_cost = 1.0;
    bool mutating = true;
};

struct PlannedAction {
    std::string id;
    std::string capability_id;
    std::string command;
    std::vector<std::string> dependencies;
    std::set<std::string> produces_facts;
    std::set<std::string> exclusive_resources;
    bool mutating = true;
    bool valid = true;
    std::string validation;
};

struct EngineeringActionPlan {
    std::uint64_t id = 0;
    std::vector<std::string> goals;
    std::vector<PlannedAction> actions;
    std::vector<std::vector<std::string>> parallel_waves;
    std::set<std::string> initial_facts;
    std::set<std::string> final_facts;
    std::vector<std::string> diagnostics;
    bool executable = false;
    bool atomic = true;
    [[nodiscard]] std::string report() const;
};

class EngineeringActionPlanner {
public:
    using CommandValidator = std::function<bool(const std::string&,std::string&)>;
    bool register_capability(ActionCapability capability,std::string& error);
    bool erase_capability(std::string_view id);
    void clear();
    [[nodiscard]] std::vector<ActionCapability> capabilities() const;
    [[nodiscard]] EngineeringActionPlan plan(const std::vector<std::string>& goals,
                                               std::set<std::string> available_facts,
                                               const CommandValidator& validator = {});
    [[nodiscard]] std::vector<std::string> commands(const EngineeringActionPlan& plan) const;
    [[nodiscard]] std::optional<EngineeringActionPlan> get(std::uint64_t id) const;
    [[nodiscard]] std::string report(std::uint64_t id = 0) const;
private:
    std::map<std::string,ActionCapability> capabilities_;
    std::map<std::uint64_t,EngineeringActionPlan> plans_;
    std::uint64_t next_plan_id_ = 1;
};

// -----------------------------------------------------------------------------
// #6 Live split-context comparison workspace
// -----------------------------------------------------------------------------
struct SplitContextLane {
    std::string id;
    std::string label;
    workflowflex::EngineeringContextCapsule context;
    std::optional<double> synchronized_time_s;
    std::string selected_object;
    std::map<std::string,double> last_metrics;
};

struct SplitContextMetricDelta {
    std::string metric;
    double left = 0.0;
    double right = 0.0;
    double absolute_delta = 0.0;
    double relative_delta = 0.0;
};

class SplitContextComparisonWorkspace {
public:
    using CaptureContext = std::function<workflowflex::EngineeringContextCapsule()>;
    using RestoreContext = std::function<bool(const workflowflex::EngineeringContextCapsule&,std::string&)>;
    using ExecuteCommand = std::function<bool(const std::string&,std::string&)>;
    using MetricProvider = std::function<std::map<std::string,double>()>;
    bool add_lane(SplitContextLane lane,std::string& error);
    bool remove_lane(std::string_view id);
    void clear();
    bool synchronize_time(double time_s,std::string& error);
    bool execute(std::string_view target,const std::string& command,bool atomic,
                 const CaptureContext& capture,const RestoreContext& restore,
                 const ExecuteCommand& execute,std::string& error);
    bool refresh_metrics(const CaptureContext& capture,const RestoreContext& restore,
                         const MetricProvider& metrics,std::string& error);
    [[nodiscard]] std::vector<SplitContextMetricDelta> compare(std::string_view left,
                                                               std::string_view right,
                                                               double epsilon=1.0e-12) const;
    [[nodiscard]] std::vector<SplitContextLane> lanes() const;
    [[nodiscard]] std::string report() const;
private:
    std::map<std::string,SplitContextLane> lanes_;
};

// -----------------------------------------------------------------------------
// #9 Resource-aware execution planner
// -----------------------------------------------------------------------------
enum class ExecutionMode : unsigned char { sequential,cpu_parallel,simd_batch,gpu_batch,distributed };
[[nodiscard]] std::string execution_mode_name(ExecutionMode mode);

struct HardwareResourceProfile {
    std::size_t cpu_threads = 1;
    std::uint64_t memory_bytes = 0;
    std::size_t gpu_count = 0;
    std::uint64_t gpu_memory_bytes_per_device = 0;
    std::size_t distributed_nodes = 1;
    double storage_write_mb_s = 250.0;
};
struct ExecutionWorkload {
    std::uint64_t scenarios = 1;
    std::uint64_t steps_per_scenario = 1;
    std::uint64_t state_bytes_per_scenario = 0;
    std::uint64_t output_bytes_per_scenario = 0;
    double parallel_fraction = 0.95;
    bool simd_eligible = true;
    bool gpu_eligible = false;
    bool distributed_eligible = false;
};
struct ExecutionCalibration {
    ExecutionMode mode = ExecutionMode::sequential;
    double steps_per_second = 1.0;
    double fixed_overhead_s = 0.0;
    double memory_multiplier = 1.0;
    double efficiency = 1.0;
};
struct ExecutionPlanEstimate {
    ExecutionMode mode = ExecutionMode::sequential;
    bool feasible = false;
    std::string reason;
    double wall_time_s = 0.0;
    double cpu_hours = 0.0;
    std::uint64_t peak_memory_bytes = 0;
    std::uint64_t gpu_memory_bytes = 0;
    std::uint64_t storage_bytes = 0;
    double parallel_efficiency = 0.0;
    double relative_speedup = 1.0;
};
class ResourceAwareExecutionPlanner {
public:
    void set_hardware(HardwareResourceProfile profile);
    void set_calibration(ExecutionCalibration calibration);
    [[nodiscard]] std::vector<ExecutionPlanEstimate> estimate(const ExecutionWorkload& workload) const;
    [[nodiscard]] std::optional<ExecutionPlanEstimate> recommend(const ExecutionWorkload& workload) const;
    [[nodiscard]] std::string report(const ExecutionWorkload& workload) const;
private:
    HardwareResourceProfile hardware_;
    std::map<ExecutionMode,ExecutionCalibration> calibrations_;
};

// -----------------------------------------------------------------------------
// #10 Workflow qualification / test harness
// -----------------------------------------------------------------------------
struct MockCommandResult { bool success=true; std::string output; std::map<std::string,double> variable_updates; };
struct WorkflowTestCase {
    std::string name;
    globalui::WorkflowGraph workflow;
    std::map<std::string,std::string> parameter_bindings;
    std::map<std::string,double> variables;
    std::map<std::string,MockCommandResult> mocks;
    std::vector<std::string> expected_commands;
    std::set<std::string> expected_visited_nodes;
    bool expect_success = true;
};
struct WorkflowQualificationResult {
    std::string name;
    bool passed = false;
    bool workflow_succeeded = false;
    std::vector<std::string> executed_commands;
    std::set<std::string> visited_nodes;
    std::set<std::string> traversed_edges;
    std::vector<std::string> failures;
    double node_coverage = 0.0;
    double edge_coverage = 0.0;
    [[nodiscard]] std::string report() const;
};
class WorkflowQualificationHarness {
public:
    [[nodiscard]] WorkflowQualificationResult run(const WorkflowTestCase& test) const;
    [[nodiscard]] std::vector<WorkflowQualificationResult> run_all(const std::vector<WorkflowTestCase>& tests) const;
    [[nodiscard]] std::string junit_xml(const std::vector<WorkflowQualificationResult>& results) const;
};

// -----------------------------------------------------------------------------
// #14 Reproducible investigation bundle (extends BugCapsuleStore)
// -----------------------------------------------------------------------------
struct InvestigationBundleRequest {
    std::string title;
    std::string failure_signature;
    std::string state_hash;
    aesim::doc::Value environment{aesim::doc::Value::Object{}};
    workflowflex::EngineeringContextCapsule context;
    std::string configuration_stack;
    std::vector<std::string> command_history;
    std::map<std::string,std::string> telemetry_artifacts;
    std::map<std::string,std::string> extra_artifacts;
    std::map<std::string,std::string> build_identity;
};
class InvestigationBundleBuilder {
public:
    [[nodiscard]] aesim::studio::BugCapsuleManifest build(const InvestigationBundleRequest& request) const;
    bool save(const InvestigationBundleRequest& request,const std::filesystem::path& path,std::string& error) const;
};

// -----------------------------------------------------------------------------
// #20 Uniform "Why?" explainability layer
// -----------------------------------------------------------------------------
enum class WhyCategory : unsigned char { value,event,recompute,solver,workflow,branch,failure,difference,selection,action_plan };
[[nodiscard]] std::string why_category_name(WhyCategory category);
struct ExplanationStep {
    std::string subject;
    std::string relation;
    std::string detail;
    std::string evidence;
};
struct WhyExplanation {
    WhyCategory category = WhyCategory::failure;
    std::string query;
    std::string summary;
    std::vector<ExplanationStep> chain;
    std::vector<std::string> next_commands;
    double confidence = 1.0;
    [[nodiscard]] std::string report() const;
};
class WhyExplainabilityEngine {
public:
    using Provider = std::function<std::optional<WhyExplanation>(std::string_view)>;
    bool register_provider(WhyCategory category,std::string id,int priority,Provider provider,std::string& error);
    bool erase_provider(WhyCategory category,std::string_view id);
    [[nodiscard]] WhyExplanation explain(WhyCategory category,std::string_view query) const;
    [[nodiscard]] WhyExplanation explain_value(std::string_view key,const workflowflex::ConfigurationOverlayStack& stack) const;
    [[nodiscard]] WhyExplanation explain_action_plan(const EngineeringActionPlan& plan,std::string_view action_id={}) const;
    [[nodiscard]] std::string providers_report() const;
private:
    struct ProviderEntry { std::string id; int priority=0; Provider provider; };
    std::map<WhyCategory,std::vector<ProviderEntry>> providers_;
};

} // namespace sim::console::workflowintelligence

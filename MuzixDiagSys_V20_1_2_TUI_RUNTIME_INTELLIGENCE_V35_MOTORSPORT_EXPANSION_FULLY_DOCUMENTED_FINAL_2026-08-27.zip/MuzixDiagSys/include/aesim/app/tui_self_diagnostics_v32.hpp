#pragma once

#include "aesim/app/tui_resilience_v31.hpp"

#include <cstddef>
#include <cstdint>
#include <deque>
#include <filesystem>
#include <functional>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <vector>

namespace sim::console::terminalws {

// V32 self-testing/self-diagnosing terminal platform.  These services consume
// the canonical V31 renderer/input/plugin/workspace state and never replace
// authoritative simulation or command-dispatch state.

enum class PaintChangeKind : unsigned char { unchanged, glyph, width, added, removed, full_redraw };
struct PaintCellChange {
    std::size_t row=0,column=0;
    PaintChangeKind kind=PaintChangeKind::unchanged;
    std::string before,after,cause;
};
struct PaintFrameRecord {
    std::uint64_t id=0,timestamp_ms=0;
    std::size_t rows=0,columns=0,changed_rows=0,changed_cells=0,emitted_bytes=0;
    double frame_ms=0.0,dirty_ratio=0.0,redundant_ratio=0.0;
    bool full_redraw=false;
    std::vector<PaintCellChange> changes;
    std::vector<std::string> invalidation_sources;
};
class RenderDirtyRegionPaintInspector {
public:
    void enable(bool value=true) noexcept { enabled_=value; }
    [[nodiscard]] bool enabled() const noexcept { return enabled_; }
    void clear();
    std::uint64_t observe(const std::vector<std::string>& rows,std::size_t changed_rows,std::size_t emitted_bytes,double frame_ms,bool full_redraw,std::vector<std::string> invalidation_sources={});
    [[nodiscard]] std::optional<PaintFrameRecord> frame(std::uint64_t id) const;
    [[nodiscard]] std::vector<PaintFrameRecord> frames(std::size_t limit=50) const;
    [[nodiscard]] std::string why(std::uint64_t frame_id,std::size_t row,std::size_t column) const;
    [[nodiscard]] std::string overlay(std::uint64_t frame_id,std::size_t max_rows=80,std::size_t max_columns=240) const;
    bool export_json(const std::filesystem::path& path,std::uint64_t frame_id,std::string& error) const;
    [[nodiscard]] std::string report(std::size_t limit=20) const;
private:
    bool enabled_=false; std::uint64_t next_id_=1; std::size_t capacity_=240;
    std::vector<std::string> previous_rows_; std::deque<PaintFrameRecord> frames_;
};

enum class RegressionStepKind : unsigned char { type_text,key,raw_bytes,resize,wait_for,assert_text,assert_absent,assert_focus,assert_cell,snapshot,sleep_ms,command };
struct RegressionScenarioStep {
    std::uint64_t id=0; RegressionStepKind kind=RegressionStepKind::type_text;
    std::string value,argument; int x=0,y=0; std::uint64_t timeout_ms=3000;
};
struct RegressionScenario {
    std::string name,terminal_profile="xterm-120x30"; int columns=120,rows=30;
    std::vector<RegressionScenarioStep> steps;
};
struct RegressionReplayResult { bool pass=true; std::size_t executed=0; std::uint64_t failed_step=0; std::string detail; };
class TuiRegressionScenarioComposer {
public:
    bool create(std::string name,std::string terminal_profile,int columns,int rows,std::string& error);
    bool begin_recording(std::string& error); void stop_recording() noexcept { recording_=false; }
    [[nodiscard]] bool recording() const noexcept { return recording_; }
    std::uint64_t append(RegressionScenarioStep step,std::string& error); bool erase(std::uint64_t step_id); void clear_steps();
    [[nodiscard]] RegressionScenario scenario() const { return scenario_; }
    RegressionReplayResult replay(const std::function<bool(const RegressionScenarioStep&,std::string&)>& executor) const;
    std::size_t minimize(const std::function<bool(const RegressionScenario&,std::string&)>& still_fails,std::string& detail);
    bool save(const std::filesystem::path& path,std::string& error) const; bool load(const std::filesystem::path& path,std::string& error);
    bool export_python(const std::filesystem::path& path,std::string executable_expression,std::string& error) const;
    [[nodiscard]] std::string report() const;
private:
    RegressionScenario scenario_; bool recording_=false; std::uint64_t next_id_=1;
};

struct UiModelState {
    int columns=120,rows=30; std::string focus="command"; bool lower_pane=true,overlay=false,connected=true,plugin_quarantined=false;
    std::set<std::string> visible_panes{"dashboard","command"};
    [[nodiscard]] std::string key() const;
};
struct UiModelViolation { std::string invariant,detail; std::vector<std::string> trace; UiModelState state; };
struct UiModelCheckResult { std::size_t visited=0,transitions=0,max_depth=0; std::vector<UiModelViolation> violations; [[nodiscard]] bool pass() const noexcept { return violations.empty(); } };
class DeterministicUiStateModelChecker {
public:
    [[nodiscard]] UiModelCheckResult check(const UiModelState& initial,std::size_t maximum_depth=7,std::size_t maximum_states=20000) const;
    [[nodiscard]] std::vector<std::string> available_actions(const UiModelState& state) const;
    [[nodiscard]] std::optional<UiModelState> transition(const UiModelState& state,std::string_view action) const;
    [[nodiscard]] std::vector<std::string> invariant_failures(const UiModelState& state) const;
    [[nodiscard]] std::string report(const UiModelCheckResult& result) const;
};

enum class EscapeMutationKind : unsigned char { truncate,oversized_parameter,embedded_nul,invalid_utf8,duplicate_escape,missing_terminator,fragment_boundary,insert_control,delete_byte,bit_flip };
struct EscapeMutationCase { std::uint64_t id=0; EscapeMutationKind kind=EscapeMutationKind::truncate; std::string source,bytes,description; std::size_t split_at=0; };
struct EscapeFuzzOutcome { std::uint64_t case_id=0; bool crash=false,hang=false,exception=false,state_divergence=false,escape_leak=false,unexpected_command=false; std::string detail; [[nodiscard]] bool failure() const noexcept { return crash||hang||exception||state_divergence||escape_leak||unexpected_command; } };
class TerminalEscapeMutationFuzzLaboratory {
public:
    void clear(); std::size_t generate(std::string corpus,std::uint64_t seed=1,std::size_t maximum_cases=64);
    [[nodiscard]] std::vector<EscapeMutationCase> cases(std::size_t limit=100) const; [[nodiscard]] std::optional<EscapeMutationCase> get(std::uint64_t id) const;
    EscapeFuzzOutcome run(std::uint64_t id,const std::function<EscapeFuzzOutcome(const EscapeMutationCase&)>& executor,std::string& error);
    std::optional<EscapeMutationCase> minimize(std::uint64_t id,const std::function<bool(std::string_view)>& still_fails,std::string& error) const;
    [[nodiscard]] std::vector<EscapeFuzzOutcome> outcomes(std::size_t limit=100) const; [[nodiscard]] std::string report() const;
private: std::uint64_t next_id_=1; std::deque<EscapeMutationCase> cases_; std::deque<EscapeFuzzOutcome> outcomes_;
};

enum class ClipboardEntryType : unsigned char { text,command,signal_list,time_range,json,csv,config_patch,parameter_set,object_uri,run_reference,table,query };
struct TypedClipboardEntry {
    std::uint64_t id=0,timestamp_ms=0; ClipboardEntryType type=ClipboardEntryType::text;
    std::string label,content; bool pinned=false,sensitive=false; std::map<std::string,std::string> metadata;
};
class TypedClipboardHistoryTransferCenter {
public:
    bool configure(const std::filesystem::path& path,std::string& error); void clear(bool include_pinned=false);
    std::uint64_t store(ClipboardEntryType type,std::string label,std::string content,bool pinned,bool sensitive,std::string& error);
    bool erase(std::uint64_t id,std::string& error); bool pin(std::uint64_t id,bool value,std::string& error);
    [[nodiscard]] std::optional<TypedClipboardEntry> get(std::uint64_t id) const; [[nodiscard]] std::vector<TypedClipboardEntry> history(std::size_t limit=100) const;
    std::optional<std::string> convert(std::uint64_t id,ClipboardEntryType target,std::string& error) const;
    std::optional<std::string> external_transfer(std::uint64_t id,const SafeShareRedactionWorkbench& safe_share,bool redact_first,bool allow_sensitive,std::string& error) const;
    [[nodiscard]] std::string report(std::size_t limit=40) const;
    [[nodiscard]] static std::optional<ClipboardEntryType> parse_type(std::string_view name); [[nodiscard]] static std::string type_name(ClipboardEntryType type);
private:
    bool persist(std::string& error) const; bool load(std::string& error);
    std::filesystem::path path_; std::deque<TypedClipboardEntry> entries_; std::uint64_t next_id_=1; std::size_t capacity_=512;
};

struct WorkspacePaneConstraint {
    std::string id,group; int min_width=24,min_height=5,preferred_width=60,preferred_height=12,priority=50,collapse_priority=50; bool required=false;
};
struct WorkspacePanePlacement { std::string id; int left=1,top=1,width=1,height=1; bool visible=true; double satisfaction=1.0; };
struct WorkspaceLayoutSolution { int columns=0,rows=0,column_count=1; double objective=0.0; std::vector<WorkspacePanePlacement> placements; std::vector<std::string> compromises; };
class AutomaticWorkspaceLayoutConstraintSolver {
public:
    bool upsert(WorkspacePaneConstraint constraint,std::string& error); bool erase(std::string_view id); void clear();
    [[nodiscard]] WorkspaceLayoutSolution solve(int columns,int rows,std::string_view goal={}) const;
    [[nodiscard]] std::string explain(const WorkspaceLayoutSolution& solution) const; [[nodiscard]] std::string report() const;
    [[nodiscard]] std::vector<WorkspacePaneConstraint> constraints() const;
private: std::map<std::string,WorkspacePaneConstraint> constraints_;
};

enum class AccessibilitySeverity : unsigned char { info,warning,error };
struct AccessibilityControl { std::string id,role,label; bool keyboard_reachable=true,focus_visible=true,mouse_action=false,text_label=true; };
struct AccessibilityAuditFinding { AccessibilitySeverity severity=AccessibilitySeverity::info; std::string rule,subject,detail; };
struct AccessibilityAuditResult { std::size_t controls=0; std::vector<AccessibilityAuditFinding> findings; [[nodiscard]] bool pass() const; };
class InteractiveAccessibilityAuditor {
public:
    void set_minimum_contrast(double ratio) noexcept { minimum_contrast_=ratio; }
    [[nodiscard]] AccessibilityAuditResult audit(std::string_view frame,const std::vector<AccessibilityControl>& controls,bool color_enabled,bool unicode_enabled,double refresh_hz) const;
    [[nodiscard]] std::string report(const AccessibilityAuditResult& result) const;
private: double minimum_contrast_=4.5;
};

enum class InteractionStage : unsigned char { input_received,decoded,keybinding,semantic_analysis,command_dispatch,backend_complete,state_update,layout,render,ansi_diff,terminal_write };
struct InteractionLatencySample {
    std::uint64_t id=0,started_ns=0,completed_ns=0,bytes=0; std::string label;
    std::map<InteractionStage,std::uint64_t> stage_ns;
    [[nodiscard]] double total_ms() const noexcept;
};
class EndToEndInteractionLatencyProfiler {
public:
    void enable(bool value=true) noexcept { enabled_=value; } [[nodiscard]] bool enabled() const noexcept { return enabled_; }
    std::uint64_t begin(std::string label={}); void mark(InteractionStage stage); void complete(std::size_t bytes=0); void clear();
    [[nodiscard]] std::vector<InteractionLatencySample> samples(std::size_t limit=200) const; [[nodiscard]] std::optional<InteractionLatencySample> sample(std::uint64_t id) const;
    [[nodiscard]] std::map<std::string,double> percentiles() const; [[nodiscard]] std::string trace(std::uint64_t id) const; [[nodiscard]] std::string report() const;
private: bool enabled_=false; std::uint64_t next_id_=1; std::optional<InteractionLatencySample> active_; std::deque<InteractionLatencySample> samples_; std::size_t capacity_=2048;
};

struct TuiStateSnapshot { std::uint64_t id=0,timestamp_ms=0; std::string name; std::map<std::string,std::string> values; };
struct TuiStateDifference { std::string key,before,after; };
class InternalTuiStateInspector {
public:
    std::uint64_t capture(std::string name,std::map<std::string,std::string> values); bool erase(std::uint64_t id); void clear();
    [[nodiscard]] std::optional<TuiStateSnapshot> get(std::uint64_t id) const; [[nodiscard]] std::vector<TuiStateSnapshot> snapshots() const;
    [[nodiscard]] std::vector<TuiStateDifference> diff(std::uint64_t before,std::uint64_t after,std::string& error) const;
    [[nodiscard]] std::string render(std::uint64_t id,std::string_view prefix={},std::string* error=nullptr) const; [[nodiscard]] std::string report() const;
private: std::map<std::uint64_t,TuiStateSnapshot> snapshots_; std::uint64_t next_id_=1;
};

struct PluginUpgradeAuditRecord { std::uint64_t id=0,timestamp_ms=0; std::string action,target,from_version,to_version,detail; bool success=false; };
class StatePreservingPluginUpgradeRollbackWorkbench {
public:
    std::uint64_t record(std::string action,std::string target,std::string from_version,std::string to_version,bool success,std::string detail);
    [[nodiscard]] std::vector<PluginUpgradeAuditRecord> audit(std::size_t limit=100) const; [[nodiscard]] std::string report() const; void clear();
private: std::uint64_t next_id_=1; std::deque<PluginUpgradeAuditRecord> audit_; std::size_t capacity_=512;
};

} // namespace sim::console::terminalws

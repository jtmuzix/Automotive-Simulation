#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace aesim::core {

struct ScheduledTaskConfig {
    std::string name;
    double period_s = 0.001;
    int priority = 0;
    bool enabled = true;
};

struct ScheduledTaskStats {
    std::string name;
    std::uint64_t executions = 0;
    std::int64_t period_ns = 0;
    std::int64_t next_due_ns = 0;
    std::int64_t last_run_ns = -1;
    int priority = 0;
    bool enabled = true;
};

struct KernelStats {
    std::int64_t time_ns = 0;
    std::uint64_t advance_calls = 0;
    std::uint64_t callback_count = 0;
    std::uint64_t coincident_dispatches = 0;
    std::vector<ScheduledTaskStats> tasks;
};

class DeterministicMultiRateKernel {
public:
    using Callback = std::function<void(double scheduled_time_s, double elapsed_s)>;

    std::size_t add_task(const ScheduledTaskConfig& config, Callback callback);
    void remove_all_tasks();
    void reset(double start_time_s = 0.0, bool execute_at_start = true);
    void advance(double dt_s);

    void set_task_period(std::size_t task_id, double period_s);
    void set_task_enabled(std::size_t task_id, bool enabled);
    [[nodiscard]] ScheduledTaskStats task_stats(std::size_t task_id) const;
    [[nodiscard]] KernelStats stats() const;
    // Reuse caller-owned storage for high-frequency telemetry paths.  This is
    // allocation-free after the destination has reached the task count.
    void stats_into(KernelStats& out) const;
    void restore_stats(const KernelStats& stats);
    [[nodiscard]] double time_s() const noexcept;

    static std::int64_t seconds_to_nanoseconds(double seconds);
    static double nanoseconds_to_seconds(std::int64_t nanoseconds) noexcept;

private:
    struct Task {
        ScheduledTaskConfig config;
        Callback callback;
        std::int64_t period_ns = 1;
        std::int64_t next_due_ns = 0;
        std::int64_t last_run_ns = -1;
        std::uint64_t executions = 0;
        std::size_t registration_order = 0;
    };

    std::vector<Task> tasks_;
    // Task priority and registration order are static between registration or
    // checkpoint restore, so cache deterministic dispatch order rather than
    // allocating/sorting a due list at every scheduler event.
    std::vector<std::size_t> execution_order_;
    std::int64_t time_ns_ = 0;
    std::uint64_t advance_calls_ = 0;
    std::uint64_t callback_count_ = 0;
    std::uint64_t coincident_dispatches_ = 0;
    bool execute_at_start_ = true;

    static std::int64_t checked_period_ns(double period_s);
    void rebuild_execution_order();
};

}  // namespace aesim::core

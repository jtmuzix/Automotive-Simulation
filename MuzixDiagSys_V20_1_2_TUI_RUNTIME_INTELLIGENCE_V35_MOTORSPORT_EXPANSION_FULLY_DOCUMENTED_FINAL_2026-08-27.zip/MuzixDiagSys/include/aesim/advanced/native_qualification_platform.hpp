#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::nativequal {

// ---------------------------------------------------------------------------
// 1. Sanitizer qualification matrix and failure workbench
// ---------------------------------------------------------------------------

enum class ToolchainFamily { Gcc, Clang, Msvc, Unknown };
enum class SanitizerKind {
    Address,
    UndefinedBehavior,
    Thread,
    Leak,
    Memory,
    Integer,
    LibstdcxxDebug,
    LibstdcxxAssertions
};
enum class FindingSeverity { Note = 0, Warning = 1, Error = 2, Critical = 3 };

struct SanitizerProfile {
    std::string id;
    std::string target;
    ToolchainFamily toolchain = ToolchainFamily::Unknown;
    std::string build_type = "Debug";
    std::vector<SanitizerKind> sanitizers;
    std::vector<std::string> extra_flags;
};

struct SanitizerFinding {
    SanitizerKind sanitizer = SanitizerKind::UndefinedBehavior;
    FindingSeverity severity = FindingSeverity::Error;
    std::string summary;
    std::string file;
    std::size_t line = 0;
    std::vector<std::string> normalized_stack;
    std::string fingerprint;
    bool baseline = false;
    bool suppressed = false;
};

struct SanitizerMatrixPlan {
    std::vector<SanitizerProfile> profiles;
    std::vector<std::string> rejected_combinations;
};

struct SanitizerGateReport {
    std::vector<SanitizerFinding> findings;
    std::size_t new_findings = 0;
    std::size_t baseline_findings = 0;
    std::size_t suppressed_findings = 0;
    bool pass = true;
};

class SanitizerQualificationWorkbench {
public:
    [[nodiscard]] SanitizerMatrixPlan plan(const std::vector<std::string>& targets,
                                           const std::vector<ToolchainFamily>& toolchains,
                                           const std::vector<std::vector<SanitizerKind>>& combinations) const;
    [[nodiscard]] bool compatible(const SanitizerProfile& profile, std::string* reason = nullptr) const;
    [[nodiscard]] std::vector<std::string> compile_flags(const SanitizerProfile& profile) const;
    [[nodiscard]] std::vector<SanitizerFinding> parse_diagnostics(const std::string& text) const;
    void set_baseline(std::set<std::string> fingerprints);
    void set_suppressions(std::set<std::string> fingerprints);
    [[nodiscard]] SanitizerGateReport gate(const std::vector<SanitizerFinding>& findings,
                                           FindingSeverity minimum = FindingSeverity::Error) const;
    void save_baseline(const std::string& path) const;
    void load_baseline(const std::string& path);

private:
    std::set<std::string> baseline_;
    std::set<std::string> suppressions_;
};

// ---------------------------------------------------------------------------
// 2. Combinatorial build/configuration interaction explorer
// ---------------------------------------------------------------------------

using ConfigurationAssignment = std::map<std::string, std::string>;

struct ConfigurationDimension {
    std::string name;
    std::vector<std::string> values;
};

struct ConfigurationRule {
    ConfigurationAssignment when;
    ConfigurationAssignment require;
    ConfigurationAssignment forbid;
    std::string rationale;
};

struct RiskInteraction {
    ConfigurationAssignment assignment;
    double weight = 1.0;
};

struct ConfigurationExplorerConfig {
    std::size_t interaction_strength = 2;
    std::size_t max_exhaustive_configurations = 100000;
    std::size_t max_selected_configurations = 1000;
};

struct InteractionCoverageReport {
    std::size_t valid_configurations = 0;
    std::size_t selected_configurations = 0;
    std::size_t total_interactions = 0;
    std::size_t covered_interactions = 0;
    double interaction_coverage_percent = 100.0;
    double weighted_coverage_percent = 100.0;
    std::vector<ConfigurationAssignment> uncovered_interactions;
    bool exhaustive_space_enumerated = true;
};

struct ConfigurationSelection {
    std::vector<ConfigurationAssignment> configurations;
    InteractionCoverageReport coverage;
};

class CombinatorialConfigurationExplorer {
public:
    [[nodiscard]] bool valid(const ConfigurationAssignment& assignment,
                             const std::vector<ConfigurationRule>& rules,
                             std::string* reason = nullptr) const;
    [[nodiscard]] std::vector<ConfigurationAssignment> enumerate_valid(
        const std::vector<ConfigurationDimension>& dimensions,
        const std::vector<ConfigurationRule>& rules,
        std::size_t limit = 100000) const;
    [[nodiscard]] ConfigurationSelection generate_covering_array(
        const std::vector<ConfigurationDimension>& dimensions,
        const std::vector<ConfigurationRule>& rules,
        const std::vector<RiskInteraction>& risks,
        const ConfigurationExplorerConfig& config = {}) const;
    [[nodiscard]] InteractionCoverageReport analyze(
        const std::vector<ConfigurationDimension>& dimensions,
        const std::vector<ConfigurationRule>& rules,
        const std::vector<RiskInteraction>& risks,
        const std::vector<ConfigurationAssignment>& selected,
        std::size_t strength) const;
};

// ---------------------------------------------------------------------------
// 3. Build reproducibility forensics workbench
// ---------------------------------------------------------------------------

struct BinarySectionDigest {
    std::string name;
    std::uint64_t size = 0;
    std::string sha256;
};

struct ArchiveMemberInfo {
    std::string name;
    std::uint64_t size = 0;
};

struct BuildArtifactDescriptor {
    std::string path;
    std::map<std::string, std::string> metadata;
};

struct ReproducibilityDifference {
    std::string category;
    std::string name;
    std::string left;
    std::string right;
    std::string diagnostic;
};

struct BuildReproducibilityReport {
    std::string left_sha256;
    std::string right_sha256;
    bool bit_identical = false;
    bool archive_member_order_identical = true;
    std::vector<BinarySectionDigest> left_sections;
    std::vector<BinarySectionDigest> right_sections;
    std::vector<ReproducibilityDifference> differences;
    std::vector<std::string> probable_causes;
    std::vector<std::string> remediation;
};

class BuildReproducibilityForensicsWorkbench {
public:
    [[nodiscard]] std::vector<BinarySectionDigest> inspect_sections(const std::string& path) const;
    [[nodiscard]] std::vector<ArchiveMemberInfo> inspect_archive(const std::string& path) const;
    [[nodiscard]] std::vector<std::string> embedded_absolute_paths(const std::string& path) const;
    [[nodiscard]] BuildReproducibilityReport compare(const BuildArtifactDescriptor& left,
                                                      const BuildArtifactDescriptor& right) const;
};

// ---------------------------------------------------------------------------
// 4. Binary size / link-map / symbol-bloat regression analyzer
// ---------------------------------------------------------------------------

struct BinarySymbolSize {
    std::string name;
    std::uint64_t address = 0;
    std::uint64_t size = 0;
    char type = '?';
    std::string object;
};

struct BinarySizeReport {
    std::string path;
    std::uint64_t file_size = 0;
    std::map<std::string, std::uint64_t> section_sizes;
    std::vector<BinarySymbolSize> symbols;
    std::map<std::string, std::uint64_t> object_contributions;
    std::uint64_t total_symbol_bytes = 0;
    std::uint64_t template_symbol_bytes = 0;
    std::uint64_t rtti_bytes = 0;
    std::uint64_t vtable_bytes = 0;
    std::uint64_t static_initializer_bytes = 0;
};

struct BinarySizeBudget {
    std::int64_t max_total_growth_bytes = 0;
    std::map<std::string, std::int64_t> max_section_growth_bytes;
    std::int64_t max_single_symbol_growth_bytes = 0;
};

struct SymbolGrowth {
    std::string name;
    std::int64_t growth_bytes = 0;
    std::uint64_t baseline_bytes = 0;
    std::uint64_t candidate_bytes = 0;
};

struct BinarySizeRegressionReport {
    std::int64_t total_growth_bytes = 0;
    std::map<std::string, std::int64_t> section_growth_bytes;
    std::vector<SymbolGrowth> largest_symbol_growth;
    std::vector<std::string> violations;
    bool pass = true;
};

class BinarySizeRegressionAnalyzer {
public:
    [[nodiscard]] BinarySizeReport analyze(const std::string& path,
                                           const std::string& nm_size_output = {},
                                           const std::string& link_map_text = {}) const;
    [[nodiscard]] std::vector<BinarySymbolSize> parse_nm_size(const std::string& text) const;
    [[nodiscard]] std::map<std::string, std::uint64_t> parse_link_map(const std::string& text) const;
    [[nodiscard]] BinarySizeRegressionReport compare(const BinarySizeReport& baseline,
                                                     const BinarySizeReport& candidate,
                                                     const BinarySizeBudget& budget) const;
};

// ---------------------------------------------------------------------------
// 5. Stochastic stream registry and seed-lineage ledger
// ---------------------------------------------------------------------------

enum class RngAlgorithm { SplitMix64V1 };

struct StochasticStreamInfo {
    std::string name;
    std::string parent;
    std::uint64_t seed = 0;
    std::uint64_t samples = 0;
    RngAlgorithm algorithm = RngAlgorithm::SplitMix64V1;
    std::string state_digest;
    [[nodiscard]] bool operator==(const StochasticStreamInfo& other) const noexcept {
        return name == other.name && parent == other.parent && seed == other.seed && samples == other.samples &&
               algorithm == other.algorithm && state_digest == other.state_digest;
    }
    [[nodiscard]] bool operator!=(const StochasticStreamInfo& other) const noexcept { return !(*this == other); }
};

struct StochasticLedgerAudit {
    bool unique_seeds = true;
    bool valid_parentage = true;
    std::vector<std::string> seed_collisions;
    std::vector<std::string> unexpected_consumers;
    bool pass = true;
};

class StochasticStreamRegistry {
public:
    explicit StochasticStreamRegistry(std::uint64_t root_seed = 0);
    [[nodiscard]] std::uint64_t root_seed() const noexcept;
    [[nodiscard]] StochasticStreamInfo create_stream(const std::string& name,
                                                     const std::string& parent = {});
    [[nodiscard]] std::uint64_t next_u64(const std::string& name);
    [[nodiscard]] double uniform01(const std::string& name);
    [[nodiscard]] double normal01(const std::string& name);
    [[nodiscard]] std::map<std::string, StochasticStreamInfo> snapshot() const;
    [[nodiscard]] StochasticLedgerAudit audit() const;
    [[nodiscard]] StochasticLedgerAudit audit_consumption(
        const std::map<std::string, StochasticStreamInfo>& before,
        const std::map<std::string, StochasticStreamInfo>& after,
        const std::set<std::string>& expected_consumers) const;
    void save(const std::string& path) const;
    void load(const std::string& path);

private:
    struct State {
        StochasticStreamInfo info;
        std::uint64_t state = 0;
    };
    std::uint64_t root_seed_ = 0;
    std::map<std::string, State> streams_;
};

// ---------------------------------------------------------------------------
// 6. Host resource lifetime and ownership auditor
// ---------------------------------------------------------------------------

enum class HostResourceKind {
    FileDescriptor,
    Socket,
    Pipe,
    Thread,
    ChildProcess,
    MemoryMap,
    SharedMemory,
    Mutex,
    TemporaryPath,
    GpuContext,
    GpuStream,
    GpuEvent,
    PluginHandle,
    DynamicLibrary,
    IpcObject,
    Other
};

struct HostResourceRecord {
    std::uint64_t token = 0;
    HostResourceKind kind = HostResourceKind::Other;
    std::string native_id;
    std::string owner;
    std::string creation_site;
    std::map<std::string, std::string> metadata;
    std::uint64_t acquisition_sequence = 0;
};

struct HostResourceSnapshot {
    std::uint64_t sequence = 0;
    std::map<std::uint64_t, HostResourceRecord> tracked;
    std::size_t observed_file_descriptors = 0;
    std::size_t observed_sockets = 0;
    std::size_t observed_threads = 0;
    std::size_t observed_memory_maps = 0;
};

struct HostResourceLeak {
    HostResourceRecord resource;
    std::string reason;
};

struct HostResourceDiff {
    std::vector<HostResourceLeak> newly_live;
    std::vector<HostResourceRecord> released;
    std::int64_t file_descriptor_delta = 0;
    std::int64_t socket_delta = 0;
    std::int64_t thread_delta = 0;
    std::int64_t memory_map_delta = 0;
    bool leak_free = true;
};

class HostResourceLifetimeAuditor {
public:
    std::uint64_t acquire(HostResourceKind kind, const std::string& native_id,
                          const std::string& owner, const std::string& creation_site,
                          std::map<std::string, std::string> metadata = {});
    bool release(std::uint64_t token);
    [[nodiscard]] HostResourceSnapshot snapshot() const;
    [[nodiscard]] HostResourceDiff diff(const HostResourceSnapshot& before,
                                        const HostResourceSnapshot& after) const;
    [[nodiscard]] std::vector<HostResourceRecord> live_resources() const;

private:
    mutable std::mutex mutex_;
    std::uint64_t next_token_ = 1;
    std::uint64_t sequence_ = 0;
    std::map<std::uint64_t, HostResourceRecord> live_;
};

// ---------------------------------------------------------------------------
// 7. Process lifecycle / signal-chaos qualification laboratory
// ---------------------------------------------------------------------------

enum class LifecycleSignal { Interrupt, Terminate, Hangup, Quit, Kill };

struct LifecycleCase {
    std::string name;
    LifecycleSignal signal = LifecycleSignal::Terminate;
    std::uint64_t signal_delay_ms = 50;
    std::uint64_t graceful_timeout_ms = 1000;
    std::uint64_t force_kill_timeout_ms = 1000;
};

struct LifecycleCaseResult {
    std::string name;
    bool launched = false;
    bool signal_delivered = false;
    bool reaped = false;
    bool process_group_gone = false;
    bool timed_out = false;
    int exit_code = -1;
    int termination_signal = 0;
    std::uint64_t duration_ms = 0;
    bool pass = false;
    std::string diagnostic;
};

struct LifecycleQualificationReport {
    std::vector<LifecycleCaseResult> cases;
    std::size_t passed = 0;
    bool pass = true;
};

class ProcessLifecycleChaosLab {
public:
    [[nodiscard]] std::vector<LifecycleSignal> supported_signals() const;
    [[nodiscard]] LifecycleCaseResult run_case(const std::string& command,
                                               const LifecycleCase& test_case) const;
    [[nodiscard]] LifecycleQualificationReport run(const std::string& command,
                                                   const std::vector<LifecycleCase>& cases) const;
};

// ---------------------------------------------------------------------------
// 8. Static-analysis orchestration and technical-debt gate
// ---------------------------------------------------------------------------

enum class StaticAnalysisTool {
    ClangTidy,
    GccAnalyzer,
    Cppcheck,
    ClangAnalyzer,
    Compiler,
    CodeQL,
    Sarif,
    Generic
};

struct StaticAnalysisFinding {
    StaticAnalysisTool tool = StaticAnalysisTool::Generic;
    FindingSeverity severity = FindingSeverity::Warning;
    std::string rule;
    std::string message;
    std::string file;
    std::size_t line = 0;
    std::size_t column = 0;
    std::string symbol;
    std::string owner;
    std::string fingerprint;
    bool baseline = false;
    bool suppressed = false;
};

struct StaticAnalysisGateConfig {
    FindingSeverity minimum_severity = FindingSeverity::Warning;
    bool fail_on_new_findings = true;
    std::set<std::string> suppressed_fingerprints;
    std::set<std::string> suppressed_rules;
    std::map<std::string, std::string> owner_by_path_prefix;
};

struct StaticAnalysisReport {
    std::vector<StaticAnalysisFinding> findings;
    std::size_t new_findings = 0;
    std::size_t baseline_findings = 0;
    std::size_t suppressed_findings = 0;
    std::map<std::string, std::size_t> new_findings_by_owner;
    bool pass = true;
};

class StaticAnalysisOrchestrator {
public:
    [[nodiscard]] std::vector<StaticAnalysisFinding> parse_text(StaticAnalysisTool tool,
                                                                const std::string& text) const;
    [[nodiscard]] std::vector<StaticAnalysisFinding> parse_sarif(const std::string& json_text) const;
    [[nodiscard]] std::vector<std::string> commands(const std::vector<std::string>& source_files,
                                                    const std::string& compile_commands_directory = {}) const;
    void set_baseline(std::set<std::string> fingerprints);
    [[nodiscard]] StaticAnalysisReport gate(std::vector<StaticAnalysisFinding> findings,
                                            const StaticAnalysisGateConfig& config = {}) const;
    [[nodiscard]] std::string export_sarif(const std::vector<StaticAnalysisFinding>& findings) const;
    void save_baseline(const std::string& path) const;
    void load_baseline(const std::string& path);

private:
    std::set<std::string> baseline_;
};

// ---------------------------------------------------------------------------
// 9. Spectrum-based regression fault localizer
// ---------------------------------------------------------------------------

enum class FaultLocalizationMetric { Ochiai, Tarantula, DStar, Jaccard };

struct FaultElement {
    std::string id;
    std::string file;
    std::size_t line = 0;
    std::string function;
    bool changed = false;
    double recent_change_weight = 0.0;
    double historical_defect_density = 0.0;
    std::size_t call_graph_distance = 0;
};

struct TestSpectrum {
    std::string test_id;
    bool passed = true;
    std::set<std::string> covered_elements;
};

struct LocalizedFault {
    FaultElement element;
    std::size_t failing_cover = 0;
    std::size_t passing_cover = 0;
    double spectrum_score = 0.0;
    double combined_score = 0.0;
};

struct FaultLocalizationReport {
    FaultLocalizationMetric metric = FaultLocalizationMetric::Ochiai;
    std::size_t failing_tests = 0;
    std::size_t passing_tests = 0;
    std::vector<LocalizedFault> ranking;
};

class SpectrumRegressionFaultLocalizer {
public:
    [[nodiscard]] FaultLocalizationReport localize(const std::vector<TestSpectrum>& spectra,
                                                   const std::vector<FaultElement>& elements,
                                                   FaultLocalizationMetric metric = FaultLocalizationMetric::Ochiai) const;
    [[nodiscard]] static double suspiciousness(FaultLocalizationMetric metric,
                                               std::size_t failing_cover,
                                               std::size_t passing_cover,
                                               std::size_t total_failing,
                                               std::size_t total_passing);
};

// ---------------------------------------------------------------------------
// 10. Cross-compiler / cross-optimization differential qualification
// ---------------------------------------------------------------------------

struct CompilerQualificationProfile {
    std::string id;
    ToolchainFamily toolchain = ToolchainFamily::Unknown;
    std::string compiler;
    std::string optimization;
    std::string standard_library;
    std::string isa;
    bool fast_math = false;
    bool fma = true;
    std::vector<std::string> flags;
};

struct DifferentialObservation {
    std::string profile_id;
    std::string state_hash;
    std::map<std::string, double> metrics;
    std::vector<std::string> event_sequence;
    std::string exception_type;
    int exit_code = 0;
};

struct DifferentialTolerance {
    std::map<std::string, double> absolute;
    std::map<std::string, double> relative;
    std::map<std::string, std::uint64_t> max_ulp;
    bool require_state_hash_match = true;
    bool require_event_order_match = true;
    bool require_exception_match = true;
    bool require_exit_code_match = true;
};

struct DifferentialProfileResult {
    std::string profile_id;
    bool state_hash_match = true;
    bool event_order_match = true;
    bool exception_match = true;
    bool exit_code_match = true;
    std::map<std::string, double> absolute_differences;
    std::map<std::string, double> relative_differences;
    std::map<std::string, std::uint64_t> ulp_differences;
    std::vector<std::string> violations;
    bool pass = true;
};

struct DifferentialQualificationReport {
    std::string baseline_profile;
    std::vector<DifferentialObservation> observations;
    std::vector<DifferentialProfileResult> comparisons;
    bool pass = true;
};

class CrossCompilerOptimizationDifferentialQualification {
public:
    [[nodiscard]] std::vector<CompilerQualificationProfile> default_matrix() const;
    [[nodiscard]] DifferentialQualificationReport run(
        const std::vector<CompilerQualificationProfile>& profiles,
        const std::function<DifferentialObservation(const CompilerQualificationProfile&)>& executor,
        const DifferentialTolerance& tolerance = {}) const;
    [[nodiscard]] DifferentialQualificationReport compare(
        const std::vector<DifferentialObservation>& observations,
        const DifferentialTolerance& tolerance = {}) const;
    [[nodiscard]] static std::uint64_t ulp_distance(double a, double b);
};

// Unified external qualification surface.
class NativeQualificationPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

}  // namespace aesim::advanced::nativequal

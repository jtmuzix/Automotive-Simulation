#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::genops {

// ---------------------------------------------------------------------------
// 1. Systematic concurrency interleaving explorer
// ---------------------------------------------------------------------------

enum class ConcurrentActionKind { Read, Write, Lock, Unlock, AssertEqual, Yield };

struct ConcurrentAction {
    std::string label;
    ConcurrentActionKind kind = ConcurrentActionKind::Yield;
    std::string resource;
    std::int64_t value = 0;
};

struct ConcurrentThread {
    std::string id;
    std::vector<ConcurrentAction> actions;
};

struct InterleavingConfig {
    std::size_t max_schedules = 10000;
    std::size_t max_steps = 100000;
    std::size_t max_preemptions = 8;
    bool stop_after_first_failure = false;
};

struct RaceWitness {
    std::string resource;
    std::string first_thread;
    std::string second_thread;
    std::string first_action;
    std::string second_action;
};

struct InterleavingReport {
    std::size_t explored_schedules = 0;
    std::size_t pruned_equivalent_choices = 0;
    std::size_t deadlocks = 0;
    std::size_t assertion_failures = 0;
    std::size_t schedules_with_races = 0;
    std::vector<RaceWitness> race_witnesses;
    std::vector<std::string> first_failing_schedule;
    std::vector<std::string> minimized_failing_prefix;
    std::string first_failing_schedule_sha256;
    std::string minimized_failing_prefix_sha256;
    bool exhaustive_within_bounds = true;
};

struct ScheduleReplayResult {
    std::size_t consumed_steps = 0;
    bool completed = false;
    bool deadlocked = false;
    bool assertion_failed = false;
    std::map<std::string, std::int64_t> final_state;
    std::vector<RaceWitness> races;
};

class SystematicInterleavingExplorer {
public:
    InterleavingReport explore(const std::vector<ConcurrentThread>& threads,
                               const std::map<std::string, std::int64_t>& initial_state,
                               const InterleavingConfig& config = {}) const;
    ScheduleReplayResult replay(const std::vector<ConcurrentThread>& threads,
                                const std::map<std::string, std::int64_t>& initial_state,
                                const std::vector<std::string>& schedule) const;
};

// ---------------------------------------------------------------------------
// 2. Hermetic external-I/O record/replay sandbox
// ---------------------------------------------------------------------------

enum class HermeticIoKind { Environment, FileRead, Clock, Subprocess, Dns, TcpExchange, TemporaryPath, Custom };
enum class HermeticIoMode { Record, Replay };

struct HermeticIoRequest {
    HermeticIoKind kind = HermeticIoKind::Custom;
    std::string key;
    std::string payload;
};

struct HermeticIoRecord {
    HermeticIoRequest request;
    std::string response;
    int status = 0;
    std::string response_sha256;
    std::string record_sha256;
};

class HermeticIoSandbox {
public:
    explicit HermeticIoSandbox(HermeticIoMode mode = HermeticIoMode::Record);

    void set_mode(HermeticIoMode mode);
    [[nodiscard]] HermeticIoMode mode() const noexcept;
    void clear();
    void rewind();

    HermeticIoRecord invoke(const HermeticIoRequest& request,
                            const std::function<std::pair<int, std::string>()>& live_operation);
    [[nodiscard]] std::string environment(const std::string& name);
    [[nodiscard]] std::string read_file(const std::string& path);
    [[nodiscard]] std::uint64_t wall_clock_ns();
    [[nodiscard]] std::string run_command(const std::string& command);
    [[nodiscard]] std::vector<std::string> resolve_host(const std::string& host);
    [[nodiscard]] std::string tcp_exchange(const std::string& host, std::uint16_t port,
                                           const std::string& request);
    [[nodiscard]] std::string temporary_path(const std::string& prefix = "muzixdiagsys");

    void save(const std::string& path) const;
    void load(const std::string& path);
    [[nodiscard]] bool replay_complete() const noexcept;
    [[nodiscard]] const std::vector<HermeticIoRecord>& records() const noexcept;

private:
    HermeticIoMode mode_ = HermeticIoMode::Record;
    std::vector<HermeticIoRecord> records_;
    std::size_t replay_index_ = 0;
};

// ---------------------------------------------------------------------------
// 3. Persistence crash-consistency and storage-fault laboratory
// ---------------------------------------------------------------------------

enum class StorageFault {
    None,
    ShortWrite,
    NoSpace,
    IoError,
    PermissionDenied,
    StaleTransactionDebris,
    RenameFailure,
    SyncFailure,
    CrashAfterTempWrite,
    CrashAfterJournal,
    CrashAfterRename
};

struct CrashCaseResult {
    StorageFault fault = StorageFault::None;
    bool operation_reported_success = false;
    bool recovered = false;
    bool atomicity_preserved = false;
    bool retained_old_value = false;
    bool committed_new_value = false;
    bool debris_free = false;
    std::string diagnostic;
};

struct CrashMatrixReport {
    std::vector<CrashCaseResult> cases;
    std::size_t passed = 0;
    bool pass = false;
};

class CrashConsistencyLab {
public:
    CrashCaseResult atomic_replace(const std::string& path,
                                   const std::string& replacement,
                                   StorageFault fault) const;
    CrashMatrixReport run_matrix(const std::string& path,
                                 const std::string& initial,
                                 const std::string& replacement) const;
};

// ---------------------------------------------------------------------------
// 4. Public API / ABI / CLI compatibility governance
// ---------------------------------------------------------------------------

enum class CompatibilitySurface { Api, Abi, Cli, Schema, Configuration };
enum class CompatibilityChangeKind { Added, Removed, Modified };
enum class CompatibilityImpact { PatchCompatible, RequiresMinor, Breaking };

struct CompatibilityEntry {
    CompatibilitySurface surface = CompatibilitySurface::Api;
    std::string name;
    std::string signature;
    bool deprecated = false;
    std::string removal_version;
};

struct CompatibilitySnapshot {
    std::string version;
    std::vector<CompatibilityEntry> entries;
};

struct CompatibilityChange {
    CompatibilityChangeKind kind = CompatibilityChangeKind::Modified;
    CompatibilityImpact impact = CompatibilityImpact::PatchCompatible;
    CompatibilitySurface surface = CompatibilitySurface::Api;
    std::string name;
    std::string before_signature;
    std::string after_signature;
};

struct CompatibilityReport {
    std::vector<CompatibilityChange> changes;
    std::size_t additions = 0;
    std::size_t removals = 0;
    std::size_t modifications = 0;
    CompatibilityImpact required_release = CompatibilityImpact::PatchCompatible;
    bool semantic_version_policy_pass = true;
    bool deprecation_policy_pass = true;
    std::vector<std::string> premature_deprecation_removals;
    std::string policy_diagnostic;
};

class CompatibilityGovernanceCenter {
public:
    CompatibilityReport compare(const CompatibilitySnapshot& baseline,
                                const CompatibilitySnapshot& candidate) const;
    static std::vector<CompatibilityEntry> parse_nm_symbols(const std::string& nm_output);
};

// ---------------------------------------------------------------------------
// 5. Adaptive test execution and flakiness operations manager
// ---------------------------------------------------------------------------

struct TestObservation {
    std::string id;
    double duration_s = 0.0;
    bool passed = true;
    std::uint64_t observed_at_epoch_s = 0;
};

struct TestHistory {
    std::string id;
    std::size_t attempts = 0;
    std::size_t failures = 0;
    double ewma_duration_s = 1.0;
    double failure_probability = 0.0;
    std::uint64_t quarantined_until_epoch_s = 0;
    std::size_t consecutive_passes = 0;
};

struct TestCandidate {
    std::string id;
    bool impacted = false;
    bool release_blocking = false;
    double criticality = 1.0;
    std::size_t memory_mb = 128;
    std::vector<std::string> dependencies;
    std::string owner;
};

struct AdaptiveTestConfig {
    std::size_t workers = 1;
    std::size_t total_retry_budget = 0;
    std::size_t memory_budget_mb = 4096;
    std::uint64_t now_epoch_s = 0;
    double quarantine_failure_probability = 0.35;
    std::size_t quarantine_min_attempts = 5;
    std::uint64_t quarantine_duration_s = 24 * 60 * 60;
};

struct PlannedTest {
    std::string id;
    std::size_t worker = 0;
    double expected_start_s = 0.0;
    double expected_finish_s = 0.0;
    std::size_t retry_budget = 0;
    bool quarantined = false;
    bool skipped_by_quarantine = false;
    bool blocked_by_dependency = false;
    bool release_blocking = false;
    std::string owner;
};

struct AdaptiveTestPlan {
    std::vector<PlannedTest> tests;
    double expected_makespan_s = 0.0;
    std::size_t allocated_retries = 0;
    std::size_t skipped_quarantined = 0;
    std::map<std::string, std::vector<std::string>> flaky_tests_by_owner;
};

class AdaptiveTestManager {
public:
    void observe(const TestObservation& observation, const AdaptiveTestConfig& policy = {});
    [[nodiscard]] AdaptiveTestPlan plan(const std::vector<TestCandidate>& candidates,
                                        const AdaptiveTestConfig& config) const;
    [[nodiscard]] const std::map<std::string, TestHistory>& history() const noexcept;
    void save(const std::string& path) const;
    void load(const std::string& path);

private:
    std::map<std::string, TestHistory> history_;
};

// ---------------------------------------------------------------------------
// 6. Native C++ line/function/branch and changed-line coverage workbench
// ---------------------------------------------------------------------------

struct SourceLine {
    std::string file;
    std::size_t line = 0;
    bool operator<(const SourceLine& other) const noexcept {
        return file < other.file || (file == other.file && line < other.line);
    }
};

struct NativeCoverageReport {
    std::size_t total_lines = 0;
    std::size_t hit_lines = 0;
    std::size_t total_functions = 0;
    std::size_t hit_functions = 0;
    std::size_t total_branches = 0;
    std::size_t hit_branches = 0;
    std::size_t changed_lines = 0;
    std::size_t hit_changed_lines = 0;
    double line_percent = 100.0;
    double function_percent = 100.0;
    double branch_percent = 100.0;
    double changed_line_percent = 100.0;
    std::vector<SourceLine> uncovered_changed_lines;
};

class NativeCoverageWorkbench {
public:
    // LCOV is intentionally the canonical interchange: both gcov/lcov and
    // llvm-cov can emit it, providing one exact ingestion path for GCC and Clang.
    void ingest_lcov(const std::string& test_id, const std::string& lcov_text);
    void set_changed_lines(const std::set<SourceLine>& lines);
    [[nodiscard]] NativeCoverageReport report() const;
    [[nodiscard]] std::vector<std::string> tests_covering(const SourceLine& line) const;
    [[nodiscard]] std::vector<std::string> tests_covering_function(const std::string& file,
                                                                   const std::string& function) const;

private:
    struct Impl;
    std::map<SourceLine, std::uint64_t> line_hits_;
    std::map<SourceLine, std::set<std::string>> line_tests_;
    std::map<std::string, std::uint64_t> function_hits_;
    std::map<std::string, std::set<std::string>> function_tests_;
    std::map<std::string, std::uint64_t> branch_hits_;
    std::set<SourceLine> changed_lines_;
};

// ---------------------------------------------------------------------------
// 7. Translation-unit/header/build-cost profiler
// ---------------------------------------------------------------------------

struct CompileSample {
    std::string translation_unit;
    double duration_s = 0.0;
    std::size_t peak_rss_mb = 0;
    std::uintmax_t object_size_bytes = 0;
    std::vector<std::string> headers;
    std::size_t template_instantiations = 0;
    double template_instantiation_time_s = 0.0;
};

struct TranslationUnitCost {
    std::string translation_unit;
    double mean_duration_s = 0.0;
    double max_duration_s = 0.0;
    std::size_t max_peak_rss_mb = 0;
    std::uintmax_t max_object_size_bytes = 0;
    std::size_t direct_or_transitive_header_count = 0;
    std::size_t max_template_instantiations = 0;
    double mean_template_instantiation_time_s = 0.0;
};

struct HeaderCost {
    std::string header;
    std::size_t translation_unit_fanout = 0;
    double rebuild_duration_s = 0.0;
    std::size_t peak_parallel_rss_mb = 0;
};

struct BuildCostReport {
    std::vector<TranslationUnitCost> translation_units;
    std::vector<HeaderCost> headers;
    double aggregate_compile_seconds = 0.0;
    std::size_t recommended_parallel_compiles = 1;
};

class BuildCostProfiler {
public:
    void record(const CompileSample& sample);
    void ingest_ninja_log(const std::string& ninja_log,
                          const std::map<std::string, std::string>& output_to_translation_unit,
                          const std::map<std::string, std::vector<std::string>>& translation_unit_headers = {});
    void ingest_clang_time_trace(const std::string& translation_unit,
                                 const std::string& json_trace,
                                 std::size_t peak_rss_mb = 0,
                                 std::uintmax_t object_size_bytes = 0,
                                 const std::vector<std::string>& headers = {});
    void ingest_gcc_time_report(const std::string& translation_unit,
                                const std::string& time_report,
                                std::size_t peak_rss_mb = 0,
                                std::uintmax_t object_size_bytes = 0,
                                const std::vector<std::string>& headers = {});
    [[nodiscard]] BuildCostReport analyze(std::size_t memory_budget_mb = 4096) const;
    [[nodiscard]] const std::vector<CompileSample>& samples() const noexcept;

private:
    std::vector<CompileSample> samples_;
};

// ---------------------------------------------------------------------------
// 8. Architecture fitness and dependency-boundary gate
// ---------------------------------------------------------------------------

struct ArchitectureLayer {
    std::string name;
    std::vector<std::string> path_prefixes;
};

struct OwnershipChange {
    std::string file;
    std::string actor;
};

struct ArchitecturePolicy {
    std::vector<ArchitectureLayer> layers;
    std::set<std::pair<std::string, std::string>> allowed_dependencies;
    std::map<std::string, std::string> ownership_by_path_prefix;
    std::vector<OwnershipChange> proposed_changes;
    bool allow_same_layer = true;
    bool fail_on_cycles = true;
};

struct DependencyViolation {
    std::string source_file;
    std::string target_file;
    std::string source_layer;
    std::string target_layer;
    std::string include_token;
};

struct OwnershipViolation {
    std::string file;
    std::string required_owner;
    std::string actual_owner;
};

struct ArchitectureFitnessReport {
    std::size_t scanned_files = 0;
    std::size_t resolved_dependencies = 0;
    std::vector<DependencyViolation> violations;
    std::vector<OwnershipViolation> ownership_violations;
    std::vector<std::vector<std::string>> layer_cycles;
    bool pass = true;
};

class ArchitectureFitnessGate {
public:
    ArchitectureFitnessReport scan(const std::string& project_root,
                                   const ArchitecturePolicy& policy) const;
};

// ---------------------------------------------------------------------------
// 15. Long-run soak/endurance qualification controller
// ---------------------------------------------------------------------------

struct SoakSample {
    std::size_t cycle = 0;
    double elapsed_s = 0.0;
    double rss_mb = 0.0;
    double heap_mb = 0.0;
    double gpu_memory_mb = 0.0;
    std::size_t file_descriptors = 0;
    std::size_t sockets = 0;
    std::size_t threads = 0;
    std::size_t queue_depth = 0;
    double latency_ms = 0.0;
    std::uintmax_t storage_bytes = 0;
    std::uintmax_t checkpoint_bytes = 0;
    double numerical_drift = 0.0;
    std::string state_hash;
};

struct SoakConfig {
    std::size_t cycles = 1000;
    std::size_t sample_every = 1;
    std::size_t warmup_samples = 5;
    double max_rss_mb = 0.0;
    double max_heap_mb = 0.0;
    double max_gpu_memory_mb = 0.0;
    std::size_t max_file_descriptors = 0;
    std::size_t max_sockets = 0;
    std::size_t max_threads = 0;
    std::size_t max_queue_depth = 0;
    double max_latency_p99_ms = 0.0;
    double max_latency_growth_ms_per_1000_cycles = 0.0;
    std::uintmax_t max_storage_bytes = 0;
    std::uintmax_t max_checkpoint_bytes = 0;
    double max_numerical_drift = 0.0;
    double max_rss_growth_mb_per_1000_cycles = 0.0;
    double max_heap_growth_mb_per_1000_cycles = 0.0;
    double max_storage_growth_bytes_per_1000_cycles = 0.0;
    double max_checkpoint_growth_bytes_per_1000_cycles = 0.0;
    std::size_t deterministic_state_period = 0;
};

struct SoakReport {
    std::vector<SoakSample> samples;
    double latency_p50_ms = 0.0;
    double latency_p95_ms = 0.0;
    double latency_p99_ms = 0.0;
    double latency_growth_ms_per_1000_cycles = 0.0;
    double rss_growth_mb_per_1000_cycles = 0.0;
    double heap_growth_mb_per_1000_cycles = 0.0;
    double storage_growth_bytes_per_1000_cycles = 0.0;
    double checkpoint_growth_bytes_per_1000_cycles = 0.0;
    bool deterministic_state_consistent = true;
    std::vector<std::string> violations;
    bool pass = true;
};

class SoakEnduranceController {
public:
    SoakReport run(const SoakConfig& config,
                   const std::function<SoakSample(std::size_t cycle)>& sampler) const;
    SoakReport analyze(std::vector<SoakSample> samples, const SoakConfig& config) const;
};

// ---------------------------------------------------------------------------
// 19. Unified fuzz corpus and failure-triage hub
// ---------------------------------------------------------------------------

struct FuzzCandidate {
    std::vector<std::uint8_t> bytes;
    std::set<std::string> coverage_features;
    std::string failure_signature;
    std::string source;
    std::string subsystem;
    std::uint64_t seed = 0;
};

struct FuzzCorpusEntry {
    std::string sha256;
    std::vector<std::uint8_t> bytes;
    std::set<std::string> coverage_features;
    std::string failure_signature;
    std::string source;
    std::string subsystem;
    std::uint64_t seed = 0;
    std::string coverage_fingerprint;
    bool promoted_seed = false;
};

struct CorpusAddResult {
    bool accepted = false;
    bool duplicate = false;
    bool new_coverage = false;
    bool new_failure = false;
    std::string sha256;
    std::string coverage_fingerprint;
};

class FuzzCorpusHub {
public:
    explicit FuzzCorpusHub(std::string corpus_directory = {});
    CorpusAddResult add(const FuzzCandidate& candidate);
    [[nodiscard]] std::vector<std::string> minimized_corpus() const;
    [[nodiscard]] std::vector<std::uint8_t> minimize_failure(
        const std::vector<std::uint8_t>& input,
        const std::function<bool(const std::vector<std::uint8_t>&)>& still_fails) const;
    void save() const;
    void load();
    void promote_seed(const std::string& sha256);
    void promote_regression(const std::string& sha256,
                            const std::string& regression_directory,
                            const std::string& name) const;
    void write_reproducer(const std::string& sha256,
                          const std::string& reproducer_directory,
                          const std::string& command_template) const;
    [[nodiscard]] std::map<std::string, std::vector<std::string>> failure_clusters() const;
    [[nodiscard]] std::map<std::string, std::vector<std::string>> failures_by_subsystem() const;
    [[nodiscard]] const std::map<std::string, FuzzCorpusEntry>& entries() const noexcept;

private:
    std::string corpus_directory_;
    std::map<std::string, FuzzCorpusEntry> entries_;
    std::set<std::string> global_coverage_;
    std::set<std::string> failure_signatures_;
};

// Unified capabilities and qualification surface for external callers.
class GeneralizedEngineeringOperationsPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory) const;
};

}  // namespace aesim::advanced::genops

#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace aesim::advanced::motorsport {

// ---------------------------------------------------------------------------
// 1. Full WEC / IMSA endurance-racing engineering
// ---------------------------------------------------------------------------

enum class EnduranceClass { Lmh, Lmdh, Gtp, Lmp2, Lmgt3, Gt3 };
enum class DriverRating { Bronze, Silver, Gold, Platinum };
enum class NeutralizationMode { Green, LocalYellow, FullCourseYellow, SafetyCar, SlowZone, RedFlag };
enum class EnduranceTyreCompound { Soft, Medium, Hard, Wet };

struct EnduranceDriver {
    std::string id;
    DriverRating rating = DriverRating::Silver;
    double pace_skill = 0.75;
    double wet_skill = 0.70;
    double traffic_skill = 0.70;
    double fatigue = 0.0;
    double continuous_drive_s = 0.0;
    double event_drive_s = 0.0;
    double rest_s = 0.0;
};

struct EnduranceVehicleSpec {
    std::string id;
    EnduranceClass category = EnduranceClass::Lmdh;
    double minimum_mass_kg = 1030.0;
    double maximum_power_kw = 500.0;
    double fuel_capacity_kg = 90.0;
    double usable_energy_per_stint_mj = 900.0;
    double hybrid_deploy_limit_kw = 200.0;
    double refuel_rate_kg_s = 2.0;
    double base_lap_time_s = 100.0;
    double brake_life_fraction_per_lap = 0.00045;
    double drivetrain_failure_base_per_hour = 0.0005;
};

struct EnduranceRaceState {
    std::string car_id;
    double elapsed_s = 0.0;
    double completed_laps = 0.0;
    double fuel_kg = 0.0;
    double stint_energy_mj = 0.0;
    double tyre_life = 1.0;
    double brake_life = 1.0;
    double damage = 0.0;
    double reliability = 1.0;
    double penalty_s = 0.0;
    double garage_s = 0.0;
    std::size_t driver_index = 0;
    EnduranceTyreCompound tyre = EnduranceTyreCompound::Medium;
    bool retired = false;
};

struct EnduranceStintConditions {
    double duration_s = 3600.0;
    double lap_length_km = 13.626;
    double rain_intensity = 0.0;
    double ambient_temperature_k = 293.15;
    double track_temperature_k = 298.15;
    double traffic_density = 0.5;
    double night_fraction = 0.0;
    double visibility = 1.0;
    NeutralizationMode neutralization = NeutralizationMode::Green;
};

struct EnduranceStintReport {
    EnduranceRaceState state;
    double laps_completed = 0.0;
    double average_lap_s = 0.0;
    double fuel_used_kg = 0.0;
    double energy_used_mj = 0.0;
    double traffic_loss_s = 0.0;
    double neutralization_loss_s = 0.0;
    double driver_fatigue_delta = 0.0;
    double failure_probability = 0.0;
    std::vector<std::string> rule_violations;
};

struct EndurancePitRequest {
    double fuel_add_kg = 0.0;
    bool change_tyres = false;
    EnduranceTyreCompound new_tyre = EnduranceTyreCompound::Medium;
    bool change_driver = false;
    std::size_t next_driver_index = 0;
    double repair_damage_fraction = 0.0;
    double brake_service_fraction = 0.0;
};

struct EndurancePitReport {
    EnduranceRaceState state;
    double stationary_time_s = 0.0;
    double refuel_time_s = 0.0;
    double tyre_time_s = 0.0;
    double driver_change_time_s = 0.0;
    double repair_time_s = 0.0;
    std::vector<std::string> rule_violations;
};

class EnduranceRaceEngineeringPlatform {
public:
    void configure_driver_limits(double max_continuous_drive_s, double max_event_drive_s,
                                 double minimum_rest_s, bool service_concurrency);
    [[nodiscard]] EnduranceStintReport simulate_stint(const EnduranceVehicleSpec& vehicle,
                                                       const std::vector<EnduranceDriver>& drivers,
                                                       const EnduranceRaceState& initial,
                                                       const EnduranceStintConditions& conditions) const;
    [[nodiscard]] EndurancePitReport execute_pit_stop(const EnduranceVehicleSpec& vehicle,
                                                       const std::vector<EnduranceDriver>& drivers,
                                                       const EnduranceRaceState& initial,
                                                       const EndurancePitRequest& request) const;
    [[nodiscard]] std::vector<EnduranceRaceState> classify(std::vector<EnduranceRaceState> states) const;
private:
    double max_continuous_drive_s_ = 4.0 * 3600.0;
    double max_event_drive_s_ = 14.0 * 3600.0;
    double minimum_rest_s_ = 3600.0;
    bool service_concurrency_ = false;
};

// ---------------------------------------------------------------------------
// 2. Advanced Balance-of-Performance engineering laboratory
// ---------------------------------------------------------------------------

struct BopParameters {
    double mass_kg = 1030.0;
    double maximum_power_kw = 500.0;
    double high_speed_power_kw = 500.0;
    double energy_per_stint_mj = 900.0;
    double aero_factor = 1.0;
    double refuel_rate_kg_s = 2.0;
};

struct BopSensitivity {
    double seconds_per_kg = 0.030;
    double seconds_per_kw = -0.018;
    double seconds_per_high_speed_kw = -0.012;
    double seconds_per_mj = -0.0008;
    double seconds_per_aero_fraction = -22.0;
    double seconds_per_refuel_kg_s = -0.25;
};

struct BopObservation {
    std::string manufacturer;
    std::string track;
    double observed_lap_s = 0.0;
    double reference_lap_s = 0.0;
    double driver_skill_offset_s = 0.0;
    double tyre_offset_s = 0.0;
    double weather_offset_s = 0.0;
    double traffic_offset_s = 0.0;
    double track_type_weight = 1.0;
    BopParameters parameters;
    BopSensitivity sensitivity;
};

struct BopManufacturerEstimate {
    std::string manufacturer;
    double latent_performance_s = 0.0;
    double standard_error_s = 0.0;
    double anomaly_score = 0.0;
    bool sandbagging_suspected = false;
};

struct BopAdjustment {
    std::string manufacturer;
    BopParameters before;
    BopParameters after;
    double predicted_delta_s = 0.0;
};

struct BopOptimizationReport {
    std::vector<BopManufacturerEstimate> estimates;
    std::vector<BopAdjustment> adjustments;
    double spread_before_s = 0.0;
    double spread_after_s = 0.0;
    bool target_met = false;
};

class BalanceOfPerformanceLaboratory {
public:
    [[nodiscard]] std::vector<BopManufacturerEstimate> infer_latent_performance(
        const std::vector<BopObservation>& observations, double anomaly_sigma = 2.5) const;
    [[nodiscard]] BopOptimizationReport optimize(const std::vector<BopObservation>& observations,
                                                  const std::map<std::string, BopParameters>& current,
                                                  double target_spread_s,
                                                  double max_mass_change_kg = 15.0,
                                                  double max_power_change_kw = 20.0) const;
    [[nodiscard]] double predict_lap_delta(const BopParameters& from, const BopParameters& to,
                                           const BopSensitivity& sensitivity) const;
};

// ---------------------------------------------------------------------------
// 3. World Rally / stage-rally platform
// ---------------------------------------------------------------------------

enum class RallySurface { Asphalt, Gravel, Mud, Snow, Ice, Mixed };
enum class RallyTyre { Soft, Hard, Gravel, SnowStudded, Wet };

enum class PaceNoteFeature { Corner, Crest, Compression, Junction, Caution, Jump, Water, Narrow, Opens, Tightens };

struct PaceNote {
    double distance_m = 0.0;
    PaceNoteFeature feature = PaceNoteFeature::Corner;
    int severity = 3;
    double confidence = 1.0;
};

struct RallyStageSegment {
    double length_m = 0.0;
    RallySurface surface = RallySurface::Gravel;
    double curvature_1_m = 0.0;
    double gradient = 0.0;
    double roughness = 0.2;
    double water_depth_mm = 0.0;
    double snow_depth_mm = 0.0;
    double road_cleaning_sensitivity = 0.1;
};

struct RallyCrewState {
    std::string crew_id;
    double driver_skill = 0.75;
    double codriver_skill = 0.75;
    double note_trust = 0.85;
    double fatigue = 0.0;
    double vehicle_damage = 0.0;
    double tyre_life = 1.0;
    RallyTyre tyre = RallyTyre::Gravel;
    unsigned punctures = 0;
    double penalty_s = 0.0;
    bool retired = false;
};

struct RallyStageConditions {
    int road_position = 1;
    double rain = 0.0;
    double visibility = 1.0;
    double ambient_temperature_k = 288.15;
    double altitude_m = 0.0;
};

struct RallyStageReport {
    RallyCrewState state;
    double stage_time_s = 0.0;
    double cleaning_loss_s = 0.0;
    double note_loss_s = 0.0;
    double puncture_probability = 0.0;
    double damage_delta = 0.0;
    std::vector<double> segment_times_s;
};

struct RallyServiceRequest {
    double available_s = 2700.0;
    double engine_repair_fraction = 0.0;
    double suspension_repair_fraction = 0.0;
    double body_repair_fraction = 0.0;
    bool replace_tyres = false;
    RallyTyre new_tyre = RallyTyre::Gravel;
};

struct RallyServiceReport {
    RallyCrewState state;
    double used_s = 0.0;
    double overtime_penalty_s = 0.0;
    std::vector<std::string> deferred_repairs;
};

class WorldRallyStagePlatform {
public:
    [[nodiscard]] RallyStageReport run_stage(const std::vector<RallyStageSegment>& route,
                                              const std::vector<PaceNote>& notes,
                                              const RallyCrewState& initial,
                                              const RallyStageConditions& conditions,
                                              std::uint64_t deterministic_seed = 1) const;
    [[nodiscard]] RallyServiceReport service(const RallyCrewState& initial,
                                              const RallyServiceRequest& request) const;
};

// ---------------------------------------------------------------------------
// 4. Formula E full-fidelity competition platform
// ---------------------------------------------------------------------------

struct FormulaEVehicleSpec {
    double usable_energy_kwh = 38.5;
    double maximum_drive_power_kw = 350.0;
    double maximum_regen_power_kw = 600.0;
    double front_regen_fraction = 0.35;
    double battery_thermal_capacity_kj_k = 900.0;
    double base_lap_time_s = 90.0;
};

struct FormulaERaceState {
    double elapsed_s = 0.0;
    double energy_kwh = 38.5;
    double battery_temperature_k = 303.15;
    double brake_temperature_k = 430.0;
    double tyre_life = 1.0;
    int attack_activations_remaining = 2;
    double attack_time_remaining_s = 0.0;
    double penalty_s = 0.0;
    unsigned completed_laps = 0;
};

struct FormulaELapCommand {
    double pace_fraction = 0.92;
    double lift_coast_fraction = 0.08;
    double regen_fraction = 0.75;
    bool activate_attack_mode = false;
    double attack_duration_s = 240.0;
};

struct FormulaELapConditions {
    double lap_length_km = 2.5;
    double traffic_loss_s = 0.0;
    double rain = 0.0;
    double ambient_temperature_k = 298.15;
    bool safety_car = false;
    bool full_course_yellow = false;
};

struct FormulaELapReport {
    FormulaERaceState state;
    double lap_time_s = 0.0;
    double traction_energy_kwh = 0.0;
    double regenerated_energy_kwh = 0.0;
    double friction_brake_fraction = 0.0;
    double thermal_derate = 1.0;
    std::vector<std::string> rule_violations;
};

struct FormulaEAttackPlan {
    std::vector<unsigned> activation_laps;
    double predicted_race_time_s = 0.0;
    double terminal_energy_kwh = 0.0;
    bool feasible = false;
};

struct FormulaEQualifyingEntry { std::string id; double group_lap_s = 0.0; double duel_lap_s = 0.0; };
struct FormulaEQualifyingResult { std::vector<std::string> grid_order; std::vector<std::pair<std::string,std::string>> duel_pairs; };

class FormulaEFullFidelityPlatform {
public:
    [[nodiscard]] FormulaELapReport simulate_lap(const FormulaEVehicleSpec& vehicle,
                                                  const FormulaERaceState& initial,
                                                  const FormulaELapCommand& command,
                                                  const FormulaELapConditions& conditions) const;
    [[nodiscard]] FormulaEAttackPlan optimize_attack_mode(const FormulaEVehicleSpec& vehicle,
                                                           const FormulaERaceState& initial,
                                                           const std::vector<FormulaELapConditions>& laps,
                                                           unsigned activation_count,
                                                           double activation_duration_s) const;
    [[nodiscard]] FormulaEQualifyingResult run_duel_qualifying(std::vector<FormulaEQualifyingEntry> entries) const;
    [[nodiscard]] double safety_car_energy_adjustment_kwh(double neutralized_time_s,
                                                           double reference_race_time_s,
                                                           double nominal_usable_energy_kwh) const;
};

// ---------------------------------------------------------------------------
// 5. Motorsport driver behavioral digital twin
// ---------------------------------------------------------------------------

struct DriverBehaviorTraits {
    double aggressiveness = 0.5;
    double braking_consistency = 0.7;
    double tyre_management = 0.7;
    double wet_skill = 0.7;
    double traffic_tolerance = 0.7;
    double defensive_propensity = 0.5;
    double overtaking_propensity = 0.5;
    double pressure_resilience = 0.7;
    double learning_rate = 0.2;
};

struct DriverLatentState {
    double confidence = 0.7;
    double fatigue = 0.0;
    double frustration = 0.0;
    double risk_appetite = 0.5;
    double tyre_confidence = 0.8;
    double brake_confidence = 0.8;
};

struct DriverTelemetryObservation {
    double braking_error_m = 0.0;
    double minimum_speed_error_mps = 0.0;
    double throttle_error = 0.0;
    double lap_time_error_s = 0.0;
    double tyre_degradation = 0.0;
    double traffic_density = 0.0;
    double rain = 0.0;
    double pressure = 0.0;
    bool contact = false;
    bool successful_overtake = false;
};

struct DriverBehaviorPrediction {
    double pace_offset_s = 0.0;
    double error_probability = 0.0;
    double overtake_attempt_probability = 0.0;
    double defend_probability = 0.0;
    double tyre_saving_fraction = 0.0;
    double braking_variability_m = 0.0;
};

class MotorsportDriverDigitalTwin {
public:
    MotorsportDriverDigitalTwin(DriverBehaviorTraits traits = {}, DriverLatentState initial = {});
    void observe(const DriverTelemetryObservation& observation, double dt_s);
    [[nodiscard]] DriverBehaviorPrediction predict(double race_progress, double championship_pressure,
                                                    double rain, double traffic_density) const;
    [[nodiscard]] const DriverBehaviorTraits& traits() const noexcept { return traits_; }
    [[nodiscard]] const DriverLatentState& state() const noexcept { return state_; }
private:
    DriverBehaviorTraits traits_;
    DriverLatentState state_;
    double braking_variance_ = 4.0;
    double pace_bias_s_ = 0.0;
    std::size_t observations_ = 0;
};

// ---------------------------------------------------------------------------
// 6. Unified spatial track-state field
// ---------------------------------------------------------------------------

struct TrackStateCell {
    double distance_m = 0.0;
    double lane_offset_m = 0.0;
    double rubber = 0.0;
    double marbles = 0.0;
    double water_mm = 0.0;
    double surface_temperature_k = 298.15;
    double oil = 0.0;
    double dust = 0.0;
    double gravel = 0.0;
    double mud = 0.0;
    double snow_mm = 0.0;
    double ice = 0.0;
    double roughness = 0.2;
    double microtexture = 0.7;
    double macrotexture = 0.7;
    double grip = 1.0;
};

struct TrackWeatherStep {
    double rain_mm_h = 0.0;
    double snow_mm_h = 0.0;
    double ambient_temperature_k = 293.15;
    double solar_w_m2 = 0.0;
    double wind_mps = 0.0;
};

struct TrackVehiclePass {
    double distance_m = 0.0;
    double lane_offset_m = 0.0;
    double tyre_load_n = 3500.0;
    double slip_energy_j = 0.0;
    double water_displacement_l = 0.0;
    bool off_track_reentry = false;
};

class SpatialTrackStateField {
public:
    void initialize(double lap_length_m, std::size_t longitudinal_cells,
                    std::size_t lateral_cells, double track_width_m, double initial_grip = 1.0);
    void advance_weather(const TrackWeatherStep& weather, double dt_s);
    void apply_vehicle_pass(const TrackVehiclePass& pass);
    void deposit_debris(double distance_m, double lane_offset_m, double oil, double gravel, double dirt);
    [[nodiscard]] TrackStateCell sample(double distance_m, double lane_offset_m) const;
    [[nodiscard]] const std::vector<TrackStateCell>& cells() const noexcept { return cells_; }
    [[nodiscard]] double lap_length_m() const noexcept { return lap_length_m_; }
private:
    [[nodiscard]] std::size_t nearest_index(double distance_m, double lane_offset_m) const;
    void recompute_grip(TrackStateCell& cell) const;
    double lap_length_m_ = 0.0;
    double track_width_m_ = 0.0;
    std::size_t longitudinal_cells_ = 0;
    std::size_t lateral_cells_ = 0;
    std::vector<TrackStateCell> cells_;
};

// ---------------------------------------------------------------------------
// 7. Racecraft interaction physics engine
// ---------------------------------------------------------------------------

enum class RacecraftAction { HoldLine, AttackInside, AttackOutside, DefendInside, DefendOutside, Yield, Crossover };

struct RacecraftCarState {
    std::string id;
    double s_m = 0.0;
    double lateral_m = 0.0;
    double speed_mps = 0.0;
    double acceleration_mps2 = 0.0;
    double maximum_deceleration_mps2 = 12.0;
    double width_m = 2.0;
    double length_m = 5.0;
    double aero_sensitivity = 0.15;
    double tyre_grip = 1.0;
};

struct RacecraftCorner {
    double entry_s_m = 0.0;
    double apex_s_m = 0.0;
    double exit_s_m = 0.0;
    double radius_m = 80.0;
    double track_width_m = 12.0;
    double grip = 1.0;
};

struct RacecraftAssessment {
    RacecraftAction recommended = RacecraftAction::HoldLine;
    double longitudinal_overlap = 0.0;
    double lateral_clearance_m = 0.0;
    double time_to_collision_s = 1e9;
    double required_deceleration_mps2 = 0.0;
    double braking_feasibility = 1.0;
    double aero_wake_loss_fraction = 0.0;
    double collision_probability = 0.0;
    double expected_time_gain_s = 0.0;
    bool legal_track_envelope = true;
};

class RacecraftInteractionPhysics {
public:
    [[nodiscard]] RacecraftAssessment assess(const RacecraftCarState& ego,
                                               const RacecraftCarState& opponent,
                                               const RacecraftCorner& corner,
                                               RacecraftAction intended) const;
};

// ---------------------------------------------------------------------------
// 8. Hierarchical race-strategy AI
// ---------------------------------------------------------------------------

struct StrategyContext {
    double championship_value_per_point = 1.0;
    double reliability_priority = 0.5;
    double risk_tolerance = 0.5;
    double weather_uncertainty = 0.2;
    double safety_car_probability = 0.15;
    double traffic_density = 0.5;
    double current_track_position = 10.0;
    double points_if_finish = 10.0;
};

struct StrategyOption {
    std::string id;
    std::vector<unsigned> pit_laps;
    std::vector<std::string> stint_compounds;
    double expected_race_time_s = 0.0;
    double time_standard_deviation_s = 0.0;
    double failure_probability = 0.0;
    double expected_points = 0.0;
    double traffic_exposure = 0.0;
    double tyre_risk = 0.0;
    double energy_risk = 0.0;
};

struct StrategyDecision {
    std::string selected_id;
    double championship_utility = 0.0;
    double race_utility = 0.0;
    double stint_utility = 0.0;
    double lap_utility = 0.0;
    double corner_utility = 0.0;
    double total_utility = 0.0;
    std::vector<std::pair<std::string,double>> ranking;
};

class HierarchicalRaceStrategyAI {
public:
    [[nodiscard]] StrategyDecision choose(const StrategyContext& context,
                                           const std::vector<StrategyOption>& options) const;
    [[nodiscard]] double update_opponent_pit_probability(double prior,
                                                          double lap_time_delta_s,
                                                          double tyre_age_fraction,
                                                          bool energy_saving,
                                                          bool pit_window_open) const;
};

// ---------------------------------------------------------------------------
// 9. Lap-time loss attribution and driver coaching
// ---------------------------------------------------------------------------

struct LapTelemetrySample {
    double distance_m = 0.0;
    double time_s = 0.0;
    double speed_mps = 0.0;
    double brake = 0.0;
    double throttle = 0.0;
    double steering_rad = 0.0;
    double lateral_accel_mps2 = 0.0;
    double longitudinal_accel_mps2 = 0.0;
    double tyre_grip = 1.0;
    double energy_fraction = 1.0;
    double traffic_loss_s = 0.0;
    double damage = 0.0;
    double weather_grip = 1.0;
};

struct LapLossComponent {
    std::string category;
    double seconds = 0.0;
};

struct CornerLossReport {
    std::size_t corner_index = 0;
    double start_distance_m = 0.0;
    double end_distance_m = 0.0;
    double total_loss_s = 0.0;
    std::vector<LapLossComponent> components;
    std::string coaching_message;
};

struct LapAttributionReport {
    double total_loss_s = 0.0;
    std::vector<LapLossComponent> total_components;
    std::vector<CornerLossReport> corners;
    std::vector<std::string> coaching_priorities;
};

class LapTimeAttributionCoach {
public:
    [[nodiscard]] LapAttributionReport analyze(const std::vector<LapTelemetrySample>& driver,
                                                const std::vector<LapTelemetrySample>& reference) const;
};

// ---------------------------------------------------------------------------
// 10. GT3 / GT4 customer-racing ecosystem
// ---------------------------------------------------------------------------

enum class GtCategory { Gt3, Gt4, OneMakeCup };
enum class GtDriverClass { Bronze, Silver, Gold, Platinum };

struct GtVehicle {
    std::string id;
    GtCategory category = GtCategory::Gt3;
    double mass_kg = 1300.0;
    double power_kw = 430.0;
    double fuel_capacity_kg = 110.0;
    double fuel_kg = 100.0;
    double tyre_life = 1.0;
    double brake_life = 1.0;
    double engine_life_km = 6000.0;
    double gearbox_life_km = 5000.0;
    double accumulated_km = 0.0;
    double damage = 0.0;
};

struct GtDriver { std::string id; GtDriverClass classification = GtDriverClass::Silver; double pace_skill = 0.75; double stint_s = 0.0; };

struct GtTeamEconomics {
    double cash = 500000.0;
    unsigned spare_front_splitters = 3;
    unsigned spare_rear_wings = 2;
    unsigned spare_gearboxes = 1;
    unsigned spare_engines = 1;
    double parts_spend = 0.0;
    double running_cost = 0.0;
};

struct GtEventRules {
    double minimum_pit_stop_s = 0.0;
    double maximum_driver_stint_s = 3600.0;
    double minimum_am_driver_time_s = 0.0;
    bool refuel_and_tyres_concurrent = false;
    bool require_driver_change = false;
};

struct GtStintReport {
    GtVehicle vehicle;
    GtTeamEconomics economics;
    double elapsed_s = 0.0;
    double average_lap_s = 0.0;
    double fuel_used_kg = 0.0;
    double operating_cost = 0.0;
    double failure_probability = 0.0;
    std::vector<std::string> rule_violations;
};

struct GtPitServiceRequest {
    double fuel_add_kg = 0.0;
    bool tyres = false;
    bool driver_change = false;
    bool splitter = false;
    bool rear_wing = false;
    bool gearbox = false;
    bool engine = false;
};

struct GtPitServiceReport {
    GtVehicle vehicle;
    GtTeamEconomics economics;
    double stationary_time_s = 0.0;
    std::vector<std::string> rule_violations;
};

class GtCustomerRacingPlatform {
public:
    [[nodiscard]] GtStintReport run_stint(const GtVehicle& vehicle,
                                           const GtDriver& driver,
                                           const GtTeamEconomics& economics,
                                           const GtEventRules& rules,
                                           double duration_s,
                                           double lap_length_km,
                                           double rain,
                                           double bop_power_factor = 1.0,
                                           double bop_mass_delta_kg = 0.0) const;
    [[nodiscard]] GtPitServiceReport service(const GtVehicle& vehicle,
                                              const GtTeamEconomics& economics,
                                              const GtEventRules& rules,
                                              const GtPitServiceRequest& request) const;
};

[[nodiscard]] std::vector<std::string> motorsport_v35_capabilities();

} // namespace aesim::advanced::motorsport

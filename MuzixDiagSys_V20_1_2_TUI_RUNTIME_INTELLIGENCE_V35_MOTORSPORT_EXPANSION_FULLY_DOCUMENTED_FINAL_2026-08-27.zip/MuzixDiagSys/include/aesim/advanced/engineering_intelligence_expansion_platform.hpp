#pragma once

#include "aesim/professional/document.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace aesim::advanced::intelligence {

// -----------------------------------------------------------------------------
// Engineering Intelligence Expansion: ten additive, non-duplicating domains.
// -----------------------------------------------------------------------------

struct HarnessPoint3d {
    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
};

struct HarnessEndpoint3d {
    std::string id;
    HarnessPoint3d position;
    std::string zone;
};

struct HarnessKeepOutBox {
    std::string id;
    HarnessPoint3d minimum;
    HarnessPoint3d maximum;
    double clearance_m = 0.0;
    double proximity_penalty = 0.0;
};

struct HarnessRouteRequirement {
    std::string id;
    std::string source_endpoint;
    std::string destination_endpoint;
    double bundle_diameter_m = 0.01;
    double minimum_bend_radius_m = 0.02;
    double maximum_length_m = 1.0e9;
    double clip_spacing_m = 0.30;
    double service_loop_length_m = 0.0;
    double mass_kg_per_m = 0.1;
    double cost_per_m = 1.0;
    double conductor_area_m2 = 1.0e-6;
    double current_a = 0.0;
};

struct HarnessRouteGeometry {
    std::string id;
    std::vector<HarnessPoint3d> points;
    double length_m = 0.0;
    double minimum_realized_bend_radius_m = 0.0;
    std::size_t bend_count = 0;
    std::size_t clip_count = 0;
    double mass_kg = 0.0;
    double cost = 0.0;
    bool collision_free = false;
    bool bend_radius_compliant = false;
    bool length_compliant = false;
    bool manufacturable = false;
    std::vector<std::string> diagnostics;
    [[nodiscard]] doc::Value to_document() const;
};

struct HarnessSynthesisResult {
    std::vector<HarnessRouteGeometry> routes;
    double total_length_m = 0.0;
    double total_mass_kg = 0.0;
    double total_cost = 0.0;
    std::size_t total_clips = 0;
    bool manufacturable = false;
    doc::Value canonical_reliability_input;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class GeometricWiringHarnessSynthesizer {
public:
    [[nodiscard]] HarnessSynthesisResult synthesize(
        const std::vector<HarnessEndpoint3d>& endpoints,
        const std::vector<HarnessKeepOutBox>& keep_outs,
        const std::vector<HarnessRouteRequirement>& requirements,
        double grid_resolution_m = 0.05,
        std::size_t maximum_expanded_nodes = 500000) const;
};

// -----------------------------------------------------------------------------
// Vehicle Function Interaction & Actuator Arbitration Engine
// -----------------------------------------------------------------------------

struct ActuatorArbitrationDefinition {
    std::string id;
    double minimum_value = -1.0e9;
    double maximum_value = 1.0e9;
    double maximum_slew_per_s = 1.0e9;
    double conflict_threshold = 0.0;
};

struct VehicleFunctionCommand {
    double time_s = 0.0;
    std::string function_id;
    std::string actuator_id;
    double requested_value = 0.0;
    int priority = 0;
    double authority = 1.0;
    double blend_weight = 1.0;
    bool driver_override = false;
    std::string exclusive_group;
};

struct ActuatorArbitrationSample {
    double time_s = 0.0;
    std::string actuator_id;
    double requested_minimum = 0.0;
    double requested_maximum = 0.0;
    double output_value = 0.0;
    std::vector<std::string> active_functions;
    std::vector<std::string> winning_functions;
    bool conflict = false;
    bool saturated = false;
    bool slew_limited = false;
    bool ownership_changed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct VehicleFunctionInteractionResult {
    std::vector<ActuatorArbitrationSample> timeline;
    std::map<std::string, std::size_t> conflict_count;
    std::map<std::string, std::size_t> ownership_switch_count;
    std::map<std::string, double> maximum_request_spread;
    std::vector<std::string> interaction_diagnostics;
    bool stable_arbitration = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class VehicleFunctionActuatorArbitrationEngine {
public:
    [[nodiscard]] VehicleFunctionInteractionResult evaluate(
        const std::vector<ActuatorArbitrationDefinition>& actuators,
        std::vector<VehicleFunctionCommand> commands,
        std::size_t maximum_owner_switches_per_actuator = 1000) const;
};

// -----------------------------------------------------------------------------
// Age-of-Information / Data Freshness Laboratory
// -----------------------------------------------------------------------------

struct InformationFreshnessSample {
    std::string stream_id;
    std::uint64_t sequence = 0;
    double generation_time_s = 0.0;
    double arrival_time_s = 0.0;
    double consumption_time_s = 0.0;
    double freshness_budget_s = 1.0e9;
    double base_variance = 0.0;
    double variance_time_constant_s = 1.0;
};

struct InformationFreshnessStreamReport {
    std::string stream_id;
    std::size_t samples = 0;
    double mean_age_s = 0.0;
    double maximum_age_s = 0.0;
    double p95_age_s = 0.0;
    double mean_transport_delay_s = 0.0;
    double mean_processing_delay_s = 0.0;
    double violation_fraction = 0.0;
    double time_weighted_mean_age_s = 0.0;
    double peak_estimator_variance = 0.0;
    bool fresh = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct InformationFreshnessResult {
    std::map<std::string, InformationFreshnessStreamReport> streams;
    double worst_age_s = 0.0;
    double worst_violation_fraction = 0.0;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AgeOfInformationFreshnessLaboratory {
public:
    [[nodiscard]] InformationFreshnessResult analyze(
        std::vector<InformationFreshnessSample> samples,
        double maximum_allowed_violation_fraction = 0.0) const;
};

// -----------------------------------------------------------------------------
// ADAS Service Calibration & Workshop Metrology Laboratory
// -----------------------------------------------------------------------------

enum class WorkshopSensorKind { Camera, Radar, Lidar };
enum class WorkshopCalibrationProcedure { StaticTarget, DynamicRoad };

struct WorkshopMetrologySetup {
    double target_position_standard_uncertainty_mm = 0.5;
    double target_angle_standard_uncertainty_deg = 0.02;
    double floor_slope_standard_uncertainty_deg = 0.02;
    double wheel_alignment_standard_uncertainty_deg = 0.02;
    double steering_center_standard_uncertainty_deg = 0.02;
    double ride_height_standard_uncertainty_mm = 1.0;
};

struct WorkshopAlignmentObservation {
    std::string sensor_id;
    double true_yaw_deg = 0.0;
    double measured_yaw_deg = 0.0;
    double true_pitch_deg = 0.0;
    double measured_pitch_deg = 0.0;
    double standard_uncertainty_deg = 0.05;
};

struct WorkshopSensorCalibrationRequest {
    std::string id;
    WorkshopSensorKind kind = WorkshopSensorKind::Camera;
    WorkshopCalibrationProcedure procedure = WorkshopCalibrationProcedure::StaticTarget;
    double yaw_tolerance_deg = 0.5;
    double pitch_tolerance_deg = 0.5;
};

struct WorkshopSensorCalibrationResult {
    std::string id;
    std::string kind;
    double yaw_correction_deg = 0.0;
    double pitch_correction_deg = 0.0;
    double yaw_standard_uncertainty_deg = 0.0;
    double pitch_standard_uncertainty_deg = 0.0;
    double expanded_yaw_uncertainty_deg = 0.0;
    double expanded_pitch_uncertainty_deg = 0.0;
    double maximum_precalibration_error_deg = 0.0;
    bool calibration_feasible = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct WorkshopCalibrationReport {
    std::vector<WorkshopSensorCalibrationResult> sensors;
    bool all_sensors_calibratable = false;
    double worst_expanded_uncertainty_deg = 0.0;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class AdasServiceCalibrationWorkshopMetrologyLaboratory {
public:
    [[nodiscard]] WorkshopCalibrationReport evaluate(
        const WorkshopMetrologySetup& setup,
        const std::vector<WorkshopSensorCalibrationRequest>& sensors,
        const std::vector<WorkshopAlignmentObservation>& observations) const;
};

// -----------------------------------------------------------------------------
// Embedded Software Memory & Resource Degradation Laboratory
// -----------------------------------------------------------------------------

enum class EmbeddedResourceEventKind {
    Allocate, Free, StackUse, QueueDepth, HandleOpen, HandleClose
};

struct EmbeddedResourceEvent {
    double time_s = 0.0;
    std::string thread_id;
    EmbeddedResourceEventKind kind = EmbeddedResourceEventKind::Allocate;
    std::string resource_id;
    std::size_t amount = 0;
    std::size_t alignment = 1;
};

struct EmbeddedResourceConfiguration {
    std::size_t heap_bytes = 1024 * 1024;
    std::size_t stack_limit_bytes = 64 * 1024;
    std::size_t queue_capacity = 1024;
    std::size_t handle_capacity = 1024;
    bool best_fit_allocator = false;
};

struct EmbeddedResourceDegradationResult {
    std::size_t peak_heap_bytes = 0;
    std::size_t final_heap_bytes = 0;
    std::size_t largest_free_block_bytes = 0;
    double peak_external_fragmentation = 0.0;
    std::map<std::string, std::size_t> stack_high_water_bytes;
    std::size_t peak_queue_depth = 0;
    std::size_t peak_handles = 0;
    std::size_t allocation_failures = 0;
    std::size_t invalid_frees = 0;
    std::size_t leaked_allocations = 0;
    bool resource_safe = false;
    std::vector<std::string> diagnostics;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class EmbeddedSoftwareResourceDegradationLaboratory {
public:
    [[nodiscard]] EmbeddedResourceDegradationResult simulate(
        const EmbeddedResourceConfiguration& configuration,
        std::vector<EmbeddedResourceEvent> events) const;
};

// -----------------------------------------------------------------------------
// Concurrent ECU Software Race & Lock-Order Analyzer
// -----------------------------------------------------------------------------

enum class ConcurrencyTraceEventKind {
    Read, Write, Lock, Unlock, TryLockFailed, Progress
};

struct ConcurrencyTraceEvent {
    std::uint64_t sequence = 0;
    std::string thread_id;
    ConcurrencyTraceEventKind kind = ConcurrencyTraceEventKind::Read;
    std::string object_id;
};

struct ConcurrencyRaceFinding {
    std::string object_id;
    std::string first_thread;
    std::string second_thread;
    std::uint64_t first_sequence = 0;
    std::uint64_t second_sequence = 0;
    std::string first_access;
    std::string second_access;
    [[nodiscard]] doc::Value to_document() const;
};

struct ConcurrentEcuAnalysisResult {
    std::vector<ConcurrencyRaceFinding> data_races;
    std::vector<std::vector<std::string>> lock_order_cycles;
    std::vector<std::string> misuse_diagnostics;
    std::map<std::string, std::size_t> failed_try_lock_count;
    std::map<std::string, std::size_t> progress_count;
    bool race_free = false;
    bool deadlock_order_free = false;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ConcurrentEcuRaceLockOrderAnalyzer {
public:
    [[nodiscard]] ConcurrentEcuAnalysisResult analyze(
        std::vector<ConcurrencyTraceEvent> events,
        std::size_t starvation_failed_try_lock_threshold = 1000) const;
};

// -----------------------------------------------------------------------------
// Cross-Fluid Condition Chemistry & Service Diagnostics Laboratory
// -----------------------------------------------------------------------------

enum class VehicleFluidKind {
    EngineOil, TransmissionOil, DifferentialOil, Coolant, BrakeFluid,
    RefrigerantOil, HydraulicFluid
};

struct VehicleFluidConditionSample {
    std::string id;
    VehicleFluidKind kind = VehicleFluidKind::EngineOil;
    double service_hours = 0.0;
    double temperature_c = 25.0;
    double water_ppm = 0.0;
    double water_percent = 0.0;
    double viscosity_cst = 0.0;
    double conductivity_us_cm = 0.0;
    double ph = 7.0;
    double glycol_fraction = 0.0;
    double boiling_point_c = 0.0;
    double tan_mg_koh_g = 0.0;
    double tbn_mg_koh_g = 0.0;
    double oxidation_fraction = 0.0;
    double additive_fraction = 1.0;
    double soot_mass_fraction = 0.0;
    double fuel_dilution_fraction = 0.0;
    double wear_metal_ppm = 0.0;
    double particle_index = 0.0;
    double acid_number_mg_koh_g = 0.0;
};

struct VehicleFluidConditionResult {
    std::string id;
    std::string kind;
    double condition_score = 100.0;
    std::string service_state;
    std::vector<std::string> alerts;
    doc::Value canonical_oil_condition;
    bool passed = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct CrossFluidConditionReport {
    std::vector<VehicleFluidConditionResult> fluids;
    std::vector<std::string> cross_fluid_diagnostics;
    double fleet_minimum_condition_score = 0.0;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class CrossFluidConditionChemistryDiagnosticsLaboratory {
public:
    [[nodiscard]] CrossFluidConditionReport evaluate(
        const std::vector<VehicleFluidConditionSample>& samples) const;
};

// -----------------------------------------------------------------------------
// EV Charging Connector Mechanical & Contact-Aging Laboratory
// -----------------------------------------------------------------------------

struct ChargingConnectorAgingProfile {
    double voltage_v = 400.0;
    double current_a = 200.0;
    double ambient_temperature_c = 25.0;
    double initial_contact_resistance_ohm = 0.0001;
    double initial_insertion_force_n = 50.0;
    double initial_retention_force_n = 80.0;
    double insulation_resistance_ohm = 1.0e8;
    double plating_thickness_um = 5.0;
    std::uint64_t mating_cycles = 0;
    double contamination_fraction = 0.0;
    double humidity_fraction = 0.5;
    double misalignment_fraction = 0.0;
    double cable_strain_fraction = 0.0;
    std::uint64_t arc_events = 0;
    double thermal_resistance_k_per_w = 0.08;
};

struct ChargingConnectorAgingResult {
    double remaining_plating_thickness_um = 0.0;
    double contact_resistance_ohm = 0.0;
    double connector_temperature_c = 0.0;
    double insertion_force_n = 0.0;
    double retention_force_n = 0.0;
    double mechanical_damage_index = 0.0;
    double corrosion_index = 0.0;
    double connector_loss_w = 0.0;
    bool j3400_physical_compliant = false;
    bool j3400_thermal_compliant = false;
    bool passed = false;
    doc::Value canonical_conformance_report;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ChargingConnectorMechanicalContactAgingLaboratory {
public:
    [[nodiscard]] ChargingConnectorAgingResult evaluate(
        const ChargingConnectorAgingProfile& profile) const;
};

// -----------------------------------------------------------------------------
// Scientific Hypothesis Discovery & Discriminating-Experiment Planner
// -----------------------------------------------------------------------------

struct ScientificObservationTable {
    std::vector<std::string> variables;
    std::vector<std::vector<double>> rows;
    std::string target_variable;
};

struct ScientificHypothesisCandidate {
    std::string id;
    std::string predictor;
    std::string target;
    double correlation = 0.0;
    double confounder_penalty = 0.0;
    double prior = 0.0;
    bool causal_claim = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct DiscriminatingExperimentCandidate {
    std::string id;
    double cost = 1.0;
    std::vector<std::string> outcomes;
    std::map<std::string, std::map<std::string, double>> outcome_probability_by_hypothesis;
};

struct ScientificHypothesisPlanningResult {
    std::vector<ScientificHypothesisCandidate> discovered_hypotheses;
    doc::Value canonical_bayesian_design;
    std::string recommended_experiment;
    double prior_entropy_bits = 0.0;
    bool generated_causal_claims = false;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class ScientificHypothesisDiscoveryExperimentPlanner {
public:
    [[nodiscard]] ScientificHypothesisPlanningResult analyze(
        const ScientificObservationTable& observations,
        const std::vector<DiscriminatingExperimentCandidate>& experiments,
        double minimum_absolute_correlation = 0.25,
        double cost_weight = 0.0) const;
};

// -----------------------------------------------------------------------------
// HPC Experiment Novelty & Redundancy Detector
// -----------------------------------------------------------------------------

struct HpcExperimentEmbedding {
    std::string id;
    std::vector<double> behavior;
    double uncertainty = 0.0;
    double estimated_compute_cost = 1.0;
    bool completed = false;
};

struct HpcNoveltyDecision {
    std::string id;
    double nearest_distance = 0.0;
    std::string nearest_existing_id;
    double novelty_score = 0.0;
    double scheduling_utility = 0.0;
    bool redundant = false;
    bool schedule = false;
    [[nodiscard]] doc::Value to_document() const;
};

struct HpcNoveltyCampaignResult {
    std::vector<HpcNoveltyDecision> decisions;
    std::vector<std::string> scheduled_ids;
    std::vector<std::string> suppressed_redundant_ids;
    double baseline_mean_behavior_novelty = 0.0;
    doc::Value canonical_scenario_coverage;
    bool passed = false;
    std::string evidence_sha256;
    [[nodiscard]] doc::Value to_document() const;
};

class HpcExperimentNoveltyRedundancyDetector {
public:
    [[nodiscard]] HpcNoveltyCampaignResult evaluate(
        const std::vector<HpcExperimentEmbedding>& experiments,
        double redundancy_distance_threshold,
        std::size_t maximum_new_experiments,
        double uncertainty_weight = 1.0,
        double cost_weight = 0.0) const;
};

[[nodiscard]] std::vector<std::string> engineering_intelligence_expansion_domains();
[[nodiscard]] std::optional<doc::Value> execute_engineering_intelligence_expansion_domain(
    const std::string& domain,
    const doc::Value& request,
    const std::string& working_directory = {});
[[nodiscard]] std::vector<std::pair<std::string, doc::Value>> engineering_intelligence_expansion_self_test_requests();

} // namespace aesim::advanced::intelligence

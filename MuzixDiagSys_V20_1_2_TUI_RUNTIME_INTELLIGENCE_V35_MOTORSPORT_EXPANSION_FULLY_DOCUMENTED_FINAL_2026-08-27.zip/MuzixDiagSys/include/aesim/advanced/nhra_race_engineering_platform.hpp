#pragma once

#include "aesim/professional/document.hpp"

#include <string>

namespace aesim::advanced::nhra {

// Deterministic NHRA run-by-run physics, track, service, and learning laboratory.
class NhraRaceEngineeringPlatform {
public:
    [[nodiscard]] doc::Value capabilities() const;
    [[nodiscard]] doc::Value execute(const std::string& domain,
                                     const doc::Value& request,
                                     const std::string& working_directory = {}) const;
    [[nodiscard]] doc::Value self_test(const std::string& working_directory = {}) const;
};

} // namespace aesim::advanced::nhra

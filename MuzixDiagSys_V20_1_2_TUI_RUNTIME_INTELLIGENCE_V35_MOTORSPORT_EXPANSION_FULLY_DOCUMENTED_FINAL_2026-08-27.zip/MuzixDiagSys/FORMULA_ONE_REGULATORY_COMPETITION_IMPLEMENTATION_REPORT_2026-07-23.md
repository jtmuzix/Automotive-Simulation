# Formula One Regulatory and Competition Expansion - Implementation Report

**Date:** 2026-07-23

## Scope

This release implements ten Formula One-only systems:

1. 2026 ERS Hardware, Energy Metering, and Overtake Mode Laboratory
2. Full-Field 22-Car, 11-Team Competition Engine
3. Championship, Points, Entries, and Super-Licence Platform
4. Power-Unit Homologation, Supply, Customer Parity, and Pool Platform
5. ATR, Wind-Tunnel, CFD, Testing, and Factory-Operations Compliance Engine
6. FIA Remote Operations and Multimodal Race-Control Fusion Center
7. Pit-Lane and Parc Ferme Computer-Vision Officiating
8. Appeals, Protests, Technical Directives, and Precedent Compiler
9. Accident Reconstruction, ADR, and Black-Box Forensics Laboratory
10. Grade 1 Circuit Homologation and Safety-Design Platform

No NASCAR or IndyCar production implementation was modified. The only shared files changed are the build graph, umbrella API export, advanced CLI, package/document regressions, and common user documentation needed to expose and validate the Formula One expansion.

## Public implementations

| System | Public class |
|---|---|
| 2026 ERS hardware and metering | `F12026ErsElectrothermalLaboratory` |
| 22-car full-field competition | `F1FullFieldCompetitionEngine` |
| Championship and Super-Licence governance | `F1ChampionshipGovernancePlatform` |
| Power-unit homologation and parity | `F1PowerUnitHomologationPlatform` |
| ATR, CFD, testing, and shutdown compliance | `F1OperationalRestrictionsPlatform` |
| FIA remote race-control fusion | `F1RemoteRaceControlFusionCenter` |
| Pit-lane and parc ferme vision | `F1PitLaneVisionOfficiatingPlatform` |
| Appeals, directives, and precedent | `F1RegulatoryCaseLawCompiler` |
| ADR and accident reconstruction | `F1AccidentReconstructionLaboratory` |
| Grade 1 circuit qualification | `F1CircuitHomologationPlatform` |

The aggregate dispatcher is `FormulaOneRegulatoryCompetitionPlatform`, exposed through the `f1-regulatory` CLI family.

## Source integration

The release adds:

- `include/aesim/advanced/formula_one_regulatory_competition_platform.hpp`
- `src/advanced/formula_one_regulatory_competition_internal.hpp`
- `src/advanced/formula_one_regulatory_competition_platform_a.cpp`
- `src/advanced/formula_one_regulatory_competition_platform_b.cpp`
- `src/advanced/formula_one_regulatory_competition_platform_c.cpp`
- `tests/formula_one_regulatory_competition_platform_tests.cpp`
- `tests/formula_one_regulatory_competition_source_regression.py`
- ten canonical request examples under `examples/formula_one_regulatory_competition/`
- `docs/FORMULA_ONE_REGULATORY_COMPETITION_PLATFORM.md`

A focused static library, `aesim_formula_one`, now owns all existing and new Formula One production sources. `aesim_advanced` links it publicly. Existing public headers and namespaces remain unchanged, and aggregate consumers retain transitive access.

## Numerical and regulatory behavior

The ERS solver uses terminal-voltage/current equations, current and energy limits, SOC conservation, exact first-order thermal states, Overtake Mode legality checks, isolation gating, and uncertainty-aware metering. The race engine uses a fixed-seed deterministic RNG, exact per-lap reliability conversion, full 22-car/11-team validation, end-of-lap order, and overtake counting that excludes pit and retirement effects.

Governance systems use explicit rule versions, unique identifiers, chronology, eligibility, supply parity, element pools, ATR entitlement, test categories, shutdown intervals, evidence synchronization, authenticated availability, pit observation ordering, procedural deadlines, precedent similarity, contact-pair reconstruction, and physics-derived circuit safety requirements.

All reports use canonical JSON and SHA-256 evidence digests. Optional report output uses atomic file replacement.

## Compatibility

The following existing Formula One suites continue to compile and pass through `aesim_formula_one`:

- platform
- race engineering
- performance laboratory
- team competition
- design qualification
- frontier laboratory
- physical operations
- championship operations

The new regulatory/competition suite is the ninth focused Formula One test family in the current CTest selection and the tenth Formula One production module overall.

## Documentation

The authoritative manual adds Chapter 46. The practical tutorial adds Section 17. The README, documentation index, package inventory, source-completeness checks, and cross-document regression have been updated. The active PDF and DOCX artifacts are regenerated from the authoritative Markdown sources and subjected to render-level inspection.

## Qualification statement

The software provides configurable engineering and evidence workflows. It does not issue official FIA approvals, licences, rulings, penalties, homologation certificates, medical conclusions, or legal determinations.


## 2026-08-22 second ten-domain regulatory/forensics expansion

The regulatory façade was extended additively from 20 to 30 domains. The new production implementation resides in `src/advanced/formula_one_regulatory_competition_platform_d.cpp` and is exported through the existing public header and dispatcher. Implemented systems are personnel/restricted-period governance; regulation migration/design-impact planning; hot/cold compression-ratio metrology; hybrid degraded-mode qualification; tyre pressure/blanket forensics; dynamic on-track aero-deflection photogrammetry; pit-equipment/unsafe-release interlocking; persistent FOD/debris-field simulation; Bayesian causal fault isolation; and controlled rulebook-to-executable-check compilation. Existing domains and command names remain unchanged.
